// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.detect;

import java.util.Collection;
import org.apache.tika.utils.ServiceLoaderUtils;
import java.util.List;
import org.apache.tika.mime.MimeTypes;
import org.apache.tika.config.ServiceLoader;

public class DefaultDetector extends CompositeDetector
{
    private static final long serialVersionUID = -8170114575326908027L;
    private final transient ServiceLoader loader;
    
    private static List<Detector> getDefaultDetectors(final MimeTypes types, final ServiceLoader loader) {
        final List<Detector> detectors = loader.loadStaticServiceProviders(Detector.class);
        ServiceLoaderUtils.sortLoadedClasses(detectors);
        detectors.add(types);
        return detectors;
    }
    
    public DefaultDetector(final MimeTypes types, final ServiceLoader loader, final Collection<Class<? extends Detector>> excludeDetectors) {
        super(types.getMediaTypeRegistry(), getDefaultDetectors(types, loader), excludeDetectors);
        this.loader = loader;
    }
    
    public DefaultDetector(final MimeTypes types, final ServiceLoader loader) {
        this(types, loader, null);
    }
    
    public DefaultDetector(final MimeTypes types, final ClassLoader loader) {
        this(types, new ServiceLoader(loader));
    }
    
    public DefaultDetector(final ClassLoader loader) {
        this(MimeTypes.getDefaultMimeTypes(), loader);
    }
    
    public DefaultDetector(final MimeTypes types) {
        this(types, new ServiceLoader());
    }
    
    public DefaultDetector() {
        this(MimeTypes.getDefaultMimeTypes());
    }
    
    @Override
    public List<Detector> getDetectors() {
        if (this.loader != null) {
            final List<Detector> detectors = this.loader.loadDynamicServiceProviders(Detector.class);
            detectors.addAll(super.getDetectors());
            return detectors;
        }
        return super.getDetectors();
    }
}
