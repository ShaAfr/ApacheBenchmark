// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.parser;

import org.apache.tika.utils.ExceptionUtils;
import org.xml.sax.helpers.DefaultHandler;
import org.apache.tika.io.FilenameUtils;
import org.apache.tika.exception.TikaException;
import java.io.IOException;
import org.xml.sax.SAXException;
import java.util.Date;
import org.xml.sax.ContentHandler;
import java.io.InputStream;
import org.apache.tika.mime.MediaType;
import java.util.Set;
import java.util.LinkedList;
import org.apache.tika.metadata.Metadata;
import java.util.List;
import org.apache.tika.sax.ContentHandlerFactory;
import org.apache.tika.metadata.Property;

public class RecursiveParserWrapper implements Parser
{
    private static final long serialVersionUID = 9086536568120690938L;
    public static final Property TIKA_CONTENT;
    public static final Property PARSE_TIME_MILLIS;
    public static final Property WRITE_LIMIT_REACHED;
    public static final Property EMBEDDED_RESOURCE_LIMIT_REACHED;
    public static final Property EMBEDDED_EXCEPTION;
    public static final Property EMBEDDED_RESOURCE_PATH;
    private final Parser wrappedParser;
    private final ContentHandlerFactory contentHandlerFactory;
    private final List<Metadata> metadatas;
    private final boolean catchEmbeddedExceptions;
    private int unknownCount;
    private int maxEmbeddedResources;
    private boolean hitMaxEmbeddedResources;
    
    public RecursiveParserWrapper(final Parser wrappedParser, final ContentHandlerFactory contentHandlerFactory) {
        this(wrappedParser, contentHandlerFactory, true);
    }
    
    public RecursiveParserWrapper(final Parser wrappedParser, final ContentHandlerFactory contentHandlerFactory, final boolean catchEmbeddedExceptions) {
        this.metadatas = new LinkedList<Metadata>();
        this.unknownCount = 0;
        this.maxEmbeddedResources = -1;
        this.hitMaxEmbeddedResources = false;
        this.wrappedParser = wrappedParser;
        this.contentHandlerFactory = contentHandlerFactory;
        this.catchEmbeddedExceptions = catchEmbeddedExceptions;
    }
    
    @Override
    public Set<MediaType> getSupportedTypes(final ParseContext context) {
        return this.wrappedParser.getSupportedTypes(context);
    }
    
    @Override
    public void parse(final InputStream stream, final ContentHandler ignore, final Metadata metadata, final ParseContext context) throws IOException, SAXException, TikaException {
        final EmbeddedParserDecorator decorator = new EmbeddedParserDecorator("/");
        context.set(Parser.class, decorator);
        final ContentHandler localHandler = this.contentHandlerFactory.getNewContentHandler();
        final long started = new Date().getTime();
        try {
            this.wrappedParser.parse(stream, localHandler, metadata, context);
        }
        catch (SAXException e) {
            final boolean wlr = this.isWriteLimitReached(e);
            if (!wlr) {
                throw e;
            }
            metadata.set(RecursiveParserWrapper.WRITE_LIMIT_REACHED, "true");
        }
        finally {
            final long elapsedMillis = new Date().getTime() - started;
            metadata.set(RecursiveParserWrapper.PARSE_TIME_MILLIS, Long.toString(elapsedMillis));
            this.addContent(localHandler, metadata);
            if (this.hitMaxEmbeddedResources) {
                metadata.set(RecursiveParserWrapper.EMBEDDED_RESOURCE_LIMIT_REACHED, "true");
            }
            this.metadatas.add(0, this.deepCopy(metadata));
        }
    }
    
    public List<Metadata> getMetadata() {
        return this.metadatas;
    }
    
    public void setMaxEmbeddedResources(final int max) {
        this.maxEmbeddedResources = max;
    }
    
    public void reset() {
        this.metadatas.clear();
        this.unknownCount = 0;
        this.hitMaxEmbeddedResources = false;
    }
    
    private boolean isWriteLimitReached(final Throwable t) {
        return (t.getMessage() != null && t.getMessage().indexOf("Your document contained more than") == 0) || (t.getCause() != null && this.isWriteLimitReached(t.getCause()));
    }
    
    private Metadata deepCopy(final Metadata m) {
        final Metadata clone = new Metadata();
        for (final String n : m.names()) {
            if (!m.isMultiValued(n)) {
                clone.set(n, m.get(n));
            }
            else {
                final String[] vals = m.getValues(n);
                for (int i = 0; i < vals.length; ++i) {
                    clone.add(n, vals[i]);
                }
            }
        }
        return clone;
    }
    
    private String getResourceName(final Metadata metadata) {
        String objectName = "";
        if (metadata.get("resourceName") != null) {
            objectName = metadata.get("resourceName");
        }
        else if (metadata.get("embeddedRelationshipId") != null) {
            objectName = metadata.get("embeddedRelationshipId");
        }
        else {
            objectName = "embedded-" + ++this.unknownCount;
        }
        objectName = FilenameUtils.getName(objectName);
        return objectName;
    }
    
    private void addContent(final ContentHandler handler, final Metadata metadata) {
        if (!handler.getClass().equals(DefaultHandler.class)) {
            final String content = handler.toString();
            if (content != null && content.trim().length() > 0) {
                metadata.add(RecursiveParserWrapper.TIKA_CONTENT, content);
            }
        }
    }
    
    static {
        TIKA_CONTENT = Property.internalText("X-TIKA:content");
        PARSE_TIME_MILLIS = Property.internalText("X-TIKA:parse_time_millis");
        WRITE_LIMIT_REACHED = Property.internalBoolean("X-TIKA:EXCEPTION:write_limit_reached");
        EMBEDDED_RESOURCE_LIMIT_REACHED = Property.internalBoolean("X-TIKA:EXCEPTION:embedded_resource_limit_reached");
        EMBEDDED_EXCEPTION = Property.internalText("X-TIKA:EXCEPTION:embedded_exception");
        EMBEDDED_RESOURCE_PATH = Property.internalText("X-TIKA:embedded_resource_path");
    }
    
    private class EmbeddedParserDecorator extends ParserDecorator
    {
        private static final long serialVersionUID = 207648200464263337L;
        private String location;
        
        private EmbeddedParserDecorator(final String location) {
            super(RecursiveParserWrapper.this.wrappedParser);
            this.location = null;
            this.location = location;
            if (!this.location.endsWith("/")) {
                this.location += "/";
            }
        }
        
        @Override
        public void parse(final InputStream stream, final ContentHandler ignore, final Metadata metadata, final ParseContext context) throws IOException, SAXException, TikaException {
            if (RecursiveParserWrapper.this.maxEmbeddedResources > -1 && RecursiveParserWrapper.this.metadatas.size() >= RecursiveParserWrapper.this.maxEmbeddedResources) {
                RecursiveParserWrapper.this.hitMaxEmbeddedResources = true;
                return;
            }
            final String objectName = RecursiveParserWrapper.this.getResourceName(metadata);
            final String objectLocation = this.location + objectName;
            metadata.add(RecursiveParserWrapper.EMBEDDED_RESOURCE_PATH, objectLocation);
            final ContentHandler localHandler = RecursiveParserWrapper.this.contentHandlerFactory.getNewContentHandler();
            final Parser preContextParser = context.get(Parser.class);
            context.set((Class<EmbeddedParserDecorator>)Parser.class, new EmbeddedParserDecorator(objectLocation));
            final long started = new Date().getTime();
            Label_0409: {
                try {
                    super.parse(stream, localHandler, metadata, context);
                }
                catch (SAXException e) {
                    final boolean wlr = RecursiveParserWrapper.this.isWriteLimitReached(e);
                    if (wlr) {
                        metadata.add(RecursiveParserWrapper.WRITE_LIMIT_REACHED, "true");
                    }
                    else {
                        if (!RecursiveParserWrapper.this.catchEmbeddedExceptions) {
                            throw e;
                        }
                        final String trace = ExceptionUtils.getStackTrace(e);
                        metadata.set(RecursiveParserWrapper.EMBEDDED_EXCEPTION, trace);
                    }
                }
                catch (TikaException e2) {
                    if (RecursiveParserWrapper.this.catchEmbeddedExceptions) {
                        final String trace2 = ExceptionUtils.getStackTrace(e2);
                        metadata.set(RecursiveParserWrapper.EMBEDDED_EXCEPTION, trace2);
                        break Label_0409;
                    }
                    throw e2;
                }
                finally {
                    context.set(Parser.class, preContextParser);
                    final long elapsedMillis = new Date().getTime() - started;
                    metadata.set(RecursiveParserWrapper.PARSE_TIME_MILLIS, Long.toString(elapsedMillis));
                }
            }
            if (RecursiveParserWrapper.this.maxEmbeddedResources > -1 && RecursiveParserWrapper.this.metadatas.size() >= RecursiveParserWrapper.this.maxEmbeddedResources) {
                RecursiveParserWrapper.this.hitMaxEmbeddedResources = true;
                return;
            }
            RecursiveParserWrapper.this.addContent(localHandler, metadata);
            RecursiveParserWrapper.this.metadatas.add(RecursiveParserWrapper.this.deepCopy(metadata));
        }
    }
}
