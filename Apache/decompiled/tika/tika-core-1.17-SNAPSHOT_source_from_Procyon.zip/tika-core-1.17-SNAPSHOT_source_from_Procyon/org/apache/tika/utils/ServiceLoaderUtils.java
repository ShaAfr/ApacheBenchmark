// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.utils;

import org.apache.tika.config.ServiceLoader;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ServiceLoaderUtils
{
    public static <T> void sortLoadedClasses(final List<T> loaded) {
        Collections.sort(loaded, new Comparator<T>() {
            @Override
            public int compare(final T c1, final T c2) {
                final String n1 = c1.getClass().getName();
                final String n2 = c2.getClass().getName();
                final boolean t1 = n1.startsWith("org.apache.tika.");
                final boolean t2 = n2.startsWith("org.apache.tika.");
                if (t1 == t2) {
                    return n1.compareTo(n2);
                }
                if (t1) {
                    return -1;
                }
                return 1;
            }
        });
    }
    
    public static <T> T newInstance(final String className) {
        return newInstance(className, ServiceLoader.class.getClassLoader());
    }
    
    public static <T> T newInstance(final String className, final ClassLoader loader) {
        try {
            final Class<T> castedClass;
            final Class loadedClass = castedClass = (Class<T>)Class.forName(className, true, loader);
            final T instance = castedClass.newInstance();
            return instance;
        }
        catch (ClassNotFoundException | InstantiationException | IllegalAccessException ex2) {
            final ReflectiveOperationException ex;
            final ReflectiveOperationException e = ex;
            throw new RuntimeException(e);
        }
    }
}
