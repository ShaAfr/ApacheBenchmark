// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.sax;

import java.io.UnsupportedEncodingException;
import java.io.OutputStream;
import org.xml.sax.ContentHandler;

public interface ContentHandlerFactory
{
    ContentHandler getNewContentHandler();
    
    ContentHandler getNewContentHandler(final OutputStream p0, final String p1) throws UnsupportedEncodingException;
}
