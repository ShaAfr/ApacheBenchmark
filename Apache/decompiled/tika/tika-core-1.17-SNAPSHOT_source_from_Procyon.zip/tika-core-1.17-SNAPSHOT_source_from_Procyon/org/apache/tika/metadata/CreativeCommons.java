// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.metadata;

public interface CreativeCommons
{
    public static final String LICENSE_URL = "License-Url";
    public static final String LICENSE_LOCATION = "License-Location";
    public static final String WORK_TYPE = "Work-Type";
}
