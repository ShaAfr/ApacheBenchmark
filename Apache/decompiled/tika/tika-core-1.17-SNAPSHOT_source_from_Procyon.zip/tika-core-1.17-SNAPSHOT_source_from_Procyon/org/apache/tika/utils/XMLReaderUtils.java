// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.utils;

import javax.xml.stream.XMLStreamException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import org.xml.sax.InputSource;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import java.util.logging.Level;
import javax.xml.stream.XMLInputFactory;
import org.xml.sax.ErrorHandler;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import org.xml.sax.SAXException;
import org.apache.tika.exception.TikaException;
import org.xml.sax.XMLReader;
import javax.xml.stream.XMLResolver;
import org.xml.sax.EntityResolver;
import java.util.logging.Logger;

public class XMLReaderUtils
{
    private static final Logger LOG;
    private static final EntityResolver IGNORING_SAX_ENTITY_RESOLVER;
    private static final XMLResolver IGNORING_STAX_ENTITY_RESOLVER;
    
    public static XMLReader getXMLReader() throws TikaException {
        XMLReader reader;
        try {
            reader = getSAXParser().getXMLReader();
        }
        catch (SAXException e) {
            throw new TikaException("Unable to create an XMLReader", e);
        }
        reader.setEntityResolver(XMLReaderUtils.IGNORING_SAX_ENTITY_RESOLVER);
        return reader;
    }
    
    public static SAXParser getSAXParser() throws TikaException {
        try {
            return getSAXParserFactory().newSAXParser();
        }
        catch (ParserConfigurationException e) {
            throw new TikaException("Unable to configure a SAX parser", e);
        }
        catch (SAXException e2) {
            throw new TikaException("Unable to create a SAX parser", e2);
        }
    }
    
    public static SAXParserFactory getSAXParserFactory() {
        final SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setValidating(false);
        try {
            factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
        }
        catch (ParserConfigurationException ex) {}
        catch (SAXNotSupportedException ex2) {}
        catch (SAXNotRecognizedException ex3) {}
        return factory;
    }
    
    public static DocumentBuilderFactory getDocumentBuilderFactory() {
        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setExpandEntityReferences(false);
        factory.setNamespaceAware(true);
        factory.setValidating(false);
        trySetSAXFeature(factory, "http://javax.xml.XMLConstants/feature/secure-processing", true);
        trySetSAXFeature(factory, "http://xml.org/sax/features/external-general-entities", false);
        trySetSAXFeature(factory, "http://xml.org/sax/features/external-parameter-entities", false);
        trySetSAXFeature(factory, "http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        trySetSAXFeature(factory, "http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
        return factory;
    }
    
    public static DocumentBuilder getDocumentBuilder() throws TikaException {
        try {
            final DocumentBuilderFactory documentBuilderFactory = getDocumentBuilderFactory();
            final DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            documentBuilder.setEntityResolver(XMLReaderUtils.IGNORING_SAX_ENTITY_RESOLVER);
            documentBuilder.setErrorHandler(null);
            return documentBuilder;
        }
        catch (ParserConfigurationException e) {
            throw new TikaException("XML parser not available", e);
        }
    }
    
    public static XMLInputFactory getXMLInputFactory() {
        final XMLInputFactory factory = XMLInputFactory.newFactory();
        tryToSetStaxProperty(factory, "javax.xml.stream.isNamespaceAware", true);
        tryToSetStaxProperty(factory, "javax.xml.stream.isValidating", false);
        factory.setXMLResolver(XMLReaderUtils.IGNORING_STAX_ENTITY_RESOLVER);
        return factory;
    }
    
    private static void trySetSAXFeature(final DocumentBuilderFactory documentBuilderFactory, final String feature, final boolean enabled) {
        try {
            documentBuilderFactory.setFeature(feature, enabled);
        }
        catch (Exception e) {
            XMLReaderUtils.LOG.log(Level.WARNING, "SAX Feature unsupported: " + feature, e);
        }
        catch (AbstractMethodError ame) {
            XMLReaderUtils.LOG.log(Level.WARNING, "Cannot set SAX feature because outdated XML parser in classpath: " + feature, ame);
        }
    }
    
    private static void tryToSetStaxProperty(final XMLInputFactory factory, final String key, final boolean value) {
        try {
            factory.setProperty(key, value);
        }
        catch (IllegalArgumentException ex) {}
    }
    
    public static Transformer getTransformer() throws TikaException {
        try {
            final TransformerFactory transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
            return transformerFactory.newTransformer();
        }
        catch (TransformerConfigurationException | TransformerFactoryConfigurationError ex) {
            final Throwable t;
            final Throwable e = t;
            throw new TikaException("Transformer not available", e);
        }
    }
    
    static {
        LOG = Logger.getLogger(XMLReaderUtils.class.getName());
        IGNORING_SAX_ENTITY_RESOLVER = new EntityResolver() {
            @Override
            public InputSource resolveEntity(final String publicId, final String systemId) throws SAXException, IOException {
                return new InputSource(new StringReader(""));
            }
        };
        IGNORING_STAX_ENTITY_RESOLVER = new XMLResolver() {
            @Override
            public Object resolveEntity(final String publicID, final String systemID, final String baseURI, final String namespace) throws XMLStreamException {
                return "";
            }
        };
    }
}
