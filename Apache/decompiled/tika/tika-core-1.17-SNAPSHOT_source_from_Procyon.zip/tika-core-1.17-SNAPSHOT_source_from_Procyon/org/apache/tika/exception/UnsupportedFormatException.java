// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.exception;

public class UnsupportedFormatException extends TikaException
{
    public UnsupportedFormatException(final String msg) {
        super(msg);
    }
}
