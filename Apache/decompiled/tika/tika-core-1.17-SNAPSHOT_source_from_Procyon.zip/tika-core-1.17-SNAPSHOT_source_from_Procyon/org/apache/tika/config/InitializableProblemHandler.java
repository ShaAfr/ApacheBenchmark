// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.config;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.tika.exception.TikaConfigException;

public interface InitializableProblemHandler
{
    public static final InitializableProblemHandler IGNORE = new InitializableProblemHandler() {
        @Override
        public void handleInitializableProblem(final String className, final String message) {
        }
        
        @Override
        public String toString() {
            return "IGNORE";
        }
    };
    public static final InitializableProblemHandler INFO = new InitializableProblemHandler() {
        @Override
        public void handleInitializableProblem(final String classname, final String message) {
            Logger.getLogger(classname).log(Level.INFO, message);
        }
        
        @Override
        public String toString() {
            return "INFO";
        }
    };
    public static final InitializableProblemHandler WARN = new InitializableProblemHandler() {
        @Override
        public void handleInitializableProblem(final String classname, final String message) {
            Logger.getLogger(classname).log(Level.WARNING, message);
        }
        
        @Override
        public String toString() {
            return "WARN";
        }
    };
    public static final InitializableProblemHandler THROW = new InitializableProblemHandler() {
        @Override
        public void handleInitializableProblem(final String classname, final String message) throws TikaConfigException {
            throw new TikaConfigException(message);
        }
        
        @Override
        public String toString() {
            return "THROW";
        }
    };
    public static final InitializableProblemHandler DEFAULT = InitializableProblemHandler.WARN;
    
    void handleInitializableProblem(final String p0, final String p1) throws TikaConfigException;
}
