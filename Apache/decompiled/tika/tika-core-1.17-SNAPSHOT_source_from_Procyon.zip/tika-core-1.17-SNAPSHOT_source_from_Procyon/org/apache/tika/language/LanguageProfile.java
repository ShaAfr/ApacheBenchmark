// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.language;

import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Set;
import java.util.Collection;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;

@Deprecated
public class LanguageProfile
{
    public static final int DEFAULT_NGRAM_LENGTH = 3;
    private final int length;
    private final Map<String, Counter> ngrams;
    private Interleaved interleaved;
    public static boolean useInterleaved;
    private long count;
    
    public LanguageProfile(final int length) {
        this.ngrams = new HashMap<String, Counter>();
        this.interleaved = new Interleaved();
        this.count = 0L;
        this.length = length;
    }
    
    public LanguageProfile() {
        this(3);
    }
    
    public LanguageProfile(final String content, final int length) {
        this(length);
        final ProfilingWriter writer = new ProfilingWriter(this);
        final char[] ch = content.toCharArray();
        writer.write(ch, 0, ch.length);
    }
    
    public LanguageProfile(final String content) {
        this(content, 3);
    }
    
    public long getCount() {
        return this.count;
    }
    
    public long getCount(final String ngram) {
        final Counter counter = this.ngrams.get(ngram);
        if (counter != null) {
            return counter.count;
        }
        return 0L;
    }
    
    public void add(final String ngram) {
        this.add(ngram, 1L);
    }
    
    public void add(final String ngram, final long count) {
        if (this.length != ngram.length()) {
            throw new IllegalArgumentException("Unable to add an ngram of incorrect length: " + ngram.length() + " != " + this.length);
        }
        Counter counter = this.ngrams.get(ngram);
        if (counter == null) {
            counter = new Counter();
            this.ngrams.put(ngram, counter);
        }
        final Counter counter2 = counter;
        counter2.count += count;
        this.count += count;
    }
    
    public double distance(final LanguageProfile that) {
        return LanguageProfile.useInterleaved ? this.distanceInterleaved(that) : this.distanceStandard(that);
    }
    
    private double distanceStandard(final LanguageProfile that) {
        if (this.length != that.length) {
            throw new IllegalArgumentException("Unable to calculage distance of language profiles with different ngram lengths: " + that.length + " != " + this.length);
        }
        double sumOfSquares = 0.0;
        final double thisCount = Math.max((double)this.count, 1.0);
        final double thatCount = Math.max((double)that.count, 1.0);
        final Set<String> ngrams = new HashSet<String>();
        ngrams.addAll(this.ngrams.keySet());
        ngrams.addAll(that.ngrams.keySet());
        for (final String ngram : ngrams) {
            final double thisFrequency = this.getCount(ngram) / thisCount;
            final double thatFrequency = that.getCount(ngram) / thatCount;
            final double difference = thisFrequency - thatFrequency;
            sumOfSquares += difference * difference;
        }
        return Math.sqrt(sumOfSquares);
    }
    
    @Override
    public String toString() {
        return this.ngrams.toString();
    }
    
    private double distanceInterleaved(final LanguageProfile that) {
        if (this.length != that.length) {
            throw new IllegalArgumentException("Unable to calculage distance of language profiles with different ngram lengths: " + that.length + " != " + this.length);
        }
        double sumOfSquares = 0.0;
        final double thisCount = Math.max((double)this.count, 1.0);
        final double thatCount = Math.max((double)that.count, 1.0);
        final Interleaved.Entry thisEntry = this.updateInterleaved().firstEntry();
        final Interleaved.Entry thatEntry = that.updateInterleaved().firstEntry();
        while (thisEntry.hasNgram() || thatEntry.hasNgram()) {
            if (!thisEntry.hasNgram()) {
                sumOfSquares += this.square(thatEntry.count / thatCount);
                thatEntry.next();
            }
            else if (!thatEntry.hasNgram()) {
                sumOfSquares += this.square(thisEntry.count / thisCount);
                thisEntry.next();
            }
            else {
                final int compare = thisEntry.compareTo(thatEntry);
                if (compare == 0) {
                    final double difference = thisEntry.count / thisCount - thatEntry.count / thatCount;
                    sumOfSquares += this.square(difference);
                    thisEntry.next();
                    thatEntry.next();
                }
                else if (compare < 0) {
                    sumOfSquares += this.square(thisEntry.count / thisCount);
                    thisEntry.next();
                }
                else {
                    sumOfSquares += this.square(thatEntry.count / thatCount);
                    thatEntry.next();
                }
            }
        }
        return Math.sqrt(sumOfSquares);
    }
    
    private double square(final double count) {
        return count * count;
    }
    
    private Interleaved updateInterleaved() {
        this.interleaved.update();
        return this.interleaved;
    }
    
    static {
        LanguageProfile.useInterleaved = true;
    }
    
    private static class Counter
    {
        private long count;
        
        private Counter() {
            this.count = 0L;
        }
        
        @Override
        public String toString() {
            return Long.toString(this.count);
        }
    }
    
    private class Interleaved
    {
        private char[] entries;
        private int size;
        private long entriesGeneratedAtCount;
        
        private Interleaved() {
            this.entries = null;
            this.size = 0;
            this.entriesGeneratedAtCount = -1L;
        }
        
        public void update() {
            if (LanguageProfile.this.count == this.entriesGeneratedAtCount) {
                return;
            }
            this.size = LanguageProfile.this.ngrams.size();
            final int numChars = (LanguageProfile.this.length + 2) * this.size;
            if (this.entries == null || this.entries.length < numChars) {
                this.entries = new char[numChars];
            }
            int pos = 0;
            for (final Map.Entry<String, Counter> entry : this.getSortedNgrams()) {
                for (int l = 0; l < LanguageProfile.this.length; ++l) {
                    this.entries[pos + l] = entry.getKey().charAt(l);
                }
                this.entries[pos + LanguageProfile.this.length] = (char)(entry.getValue().count / 65536L);
                this.entries[pos + LanguageProfile.this.length + 1] = (char)(entry.getValue().count % 65536L);
                pos += LanguageProfile.this.length + 2;
            }
            this.entriesGeneratedAtCount = LanguageProfile.this.count;
        }
        
        public Entry firstEntry() {
            final Entry entry = new Entry();
            if (this.size > 0) {
                entry.update(0);
            }
            return entry;
        }
        
        private List<Map.Entry<String, Counter>> getSortedNgrams() {
            final List<Map.Entry<String, Counter>> entries = new ArrayList<Map.Entry<String, Counter>>(LanguageProfile.this.ngrams.size());
            entries.addAll(LanguageProfile.this.ngrams.entrySet());
            Collections.sort(entries, new Comparator<Map.Entry<String, Counter>>() {
                @Override
                public int compare(final Map.Entry<String, Counter> o1, final Map.Entry<String, Counter> o2) {
                    return o1.getKey().compareTo((String)o2.getKey());
                }
            });
            return entries;
        }
        
        private class Entry implements Comparable<Entry>
        {
            char[] ngram;
            int count;
            int pos;
            
            private Entry() {
                this.ngram = new char[LanguageProfile.this.length];
                this.count = 0;
                this.pos = 0;
            }
            
            private void update(final int pos) {
                this.pos = pos;
                if (pos >= Interleaved.this.size) {
                    return;
                }
                final int origo = pos * (LanguageProfile.this.length + 2);
                System.arraycopy(Interleaved.this.entries, origo, this.ngram, 0, LanguageProfile.this.length);
                this.count = Interleaved.this.entries[origo + LanguageProfile.this.length] * 65536 + Interleaved.this.entries[origo + LanguageProfile.this.length + 1];
            }
            
            @Override
            public int compareTo(final Entry other) {
                for (int i = 0; i < this.ngram.length; ++i) {
                    if (this.ngram[i] != other.ngram[i]) {
                        return this.ngram[i] - other.ngram[i];
                    }
                }
                return 0;
            }
            
            public boolean hasNext() {
                return this.pos < Interleaved.this.size - 1;
            }
            
            public boolean hasNgram() {
                return this.pos < Interleaved.this.size;
            }
            
            public void next() {
                this.update(this.pos + 1);
            }
            
            @Override
            public String toString() {
                return new String(this.ngram) + "(" + this.count + ")";
            }
        }
    }
}
