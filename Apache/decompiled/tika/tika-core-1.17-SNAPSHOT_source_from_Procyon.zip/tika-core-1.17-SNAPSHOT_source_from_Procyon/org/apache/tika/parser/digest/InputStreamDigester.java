// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.parser.digest;

import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.IOExceptionWithCause;
import org.apache.tika.io.TemporaryResources;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.metadata.Metadata;
import java.io.InputStream;
import java.security.Provider;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import org.apache.tika.parser.DigestingParser;

public class InputStreamDigester implements DigestingParser.Digester
{
    private final String algorithm;
    private final String algorithmKeyName;
    private final DigestingParser.Encoder encoder;
    private final int markLimit;
    
    public InputStreamDigester(final int markLimit, final String algorithm, final DigestingParser.Encoder encoder) {
        this(markLimit, algorithm, algorithm, encoder);
    }
    
    public InputStreamDigester(final int markLimit, final String algorithm, final String algorithmKeyName, final DigestingParser.Encoder encoder) {
        this.algorithm = algorithm;
        this.algorithmKeyName = algorithmKeyName;
        this.encoder = encoder;
        this.markLimit = markLimit;
        if (markLimit < 0) {
            throw new IllegalArgumentException("markLimit must be >= 0");
        }
    }
    
    private MessageDigest newMessageDigest() {
        try {
            final Provider provider = this.getProvider();
            if (provider == null) {
                return MessageDigest.getInstance(this.algorithm);
            }
            return MessageDigest.getInstance(this.algorithm, provider);
        }
        catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    protected Provider getProvider() {
        return null;
    }
    
    @Override
    public void digest(final InputStream is, final Metadata metadata, final ParseContext parseContext) throws IOException {
        final TikaInputStream tis = TikaInputStream.cast(is);
        if (tis != null && tis.hasFile()) {
            long sz = -1L;
            if (tis.hasFile()) {
                sz = tis.getLength();
            }
            if (sz > this.markLimit) {
                this.digestFile(tis.getFile(), metadata);
                return;
            }
        }
        final SimpleBoundedInputStream bis = new SimpleBoundedInputStream((long)this.markLimit, is);
        boolean finishedStream = false;
        bis.mark(this.markLimit + 1);
        finishedStream = this.digestStream(bis, metadata);
        bis.reset();
        if (finishedStream) {
            return;
        }
        if (tis != null) {
            this.digestFile(tis.getFile(), metadata);
        }
        else {
            final TemporaryResources tmp = new TemporaryResources();
            try {
                final TikaInputStream tmpTikaInputStream = TikaInputStream.get(is, tmp);
                this.digestFile(tmpTikaInputStream.getFile(), metadata);
            }
            finally {
                try {
                    tmp.dispose();
                }
                catch (TikaException e) {
                    throw new IOExceptionWithCause(e);
                }
            }
        }
    }
    
    private String getMetadataKey() {
        return "X-TIKA:digest:" + this.algorithmKeyName;
    }
    
    private void digestFile(final File f, final Metadata m) throws IOException {
        try (final InputStream is = new FileInputStream(f)) {
            this.digestStream(is, m);
        }
    }
    
    private boolean digestStream(final InputStream is, final Metadata metadata) throws IOException {
        final MessageDigest messageDigest = this.newMessageDigest();
        updateDigest(messageDigest, is);
        final byte[] digestBytes = messageDigest.digest();
        if (is instanceof SimpleBoundedInputStream && ((SimpleBoundedInputStream)is).hasHitBound()) {
            return false;
        }
        metadata.set(this.getMetadataKey(), this.encoder.encode(digestBytes));
        return true;
    }
    
    private static MessageDigest updateDigest(final MessageDigest digest, final InputStream data) throws IOException {
        final byte[] buffer = new byte[1024];
        for (int read = data.read(buffer, 0, 1024); read > -1; read = data.read(buffer, 0, 1024)) {
            digest.update(buffer, 0, read);
        }
        return digest;
    }
    
    private static class SimpleBoundedInputStream extends InputStream
    {
        private static final int EOF = -1;
        private final long max;
        private final InputStream in;
        private long pos;
        
        private SimpleBoundedInputStream(final long max, final InputStream in) {
            this.max = max;
            this.in = in;
        }
        
        @Override
        public int read() throws IOException {
            if (this.max >= 0L && this.pos >= this.max) {
                return -1;
            }
            final int result = this.in.read();
            ++this.pos;
            return result;
        }
        
        @Override
        public int read(final byte[] b) throws IOException {
            return this.read(b, 0, b.length);
        }
        
        @Override
        public int read(final byte[] b, final int off, final int len) throws IOException {
            if (this.max >= 0L && this.pos >= this.max) {
                return -1;
            }
            final long maxRead = (this.max >= 0L) ? Math.min(len, this.max - this.pos) : len;
            final int bytesRead = this.in.read(b, off, (int)maxRead);
            if (bytesRead == -1) {
                return -1;
            }
            this.pos += bytesRead;
            return bytesRead;
        }
        
        @Override
        public long skip(final long n) throws IOException {
            final long toSkip = (this.max >= 0L) ? Math.min(n, this.max - this.pos) : n;
            final long skippedBytes = this.in.skip(toSkip);
            this.pos += skippedBytes;
            return skippedBytes;
        }
        
        @Override
        public void reset() throws IOException {
            this.in.reset();
            this.pos = 0L;
        }
        
        @Override
        public void mark(final int readLimit) {
            this.in.mark(readLimit);
        }
        
        public boolean hasHitBound() {
            return this.pos >= this.max;
        }
    }
}
