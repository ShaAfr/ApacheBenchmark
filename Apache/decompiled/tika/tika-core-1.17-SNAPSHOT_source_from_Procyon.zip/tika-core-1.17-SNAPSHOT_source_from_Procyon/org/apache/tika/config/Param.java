// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.config;

import java.util.Iterator;
import java.net.URL;
import java.net.URI;
import java.io.File;
import java.math.BigInteger;
import java.util.HashMap;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.io.IOException;
import org.xml.sax.SAXException;
import java.io.InputStream;
import org.apache.tika.exception.TikaException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.Transformer;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import org.w3c.dom.Node;
import org.apache.tika.utils.XMLReaderUtils;
import java.io.OutputStream;
import java.util.Map;
import java.io.Serializable;

public class Param<T> implements Serializable
{
    private static final Map<Class<?>, String> map;
    private static final Map<String, Class<?>> reverseMap;
    private Class<T> type;
    private String name;
    private String value;
    private T actualValue;
    
    public Param() {
    }
    
    public Param(final String name, final Class<T> type, final T value) {
        this.name = name;
        this.type = type;
        this.value = value.toString();
    }
    
    public Param(final String name, final T value) {
        this(name, (Class<Object>)value.getClass(), value);
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public Class<T> getType() {
        return this.type;
    }
    
    public void setType(final Class<T> type) {
        this.type = type;
    }
    
    public String getTypeString() {
        if (this.type == null) {
            return null;
        }
        if (Param.map.containsKey(this.type)) {
            return Param.map.get(this.type);
        }
        return this.type.getName();
    }
    
    public void setTypeString(final String type) {
        if (type == null || type.isEmpty()) {
            return;
        }
        this.type = classFromType(type);
        this.actualValue = null;
    }
    
    public T getValue() {
        if (this.actualValue == null) {
            this.actualValue = getTypedValue(this.type, this.value);
        }
        return this.actualValue;
    }
    
    @Override
    public String toString() {
        return "Param{name='" + this.name + '\'' + ", value='" + this.value + '\'' + ", actualValue=" + this.actualValue + '}';
    }
    
    public void save(final OutputStream stream) throws TransformerException, TikaException {
        final DocumentBuilder builder = XMLReaderUtils.getDocumentBuilder();
        final Document doc = builder.newDocument();
        final Element paramEl = doc.createElement("param");
        doc.appendChild(paramEl);
        this.save(paramEl);
        final Transformer transformer = XMLReaderUtils.getTransformer();
        transformer.transform(new DOMSource(paramEl), new StreamResult(stream));
    }
    
    public void save(final Node node) {
        if (!(node instanceof Element)) {
            throw new IllegalArgumentException("Not an Element : " + node);
        }
        final Element el = (Element)node;
        el.setAttribute("name", this.getName());
        el.setAttribute("type", this.getTypeString());
        el.setTextContent(this.value);
    }
    
    public static <T> Param<T> load(final InputStream stream) throws SAXException, IOException, TikaException {
        final DocumentBuilder db = XMLReaderUtils.getDocumentBuilder();
        final Document document = db.parse(stream);
        return load(document.getFirstChild());
    }
    
    public static <T> Param<T> load(final Node node) {
        final Node nameAttr = node.getAttributes().getNamedItem("name");
        final Node typeAttr = node.getAttributes().getNamedItem("type");
        final Node value = node.getFirstChild();
        final Param<T> ret = new Param<T>();
        ret.name = nameAttr.getTextContent();
        ret.setTypeString(typeAttr.getTextContent());
        ret.value = value.getTextContent();
        return ret;
    }
    
    private static <T> Class<T> classFromType(final String type) {
        if (Param.reverseMap.containsKey(type)) {
            return (Class<T>)Param.reverseMap.get(type);
        }
        try {
            return (Class<T>)Class.forName(type);
        }
        catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
    private static <T> T getTypedValue(final Class<T> type, final String value) {
        try {
            final Constructor<T> constructor = type.getConstructor(String.class);
            constructor.setAccessible(true);
            return constructor.newInstance(value);
        }
        catch (NoSuchMethodException e) {
            throw new RuntimeException(type + " doesnt have a constructor that takes String arg", e);
        }
        catch (IllegalAccessException | InstantiationException | InvocationTargetException ex2) {
            final ReflectiveOperationException ex;
            final ReflectiveOperationException e2 = ex;
            throw new RuntimeException(e2);
        }
    }
    
    static {
        map = new HashMap<Class<?>, String>();
        reverseMap = new HashMap<String, Class<?>>();
        Param.map.put(Boolean.class, "bool");
        Param.map.put(String.class, "string");
        Param.map.put(Byte.class, "byte");
        Param.map.put(Short.class, "short");
        Param.map.put(Integer.class, "int");
        Param.map.put(Long.class, "long");
        Param.map.put(BigInteger.class, "bigint");
        Param.map.put(Float.class, "float");
        Param.map.put(Double.class, "double");
        Param.map.put(File.class, "file");
        Param.map.put(URI.class, "uri");
        Param.map.put(URL.class, "url");
        for (final Map.Entry<Class<?>, String> entry : Param.map.entrySet()) {
            Param.reverseMap.put(entry.getValue(), entry.getKey());
        }
    }
}
