// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.language.detect;

public enum LanguageConfidence
{
    HIGH, 
    MEDIUM, 
    LOW, 
    NONE;
}
