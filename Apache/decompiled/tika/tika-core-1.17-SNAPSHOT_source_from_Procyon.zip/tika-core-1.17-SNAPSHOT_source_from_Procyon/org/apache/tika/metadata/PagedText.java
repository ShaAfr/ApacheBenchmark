// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.metadata;

public interface PagedText
{
    public static final Property N_PAGES = Property.internalInteger("xmpTPg:NPages");
}
