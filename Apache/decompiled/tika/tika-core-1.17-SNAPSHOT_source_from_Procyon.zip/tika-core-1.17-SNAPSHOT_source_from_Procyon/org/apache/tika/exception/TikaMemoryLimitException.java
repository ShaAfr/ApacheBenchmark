// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.exception;

public class TikaMemoryLimitException extends TikaException
{
    public TikaMemoryLimitException(final String msg) {
        super(msg);
    }
}
