// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.tika.exception;

public class ZeroByteFileException extends TikaException
{
    public ZeroByteFileException(final String msg) {
        super(msg);
    }
}
