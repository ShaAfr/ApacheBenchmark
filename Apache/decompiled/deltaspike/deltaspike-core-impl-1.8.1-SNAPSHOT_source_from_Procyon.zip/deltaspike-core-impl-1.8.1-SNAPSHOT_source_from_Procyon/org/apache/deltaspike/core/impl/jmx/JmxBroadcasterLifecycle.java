// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.jmx;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import org.apache.deltaspike.core.api.jmx.JmxBroadcaster;
import org.apache.deltaspike.core.util.metadata.builder.ContextualLifecycle;

public class JmxBroadcasterLifecycle implements ContextualLifecycle<JmxBroadcaster>
{
    private final DynamicMBeanWrapper delegate;
    
    public JmxBroadcasterLifecycle(final DynamicMBeanWrapper mbean) {
        this.delegate = mbean;
    }
    
    public JmxBroadcaster create(final Bean<JmxBroadcaster> bean, final CreationalContext<JmxBroadcaster> creationalContext) {
        return (JmxBroadcaster)this.delegate;
    }
    
    public void destroy(final Bean<JmxBroadcaster> bean, final JmxBroadcaster instance, final CreationalContext<JmxBroadcaster> creationalContext) {
    }
}
