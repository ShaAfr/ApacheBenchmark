// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.resourceloader;

import org.apache.deltaspike.core.api.resourceloader.FileResourceProvider;
import javax.enterprise.inject.spi.AnnotatedType;
import org.apache.deltaspike.core.api.resourceloader.ClasspathResourceProvider;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import javax.enterprise.inject.spi.Extension;

public class ResourceLoaderExtension implements Extension
{
    public void addResourceLoaders(final BeforeBeanDiscovery beforeBeanDiscovery, final BeanManager beanManager) {
        beforeBeanDiscovery.addAnnotatedType((AnnotatedType)this.createAnnotatedType(ClasspathResourceProvider.class, beanManager));
        beforeBeanDiscovery.addAnnotatedType((AnnotatedType)this.createAnnotatedType(InjectableResourceProducer.class, beanManager));
        beforeBeanDiscovery.addAnnotatedType((AnnotatedType)this.createAnnotatedType(FileResourceProvider.class, beanManager));
    }
    
    private AnnotatedType<?> createAnnotatedType(final Class<?> clazz, final BeanManager beanManager) {
        return (AnnotatedType<?>)beanManager.createAnnotatedType((Class)clazz);
    }
}
