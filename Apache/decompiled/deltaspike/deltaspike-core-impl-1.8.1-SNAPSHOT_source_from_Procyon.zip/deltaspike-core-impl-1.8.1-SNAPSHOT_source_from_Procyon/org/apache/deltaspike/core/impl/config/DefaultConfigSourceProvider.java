// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.util.Iterator;
import org.apache.deltaspike.core.util.ServiceUtils;
import org.apache.deltaspike.core.api.config.PropertyFileConfig;
import java.net.MalformedURLException;
import java.util.logging.Level;
import java.io.File;
import java.util.Collection;
import java.util.ArrayList;
import org.apache.deltaspike.core.spi.config.ConfigSource;
import java.util.List;
import java.util.logging.Logger;
import org.apache.deltaspike.core.spi.config.ConfigSourceProvider;

public class DefaultConfigSourceProvider implements ConfigSourceProvider
{
    private static final Logger LOG;
    private static final String PROPERTY_FILE_NAME = "apache-deltaspike.properties";
    private static final String PROPERTY_FILE_RESOURCE = "META-INF/apache-deltaspike.properties";
    private static final String PROPERTY_FILE_HOME_NAME = "/.deltaspike/apache-deltaspike.properties";
    private List<ConfigSource> configSources;
    
    public DefaultConfigSourceProvider() {
        (this.configSources = new ArrayList<ConfigSource>()).add((ConfigSource)new SystemPropertyConfigSource());
        this.configSources.add((ConfigSource)new EnvironmentPropertyConfigSource());
        this.configSources.add((ConfigSource)new LocalJndiConfigSource());
        this.addUserHomeConfigSource();
        final EnvironmentPropertyConfigSourceProvider epcsp = new EnvironmentPropertyConfigSourceProvider("META-INF/apache-deltaspike.properties", true);
        this.configSources.addAll(epcsp.getConfigSources());
        this.registerPropertyFileConfigs();
    }
    
    private void addUserHomeConfigSource() {
        final String userHome = System.getProperty("user.home");
        if (userHome != null && !userHome.isEmpty()) {
            final File dsHome = new File(userHome, "/.deltaspike/apache-deltaspike.properties");
            if (dsHome.exists()) {
                try {
                    final ConfigSource dsHomeConfigSource = (ConfigSource)new PropertyFileConfigSource(dsHome.toURI().toURL());
                    this.configSources.add(dsHomeConfigSource);
                    DefaultConfigSourceProvider.LOG.log(Level.INFO, "Reading configuration from {}", dsHome.getAbsolutePath());
                }
                catch (MalformedURLException e) {
                    DefaultConfigSourceProvider.LOG.log(Level.WARNING, "Could not read configuration from " + dsHome.getAbsolutePath(), e);
                }
            }
        }
    }
    
    private void registerPropertyFileConfigs() {
        final List<? extends PropertyFileConfig> propertyFileConfigs = (List<? extends PropertyFileConfig>)ServiceUtils.loadServiceImplementations((Class)PropertyFileConfig.class);
        for (final PropertyFileConfig propertyFileConfig : propertyFileConfigs) {
            final EnvironmentPropertyConfigSourceProvider environmentPropertyConfigSourceProvider = new EnvironmentPropertyConfigSourceProvider(propertyFileConfig.getPropertyFileName(), propertyFileConfig.isOptional());
            this.configSources.addAll(environmentPropertyConfigSourceProvider.getConfigSources());
        }
    }
    
    public List<ConfigSource> getConfigSources() {
        return this.configSources;
    }
    
    static {
        LOG = Logger.getLogger(DefaultConfigSourceProvider.class.getName());
    }
}
