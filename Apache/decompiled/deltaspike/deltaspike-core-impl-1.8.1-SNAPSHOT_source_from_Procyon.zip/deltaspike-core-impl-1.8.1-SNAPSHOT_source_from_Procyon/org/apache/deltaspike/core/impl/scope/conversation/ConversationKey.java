// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.conversation;

import java.util.Iterator;
import java.util.Collections;
import java.util.Set;
import org.apache.deltaspike.core.api.scope.ConversationGroup;
import javax.inject.Named;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Any;
import java.lang.annotation.Annotation;
import java.util.HashSet;
import java.io.Serializable;

public class ConversationKey implements Serializable
{
    private static final long serialVersionUID = 6565204223928766263L;
    private final Class<?> groupKey;
    private HashSet<Annotation> qualifiers;
    
    public ConversationKey(final Class<?> groupKey, final Annotation... qualifiers) {
        this.groupKey = groupKey;
        for (final Annotation qualifier : qualifiers) {
            final Class<? extends Annotation> annotationType = qualifier.annotationType();
            if (!Any.class.isAssignableFrom(annotationType) && !Default.class.isAssignableFrom(annotationType) && !Named.class.isAssignableFrom(annotationType)) {
                if (!ConversationGroup.class.isAssignableFrom(annotationType)) {
                    if (this.qualifiers == null) {
                        this.qualifiers = new HashSet<Annotation>();
                    }
                    this.qualifiers.add(qualifier);
                }
            }
        }
    }
    
    public Class<?> getConversationGroup() {
        return this.groupKey;
    }
    
    public Set<Annotation> getQualifiers() {
        if (this.qualifiers == null) {
            return Collections.emptySet();
        }
        return Collections.unmodifiableSet((Set<? extends Annotation>)this.qualifiers);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ConversationKey)) {
            return false;
        }
        final ConversationKey that = (ConversationKey)o;
        return this.groupKey.equals(that.groupKey) && ((this.qualifiers == null && that.qualifiers == null) || ((this.qualifiers == null || that.qualifiers != null) && that.qualifiers.equals(this.qualifiers)));
    }
    
    @Override
    public int hashCode() {
        int result = this.groupKey.hashCode();
        result = 31 * result + ((this.qualifiers != null) ? this.qualifiers.hashCode() : 0);
        return result;
    }
    
    @Override
    public String toString() {
        final StringBuilder result = new StringBuilder("conversation-key\n");
        result.append("\n");
        result.append("\tgroup:\t\t");
        result.append(this.groupKey.getName());
        result.append("\n");
        result.append("\tqualifiers:\t");
        if (this.qualifiers != null) {
            for (final Annotation qualifier : this.qualifiers) {
                result.append(qualifier.annotationType().getName());
                result.append(" ");
            }
        }
        else {
            result.append("---");
        }
        return result.toString();
    }
}
