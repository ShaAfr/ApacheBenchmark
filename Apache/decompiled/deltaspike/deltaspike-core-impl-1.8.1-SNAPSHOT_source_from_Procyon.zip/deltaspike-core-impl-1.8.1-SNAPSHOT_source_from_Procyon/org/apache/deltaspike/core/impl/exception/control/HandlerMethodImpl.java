// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control;

import org.apache.deltaspike.core.util.metadata.builder.ImmutableInjectionPoint;
import org.apache.deltaspike.core.util.metadata.builder.InjectableMethod;
import org.apache.deltaspike.core.util.metadata.builder.ParameterValueRedefiner;
import javax.enterprise.context.spi.CreationalContext;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import javax.enterprise.context.spi.Contextual;
import org.apache.deltaspike.core.api.exception.control.event.ExceptionEvent;
import java.util.Collections;
import java.util.Iterator;
import java.lang.reflect.ParameterizedType;
import org.apache.deltaspike.core.api.literal.AnyLiteral;
import java.util.Collection;
import org.apache.deltaspike.core.util.BeanUtils;
import org.apache.deltaspike.core.api.exception.control.BeforeHandles;
import org.apache.deltaspike.core.api.exception.control.Handles;
import java.util.HashSet;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.enterprise.inject.spi.AnnotatedParameter;
import java.lang.reflect.Method;
import javax.enterprise.inject.spi.AnnotatedMethod;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import java.util.Set;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.api.exception.control.HandlerMethod;

@Typed
public class HandlerMethodImpl<T extends Throwable> implements HandlerMethod<T>
{
    private final Class declaringBeanClass;
    private final Bean<?> declaringBean;
    private final Set<Annotation> qualifiers;
    private final Type exceptionType;
    private final AnnotatedMethod<?> handler;
    private final boolean before;
    private final int ordinal;
    private final Method javaMethod;
    private final AnnotatedParameter<?> handlerParameter;
    private Set<InjectionPoint> injectionPoints;
    
    public HandlerMethodImpl(final Bean<?> handlerDeclaringBean, final AnnotatedMethod<?> method, final BeanManager bm) {
        final Set<Annotation> tmpQualifiers = new HashSet<Annotation>();
        this.declaringBean = handlerDeclaringBean;
        this.handler = method;
        this.javaMethod = method.getJavaMember();
        this.handlerParameter = findHandlerParameter(method);
        if (!this.handlerParameter.isAnnotationPresent((Class)Handles.class) && !this.handlerParameter.isAnnotationPresent((Class)BeforeHandles.class)) {
            throw new IllegalArgumentException("Method is not annotated with @Handles or @BeforeHandles");
        }
        this.before = (this.handlerParameter.getAnnotation((Class)BeforeHandles.class) != null);
        if (this.before) {
            this.ordinal = ((BeforeHandles)this.handlerParameter.getAnnotation((Class)BeforeHandles.class)).ordinal();
        }
        else {
            this.ordinal = ((Handles)this.handlerParameter.getAnnotation((Class)Handles.class)).ordinal();
        }
        tmpQualifiers.addAll(BeanUtils.getQualifiers(bm, (Iterable)this.handlerParameter.getAnnotations()));
        if (tmpQualifiers.isEmpty()) {
            tmpQualifiers.add((Annotation)new AnyLiteral());
        }
        this.qualifiers = tmpQualifiers;
        this.declaringBeanClass = method.getJavaMember().getDeclaringClass();
        this.exceptionType = ((ParameterizedType)this.handlerParameter.getBaseType()).getActualTypeArguments()[0];
    }
    
    public static boolean isHandler(final AnnotatedMethod<?> method) {
        if (method == null) {
            throw new IllegalArgumentException("Method must not be null");
        }
        for (final AnnotatedParameter<?> param : method.getParameters()) {
            if (param.isAnnotationPresent((Class)Handles.class) || param.isAnnotationPresent((Class)BeforeHandles.class)) {
                return true;
            }
        }
        return false;
    }
    
    public static AnnotatedParameter<?> findHandlerParameter(final AnnotatedMethod<?> method) {
        if (!isHandler(method)) {
            throw new IllegalArgumentException("Method is not a valid handler");
        }
        AnnotatedParameter<?> returnParam = null;
        for (final AnnotatedParameter<?> param : method.getParameters()) {
            if (param.isAnnotationPresent((Class)Handles.class) || param.isAnnotationPresent((Class)BeforeHandles.class)) {
                returnParam = param;
                break;
            }
        }
        return returnParam;
    }
    
    public Bean<?> getDeclaringBean() {
        return this.declaringBean;
    }
    
    public Set<Annotation> getQualifiers() {
        return Collections.unmodifiableSet((Set<? extends Annotation>)this.qualifiers);
    }
    
    public Type getExceptionType() {
        return this.exceptionType;
    }
    
    public void notify(final ExceptionEvent<T> event, final BeanManager beanManager) throws Exception {
        CreationalContext<?> ctx = null;
        try {
            ctx = (CreationalContext<?>)beanManager.createCreationalContext((Contextual)null);
            final Object handlerInstance = BeanProvider.getContextualReference(this.declaringBeanClass, new Annotation[0]);
            final InjectableMethod<?> im = this.createInjectableMethod(this.handler, this.getDeclaringBean(), beanManager);
            im.invoke(handlerInstance, (CreationalContext)ctx, (ParameterValueRedefiner)new OutboundParameterValueRedefiner(event, this));
        }
        finally {
            if (ctx != null) {
                ctx.release();
            }
        }
    }
    
    private <X> InjectableMethod<X> createInjectableMethod(final AnnotatedMethod<X> handlerMethod, final Bean<?> bean, final BeanManager bm) {
        return (InjectableMethod<X>)new InjectableMethod((AnnotatedMethod)handlerMethod, (Bean)bean, bm);
    }
    
    public boolean isBeforeHandler() {
        return this.before;
    }
    
    public int getOrdinal() {
        return this.ordinal;
    }
    
    public AnnotatedParameter<?> getHandlerParameter() {
        return this.handlerParameter;
    }
    
    public Method getJavaMethod() {
        return this.handler.getJavaMember();
    }
    
    public Set<InjectionPoint> getInjectionPoints(final BeanManager bm) {
        if (this.injectionPoints == null) {
            this.injectionPoints = new HashSet<InjectionPoint>(this.handler.getParameters().size() - 1);
            for (final AnnotatedParameter<?> param : this.handler.getParameters()) {
                if (!param.equals(this.handlerParameter)) {
                    this.injectionPoints.add((InjectionPoint)new ImmutableInjectionPoint((AnnotatedParameter)param, bm, (Bean)this.getDeclaringBean(), false, false));
                }
            }
        }
        return new HashSet<InjectionPoint>(this.injectionPoints);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || !HandlerMethod.class.isAssignableFrom(o.getClass())) {
            return false;
        }
        final HandlerMethod<?> that = (HandlerMethod<?>)o;
        return this.qualifiers.equals(that.getQualifiers()) && this.isBeforeHandler() == that.isBeforeHandler() && this.exceptionType.equals(that.getExceptionType()) && this.ordinal == that.getOrdinal();
    }
    
    @Override
    public int hashCode() {
        int result = this.declaringBeanClass.hashCode();
        result = 5 * result + this.qualifiers.hashCode();
        result = 5 * result + this.exceptionType.hashCode();
        result = 5 * result + this.ordinal;
        result = 5 * result + this.javaMethod.hashCode();
        result = 5 * result + this.handlerParameter.hashCode();
        return result;
    }
    
    @Override
    public String toString() {
        return "{Qualifiers: " + this.qualifiers + ", Handles Type: " + this.exceptionType + ", Before: " + this.before + ", Precedence: " + this.ordinal + ", Method: " + this.handler.getJavaMember().getName() + "}";
    }
}
