// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.context.spi.Contextual;
import org.apache.deltaspike.core.api.provider.BeanManagerProvider;
import javax.enterprise.inject.spi.Bean;
import org.apache.deltaspike.core.api.exception.control.event.ExceptionEvent;
import org.apache.deltaspike.core.util.metadata.builder.ParameterValueRedefiner;

class OutboundParameterValueRedefiner implements ParameterValueRedefiner
{
    private final ExceptionEvent<?> event;
    private final Bean<?> declaringBean;
    private final HandlerMethodImpl<?> handlerMethod;
    
    OutboundParameterValueRedefiner(final ExceptionEvent<?> event, final HandlerMethodImpl<?> handlerMethod) {
        this.event = event;
        this.declaringBean = handlerMethod.getDeclaringBean();
        this.handlerMethod = handlerMethod;
    }
    
    public Object redefineParameterValue(final ParameterValueRedefiner.ParameterValue value) {
        final CreationalContext<?> ctx = (CreationalContext<?>)BeanManagerProvider.getInstance().getBeanManager().createCreationalContext((Contextual)this.declaringBean);
        try {
            if (value.getPosition() == this.handlerMethod.getHandlerParameter().getPosition()) {
                return this.event;
            }
            return value.getDefaultValue((CreationalContext)ctx);
        }
        finally {
            if (ctx != null) {
                ctx.release();
            }
        }
    }
}
