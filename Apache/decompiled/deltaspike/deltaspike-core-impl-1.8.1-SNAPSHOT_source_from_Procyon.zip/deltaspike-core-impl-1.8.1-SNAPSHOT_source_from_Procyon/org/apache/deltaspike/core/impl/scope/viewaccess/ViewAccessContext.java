// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.viewaccess;

import java.util.Iterator;
import org.apache.deltaspike.core.util.context.ContextualInstanceInfo;
import java.util.Map;
import org.apache.deltaspike.core.api.scope.ViewAccessScoped;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.util.context.ContextualStorage;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.PassivationCapable;
import javax.enterprise.context.spi.Contextual;
import org.apache.deltaspike.core.impl.scope.window.WindowContextImpl;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.spi.scope.viewaccess.ViewAccessContextManager;
import org.apache.deltaspike.core.util.context.AbstractContext;

@Typed
public class ViewAccessContext extends AbstractContext implements ViewAccessContextManager
{
    private static final String KEY = "VAS";
    private final BeanManager beanManager;
    private final WindowContextImpl windowContext;
    private ViewAccessBeanHolder viewAccessBeanHolder;
    private ViewAccessBeanAccessHistory viewAccessBeanAccessHistory;
    private ViewAccessViewHistory viewAccessViewHistory;
    
    public ViewAccessContext(final BeanManager beanManager, final WindowContextImpl windowContext) {
        super(beanManager);
        this.beanManager = beanManager;
        this.windowContext = windowContext;
    }
    
    public void init(final ViewAccessBeanHolder viewAccessBeanHolder, final ViewAccessBeanAccessHistory viewAccessBeanAccessHistory, final ViewAccessViewHistory viewAccessViewHistory) {
        this.viewAccessBeanHolder = viewAccessBeanHolder;
        this.viewAccessBeanAccessHistory = viewAccessBeanAccessHistory;
        this.viewAccessViewHistory = viewAccessViewHistory;
    }
    
    public <T> T get(final Contextual<T> bean) {
        try {
            return (T)super.get((Contextual)bean);
        }
        finally {
            if (bean instanceof PassivationCapable) {
                final PassivationCapable pc = (PassivationCapable)bean;
                this.viewAccessBeanAccessHistory.getAccessedBeans().add(pc.getId());
            }
        }
    }
    
    public <T> T get(final Contextual<T> bean, final CreationalContext<T> creationalContext) {
        try {
            return (T)super.get((Contextual)bean, (CreationalContext)creationalContext);
        }
        finally {
            if (bean instanceof PassivationCapable) {
                final PassivationCapable pc = (PassivationCapable)bean;
                this.viewAccessBeanAccessHistory.getAccessedBeans().add(pc.getId());
            }
        }
    }
    
    protected ContextualStorage getContextualStorage(final Contextual<?> contextual, final boolean createIfNotExist) {
        return this.viewAccessBeanHolder.getContextualStorage(this.beanManager, "VAS", createIfNotExist);
    }
    
    public Class<? extends Annotation> getScope() {
        return (Class<? extends Annotation>)ViewAccessScoped.class;
    }
    
    public boolean isActive() {
        return this.windowContext.isActive();
    }
    
    public void onProcessingViewFinished(final String view) {
        this.close(view, false);
    }
    
    public void close(final String view, final boolean force) {
        if (!this.windowContext.isActive()) {
            return;
        }
        if (force || !view.equals(this.viewAccessViewHistory.getLastView())) {
            this.viewAccessViewHistory.setLastView(view);
            this.destroyExpiredBeans(force);
        }
        this.viewAccessBeanAccessHistory.getAccessedBeans().clear();
    }
    
    private void destroyExpiredBeans(final boolean force) {
        final ContextualStorage storage = this.viewAccessBeanHolder.getContextualStorage(this.beanManager, "VAS", false);
        if (storage != null) {
            for (final Map.Entry<Object, ContextualInstanceInfo<?>> storageEntry : storage.getStorage().entrySet()) {
                if (force || !this.viewAccessBeanAccessHistory.getAccessedBeans().contains(storageEntry.getKey())) {
                    final Contextual bean = storage.getBean(storageEntry.getKey());
                    AbstractContext.destroyBean(bean, (ContextualInstanceInfo)storageEntry.getValue());
                    storage.getStorage().remove(storageEntry.getKey());
                }
            }
        }
    }
    
    public void close() {
        this.close(null, true);
    }
}
