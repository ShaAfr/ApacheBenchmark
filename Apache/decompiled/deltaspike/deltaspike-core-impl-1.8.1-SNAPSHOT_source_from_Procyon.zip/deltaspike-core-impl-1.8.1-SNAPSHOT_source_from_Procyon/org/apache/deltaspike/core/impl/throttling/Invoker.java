// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.throttling;

import org.apache.deltaspike.core.util.ExceptionUtils;
import java.util.concurrent.TimeUnit;
import javax.interceptor.InvocationContext;
import java.util.concurrent.Semaphore;

class Invoker
{
    private final int weight;
    private final Semaphore semaphore;
    private final long timeout;
    
    Invoker(final Semaphore semaphore, final int weight, final long timeout) {
        this.semaphore = semaphore;
        this.weight = weight;
        this.timeout = timeout;
    }
    
    public Object invoke(final InvocationContext context) throws Exception {
        Label_0120: {
            if (this.timeout > 0L) {
                try {
                    if (!this.semaphore.tryAcquire(this.weight, this.timeout, TimeUnit.MILLISECONDS)) {
                        throw new IllegalStateException("Can't acquire " + this.weight + " permits for " + context.getMethod() + " in " + this.timeout + "ms");
                    }
                    break Label_0120;
                }
                catch (InterruptedException e) {
                    return onInterruption(e);
                }
            }
            try {
                this.semaphore.acquire(this.weight);
            }
            catch (InterruptedException e) {
                return onInterruption(e);
            }
            try {
                return context.proceed();
            }
            finally {
                this.semaphore.release(this.weight);
            }
        }
    }
    
    private static Semaphore onInterruption(final InterruptedException e) {
        Thread.interrupted();
        throw ExceptionUtils.throwAsRuntimeException((Throwable)e);
    }
}
