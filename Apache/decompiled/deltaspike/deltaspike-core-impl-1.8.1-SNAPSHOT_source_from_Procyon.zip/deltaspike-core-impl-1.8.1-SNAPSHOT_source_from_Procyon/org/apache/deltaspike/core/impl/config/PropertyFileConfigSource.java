// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import org.apache.deltaspike.core.util.PropertyFileUtils;
import java.net.URL;

class PropertyFileConfigSource extends PropertiesConfigSource
{
    private String fileName;
    
    PropertyFileConfigSource(final URL propertyFileUrl) {
        super(PropertyFileUtils.loadProperties(propertyFileUrl));
        this.fileName = propertyFileUrl.toExternalForm();
        this.initOrdinal(100);
    }
    
    public String getConfigName() {
        return this.fileName;
    }
}
