// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.util;

import java.util.Map;
import org.apache.deltaspike.core.util.metadata.AnnotationInstanceProvider;
import java.util.HashMap;
import org.apache.deltaspike.core.util.ClassUtils;
import java.lang.annotation.Annotation;
import javax.enterprise.inject.Typed;

@Typed
public abstract class AnnotationInstanceUtils
{
    private AnnotationInstanceUtils() {
    }
    
    public static Annotation getPriorityAnnotationInstance(final int priorityValue) {
        Annotation priorityAnnotationInstance = null;
        final Class<? extends Annotation> priorityAnnotationClass = (Class<? extends Annotation>)ClassUtils.tryToLoadClassForName("javax.annotation.Priority");
        if (priorityAnnotationClass != null && ClassUtils.tryToLoadClassForName("javax.enterprise.inject.spi.AfterTypeDiscovery") != null) {
            final Map<String, Object> defaultValueMap = new HashMap<String, Object>();
            defaultValueMap.put("value", priorityValue);
            priorityAnnotationInstance = AnnotationInstanceProvider.of((Class)priorityAnnotationClass, (Map)defaultValueMap);
        }
        return priorityAnnotationInstance;
    }
}
