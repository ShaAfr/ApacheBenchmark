// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.conversation;

import org.apache.deltaspike.core.util.context.ContextualInstanceInfo;
import java.util.Iterator;
import java.util.Map;
import java.util.Collections;
import org.apache.deltaspike.core.api.scope.ConversationSubGroup;
import java.util.HashSet;
import java.util.Set;
import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;
import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import org.apache.deltaspike.core.impl.util.ConversationUtils;
import org.apache.deltaspike.core.util.context.ContextualStorage;
import javax.enterprise.context.spi.Contextual;
import org.apache.deltaspike.core.impl.scope.window.WindowContextImpl;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.spi.scope.conversation.GroupedConversationManager;
import org.apache.deltaspike.core.util.context.AbstractContext;

@Typed
public class GroupedConversationContext extends AbstractContext implements GroupedConversationManager
{
    private static final long serialVersionUID = -5463564406828391468L;
    private final BeanManager beanManager;
    private final WindowContextImpl windowContext;
    private ConversationBeanHolder conversationBeanHolder;
    
    public GroupedConversationContext(final BeanManager beanManager, final WindowContextImpl windowContext) {
        super(beanManager);
        this.beanManager = beanManager;
        this.windowContext = windowContext;
    }
    
    public void init(final ConversationBeanHolder conversationBeanHolder) {
        this.conversationBeanHolder = conversationBeanHolder;
    }
    
    protected ContextualStorage getContextualStorage(final Contextual<?> contextual, final boolean createIfNotExist) {
        final ConversationKey conversationKey = ConversationUtils.convertToConversationKey(contextual, this.beanManager);
        return this.conversationBeanHolder.getContextualStorage(this.beanManager, conversationKey, createIfNotExist);
    }
    
    protected List<ContextualStorage> getActiveContextualStorages() {
        final List<ContextualStorage> result = new ArrayList<ContextualStorage>();
        result.addAll(this.conversationBeanHolder.getStorageMap().values());
        return result;
    }
    
    public Class<? extends Annotation> getScope() {
        return (Class<? extends Annotation>)GroupedConversationScoped.class;
    }
    
    public boolean isActive() {
        return this.windowContext.isActive();
    }
    
    public ContextualStorage closeConversation(final Class<?> conversationGroup, final Annotation... qualifiers) {
        final ConversationKey conversationKey = new ConversationKey(conversationGroup, qualifiers);
        final ContextualStorage contextualStorage = this.conversationBeanHolder.getStorageMap().remove(conversationKey);
        if (contextualStorage != null) {
            AbstractContext.destroyAllActive(contextualStorage);
        }
        return contextualStorage;
    }
    
    public Set<ContextualStorage> closeConversationGroup(Class<?> conversationGroup) {
        final Set<ContextualStorage> result = new HashSet<ContextualStorage>();
        final ConversationSubGroup conversationSubGroup = conversationGroup.getAnnotation(ConversationSubGroup.class);
        Set<Class<?>> subGroups = null;
        if (conversationSubGroup != null) {
            conversationGroup = ConversationUtils.getDeclaredConversationGroup(conversationGroup);
            subGroups = new HashSet<Class<?>>(conversationSubGroup.subGroup().length);
            Collections.addAll((Collection<? super Class>)subGroups, (Class[])conversationSubGroup.subGroup());
        }
        final Map<ConversationKey, ContextualStorage> storageMap = this.conversationBeanHolder.getStorageMap();
        for (final Map.Entry<ConversationKey, ContextualStorage> entry : storageMap.entrySet()) {
            if (entry.getKey().getConversationGroup().equals(conversationGroup)) {
                if (subGroups == null) {
                    AbstractContext.destroyAllActive((ContextualStorage)entry.getValue());
                    result.add(entry.getValue());
                    storageMap.remove(entry.getKey());
                }
                else {
                    this.tryToDestroySubGroup(subGroups, entry);
                    if (!entry.getValue().getStorage().isEmpty()) {
                        continue;
                    }
                    storageMap.remove(entry.getKey());
                }
            }
        }
        return result;
    }
    
    private void tryToDestroySubGroup(final Set<Class<?>> subGroups, final Map.Entry<ConversationKey, ContextualStorage> entry) {
        final ContextualStorage storage = entry.getValue();
        for (final Map.Entry<Object, ContextualInstanceInfo<?>> storageEntry : storage.getStorage().entrySet()) {
            for (final Class<?> subGroup : subGroups) {
                final Class classOfEntry = storageEntry.getValue().getContextualInstance().getClass();
                if (subGroup.equals(classOfEntry) || (subGroup.isInterface() && subGroup.isAssignableFrom(classOfEntry))) {
                    final Contextual bean = storage.getBean(storageEntry.getKey());
                    AbstractContext.destroyBean(bean, (ContextualInstanceInfo)storageEntry.getValue());
                    storage.getStorage().remove(storageEntry.getKey());
                    break;
                }
            }
        }
    }
    
    public void closeConversations() {
        this.conversationBeanHolder.destroyBeans();
    }
}
