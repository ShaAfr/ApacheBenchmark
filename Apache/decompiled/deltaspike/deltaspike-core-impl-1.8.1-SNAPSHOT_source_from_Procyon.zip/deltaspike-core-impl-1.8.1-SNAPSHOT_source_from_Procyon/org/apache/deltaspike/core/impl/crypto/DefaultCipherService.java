// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.crypto;

import java.io.InputStream;
import java.net.URL;
import java.util.Arrays;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import javax.crypto.Cipher;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.net.MalformedURLException;
import java.io.File;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.Properties;
import java.io.IOException;
import java.nio.charset.Charset;

public class DefaultCipherService
{
    private static final Charset UTF_8;
    private static final String HASH_ALGORITHM = "SHA-256";
    private static final String CIPHER_ALGORITHM = "AES";
    
    public String setMasterHash(final String masterPassword, final String masterSalt, final boolean overwrite) throws IOException {
        final File masterFile = this.getMasterFile();
        if (!masterFile.getParentFile().exists() && !masterFile.getParentFile().mkdirs()) {
            throw new IOException("Can not create directory " + masterFile.getParent());
        }
        final String saltHash = this.byteToHex(this.secureHash(masterSalt));
        final String saltKey = this.byteToHex(this.secureHash(saltHash));
        final String encrypted = this.byteToHex(this.aesEncrypt(this.byteToHex(this.secureHash(masterPassword)), saltHash));
        Properties keys = new Properties();
        if (masterFile.exists()) {
            keys = this.loadProperties(masterFile.toURI().toURL());
        }
        if (keys.get(saltKey) != null && !overwrite) {
            throw new IllegalStateException("MasterKey for hash " + saltKey + " already exists. Forced overwrite option needed");
        }
        keys.put(saltKey, encrypted);
        keys.store(new FileOutputStream(masterFile), null);
        return saltKey;
    }
    
    protected String getMasterKey(final String masterSalt) {
        final File masterFile = this.getMasterFile();
        if (!masterFile.exists()) {
            throw new IllegalStateException("Could not find master.hash file. Create a master password first!");
        }
        try {
            final String saltHash = this.byteToHex(this.secureHash(masterSalt));
            final String saltKey = this.byteToHex(this.secureHash(saltHash));
            final Properties keys = this.loadProperties(masterFile.toURI().toURL());
            final String encryptedMasterKey = (String)keys.get(saltKey);
            if (encryptedMasterKey == null) {
                throw new IllegalStateException("Could not find master key for hash " + saltKey + ". Create a master password first!");
            }
            return this.aesDecrypt(this.hexToByte(encryptedMasterKey), saltHash);
        }
        catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String encrypt(final String cleartext, final String masterSalt) {
        return this.byteToHex(this.aesEncrypt(cleartext, this.getMasterKey(masterSalt)));
    }
    
    public String decrypt(final String encryptedValue, final String masterSalt) {
        return this.aesDecrypt(this.hexToByte(encryptedValue), this.getMasterKey(masterSalt));
    }
    
    protected File getMasterFile() {
        final String userHome = System.getProperty("user.home");
        if (userHome == null || userHome.isEmpty()) {
            throw new IllegalStateException("Can not determine user home directory");
        }
        return new File(userHome, ".deltaspike/master.hash");
    }
    
    protected byte[] secureHash(final String value) {
        try {
            final MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(value.getBytes(DefaultCipherService.UTF_8));
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    
    public byte[] aesEncrypt(final String valueToEncrypt, final String key) {
        try {
            final SecretKeySpec secretKeySpec = this.getSecretKeySpec(key);
            final Cipher cipher = Cipher.getInstance("AES");
            cipher.init(1, secretKeySpec);
            return cipher.doFinal(valueToEncrypt.getBytes(DefaultCipherService.UTF_8));
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public String aesDecrypt(final byte[] encryptedValue, final String key) {
        try {
            final SecretKeySpec secretKeySpec = this.getSecretKeySpec(key);
            final Cipher cipher = Cipher.getInstance("AES");
            cipher.init(2, secretKeySpec);
            return new String(cipher.doFinal(encryptedValue), DefaultCipherService.UTF_8);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    private SecretKeySpec getSecretKeySpec(final String password) {
        final byte[] pwdHash = this.secureHash(password);
        final byte[] key = Arrays.copyOf(pwdHash, 16);
        return new SecretKeySpec(key, "AES");
    }
    
    protected String byteToHex(final byte[] hash) {
        final StringBuilder sb = new StringBuilder(hash.length * 2);
        for (final byte b : hash) {
            sb.append(Character.forDigit(b >> 4 & 0xF, 16));
            sb.append(Character.forDigit(b & 0xF, 16));
        }
        return sb.toString();
    }
    
    protected byte[] hexToByte(String hexString) {
        if (hexString == null || hexString.length() == 0) {
            return new byte[0];
        }
        hexString = hexString.trim();
        if (hexString.length() % 2 != 0) {
            throw new IllegalArgumentException("not a valid hex string " + hexString);
        }
        final byte[] bytes = new byte[hexString.length() / 2];
        for (int i = 0; i < hexString.length() / 2; ++i) {
            final int val = (Character.digit(hexString.charAt(i * 2), 16) << 4) + Character.digit(hexString.charAt(i * 2 + 1), 16);
            bytes[i] = (byte)val;
        }
        return bytes;
    }
    
    private Properties loadProperties(final URL url) {
        final Properties props = new Properties();
        InputStream inputStream = null;
        try {
            inputStream = url.openStream();
            if (inputStream != null) {
                props.load(inputStream);
            }
        }
        catch (IOException e) {
            throw new IllegalStateException(e);
        }
        finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            catch (IOException ex) {}
        }
        return props;
    }
    
    static {
        UTF_8 = Charset.forName("UTF-8");
    }
}
