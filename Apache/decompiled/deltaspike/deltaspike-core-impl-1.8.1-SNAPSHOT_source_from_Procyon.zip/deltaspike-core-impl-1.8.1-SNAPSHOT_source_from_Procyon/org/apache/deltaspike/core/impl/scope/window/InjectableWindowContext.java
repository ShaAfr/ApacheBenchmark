// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.window;

import org.apache.deltaspike.core.api.provider.BeanProvider;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.impl.scope.DeltaSpikeContextExtension;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.spi.scope.window.WindowContext;

@Typed
public class InjectableWindowContext implements WindowContext
{
    private static final long serialVersionUID = -3606786361833889628L;
    private transient volatile WindowContext windowContext;
    
    InjectableWindowContext(final WindowContext windowContext) {
        this.windowContext = windowContext;
    }
    
    private WindowContext getWindowContext() {
        if (this.windowContext == null) {
            this.windowContext = (WindowContext)((DeltaSpikeContextExtension)BeanProvider.getContextualReference((Class)DeltaSpikeContextExtension.class, new Annotation[0])).getWindowContext();
        }
        return this.windowContext;
    }
    
    public String getCurrentWindowId() {
        return this.getWindowContext().getCurrentWindowId();
    }
    
    public void activateWindow(final String windowId) {
        this.getWindowContext().activateWindow(windowId);
    }
    
    public boolean closeWindow(final String windowId) {
        return this.getWindowContext().closeWindow(windowId);
    }
}
