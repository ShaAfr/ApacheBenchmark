// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import java.util.Locale;
import javax.enterprise.context.ApplicationScoped;
import java.io.Serializable;
import org.apache.deltaspike.core.api.message.MessageInterpolator;

@ApplicationScoped
public class DefaultMessageInterpolator implements MessageInterpolator, Serializable
{
    private static final long serialVersionUID = -8854087197813424812L;
    
    public String interpolate(final String messageTemplate, final Serializable[] arguments, final Locale locale) {
        if (arguments == null || arguments.length == 0) {
            return messageTemplate;
        }
        return String.format(locale, messageTemplate, (Object[])arguments);
    }
}
