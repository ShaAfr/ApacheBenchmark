// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control.extension;

import java.util.HashSet;
import java.util.Arrays;
import java.util.Collections;
import javax.enterprise.inject.InjectionException;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.enterprise.inject.spi.AfterDeploymentValidation;
import java.util.Iterator;
import java.util.Set;
import javax.enterprise.inject.spi.Bean;
import org.apache.deltaspike.core.impl.exception.control.HandlerMethodImpl;
import javax.enterprise.inject.spi.AnnotatedMethod;
import org.apache.deltaspike.core.api.exception.control.ExceptionHandler;
import javax.enterprise.inject.spi.AnnotatedType;
import javax.enterprise.inject.spi.Decorator;
import javax.enterprise.inject.spi.Interceptor;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.ProcessBean;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import java.util.HashMap;
import org.apache.deltaspike.core.api.exception.control.HandlerMethod;
import java.util.Collection;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.logging.Logger;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import javax.enterprise.inject.spi.Extension;

public class ExceptionControlExtension implements Extension, Deactivatable
{
    private static final Logger LOG;
    private Map<Type, Collection<HandlerMethod<? extends Throwable>>> allHandlers;
    private Boolean isActivated;
    
    public ExceptionControlExtension() {
        this.allHandlers = new HashMap<Type, Collection<HandlerMethod<? extends Throwable>>>();
        this.isActivated = true;
    }
    
    protected void init(@Observes final BeforeBeanDiscovery beforeBeanDiscovery) {
        this.isActivated = ClassDeactivationUtils.isActivated((Class)this.getClass());
    }
    
    public <T> void findHandlers(@Observes final ProcessBean<?> processBean, final BeanManager beanManager) {
        if (!this.isActivated) {
            return;
        }
        if (processBean.getBean() instanceof Interceptor || processBean.getBean() instanceof Decorator || !(processBean.getAnnotated() instanceof AnnotatedType)) {
            return;
        }
        final AnnotatedType annotatedType = (AnnotatedType)processBean.getAnnotated();
        if (annotatedType.getJavaClass().isAnnotationPresent(ExceptionHandler.class)) {
            final Set<AnnotatedMethod<? super T>> methods = (Set<AnnotatedMethod<? super T>>)annotatedType.getMethods();
            for (final AnnotatedMethod<? super T> method : methods) {
                if (HandlerMethodImpl.isHandler(method)) {
                    if (method.getJavaMember().getExceptionTypes().length != 0) {
                        processBean.addDefinitionError((Throwable)new IllegalArgumentException(String.format("Handler method %s must not throw exceptions", method.getJavaMember())));
                    }
                    this.registerHandlerMethod((org.apache.deltaspike.core.api.exception.control.HandlerMethod<Throwable>)new HandlerMethodImpl((Bean<?>)processBean.getBean(), method, beanManager));
                }
            }
        }
    }
    
    public void verifyInjectionPoints(@Observes final AfterDeploymentValidation afterDeploymentValidation, final BeanManager bm) {
        if (!this.isActivated) {
            return;
        }
        for (final Map.Entry<Type, Collection<HandlerMethod<? extends Throwable>>> entry : this.allHandlers.entrySet()) {
            for (final HandlerMethod<? extends Throwable> handler : entry.getValue()) {
                for (final InjectionPoint ip : ((HandlerMethodImpl)handler).getInjectionPoints(bm)) {
                    try {
                        bm.validate(ip);
                    }
                    catch (InjectionException e) {
                        afterDeploymentValidation.addDeploymentProblem((Throwable)e);
                    }
                }
            }
        }
    }
    
    public Map<Type, Collection<HandlerMethod<? extends Throwable>>> getAllExceptionHandlers() {
        return Collections.unmodifiableMap((Map<? extends Type, ? extends Collection<HandlerMethod<? extends Throwable>>>)this.allHandlers);
    }
    
    private <T extends Throwable> void registerHandlerMethod(final HandlerMethod<T> handlerMethod) {
        ExceptionControlExtension.LOG.fine(String.format("Adding handler %s to known handlers", handlerMethod));
        if (this.allHandlers.containsKey(handlerMethod.getExceptionType())) {
            this.allHandlers.get(handlerMethod.getExceptionType()).add(handlerMethod);
        }
        else {
            this.allHandlers.put(handlerMethod.getExceptionType(), new HashSet<HandlerMethod<? extends Throwable>>((Collection<? extends HandlerMethod<? extends Throwable>>)Arrays.asList(handlerMethod)));
        }
    }
    
    static {
        LOG = Logger.getLogger(ExceptionControlExtension.class.getName());
    }
}
