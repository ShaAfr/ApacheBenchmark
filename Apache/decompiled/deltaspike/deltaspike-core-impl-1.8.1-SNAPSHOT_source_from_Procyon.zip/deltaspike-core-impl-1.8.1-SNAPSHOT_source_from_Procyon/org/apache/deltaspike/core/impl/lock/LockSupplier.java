// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.lock;

import java.util.concurrent.locks.Lock;

interface LockSupplier
{
    Lock get();
}
