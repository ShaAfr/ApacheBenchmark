// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.crypto;

import java.io.IOException;
import javax.enterprise.context.ApplicationScoped;
import org.apache.deltaspike.core.api.crypto.CipherService;

@ApplicationScoped
public class CdiCipherService implements CipherService
{
    private DefaultCipherService cipherService;
    
    public CdiCipherService() {
        this.cipherService = new DefaultCipherService();
    }
    
    public void setMasterHash(final String masterPassword, final String masterSalt, final boolean overwrite) throws IOException {
        this.cipherService.setMasterHash(masterPassword, masterSalt, overwrite);
    }
    
    public String encrypt(final String cleartext, final String masterSalt) {
        return this.cipherService.encrypt(cleartext, masterSalt);
    }
    
    public String decrypt(final String encryptedValue, final String masterSalt) {
        return this.cipherService.decrypt(encryptedValue, masterSalt);
    }
}
