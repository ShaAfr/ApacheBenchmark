// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.apache.deltaspike.core.util.ClassUtils;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import javax.enterprise.context.spi.CreationalContext;
import org.apache.deltaspike.core.api.provider.DependentProvider;
import javax.enterprise.inject.spi.AfterDeploymentValidation;
import javax.enterprise.context.ApplicationScoped;
import org.apache.deltaspike.core.api.literal.DefaultLiteral;
import java.io.Serializable;
import java.lang.reflect.Type;
import org.apache.deltaspike.core.util.metadata.builder.ContextualLifecycle;
import org.apache.deltaspike.core.util.bean.BeanBuilder;
import java.util.Iterator;
import javax.enterprise.inject.spi.Bean;
import java.util.Arrays;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.AfterBeanDiscovery;
import java.lang.reflect.Method;
import org.apache.deltaspike.core.api.message.Message;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.api.message.MessageTemplate;
import org.apache.deltaspike.core.api.message.MessageBundle;
import javax.enterprise.inject.spi.ProcessAnnotatedType;
import org.apache.deltaspike.core.util.ParentExtensionStorage;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.enterprise.inject.spi.AnnotatedType;
import java.util.Collection;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import javax.enterprise.inject.spi.Extension;

public class MessageBundleExtension implements Extension, Deactivatable
{
    private final Collection<AnnotatedType<?>> messageBundleTypes;
    private List<String> deploymentErrors;
    private Boolean isActivated;
    
    public MessageBundleExtension() {
        this.messageBundleTypes = new HashSet<AnnotatedType<?>>();
        this.deploymentErrors = new ArrayList<String>();
        this.isActivated = true;
    }
    
    protected void init(@Observes final BeforeBeanDiscovery beforeBeanDiscovery) {
        this.isActivated = ClassDeactivationUtils.isActivated((Class)this.getClass());
        ParentExtensionStorage.addExtension((Extension)this);
    }
    
    protected void detectInterfaces(@Observes final ProcessAnnotatedType processAnnotatedType) {
        if (!this.isActivated) {
            return;
        }
        final AnnotatedType<?> type = (AnnotatedType<?>)processAnnotatedType.getAnnotatedType();
        if (type.isAnnotationPresent((Class)MessageBundle.class) && this.validateMessageBundle(type.getJavaClass())) {
            this.messageBundleTypes.add(type);
        }
    }
    
    private boolean validateMessageBundle(final Class<?> currentClass) {
        boolean ok = true;
        if (!currentClass.isInterface()) {
            this.deploymentErrors.add("@MessageBundle must only be used on Interfaces, but got used on class " + currentClass.getName());
            return false;
        }
        for (final Method currentMethod : currentClass.getDeclaredMethods()) {
            if (currentMethod.isAnnotationPresent((Class<? extends Annotation>)MessageTemplate.class)) {
                if (!String.class.isAssignableFrom(currentMethod.getReturnType())) {
                    if (!Message.class.isAssignableFrom(currentMethod.getReturnType())) {
                        this.deploymentErrors.add(currentMethod.getReturnType().getName() + " isn't supported. Details: " + currentMethod.getDeclaringClass().getName() + "#" + currentMethod.getName() + " only " + String.class.getName() + " or " + Message.class.getName());
                        ok = false;
                    }
                }
            }
        }
        return ok;
    }
    
    protected void installMessageBundleProducerBeans(@Observes final AfterBeanDiscovery abd, final BeanManager beanManager) {
        if (!this.deploymentErrors.isEmpty()) {
            abd.addDefinitionError((Throwable)new IllegalArgumentException("The following MessageBundle problems where found: " + Arrays.toString(this.deploymentErrors.toArray())));
            return;
        }
        final MessageBundleExtension parentExtension = (MessageBundleExtension)ParentExtensionStorage.getParentExtension((Extension)this);
        if (parentExtension != null) {
            this.messageBundleTypes.addAll(parentExtension.messageBundleTypes);
        }
        for (final AnnotatedType<?> type : this.messageBundleTypes) {
            abd.addBean((Bean)this.createMessageBundleBean(type, beanManager));
        }
    }
    
    private <T> Bean<T> createMessageBundleBean(final AnnotatedType<T> annotatedType, final BeanManager beanManager) {
        final BeanBuilder<T> beanBuilder = (BeanBuilder<T>)new BeanBuilder(beanManager).readFromType((AnnotatedType)annotatedType);
        beanBuilder.beanLifecycle((ContextualLifecycle)new MessageBundleLifecycle(beanManager));
        beanBuilder.types(new Type[] { annotatedType.getJavaClass(), Object.class, Serializable.class });
        beanBuilder.addQualifier((Annotation)new DefaultLiteral());
        beanBuilder.passivationCapable(true);
        beanBuilder.scope((Class)ApplicationScoped.class);
        beanBuilder.id("MessageBundleBean#" + annotatedType.getJavaClass().getName());
        return (Bean<T>)beanBuilder.create();
    }
    
    protected void cleanup(@Observes final AfterDeploymentValidation afterDeploymentValidation) {
        this.messageBundleTypes.clear();
    }
    
    private static class MessageBundleLifecycle<T> implements ContextualLifecycle<T>
    {
        private final BeanManager beanManager;
        private DependentProvider<MessageBundleInvocationHandler> invocationHandlerProvider;
        
        private MessageBundleLifecycle(final BeanManager beanManager) {
            this.beanManager = beanManager;
        }
        
        public T create(final Bean<T> bean, final CreationalContext<T> creationalContext) {
            this.invocationHandlerProvider = (DependentProvider<MessageBundleInvocationHandler>)BeanProvider.getDependent(this.beanManager, (Class)MessageBundleInvocationHandler.class, new Annotation[0]);
            return this.createMessageBundleProxy((Class<T>)bean.getBeanClass(), (MessageBundleInvocationHandler)this.invocationHandlerProvider.get());
        }
        
        public void destroy(final Bean<T> bean, final T instance, final CreationalContext<T> creationalContext) {
            if (this.invocationHandlerProvider != null) {
                this.invocationHandlerProvider.destroy();
            }
        }
        
        private <T> T createMessageBundleProxy(final Class<T> type, final MessageBundleInvocationHandler handler) {
            return type.cast(Proxy.newProxyInstance(ClassUtils.getClassLoader((Object)null), new Class[] { type, Serializable.class }, handler));
        }
    }
}
