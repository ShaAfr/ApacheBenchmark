// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.window;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.enterprise.inject.Produces;
import org.apache.deltaspike.core.spi.scope.window.WindowContext;
import javax.inject.Inject;
import org.apache.deltaspike.core.impl.scope.DeltaSpikeContextExtension;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class WindowContextProducer
{
    @Inject
    private DeltaSpikeContextExtension deltaSpikeContextExtension;
    
    @Produces
    @Named("dsWindowContext")
    @Dependent
    public WindowContext getWindowContext() {
        return (WindowContext)new InjectableWindowContext((WindowContext)this.deltaSpikeContextExtension.getWindowContext());
    }
}
