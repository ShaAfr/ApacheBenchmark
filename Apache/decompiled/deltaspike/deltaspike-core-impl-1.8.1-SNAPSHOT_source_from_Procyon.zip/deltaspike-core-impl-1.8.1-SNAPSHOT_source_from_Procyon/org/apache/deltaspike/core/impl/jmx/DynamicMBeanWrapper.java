// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.jmx;

import javax.management.MBeanFeatureInfo;
import javax.management.Notification;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.context.spi.Contextual;
import java.util.Set;
import java.util.Arrays;
import java.lang.reflect.Type;
import org.apache.deltaspike.core.api.provider.BeanManagerProvider;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import javax.management.AttributeList;
import javax.management.InvalidAttributeValueException;
import javax.management.Attribute;
import java.util.Iterator;
import javax.management.openmbean.OpenDataException;
import javax.management.openmbean.CompositeData;
import javax.management.openmbean.CompositeDataSupport;
import javax.management.openmbean.TabularDataSupport;
import javax.management.openmbean.TabularType;
import javax.management.openmbean.CompositeType;
import javax.management.openmbean.SimpleType;
import javax.management.openmbean.OpenType;
import java.util.Collection;
import javax.management.ReflectionException;
import javax.management.MBeanException;
import javax.management.AttributeNotFoundException;
import java.lang.reflect.InvocationTargetException;
import java.util.logging.Level;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import javax.management.Descriptor;
import javax.management.ImmutableDescriptor;
import javax.management.openmbean.TabularData;
import org.apache.deltaspike.core.api.jmx.Table;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import javax.management.MBeanConstructorInfo;
import java.util.Comparator;
import java.util.Collections;
import org.apache.deltaspike.core.api.jmx.JmxParameter;
import org.apache.deltaspike.core.util.ParameterUtil;
import javax.management.MBeanParameterInfo;
import java.lang.reflect.Modifier;
import org.apache.deltaspike.core.api.jmx.JmxManaged;
import org.apache.deltaspike.core.api.jmx.NotificationInfo;
import org.apache.deltaspike.core.api.jmx.MBean;
import javax.management.MBeanNotificationInfo;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanAttributeInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.lang.annotation.Annotation;
import java.util.Map;
import javax.management.MBeanInfo;
import java.util.logging.Logger;
import org.apache.deltaspike.core.api.jmx.JmxBroadcaster;
import javax.management.DynamicMBean;
import javax.management.NotificationBroadcasterSupport;

public class DynamicMBeanWrapper extends NotificationBroadcasterSupport implements DynamicMBean, JmxBroadcaster
{
    public static final Logger LOGGER;
    private final MBeanInfo info;
    private final Map<String, AttributeAccessor> fields;
    private final Map<String, Operation> operations;
    private final ClassLoader classloader;
    private final Class<?> clazz;
    private final boolean normalScope;
    private final Annotation[] qualifiers;
    private Object instance;
    
    public DynamicMBeanWrapper(final Class<?> annotatedMBean, final boolean normalScope, final Annotation[] qualifiers) {
        this.fields = new HashMap<String, AttributeAccessor>();
        this.operations = new HashMap<String, Operation>();
        this.instance = null;
        this.clazz = annotatedMBean;
        this.classloader = Thread.currentThread().getContextClassLoader();
        this.normalScope = normalScope;
        this.qualifiers = qualifiers;
        final List<MBeanAttributeInfo> attributeInfos = new ArrayList<MBeanAttributeInfo>();
        final List<MBeanOperationInfo> operationInfos = new ArrayList<MBeanOperationInfo>();
        final List<MBeanNotificationInfo> notificationInfos = new ArrayList<MBeanNotificationInfo>();
        final String description = this.getDescription(annotatedMBean.getAnnotation(MBean.class).description(), annotatedMBean.getName());
        final NotificationInfo notification = annotatedMBean.getAnnotation(NotificationInfo.class);
        if (notification != null) {
            notificationInfos.add(this.getNotificationInfo(notification, annotatedMBean.getName()));
        }
        final NotificationInfo.List notifications = annotatedMBean.getAnnotation(NotificationInfo.List.class);
        if (notifications != null) {
            for (final NotificationInfo notificationInfo : notifications.value()) {
                notificationInfos.add(this.getNotificationInfo(notificationInfo, annotatedMBean.getName()));
            }
        }
        for (final Method method : annotatedMBean.getMethods()) {
            final int modifiers = method.getModifiers();
            final JmxManaged annotation = method.getAnnotation(JmxManaged.class);
            if (!method.getDeclaringClass().equals(Object.class) && Modifier.isPublic(modifiers) && !Modifier.isAbstract(modifiers) && !Modifier.isStatic(modifiers)) {
                if (annotation != null) {
                    this.operations.put(method.getName(), new Operation(method, annotation.convertToTabularData()));
                    final String operationDescr = this.getDescription(annotation.description(), method.getName());
                    final Annotation[][] parametersAnnotations = method.getParameterAnnotations();
                    final Class<?>[] parameterTypes = method.getParameterTypes();
                    final MBeanParameterInfo[] parameterInfos = new MBeanParameterInfo[parameterTypes.length];
                    for (int i = 0; i < parametersAnnotations.length; ++i) {
                        String parameterDescription = null;
                        String parameterName = "p" + (i + 1);
                        final String java8ParameterName = ParameterUtil.getName(method, i);
                        if (java8ParameterName != null) {
                            parameterName = java8ParameterName;
                        }
                        for (int j = 0; j < parametersAnnotations[i].length; ++j) {
                            if (parametersAnnotations[i][j] instanceof JmxParameter) {
                                final JmxParameter jmxParameter = (JmxParameter)parametersAnnotations[i][j];
                                if (!"".equals(jmxParameter.name())) {
                                    parameterName = jmxParameter.name();
                                }
                                if (!"".equals(jmxParameter.description())) {
                                    parameterDescription = jmxParameter.description();
                                }
                            }
                        }
                        parameterInfos[i] = new MBeanParameterInfo(parameterName, parameterTypes[i].getName(), parameterDescription);
                    }
                    operationInfos.add(new MBeanOperationInfo(method.getName(), operationDescr, parameterInfos, method.getReturnType().getName(), 3));
                }
            }
        }
        for (Class<?> clazz = annotatedMBean; !Object.class.equals(clazz) && clazz != null; clazz = clazz.getSuperclass()) {
            for (final Field field : clazz.getDeclaredFields()) {
                final JmxManaged annotation = field.getAnnotation(JmxManaged.class);
                if (annotation != null) {
                    field.setAccessible(true);
                    final String fieldName = field.getName();
                    final String fieldDescription = this.getDescription(annotation.description(), fieldName);
                    final Class<?> type = field.getType();
                    String methodName;
                    if (fieldName.length() > 1) {
                        methodName = Character.toUpperCase(fieldName.charAt(0)) + fieldName.substring(1);
                    }
                    else {
                        methodName = Character.toString(Character.toUpperCase(fieldName.charAt(0)));
                    }
                    Method setter = null;
                    Method getter = null;
                    try {
                        getter = clazz.getMethod("get" + methodName, (Class<?>[])new Class[0]);
                    }
                    catch (NoSuchMethodException e1) {
                        try {
                            getter = clazz.getMethod("is" + methodName, (Class<?>[])new Class[0]);
                        }
                        catch (NoSuchMethodException ex) {}
                    }
                    try {
                        setter = clazz.getMethod("set" + methodName, field.getType());
                    }
                    catch (NoSuchMethodException ex2) {}
                    attributeInfos.add(new MBeanAttributeInfo(fieldName, this.toMBeanType(type).getName(), fieldDescription, getter != null, setter != null, false));
                    this.fields.put(fieldName, new AttributeAccessor(getter, setter, annotation.convertToTabularData()));
                }
            }
        }
        Collections.sort(attributeInfos, MBeanFeatureInfoSorter.INSTANCE);
        Collections.sort(operationInfos, MBeanFeatureInfoSorter.INSTANCE);
        Collections.sort(notificationInfos, MBeanFeatureInfoSorter.INSTANCE);
        this.info = new MBeanInfo(annotatedMBean.getName(), description, attributeInfos.toArray(new MBeanAttributeInfo[attributeInfos.size()]), null, operationInfos.toArray(new MBeanOperationInfo[operationInfos.size()]), notificationInfos.toArray(new MBeanNotificationInfo[notificationInfos.size()]));
    }
    
    private Class<?> toMBeanType(final Class<?> type) {
        if (Map.class.isAssignableFrom(type) || Table.class.isAssignableFrom(type)) {
            return TabularData.class;
        }
        return type;
    }
    
    private MBeanNotificationInfo getNotificationInfo(final NotificationInfo notificationInfo, final String sourceInfo) {
        return new MBeanNotificationInfo(notificationInfo.types(), notificationInfo.notificationClass().getName(), this.getDescription(notificationInfo.description(), sourceInfo), new ImmutableDescriptor(notificationInfo.descriptorFields()));
    }
    
    private String getDescription(final String description, final String defaultDescription) {
        if (description.isEmpty()) {
            return defaultDescription;
        }
        final String descriptionValue = description.trim();
        if (descriptionValue.startsWith("{") && descriptionValue.endsWith("}")) {
            return ConfigResolver.getPropertyValue(descriptionValue.substring(1, descriptionValue.length() - 1), defaultDescription);
        }
        return description;
    }
    
    @Override
    public MBeanInfo getMBeanInfo() {
        return this.info;
    }
    
    @Override
    public Object getAttribute(final String attribute) throws AttributeNotFoundException, MBeanException, ReflectionException {
        if (this.fields.containsKey(attribute)) {
            final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
            Thread.currentThread().setContextClassLoader(this.classloader);
            try {
                final AttributeAccessor attributeAccessor = this.fields.get(attribute);
                final Object value = attributeAccessor.get(this.instance());
                return attributeAccessor.isPresentAsTabularIfPossible() ? this.toResult(attribute, value) : value;
            }
            catch (IllegalArgumentException e) {
                DynamicMBeanWrapper.LOGGER.log(Level.SEVERE, "can't get " + attribute + " value", e);
            }
            catch (IllegalAccessException e2) {
                DynamicMBeanWrapper.LOGGER.log(Level.SEVERE, "can't get " + attribute + " value", e2);
            }
            catch (InvocationTargetException e3) {
                DynamicMBeanWrapper.LOGGER.log(Level.SEVERE, "can't get " + attribute + " value", e3);
            }
            finally {
                Thread.currentThread().setContextClassLoader(oldCl);
            }
        }
        throw new AttributeNotFoundException();
    }
    
    private Object toResult(final String attribute, final Object value) throws InvocationTargetException, IllegalAccessException {
        if (Map.class.isInstance(value)) {
            final Map map = Map.class.cast(value);
            return this.toTabularData(attribute, attribute, new Table().withColumns((Collection)map.keySet()).withLine((Collection)map.values()));
        }
        if (Table.class.isInstance(value)) {
            return this.toTabularData(attribute, attribute, Table.class.cast(value));
        }
        return value;
    }
    
    private TabularData toTabularData(final String typeName, final String description, final Table table) {
        final OpenType<?>[] types = (OpenType<?>[])new OpenType[table.getColumnNames().size()];
        for (int i = 0; i < types.length; ++i) {
            types[i] = SimpleType.STRING;
        }
        try {
            final String[] keys = table.getColumnNames().toArray(new String[table.getColumnNames().size()]);
            final CompositeType ct = new CompositeType(typeName, description, keys, keys, types);
            final TabularType type = new TabularType(typeName, description, ct, keys);
            final TabularDataSupport data = new TabularDataSupport(type);
            for (final Collection<String> line : table.getLines()) {
                data.put(new CompositeDataSupport(ct, keys, line.toArray(new Object[line.size()])));
            }
            return data;
        }
        catch (OpenDataException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    @Override
    public void setAttribute(final Attribute attribute) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException {
        if (this.fields.containsKey(attribute.getName())) {
            final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
            Thread.currentThread().setContextClassLoader(this.classloader);
            try {
                this.fields.get(attribute.getName()).set(this.instance(), attribute.getValue());
            }
            catch (IllegalArgumentException e) {
                DynamicMBeanWrapper.LOGGER.log(Level.SEVERE, "can't set " + attribute + " value", e);
            }
            catch (IllegalAccessException e2) {
                DynamicMBeanWrapper.LOGGER.log(Level.SEVERE, "can't set " + attribute + " value", e2);
            }
            catch (InvocationTargetException e3) {
                DynamicMBeanWrapper.LOGGER.log(Level.SEVERE, "can't set " + attribute + " value", e3);
            }
            finally {
                Thread.currentThread().setContextClassLoader(oldCl);
            }
            return;
        }
        throw new AttributeNotFoundException();
    }
    
    @Override
    public AttributeList getAttributes(final String[] attributes) {
        final AttributeList list = new AttributeList();
        for (final String n : attributes) {
            try {
                list.add(new Attribute(n, this.getAttribute(n)));
            }
            catch (Exception ex) {}
        }
        return list;
    }
    
    @Override
    public AttributeList setAttributes(final AttributeList attributes) {
        final AttributeList list = new AttributeList();
        for (final Object o : attributes) {
            final Attribute attr = (Attribute)o;
            try {
                this.setAttribute(attr);
                list.add(attr);
            }
            catch (Exception ex) {}
        }
        return list;
    }
    
    @Override
    public Object invoke(final String actionName, final Object[] params, final String[] signature) throws MBeanException, ReflectionException {
        if (this.operations.containsKey(actionName)) {
            final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
            Thread.currentThread().setContextClassLoader(this.classloader);
            try {
                final Operation operation = this.operations.get(actionName);
                final Object result = operation.getOperation().invoke(this.instance(), params);
                return operation.isPresentAsTabularIfPossible() ? this.toResult(actionName, result) : result;
            }
            catch (InvocationTargetException e) {
                final Throwable cause = e.getCause();
                if (cause instanceof Error) {
                    throw (Error)cause;
                }
                if (cause instanceof MBeanException) {
                    throw (MBeanException)cause;
                }
                throw new MBeanException((Exception)cause, actionName + " failed with exception");
            }
            catch (IllegalAccessException e2) {
                throw new ReflectionException(e2, actionName + " could not be invoked");
            }
            catch (IllegalArgumentException e3) {
                throw new ReflectionException(e3, actionName + " could not be invoked");
            }
            finally {
                Thread.currentThread().setContextClassLoader(oldCl);
            }
        }
        throw new ReflectionException(new NoSuchMethodException(actionName + " doesn't exist"));
    }
    
    private synchronized Object instance() {
        final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(this.classloader);
        try {
            if (this.instance != null) {
                return this.instance;
            }
            if (this.normalScope) {
                this.instance = BeanProvider.getContextualReference((Class)this.clazz, this.qualifiers);
            }
            else {
                final BeanManager bm = BeanManagerProvider.getInstance().getBeanManager();
                final Set<Bean<?>> beans = (Set<Bean<?>>)bm.getBeans((Type)this.clazz, this.qualifiers);
                if (beans == null || beans.isEmpty()) {
                    throw new IllegalStateException("Could not find beans for Type=" + this.clazz + " and qualifiers:" + Arrays.toString(this.qualifiers));
                }
                final Bean<?> resolvedBean = (Bean<?>)bm.resolve((Set)beans);
                final CreationalContext<?> creationalContext = (CreationalContext<?>)bm.createCreationalContext((Contextual)resolvedBean);
                this.instance = bm.getReference((Bean)resolvedBean, (Type)this.clazz, (CreationalContext)creationalContext);
                creationalContext.release();
            }
            return this.instance;
        }
        finally {
            Thread.currentThread().setContextClassLoader(oldCl);
        }
    }
    
    public void send(final Notification notification) {
        this.sendNotification(notification);
    }
    
    static {
        LOGGER = Logger.getLogger(DynamicMBeanWrapper.class.getName());
    }
    
    private static class MBeanFeatureInfoSorter<T extends MBeanFeatureInfo> implements Comparator<T>
    {
        private static final Comparator<? super MBeanFeatureInfo> INSTANCE;
        
        @Override
        public int compare(final T o1, final T o2) {
            return o1.getName().compareTo(o2.getName());
        }
        
        static {
            INSTANCE = new MBeanFeatureInfoSorter<Object>();
        }
    }
}
