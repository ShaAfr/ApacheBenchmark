// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.util;

import javax.naming.NamingEnumeration;
import javax.naming.NameParser;
import javax.naming.NameClassPair;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import org.apache.deltaspike.core.util.ClassUtils;
import javax.naming.NamingException;
import org.apache.deltaspike.core.util.ExceptionUtils;
import javax.naming.Name;
import javax.naming.InitialContext;
import java.util.logging.Logger;
import javax.enterprise.inject.Typed;

@Typed
public abstract class JndiUtils
{
    private static final Logger LOG;
    private static InitialContext initialContext;
    
    private JndiUtils() {
    }
    
    public static <T> T lookup(final Name name, final Class<? extends T> targetType) {
        try {
            return verifyLookupResult(JndiUtils.initialContext.lookup(name), name.toString(), targetType);
        }
        catch (NamingException e) {
            throw ExceptionUtils.throwAsRuntimeException((Throwable)e);
        }
    }
    
    public static <T> T lookup(final String name, final Class<? extends T> targetType) {
        try {
            return verifyLookupResult(JndiUtils.initialContext.lookup(name), name, targetType);
        }
        catch (NamingException e) {
            throw ExceptionUtils.throwAsRuntimeException((Throwable)e);
        }
    }
    
    private static <T> T verifyLookupResult(final Object result, final String name, final Class<? extends T> targetType) {
        if (result != null) {
            if (targetType.isAssignableFrom(result.getClass())) {
                return (T)result;
            }
            if (result instanceof String) {
                try {
                    final Class<?> classOfResult = (Class<?>)ClassUtils.loadClassForName((String)result);
                    if (targetType.isAssignableFrom(classOfResult)) {
                        try {
                            return (T)classOfResult.newInstance();
                        }
                        catch (Exception e) {
                            JndiUtils.LOG.log(Level.SEVERE, "Class " + classOfResult + " from JNDI lookup for name " + name + " could not be instantiated", e);
                            return null;
                        }
                    }
                    JndiUtils.LOG.log(Level.SEVERE, "JNDI lookup for key " + name + " returned class " + classOfResult.getName() + " which does not implement/extend the expected class" + targetType.getName());
                }
                catch (ClassNotFoundException cnfe) {
                    JndiUtils.LOG.log(Level.SEVERE, "Could not find Class " + result + " from JNDI lookup for name " + name, cnfe);
                }
            }
            else {
                JndiUtils.LOG.log(Level.SEVERE, "JNDI lookup for key " + name + " should return a value of " + targetType + ", but returned " + result);
            }
        }
        return null;
    }
    
    public static <T> Map<String, T> list(final String name, final Class<T> type) {
        final Map<String, T> result = new HashMap<String, T>();
        try {
            final NameParser nameParser = JndiUtils.initialContext.getNameParser(name);
            final NamingEnumeration<NameClassPair> enumeration = JndiUtils.initialContext.list(name);
            while (enumeration.hasMoreElements()) {
                try {
                    final NameClassPair binding = enumeration.nextElement();
                    final Name bindingName = nameParser.parse(name).add(binding.getName());
                    result.put(binding.getName(), lookup(bindingName, (Class<? extends T>)type));
                }
                catch (NamingException e) {
                    if (!JndiUtils.LOG.isLoggable(Level.FINEST)) {
                        continue;
                    }
                    JndiUtils.LOG.log(Level.FINEST, "InitialContext#list failed!", e);
                }
            }
        }
        catch (NamingException e2) {
            JndiUtils.LOG.log(Level.WARNING, "Problem reading the name of the JNDI location " + name + " or failuring listing pairs.", e2);
        }
        return result;
    }
    
    static {
        LOG = Logger.getLogger(JndiUtils.class.getName());
        JndiUtils.initialContext = null;
        try {
            JndiUtils.initialContext = new InitialContext();
        }
        catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }
}
