// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.util.Enumeration;
import java.net.URISyntaxException;
import java.io.IOException;
import java.util.logging.Level;
import java.net.URL;
import org.apache.deltaspike.core.util.PropertyFileUtils;
import java.util.ArrayList;
import org.apache.deltaspike.core.spi.config.ConfigSource;
import java.util.List;
import java.util.logging.Logger;
import org.apache.deltaspike.core.spi.config.ConfigSourceProvider;

class EnvironmentPropertyConfigSourceProvider implements ConfigSourceProvider
{
    private static final Logger LOG;
    private List<ConfigSource> configSources;
    
    EnvironmentPropertyConfigSourceProvider(final String propertyFileName, final boolean optional) {
        this.configSources = new ArrayList<ConfigSource>();
        try {
            final Enumeration<URL> propertyFileUrls = (Enumeration<URL>)PropertyFileUtils.resolvePropertyFiles(propertyFileName);
            if (!optional && !propertyFileUrls.hasMoreElements()) {
                throw new IllegalStateException(propertyFileName + " wasn't found.");
            }
            while (propertyFileUrls.hasMoreElements()) {
                final URL propertyFileUrl = propertyFileUrls.nextElement();
                EnvironmentPropertyConfigSourceProvider.LOG.log(Level.INFO, "Custom config found by DeltaSpike. Name: ''{0}'', URL: ''{1}''", new Object[] { propertyFileName, propertyFileUrl });
                this.configSources.add((ConfigSource)new PropertyFileConfigSource(propertyFileUrl));
            }
        }
        catch (IOException ioe) {
            throw new IllegalStateException("problem while loading DeltaSpike property files", ioe);
        }
        catch (URISyntaxException ue) {
            throw new IllegalStateException("Property file URL is malformed", ue);
        }
    }
    
    public List<ConfigSource> getConfigSources() {
        return this.configSources;
    }
    
    static {
        LOG = Logger.getLogger(EnvironmentPropertyConfigSourceProvider.class.getName());
    }
}
