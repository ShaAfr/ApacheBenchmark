// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope;

import org.apache.deltaspike.core.impl.scope.viewaccess.ViewAccessViewHistory;
import org.apache.deltaspike.core.impl.scope.viewaccess.ViewAccessBeanAccessHistory;
import org.apache.deltaspike.core.impl.scope.viewaccess.ViewAccessBeanHolder;
import org.apache.deltaspike.core.impl.scope.conversation.ConversationBeanHolder;
import org.apache.deltaspike.core.impl.scope.window.WindowIdHolder;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.impl.scope.window.WindowBeanHolder;
import javax.enterprise.inject.spi.AfterDeploymentValidation;
import javax.enterprise.context.spi.Context;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.AfterBeanDiscovery;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import org.apache.deltaspike.core.impl.scope.viewaccess.ViewAccessContext;
import org.apache.deltaspike.core.impl.scope.conversation.GroupedConversationContext;
import org.apache.deltaspike.core.impl.scope.window.WindowContextImpl;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import javax.enterprise.inject.spi.Extension;

public class DeltaSpikeContextExtension implements Extension, Deactivatable
{
    private WindowContextImpl windowContext;
    private GroupedConversationContext conversationContext;
    private ViewAccessContext viewAccessScopedContext;
    private Boolean isActivated;
    
    public DeltaSpikeContextExtension() {
        this.isActivated = true;
    }
    
    protected void init(@Observes final BeforeBeanDiscovery beforeBeanDiscovery) {
        this.isActivated = ClassDeactivationUtils.isActivated((Class)this.getClass());
    }
    
    public void registerDeltaSpikeContexts(@Observes final AfterBeanDiscovery afterBeanDiscovery, final BeanManager beanManager) {
        if (!this.isActivated) {
            return;
        }
        this.windowContext = new WindowContextImpl(beanManager);
        this.conversationContext = new GroupedConversationContext(beanManager, this.windowContext);
        this.viewAccessScopedContext = new ViewAccessContext(beanManager, this.windowContext);
        afterBeanDiscovery.addContext((Context)this.windowContext);
        afterBeanDiscovery.addContext((Context)this.conversationContext);
        afterBeanDiscovery.addContext((Context)this.viewAccessScopedContext);
    }
    
    public void initializeDeltaSpikeContexts(@Observes final AfterDeploymentValidation adv, final BeanManager beanManager) {
        if (!this.isActivated) {
            return;
        }
        final WindowBeanHolder windowBeanHolder = (WindowBeanHolder)BeanProvider.getContextualReference(beanManager, (Class)WindowBeanHolder.class, false, new Annotation[0]);
        final WindowIdHolder windowIdHolder = (WindowIdHolder)BeanProvider.getContextualReference(beanManager, (Class)WindowIdHolder.class, false, new Annotation[0]);
        this.windowContext.init(windowBeanHolder, windowIdHolder);
        final ConversationBeanHolder conversationBeanHolder = (ConversationBeanHolder)BeanProvider.getContextualReference(beanManager, (Class)ConversationBeanHolder.class, false, new Annotation[0]);
        this.conversationContext.init(conversationBeanHolder);
        final ViewAccessBeanHolder viewAccessBeanHolder = (ViewAccessBeanHolder)BeanProvider.getContextualReference(beanManager, (Class)ViewAccessBeanHolder.class, false, new Annotation[0]);
        final ViewAccessBeanAccessHistory viewAccessBeanAccessHistory = (ViewAccessBeanAccessHistory)BeanProvider.getContextualReference(beanManager, (Class)ViewAccessBeanAccessHistory.class, false, new Annotation[0]);
        final ViewAccessViewHistory viewAccessViewHistory = (ViewAccessViewHistory)BeanProvider.getContextualReference(beanManager, (Class)ViewAccessViewHistory.class, false, new Annotation[0]);
        this.viewAccessScopedContext.init(viewAccessBeanHolder, viewAccessBeanAccessHistory, viewAccessViewHistory);
    }
    
    public WindowContextImpl getWindowContext() {
        return this.windowContext;
    }
    
    public GroupedConversationContext getConversationContext() {
        return this.conversationContext;
    }
    
    public ViewAccessContext getViewAccessScopedContext() {
        return this.viewAccessScopedContext;
    }
}
