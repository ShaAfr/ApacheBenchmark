// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.resourceloader;

import java.util.Iterator;
import java.util.logging.Level;
import javax.enterprise.inject.Disposes;
import java.io.IOException;
import java.util.Properties;
import java.util.List;
import javax.enterprise.inject.Produces;
import org.apache.deltaspike.core.api.resourceloader.InjectableResource;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import java.lang.annotation.Annotation;
import java.io.InputStream;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.enterprise.inject.Any;
import javax.inject.Inject;
import org.apache.deltaspike.core.api.resourceloader.InjectableResourceProvider;
import javax.enterprise.inject.Instance;
import java.util.logging.Logger;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class InjectableResourceProducer
{
    private static final Logger logger;
    @Inject
    @Any
    private Instance<InjectableResourceProvider> resourceProviders;
    
    @Produces
    @InjectableResource(resourceProvider = InjectableResourceProvider.class, location = "")
    public InputStream getInputStream(final InjectionPoint injectionPoint) {
        final InjectableResource injectableResource = this.getAnnotation(injectionPoint);
        final InjectableResourceProvider provider = (InjectableResourceProvider)BeanProvider.getContextualReference(injectableResource.resourceProvider(), new Annotation[0]);
        final InputStream is = provider.readStream(injectableResource);
        return is;
    }
    
    @Produces
    @InjectableResource(resourceProvider = InjectableResourceProvider.class, location = "")
    public List<InputStream> getInputStreams(final InjectionPoint injectionPoint) {
        final InjectableResource injectableResource = this.getAnnotation(injectionPoint);
        final InjectableResourceProvider provider = (InjectableResourceProvider)BeanProvider.getContextualReference(injectableResource.resourceProvider(), new Annotation[0]);
        return (List<InputStream>)provider.readStreams(injectableResource);
    }
    
    @Produces
    @InjectableResource(resourceProvider = InjectableResourceProvider.class, location = "")
    public Properties getProperties(final InjectionPoint injectionPoint) throws IOException {
        final InjectableResource injectableResource = this.getAnnotation(injectionPoint);
        final InjectableResourceProvider provider = (InjectableResourceProvider)BeanProvider.getContextualReference(injectableResource.resourceProvider(), new Annotation[0]);
        final Properties properties = provider.readProperties(injectableResource);
        return properties;
    }
    
    public void closeInputStream(@Disposes @InjectableResource(resourceProvider = InjectableResourceProvider.class, location = "") final InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            }
            catch (IOException e) {
                if (InjectableResourceProducer.logger.isLoggable(Level.FINE)) {
                    InjectableResourceProducer.logger.log(Level.FINE, "Unable to close input stream ", e);
                }
            }
        }
    }
    
    private InjectableResource getAnnotation(final InjectionPoint injectionPoint) {
        for (final Annotation annotation : injectionPoint.getQualifiers()) {
            if (annotation instanceof InjectableResource) {
                return (InjectableResource)annotation;
            }
        }
        return null;
    }
    
    static {
        logger = Logger.getLogger(InjectableResourceProducer.class.getName());
    }
}
