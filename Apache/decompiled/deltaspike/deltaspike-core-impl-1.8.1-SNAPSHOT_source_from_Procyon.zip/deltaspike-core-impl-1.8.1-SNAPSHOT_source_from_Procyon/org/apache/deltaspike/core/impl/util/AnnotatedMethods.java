// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.util;

import java.util.Iterator;
import javax.enterprise.inject.spi.AnnotatedMethod;
import java.lang.reflect.Method;
import javax.enterprise.inject.spi.AnnotatedType;

public final class AnnotatedMethods
{
    private AnnotatedMethods() {
    }
    
    public static AnnotatedMethod<?> findMethod(final AnnotatedType<?> type, final Method method) {
        AnnotatedMethod<?> annotatedMethod = null;
        for (final AnnotatedMethod<?> am : type.getMethods()) {
            if (am.getJavaMember().equals(method)) {
                annotatedMethod = am;
                break;
            }
        }
        if (annotatedMethod == null) {
            throw new IllegalStateException("No annotated method for " + method);
        }
        return annotatedMethod;
    }
}
