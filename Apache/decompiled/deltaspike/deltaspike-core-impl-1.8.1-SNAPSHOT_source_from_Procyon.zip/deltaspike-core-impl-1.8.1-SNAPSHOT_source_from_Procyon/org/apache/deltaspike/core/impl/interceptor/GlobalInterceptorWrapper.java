// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.interceptor;

import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.Collection;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Set;
import java.lang.annotation.Annotation;
import java.util.Map;
import javax.enterprise.inject.spi.AnnotatedType;

class GlobalInterceptorWrapper implements AnnotatedType<Object>
{
    private final AnnotatedType wrapped;
    private Map<Class<? extends Annotation>, Annotation> annotations;
    private Set<Annotation> annotationSet;
    
    GlobalInterceptorWrapper(final AnnotatedType wrapped, final Annotation priorityAnnotation) {
        this.wrapped = wrapped;
        final Set<Annotation> originalAnnotationSet = (Set<Annotation>)wrapped.getAnnotations();
        this.annotations = new HashMap<Class<? extends Annotation>, Annotation>(originalAnnotationSet.size());
        for (final Annotation originalAnnotation : originalAnnotationSet) {
            this.annotations.put(originalAnnotation.annotationType(), originalAnnotation);
        }
        this.annotations.put(priorityAnnotation.annotationType(), priorityAnnotation);
        (this.annotationSet = new HashSet<Annotation>(this.annotations.size())).addAll(this.annotations.values());
    }
    
    public Class getJavaClass() {
        return this.wrapped.getJavaClass();
    }
    
    public Set getConstructors() {
        return this.wrapped.getConstructors();
    }
    
    public Set getMethods() {
        return this.wrapped.getMethods();
    }
    
    public Set getFields() {
        return this.wrapped.getFields();
    }
    
    public Type getBaseType() {
        return this.wrapped.getBaseType();
    }
    
    public Set<Type> getTypeClosure() {
        return (Set<Type>)this.wrapped.getTypeClosure();
    }
    
    public <T extends Annotation> T getAnnotation(final Class<T> targetClass) {
        return (T)this.annotations.get(targetClass);
    }
    
    public Set<Annotation> getAnnotations() {
        return this.annotationSet;
    }
    
    public boolean isAnnotationPresent(final Class<? extends Annotation> targetClass) {
        return this.annotations.containsKey(targetClass);
    }
}
