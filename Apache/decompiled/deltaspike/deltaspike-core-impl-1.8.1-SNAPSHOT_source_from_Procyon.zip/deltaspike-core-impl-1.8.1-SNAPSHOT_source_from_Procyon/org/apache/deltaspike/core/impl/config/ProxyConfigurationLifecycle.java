// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.util.concurrent.TimeUnit;
import java.lang.reflect.Type;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentMap;
import org.apache.deltaspike.core.spi.config.BaseConfigPropertyProducer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.apache.deltaspike.core.api.config.Configuration;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import org.apache.deltaspike.core.util.metadata.builder.ContextualLifecycle;

class ProxyConfigurationLifecycle implements ContextualLifecycle
{
    private Class<?>[] api;
    
    ProxyConfigurationLifecycle(final Class<?> proxyType) {
        this.api = (Class<?>[])new Class[] { proxyType };
    }
    
    public Object create(final Bean bean, final CreationalContext creationalContext) {
        final Configuration configuration = this.api[0].getAnnotation(Configuration.class);
        final long cacheFor = configuration.cacheFor();
        return Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), this.api, new ConfigurationHandler((cacheFor <= 0L) ? -1L : configuration.cacheUnit().toMillis(cacheFor), configuration.prefix()));
    }
    
    public void destroy(final Bean bean, final Object instance, final CreationalContext creationalContext) {
    }
    
    private static final class ConfigurationHandler implements InvocationHandler
    {
        private final BaseConfigPropertyProducer delegate;
        private final ConcurrentMap<Method, ConfigResolver.TypedResolver<?>> resolvers;
        private final long cacheMs;
        private final String prefix;
        
        private ConfigurationHandler(final long cacheMs, final String prefix) {
            this.delegate = new BaseConfigPropertyProducer() {};
            this.resolvers = new ConcurrentHashMap<Method, ConfigResolver.TypedResolver<?>>();
            this.cacheMs = cacheMs;
            this.prefix = prefix;
        }
        
        @Override
        public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
            if (Object.class == method.getDeclaringClass()) {
                try {
                    return method.invoke(this, args);
                }
                catch (InvocationTargetException ite) {
                    throw ite.getCause();
                }
            }
            ConfigResolver.TypedResolver<?> typedResolver = (ConfigResolver.TypedResolver<?>)this.resolvers.get(method);
            if (typedResolver == null) {
                final ConfigProperty annotation = method.getAnnotation(ConfigProperty.class);
                if (annotation == null) {
                    throw new UnsupportedOperationException(method + " doesn't have @ConfigProperty and therefore is illegal");
                }
                Class<?> returnType = method.getReturnType();
                if (Integer.TYPE == returnType) {
                    returnType = Integer.class;
                }
                else if (Long.TYPE == returnType) {
                    returnType = Long.class;
                }
                else if (Boolean.TYPE == returnType) {
                    returnType = Boolean.class;
                }
                else if (Short.TYPE == returnType) {
                    returnType = Short.class;
                }
                else if (Byte.TYPE == returnType) {
                    returnType = Byte.class;
                }
                else if (Float.TYPE == returnType) {
                    returnType = Float.class;
                }
                else if (Double.TYPE == returnType) {
                    returnType = Double.class;
                }
                typedResolver = (ConfigResolver.TypedResolver<?>)this.delegate.asResolver(this.prefix + annotation.name(), annotation.defaultValue(), (Type)returnType, annotation.converter(), annotation.parameterizedBy(), annotation.projectStageAware(), annotation.evaluateVariables());
                if (this.cacheMs > 0L) {
                    typedResolver.cacheFor(TimeUnit.MILLISECONDS, this.cacheMs);
                }
                final ConfigResolver.TypedResolver<?> existing = this.resolvers.putIfAbsent(method, typedResolver);
                if (existing != null) {
                    typedResolver = existing;
                }
            }
            return typedResolver.getValue();
        }
    }
}
