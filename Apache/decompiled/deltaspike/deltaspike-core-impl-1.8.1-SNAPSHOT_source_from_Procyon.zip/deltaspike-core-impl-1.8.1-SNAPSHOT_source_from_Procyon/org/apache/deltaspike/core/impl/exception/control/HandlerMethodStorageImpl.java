// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control;

import java.util.Iterator;
import org.apache.deltaspike.core.api.literal.AnyLiteral;
import org.apache.deltaspike.core.util.HierarchyDiscovery;
import java.util.Comparator;
import java.util.TreeSet;
import java.lang.annotation.Annotation;
import java.util.Set;
import javax.enterprise.inject.spi.BeanManager;
import java.util.HashSet;
import java.util.Collections;
import java.util.logging.Logger;
import org.apache.deltaspike.core.api.exception.control.HandlerMethod;
import java.util.Collection;
import java.lang.reflect.Type;
import java.util.Map;
import javax.enterprise.inject.Typed;

@Typed
class HandlerMethodStorageImpl implements HandlerMethodStorage
{
    private final Map<Type, Collection<HandlerMethod<? extends Throwable>>> allHandlers;
    private Logger log;
    
    HandlerMethodStorageImpl(final Map<Type, Collection<HandlerMethod<? extends Throwable>>> allHandlers) {
        this.log = Logger.getLogger(HandlerMethodStorageImpl.class.toString());
        this.allHandlers = allHandlers;
    }
    
    @Override
    public <T extends Throwable> void registerHandlerMethod(final HandlerMethod<T> handlerMethod) {
        this.log.fine(String.format("Adding handler %s to known handlers", handlerMethod));
        if (this.allHandlers.containsKey(handlerMethod.getExceptionType())) {
            this.allHandlers.get(handlerMethod.getExceptionType()).add(handlerMethod);
        }
        else {
            this.allHandlers.put(handlerMethod.getExceptionType(), new HashSet<HandlerMethod<? extends Throwable>>(Collections.singleton(handlerMethod)));
        }
    }
    
    @Override
    public Collection<HandlerMethod<? extends Throwable>> getHandlersForException(final Type exceptionClass, final BeanManager bm, final Set<Annotation> handlerQualifiers, final boolean isBefore) {
        final Collection<HandlerMethod<? extends Throwable>> returningHandlers = new TreeSet<HandlerMethod<? extends Throwable>>(new ExceptionHandlerComparator());
        final HierarchyDiscovery h = new HierarchyDiscovery(exceptionClass);
        final Set<Type> closure = (Set<Type>)h.getTypeClosure();
        for (final Type hierarchyType : closure) {
            if (this.allHandlers.get(hierarchyType) != null) {
                for (final HandlerMethod<?> handler : this.allHandlers.get(hierarchyType)) {
                    if (handler.isBeforeHandler() && isBefore) {
                        if (handler.getQualifiers().contains(new AnyLiteral())) {
                            returningHandlers.add((HandlerMethod<? extends Throwable>)handler);
                        }
                        else {
                            if (handlerQualifiers.isEmpty() || !handlerQualifiers.equals(handler.getQualifiers())) {
                                continue;
                            }
                            returningHandlers.add((HandlerMethod<? extends Throwable>)handler);
                        }
                    }
                    else {
                        if (handler.isBeforeHandler() || isBefore) {
                            continue;
                        }
                        if (handler.getQualifiers().contains(new AnyLiteral())) {
                            returningHandlers.add((HandlerMethod<? extends Throwable>)handler);
                        }
                        else {
                            if (handlerQualifiers.isEmpty() || !handlerQualifiers.equals(handler.getQualifiers())) {
                                continue;
                            }
                            returningHandlers.add((HandlerMethod<? extends Throwable>)handler);
                        }
                    }
                }
            }
        }
        this.log.fine(String.format("Found handlers %s for exception type %s, qualifiers %s", returningHandlers, exceptionClass, handlerQualifiers));
        return Collections.unmodifiableCollection((Collection<? extends HandlerMethod<? extends Throwable>>)returningHandlers);
    }
}
