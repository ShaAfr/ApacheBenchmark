// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exclude.extension;

import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.net.URL;
import org.apache.deltaspike.core.api.interpreter.ExpressionInterpreter;
import org.apache.deltaspike.core.impl.interpreter.PropertyExpressionInterpreter;
import java.util.ArrayList;
import java.lang.reflect.Method;
import javax.enterprise.util.Nonbinding;
import java.util.List;
import org.apache.deltaspike.core.util.metadata.builder.AnnotatedTypeBuilder;
import java.util.Collection;
import java.util.Arrays;
import org.apache.deltaspike.core.util.ClassUtils;
import java.util.HashSet;
import java.util.Set;
import javax.enterprise.inject.Alternative;
import java.lang.reflect.Modifier;
import org.apache.deltaspike.core.api.exclude.Exclude;
import org.apache.deltaspike.core.api.projectstage.ProjectStage;
import javax.enterprise.inject.spi.ProcessAnnotatedType;
import org.apache.deltaspike.core.util.ProjectStageProducer;
import javax.enterprise.inject.spi.AfterDeploymentValidation;
import java.util.Iterator;
import org.apache.deltaspike.core.impl.util.AnnotationInstanceUtils;
import org.apache.deltaspike.core.api.config.base.CoreBaseConfig;
import java.util.logging.Level;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.impl.exclude.GlobalAlternative;
import org.apache.deltaspike.core.impl.exclude.CustomProjectStageBeanFilter;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import java.util.HashMap;
import java.lang.annotation.Annotation;
import java.util.Map;
import java.util.logging.Logger;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import javax.enterprise.inject.spi.Extension;

public class ExcludeExtension implements Extension, Deactivatable
{
    private static final String GLOBAL_ALTERNATIVES = "globalAlternatives.";
    private static final Logger LOG;
    private boolean isActivated;
    private boolean isGlobalAlternativeActivated;
    private boolean isCustomProjectStageBeanFilterActivated;
    private Map<String, String> globalAlternatives;
    private Annotation priorityAnnotationInstance;
    
    public ExcludeExtension() {
        this.isActivated = true;
        this.isGlobalAlternativeActivated = true;
        this.isCustomProjectStageBeanFilterActivated = true;
        this.globalAlternatives = new HashMap<String, String>();
    }
    
    protected void init(@Observes final BeforeBeanDiscovery beforeBeanDiscovery, final BeanManager beanManager) {
        this.isActivated = ClassDeactivationUtils.isActivated((Class)this.getClass());
        this.isCustomProjectStageBeanFilterActivated = ClassDeactivationUtils.isActivated((Class)CustomProjectStageBeanFilter.class);
        this.isGlobalAlternativeActivated = ClassDeactivationUtils.isActivated((Class)GlobalAlternative.class);
        if (this.isGlobalAlternativeActivated) {
            final Map<String, String> allProperties = (Map<String, String>)ConfigResolver.getAllProperties();
            for (final Map.Entry<String, String> property : allProperties.entrySet()) {
                if (property.getKey().startsWith("globalAlternatives.")) {
                    final String interfaceName = property.getKey().substring("globalAlternatives.".length());
                    final String implementation = property.getValue();
                    if (ExcludeExtension.LOG.isLoggable(Level.FINE)) {
                        ExcludeExtension.LOG.fine("Enabling global alternative for interface " + interfaceName + ": " + implementation);
                    }
                    this.globalAlternatives.put(interfaceName, implementation);
                }
            }
            if (this.globalAlternatives.isEmpty()) {
                this.isGlobalAlternativeActivated = false;
            }
            if (this.isGlobalAlternativeActivated) {
                final int priorityValue = CoreBaseConfig.InterceptorCustomization.PRIORITY;
                this.priorityAnnotationInstance = AnnotationInstanceUtils.getPriorityAnnotationInstance(priorityValue);
            }
        }
    }
    
    protected void initProjectStage(@Observes final AfterDeploymentValidation afterDeploymentValidation) {
        ProjectStageProducer.getInstance();
    }
    
    protected void vetoBeans(@Observes final ProcessAnnotatedType processAnnotatedType, final BeanManager beanManager) {
        if (this.isGlobalAlternativeActivated) {
            this.activateGlobalAlternatives(processAnnotatedType, beanManager);
        }
        if (this.isCustomProjectStageBeanFilterActivated) {
            this.vetoCustomProjectStageBeans(processAnnotatedType);
        }
        if (!this.isActivated) {
            return;
        }
        final ProjectStage projectStage = ProjectStageProducer.getInstance().getProjectStage();
        final Exclude exclude = this.extractExcludeAnnotation(processAnnotatedType.getAnnotatedType().getJavaClass());
        if (exclude == null) {
            return;
        }
        if (!this.evalExcludeWithoutCondition(processAnnotatedType, exclude)) {
            return;
        }
        if (!this.evalExcludeInProjectStage(processAnnotatedType, exclude, projectStage)) {
            return;
        }
        if (!this.evalExcludeNotInProjectStage(processAnnotatedType, exclude, projectStage)) {
            return;
        }
        this.evalExcludeWithExpression(processAnnotatedType, exclude);
    }
    
    protected Exclude extractExcludeAnnotation(Class<?> currentClass) {
        Exclude result = currentClass.getAnnotation(Exclude.class);
        if (result != null) {
            return result;
        }
        for (currentClass = currentClass.getSuperclass(); !Object.class.equals(currentClass) && currentClass != null; currentClass = currentClass.getSuperclass()) {
            if (Modifier.isAbstract(currentClass.getModifiers())) {
                result = currentClass.getAnnotation(Exclude.class);
            }
            if (result != null) {
                return result;
            }
        }
        return null;
    }
    
    protected void vetoCustomProjectStageBeans(final ProcessAnnotatedType processAnnotatedType) {
        if (ProjectStage.class.isAssignableFrom(processAnnotatedType.getAnnotatedType().getJavaClass())) {
            processAnnotatedType.veto();
        }
    }
    
    private void activateGlobalAlternatives(final ProcessAnnotatedType processAnnotatedType, final BeanManager beanManager) {
        final Class<Object> currentBean = (Class<Object>)processAnnotatedType.getAnnotatedType().getJavaClass();
        if (currentBean.isInterface()) {
            return;
        }
        final Set<Class> beanBaseTypes = this.resolveBeanTypes(currentBean);
        final boolean isAlternativeBeanImplementation = currentBean.isAnnotationPresent((Class<? extends Annotation>)Alternative.class);
        final List<Annotation> qualifiersOfCurrentBean = this.resolveQualifiers(processAnnotatedType.getAnnotatedType().getAnnotations(), beanManager);
        for (final Class currentType : beanBaseTypes) {
            final Set<Annotation> alternativeBeanAnnotations = new HashSet<Annotation>();
            final String configuredBeanName = this.globalAlternatives.get(currentType.getName());
            if (configuredBeanName != null && configuredBeanName.length() > 0) {
                final Class<Object> alternativeBeanClass = (Class<Object>)ClassUtils.tryToLoadClassForName(configuredBeanName);
                if (alternativeBeanClass == null) {
                    throw new IllegalStateException("Can't find class " + configuredBeanName + " which is configured for " + currentType.getName());
                }
                if (!alternativeBeanClass.isAnnotationPresent((Class<? extends Annotation>)Alternative.class)) {
                    continue;
                }
                alternativeBeanAnnotations.addAll(Arrays.asList(alternativeBeanClass.getAnnotations()));
                final List<Annotation> qualifiersOfConfiguredBean = this.resolveQualifiers(alternativeBeanAnnotations, beanManager);
                if (!this.doQualifiersMatch(qualifiersOfCurrentBean, qualifiersOfConfiguredBean)) {
                    continue;
                }
                if (isAlternativeBeanImplementation && alternativeBeanClass.equals(currentBean)) {
                    ExcludeExtension.LOG.info(processAnnotatedType.getAnnotatedType().getJavaClass().getName() + " is configured as global-alternative");
                    if (this.priorityAnnotationInstance == null) {
                        final AnnotatedTypeBuilder<Object> annotatedTypeBuilder = (AnnotatedTypeBuilder<Object>)new AnnotatedTypeBuilder().readFromType(processAnnotatedType.getAnnotatedType());
                        annotatedTypeBuilder.removeFromClass((Class)Alternative.class);
                        processAnnotatedType.setAnnotatedType(annotatedTypeBuilder.create());
                        return;
                    }
                    final AnnotatedTypeBuilder<Object> annotatedTypeBuilder = (AnnotatedTypeBuilder<Object>)new AnnotatedTypeBuilder().readFromType(processAnnotatedType.getAnnotatedType());
                    annotatedTypeBuilder.addToClass(this.priorityAnnotationInstance);
                    processAnnotatedType.setAnnotatedType(annotatedTypeBuilder.create());
                }
                else {
                    if (this.priorityAnnotationInstance == null) {
                        processAnnotatedType.veto();
                        return;
                    }
                    continue;
                }
            }
        }
    }
    
    private boolean doQualifiersMatch(final List<Annotation> qualifiersOfCurrentBean, final List<Annotation> qualifiersOfConfiguredBean) {
        if (qualifiersOfCurrentBean.size() != qualifiersOfConfiguredBean.size()) {
            return false;
        }
        int matchingQualifiers = 0;
        for (final Annotation currentQualifier : qualifiersOfCurrentBean) {
            for (final Annotation qualifierConfiguredBean : qualifiersOfConfiguredBean) {
                if (this.doesQualifierMatch(currentQualifier, qualifierConfiguredBean)) {
                    ++matchingQualifiers;
                    break;
                }
            }
        }
        return qualifiersOfConfiguredBean.size() == matchingQualifiers;
    }
    
    private boolean doesQualifierMatch(final Annotation currentQualifier, final Annotation qualifierConfiguredBean) {
        if (!currentQualifier.annotationType().equals(qualifierConfiguredBean.annotationType())) {
            return false;
        }
        for (final Method currentMethod : currentQualifier.annotationType().getDeclaredMethods()) {
            if (!currentMethod.isAnnotationPresent((Class<? extends Annotation>)Nonbinding.class)) {
                try {
                    currentMethod.setAccessible(true);
                    final Object currentValue = currentMethod.invoke(currentQualifier, new Object[0]);
                    final Object valueOfQualifierConfiguredBean = currentMethod.invoke(qualifierConfiguredBean, new Object[0]);
                    if (!currentValue.equals(valueOfQualifierConfiguredBean)) {
                        return false;
                    }
                }
                catch (Exception e) {
                    throw new IllegalStateException("Can't compare " + currentQualifier.annotationType().getName() + " with " + qualifierConfiguredBean.annotationType().getName(), e);
                }
            }
        }
        return true;
    }
    
    private List<Annotation> resolveQualifiers(final Set<Annotation> annotations, final BeanManager beanManager) {
        final List<Annotation> result = new ArrayList<Annotation>();
        for (final Annotation annotation : annotations) {
            if (beanManager.isQualifier((Class)annotation.annotationType())) {
                result.add(annotation);
            }
        }
        return result;
    }
    
    private Set<Class> resolveBeanTypes(final Class beanClass) {
        final Set<Class> result = new HashSet<Class>();
        for (Class<?> currentClass = (Class<?>)beanClass; currentClass != null && !Object.class.getName().equals(currentClass.getName()); currentClass = currentClass.getSuperclass()) {
            result.add(currentClass);
            for (final Class interfaceClass : currentClass.getInterfaces()) {
                if (!interfaceClass.getName().startsWith("java.")) {
                    if (!interfaceClass.getName().startsWith("javax.")) {
                        result.addAll(this.resolveBeanTypes(interfaceClass));
                    }
                }
            }
        }
        return result;
    }
    
    private boolean evalExcludeWithoutCondition(final ProcessAnnotatedType processAnnotatedType, final Exclude exclude) {
        if (exclude.ifProjectStage().length == 0 && exclude.exceptIfProjectStage().length == 0 && "".equals(exclude.onExpression())) {
            this.veto(processAnnotatedType, "Stateless");
            return false;
        }
        return true;
    }
    
    private boolean evalExcludeInProjectStage(final ProcessAnnotatedType processAnnotatedType, final Exclude exclude, final ProjectStage currentlyConfiguredProjectStage) {
        final Class<? extends ProjectStage>[] activatedIn = (Class<? extends ProjectStage>[])exclude.ifProjectStage();
        if (activatedIn.length == 0) {
            return true;
        }
        if (this.isInProjectStage(activatedIn, currentlyConfiguredProjectStage)) {
            this.veto(processAnnotatedType, "IfProjectState");
            return false;
        }
        return true;
    }
    
    private boolean evalExcludeNotInProjectStage(final ProcessAnnotatedType processAnnotatedType, final Exclude exclude, final ProjectStage currentlyConfiguredProjectStage) {
        final Class<? extends ProjectStage>[] notIn = (Class<? extends ProjectStage>[])exclude.exceptIfProjectStage();
        if (notIn.length == 0) {
            return true;
        }
        if (!this.isInProjectStage(notIn, currentlyConfiguredProjectStage)) {
            this.veto(processAnnotatedType, "ExceptIfProjectState");
            return false;
        }
        return true;
    }
    
    private void evalExcludeWithExpression(final ProcessAnnotatedType processAnnotatedType, final Exclude exclude) {
        if ("".equals(exclude.onExpression())) {
            return;
        }
        if (this.isDeactivated(exclude, PropertyExpressionInterpreter.class)) {
            this.veto(processAnnotatedType, "Expression");
        }
    }
    
    private boolean isInProjectStage(final Class<? extends ProjectStage>[] activatedIn, final ProjectStage currentlyConfiguredProjectStage) {
        if (activatedIn != null && activatedIn.length > 0) {
            for (final Class<? extends ProjectStage> activated : activatedIn) {
                if (currentlyConfiguredProjectStage.getClass().equals(activated)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean isDeactivated(final Exclude exclude, final Class defaultExpressionInterpreterClass) {
        final String expressions = exclude.onExpression();
        Class<? extends ExpressionInterpreter> interpreterClass = (Class<? extends ExpressionInterpreter>)exclude.interpretedBy();
        if (interpreterClass.equals(ExpressionInterpreter.class)) {
            interpreterClass = (Class<? extends ExpressionInterpreter>)defaultExpressionInterpreterClass;
        }
        final ExpressionInterpreter<String, Boolean> expressionInterpreter = (ExpressionInterpreter<String, Boolean>)ClassUtils.tryToInstantiateClass((Class)interpreterClass);
        if (expressionInterpreter == null) {
            if (ExcludeExtension.LOG.isLoggable(Level.WARNING)) {
                ExcludeExtension.LOG.warning("can't instantiate " + interpreterClass.getClass().getName());
            }
            return true;
        }
        return (boolean)expressionInterpreter.evaluate((Object)expressions);
    }
    
    private void veto(final ProcessAnnotatedType processAnnotatedType, final String vetoType) {
        processAnnotatedType.veto();
        ExcludeExtension.LOG.finer(vetoType + " based veto for bean with type: " + processAnnotatedType.getAnnotatedType().getJavaClass());
    }
    
    private static String getJarVersion(final Class targetClass) {
        final String manifestFileLocation = getManifestFileLocationOfClass(targetClass);
        try {
            return new Manifest(new URL(manifestFileLocation).openStream()).getMainAttributes().getValue(Attributes.Name.SPECIFICATION_VERSION);
        }
        catch (Exception e) {
            return null;
        }
    }
    
    private static String getManifestFileLocationOfClass(final Class targetClass) {
        String manifestFileLocation;
        try {
            manifestFileLocation = getManifestLocation(targetClass);
        }
        catch (Exception e) {
            manifestFileLocation = getManifestLocation(targetClass.getSuperclass());
        }
        return manifestFileLocation;
    }
    
    private static String getManifestLocation(final Class targetClass) {
        final String classFilePath = targetClass.getCanonicalName().replace('.', '/') + ".class";
        final String manifestFilePath = "/META-INF/MANIFEST.MF";
        final String classLocation = targetClass.getResource(targetClass.getSimpleName() + ".class").toString();
        return classLocation.substring(0, classLocation.indexOf(classFilePath) - 1) + manifestFilePath;
    }
    
    static {
        LOG = Logger.getLogger(ExcludeExtension.class.getName());
    }
}
