// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.window;

import org.apache.deltaspike.core.util.context.ContextualStorage;
import javax.enterprise.inject.spi.BeanManager;
import javax.annotation.PostConstruct;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import org.apache.deltaspike.core.util.ProxyUtils;
import javax.inject.Inject;
import org.apache.deltaspike.core.spi.scope.window.WindowContextQuotaHandler;
import javax.enterprise.context.SessionScoped;
import org.apache.deltaspike.core.impl.scope.AbstractBeanHolder;

@SessionScoped
public class WindowBeanHolder extends AbstractBeanHolder<String>
{
    private static final long serialVersionUID = 6313493410718133308L;
    @Inject
    private WindowContextQuotaHandler windowContextQuotaHandler;
    private boolean windowContextQuotaHandlerEnabled;
    
    @PostConstruct
    protected void init() {
        final Class<? extends Deactivatable> windowContextQuotaHandlerClass = (Class<? extends Deactivatable>)ProxyUtils.getUnproxiedClass((Class)this.windowContextQuotaHandler.getClass());
        this.windowContextQuotaHandlerEnabled = ClassDeactivationUtils.isActivated((Class)windowContextQuotaHandlerClass);
    }
    
    @Override
    public ContextualStorage getContextualStorage(final BeanManager beanManager, final String key, final boolean createIfNotExist) {
        final ContextualStorage result = super.getContextualStorage(beanManager, key, createIfNotExist);
        if (this.windowContextQuotaHandlerEnabled) {
            this.windowContextQuotaHandler.checkWindowContextQuota(key);
        }
        return result;
    }
}
