// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.throttling;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.inject.Inject;
import org.apache.deltaspike.core.spi.throttling.ThrottledStrategy;
import javax.interceptor.Interceptor;
import org.apache.deltaspike.core.api.throttling.Throttled;
import java.io.Serializable;

@Throttled
@Interceptor
public class ThrottledInterceptor implements Serializable
{
    @Inject
    private ThrottledStrategy throttledStrategy;
    
    @AroundInvoke
    public Object invoke(final InvocationContext ic) throws Exception {
        return this.throttledStrategy.execute(ic);
    }
}
