// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import java.util.ArrayList;
import org.apache.deltaspike.core.api.message.LocaleResolver;
import org.apache.deltaspike.core.api.message.MessageInterpolator;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import org.apache.deltaspike.core.api.literal.AnyLiteral;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.util.ClassUtils;
import org.apache.deltaspike.core.api.message.MessageResolver;
import org.apache.deltaspike.core.api.message.Message;
import java.util.List;
import org.apache.deltaspike.core.api.message.MessageContextConfig;
import org.apache.deltaspike.core.api.message.MessageTemplate;
import java.lang.reflect.Method;
import javax.inject.Inject;
import org.apache.deltaspike.core.api.message.MessageContext;
import javax.enterprise.inject.Typed;
import javax.enterprise.context.Dependent;
import java.io.Serializable;
import java.lang.reflect.InvocationHandler;

@Dependent
@Typed({ MessageBundleInvocationHandler.class })
public class MessageBundleInvocationHandler implements InvocationHandler, Serializable
{
    private static final long serialVersionUID = -8980912335543392357L;
    @Inject
    private MessageContext baseMessageContext;
    
    public MessageBundleInvocationHandler() {
        this.baseMessageContext = null;
    }
    
    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        if (method.getDeclaringClass().equals(Object.class)) {
            if ("hashCode".equals(method.getName())) {
                return proxy.getClass().hashCode();
            }
            if ("toString".equals(method.getName())) {
                return proxy.getClass().toString();
            }
            if ("equals".equals(method.getName())) {
                return proxy.getClass().equals(args[0].getClass());
            }
            return null;
        }
        else {
            final MessageTemplate messageTemplate = method.getAnnotation(MessageTemplate.class);
            String messageTemplateValue;
            if (messageTemplate != null) {
                messageTemplateValue = messageTemplate.value();
            }
            else {
                messageTemplateValue = "{" + method.getName() + "}";
            }
            MessageContext messageContext = this.resolveMessageContextFromArguments(args);
            final List<Serializable> arguments = this.resolveMessageArguments(args);
            if (messageContext == null) {
                messageContext = this.baseMessageContext.clone();
                final MessageContextConfig messageContextConfig = method.getDeclaringClass().getAnnotation(MessageContextConfig.class);
                if (messageContextConfig != null) {
                    this.applyMessageContextConfig(messageContext, messageContextConfig);
                }
            }
            final String messageBundleName = method.getDeclaringClass().getName();
            final Message message = messageContext.messageSource(new String[] { messageBundleName }).message().template(messageTemplateValue).argument((Serializable[])arguments.toArray(new Serializable[arguments.size()]));
            if (String.class.isAssignableFrom(method.getReturnType())) {
                return message.toString();
            }
            return message;
        }
    }
    
    private void applyMessageContextConfig(final MessageContext messageContext, final MessageContextConfig messageContextConfig) {
        if (!MessageResolver.class.equals(messageContextConfig.messageResolver())) {
            final Class<? extends MessageResolver> messageResolverClass = (Class<? extends MessageResolver>)ClassUtils.tryToLoadClassForName(messageContextConfig.messageResolver().getName());
            messageContext.messageResolver((MessageResolver)BeanProvider.getContextualReference((Class)messageResolverClass, new Annotation[] { (Annotation)new AnyLiteral() }));
        }
        if (!MessageInterpolator.class.equals(messageContextConfig.messageInterpolator())) {
            final Class<? extends MessageInterpolator> messageInterpolatorClass = (Class<? extends MessageInterpolator>)ClassUtils.tryToLoadClassForName(messageContextConfig.messageInterpolator().getName());
            messageContext.messageInterpolator((MessageInterpolator)BeanProvider.getContextualReference((Class)messageInterpolatorClass, new Annotation[] { (Annotation)new AnyLiteral() }));
        }
        if (!LocaleResolver.class.equals(messageContextConfig.localeResolver())) {
            final Class<? extends LocaleResolver> localeResolverClass = (Class<? extends LocaleResolver>)ClassUtils.tryToLoadClassForName(messageContextConfig.localeResolver().getName());
            messageContext.localeResolver((LocaleResolver)BeanProvider.getContextualReference((Class)localeResolverClass, new Annotation[] { (Annotation)new AnyLiteral() }));
        }
        final String[] messageSources = messageContextConfig.messageSource();
        messageContext.messageSource(messageSources);
    }
    
    private List<Serializable> resolveMessageArguments(final Object[] args) {
        final List<Serializable> arguments = new ArrayList<Serializable>();
        if (args != null && args.length > 0) {
            for (int i = 0; i < args.length; ++i) {
                final Object arg = args[i];
                if (i != 0 || arg == null || !MessageContext.class.isAssignableFrom(arg.getClass())) {
                    if (arg == null) {
                        arguments.add("'null'");
                    }
                    else if (arg instanceof Serializable) {
                        arguments.add((Serializable)arg);
                    }
                    else {
                        arguments.add(arg.toString());
                    }
                }
            }
        }
        return arguments;
    }
    
    private MessageContext resolveMessageContextFromArguments(final Object[] args) {
        if (args != null && args.length > 0 && args[0] != null && MessageContext.class.isAssignableFrom(args[0].getClass())) {
            return (MessageContext)args[0];
        }
        return null;
    }
}
