// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.util.HashMap;
import java.util.Map;
import org.apache.deltaspike.core.impl.util.JndiUtils;
import javax.enterprise.inject.Typed;

@Typed
class LocalJndiConfigSource extends BaseConfigSource
{
    private static final String BASE_NAME = "java:comp/env/deltaspike/";
    
    public LocalJndiConfigSource() {
        this.initOrdinal(200);
    }
    
    public String getPropertyValue(final String key) {
        try {
            return JndiUtils.lookup(this.getJndiKey(key), (Class<? extends String>)String.class);
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    private String getJndiKey(final String key) {
        if (key.startsWith("java:comp/env")) {
            return key;
        }
        return "java:comp/env/deltaspike/" + key;
    }
    
    public Map<String, String> getProperties() {
        final Map<String, String> result = new HashMap<String, String>();
        result.putAll(JndiUtils.list("java:comp/env/deltaspike/", (Class<? extends String>)String.class));
        result.putAll(JndiUtils.list("java:comp/env", (Class<? extends String>)String.class));
        return result;
    }
    
    public String getConfigName() {
        return "java:comp/env/deltaspike/";
    }
    
    public boolean isScannable() {
        return false;
    }
}
