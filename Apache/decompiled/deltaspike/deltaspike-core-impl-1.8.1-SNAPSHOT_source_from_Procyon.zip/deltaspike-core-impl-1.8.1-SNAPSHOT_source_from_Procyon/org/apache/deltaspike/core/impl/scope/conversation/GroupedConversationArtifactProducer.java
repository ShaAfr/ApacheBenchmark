// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.conversation;

import javax.enterprise.context.spi.Contextual;
import org.apache.deltaspike.core.impl.util.ConversationUtils;
import org.apache.deltaspike.core.api.scope.GroupedConversation;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import org.apache.deltaspike.core.spi.scope.conversation.GroupedConversationManager;
import javax.inject.Inject;
import org.apache.deltaspike.core.impl.scope.DeltaSpikeContextExtension;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class GroupedConversationArtifactProducer
{
    @Inject
    private DeltaSpikeContextExtension deltaSpikeContextExtension;
    
    @Produces
    @Dependent
    public GroupedConversationManager getGroupedConversationManager() {
        return (GroupedConversationManager)new InjectableGroupedConversationManager((GroupedConversationManager)this.deltaSpikeContextExtension.getConversationContext());
    }
    
    @Produces
    @Dependent
    public GroupedConversation getGroupedConversation(final InjectionPoint injectionPoint, final BeanManager beanManager) {
        final ConversationKey conversationKey = ConversationUtils.convertToConversationKey((Contextual<?>)injectionPoint.getBean(), beanManager);
        return (GroupedConversation)new InjectableGroupedConversation(conversationKey, this.getGroupedConversationManager());
    }
}
