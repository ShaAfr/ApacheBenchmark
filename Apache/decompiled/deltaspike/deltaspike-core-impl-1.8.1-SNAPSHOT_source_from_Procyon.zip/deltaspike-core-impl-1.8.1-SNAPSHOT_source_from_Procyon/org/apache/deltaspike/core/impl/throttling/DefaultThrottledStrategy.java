// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.throttling;

import javax.interceptor.InvocationContext;
import javax.inject.Inject;
import javax.enterprise.context.Dependent;
import org.apache.deltaspike.core.spi.throttling.ThrottledStrategy;

@Dependent
public class DefaultThrottledStrategy implements ThrottledStrategy
{
    @Inject
    private InvokerStorage metadata;
    
    public Object execute(final InvocationContext ic) throws Exception {
        return this.metadata.getOrCreateInvoker(ic).invoke(ic);
    }
}
