// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.conversation;

import java.util.Set;
import org.apache.deltaspike.core.util.context.ContextualStorage;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.impl.scope.DeltaSpikeContextExtension;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.spi.scope.conversation.GroupedConversationManager;

@Typed
class InjectableGroupedConversationManager implements GroupedConversationManager
{
    private transient volatile GroupedConversationManager conversationManager;
    
    public InjectableGroupedConversationManager(final GroupedConversationManager conversationManager) {
        this.conversationManager = conversationManager;
    }
    
    private GroupedConversationManager getConversationManager() {
        if (this.conversationManager == null) {
            this.conversationManager = (GroupedConversationManager)((DeltaSpikeContextExtension)BeanProvider.getContextualReference((Class)DeltaSpikeContextExtension.class, new Annotation[0])).getConversationContext();
        }
        return this.conversationManager;
    }
    
    public ContextualStorage closeConversation(final Class<?> conversationGroup, final Annotation... qualifiers) {
        return this.getConversationManager().closeConversation((Class)conversationGroup, qualifiers);
    }
    
    public Set<ContextualStorage> closeConversationGroup(final Class<?> conversationGroup) {
        return (Set<ContextualStorage>)this.getConversationManager().closeConversationGroup((Class)conversationGroup);
    }
    
    public void closeConversations() {
        this.getConversationManager().closeConversations();
    }
}
