// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import java.util.Arrays;
import java.util.Locale;
import org.apache.deltaspike.core.api.message.MessageInterpolator;
import org.apache.deltaspike.core.api.message.MessageResolver;
import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;
import org.apache.deltaspike.core.api.message.MessageContext;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.api.message.Message;

@Typed
public class DefaultMessage implements Message
{
    private String messageTemplate;
    private List<Serializable> arguments;
    private MessageContext messageContext;
    
    public DefaultMessage(final MessageContext messageContext) {
        this.arguments = new ArrayList<Serializable>();
        this.reset();
        this.messageContext = messageContext;
    }
    
    protected void reset() {
        this.messageTemplate = null;
        this.arguments = new ArrayList<Serializable>();
    }
    
    public Message argument(final Serializable... arguments) {
        if (arguments != null) {
            Collections.addAll(this.arguments, arguments);
        }
        return (Message)this;
    }
    
    public Message template(final String messageTemplate) {
        this.messageTemplate = messageTemplate;
        return (Message)this;
    }
    
    public String getTemplate() {
        return this.messageTemplate;
    }
    
    public Serializable[] getArguments() {
        return this.arguments.toArray(new Serializable[this.arguments.size()]);
    }
    
    @Override
    public String toString() {
        return this.toString((String)null);
    }
    
    public String toString(final String category) {
        String template = this.getTemplate();
        if (template == null) {
            return "";
        }
        String ret = template;
        final MessageResolver messageResolver = this.messageContext.getMessageResolver();
        if (messageResolver != null) {
            String resolvedTemplate = messageResolver.getMessage(this.messageContext, template, category);
            if (resolvedTemplate == null) {
                resolvedTemplate = this.markAsUnresolved(template);
            }
            ret = resolvedTemplate;
            template = resolvedTemplate;
        }
        final MessageInterpolator messageInterpolator = this.messageContext.getMessageInterpolator();
        if (messageInterpolator != null) {
            final Locale locale = this.messageContext.getLocale();
            ret = messageInterpolator.interpolate(template, this.getArguments(), locale);
        }
        return ret;
    }
    
    private String markAsUnresolved(String template) {
        if (this.messageTemplate.startsWith("{") && this.messageTemplate.endsWith("}")) {
            template = this.messageTemplate.substring(1, this.messageTemplate.length() - 1);
        }
        final StringBuilder sb = new StringBuilder("???" + template + "???");
        if (this.getArguments() != null && this.getArguments().length > 0) {
            sb.append(" ").append(Arrays.toString(this.getArguments()));
        }
        return sb.toString();
    }
    
    public String toString(final MessageContext messageContext) {
        return this.toString(messageContext, null);
    }
    
    public String toString(final MessageContext messageContext, final String category) {
        return messageContext.message().template(this.getTemplate()).argument(this.getArguments()).toString(category);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Message)) {
            return false;
        }
        final Message other = (Message)o;
        if (this.getTemplate() == null && other.getTemplate() != null) {
            return false;
        }
        if (this.getTemplate() != null && !this.getTemplate().equals(other.getTemplate())) {
            return false;
        }
        if (this.arguments != null) {
            if (Arrays.equals(this.arguments.toArray(), other.getArguments())) {
                return true;
            }
        }
        else if (other.getArguments() == null) {
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        int result = this.getTemplate().hashCode();
        result = 31 * result + ((this.arguments != null) ? this.arguments.hashCode() : 0);
        return result;
    }
    
    public Message argumentArray(final Serializable[] arguments) {
        if (arguments != null) {
            return this.argument(Arrays.asList(arguments));
        }
        return (Message)this;
    }
    
    public Message argument(final Collection<Serializable> arguments) {
        if (arguments != null) {
            this.arguments.addAll(arguments);
        }
        return (Message)this;
    }
}
