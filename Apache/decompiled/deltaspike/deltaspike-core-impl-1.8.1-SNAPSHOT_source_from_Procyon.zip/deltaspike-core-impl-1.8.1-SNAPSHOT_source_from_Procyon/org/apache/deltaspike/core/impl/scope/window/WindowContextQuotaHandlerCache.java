// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.window;

import javax.annotation.PreDestroy;
import javax.inject.Inject;
import org.apache.deltaspike.core.spi.scope.window.WindowContext;
import javax.enterprise.context.RequestScoped;
import java.io.Serializable;

@RequestScoped
public class WindowContextQuotaHandlerCache implements Serializable
{
    private String checkedWindowId;
    private String windowIdToRemove;
    @Inject
    private WindowContext windowContext;
    
    public boolean cacheWindowId(final String currentWindowId) {
        final boolean result = currentWindowId.equals(this.checkedWindowId);
        this.checkedWindowId = currentWindowId;
        return result;
    }
    
    public void setWindowIdToDestroy(final String windowIdToRemove) {
        this.windowIdToRemove = windowIdToRemove;
    }
    
    @PreDestroy
    public void cleanup() {
        if (this.windowIdToRemove != null) {
            this.windowContext.closeWindow(this.windowIdToRemove);
        }
    }
}
