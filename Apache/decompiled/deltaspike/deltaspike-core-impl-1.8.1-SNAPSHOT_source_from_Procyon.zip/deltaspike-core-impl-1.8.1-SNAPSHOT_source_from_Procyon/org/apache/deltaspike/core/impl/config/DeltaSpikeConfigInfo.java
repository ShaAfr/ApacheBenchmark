// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.util.Map;
import java.util.Iterator;
import javax.management.openmbean.OpenDataException;
import javax.management.openmbean.CompositeData;
import javax.management.openmbean.CompositeDataSupport;
import javax.management.openmbean.TabularDataSupport;
import javax.management.openmbean.TabularType;
import javax.management.openmbean.CompositeType;
import javax.management.openmbean.SimpleType;
import javax.management.openmbean.OpenType;
import javax.management.openmbean.TabularData;
import java.util.List;
import org.apache.deltaspike.core.spi.config.ConfigSource;
import java.util.ArrayList;
import org.apache.deltaspike.core.api.config.ConfigResolver;

public class DeltaSpikeConfigInfo implements DeltaSpikeConfigInfoMBean
{
    private final ClassLoader appConfigClassLoader;
    
    public DeltaSpikeConfigInfo(final ClassLoader appConfigClassLoader) {
        this.appConfigClassLoader = appConfigClassLoader;
    }
    
    @Override
    public String[] getConfigSourcesAsString() {
        final ClassLoader originalCl = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(this.appConfigClassLoader);
            final ConfigSource[] configSources = ConfigResolver.getConfigSources();
            final List<String> configSourceInfo = new ArrayList<String>();
            for (final ConfigSource configSource : configSources) {
                configSourceInfo.add(Integer.toString(configSource.getOrdinal()) + " - " + configSource.getConfigName());
            }
            return configSourceInfo.toArray(new String[configSourceInfo.size()]);
        }
        finally {
            Thread.currentThread().setContextClassLoader(originalCl);
        }
    }
    
    @Override
    public String[] getConfigEntriesAsString() {
        final ClassLoader originalCl = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(this.appConfigClassLoader);
            final List<ConfigEntry> configEntries = this.calculateConfigEntries();
            final String[] configArray = new String[configEntries.size()];
            for (int i = 0; i < configEntries.size(); ++i) {
                final ConfigEntry configEntry = configEntries.get(i);
                configArray[i] = configEntry.getKey() + " = " + configEntry.getValue() + " - picked up from: " + configEntry.getFromConfigSource();
            }
            return configArray;
        }
        finally {
            Thread.currentThread().setContextClassLoader(originalCl);
        }
    }
    
    @Override
    public TabularData getConfigEntries() {
        final ClassLoader originalCl = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(this.appConfigClassLoader);
            final List<ConfigEntry> configEntries = this.calculateConfigEntries();
            final String[] configArray = new String[configEntries.size()];
            for (int i = 0; i < configEntries.size(); ++i) {
                final ConfigEntry configEntry = configEntries.get(i);
                configArray[i] = configEntry.getKey() + " = " + configEntry.getValue() + " - picked up from: " + configEntry.getFromConfigSource();
            }
            final String typeName = "ConfigEntries";
            final OpenType<?>[] types = (OpenType<?>[])new OpenType[] { SimpleType.STRING, SimpleType.STRING, SimpleType.STRING };
            final String[] keys = { "Key", "Value", "fromConfigSource" };
            final CompositeType ct = new CompositeType(typeName, typeName, keys, keys, types);
            final TabularType type = new TabularType(typeName, typeName, ct, keys);
            final TabularDataSupport configEntryInfo = new TabularDataSupport(type);
            final ConfigSource[] configSources = ConfigResolver.getConfigSources();
            for (final ConfigEntry configEntry2 : configEntries) {
                configEntryInfo.put(new CompositeDataSupport(ct, keys, new Object[] { configEntry2.getKey(), configEntry2.getValue(), configEntry2.getFromConfigSource() }));
            }
            return configEntryInfo;
        }
        catch (OpenDataException e) {
            throw new RuntimeException(e);
        }
        finally {
            Thread.currentThread().setContextClassLoader(originalCl);
        }
    }
    
    @Override
    public TabularData getConfigSources() {
        final ClassLoader originalCl = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(this.appConfigClassLoader);
            final String typeName = "ConfigSources";
            final OpenType<?>[] types = (OpenType<?>[])new OpenType[] { SimpleType.INTEGER, SimpleType.STRING };
            final String[] keys = { "Ordinal", "ConfigSource" };
            final CompositeType ct = new CompositeType(typeName, typeName, keys, keys, types);
            final TabularType type = new TabularType(typeName, typeName, ct, keys);
            final TabularDataSupport configSourceInfo = new TabularDataSupport(type);
            final ConfigSource[] configSources2;
            final ConfigSource[] configSources = configSources2 = ConfigResolver.getConfigSources();
            for (final ConfigSource configSource : configSources2) {
                configSourceInfo.put(new CompositeDataSupport(ct, keys, new Object[] { configSource.getOrdinal(), configSource.getConfigName() }));
            }
            return configSourceInfo;
        }
        catch (OpenDataException e) {
            throw new RuntimeException(e);
        }
        finally {
            Thread.currentThread().setContextClassLoader(originalCl);
        }
    }
    
    private List<ConfigEntry> calculateConfigEntries() {
        final Map<String, String> allProperties = (Map<String, String>)ConfigResolver.getAllProperties();
        final List<ConfigEntry> configEntries = new ArrayList<ConfigEntry>(allProperties.size());
        final ConfigSource[] configSources = ConfigResolver.getConfigSources();
        for (final Map.Entry<String, String> configEntry : allProperties.entrySet()) {
            final String key = configEntry.getKey();
            final String value = ConfigResolver.filterConfigValueForLog(key, ConfigResolver.getProjectStageAwarePropertyValue(key));
            final String fromConfigSource = this.getFromConfigSource(configSources, key);
            configEntries.add(new ConfigEntry(key, value, fromConfigSource));
        }
        return configEntries;
    }
    
    private String getFromConfigSource(final ConfigSource[] configSources, final String key) {
        for (final ConfigSource configSource : configSources) {
            if (configSource.getPropertyValue(key) != null) {
                return configSource.getConfigName();
            }
        }
        return null;
    }
    
    private class ConfigEntry
    {
        private final String key;
        private final String value;
        private final String fromConfigSource;
        
        public ConfigEntry(final String key, final String value, final String fromConfigSource) {
            this.key = key;
            this.value = value;
            this.fromConfigSource = fromConfigSource;
        }
        
        public String getKey() {
            return this.key;
        }
        
        public String getValue() {
            return this.value;
        }
        
        public String getFromConfigSource() {
            return this.fromConfigSource;
        }
    }
}
