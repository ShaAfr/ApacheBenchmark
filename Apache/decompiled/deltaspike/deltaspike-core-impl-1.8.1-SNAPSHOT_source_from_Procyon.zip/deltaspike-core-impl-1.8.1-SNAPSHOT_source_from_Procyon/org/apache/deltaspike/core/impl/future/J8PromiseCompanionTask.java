// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.future;

import java.lang.reflect.InvocationTargetException;
import org.apache.deltaspike.core.util.ExceptionUtils;
import java.util.concurrent.Callable;
import java.lang.reflect.Method;

class J8PromiseCompanionTask<T> implements Runnable
{
    private static final Method COMPLETABLE_FUTURE_COMPLETE;
    private static final Method COMPLETABLE_FUTURE_COMPLETE_ERROR;
    private Object dep;
    private Callable<T> fn;
    
    J8PromiseCompanionTask(final Object dep, final Callable<T> fn) {
        this.dep = dep;
        this.fn = fn;
    }
    
    @Override
    public void run() {
        try {
            J8PromiseCompanionTask.COMPLETABLE_FUTURE_COMPLETE.invoke(this.dep, this.fn.call());
        }
        catch (InvocationTargetException e) {
            try {
                J8PromiseCompanionTask.COMPLETABLE_FUTURE_COMPLETE_ERROR.invoke(this.dep, e.getCause());
            }
            catch (IllegalAccessException e2) {
                throw ExceptionUtils.throwAsRuntimeException((Throwable)e2);
            }
            catch (InvocationTargetException e3) {
                throw ExceptionUtils.throwAsRuntimeException(e3.getCause());
            }
        }
        catch (Exception e4) {
            try {
                J8PromiseCompanionTask.COMPLETABLE_FUTURE_COMPLETE_ERROR.invoke(this.dep, e4);
            }
            catch (IllegalAccessException e2) {
                throw ExceptionUtils.throwAsRuntimeException((Throwable)e2);
            }
            catch (InvocationTargetException e3) {
                throw ExceptionUtils.throwAsRuntimeException(e3.getCause());
            }
        }
    }
    
    static {
        Class<?> completableFutureClass = null;
        Method completableFutureComplete = null;
        Method completableFutureCompleteError = null;
        try {
            final ClassLoader classLoader = ClassLoader.getSystemClassLoader();
            completableFutureClass = classLoader.loadClass("java.util.concurrent.CompletableFuture");
            completableFutureComplete = completableFutureClass.getMethod("complete", Object.class);
            completableFutureCompleteError = completableFutureClass.getMethod("completeExceptionally", Throwable.class);
        }
        catch (Exception ex) {}
        COMPLETABLE_FUTURE_COMPLETE = completableFutureComplete;
        COMPLETABLE_FUTURE_COMPLETE_ERROR = completableFutureCompleteError;
    }
}
