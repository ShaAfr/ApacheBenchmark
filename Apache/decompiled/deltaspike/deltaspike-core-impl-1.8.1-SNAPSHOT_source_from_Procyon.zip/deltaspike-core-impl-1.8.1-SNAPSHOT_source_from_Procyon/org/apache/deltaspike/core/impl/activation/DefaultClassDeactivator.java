// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.activation;

import java.util.logging.Level;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import java.util.logging.Logger;
import org.apache.deltaspike.core.spi.activation.ClassDeactivator;

public class DefaultClassDeactivator implements ClassDeactivator
{
    public static final String KEY_PREFIX = "deactivate.";
    private static final Logger LOG;
    
    public Boolean isActivated(final Class<? extends Deactivatable> targetClass) {
        final String key = "deactivate." + targetClass.getName();
        final String value = ConfigResolver.getPropertyValue(key);
        if (value == null) {
            return null;
        }
        if (DefaultClassDeactivator.LOG.isLoggable(Level.FINE)) {
            DefaultClassDeactivator.LOG.log(Level.FINE, "Deactivation setting for {0} found to be {1} based on configuration.", new Object[] { key, value });
        }
        return !Boolean.valueOf(value);
    }
    
    static {
        LOG = Logger.getLogger(DefaultClassDeactivator.class.getName());
    }
}
