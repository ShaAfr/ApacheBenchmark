// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control;

import java.util.Iterator;
import javax.enterprise.context.spi.CreationalContext;
import java.util.List;
import java.util.Collections;
import org.apache.deltaspike.core.api.exception.control.event.ExceptionEvent;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Set;
import java.lang.reflect.Type;
import org.apache.deltaspike.core.api.exception.control.event.ExceptionStackEvent;
import org.apache.deltaspike.core.api.exception.control.HandlerMethod;
import java.util.HashSet;
import javax.enterprise.context.spi.Contextual;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import java.lang.annotation.Annotation;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.Any;
import javax.enterprise.event.Observes;
import org.apache.deltaspike.core.api.exception.control.event.ExceptionToCatchEvent;
import java.util.logging.Logger;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ExceptionHandlerBroadcaster
{
    private static final Logger LOG;
    
    public void executeHandlers(@Observes @Any final ExceptionToCatchEvent exceptionEventEvent, final BeanManager beanManager) throws Throwable {
        ExceptionHandlerBroadcaster.LOG.entering(ExceptionHandlerBroadcaster.class.getName(), "executeHandlers", exceptionEventEvent.getException());
        CreationalContext<Object> creationalContext = null;
        Throwable throwException = null;
        final HandlerMethodStorage handlerMethodStorage = (HandlerMethodStorage)BeanProvider.getContextualReference((Class)HandlerMethodStorage.class, new Annotation[0]);
        try {
            creationalContext = (CreationalContext<Object>)beanManager.createCreationalContext((Contextual)null);
            final Set<HandlerMethod<?>> processedHandlers = new HashSet<HandlerMethod<?>>();
            final ExceptionStackEvent stack = new ExceptionStackEvent(exceptionEventEvent.getException());
            beanManager.fireEvent((Object)stack, new Annotation[0]);
        Label_0078:
            while (stack.getCurrent() != null) {
                final List<HandlerMethod<?>> callbackExceptionEvent = new ArrayList<HandlerMethod<?>>(handlerMethodStorage.getHandlersForException(stack.getCurrent().getClass(), beanManager, exceptionEventEvent.getQualifiers(), true));
                for (final HandlerMethod<?> handler : callbackExceptionEvent) {
                    if (!processedHandlers.contains(handler)) {
                        ExceptionHandlerBroadcaster.LOG.fine(String.format("Notifying handler %s", handler));
                        final DefaultExceptionEvent callbackEvent = new DefaultExceptionEvent(stack, true, exceptionEventEvent.isHandled());
                        handler.notify((ExceptionEvent)callbackEvent, beanManager);
                        ExceptionHandlerBroadcaster.LOG.fine(String.format("Handler %s returned status %s", handler, callbackEvent.getCurrentExceptionHandlingFlow().name()));
                        if (!callbackEvent.isUnmute()) {
                            processedHandlers.add(handler);
                        }
                        switch (callbackEvent.getCurrentExceptionHandlingFlow()) {
                            case HANDLED: {
                                exceptionEventEvent.setHandled(true);
                                return;
                            }
                            case HANDLED_AND_CONTINUE: {
                                exceptionEventEvent.setHandled(true);
                                continue;
                            }
                            case ABORT: {
                                return;
                            }
                            case SKIP_CAUSE: {
                                exceptionEventEvent.setHandled(true);
                                stack.skipCause();
                                continue Label_0078;
                            }
                            case THROW_ORIGINAL: {
                                throw exceptionEventEvent.getException();
                            }
                            case THROW: {
                                throw callbackEvent.getThrowNewException();
                            }
                            default: {
                                throw new IllegalStateException("Unexpected enum type " + callbackEvent.getCurrentExceptionHandlingFlow());
                            }
                        }
                    }
                }
                final Collection<HandlerMethod<? extends Throwable>> handlersForException = handlerMethodStorage.getHandlersForException(stack.getCurrent().getClass(), beanManager, exceptionEventEvent.getQualifiers(), false);
                final List<HandlerMethod<? extends Throwable>> handlerMethods = new ArrayList<HandlerMethod<? extends Throwable>>(handlersForException);
                Collections.reverse(handlerMethods);
                for (final HandlerMethod<?> handler2 : handlerMethods) {
                    if (!processedHandlers.contains(handler2)) {
                        ExceptionHandlerBroadcaster.LOG.fine(String.format("Notifying handler %s", handler2));
                        final DefaultExceptionEvent depthFirstEvent = new DefaultExceptionEvent(stack, false, exceptionEventEvent.isHandled());
                        handler2.notify((ExceptionEvent)depthFirstEvent, beanManager);
                        ExceptionHandlerBroadcaster.LOG.fine(String.format("Handler %s returned status %s", handler2, depthFirstEvent.getCurrentExceptionHandlingFlow().name()));
                        if (!depthFirstEvent.isUnmute()) {
                            processedHandlers.add(handler2);
                        }
                        switch (depthFirstEvent.getCurrentExceptionHandlingFlow()) {
                            case HANDLED: {
                                exceptionEventEvent.setHandled(true);
                                return;
                            }
                            case HANDLED_AND_CONTINUE: {
                                exceptionEventEvent.setHandled(true);
                                continue;
                            }
                            case ABORT: {
                                return;
                            }
                            case SKIP_CAUSE: {
                                exceptionEventEvent.setHandled(true);
                                stack.skipCause();
                                continue Label_0078;
                            }
                            case THROW_ORIGINAL: {
                                throwException = exceptionEventEvent.getException();
                                continue;
                            }
                            case THROW: {
                                throwException = depthFirstEvent.getThrowNewException();
                                continue;
                            }
                            default: {
                                throw new IllegalStateException("Unexpected enum type " + depthFirstEvent.getCurrentExceptionHandlingFlow());
                            }
                        }
                    }
                }
                stack.skipCause();
            }
            if (!exceptionEventEvent.isHandled() && throwException == null && !exceptionEventEvent.isOptional()) {
                ExceptionHandlerBroadcaster.LOG.warning(String.format("No handlers found for exception %s", exceptionEventEvent.getException()));
                throw exceptionEventEvent.getException();
            }
            if (throwException != null) {
                throw throwException;
            }
        }
        finally {
            if (creationalContext != null) {
                creationalContext.release();
            }
            ExceptionHandlerBroadcaster.LOG.exiting(ExceptionHandlerBroadcaster.class.getName(), "executeHandlers", exceptionEventEvent.getException());
        }
    }
    
    static {
        LOG = Logger.getLogger(ExceptionHandlerBroadcaster.class.getName());
    }
}
