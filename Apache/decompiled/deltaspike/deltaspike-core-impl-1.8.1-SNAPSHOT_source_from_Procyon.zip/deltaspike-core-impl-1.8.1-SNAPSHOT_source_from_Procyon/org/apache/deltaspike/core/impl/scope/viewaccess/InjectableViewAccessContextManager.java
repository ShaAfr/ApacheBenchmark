// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.viewaccess;

import org.apache.deltaspike.core.api.provider.BeanProvider;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.impl.scope.DeltaSpikeContextExtension;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.spi.scope.viewaccess.ViewAccessContextManager;

@Typed
class InjectableViewAccessContextManager implements ViewAccessContextManager
{
    private transient volatile ViewAccessContextManager viewAccessContextManager;
    
    public InjectableViewAccessContextManager(final ViewAccessContextManager viewAccessContextManager) {
        this.viewAccessContextManager = viewAccessContextManager;
    }
    
    private ViewAccessContextManager getConversationManager() {
        if (this.viewAccessContextManager == null) {
            this.viewAccessContextManager = (ViewAccessContextManager)((DeltaSpikeContextExtension)BeanProvider.getContextualReference((Class)DeltaSpikeContextExtension.class, new Annotation[0])).getViewAccessScopedContext();
        }
        return this.viewAccessContextManager;
    }
    
    public void close() {
        this.getConversationManager().close();
    }
}
