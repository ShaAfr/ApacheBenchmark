// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.interceptor;

import java.util.Iterator;
import javax.enterprise.inject.spi.AnnotatedType;
import javax.interceptor.Interceptor;
import javax.enterprise.inject.spi.ProcessAnnotatedType;
import org.apache.deltaspike.core.impl.util.AnnotationInstanceUtils;
import org.apache.deltaspike.core.api.config.base.CoreBaseConfig;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import javax.enterprise.inject.spi.BeanManager;
import java.lang.annotation.Annotation;
import java.util.logging.Logger;
import javax.enterprise.inject.spi.Extension;
import org.apache.deltaspike.core.spi.activation.Deactivatable;

public class GlobalInterceptorExtension implements Deactivatable, Extension
{
    private static final Logger LOG;
    private static final String DS_PACKAGE_NAME = "org.apache.deltaspike.";
    private Annotation priorityAnnotationInstance;
    private BeanManager beanManager;
    
    protected void init(@Observes final BeforeBeanDiscovery beforeBeanDiscovery, final BeanManager beanManager) {
        if (!ClassDeactivationUtils.isActivated((Class)this.getClass())) {
            return;
        }
        this.beanManager = beanManager;
        final int priorityValue = CoreBaseConfig.InterceptorCustomization.PRIORITY;
        this.priorityAnnotationInstance = AnnotationInstanceUtils.getPriorityAnnotationInstance(priorityValue);
    }
    
    protected void promoteInterceptors(@Observes final ProcessAnnotatedType pat) {
        if (this.priorityAnnotationInstance == null) {
            return;
        }
        final String beanClassName = pat.getAnnotatedType().getJavaClass().getName();
        if (beanClassName.startsWith("org.apache.deltaspike.")) {
            if (pat.getAnnotatedType().isAnnotationPresent((Class)Interceptor.class)) {
                pat.setAnnotatedType((AnnotatedType)new GlobalInterceptorWrapper(pat.getAnnotatedType(), this.priorityAnnotationInstance));
            }
            else if (!beanClassName.contains(".test.")) {
                for (final Annotation annotation : pat.getAnnotatedType().getAnnotations()) {
                    if (this.beanManager.isInterceptorBinding((Class)annotation.annotationType())) {
                        GlobalInterceptorExtension.LOG.warning(beanClassName + " is an bean from DeltaSpike which is intercepted.");
                    }
                }
            }
        }
    }
    
    static {
        LOG = Logger.getLogger(GlobalInterceptorExtension.class.getName());
    }
}
