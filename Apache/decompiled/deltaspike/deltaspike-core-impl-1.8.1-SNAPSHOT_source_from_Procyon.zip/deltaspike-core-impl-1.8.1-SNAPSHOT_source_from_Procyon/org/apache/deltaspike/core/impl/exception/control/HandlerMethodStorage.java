// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control;

import java.util.Collection;
import java.lang.annotation.Annotation;
import java.util.Set;
import javax.enterprise.inject.spi.BeanManager;
import java.lang.reflect.Type;
import org.apache.deltaspike.core.api.exception.control.HandlerMethod;

public interface HandlerMethodStorage
{
     <T extends Throwable> void registerHandlerMethod(final HandlerMethod<T> p0);
    
    Collection<HandlerMethod<? extends Throwable>> getHandlersForException(final Type p0, final BeanManager p1, final Set<Annotation> p2, final boolean p3);
}
