// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.jmx;

import java.lang.reflect.Method;

class Operation
{
    private final Method operation;
    private final boolean presentAsTabularIfPossible;
    
    public Operation(final Method operation, final boolean presentAsTabularIfPossible) {
        this.operation = operation;
        this.presentAsTabularIfPossible = presentAsTabularIfPossible;
    }
    
    public boolean isPresentAsTabularIfPossible() {
        return this.presentAsTabularIfPossible;
    }
    
    public Method getOperation() {
        return this.operation;
    }
}
