// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.future;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.inject.Inject;
import org.apache.deltaspike.core.spi.future.FutureableStrategy;
import org.apache.deltaspike.core.api.future.Futureable;
import javax.interceptor.Interceptor;
import java.io.Serializable;

@Interceptor
@Futureable
public class FutureableInterceptor implements Serializable
{
    @Inject
    private FutureableStrategy futureableStrategy;
    
    @AroundInvoke
    public Object invoke(final InvocationContext ic) throws Exception {
        return this.futureableStrategy.execute(ic);
    }
}
