// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.lock;

import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import javax.enterprise.inject.spi.AnnotatedMethod;
import javax.enterprise.context.spi.CreationalContext;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import javax.enterprise.inject.spi.AnnotatedType;
import org.apache.deltaspike.core.impl.util.AnnotatedMethods;
import javax.interceptor.InvocationContext;
import java.util.concurrent.ConcurrentHashMap;
import javax.inject.Inject;
import javax.enterprise.inject.spi.BeanManager;
import java.lang.reflect.Method;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.ConcurrentMap;
import javax.enterprise.inject.Typed;
import javax.enterprise.context.ApplicationScoped;
import org.apache.deltaspike.core.api.lock.Locked;

@ApplicationScoped
@Typed({ LockSupplierStorage.class })
public class LockSupplierStorage implements Locked.LockFactory
{
    private final ConcurrentMap<String, ReadWriteLock> locks;
    private final ConcurrentMap<Method, LockSupplier> lockSuppliers;
    @Inject
    private BeanManager beanManager;
    
    public LockSupplierStorage() {
        this.locks = new ConcurrentHashMap<String, ReadWriteLock>();
        this.lockSuppliers = new ConcurrentHashMap<Method, LockSupplier>();
    }
    
    protected LockSupplier getLockSupplier(final InvocationContext ic) {
        final Method key = ic.getMethod();
        LockSupplier operation = this.lockSuppliers.get(key);
        if (operation == null) {
            final Class declaringClass = key.getDeclaringClass();
            final AnnotatedType<Object> annotatedType = (AnnotatedType<Object>)this.beanManager.createAnnotatedType(declaringClass);
            final AnnotatedMethod<?> annotatedMethod = AnnotatedMethods.findMethod(annotatedType, key);
            Locked config = (Locked)annotatedMethod.getAnnotation((Class)Locked.class);
            if (config == null) {
                config = (Locked)annotatedType.getAnnotation((Class)Locked.class);
            }
            final Locked.LockFactory factory = (Locked.LockFactory)((config.factory() != Locked.LockFactory.class) ? ((Locked.LockFactory)Locked.LockFactory.class.cast(this.beanManager.getReference(this.beanManager.resolve(this.beanManager.getBeans((Type)config.factory(), new Annotation[0])), (Type)Locked.LockFactory.class, (CreationalContext)null))) : this);
            final ReadWriteLock writeLock = factory.newLock((AnnotatedMethod)annotatedMethod, config.fair());
            final long timeout = config.timeoutUnit().toMillis(config.timeout());
            final Lock lock = (config.operation() == Locked.Operation.READ) ? writeLock.readLock() : writeLock.writeLock();
            if (timeout > 0L) {
                operation = new LockSupplier() {
                    @Override
                    public Lock get() {
                        try {
                            if (!lock.tryLock(timeout, TimeUnit.MILLISECONDS)) {
                                throw new IllegalStateException("Can't lock for " + key + " in " + timeout + "ms");
                            }
                        }
                        catch (InterruptedException e) {
                            Thread.interrupted();
                            throw new IllegalStateException("Locking interrupted", e);
                        }
                        return lock;
                    }
                };
            }
            else {
                operation = new LockSupplier() {
                    @Override
                    public Lock get() {
                        lock.lock();
                        return lock;
                    }
                };
            }
            final LockSupplier existing = this.lockSuppliers.putIfAbsent(key, operation);
            if (existing != null) {
                operation = existing;
            }
        }
        return operation;
    }
    
    public ReadWriteLock newLock(final AnnotatedMethod<?> method, final boolean fair) {
        final String name = method.getJavaMember().getDeclaringClass().getName();
        ReadWriteLock lock = this.locks.get(name);
        if (lock == null) {
            lock = new ReentrantReadWriteLock(fair);
            final ReadWriteLock existing = this.locks.putIfAbsent(name, lock);
            if (existing != null) {
                lock = existing;
            }
        }
        return lock;
    }
}
