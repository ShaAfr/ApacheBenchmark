// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.window;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class WindowIdHolder
{
    private String windowId;
    
    public String getWindowId() {
        return this.windowId;
    }
    
    public void setWindowId(final String windowId) {
        this.windowId = windowId;
    }
}
