// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.Typed;

@Typed
abstract class MessageBundleContext
{
    private static final ThreadLocal<Bean> MESSAGE_BUNDLE_BEAN;
    
    private MessageBundleContext() {
    }
    
    static void setBean(final Bean bean) {
        MessageBundleContext.MESSAGE_BUNDLE_BEAN.set(bean);
    }
    
    static void reset() {
        MessageBundleContext.MESSAGE_BUNDLE_BEAN.set(null);
        MessageBundleContext.MESSAGE_BUNDLE_BEAN.remove();
    }
    
    static Bean getCurrentMessageBundleBean() {
        return MessageBundleContext.MESSAGE_BUNDLE_BEAN.get();
    }
    
    static {
        MESSAGE_BUNDLE_BEAN = new ThreadLocal<Bean>();
    }
}
