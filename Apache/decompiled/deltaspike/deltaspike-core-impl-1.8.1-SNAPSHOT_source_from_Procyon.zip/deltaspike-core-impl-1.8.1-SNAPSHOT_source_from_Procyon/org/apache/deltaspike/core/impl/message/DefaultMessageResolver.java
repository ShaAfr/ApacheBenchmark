// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import java.util.ResourceBundle;
import java.util.Locale;
import java.util.Iterator;
import java.util.List;
import java.util.MissingResourceException;
import org.apache.deltaspike.core.util.PropertyFileUtils;
import org.apache.deltaspike.core.api.message.MessageContext;
import javax.enterprise.context.Dependent;
import org.apache.deltaspike.core.api.message.MessageResolver;

@Dependent
public class DefaultMessageResolver implements MessageResolver
{
    private static final long serialVersionUID = 5834411208472341006L;
    
    public String getMessage(final MessageContext messageContext, final String messageTemplate, final String category) {
        if (messageTemplate.startsWith("{{")) {
            return messageTemplate.substring(1);
        }
        if (messageTemplate.startsWith("{") && messageTemplate.endsWith("}")) {
            final String resourceKey = messageTemplate.substring(1, messageTemplate.length() - 1);
            final List<String> messageSources = this.getMessageSources(messageContext);
            if (messageSources == null || messageSources.isEmpty()) {
                return null;
            }
            final Iterator<String> messageSourceIterator = messageSources.iterator();
            final Locale locale = messageContext.getLocale();
            while (messageSourceIterator.hasNext()) {
                final String currentMessageSource = messageSourceIterator.next();
                try {
                    final ResourceBundle messageBundle = PropertyFileUtils.getResourceBundle(currentMessageSource, locale);
                    if (category != null && category.length() > 0) {
                        try {
                            return messageBundle.getString(resourceKey + "_" + category);
                        }
                        catch (MissingResourceException e) {
                            return messageBundle.getString(resourceKey);
                        }
                    }
                    return messageBundle.getString(resourceKey);
                }
                catch (MissingResourceException e2) {
                    if (!messageSourceIterator.hasNext()) {
                        return null;
                    }
                    continue;
                }
                break;
            }
        }
        return messageTemplate;
    }
    
    protected List<String> getMessageSources(final MessageContext messageContext) {
        return (List<String>)messageContext.getMessageSources();
    }
}
