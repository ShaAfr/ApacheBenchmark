// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.util.Map;

public abstract class MapConfigSource extends BaseConfigSource
{
    private final Map<String, String> map;
    
    public MapConfigSource(final Map<String, String> map) {
        this.map = map;
    }
    
    public Map<String, String> getProperties() {
        return this.map;
    }
    
    public String getPropertyValue(final String key) {
        return this.map.get(key);
    }
    
    public boolean isScannable() {
        return true;
    }
}
