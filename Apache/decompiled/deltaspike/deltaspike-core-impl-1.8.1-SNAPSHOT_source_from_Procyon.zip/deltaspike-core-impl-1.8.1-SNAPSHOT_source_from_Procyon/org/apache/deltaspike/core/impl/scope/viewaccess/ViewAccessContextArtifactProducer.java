// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.viewaccess;

import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import org.apache.deltaspike.core.spi.scope.viewaccess.ViewAccessContextManager;
import javax.inject.Inject;
import org.apache.deltaspike.core.impl.scope.DeltaSpikeContextExtension;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ViewAccessContextArtifactProducer
{
    @Inject
    private DeltaSpikeContextExtension deltaSpikeContextExtension;
    
    @Produces
    @Dependent
    public ViewAccessContextManager getViewAccessContextManager() {
        return (ViewAccessContextManager)new InjectableViewAccessContextManager((ViewAccessContextManager)this.deltaSpikeContextExtension.getViewAccessScopedContext());
    }
}
