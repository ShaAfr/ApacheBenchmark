// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.viewaccess;

import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.RequestScoped;

@RequestScoped
public class ViewAccessBeanAccessHistory
{
    private final List<String> accessedBeans;
    
    public ViewAccessBeanAccessHistory() {
        this.accessedBeans = new ArrayList<String>();
    }
    
    public List<String> getAccessedBeans() {
        return this.accessedBeans;
    }
}
