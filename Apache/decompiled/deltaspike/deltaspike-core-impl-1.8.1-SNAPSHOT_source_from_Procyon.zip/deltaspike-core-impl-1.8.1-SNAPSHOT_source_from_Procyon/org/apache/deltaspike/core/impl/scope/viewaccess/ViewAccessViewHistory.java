// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.viewaccess;

import org.apache.deltaspike.core.api.scope.WindowScoped;
import java.io.Serializable;

@WindowScoped
public class ViewAccessViewHistory implements Serializable
{
    private static final long serialVersionUID = 8917607910721148527L;
    private String lastView;
    
    public String getLastView() {
        return this.lastView;
    }
    
    public void setLastView(final String lastView) {
        this.lastView = lastView;
    }
}
