// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.lock;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.inject.Inject;
import org.apache.deltaspike.core.spi.lock.LockedStrategy;
import javax.interceptor.Interceptor;
import org.apache.deltaspike.core.api.lock.Locked;
import java.io.Serializable;

@Locked
@Interceptor
public class LockedInterceptor implements Serializable
{
    @Inject
    private LockedStrategy lockedStrategy;
    
    @AroundInvoke
    public Object invoke(final InvocationContext ic) throws Exception {
        return this.lockedStrategy.execute(ic);
    }
}
