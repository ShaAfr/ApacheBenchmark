// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control;

import java.util.Set;
import java.util.Collection;
import java.util.ArrayList;
import org.apache.deltaspike.core.util.HierarchyDiscovery;
import java.lang.reflect.Type;
import org.apache.deltaspike.core.api.literal.AnyLiteral;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.api.exception.control.HandlerMethod;
import java.util.Comparator;

@Typed
public final class ExceptionHandlerComparator implements Comparator<HandlerMethod<?>>
{
    @Override
    public int compare(final HandlerMethod<?> lhs, final HandlerMethod<?> rhs) {
        if (lhs.equals((Object)rhs)) {
            return 0;
        }
        if (lhs.getExceptionType().equals(rhs.getExceptionType()) && lhs.getQualifiers().equals(rhs.getQualifiers())) {
            final int precedenceReturnValue = this.comparePrecedence(lhs.getOrdinal(), rhs.getOrdinal(), lhs.isBeforeHandler());
            if (precedenceReturnValue == 0) {
                return -1;
            }
            return precedenceReturnValue;
        }
        else {
            if (!lhs.getExceptionType().equals(rhs.getExceptionType()) || lhs.getQualifiers().equals(rhs.getQualifiers())) {
                return this.compareHierarchies(lhs.getExceptionType(), rhs.getExceptionType());
            }
            if (lhs.getQualifiers().contains(new AnyLiteral())) {
                return -1;
            }
            return 1;
        }
    }
    
    private int compareHierarchies(final Type lhsExceptionType, final Type rhsExceptionType) {
        final HierarchyDiscovery lhsHierarchy = new HierarchyDiscovery(lhsExceptionType);
        final Set<Type> lhsTypeclosure = (Set<Type>)lhsHierarchy.getTypeClosure();
        if (lhsTypeclosure.contains(rhsExceptionType)) {
            final int indexOfLhsType = new ArrayList(lhsTypeclosure).indexOf(lhsExceptionType);
            final int indexOfRhsType = new ArrayList(lhsTypeclosure).indexOf(rhsExceptionType);
            if (indexOfLhsType > indexOfRhsType) {
                return 1;
            }
        }
        return -1;
    }
    
    private int comparePrecedence(final int lhs, final int rhs, final boolean isLhsBefore) {
        if (!isLhsBefore) {
            return lhs - rhs;
        }
        return (lhs - rhs) * -1;
    }
}
