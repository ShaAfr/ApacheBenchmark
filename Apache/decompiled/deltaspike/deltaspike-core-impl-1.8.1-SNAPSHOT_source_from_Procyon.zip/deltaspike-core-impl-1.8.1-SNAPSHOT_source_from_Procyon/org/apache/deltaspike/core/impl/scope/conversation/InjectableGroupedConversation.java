// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.conversation;

import java.util.Set;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.spi.scope.conversation.GroupedConversationManager;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.api.scope.GroupedConversation;

@Typed
class InjectableGroupedConversation implements GroupedConversation
{
    private static final long serialVersionUID = -3909049219127821425L;
    private final ConversationKey conversationKey;
    private final GroupedConversationManager conversationManager;
    
    InjectableGroupedConversation(final ConversationKey conversationKey, final GroupedConversationManager conversationManager) {
        this.conversationManager = conversationManager;
        this.conversationKey = conversationKey;
    }
    
    public void close() {
        final Set<Annotation> qualifiers = this.conversationKey.getQualifiers();
        this.conversationManager.closeConversation((Class)this.conversationKey.getConversationGroup(), (Annotation[])qualifiers.toArray(new Annotation[qualifiers.size()]));
    }
}
