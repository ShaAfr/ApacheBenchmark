// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.jmx;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class AttributeAccessor
{
    private final Method getter;
    private final Method setter;
    private final boolean presentAsTabularIfPossible;
    
    public AttributeAccessor(final Method get, final Method set, final boolean presentAsTabularIfPossible) {
        this.setter = set;
        this.getter = get;
        this.presentAsTabularIfPossible = presentAsTabularIfPossible;
    }
    
    public boolean isPresentAsTabularIfPossible() {
        return this.presentAsTabularIfPossible;
    }
    
    public Object get(final Object instance) throws InvocationTargetException, IllegalAccessException {
        if (this.getter == null) {
            throw new IllegalAccessException("This attribute has no getter");
        }
        return this.getter.invoke(instance, new Object[0]);
    }
    
    public void set(final Object instance, final Object value) throws InvocationTargetException, IllegalAccessException {
        if (this.setter == null) {
            throw new IllegalAccessException("This attribute has no setter");
        }
        this.setter.invoke(instance, value);
    }
}
