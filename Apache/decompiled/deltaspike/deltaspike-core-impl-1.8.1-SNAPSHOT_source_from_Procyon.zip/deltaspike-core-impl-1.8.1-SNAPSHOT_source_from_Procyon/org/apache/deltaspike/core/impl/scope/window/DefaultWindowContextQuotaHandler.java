// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.window;

import javax.annotation.PostConstruct;
import org.apache.deltaspike.core.api.config.base.CoreBaseConfig;
import java.util.Stack;
import javax.inject.Inject;
import javax.enterprise.context.SessionScoped;
import org.apache.deltaspike.core.spi.scope.window.WindowContextQuotaHandler;

@SessionScoped
public class DefaultWindowContextQuotaHandler implements WindowContextQuotaHandler
{
    protected int maxWindowContextCount;
    @Inject
    private WindowContextQuotaHandlerCache quotaHandlerCache;
    private Stack<String> windowIdStack;
    
    public DefaultWindowContextQuotaHandler() {
        this.windowIdStack = new Stack<String>();
    }
    
    @PostConstruct
    protected void init() {
        this.maxWindowContextCount = CoreBaseConfig.ScopeCustomization.WindowRestriction.MAX_COUNT;
    }
    
    public synchronized void checkWindowContextQuota(final String windowId) {
        if (windowId == null) {
            return;
        }
        if (this.quotaHandlerCache.cacheWindowId(windowId)) {
            return;
        }
        if (this.windowIdStack.contains(windowId)) {
            if (this.windowIdStack.size() > 1) {
                this.windowIdStack.remove(windowId);
                this.windowIdStack.push(windowId);
            }
        }
        else {
            this.windowIdStack.push(windowId);
            if (this.windowIdStack.size() > this.maxWindowContextCount) {
                final String windowIdToRemove = this.windowIdStack.remove(0);
                this.quotaHandlerCache.setWindowIdToDestroy(windowIdToRemove);
            }
        }
    }
}
