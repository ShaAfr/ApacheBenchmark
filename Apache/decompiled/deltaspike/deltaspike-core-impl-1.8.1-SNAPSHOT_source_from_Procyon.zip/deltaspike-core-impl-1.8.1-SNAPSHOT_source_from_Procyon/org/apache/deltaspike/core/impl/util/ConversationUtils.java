// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.util;

import org.apache.deltaspike.core.api.scope.ConversationSubGroup;
import java.util.Iterator;
import java.util.Set;
import org.apache.deltaspike.core.api.scope.ConversationGroup;
import java.lang.annotation.Annotation;
import javax.enterprise.inject.spi.PassivationCapable;
import javax.enterprise.inject.spi.Bean;
import org.apache.deltaspike.core.impl.scope.conversation.ConversationKey;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.context.spi.Contextual;
import javax.enterprise.inject.Typed;

@Typed
public abstract class ConversationUtils
{
    private ConversationUtils() {
    }
    
    public static ConversationKey convertToConversationKey(Contextual<?> contextual, final BeanManager beanManager) {
        if (!(contextual instanceof Bean)) {
            if (!(contextual instanceof PassivationCapable)) {
                throw new IllegalArgumentException(contextual.getClass().getName() + " is not of type " + Bean.class.getName());
            }
            contextual = (Contextual<?>)beanManager.getPassivationCapableBean(((PassivationCapable)contextual).getId());
        }
        final Bean<?> bean = (Bean<?>)contextual;
        final ConversationGroup conversationGroupAnnotation = findConversationGroupAnnotation(bean);
        Class<?> conversationGroup;
        if (conversationGroupAnnotation != null) {
            conversationGroup = (Class<?>)conversationGroupAnnotation.value();
        }
        else {
            conversationGroup = (Class<?>)bean.getBeanClass();
        }
        final Set<Annotation> qualifiers = (Set<Annotation>)bean.getQualifiers();
        return new ConversationKey(conversationGroup, (Annotation[])qualifiers.toArray(new Annotation[qualifiers.size()]));
    }
    
    private static ConversationGroup findConversationGroupAnnotation(final Bean<?> bean) {
        final Set<Annotation> qualifiers = (Set<Annotation>)bean.getQualifiers();
        for (final Annotation qualifier : qualifiers) {
            if (ConversationGroup.class.isAssignableFrom(qualifier.annotationType())) {
                return (ConversationGroup)qualifier;
            }
        }
        return null;
    }
    
    public static Class<?> getDeclaredConversationGroup(final Class<?> conversationGroup) {
        final ConversationSubGroup conversationSubGroup = conversationGroup.getAnnotation(ConversationSubGroup.class);
        if (conversationSubGroup == null) {
            return conversationGroup;
        }
        Class<?> result = (Class<?>)conversationSubGroup.of();
        if (!ConversationSubGroup.class.equals(result)) {
            return result;
        }
        result = conversationGroup.getSuperclass();
        if ((result == null || Object.class.getName().equals(result.getName())) && conversationGroup.getInterfaces().length == 1) {
            return conversationGroup.getInterfaces()[0];
        }
        if (result == null) {
            throw new IllegalStateException(conversationGroup.getName() + " hosts an invalid usage of @" + ConversationSubGroup.class.getName());
        }
        return result;
    }
}
