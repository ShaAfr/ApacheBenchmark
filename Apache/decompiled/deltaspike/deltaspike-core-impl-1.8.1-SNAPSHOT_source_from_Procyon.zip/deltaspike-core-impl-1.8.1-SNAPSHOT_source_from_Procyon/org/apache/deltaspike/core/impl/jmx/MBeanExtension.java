// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.jmx;

import org.apache.deltaspike.core.api.config.ConfigResolver;
import java.lang.management.ManagementFactory;
import org.apache.deltaspike.core.api.jmx.JmxBroadcaster;
import org.apache.deltaspike.core.util.BeanUtils;
import org.apache.deltaspike.core.api.config.base.CoreBaseConfig;
import javax.enterprise.inject.spi.AnnotatedType;
import java.lang.annotation.Annotation;
import java.util.Set;
import java.util.Iterator;
import javax.management.MBeanServer;
import javax.enterprise.inject.spi.BeforeShutdown;
import org.apache.deltaspike.core.api.jmx.MBean;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.ProcessManagedBean;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import javax.management.ObjectName;
import java.util.Collection;
import java.util.Map;
import java.util.logging.Logger;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import javax.enterprise.inject.spi.Extension;

public class MBeanExtension implements Extension, Deactivatable
{
    private static final Logger LOGGER;
    private static final String DEFAULT_TYPE = "MBeans";
    private static final String DEFAULT_CATEGORY = "org.apache.deltaspike";
    private final Map<Class<?>, DynamicMBeanWrapper> wrappers;
    private final Collection<ObjectName> objectNames;
    private Boolean isActivated;
    
    public MBeanExtension() {
        this.wrappers = new ConcurrentHashMap<Class<?>, DynamicMBeanWrapper>();
        this.objectNames = new ArrayList<ObjectName>();
        this.isActivated = true;
    }
    
    protected void init(@Observes final BeforeBeanDiscovery beforeBeanDiscovery) {
        this.isActivated = ClassDeactivationUtils.isActivated((Class)this.getClass());
    }
    
    protected void processBean(@Observes final ProcessManagedBean<?> bean, final BeanManager bm) throws Exception {
        if (!this.isActivated) {
            return;
        }
        final MBean mBeanAnnotation = (MBean)bean.getAnnotated().getAnnotation((Class)MBean.class);
        if (mBeanAnnotation != null) {
            this.registerObject(bean, mBeanAnnotation, bm);
        }
    }
    
    protected void shutdown(@Observes final BeforeShutdown shutdown) throws Exception {
        if (!this.isActivated) {
            return;
        }
        final MBeanServer mBeanServer = this.mBeanServer();
        for (final ObjectName objectName : this.objectNames) {
            mBeanServer.unregisterMBean(objectName);
            MBeanExtension.LOGGER.info("Unregistered MBean " + objectName.getCanonicalName());
        }
        this.objectNames.clear();
    }
    
    private void registerObject(final ProcessManagedBean<?> bean, final MBean mBeanAnnotation, final BeanManager bm) throws Exception {
        final Class<?> clazz = (Class<?>)bean.getAnnotatedBeanClass().getJavaClass();
        String objectNameValue = mBeanAnnotation.objectName();
        if (objectNameValue.isEmpty()) {
            final String type = this.getConfigurableAttribute(mBeanAnnotation.type(), "MBeans");
            final String category = this.getConfigurableAttribute(mBeanAnnotation.category(), "org.apache.deltaspike");
            final String properties = this.getConfigurableAttribute(mBeanAnnotation.properties(), "");
            final String name = mBeanAnnotation.name();
            final StringBuilder builder = new StringBuilder(category).append(':');
            if (!properties.contains("type=")) {
                builder.append("type=").append(type);
            }
            else if (!"MBeans".equals(type)) {
                MBeanExtension.LOGGER.warning("type() ignored on " + clazz + " since properties contains it.");
            }
            if (!properties.contains("name=") && (!name.isEmpty() || properties.isEmpty())) {
                builder.append(",name=");
                if (name.isEmpty()) {
                    builder.append(clazz.getName());
                }
                else {
                    builder.append(name);
                }
            }
            if (!properties.isEmpty()) {
                builder.append(',').append(properties);
            }
            objectNameValue = builder.toString();
        }
        final ObjectName objectName = new ObjectName(objectNameValue);
        final boolean normalScoped = this.isNormalScope(bean.getAnnotated().getAnnotations(), bm);
        final Annotation[] qualifiers = this.qualifiers((AnnotatedType<?>)bean.getAnnotatedBeanClass(), bm);
        final DynamicMBeanWrapper mbean = new DynamicMBeanWrapper(clazz, normalScoped, qualifiers);
        final MBeanServer server = this.mBeanServer();
        if (server.isRegistered(objectName) && CoreBaseConfig.MBeanIntegration.AUTO_UNREGISTER) {
            server.unregisterMBean(objectName);
        }
        server.registerMBean(mbean, objectName);
        this.objectNames.add(objectName);
        this.wrappers.put(clazz, mbean);
        MBeanExtension.LOGGER.info("Registered MBean " + objectName);
    }
    
    private Annotation[] qualifiers(final AnnotatedType<?> annotatedBeanClass, final BeanManager bm) {
        final Set<Annotation> qualifiers = (Set<Annotation>)BeanUtils.getQualifiers(bm, (Iterable)annotatedBeanClass.getAnnotations());
        return qualifiers.toArray(new Annotation[qualifiers.size()]);
    }
    
    private boolean isNormalScope(final Set<Annotation> annotations, final BeanManager bm) {
        for (final Annotation annotation : annotations) {
            if (bm.isNormalScope((Class)annotation.annotationType())) {
                return true;
            }
        }
        return false;
    }
    
    JmxBroadcaster getBroadcasterFor(final Class<?> clazz) {
        return (JmxBroadcaster)this.wrappers.get(clazz);
    }
    
    private MBeanServer mBeanServer() {
        return ManagementFactory.getPlatformMBeanServer();
    }
    
    private String getConfigurableAttribute(final String annotationAttributeValue, final String defaultValue) {
        String val = annotationAttributeValue.trim();
        if (val.startsWith("{") && val.endsWith("}")) {
            val = ConfigResolver.getPropertyValue(val.substring(1, val.length() - 1), defaultValue);
        }
        return (val == null || val.isEmpty()) ? defaultValue : val;
    }
    
    static {
        LOGGER = Logger.getLogger(MBeanExtension.class.getName());
    }
}
