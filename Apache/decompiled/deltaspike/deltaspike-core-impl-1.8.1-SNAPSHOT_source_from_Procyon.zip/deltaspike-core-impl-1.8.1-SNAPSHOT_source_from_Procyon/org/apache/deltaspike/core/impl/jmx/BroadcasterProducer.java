// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.jmx;

import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import org.apache.deltaspike.core.api.jmx.MBean;
import org.apache.deltaspike.core.api.jmx.JmxBroadcaster;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Inject;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class BroadcasterProducer
{
    @Inject
    private MBeanExtension extension;
    
    @Produces
    @Dependent
    public JmxBroadcaster jmxBroadcaster(final InjectionPoint ip) {
        final Class<?> declaringClass = ip.getMember().getDeclaringClass();
        final JmxBroadcaster broadcaster = this.extension.getBroadcasterFor(declaringClass);
        if (broadcaster == null) {
            throw new IllegalStateException("Invalid injection of " + JmxBroadcaster.class.getName() + " in " + declaringClass.getName() + " detected. It is required to annotate the class with @" + MBean.class.getName());
        }
        return broadcaster;
    }
}
