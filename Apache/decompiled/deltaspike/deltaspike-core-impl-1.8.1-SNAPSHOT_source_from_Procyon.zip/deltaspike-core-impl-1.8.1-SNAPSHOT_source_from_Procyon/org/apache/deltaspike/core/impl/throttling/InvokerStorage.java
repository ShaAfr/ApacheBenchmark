// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.throttling;

import javax.enterprise.inject.spi.AnnotatedMethod;
import javax.enterprise.context.spi.CreationalContext;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.api.throttling.Throttled;
import javax.enterprise.inject.spi.AnnotatedType;
import org.apache.deltaspike.core.impl.util.AnnotatedMethods;
import javax.interceptor.InvocationContext;
import java.util.concurrent.ConcurrentHashMap;
import javax.inject.Inject;
import javax.enterprise.inject.spi.BeanManager;
import java.lang.reflect.Method;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ConcurrentMap;
import javax.enterprise.inject.Typed;
import javax.enterprise.context.ApplicationScoped;
import org.apache.deltaspike.core.api.throttling.Throttling;

@ApplicationScoped
@Typed({ InvokerStorage.class })
public class InvokerStorage implements Throttling.SemaphoreFactory
{
    private final ConcurrentMap<String, Semaphore> semaphores;
    private final ConcurrentMap<Method, Invoker> providers;
    @Inject
    private BeanManager beanManager;
    
    public InvokerStorage() {
        this.semaphores = new ConcurrentHashMap<String, Semaphore>();
        this.providers = new ConcurrentHashMap<Method, Invoker>();
    }
    
    Invoker getOrCreateInvoker(final InvocationContext ic) {
        final Method method = ic.getMethod();
        Invoker i = this.providers.get(method);
        if (i == null) {
            final Class declaringClass = method.getDeclaringClass();
            final AnnotatedType<Object> annotatedType = (AnnotatedType<Object>)this.beanManager.createAnnotatedType(declaringClass);
            final AnnotatedMethod<?> annotatedMethod = AnnotatedMethods.findMethod(annotatedType, method);
            Throttled config = (Throttled)annotatedMethod.getAnnotation((Class)Throttled.class);
            if (config == null) {
                config = (Throttled)annotatedType.getAnnotation((Class)Throttled.class);
            }
            Throttling sharedConfig = (Throttling)annotatedMethod.getAnnotation((Class)Throttling.class);
            if (sharedConfig == null) {
                sharedConfig = (Throttling)annotatedType.getAnnotation((Class)Throttling.class);
            }
            final Throttling.SemaphoreFactory factory = (Throttling.SemaphoreFactory)((sharedConfig != null && sharedConfig.factory() != Throttling.SemaphoreFactory.class) ? ((Throttling.SemaphoreFactory)Throttling.SemaphoreFactory.class.cast(this.beanManager.getReference(this.beanManager.resolve(this.beanManager.getBeans((Type)sharedConfig.factory(), new Annotation[0])), (Type)Throttling.SemaphoreFactory.class, (CreationalContext)null))) : this);
            final Semaphore semaphore = factory.newSemaphore((AnnotatedMethod)annotatedMethod, (sharedConfig != null && !sharedConfig.name().isEmpty()) ? sharedConfig.name() : declaringClass.getName(), sharedConfig != null && sharedConfig.fair(), (sharedConfig != null) ? sharedConfig.permits() : 1);
            final long timeout = config.timeoutUnit().toMillis(config.timeout());
            final int weigth = config.weight();
            i = new Invoker(semaphore, weigth, timeout);
            final Invoker existing = this.providers.putIfAbsent(ic.getMethod(), i);
            if (existing != null) {
                i = existing;
            }
        }
        return i;
    }
    
    public Semaphore newSemaphore(final AnnotatedMethod<?> method, final String name, final boolean fair, final int permits) {
        Semaphore semaphore = this.semaphores.get(name);
        if (semaphore == null) {
            semaphore = new Semaphore(permits, fair);
            final Semaphore existing = this.semaphores.putIfAbsent(name, semaphore);
            if (existing != null) {
                semaphore = existing;
            }
        }
        return semaphore;
    }
}
