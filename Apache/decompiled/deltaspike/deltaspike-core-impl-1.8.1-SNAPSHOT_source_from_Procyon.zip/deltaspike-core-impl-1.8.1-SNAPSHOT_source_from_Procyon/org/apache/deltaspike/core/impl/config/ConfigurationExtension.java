// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.spi.config.BaseConfigPropertyProducer;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.deltaspike.core.util.ServiceUtils;
import org.apache.deltaspike.core.spi.config.ConfigValidator;
import javax.enterprise.inject.spi.BeforeShutdown;
import java.util.logging.Level;
import org.apache.deltaspike.core.api.provider.BeanProvider;
import java.util.Collection;
import javax.enterprise.inject.spi.AfterDeploymentValidation;
import javax.enterprise.context.ApplicationScoped;
import org.apache.deltaspike.core.util.metadata.builder.ContextualLifecycle;
import org.apache.deltaspike.core.api.literal.AnyLiteral;
import org.apache.deltaspike.core.api.literal.DefaultLiteral;
import java.lang.annotation.Annotation;
import org.apache.deltaspike.core.util.bean.BeanBuilder;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.AfterBeanDiscovery;
import java.util.Iterator;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import javax.enterprise.inject.spi.InjectionPoint;
import org.apache.deltaspike.core.api.config.Filter;
import org.apache.deltaspike.core.api.config.Source;
import javax.enterprise.inject.spi.ProcessBean;
import org.apache.deltaspike.core.api.config.Configuration;
import org.apache.deltaspike.core.api.exclude.Exclude;
import javax.enterprise.inject.spi.ProcessAnnotatedType;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanServer;
import javax.management.InstanceAlreadyExistsException;
import javax.management.ObjectName;
import org.apache.deltaspike.core.util.ClassUtils;
import java.lang.management.ManagementFactory;
import org.apache.deltaspike.core.api.config.ConfigResolver;
import org.apache.deltaspike.core.util.ClassDeactivationUtils;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import java.util.HashSet;
import java.util.ArrayList;
import org.apache.deltaspike.core.spi.config.ConfigFilter;
import org.apache.deltaspike.core.spi.config.ConfigSource;
import javax.enterprise.inject.spi.Bean;
import java.lang.reflect.Type;
import java.util.Set;
import org.apache.deltaspike.core.api.config.PropertyFileConfig;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.apache.deltaspike.core.spi.activation.Deactivatable;
import javax.enterprise.inject.spi.Extension;

public class ConfigurationExtension implements Extension, Deactivatable
{
    private static final Logger LOG;
    private static final String CANNOT_CREATE_CONFIG_SOURCE_FOR_CUSTOM_PROPERTY_FILE_CONFIG = "Cannot create ConfigSource for custom property-file config ";
    private static Map<ClassLoader, List<Class<? extends PropertyFileConfig>>> detectedParentPropertyFileConfigs;
    private boolean isActivated;
    private List<Class<? extends PropertyFileConfig>> propertyFileConfigClasses;
    private final Set<Type> dynamicConfigTypes;
    private Bean<DynamicBeanProducer> dynamicProducer;
    private final List<Bean<? extends ConfigSource>> cdiSources;
    private final List<Bean<? extends ConfigFilter>> cdiFilters;
    private final List<Class<?>> dynamicConfigurationBeanClasses;
    
    public ConfigurationExtension() {
        this.isActivated = true;
        this.propertyFileConfigClasses = new ArrayList<Class<? extends PropertyFileConfig>>();
        this.dynamicConfigTypes = new HashSet<Type>();
        this.cdiSources = new ArrayList<Bean<? extends ConfigSource>>();
        this.cdiFilters = new ArrayList<Bean<? extends ConfigFilter>>();
        this.dynamicConfigurationBeanClasses = new ArrayList<Class<?>>();
    }
    
    protected void init(@Observes final BeforeBeanDiscovery beforeBeanDiscovery) {
        this.isActivated = ClassDeactivationUtils.isActivated((Class)this.getClass());
    }
    
    public static void registerConfigMBean() {
        final String appName = ConfigResolver.getPropertyValue("deltaspike.application.name");
        if (appName != null && appName.length() > 0) {
            try {
                final MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
                final ClassLoader tccl = ClassUtils.getClassLoader((Object)ConfigurationExtension.class);
                final DeltaSpikeConfigInfo cfgMBean = new DeltaSpikeConfigInfo(tccl);
                final ObjectName name = new ObjectName("deltaspike.config." + appName + ":type=DeltaSpikeConfig");
                mBeanServer.registerMBean(cfgMBean, name);
            }
            catch (InstanceAlreadyExistsException ex) {}
            catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    public static void unRegisterConfigMBean(final String appName) {
        if (appName != null && appName.length() > 0) {
            try {
                final MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
                final ObjectName name = new ObjectName("deltaspike.config." + appName + ":type=DeltaSpikeConfig");
                mBeanServer.unregisterMBean(name);
            }
            catch (InstanceNotFoundException ex) {}
            catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    public void collectUserConfigSources(@Observes final ProcessAnnotatedType<? extends PropertyFileConfig> pat) {
        if (!this.isActivated) {
            return;
        }
        final Class<? extends PropertyFileConfig> pcsClass = (Class<? extends PropertyFileConfig>)pat.getAnnotatedType().getJavaClass();
        if (pcsClass.isAnnotation() || pcsClass.isInterface() || pcsClass.isSynthetic() || pcsClass.isArray() || pcsClass.isEnum()) {
            return;
        }
        if (pat.getAnnotatedType().isAnnotationPresent((Class)Exclude.class)) {
            return;
        }
        this.propertyFileConfigClasses.add(pcsClass);
    }
    
    public void findDynamicConfigurationBeans(@Observes final ProcessAnnotatedType<?> pat) {
        if (!pat.getAnnotatedType().isAnnotationPresent((Class)Configuration.class)) {
            return;
        }
        final Class<?> javaClass = (Class<?>)pat.getAnnotatedType().getJavaClass();
        if (!javaClass.isInterface()) {
            return;
        }
        this.dynamicConfigurationBeanClasses.add(javaClass);
    }
    
    public void findSources(@Observes final ProcessBean<? extends ConfigSource> source) {
        if (!source.getAnnotated().isAnnotationPresent((Class)Source.class)) {
            return;
        }
        this.cdiSources.add((Bean<? extends ConfigSource>)source.getBean());
    }
    
    public void findFilters(@Observes final ProcessBean<? extends ConfigFilter> filter) {
        if (!filter.getAnnotated().isAnnotationPresent((Class)Filter.class)) {
            return;
        }
        this.cdiFilters.add((Bean<? extends ConfigFilter>)filter.getBean());
    }
    
    public void findDynamicProducer(@Observes final ProcessBean<DynamicBeanProducer> processBean) {
        this.dynamicProducer = (Bean<DynamicBeanProducer>)processBean.getBean();
    }
    
    public void collectDynamicTypes(@Observes final ProcessBean<?> processBean) {
        for (final InjectionPoint ip : processBean.getBean().getInjectionPoints()) {
            final ConfigProperty annotation = (ConfigProperty)ip.getAnnotated().getAnnotation((Class)ConfigProperty.class);
            if (annotation != null) {
                if (annotation.converter() == ConfigResolver.Converter.class) {
                    continue;
                }
                this.dynamicConfigTypes.add(ip.getType());
            }
        }
    }
    
    public void addDynamicBeans(@Observes final AfterBeanDiscovery afterBeanDiscovery, final BeanManager bm) {
        if (this.dynamicProducer != null && !this.dynamicConfigTypes.isEmpty()) {
            afterBeanDiscovery.addBean((Bean)new DynamicBean((Bean)this.dynamicProducer, (Set)this.dynamicConfigTypes));
        }
        for (final Class<?> proxyType : this.dynamicConfigurationBeanClasses) {
            afterBeanDiscovery.addBean(new BeanBuilder((BeanManager)null).types(new Type[] { proxyType, Object.class }).qualifiers(new Annotation[] { (Annotation)new DefaultLiteral(), (Annotation)new AnyLiteral() }).beanLifecycle((ContextualLifecycle)new ProxyConfigurationLifecycle(proxyType)).scope((Class)ApplicationScoped.class).passivationCapable(true).id("DeltaSpikeConfiguration#" + proxyType.getName()).beanClass((Class)proxyType).create());
        }
    }
    
    public void registerUserConfigSources(@Observes final AfterDeploymentValidation adv) {
        if (!this.isActivated) {
            return;
        }
        final Set<Class<? extends PropertyFileConfig>> allPropertyFileConfigClasses = new HashSet<Class<? extends PropertyFileConfig>>(this.propertyFileConfigClasses);
        final ClassLoader currentClassLoader = ClassUtils.getClassLoader((Object)null);
        this.addParentPropertyFileConfigs(currentClassLoader, allPropertyFileConfigClasses);
        if (!this.propertyFileConfigClasses.isEmpty()) {
            ConfigurationExtension.detectedParentPropertyFileConfigs.put(currentClassLoader, this.propertyFileConfigClasses);
        }
        final List<ConfigSource> configSources = new ArrayList<ConfigSource>();
        for (final Class<? extends PropertyFileConfig> propertyFileConfigClass : allPropertyFileConfigClasses) {
            configSources.addAll(this.createPropertyConfigSource(propertyFileConfigClass));
        }
        for (final Bean bean : this.cdiSources) {
            configSources.add((ConfigSource)BeanProvider.getContextualReference((Class)ConfigSource.class, bean));
        }
        ConfigResolver.addConfigSources((List)configSources);
        for (final Bean bean : this.cdiFilters) {
            ConfigResolver.addConfigFilter((ConfigFilter)BeanProvider.getContextualReference((Class)ConfigFilter.class, bean));
        }
        this.processConfigurationValidation(adv);
        registerConfigMBean();
        this.logConfiguration();
    }
    
    private void logConfiguration() {
        final Boolean logConfig = (Boolean)ConfigResolver.resolve("deltaspike.config.log").as((Class)Boolean.class).getValue();
        if (logConfig != null && logConfig && ConfigurationExtension.LOG.isLoggable(Level.INFO)) {
            final StringBuilder sb = new StringBuilder(65536);
            sb.append("ConfigSources: ");
            final ConfigSource[] configSources2;
            final ConfigSource[] configSources = configSources2 = ConfigResolver.getConfigSources();
            for (final ConfigSource configSource : configSources2) {
                sb.append("\n\t").append(configSource.getOrdinal()).append(" - ").append(configSource.getConfigName());
            }
            final Map<String, String> allProperties = (Map<String, String>)ConfigResolver.getAllProperties();
            sb.append("\n\nConfigured Values:");
            for (final Map.Entry<String, String> entry : allProperties.entrySet()) {
                sb.append("\n\t").append(entry.getKey()).append(" = ").append(ConfigResolver.filterConfigValueForLog((String)entry.getKey(), (String)entry.getValue()));
            }
            ConfigurationExtension.LOG.info(sb.toString());
        }
    }
    
    private void addParentPropertyFileConfigs(final ClassLoader currentClassLoader, final Set<Class<? extends PropertyFileConfig>> propertyFileConfigClasses) {
        if (currentClassLoader.getParent() == null) {
            return;
        }
        for (final Map.Entry<ClassLoader, List<Class<? extends PropertyFileConfig>>> classLoaderListEntry : ConfigurationExtension.detectedParentPropertyFileConfigs.entrySet()) {
            if (currentClassLoader.getParent().equals(classLoaderListEntry.getKey())) {
                propertyFileConfigClasses.addAll(classLoaderListEntry.getValue());
                this.addParentPropertyFileConfigs(classLoaderListEntry.getKey(), propertyFileConfigClasses);
            }
        }
    }
    
    public void freeConfigSources(@Observes final BeforeShutdown bs) {
        final String appName = ConfigResolver.getPropertyValue("deltaspike.application.name");
        unRegisterConfigMBean(appName);
        ConfigResolver.freeConfigSources();
        ConfigurationExtension.detectedParentPropertyFileConfigs.remove(ClassUtils.getClassLoader((Object)null));
    }
    
    private List<ConfigSource> createPropertyConfigSource(final Class<? extends PropertyFileConfig> propertyFileConfigClass) {
        String fileName = "";
        try {
            final PropertyFileConfig propertyFileConfig = (PropertyFileConfig)propertyFileConfigClass.newInstance();
            fileName = propertyFileConfig.getPropertyFileName();
            final EnvironmentPropertyConfigSourceProvider environmentPropertyConfigSourceProvider = new EnvironmentPropertyConfigSourceProvider(fileName, propertyFileConfig.isOptional());
            return environmentPropertyConfigSourceProvider.getConfigSources();
        }
        catch (InstantiationException e) {
            throw new RuntimeException("Cannot create ConfigSource for custom property-file config " + propertyFileConfigClass.getName(), e);
        }
        catch (IllegalAccessException e2) {
            throw new RuntimeException("Cannot create ConfigSource for custom property-file config " + propertyFileConfigClass.getName(), e2);
        }
        catch (IllegalStateException e3) {
            throw new IllegalStateException(propertyFileConfigClass.getName() + " points to an invalid file: '" + fileName + "'", e3);
        }
    }
    
    protected void processConfigurationValidation(final AfterDeploymentValidation adv) {
        for (final ConfigValidator configValidator : ServiceUtils.loadServiceImplementations((Class)ConfigValidator.class)) {
            final Set<String> violations = (Set<String>)configValidator.processValidation();
            if (violations == null) {
                continue;
            }
            for (final String violation : violations) {
                adv.addDeploymentProblem((Throwable)new IllegalStateException(violation));
            }
        }
    }
    
    static {
        LOG = Logger.getLogger(ConfigurationExtension.class.getName());
        ConfigurationExtension.detectedParentPropertyFileConfigs = new ConcurrentHashMap<ClassLoader, List<Class<? extends PropertyFileConfig>>>();
    }
    
    @ApplicationScoped
    @Typed({ DynamicBeanProducer.class })
    static class DynamicBeanProducer extends BaseConfigPropertyProducer
    {
        @Produces
        @ConfigProperty(name = "ignored")
        public Object create(final InjectionPoint ip) {
            return super.getUntypedPropertyValue(ip, ip.getType());
        }
    }
    
    @Typed
    private static final class DynamicBean<T> implements Bean<T>
    {
        private final Bean<T> producer;
        private final Set<Type> types;
        
        private DynamicBean(final Bean<T> producer, final Set<Type> types) {
            this.producer = producer;
            this.types = types;
        }
        
        public Set<Type> getTypes() {
            return this.types;
        }
        
        public Set<Annotation> getQualifiers() {
            return (Set<Annotation>)this.producer.getQualifiers();
        }
        
        public Class<? extends Annotation> getScope() {
            return (Class<? extends Annotation>)this.producer.getScope();
        }
        
        public String getName() {
            return this.producer.getName();
        }
        
        public boolean isNullable() {
            return this.producer.isNullable();
        }
        
        public Set<InjectionPoint> getInjectionPoints() {
            return (Set<InjectionPoint>)this.producer.getInjectionPoints();
        }
        
        public Class<?> getBeanClass() {
            return (Class<?>)this.producer.getBeanClass();
        }
        
        public Set<Class<? extends Annotation>> getStereotypes() {
            return (Set<Class<? extends Annotation>>)this.producer.getStereotypes();
        }
        
        public boolean isAlternative() {
            return this.producer.isAlternative();
        }
        
        public T create(final CreationalContext<T> creationalContext) {
            return (T)this.producer.create((CreationalContext)creationalContext);
        }
        
        public void destroy(final T t, final CreationalContext<T> creationalContext) {
            this.producer.destroy((Object)t, (CreationalContext)creationalContext);
        }
    }
}
