// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.lang.reflect.Type;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.enterprise.context.ApplicationScoped;
import org.apache.deltaspike.core.spi.config.BaseConfigPropertyProducer;

@ApplicationScoped
public class DefaultConfigPropertyProducer extends BaseConfigPropertyProducer
{
    @Produces
    @Dependent
    @ConfigProperty(name = "ignored")
    public String produceStringConfiguration(final InjectionPoint injectionPoint) {
        return this.getStringPropertyValue(injectionPoint);
    }
    
    @Produces
    @Dependent
    @ConfigProperty(name = "ignored")
    public Class produceClassConfiguration(final InjectionPoint injectionPoint) {
        return this.getPropertyWithException(injectionPoint, Class.class);
    }
    
    @Produces
    @Dependent
    @ConfigProperty(name = "ignored")
    public Boolean produceBooleanConfiguration(final InjectionPoint injectionPoint) {
        return this.getPropertyWithException(injectionPoint, Boolean.class);
    }
    
    @Produces
    @Dependent
    @ConfigProperty(name = "ignored")
    public Integer produceIntegerConfiguration(final InjectionPoint injectionPoint) {
        return this.getPropertyWithException(injectionPoint, Integer.class);
    }
    
    @Produces
    @Dependent
    @ConfigProperty(name = "ignored")
    public Long produceLongConfiguration(final InjectionPoint injectionPoint) {
        return this.getPropertyWithException(injectionPoint, Long.class);
    }
    
    @Produces
    @Dependent
    @ConfigProperty(name = "ignored")
    public Float produceFloatConfiguration(final InjectionPoint injectionPoint) {
        return this.getPropertyWithException(injectionPoint, Float.class);
    }
    
    @Produces
    @Dependent
    @ConfigProperty(name = "ignored")
    public Double produceDoubleConfiguration(final InjectionPoint injectionPoint) {
        return this.getPropertyWithException(injectionPoint, Double.class);
    }
    
    private <T> T getPropertyWithException(final InjectionPoint ip, final Type ipCls) {
        try {
            return (T)this.getUntypedPropertyValue(ip, ipCls);
        }
        catch (RuntimeException rte) {
            final ConfigProperty configProperty = (ConfigProperty)this.getAnnotation(ip, (Class)ConfigProperty.class);
            throw new RuntimeException("Error while converting property '" + configProperty.name() + "' happening in bean " + ip.getBean(), rte);
        }
    }
}
