// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.future;

import java.util.Arrays;
import javax.enterprise.inject.spi.AnnotatedMethod;
import javax.enterprise.inject.spi.AnnotatedType;
import org.apache.deltaspike.core.api.future.Futureable;
import org.apache.deltaspike.core.impl.util.AnnotatedMethods;
import java.lang.reflect.InvocationTargetException;
import org.apache.deltaspike.core.util.ExceptionUtils;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import javax.interceptor.InvocationContext;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ConcurrentMap;
import javax.enterprise.inject.spi.BeanManager;
import javax.inject.Inject;
import java.util.LinkedList;
import java.lang.reflect.Method;
import javax.enterprise.context.Dependent;
import org.apache.deltaspike.core.spi.future.FutureableStrategy;

@Dependent
public class DefaultFutureableStrategy implements FutureableStrategy
{
    private static final Class<?> COMPLETION_STAGE;
    private static final Class<?> COMPLETABLE_FUTURE;
    private static final Method COMPLETABLE_STAGE_TO_FUTURE;
    private static final boolean IS_WELD1;
    private static final ThreadLocal<LinkedList<CallKey>> STACK;
    @Inject
    private ThreadPoolManager manager;
    @Inject
    private BeanManager beanManager;
    private transient ConcurrentMap<Method, ExecutorService> configByMethod;
    
    public DefaultFutureableStrategy() {
        this.configByMethod = new ConcurrentHashMap<Method, ExecutorService>();
    }
    
    public Object execute(final InvocationContext ic) throws Exception {
        CallKey invocationKey;
        if (DefaultFutureableStrategy.IS_WELD1) {
            invocationKey = new CallKey(ic);
            final LinkedList<CallKey> stack = DefaultFutureableStrategy.STACK.get();
            if (!stack.isEmpty() && stack.getLast().equals(invocationKey)) {
                try {
                    return ic.proceed();
                }
                finally {
                    if (stack.isEmpty()) {
                        DefaultFutureableStrategy.STACK.remove();
                    }
                }
            }
        }
        else {
            invocationKey = null;
        }
        final Class<?> returnType = ic.getMethod().getReturnType();
        if (!Future.class.isAssignableFrom(returnType) && !Void.TYPE.isAssignableFrom(returnType) && (DefaultFutureableStrategy.COMPLETION_STAGE == null || !DefaultFutureableStrategy.COMPLETION_STAGE.isAssignableFrom(returnType))) {
            throw new IllegalArgumentException("Return type should be a CompletableStage, Future or Void");
        }
        if (this.configByMethod == null) {
            synchronized (this) {
                if (this.configByMethod == null) {
                    this.configByMethod = new ConcurrentHashMap<Method, ExecutorService>();
                }
            }
        }
        final Callable<Object> invocation = new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                Label_0030: {
                    if (DefaultFutureableStrategy.IS_WELD1) {
                        final LinkedList<CallKey> callStack = DefaultFutureableStrategy.STACK.get();
                        callStack.add(invocationKey);
                        break Label_0030;
                    }
                    final LinkedList<CallKey> callStack = null;
                    try {
                        final Object proceed = ic.proceed();
                        final Future<?> future = (DefaultFutureableStrategy.COMPLETION_STAGE == null || !DefaultFutureableStrategy.COMPLETION_STAGE.isInstance(proceed)) ? Future.class.cast(proceed) : Future.class.cast(DefaultFutureableStrategy.COMPLETABLE_STAGE_TO_FUTURE.invoke(proceed, new Object[0]));
                        return future.get();
                    }
                    catch (InvocationTargetException e) {
                        throw ExceptionUtils.throwAsRuntimeException(e.getCause());
                    }
                    catch (Exception e2) {
                        throw ExceptionUtils.throwAsRuntimeException((Throwable)e2);
                    }
                    finally {
                        if (DefaultFutureableStrategy.IS_WELD1) {
                            callStack.removeLast();
                            if (callStack.isEmpty()) {
                                DefaultFutureableStrategy.STACK.remove();
                            }
                        }
                    }
                }
            }
        };
        final ExecutorService pool = this.getOrCreatePool(ic);
        if (Void.TYPE.isAssignableFrom(returnType)) {
            pool.submit(invocation);
            return null;
        }
        if (DefaultFutureableStrategy.COMPLETABLE_FUTURE == null) {
            return pool.submit(invocation);
        }
        final Object completableFuture = DefaultFutureableStrategy.COMPLETABLE_FUTURE.newInstance();
        pool.submit(new J8PromiseCompanionTask<Object>(completableFuture, invocation));
        return completableFuture;
    }
    
    protected ExecutorService getOrCreatePool(final InvocationContext ic) {
        final Method method = ic.getMethod();
        ExecutorService executorService = this.configByMethod.get(method);
        if (executorService == null) {
            final AnnotatedType<?> annotatedType = (AnnotatedType<?>)this.beanManager.createAnnotatedType((Class)method.getDeclaringClass());
            final AnnotatedMethod<?> annotatedMethod = AnnotatedMethods.findMethod(annotatedType, method);
            final Futureable methodConfig = (Futureable)annotatedMethod.getAnnotation((Class)Futureable.class);
            final ExecutorService instance = this.manager.find(((Futureable)((methodConfig == null) ? annotatedType.getAnnotation((Class)Futureable.class) : methodConfig)).value());
            this.configByMethod.putIfAbsent(method, instance);
            executorService = instance;
        }
        return executorService;
    }
    
    static {
        STACK = new ThreadLocal<LinkedList<CallKey>>() {
            @Override
            protected LinkedList<CallKey> initialValue() {
                return new LinkedList<CallKey>();
            }
        };
        Class<?> completionStageClass = null;
        Class<?> completableFutureClass = null;
        Method completionStageClassToCompletableFuture = null;
        try {
            final ClassLoader classLoader = ClassLoader.getSystemClassLoader();
            completionStageClass = classLoader.loadClass("java.util.concurrent.CompletionStage");
            completionStageClassToCompletableFuture = completionStageClass.getMethod("toCompletableFuture", (Class<?>[])new Class[0]);
            completableFutureClass = classLoader.loadClass("java.util.concurrent.CompletableFuture");
        }
        catch (Exception ex) {}
        COMPLETION_STAGE = completionStageClass;
        COMPLETABLE_FUTURE = completableFutureClass;
        COMPLETABLE_STAGE_TO_FUTURE = completionStageClassToCompletableFuture;
        boolean weld1 = false;
        try {
            final Class<?> impl = Thread.currentThread().getContextClassLoader().loadClass("org.jboss.weld.manager.BeanManagerImpl");
            final Package pck = impl.getPackage();
            weld1 = ("Weld Implementation".equals(pck.getImplementationTitle()) && pck.getSpecificationVersion() != null && pck.getSpecificationVersion().startsWith("1.1."));
        }
        catch (Throwable t) {}
        IS_WELD1 = weld1;
    }
    
    private static final class CallKey
    {
        private final InvocationContext ic;
        private final int hash;
        
        private CallKey(final InvocationContext ic) {
            this.ic = ic;
            final Object[] parameters = ic.getParameters();
            this.hash = ic.getMethod().hashCode() + ((parameters == null) ? 0 : Arrays.hashCode(parameters));
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || (o != null && this.getClass() == o.getClass() && this.equals(this.ic, CallKey.class.cast(o).ic));
        }
        
        @Override
        public int hashCode() {
            return this.hash;
        }
        
        private boolean equals(final InvocationContext ic1, final InvocationContext ic2) {
            final Object[] parameters1 = ic1.getParameters();
            final Object[] parameters2 = ic2.getParameters();
            return ic2.getMethod().equals(ic1.getMethod()) && (parameters1 == parameters2 || (parameters1 != null && parameters2 != null && Arrays.equals(parameters1, ic2.getParameters())));
        }
    }
}
