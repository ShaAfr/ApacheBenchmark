// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.config;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public abstract class PropertiesConfigSource extends BaseConfigSource
{
    private final Properties properties;
    
    protected PropertiesConfigSource(final Properties properties) {
        this.properties = properties;
    }
    
    public String getPropertyValue(final String key) {
        return this.properties.getProperty(key);
    }
    
    public Map<String, String> getProperties() {
        final Map<String, String> result = new HashMap<String, String>();
        for (final String propertyName : this.properties.stringPropertyNames()) {
            result.put(propertyName, this.properties.getProperty(propertyName));
        }
        return result;
    }
    
    public boolean isScannable() {
        return true;
    }
}
