// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.lock;

import java.util.concurrent.locks.Lock;
import javax.interceptor.InvocationContext;
import javax.inject.Inject;
import javax.enterprise.context.Dependent;
import org.apache.deltaspike.core.spi.lock.LockedStrategy;

@Dependent
public class DefaultLockedStrategy implements LockedStrategy
{
    @Inject
    private LockSupplierStorage lockSupplierStorage;
    
    public Object execute(final InvocationContext ic) throws Exception {
        final Lock lock = this.lockSupplierStorage.getLockSupplier(ic).get();
        try {
            return ic.proceed();
        }
        finally {
            lock.unlock();
        }
    }
}
