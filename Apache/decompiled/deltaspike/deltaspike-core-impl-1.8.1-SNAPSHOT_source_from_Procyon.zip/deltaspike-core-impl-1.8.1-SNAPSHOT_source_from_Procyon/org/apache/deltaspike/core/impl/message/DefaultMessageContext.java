// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import java.util.Collections;
import java.util.Locale;
import org.apache.deltaspike.core.api.message.Message;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import org.apache.deltaspike.core.api.message.LocaleResolver;
import org.apache.deltaspike.core.api.message.MessageResolver;
import javax.inject.Inject;
import org.apache.deltaspike.core.api.message.MessageInterpolator;
import javax.enterprise.inject.Typed;
import javax.enterprise.context.Dependent;
import org.apache.deltaspike.core.api.message.MessageContext;

@Dependent
@Typed({ MessageContext.class })
class DefaultMessageContext implements MessageContext
{
    private static final long serialVersionUID = -110779217295211303L;
    @Inject
    private MessageInterpolator messageInterpolator;
    @Inject
    private MessageResolver messageResolver;
    @Inject
    private LocaleResolver localeResolver;
    private List<String> messageSources;
    
    public DefaultMessageContext() {
        this.messageInterpolator = null;
        this.messageResolver = null;
        this.localeResolver = null;
        this.messageSources = new ArrayList<String>();
    }
    
    public DefaultMessageContext(final MessageContext otherMessageContext) {
        this.messageInterpolator = null;
        this.messageResolver = null;
        this.localeResolver = null;
        this.messageSources = new ArrayList<String>();
        this.messageInterpolator(otherMessageContext.getMessageInterpolator());
        this.localeResolver(otherMessageContext.getLocaleResolver());
        this.messageResolver(otherMessageContext.getMessageResolver());
        this.messageSources.addAll(otherMessageContext.getMessageSources());
    }
    
    public MessageContext clone() {
        return (MessageContext)new DefaultMessageContext((MessageContext)this);
    }
    
    public Message message() {
        return (Message)new DefaultMessage((MessageContext)this);
    }
    
    public MessageContext messageSource(final String... messageSource) {
        final List<String> newMessageSources = new ArrayList<String>();
        for (final String currentMessageSource : messageSource) {
            if (!this.messageSources.contains(currentMessageSource)) {
                newMessageSources.add(currentMessageSource);
            }
        }
        this.messageSources.addAll(0, newMessageSources);
        return (MessageContext)this;
    }
    
    public Locale getLocale() {
        if (this.getLocaleResolver() == null) {
            return Locale.getDefault();
        }
        return this.getLocaleResolver().getLocale();
    }
    
    public LocaleResolver getLocaleResolver() {
        return this.localeResolver;
    }
    
    public List<String> getMessageSources() {
        return Collections.unmodifiableList((List<? extends String>)this.messageSources);
    }
    
    public MessageContext localeResolver(final LocaleResolver localeResolver) {
        this.localeResolver = localeResolver;
        return (MessageContext)this;
    }
    
    public MessageInterpolator getMessageInterpolator() {
        return this.messageInterpolator;
    }
    
    public MessageContext messageInterpolator(final MessageInterpolator messageInterpolator) {
        this.messageInterpolator = messageInterpolator;
        return (MessageContext)this;
    }
    
    public MessageResolver getMessageResolver() {
        return this.messageResolver;
    }
    
    public MessageContext messageResolver(final MessageResolver messageResolver) {
        this.messageResolver = messageResolver;
        return (MessageContext)this;
    }
}
