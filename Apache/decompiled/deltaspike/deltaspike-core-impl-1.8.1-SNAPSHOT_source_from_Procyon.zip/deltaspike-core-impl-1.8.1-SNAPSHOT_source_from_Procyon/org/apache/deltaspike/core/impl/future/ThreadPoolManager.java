// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.future;

import java.util.concurrent.Executors;
import javax.annotation.PreDestroy;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import org.apache.deltaspike.core.api.config.base.CoreBaseConfig;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ConcurrentMap;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ThreadPoolManager
{
    private final ConcurrentMap<String, ExecutorService> pools;
    private volatile ExecutorService defaultPool;
    private volatile boolean closed;
    
    public ThreadPoolManager() {
        this.pools = new ConcurrentHashMap<String, ExecutorService>();
        this.closed = false;
    }
    
    @PreDestroy
    private void shutdown() {
        this.closed = true;
        final long timeout = CoreBaseConfig.TimeoutCustomization.FUTUREABLE_TERMINATION_TIMEOUT_IN_MILLISECONDS;
        for (final ExecutorService es : this.pools.values()) {
            es.shutdown();
            try {
                es.awaitTermination(timeout, TimeUnit.MILLISECONDS);
            }
            catch (InterruptedException e) {
                Thread.interrupted();
            }
        }
        if (this.defaultPool != null) {
            this.defaultPool.shutdown();
            try {
                this.defaultPool.awaitTermination(timeout, TimeUnit.MILLISECONDS);
            }
            catch (InterruptedException e2) {
                Thread.interrupted();
            }
        }
        this.pools.clear();
    }
    
    public ExecutorService find(final String name) {
        if (this.closed) {
            throw new IllegalStateException("Container is shutting down");
        }
        ExecutorService pool = this.pools.get(name);
        if (pool == null) {
            this.ensureDefaultPool();
            pool = this.defaultPool;
        }
        return pool;
    }
    
    private void ensureDefaultPool() {
        if (this.defaultPool == null) {
            synchronized (this) {
                if (this.defaultPool == null) {
                    this.defaultPool = Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors()));
                }
            }
        }
    }
}
