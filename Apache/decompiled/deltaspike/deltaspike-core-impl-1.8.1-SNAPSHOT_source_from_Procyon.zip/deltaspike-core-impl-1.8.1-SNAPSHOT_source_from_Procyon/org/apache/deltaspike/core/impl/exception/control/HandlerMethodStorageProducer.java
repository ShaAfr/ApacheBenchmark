// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.exception.control;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import org.apache.deltaspike.core.impl.exception.control.extension.ExceptionControlExtension;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class HandlerMethodStorageProducer
{
    @Inject
    private ExceptionControlExtension exceptionControlExtension;
    
    @Produces
    @ApplicationScoped
    protected HandlerMethodStorage createHandlerMethodStorage() {
        return new HandlerMethodStorageImpl(this.exceptionControlExtension.getAllExceptionHandlers());
    }
}
