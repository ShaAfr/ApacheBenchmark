// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope;

import javax.annotation.PreDestroy;
import java.util.Iterator;
import org.apache.deltaspike.core.util.context.AbstractContext;
import javax.enterprise.inject.spi.BeanManager;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.deltaspike.core.util.context.ContextualStorage;
import java.util.Map;
import java.io.Serializable;

public abstract class AbstractBeanHolder<K> implements Serializable
{
    private Map<K, ContextualStorage> storageMap;
    private final boolean useConcurrentStorage;
    private final boolean usePassivationCapableStorage;
    
    protected AbstractBeanHolder() {
        this(true, true);
    }
    
    protected AbstractBeanHolder(final boolean useConcurrentStorage, final boolean usePassivationCapableStorage) {
        this.storageMap = new ConcurrentHashMap<K, ContextualStorage>();
        this.useConcurrentStorage = useConcurrentStorage;
        this.usePassivationCapableStorage = usePassivationCapableStorage;
    }
    
    public ContextualStorage getContextualStorage(final BeanManager beanManager, final K key, final boolean createIfNotExist) {
        ContextualStorage contextualStorage = this.storageMap.get(key);
        if (contextualStorage == null && createIfNotExist) {
            contextualStorage = this.createContextualStorage(beanManager, key);
        }
        return contextualStorage;
    }
    
    protected synchronized ContextualStorage createContextualStorage(final BeanManager beanManager, final K key) {
        ContextualStorage contextualStorage = this.storageMap.get(key);
        if (contextualStorage == null) {
            contextualStorage = new ContextualStorage(beanManager, this.useConcurrentStorage, this.usePassivationCapableStorage);
            this.storageMap.put(key, contextualStorage);
        }
        return contextualStorage;
    }
    
    public Map<K, ContextualStorage> getStorageMap() {
        return this.storageMap;
    }
    
    public Map<K, ContextualStorage> forceNewStorage() {
        final Map<K, ContextualStorage> oldStorageMap = this.storageMap;
        this.storageMap = new ConcurrentHashMap<K, ContextualStorage>();
        return oldStorageMap;
    }
    
    @PreDestroy
    public void destroyBeans() {
        final Map<K, ContextualStorage> oldWindowContextStorages = this.forceNewStorage();
        for (final ContextualStorage contextualStorage : oldWindowContextStorages.values()) {
            AbstractContext.destroyAllActive(contextualStorage);
        }
    }
}
