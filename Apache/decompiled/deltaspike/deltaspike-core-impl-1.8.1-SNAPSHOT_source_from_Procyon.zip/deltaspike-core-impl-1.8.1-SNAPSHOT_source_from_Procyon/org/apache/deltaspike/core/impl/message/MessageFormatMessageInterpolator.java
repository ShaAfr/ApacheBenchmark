// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.message;

import java.text.MessageFormat;
import java.util.Locale;
import javax.enterprise.inject.Alternative;
import javax.enterprise.context.ApplicationScoped;
import java.io.Serializable;
import org.apache.deltaspike.core.api.message.MessageInterpolator;

@ApplicationScoped
@Alternative
public class MessageFormatMessageInterpolator implements MessageInterpolator, Serializable
{
    private static final long serialVersionUID = -8854087197813424812L;
    
    public String interpolate(final String messageTemplate, final Serializable[] arguments, final Locale locale) {
        final MessageFormat messageFormat = new MessageFormat(messageTemplate, locale);
        return messageFormat.format(arguments);
    }
}
