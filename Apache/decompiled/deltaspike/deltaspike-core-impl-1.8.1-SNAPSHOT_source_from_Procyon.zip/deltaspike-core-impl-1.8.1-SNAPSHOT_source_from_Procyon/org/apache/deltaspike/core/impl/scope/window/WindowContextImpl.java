// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.deltaspike.core.impl.scope.window;

import org.apache.deltaspike.core.api.scope.WindowScoped;
import java.lang.annotation.Annotation;
import javax.enterprise.context.ContextNotActiveException;
import javax.enterprise.context.spi.Contextual;
import org.apache.deltaspike.core.util.context.ContextualStorage;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.Typed;
import org.apache.deltaspike.core.spi.scope.window.WindowContext;
import org.apache.deltaspike.core.util.context.AbstractContext;

@Typed
public class WindowContextImpl extends AbstractContext implements WindowContext
{
    private WindowIdHolder windowIdHolder;
    private WindowBeanHolder windowBeanHolder;
    private BeanManager beanManager;
    
    public WindowContextImpl(final BeanManager beanManager) {
        super(beanManager);
        this.beanManager = beanManager;
    }
    
    public void init(final WindowBeanHolder windowBeanHolder, final WindowIdHolder windowIdHolder) {
        this.windowBeanHolder = windowBeanHolder;
        this.windowIdHolder = windowIdHolder;
    }
    
    public void activateWindow(final String windowId) {
        this.windowIdHolder.setWindowId(windowId);
    }
    
    public String getCurrentWindowId() {
        return this.windowIdHolder.getWindowId();
    }
    
    public boolean closeWindow(final String windowId) {
        if (windowId == null) {
            return false;
        }
        final ContextualStorage windowStorage = this.windowBeanHolder.getStorageMap().remove(windowId);
        if (windowStorage != null) {
            if (windowId.equals(this.windowIdHolder.getWindowId())) {
                this.windowIdHolder.setWindowId(null);
            }
            AbstractContext.destroyAllActive(windowStorage);
        }
        return windowStorage != null;
    }
    
    protected ContextualStorage getContextualStorage(final Contextual<?> contextual, final boolean createIfNotExist) {
        final String windowId = this.getCurrentWindowId();
        if (windowId == null) {
            throw new ContextNotActiveException("WindowContext: no windowId set for the current Thread yet!");
        }
        return this.windowBeanHolder.getContextualStorage(this.beanManager, windowId, createIfNotExist);
    }
    
    public Class<? extends Annotation> getScope() {
        return (Class<? extends Annotation>)WindowScoped.class;
    }
    
    public boolean isActive() {
        final String windowId = this.getCurrentWindowId();
        return windowId != null;
    }
}
