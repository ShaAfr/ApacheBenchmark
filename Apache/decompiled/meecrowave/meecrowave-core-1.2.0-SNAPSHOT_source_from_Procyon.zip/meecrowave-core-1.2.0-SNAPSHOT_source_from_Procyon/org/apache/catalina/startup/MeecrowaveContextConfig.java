// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.catalina.startup;

import java.nio.charset.StandardCharsets;
import java.io.File;
import org.apache.meecrowave.logging.tomcat.LogFacade;
import java.util.function.Consumer;
import java.lang.annotation.Annotation;
import javax.servlet.annotation.HandlesTypes;
import java.net.URL;
import org.apache.tomcat.util.descriptor.web.WebXml;
import org.apache.catalina.WebResource;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import org.xml.sax.InputSource;
import org.apache.catalina.Context;
import org.apache.catalina.LifecycleEvent;
import java.util.HashSet;
import java.lang.reflect.Modifier;
import java.util.stream.Stream;
import javax.servlet.annotation.WebListener;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import org.apache.webbeans.corespi.scanner.xbean.CdiArchive;
import java.util.function.Function;
import org.apache.tomcat.JarScanner;
import java.util.Optional;
import org.apache.tomcat.JarScanFilter;
import org.apache.webbeans.config.WebBeansContext;
import org.apache.meecrowave.openwebbeans.OWBTomcatWebScannerService;
import java.util.Set;
import java.util.Collections;
import java.io.IOException;
import java.util.HashMap;
import org.apache.meecrowave.watching.ReloadOnChangeController;
import org.apache.webbeans.corespi.scanner.xbean.OwbAnnotationFinder;
import javax.servlet.ServletContainerInitializer;
import java.util.Collection;
import java.util.Map;
import org.apache.meecrowave.Meecrowave;

public class MeecrowaveContextConfig extends ContextConfig
{
    private static final byte[] DEFAULT_WEB_XML;
    private final Meecrowave.Builder configuration;
    private final Map<String, Collection<Class<?>>> webClasses;
    private final boolean fixDocBase;
    private final ServletContainerInitializer intializer;
    private OwbAnnotationFinder finder;
    private ReloadOnChangeController watcher;
    
    public MeecrowaveContextConfig(final Meecrowave.Builder configuration, final boolean fixDocBase, final ServletContainerInitializer intializer) {
        this.webClasses = new HashMap<String, Collection<Class<?>>>();
        this.configuration = configuration;
        this.fixDocBase = fixDocBase;
        this.intializer = intializer;
    }
    
    protected void fixDocBase() throws IOException {
        if (!this.fixDocBase) {
            return;
        }
        super.fixDocBase();
    }
    
    protected void webConfig() {
        if (this.context.getServletContext().getAttribute("meecrowave.configuration") == null) {
            this.context.getServletContext().setAttribute("meecrowave.configuration", (Object)this.configuration);
            this.context.addServletContainerInitializer(this.intializer, (Set)Collections.emptySet());
        }
        if (!this.configuration.isTomcatScanning()) {
            super.webConfig();
            return;
        }
        final ClassLoader loader = this.context.getLoader().getClassLoader();
        final Thread thread = Thread.currentThread();
        final ClassLoader old = thread.getContextClassLoader();
        thread.setContextClassLoader(loader);
        try {
            final OWBTomcatWebScannerService scannerService = OWBTomcatWebScannerService.class.cast(WebBeansContext.getInstance().getScannerService());
            scannerService.setFilter(Optional.ofNullable(this.context.getJarScanner()).map((Function<? super JarScanner, ? extends JarScanFilter>)JarScanner::getJarScanFilter).orElse(null), this.context.getServletContext());
            scannerService.setDocBase(this.context.getDocBase());
            scannerService.setShared(this.configuration.getSharedLibraries());
            if (this.configuration.getWatcherBouncing() > 0) {
                this.watcher = new ReloadOnChangeController(this.context, this.configuration.getWatcherBouncing());
                scannerService.setFileVisitor(f -> this.watcher.register(f));
            }
            scannerService.scan();
            (this.finder = scannerService.getFinder()).link();
            final CdiArchive archive = CdiArchive.class.cast(this.finder.getArchive());
            Stream.of((Class[])new Class[] { WebServlet.class, WebFilter.class, WebListener.class }).forEach(marker -> this.finder.findAnnotatedClasses(marker).stream().filter(c -> !Modifier.isAbstract(c.getModifiers()) && Modifier.isPublic(c.getModifiers())).forEach(webComponent -> this.webClasses.computeIfAbsent(((Map.Entry)archive.classesByUrl().entrySet().stream().filter(e -> e.getValue().getClassNames().contains(webComponent.getName())).findFirst().get()).getKey(), k -> new HashSet()).add(webComponent)));
        }
        finally {
            thread.setContextClassLoader(old);
        }
        try {
            super.webConfig();
        }
        finally {
            this.webClasses.clear();
            this.finder = null;
        }
    }
    
    public void lifecycleEvent(final LifecycleEvent event) {
        super.lifecycleEvent(event);
        if (this.watcher != null && this.watcher.shouldRun() && Context.class.cast(event.getLifecycle()) == this.context) {
            if ("after_start".equals(event.getType())) {
                this.watcher.start();
            }
            else if ("before_stop".equals(event.getType())) {
                this.watcher.close();
            }
        }
    }
    
    protected InputSource getGlobalWebXmlSource() {
        return Optional.ofNullable(super.getGlobalWebXmlSource()).orElse(new InputSource(new ByteArrayInputStream(MeecrowaveContextConfig.DEFAULT_WEB_XML)));
    }
    
    protected void processAnnotationsWebResource(final WebResource webResource, final WebXml fragment, final boolean handlesTypesOnly, final Map<String, ContextConfig.JavaClassCacheEntry> javaClassCache) {
        if (this.configuration.isTomcatScanning()) {
            this.webClasses.keySet().stream().filter(k -> k.endsWith("/WEB-INF/classes")).forEach(k -> this.processClasses(fragment, handlesTypesOnly, javaClassCache, k));
        }
    }
    
    protected void processAnnotationsUrl(final URL url, final WebXml fragment, final boolean handlesTypesOnly, final Map<String, ContextConfig.JavaClassCacheEntry> javaClassCache) {
        if (!this.configuration.isTomcatScanning()) {
            return;
        }
        this.processClasses(fragment, handlesTypesOnly, javaClassCache, url.toExternalForm());
    }
    
    protected void processServletContainerInitializers() {
        if (!this.configuration.isTomcatScanning()) {
            return;
        }
        try {
            final HashSet<Class<?>> classes;
            HandlesTypes ht;
            final Throwable t2;
            Throwable e;
            Class<? extends Annotation> annotation;
            final Set<Object> set;
            new WebappServiceLoader(this.context).load((Class)ServletContainerInitializer.class).forEach(sci -> {
                classes = new HashSet<Class<?>>();
                this.initializerClassMap.put(sci, classes);
                try {
                    ht = sci.getClass().getAnnotation(HandlesTypes.class);
                }
                catch (Exception | NoClassDefFoundError ex) {
                    e = t2;
                    return;
                }
                if (ht != null) {
                    Stream.of((Class[])ht.value()).forEach(t -> {
                        if (t.isAnnotation()) {
                            annotation = Class.class.cast(t);
                            this.finder.findAnnotatedClasses((Class)annotation).forEach(set::add);
                        }
                        else if (t.isInterface()) {
                            this.finder.findImplementations(t).forEach(set::add);
                        }
                        else {
                            this.finder.findSubclasses(t).forEach(set::add);
                        }
                    });
                }
            });
        }
        catch (IOException e2) {
            this.ok = false;
        }
    }
    
    private void processClasses(final WebXml fragment, final boolean handlesTypesOnly, final Map<String, ContextConfig.JavaClassCacheEntry> javaClassCache, final String key) {
        Collection<Class<?>> classes = this.webClasses.remove(key);
        if (classes == null && key.endsWith(".jar") && key.startsWith("file:")) {
            classes = this.webClasses.remove("jar:" + key + "!/");
        }
        if (classes != null && !classes.isEmpty()) {
            final ClassLoader loader = this.context.getLoader().getClassLoader();
            final ClassLoader classLoader;
            InputStream stream;
            final Throwable t2;
            classes.forEach(c -> {
                try {
                    stream = classLoader.getResourceAsStream(c.getName().replace('.', '/') + ".class");
                    try {
                        super.processAnnotationsStream(stream, fragment, handlesTypesOnly, (Map)javaClassCache);
                    }
                    catch (Throwable t) {
                        throw t;
                    }
                    finally {
                        if (stream != null) {
                            if (t2 != null) {
                                try {
                                    stream.close();
                                }
                                catch (Throwable exception) {
                                    t2.addSuppressed(exception);
                                }
                            }
                            else {
                                stream.close();
                            }
                        }
                    }
                }
                catch (IOException e) {
                    new LogFacade(MeecrowaveContextConfig.class.getName()).error("Can't parse " + c);
                }
            });
        }
    }
    
    static {
        DEFAULT_WEB_XML = "<web-app version=\"3.1\" />".getBytes(StandardCharsets.UTF_8);
    }
}
