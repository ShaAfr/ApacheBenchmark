// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.service;

import java.util.function.Function;

public interface ValueTransformer extends Function<String, String>
{
    String name();
}
