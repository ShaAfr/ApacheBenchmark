// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.api;

import org.apache.catalina.Context;
import org.apache.catalina.Host;
import org.apache.catalina.connector.Connector;

public class StopListening extends ListeningBase
{
    public StopListening(final Connector connector, final Host host, final Context context) {
        super(connector, host, context);
    }
}
