// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.tomcat;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import java.beans.PropertyChangeListener;
import org.apache.catalina.Context;
import org.apache.catalina.Loader;
import org.apache.catalina.util.LifecycleBase;

public class ProvidedLoader extends LifecycleBase implements Loader
{
    private static final ClassLoader MOCK;
    private final ClassLoader delegate;
    private Context context;
    private int mockReturns;
    
    public ProvidedLoader(final ClassLoader loader, final boolean wrap) {
        this.mockReturns = -1;
        final ClassLoader impl = (loader == null) ? ClassLoader.getSystemClassLoader() : loader;
        this.delegate = (wrap ? new TomcatSettersClassLoader(impl) : impl);
    }
    
    public void backgroundProcess() {
    }
    
    public ClassLoader getClassLoader() {
        if (this.mockReturns > 0) {
            --this.mockReturns;
            return ProvidedLoader.MOCK;
        }
        return this.delegate;
    }
    
    public Context getContext() {
        return this.context;
    }
    
    public void setContext(final Context context) {
        this.context = context;
    }
    
    public boolean modified() {
        return false;
    }
    
    public boolean getDelegate() {
        return false;
    }
    
    public void setDelegate(final boolean delegate) {
    }
    
    public boolean getReloadable() {
        return false;
    }
    
    public void setReloadable(final boolean reloadable) {
    }
    
    public void addPropertyChangeListener(final PropertyChangeListener listener) {
    }
    
    public void removePropertyChangeListener(final PropertyChangeListener listener) {
    }
    
    protected void startInternal() throws LifecycleException {
        this.mockReturns = 4;
        this.setState(LifecycleState.STARTING);
    }
    
    protected void initInternal() throws LifecycleException {
    }
    
    protected void stopInternal() throws LifecycleException {
        this.setState(LifecycleState.STOPPING);
    }
    
    protected void destroyInternal() throws LifecycleException {
    }
    
    static {
        MOCK = new TomcatSettersClassLoader(ProvidedLoader.class.getClassLoader());
    }
    
    public static class TomcatSettersClassLoader extends ClassLoader
    {
        private TomcatSettersClassLoader(final ClassLoader classLoader) {
            super(classLoader);
        }
        
        public void setClearReferencesHttpClientKeepAliveThread(final boolean ignored) {
        }
        
        public void setClearReferencesRmiTargets(final boolean ignored) {
        }
        
        public void setClearReferencesStopThreads(final boolean ignored) {
        }
        
        public void setClearReferencesStopTimerThreads(final boolean ignored) {
        }
    }
}
