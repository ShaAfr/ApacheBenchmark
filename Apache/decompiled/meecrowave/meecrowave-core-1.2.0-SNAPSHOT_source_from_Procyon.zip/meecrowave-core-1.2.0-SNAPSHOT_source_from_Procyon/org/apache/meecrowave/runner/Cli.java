// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.runner;

import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.DefaultParser;
import java.util.stream.StreamSupport;
import java.util.ServiceLoader;
import java.lang.annotation.Annotation;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.catalina.connector.Connector;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import org.apache.xbean.recipe.ObjectRecipe;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.stream.IntStream;
import java.util.function.Predicate;
import java.util.stream.Stream;
import org.apache.meecrowave.runner.cli.CliOption;
import java.lang.reflect.Field;
import java.util.List;
import org.apache.commons.cli.CommandLine;
import org.apache.catalina.Context;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.Optional;
import java.io.File;
import org.apache.meecrowave.Meecrowave;
import javax.enterprise.inject.Vetoed;

@Vetoed
public class Cli implements Runnable
{
    private final String[] args;
    
    public Cli(final String[] args) {
        this.args = args;
    }
    
    @Override
    public void run() {
        final ParsedCommand parsedCommand = new ParsedCommand(this.args).invoke();
        if (parsedCommand.isFailed()) {
            return;
        }
        final Meecrowave.Builder builder = parsedCommand.getBuilder();
        final CommandLine line = parsedCommand.getLine();
        try (final Meecrowave meecrowave = new Meecrowave(builder)) {
            final String ctx = line.getOptionValue("context", "");
            final String fixedCtx = (ctx.isEmpty() || ctx.startsWith("/")) ? ctx : ('/' + ctx);
            final String war = line.getOptionValue("webapp");
            meecrowave.start();
            if (war == null) {
                meecrowave.deployClasspath(new Meecrowave.DeploymentMeta(ctx, Optional.ofNullable(line.getOptionValue("docbase")).map((Function<? super String, ? extends File>)File::new).orElse(null), null));
            }
            else {
                meecrowave.deployWebapp(fixedCtx, new File(war));
            }
            this.doWait(meecrowave, line);
        }
    }
    
    protected void doWait(final Meecrowave meecrowave, final CommandLine line) {
        meecrowave.getTomcat().getServer().await();
    }
    
    public static void main(final String[] args) {
        new Cli(args).run();
    }
    
    public static Meecrowave.Builder create(final String[] args) {
        final ParsedCommand command = new ParsedCommand(args).invoke();
        if (command.isFailed()) {
            return null;
        }
        return command.getBuilder();
    }
    
    private static void bind(final Meecrowave.Builder builder, final CommandLine line, final List<Field> fields, final Object config) {
        final CliOption opt;
        final Optional<String> first;
        String name;
        fields.forEach(f -> {
            opt = f.getAnnotation(CliOption.class);
            first = Stream.of((Stream[])new Stream[] { Stream.of(opt.name()), Stream.of(opt.alias()) }).flatMap(a -> a).filter(line::hasOption).findFirst();
            if (first.isPresent()) {
                name = first.get();
                Optional.ofNullable((f.getType() == Boolean.TYPE) ? Optional.ofNullable(line.getOptionValue(name)).map((Function<? super String, ? extends Boolean>)Boolean::parseBoolean).orElse(true) : toValue(builder, name, line.getOptionValues(name), f.getType())).ifPresent(v -> {
                    if (!f.isAccessible()) {
                        f.setAccessible(true);
                    }
                    try {
                        f.set(config, v);
                    }
                    catch (IllegalAccessException e) {
                        throw new IllegalStateException(e);
                    }
                });
            }
        });
    }
    
    private static Object toValue(final Meecrowave.Builder builder, final String name, final String[] optionValues, final Class<?> type) {
        if (optionValues == null || optionValues.length == 0) {
            return null;
        }
        IntStream.range(0, optionValues.length).forEach(i -> optionValues[i] = builder.getExtension(Meecrowave.ValueTransformers.class).apply(optionValues[i]));
        if (String.class == type) {
            return optionValues[0];
        }
        if (Integer.TYPE == type) {
            return Integer.parseInt(optionValues[0]);
        }
        if (File.class == type) {
            return new File(optionValues[0]);
        }
        if (Properties.class == type) {
            final Properties props = new Properties();
            Stream.of(optionValues).map(v -> v.split("=")).forEach(v -> props.setProperty(v[0], v[1]));
            return props;
        }
        if (Map.class == type) {
            final Map<String, String> props2 = new HashMap<String, String>();
            final String s;
            Stream.of(optionValues).map(v -> v.split("=")).forEach(v -> s = props2.put(v[0], v[1]));
            return props2;
        }
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        switch (name) {
            case "realm": {
                try {
                    final int end = optionValues[0].indexOf(58);
                    if (end < 0) {
                        return loader.loadClass(optionValues[0]).newInstance();
                    }
                    final ObjectRecipe recipe = new ObjectRecipe(optionValues[0].substring(0, end));
                    Stream.of(optionValues[0].substring(end + 1, optionValues[0].length()).split(";")).map(v -> v.split("=")).forEach(v -> recipe.setProperty(v[0], (Object)v[1]));
                    return recipe.create(loader);
                }
                catch (Exception cnfe) {
                    throw new IllegalArgumentException(optionValues[0]);
                }
            }
            case "security-constraint": {
                ObjectRecipe recipe2;
                final ClassLoader classLoader;
                return Stream.of(optionValues).map(item -> {
                    try {
                        recipe2 = new ObjectRecipe((Class)Meecrowave.SecurityConstaintBuilder.class);
                        Stream.of(item.split(";")).map(v -> v.split("=")).forEach(v -> recipe2.setProperty(v[0], (Object)v[1]));
                        return recipe2.create(classLoader);
                    }
                    catch (Exception cnfe2) {
                        throw new IllegalArgumentException(optionValues[0]);
                    }
                }).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
            }
            case "login-config": {
                try {
                    final ObjectRecipe recipe3 = new ObjectRecipe((Class)Meecrowave.LoginConfigBuilder.class);
                    Stream.of(optionValues[0].split(";")).map(v -> v.split("=")).forEach(v -> recipe3.setProperty(v[0], (Object)v[1]));
                    return recipe3.create(loader);
                }
                catch (Exception cnfe) {
                    throw new IllegalArgumentException(optionValues[0]);
                }
            }
            case "connector": {
                int end2;
                Connector connector;
                return Stream.of(optionValues).map(v -> {
                    try {
                        end2 = v.indexOf(58);
                        if (end2 < 0) {
                            return new Connector(v);
                        }
                        else {
                            connector = new Connector(optionValues[0].substring(0, end2));
                            Stream.of(v.substring(end2 + 1, v.length()).split(";")).map(i -> i.split("=")).forEach(i -> connector.setProperty(i[0], i[1]));
                            return connector;
                        }
                    }
                    catch (Exception cnfe3) {
                        throw new IllegalArgumentException(optionValues[0]);
                    }
                }).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
            }
            default: {
                throw new IllegalArgumentException("Unsupported " + name);
            }
        }
    }
    
    private static final class ParsedCommand
    {
        private final String[] args;
        private boolean failed;
        private CommandLine line;
        private Meecrowave.Builder builder;
        
        private ParsedCommand(final String... args) {
            this.args = args;
        }
        
        private static void help(final org.apache.commons.cli.Options options) {
            new HelpFormatter().printHelp("java -jar meecrowave-runner.jar", options);
        }
        
        private static Meecrowave.Builder buildConfig(final CommandLine line, final List<Field> fields, final Map<Object, List<Field>> propertiesOptions) {
            final Meecrowave.Builder config = new Meecrowave.Builder();
            bind(config, line, fields, config);
            final Meecrowave.Builder x0;
            propertiesOptions.forEach((o, f) -> {
                bind(x0, line, f, o);
                x0.setExtension(o.getClass(), o);
                return;
            });
            return config;
        }
        
        boolean isFailed() {
            return this.failed;
        }
        
        public CommandLine getLine() {
            return this.line;
        }
        
        public Meecrowave.Builder getBuilder() {
            return this.builder;
        }
        
        public ParsedCommand invoke() {
            final org.apache.commons.cli.Options options = new org.apache.commons.cli.Options();
            options.addOption((String)null, "help", false, "Show help");
            options.addOption((String)null, "context", true, "The context to use to deploy the webapp");
            options.addOption((String)null, "webapp", true, "Location of the webapp, if not set the classpath will be deployed");
            options.addOption((String)null, "docbase", true, "Location of the docbase for a classpath deployment");
            final List<Field> fields = Stream.of(Meecrowave.Builder.class.getDeclaredFields()).filter(f -> f.isAnnotationPresent(CliOption.class)).collect((Collector<? super Field, ?, List<Field>>)Collectors.toList());
            final Map<Object, List<Field>> propertiesOptions = StreamSupport.stream(ServiceLoader.load(Options.class).spliterator(), false).collect(Collectors.toMap((Function<? super Options, ?>)Function.identity(), o -> Stream.of(o.getClass().getDeclaredFields()).filter(f -> f.isAnnotationPresent(CliOption.class)).collect((Collector<? super Field, ?, List<? super Field>>)Collectors.toList())));
            final CliOption opt;
            final String description;
            final org.apache.commons.cli.Options options2;
            fields.forEach(f -> {
                opt = f.getAnnotation(CliOption.class);
                description = opt.description();
                options2.addOption((String)null, opt.name(), true, description);
                Stream.of(opt.alias()).forEach(a -> options2.addOption((String)null, a, true, description));
                return;
            });
            final CliOption opt2;
            final String description2;
            final org.apache.commons.cli.Options options3;
            propertiesOptions.values().forEach(all -> all.forEach(f -> {
                opt2 = f.getAnnotation(CliOption.class);
                description2 = opt2.description();
                options3.addOption((String)null, opt2.name(), true, description2);
                Stream.of(opt2.alias()).forEach(a -> options3.addOption((String)null, a, true, description2));
            }));
            final CommandLineParser parser = (CommandLineParser)new DefaultParser();
            try {
                this.line = parser.parse(options, this.args, true);
            }
            catch (ParseException exp) {
                help(options);
                this.failed = true;
                return this;
            }
            if (this.line.hasOption("help")) {
                help(options);
                this.failed = true;
                return this;
            }
            this.builder = buildConfig(this.line, fields, propertiesOptions);
            this.failed = false;
            return this;
        }
    }
    
    public interface Options
    {
    }
}
