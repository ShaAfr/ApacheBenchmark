// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave;

import java.net.URLClassLoader;
import javax.xml.parsers.SAXParser;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import java.util.Comparator;
import java.util.TreeMap;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.apache.catalina.Manager;
import org.apache.catalina.session.ManagerBase;
import org.apache.catalina.session.StandardManager;
import org.apache.tomcat.util.descriptor.web.SecurityCollection;
import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
import org.apache.tomcat.util.descriptor.web.LoginConfig;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import java.util.Base64;
import javax.crypto.spec.SecretKeySpec;
import org.apache.meecrowave.service.ValueTransformer;
import org.apache.commons.lang3.text.StrSubstitutor;
import org.apache.commons.lang3.text.StrLookup;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.net.ServerSocket;
import java.util.stream.StreamSupport;
import java.util.ServiceLoader;
import org.apache.johnzon.core.BufferStrategy;
import java.util.LinkedList;
import org.apache.catalina.Realm;
import org.apache.meecrowave.runner.cli.CliOption;
import javax.servlet.ServletException;
import java.util.Objects;
import org.apache.meecrowave.tomcat.TomcatAutoInitializer;
import org.apache.meecrowave.cxf.CxfCdiAutoSetup;
import javax.servlet.ServletContext;
import org.apache.meecrowave.logging.log4j2.Log4j2Shutdown;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Collection;
import java.net.MalformedURLException;
import java.util.ArrayList;
import org.apache.catalina.Valve;
import org.apache.meecrowave.tomcat.LoggingAccessLogPattern;
import org.apache.catalina.LifecycleEvent;
import java.io.Writer;
import java.io.FileWriter;
import java.lang.management.ManagementFactory;
import org.apache.catalina.Service;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.net.URL;
import org.apache.xbean.finder.ResourceFinder;
import org.apache.catalina.startup.Catalina;
import org.apache.catalina.Server;
import java.util.Properties;
import org.apache.meecrowave.io.IO;
import org.apache.catalina.LifecycleException;
import javax.enterprise.inject.spi.InjectionTarget;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.context.spi.Contextual;
import javax.enterprise.inject.spi.AnnotatedType;
import javax.enterprise.inject.spi.CDI;
import java.util.Iterator;
import org.apache.xbean.recipe.ObjectRecipe;
import org.apache.tomcat.util.net.SSLHostConfig;
import org.apache.meecrowave.tomcat.NoDescriptorRegistry;
import org.apache.tomcat.util.modeler.Registry;
import java.lang.annotation.Annotation;
import org.apache.webbeans.config.WebBeansContext;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.Host;
import java.lang.reflect.Field;
import javax.servlet.ServletContainerInitializer;
import org.apache.meecrowave.api.StopListening;
import org.apache.meecrowave.api.StartListening;
import org.apache.catalina.Container;
import java.util.Set;
import java.util.Collections;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.startup.MeecrowaveContextConfig;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.tomcat.JarScanFilter;
import java.io.IOException;
import org.apache.tomcat.InstanceManager;
import org.apache.meecrowave.tomcat.CDIInstanceManager;
import org.apache.tomcat.JarScanner;
import org.apache.meecrowave.openwebbeans.OWBAutoSetup;
import org.apache.catalina.core.StandardContext;
import org.apache.meecrowave.tomcat.OWBJarScanner;
import org.apache.meecrowave.logging.tomcat.LogFacade;
import org.apache.catalina.Context;
import java.util.function.Consumer;
import org.apache.catalina.Loader;
import org.apache.meecrowave.tomcat.ProvidedLoader;
import java.util.Optional;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.startup.Tomcat;
import java.util.HashMap;
import java.util.Map;
import java.io.File;

public class Meecrowave implements AutoCloseable
{
    private final Builder configuration;
    protected File base;
    protected final File ownedTempDir;
    protected InternalTomcat tomcat;
    protected volatile Thread hook;
    private final Map<String, Runnable> contexts;
    private Runnable postTask;
    private boolean clearCatalinaSystemProperties;
    
    public Meecrowave() {
        this(new Builder());
    }
    
    public Meecrowave(final Builder builder) {
        this.contexts = new HashMap<String, Runnable>();
        this.configuration = builder;
        this.ownedTempDir = new File(this.configuration.tempDir, "meecrowave_" + System.nanoTime());
    }
    
    public Builder getConfiguration() {
        return this.configuration;
    }
    
    public File getBase() {
        return this.base;
    }
    
    public Tomcat getTomcat() {
        return this.tomcat;
    }
    
    public boolean isServing() {
        return this.tomcat != null && this.tomcat.getHost().getState() == LifecycleState.STARTED;
    }
    
    public void undeploy(final String root) {
        Optional.ofNullable(this.contexts.remove(root)).ifPresent(Runnable::run);
    }
    
    public Meecrowave deployClasspath(final DeploymentMeta meta) {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        final ClassLoader parentLoader = this.tomcat.getServer().getParentClassLoader();
        if (parentLoader.getParent() == classLoader) {
            classLoader = parentLoader;
        }
        final ProvidedLoader loader = new ProvidedLoader(classLoader, this.configuration.isTomcatWrapLoader());
        final Consumer<Context> builtInCustomizer = c -> c.setLoader((Loader)loader);
        return this.deployWebapp(new DeploymentMeta(meta.context, meta.docBase, Optional.ofNullable(meta.consumer).map(c -> ctx -> {
            builtInCustomizer.accept(ctx);
            c.accept(ctx);
        }).orElse(builtInCustomizer)));
    }
    
    public Meecrowave deployClasspath() {
        return this.deployClasspath("");
    }
    
    public Meecrowave bake(final Consumer<Context> customizer) {
        this.start();
        return this.deployClasspath(new DeploymentMeta("", null, customizer));
    }
    
    public Meecrowave deployClasspath(final String context) {
        return this.deployClasspath(new DeploymentMeta(context, null, null));
    }
    
    public Meecrowave deployWebapp(final File warOrDir) {
        return this.deployWebapp("", warOrDir);
    }
    
    public Meecrowave deployWebapp(final String context, final File warOrDir) {
        return this.deployWebapp(new DeploymentMeta(context, warOrDir, null));
    }
    
    public Meecrowave deployWebapp(final DeploymentMeta meta) {
        if (this.contexts.containsKey(meta.context)) {
            throw new IllegalArgumentException("Already deployed: '" + meta.context + "'");
        }
        final String base = (this.tomcat.getService().findConnectors().length > 0) ? (this.configuration.getActiveProtocol() + "://" + this.tomcat.getHost().getName() + ':' + this.configuration.getActivePort()) : "";
        new LogFacade(Meecrowave.class.getName()).info("--------------- " + base + meta.context);
        final OWBJarScanner scanner = new OWBJarScanner();
        final StandardContext ctx = new StandardContext() {
            public void setApplicationEventListeners(final Object[] listeners) {
                if (listeners == null) {
                    super.setApplicationEventListeners((Object[])null);
                    return;
                }
                for (int i = 1; i < listeners.length; ++i) {
                    if (OWBAutoSetup.EagerBootListener.class.isInstance(listeners[i])) {
                        final Object first = listeners[0];
                        listeners[0] = listeners[i];
                        listeners[i] = first;
                        break;
                    }
                }
                super.setApplicationEventListeners(listeners);
            }
        };
        ctx.setPath(meta.context);
        ctx.setName(meta.context);
        ctx.setJarScanner((JarScanner)scanner);
        ctx.setInstanceManager((InstanceManager)new CDIInstanceManager());
        final StandardContext standardContext;
        Optional.ofNullable(meta.docBase).ifPresent(d -> {
            try {
                standardContext.setDocBase(meta.docBase.getCanonicalPath());
            }
            catch (IOException e3) {
                standardContext.setDocBase(meta.docBase.getAbsolutePath());
            }
            return;
        });
        final OWBJarScanner owbJarScanner;
        final ReflectiveOperationException ex;
        ReflectiveOperationException e;
        Optional.ofNullable(this.configuration.tomcatFilter).ifPresent(filter -> {
            try {
                owbJarScanner.setJarScanFilter(JarScanFilter.class.cast(Thread.currentThread().getContextClassLoader().loadClass(filter).newInstance()));
            }
            catch (ClassNotFoundException | InstantiationException | IllegalAccessException ex3) {
                e = ex;
                throw new IllegalArgumentException(e);
            }
            return;
        });
        final AtomicReference<Runnable> releaseSCI = new AtomicReference<Runnable>();
        final ServletContainerInitializer meecrowaveInitializer = (c, ctx1) -> {
            new OWBAutoSetup().onStartup(c, ctx1);
            new CxfCdiAutoSetup().onStartup(c, ctx1);
            new TomcatAutoInitializer().onStartup(c, ctx1);
            if (this.configuration.isInjectServletContainerInitializer()) {
                Field f;
                try {
                    f = StandardContext.class.getDeclaredField("initializers");
                    if (!f.isAccessible()) {
                        f.setAccessible(true);
                    }
                }
                catch (Exception e) {
                    throw new IllegalStateException("Bad tomcat version", e);
                }
                List<AutoCloseable> cc;
                try {
                    cc = (List<AutoCloseable>)((Map)f.get(ctx)).keySet().stream().filter(i -> !i.getClass().getName().startsWith(Meecrowave.class.getName())).map(i -> {
                        try {
                            return this.inject(i);
                        }
                        catch (IllegalArgumentException iae) {
                            return null;
                        }
                    }).filter(Objects::nonNull).collect(Collectors.toList());
                }
                catch (IllegalAccessException e2) {
                    throw new IllegalStateException("Can't read initializers", e2);
                }
                releaseSCI.set(() -> cc.forEach(closeable -> {
                    try {
                        closeable.close();
                    }
                    catch (Exception e3) {
                        throw new IllegalStateException(e3);
                    }
                }));
            }
        };
        ctx.addLifecycleListener((LifecycleListener)new MeecrowaveContextConfig(this.configuration, meta.docBase != null, meecrowaveInitializer));
        ctx.addLifecycleListener(event -> {
            final String type = event.getType();
            switch (type) {
                case "after_start": {
                    ctx.getResources().setCachingAllowed(this.configuration.webResourceCached);
                    break;
                }
                case "before_init": {
                    ctx.getServletContext().setAttribute("meecrowave.configuration", (Object)this.configuration);
                    ctx.getServletContext().setAttribute("meecrowave.instance", (Object)this);
                    if (this.configuration.loginConfig != null) {
                        ctx.setLoginConfig(this.configuration.loginConfig.build());
                    }
                    for (final SecurityConstaintBuilder sc : this.configuration.securityConstraints) {
                        ctx.addConstraint(sc.build());
                    }
                    if (this.configuration.webXml != null) {
                        ctx.getServletContext().setAttribute("org.apache.catalina.deploy.alt_dd", (Object)this.configuration.webXml);
                        break;
                    }
                    break;
                }
            }
        });
        ctx.addLifecycleListener((LifecycleListener)new Tomcat.FixContextListener());
        ctx.addServletContainerInitializer(meecrowaveInitializer, (Set)Collections.emptySet());
        if (this.configuration.isUseTomcatDefaults()) {
            ctx.setSessionTimeout(30);
            ctx.addWelcomeFile("index.html");
            ctx.addWelcomeFile("index.htm");
            try {
                final Field mimesField = Tomcat.class.getDeclaredField("DEFAULT_MIME_MAPPINGS");
                if (!mimesField.isAccessible()) {
                    mimesField.setAccessible(true);
                }
                final String[] defaultMimes = String[].class.cast(mimesField.get(null));
                int i = 0;
                while (i < defaultMimes.length) {
                    ctx.addMimeMapping(defaultMimes[i++], defaultMimes[i++]);
                }
            }
            catch (NoSuchFieldException | IllegalAccessException ex4) {
                final ReflectiveOperationException ex2;
                final ReflectiveOperationException e2 = ex2;
                throw new IllegalStateException("Incompatible Tomcat", e2);
            }
        }
        Optional.ofNullable(meta.consumer).ifPresent(c -> c.accept(ctx));
        final Host host = this.tomcat.getHost();
        host.addChild((Container)ctx);
        final ClassLoader classLoader = ctx.getLoader().getClassLoader();
        if (host.getState().isAvailable()) {
            this.fire(new StartListening(this.findFirstConnector(), host, (Context)ctx), classLoader);
        }
        final Host host2;
        final Context context;
        final ClassLoader classLoader2;
        final AtomicReference<T> atomicReference;
        this.contexts.put(meta.context, () -> {
            if (host2.getState().isAvailable()) {
                this.fire(new StopListening(this.findFirstConnector(), host2, context), classLoader2);
            }
            Optional.ofNullable((Object)atomicReference.get()).ifPresent(Runnable::run);
            this.tomcat.getHost().removeChild((Container)context);
            return;
        });
        return this;
    }
    
    public Meecrowave bake() {
        return this.bake("");
    }
    
    public Meecrowave bake(final String ctx) {
        this.start();
        return this.deployClasspath(ctx);
    }
    
    public Meecrowave start() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: invokespecial   java/util/HashMap.<init>:()V
        //     7: astore_1        /* systemPropsToRestore */
        //     8: aload_0         /* this */
        //     9: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //    12: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.getMeecrowaveProperties:()Ljava/lang/String;
        //    15: ifnull          48
        //    18: ldc             "meecrowave.properties"
        //    20: aload_0         /* this */
        //    21: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //    24: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.getMeecrowaveProperties:()Ljava/lang/String;
        //    27: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    30: ifne            48
        //    33: aload_0         /* this */
        //    34: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //    37: aload_0         /* this */
        //    38: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //    41: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.getMeecrowaveProperties:()Ljava/lang/String;
        //    44: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.loadFrom:(Ljava/lang/String;)Lorg/apache/meecrowave/Meecrowave$Builder;
        //    47: pop            
        //    48: aload_0         /* this */
        //    49: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //    52: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.isUseLog4j2JulLogManager:()Z
        //    55: ifeq            66
        //    58: ldc             "java.util.logging.manager"
        //    60: ldc             "org.apache.logging.log4j.jul.LogManager"
        //    62: invokestatic    java/lang/System.setProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //    65: pop            
        //    66: aload_0         /* this */
        //    67: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //    70: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$500:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //    73: ifeq            131
        //    76: aload_0         /* this */
        //    77: aload_1         /* systemPropsToRestore */
        //    78: ldc             "log4j.shutdownHookEnabled"
        //    80: ldc             "false"
        //    82: invokespecial   org/apache/meecrowave/Meecrowave.setSystemProperty:(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
        //    85: aload_0         /* this */
        //    86: aload_1         /* systemPropsToRestore */
        //    87: ldc             "openwebbeans.logging.factory"
        //    89: ldc             Lorg/apache/meecrowave/logging/openwebbeans/Log4j2LoggerFactory;.class
        //    91: invokevirtual   java/lang/Class.getName:()Ljava/lang/String;
        //    94: invokespecial   org/apache/meecrowave/Meecrowave.setSystemProperty:(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
        //    97: aload_0         /* this */
        //    98: aload_1         /* systemPropsToRestore */
        //    99: ldc             "org.apache.cxf.Logger"
        //   101: ldc             Lorg/apache/meecrowave/logging/jul/Log4j2Logger;.class
        //   103: invokevirtual   java/lang/Class.getName:()Ljava/lang/String;
        //   106: invokespecial   org/apache/meecrowave/Meecrowave.setSystemProperty:(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
        //   109: aload_0         /* this */
        //   110: aload_1         /* systemPropsToRestore */
        //   111: ldc             "org.apache.tomcat.Logger"
        //   113: ldc             Lorg/apache/meecrowave/logging/tomcat/Log4j2Log;.class
        //   115: invokevirtual   java/lang/Class.getName:()Ljava/lang/String;
        //   118: invokespecial   org/apache/meecrowave/Meecrowave.setSystemProperty:(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
        //   121: aload_0         /* this */
        //   122: aload_1         /* systemPropsToRestore */
        //   123: invokedynamic   BootstrapMethod #9, run:(Ljava/util/Map;)Ljava/lang/Runnable;
        //   128: putfield        org/apache/meecrowave/Meecrowave.postTask:Ljava/lang/Runnable;
        //   131: aload_0         /* this */
        //   132: aload_0         /* this */
        //   133: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   136: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.isTomcatNoJmx:()Z
        //   139: invokespecial   org/apache/meecrowave/Meecrowave.setupJmx:(Z)V
        //   142: aload_0         /* this */
        //   143: ldc             "catalina.base"
        //   145: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;)Ljava/lang/String;
        //   148: ifnonnull       163
        //   151: ldc             "catalina.home"
        //   153: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;)Ljava/lang/String;
        //   156: ifnonnull       163
        //   159: iconst_1       
        //   160: goto            164
        //   163: iconst_0       
        //   164: putfield        org/apache/meecrowave/Meecrowave.clearCatalinaSystemProperties:Z
        //   167: aload_0         /* this */
        //   168: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   171: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$600:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //   174: ifeq            192
        //   177: aload_0         /* this */
        //   178: new             Lorg/apache/meecrowave/Meecrowave$TomcatWithFastSessionIDs;
        //   181: dup            
        //   182: aconst_null    
        //   183: invokespecial   org/apache/meecrowave/Meecrowave$TomcatWithFastSessionIDs.<init>:(Lorg/apache/meecrowave/Meecrowave$1;)V
        //   186: putfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //   189: goto            204
        //   192: aload_0         /* this */
        //   193: new             Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //   196: dup            
        //   197: aconst_null    
        //   198: invokespecial   org/apache/meecrowave/Meecrowave$InternalTomcat.<init>:(Lorg/apache/meecrowave/Meecrowave$1;)V
        //   201: putfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //   204: aload_0         /* this */
        //   205: new             Ljava/io/File;
        //   208: dup            
        //   209: aload_0         /* this */
        //   210: invokespecial   org/apache/meecrowave/Meecrowave.newBaseDir:()Ljava/lang/String;
        //   213: invokespecial   java/io/File.<init>:(Ljava/lang/String;)V
        //   216: putfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   219: aload_0         /* this */
        //   220: aload_0         /* this */
        //   221: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   224: ldc             "conf"
        //   226: invokespecial   org/apache/meecrowave/Meecrowave.createDirectory:(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
        //   229: astore_2        /* conf */
        //   230: aload_0         /* this */
        //   231: aload_0         /* this */
        //   232: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   235: ldc             "lib"
        //   237: invokespecial   org/apache/meecrowave/Meecrowave.createDirectory:(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
        //   240: pop            
        //   241: aload_0         /* this */
        //   242: aload_0         /* this */
        //   243: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   246: ldc             "logs"
        //   248: invokespecial   org/apache/meecrowave/Meecrowave.createDirectory:(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
        //   251: pop            
        //   252: aload_0         /* this */
        //   253: aload_0         /* this */
        //   254: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   257: ldc             "temp"
        //   259: invokespecial   org/apache/meecrowave/Meecrowave.createDirectory:(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
        //   262: pop            
        //   263: aload_0         /* this */
        //   264: aload_0         /* this */
        //   265: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   268: ldc             "work"
        //   270: invokespecial   org/apache/meecrowave/Meecrowave.createDirectory:(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
        //   273: pop            
        //   274: aload_0         /* this */
        //   275: aload_0         /* this */
        //   276: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   279: ldc             "webapps"
        //   281: invokespecial   org/apache/meecrowave/Meecrowave.createDirectory:(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
        //   284: pop            
        //   285: aload_0         /* this */
        //   286: aload_2         /* conf */
        //   287: aload_0         /* this */
        //   288: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   291: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$900:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //   294: invokespecial   org/apache/meecrowave/Meecrowave.synchronize:(Ljava/io/File;Ljava/lang/String;)V
        //   297: aload_0         /* this */
        //   298: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   301: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1000:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Properties;
        //   304: astore_2        /* props */
        //   305: aconst_null    
        //   306: astore_3        /* substitutor */
        //   307: aload_2         /* props */
        //   308: invokevirtual   java/util/Properties.stringPropertyNames:()Ljava/util/Set;
        //   311: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //   316: astore          4
        //   318: aload           4
        //   320: invokeinterface java/util/Iterator.hasNext:()Z
        //   325: ifeq            462
        //   328: aload           4
        //   330: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   335: checkcast       Ljava/lang/String;
        //   338: astore          s
        //   340: aload_2         /* props */
        //   341: aload           s
        //   343: invokevirtual   java/util/Properties.getProperty:(Ljava/lang/String;)Ljava/lang/String;
        //   346: astore          v
        //   348: aload           v
        //   350: ifnull          459
        //   353: aload           v
        //   355: ldc             "${"
        //   357: invokevirtual   java/lang/String.contains:(Ljava/lang/CharSequence;)Z
        //   360: ifeq            459
        //   363: aload_3         /* substitutor */
        //   364: ifnonnull       446
        //   367: new             Ljava/util/HashMap;
        //   370: dup            
        //   371: invokespecial   java/util/HashMap.<init>:()V
        //   374: astore          placeHolders
        //   376: aload           placeHolders
        //   378: ldc             "meecrowave.embedded.http"
        //   380: aload_0         /* this */
        //   381: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   384: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1100:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //   387: invokestatic    java/lang/Integer.toString:(I)Ljava/lang/String;
        //   390: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   395: pop            
        //   396: aload           placeHolders
        //   398: ldc             "meecrowave.embedded.https"
        //   400: aload_0         /* this */
        //   401: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   404: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1200:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //   407: invokestatic    java/lang/Integer.toString:(I)Ljava/lang/String;
        //   410: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   415: pop            
        //   416: aload           placeHolders
        //   418: ldc             "meecrowave.embedded.stop"
        //   420: aload_0         /* this */
        //   421: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   424: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1300:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //   427: invokestatic    java/lang/Integer.toString:(I)Ljava/lang/String;
        //   430: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   435: pop            
        //   436: new             Lorg/apache/commons/lang3/text/StrSubstitutor;
        //   439: dup            
        //   440: aload           placeHolders
        //   442: invokespecial   org/apache/commons/lang3/text/StrSubstitutor.<init>:(Ljava/util/Map;)V
        //   445: astore_3        /* substitutor */
        //   446: aload_2         /* props */
        //   447: aload           s
        //   449: aload_3         /* substitutor */
        //   450: aload           v
        //   452: invokevirtual   org/apache/commons/lang3/text/StrSubstitutor.replace:(Ljava/lang/String;)Ljava/lang/String;
        //   455: invokevirtual   java/util/Properties.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   458: pop            
        //   459: goto            318
        //   462: new             Ljava/io/File;
        //   465: dup            
        //   466: aload_0         /* this */
        //   467: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   470: ldc             "conf"
        //   472: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   475: astore          conf
        //   477: new             Ljava/io/File;
        //   480: dup            
        //   481: aload_0         /* this */
        //   482: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   485: ldc             "webapps"
        //   487: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   490: astore          webapps
        //   492: aload_0         /* this */
        //   493: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //   496: aload_0         /* this */
        //   497: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //   500: invokevirtual   java/io/File.getAbsolutePath:()Ljava/lang/String;
        //   503: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.setBaseDir:(Ljava/lang/String;)V
        //   506: aload_0         /* this */
        //   507: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //   510: aload_0         /* this */
        //   511: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   514: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1400:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //   517: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.setHostname:(Ljava/lang/String;)V
        //   520: aload_0         /* this */
        //   521: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   524: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1500:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/io/File;
        //   527: ifnull          1256
        //   530: new             Ljava/io/File;
        //   533: dup            
        //   534: aload           conf
        //   536: ldc             "server.xml"
        //   538: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   541: astore          file
        //   543: aload           file
        //   545: aload_0         /* this */
        //   546: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   549: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1500:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/io/File;
        //   552: invokevirtual   java/io/File.equals:(Ljava/lang/Object;)Z
        //   555: ifne            787
        //   558: new             Ljava/io/FileInputStream;
        //   561: dup            
        //   562: aload_0         /* this */
        //   563: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   566: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1500:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/io/File;
        //   569: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   572: astore          is
        //   574: aconst_null    
        //   575: astore          9
        //   577: new             Ljava/io/FileOutputStream;
        //   580: dup            
        //   581: aload           file
        //   583: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/File;)V
        //   586: astore          fos
        //   588: aconst_null    
        //   589: astore          11
        //   591: aload           is
        //   593: aload           fos
        //   595: invokestatic    org/apache/meecrowave/io/IO.copy:(Ljava/io/InputStream;Ljava/io/OutputStream;)V
        //   598: aload           fos
        //   600: ifnull          685
        //   603: aload           11
        //   605: ifnull          628
        //   608: aload           fos
        //   610: invokevirtual   java/io/FileOutputStream.close:()V
        //   613: goto            685
        //   616: astore          12
        //   618: aload           11
        //   620: aload           12
        //   622: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //   625: goto            685
        //   628: aload           fos
        //   630: invokevirtual   java/io/FileOutputStream.close:()V
        //   633: goto            685
        //   636: astore          12
        //   638: aload           12
        //   640: astore          11
        //   642: aload           12
        //   644: athrow         
        //   645: astore          13
        //   647: aload           fos
        //   649: ifnull          682
        //   652: aload           11
        //   654: ifnull          677
        //   657: aload           fos
        //   659: invokevirtual   java/io/FileOutputStream.close:()V
        //   662: goto            682
        //   665: astore          14
        //   667: aload           11
        //   669: aload           14
        //   671: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //   674: goto            682
        //   677: aload           fos
        //   679: invokevirtual   java/io/FileOutputStream.close:()V
        //   682: aload           13
        //   684: athrow         
        //   685: aload           is
        //   687: ifnull          772
        //   690: aload           9
        //   692: ifnull          715
        //   695: aload           is
        //   697: invokevirtual   java/io/InputStream.close:()V
        //   700: goto            772
        //   703: astore          10
        //   705: aload           9
        //   707: aload           10
        //   709: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //   712: goto            772
        //   715: aload           is
        //   717: invokevirtual   java/io/InputStream.close:()V
        //   720: goto            772
        //   723: astore          10
        //   725: aload           10
        //   727: astore          9
        //   729: aload           10
        //   731: athrow         
        //   732: astore          15
        //   734: aload           is
        //   736: ifnull          769
        //   739: aload           9
        //   741: ifnull          764
        //   744: aload           is
        //   746: invokevirtual   java/io/InputStream.close:()V
        //   749: goto            769
        //   752: astore          16
        //   754: aload           9
        //   756: aload           16
        //   758: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //   761: goto            769
        //   764: aload           is
        //   766: invokevirtual   java/io/InputStream.close:()V
        //   769: aload           15
        //   771: athrow         
        //   772: goto            787
        //   775: astore          e
        //   777: new             Ljava/lang/IllegalStateException;
        //   780: dup            
        //   781: aload           e
        //   783: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/Throwable;)V
        //   786: athrow         
        //   787: aload           file
        //   789: invokestatic    org/apache/meecrowave/Meecrowave$QuickServerXmlParser.access$1600:(Ljava/io/File;)Lorg/apache/meecrowave/Meecrowave$QuickServerXmlParser;
        //   792: astore          ports
        //   794: aload_0         /* this */
        //   795: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   798: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1700:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //   801: ifeq            839
        //   804: aload_0         /* this */
        //   805: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   808: aload           ports
        //   810: invokevirtual   org/apache/meecrowave/Meecrowave$QuickServerXmlParser.http:()Ljava/lang/String;
        //   813: invokestatic    java/lang/Integer.parseInt:(Ljava/lang/String;)I
        //   816: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1102:(Lorg/apache/meecrowave/Meecrowave$Builder;I)I
        //   819: pop            
        //   820: aload_0         /* this */
        //   821: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   824: aload           ports
        //   826: invokestatic    org/apache/meecrowave/Meecrowave$QuickServerXmlParser.access$1800:(Lorg/apache/meecrowave/Meecrowave$QuickServerXmlParser;)Ljava/lang/String;
        //   829: invokestatic    java/lang/Integer.parseInt:(Ljava/lang/String;)I
        //   832: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1302:(Lorg/apache/meecrowave/Meecrowave$Builder;I)I
        //   835: pop            
        //   836: goto            1235
        //   839: new             Ljava/util/HashMap;
        //   842: dup            
        //   843: invokespecial   java/util/HashMap.<init>:()V
        //   846: astore          replacements
        //   848: aload           replacements
        //   850: aload           ports
        //   852: invokevirtual   org/apache/meecrowave/Meecrowave$QuickServerXmlParser.http:()Ljava/lang/String;
        //   855: aload_0         /* this */
        //   856: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   859: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1100:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //   862: invokestatic    java/lang/String.valueOf:(I)Ljava/lang/String;
        //   865: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   870: pop            
        //   871: aload           replacements
        //   873: aload           ports
        //   875: invokestatic    org/apache/meecrowave/Meecrowave$QuickServerXmlParser.access$1900:(Lorg/apache/meecrowave/Meecrowave$QuickServerXmlParser;)Ljava/lang/String;
        //   878: aload_0         /* this */
        //   879: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   882: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1200:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //   885: invokestatic    java/lang/String.valueOf:(I)Ljava/lang/String;
        //   888: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   893: pop            
        //   894: aload           replacements
        //   896: aload           ports
        //   898: invokestatic    org/apache/meecrowave/Meecrowave$QuickServerXmlParser.access$1800:(Lorg/apache/meecrowave/Meecrowave$QuickServerXmlParser;)Ljava/lang/String;
        //   901: aload_0         /* this */
        //   902: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //   905: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1300:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //   908: invokestatic    java/lang/String.valueOf:(I)Ljava/lang/String;
        //   911: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   916: pop            
        //   917: new             Ljava/io/FileInputStream;
        //   920: dup            
        //   921: aload           file
        //   923: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   926: astore          stream
        //   928: aconst_null    
        //   929: astore          12
        //   931: aload           stream
        //   933: invokestatic    org/apache/meecrowave/io/IO.toString:(Ljava/io/InputStream;)Ljava/lang/String;
        //   936: astore          serverXmlContent
        //   938: aload           replacements
        //   940: invokeinterface java/util/Map.entrySet:()Ljava/util/Set;
        //   945: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //   950: astore          13
        //   952: aload           13
        //   954: invokeinterface java/util/Iterator.hasNext:()Z
        //   959: ifeq            1004
        //   962: aload           13
        //   964: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   969: checkcast       Ljava/util/Map$Entry;
        //   972: astore          pair
        //   974: aload           serverXmlContent
        //   976: aload           pair
        //   978: invokeinterface java/util/Map$Entry.getKey:()Ljava/lang/Object;
        //   983: checkcast       Ljava/lang/CharSequence;
        //   986: aload           pair
        //   988: invokeinterface java/util/Map$Entry.getValue:()Ljava/lang/Object;
        //   993: checkcast       Ljava/lang/CharSequence;
        //   996: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   999: astore          serverXmlContent
        //  1001: goto            952
        //  1004: aload           stream
        //  1006: ifnull          1091
        //  1009: aload           12
        //  1011: ifnull          1034
        //  1014: aload           stream
        //  1016: invokevirtual   java/io/InputStream.close:()V
        //  1019: goto            1091
        //  1022: astore          13
        //  1024: aload           12
        //  1026: aload           13
        //  1028: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //  1031: goto            1091
        //  1034: aload           stream
        //  1036: invokevirtual   java/io/InputStream.close:()V
        //  1039: goto            1091
        //  1042: astore          13
        //  1044: aload           13
        //  1046: astore          12
        //  1048: aload           13
        //  1050: athrow         
        //  1051: astore          17
        //  1053: aload           stream
        //  1055: ifnull          1088
        //  1058: aload           12
        //  1060: ifnull          1083
        //  1063: aload           stream
        //  1065: invokevirtual   java/io/InputStream.close:()V
        //  1068: goto            1088
        //  1071: astore          18
        //  1073: aload           12
        //  1075: aload           18
        //  1077: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //  1080: goto            1088
        //  1083: aload           stream
        //  1085: invokevirtual   java/io/InputStream.close:()V
        //  1088: aload           17
        //  1090: athrow         
        //  1091: goto            1106
        //  1094: astore          e
        //  1096: new             Ljava/lang/IllegalStateException;
        //  1099: dup            
        //  1100: aload           e
        //  1102: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/Throwable;)V
        //  1105: athrow         
        //  1106: new             Ljava/io/FileOutputStream;
        //  1109: dup            
        //  1110: aload           file
        //  1112: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/File;)V
        //  1115: astore          os
        //  1117: aconst_null    
        //  1118: astore          12
        //  1120: aload           os
        //  1122: aload           serverXmlContent
        //  1124: getstatic       java/nio/charset/StandardCharsets.UTF_8:Ljava/nio/charset/Charset;
        //  1127: invokevirtual   java/lang/String.getBytes:(Ljava/nio/charset/Charset;)[B
        //  1130: invokevirtual   java/io/OutputStream.write:([B)V
        //  1133: aload           os
        //  1135: ifnull          1220
        //  1138: aload           12
        //  1140: ifnull          1163
        //  1143: aload           os
        //  1145: invokevirtual   java/io/OutputStream.close:()V
        //  1148: goto            1220
        //  1151: astore          13
        //  1153: aload           12
        //  1155: aload           13
        //  1157: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //  1160: goto            1220
        //  1163: aload           os
        //  1165: invokevirtual   java/io/OutputStream.close:()V
        //  1168: goto            1220
        //  1171: astore          13
        //  1173: aload           13
        //  1175: astore          12
        //  1177: aload           13
        //  1179: athrow         
        //  1180: astore          19
        //  1182: aload           os
        //  1184: ifnull          1217
        //  1187: aload           12
        //  1189: ifnull          1212
        //  1192: aload           os
        //  1194: invokevirtual   java/io/OutputStream.close:()V
        //  1197: goto            1217
        //  1200: astore          20
        //  1202: aload           12
        //  1204: aload           20
        //  1206: invokevirtual   java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V
        //  1209: goto            1217
        //  1212: aload           os
        //  1214: invokevirtual   java/io/OutputStream.close:()V
        //  1217: aload           19
        //  1219: athrow         
        //  1220: goto            1235
        //  1223: astore          e
        //  1225: new             Ljava/lang/IllegalStateException;
        //  1228: dup            
        //  1229: aload           e
        //  1231: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/Throwable;)V
        //  1234: athrow         
        //  1235: aload_0         /* this */
        //  1236: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1239: aload           file
        //  1241: invokevirtual   java/io/File.getAbsolutePath:()Ljava/lang/String;
        //  1244: invokestatic    org/apache/meecrowave/Meecrowave.createServer:(Ljava/lang/String;)Lorg/apache/catalina/Server;
        //  1247: invokestatic    org/apache/meecrowave/Meecrowave$InternalTomcat.access$2000:(Lorg/apache/meecrowave/Meecrowave$InternalTomcat;Lorg/apache/catalina/Server;)V
        //  1250: iconst_1       
        //  1251: istore          initialized
        //  1253: goto            1278
        //  1256: aload_0         /* this */
        //  1257: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1260: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getServer:()Lorg/apache/catalina/Server;
        //  1263: aload_0         /* this */
        //  1264: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1267: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1300:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //  1270: invokeinterface org/apache/catalina/Server.setPort:(I)V
        //  1275: iconst_0       
        //  1276: istore          initialized
        //  1278: aload_0         /* this */
        //  1279: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1282: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.getSharedLibraries:()Ljava/lang/String;
        //  1285: invokestatic    java/util/Optional.ofNullable:(Ljava/lang/Object;)Ljava/util/Optional;
        //  1288: invokedynamic   BootstrapMethod #10, apply:()Ljava/util/function/Function;
        //  1293: invokevirtual   java/util/Optional.map:(Ljava/util/function/Function;)Ljava/util/Optional;
        //  1296: invokedynamic   BootstrapMethod #11, test:()Ljava/util/function/Predicate;
        //  1301: invokevirtual   java/util/Optional.filter:(Ljava/util/function/Predicate;)Ljava/util/Optional;
        //  1304: aload_0         /* this */
        //  1305: invokedynamic   BootstrapMethod #12, accept:(Lorg/apache/meecrowave/Meecrowave;)Ljava/util/function/Consumer;
        //  1310: invokevirtual   java/util/Optional.ifPresent:(Ljava/util/function/Consumer;)V
        //  1313: iload           initialized
        //  1315: ifne            1444
        //  1318: aload_0         /* this */
        //  1319: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1322: aload_0         /* this */
        //  1323: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1326: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1400:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1329: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.setHostname:(Ljava/lang/String;)V
        //  1332: aload_0         /* this */
        //  1333: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1336: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getEngine:()Lorg/apache/catalina/Engine;
        //  1339: aload_0         /* this */
        //  1340: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1343: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1400:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1346: invokeinterface org/apache/catalina/Engine.setDefaultHost:(Ljava/lang/String;)V
        //  1351: new             Lorg/apache/catalina/core/StandardHost;
        //  1354: dup            
        //  1355: invokespecial   org/apache/catalina/core/StandardHost.<init>:()V
        //  1358: astore          host
        //  1360: aload           host
        //  1362: aload_0         /* this */
        //  1363: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1366: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1400:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1369: invokevirtual   org/apache/catalina/core/StandardHost.setName:(Ljava/lang/String;)V
        //  1372: aload           host
        //  1374: aload           webapps
        //  1376: invokevirtual   java/io/File.getAbsolutePath:()Ljava/lang/String;
        //  1379: invokevirtual   org/apache/catalina/core/StandardHost.setAppBase:(Ljava/lang/String;)V
        //  1382: aload           host
        //  1384: iconst_1       
        //  1385: invokevirtual   org/apache/catalina/core/StandardHost.setUnpackWARs:(Z)V
        //  1388: aload           host
        //  1390: new             Ljava/io/File;
        //  1393: dup            
        //  1394: aload_0         /* this */
        //  1395: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //  1398: ldc             "work"
        //  1400: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //  1403: invokevirtual   java/io/File.getCanonicalPath:()Ljava/lang/String;
        //  1406: invokevirtual   org/apache/catalina/core/StandardHost.setWorkDir:(Ljava/lang/String;)V
        //  1409: goto            1435
        //  1412: astore          e
        //  1414: aload           host
        //  1416: new             Ljava/io/File;
        //  1419: dup            
        //  1420: aload_0         /* this */
        //  1421: getfield        org/apache/meecrowave/Meecrowave.base:Ljava/io/File;
        //  1424: ldc             "work"
        //  1426: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //  1429: invokevirtual   java/io/File.getAbsolutePath:()Ljava/lang/String;
        //  1432: invokevirtual   org/apache/catalina/core/StandardHost.setWorkDir:(Ljava/lang/String;)V
        //  1435: aload_0         /* this */
        //  1436: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1439: aload           host
        //  1441: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.setHost:(Lorg/apache/catalina/Host;)V
        //  1444: aload_0         /* this */
        //  1445: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1448: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.getTomcatAccessLogPattern:()Ljava/lang/String;
        //  1451: invokestatic    java/util/Optional.ofNullable:(Ljava/lang/Object;)Ljava/util/Optional;
        //  1454: aload_0         /* this */
        //  1455: invokedynamic   BootstrapMethod #13, accept:(Lorg/apache/meecrowave/Meecrowave;)Ljava/util/function/Consumer;
        //  1460: invokevirtual   java/util/Optional.ifPresent:(Ljava/util/function/Consumer;)V
        //  1463: aload_0         /* this */
        //  1464: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1467: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2100:(Lorg/apache/meecrowave/Meecrowave$Builder;)Lorg/apache/catalina/Realm;
        //  1470: ifnull          1492
        //  1473: aload_0         /* this */
        //  1474: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1477: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getEngine:()Lorg/apache/catalina/Engine;
        //  1480: aload_0         /* this */
        //  1481: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1484: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2100:(Lorg/apache/meecrowave/Meecrowave$Builder;)Lorg/apache/catalina/Realm;
        //  1487: invokeinterface org/apache/catalina/Engine.setRealm:(Lorg/apache/catalina/Realm;)V
        //  1492: aload_0         /* this */
        //  1493: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1496: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getRawConnector:()Lorg/apache/catalina/connector/Connector;
        //  1499: ifnonnull       1573
        //  1502: aload_0         /* this */
        //  1503: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1506: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2200:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //  1509: ifne            1573
        //  1512: aload_0         /* this */
        //  1513: invokevirtual   org/apache/meecrowave/Meecrowave.createConnector:()Lorg/apache/catalina/connector/Connector;
        //  1516: astore          connector
        //  1518: aload           connector
        //  1520: aload_0         /* this */
        //  1521: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1524: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1100:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //  1527: invokevirtual   org/apache/catalina/connector/Connector.setPort:(I)V
        //  1530: aload           connector
        //  1532: ldc             "connectionTimeout"
        //  1534: invokevirtual   org/apache/catalina/connector/Connector.getAttribute:(Ljava/lang/String;)Ljava/lang/Object;
        //  1537: ifnonnull       1550
        //  1540: aload           connector
        //  1542: ldc             "connectionTimeout"
        //  1544: ldc_w           "3000"
        //  1547: invokevirtual   org/apache/catalina/connector/Connector.setAttribute:(Ljava/lang/String;Ljava/lang/Object;)V
        //  1550: aload_0         /* this */
        //  1551: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1554: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getService:()Lorg/apache/catalina/Service;
        //  1557: aload           connector
        //  1559: invokeinterface org/apache/catalina/Service.addConnector:(Lorg/apache/catalina/connector/Connector;)V
        //  1564: aload_0         /* this */
        //  1565: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1568: aload           connector
        //  1570: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.setConnector:(Lorg/apache/catalina/connector/Connector;)V
        //  1573: aload_0         /* this */
        //  1574: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1577: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2300:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //  1580: ifeq            1783
        //  1583: aload_0         /* this */
        //  1584: invokevirtual   org/apache/meecrowave/Meecrowave.createConnector:()Lorg/apache/catalina/connector/Connector;
        //  1587: astore          httpsConnector
        //  1589: aload           httpsConnector
        //  1591: aload_0         /* this */
        //  1592: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1595: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$1200:(Lorg/apache/meecrowave/Meecrowave$Builder;)I
        //  1598: invokevirtual   org/apache/catalina/connector/Connector.setPort:(I)V
        //  1601: aload           httpsConnector
        //  1603: iconst_1       
        //  1604: invokevirtual   org/apache/catalina/connector/Connector.setSecure:(Z)V
        //  1607: aload           httpsConnector
        //  1609: ldc_w           "SSLEnabled"
        //  1612: ldc_w           "true"
        //  1615: invokevirtual   org/apache/catalina/connector/Connector.setProperty:(Ljava/lang/String;Ljava/lang/String;)Z
        //  1618: pop            
        //  1619: aload           httpsConnector
        //  1621: ldc_w           "sslProtocol"
        //  1624: aload_0         /* this */
        //  1625: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1628: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2400:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1631: invokevirtual   org/apache/catalina/connector/Connector.setProperty:(Ljava/lang/String;Ljava/lang/String;)Z
        //  1634: pop            
        //  1635: aload_0         /* this */
        //  1636: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1639: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2500:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1642: ifnull          1660
        //  1645: aload           httpsConnector
        //  1647: ldc_w           "keystoreFile"
        //  1650: aload_0         /* this */
        //  1651: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1654: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2500:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1657: invokevirtual   org/apache/catalina/connector/Connector.setAttribute:(Ljava/lang/String;Ljava/lang/Object;)V
        //  1660: aload_0         /* this */
        //  1661: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1664: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2600:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1667: ifnull          1685
        //  1670: aload           httpsConnector
        //  1672: ldc_w           "keystorePass"
        //  1675: aload_0         /* this */
        //  1676: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1679: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2600:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1682: invokevirtual   org/apache/catalina/connector/Connector.setAttribute:(Ljava/lang/String;Ljava/lang/Object;)V
        //  1685: aload           httpsConnector
        //  1687: ldc_w           "keystoreType"
        //  1690: aload_0         /* this */
        //  1691: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1694: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2700:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1697: invokevirtual   org/apache/catalina/connector/Connector.setAttribute:(Ljava/lang/String;Ljava/lang/Object;)V
        //  1700: aload_0         /* this */
        //  1701: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1704: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2800:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1707: ifnull          1725
        //  1710: aload           httpsConnector
        //  1712: ldc_w           "clientAuth"
        //  1715: aload_0         /* this */
        //  1716: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1719: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2800:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1722: invokevirtual   org/apache/catalina/connector/Connector.setAttribute:(Ljava/lang/String;Ljava/lang/Object;)V
        //  1725: aload_0         /* this */
        //  1726: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1729: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2900:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1732: ifnull          1750
        //  1735: aload           httpsConnector
        //  1737: ldc_w           "keyAlias"
        //  1740: aload_0         /* this */
        //  1741: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1744: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2900:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/lang/String;
        //  1747: invokevirtual   org/apache/catalina/connector/Connector.setAttribute:(Ljava/lang/String;Ljava/lang/Object;)V
        //  1750: aload_0         /* this */
        //  1751: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1754: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getService:()Lorg/apache/catalina/Service;
        //  1757: aload           httpsConnector
        //  1759: invokeinterface org/apache/catalina/Service.addConnector:(Lorg/apache/catalina/connector/Connector;)V
        //  1764: aload_0         /* this */
        //  1765: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1768: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2200:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //  1771: ifeq            1783
        //  1774: aload_0         /* this */
        //  1775: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1778: aload           httpsConnector
        //  1780: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.setConnector:(Lorg/apache/catalina/connector/Connector;)V
        //  1783: aload_0         /* this */
        //  1784: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1787: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3000:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //  1790: ifeq            1887
        //  1793: aload_0         /* this */
        //  1794: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1797: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2300:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //  1800: ifeq            1834
        //  1803: aload_0         /* this */
        //  1804: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1807: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getService:()Lorg/apache/catalina/Service;
        //  1810: invokeinterface org/apache/catalina/Service.findConnectors:()[Lorg/apache/catalina/connector/Connector;
        //  1815: aload_0         /* this */
        //  1816: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1819: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getService:()Lorg/apache/catalina/Service;
        //  1822: invokeinterface org/apache/catalina/Service.findConnectors:()[Lorg/apache/catalina/connector/Connector;
        //  1827: arraylength    
        //  1828: iconst_1       
        //  1829: isub           
        //  1830: aaload         
        //  1831: goto            1864
        //  1834: aload_0         /* this */
        //  1835: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1838: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getRawConnector:()Lorg/apache/catalina/connector/Connector;
        //  1841: invokestatic    java/util/Optional.ofNullable:(Ljava/lang/Object;)Ljava/util/Optional;
        //  1844: aload_0         /* this */
        //  1845: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1848: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getService:()Lorg/apache/catalina/Service;
        //  1851: invokeinterface org/apache/catalina/Service.findConnectors:()[Lorg/apache/catalina/connector/Connector;
        //  1856: iconst_0       
        //  1857: aaload         
        //  1858: invokevirtual   java/util/Optional.orElse:(Ljava/lang/Object;)Ljava/lang/Object;
        //  1861: checkcast       Lorg/apache/catalina/connector/Connector;
        //  1864: astore          c
        //  1866: aload           c
        //  1868: new             Lorg/apache/coyote/http2/Http2Protocol;
        //  1871: dup            
        //  1872: invokespecial   org/apache/coyote/http2/Http2Protocol.<init>:()V
        //  1875: invokevirtual   org/apache/catalina/connector/Connector.addUpgradeProtocol:(Lorg/apache/coyote/UpgradeProtocol;)V
        //  1878: aload           c
        //  1880: aload_0         /* this */
        //  1881: invokespecial   org/apache/meecrowave/Meecrowave.buildSslHostConfig:()Lorg/apache/tomcat/util/net/SSLHostConfig;
        //  1884: invokevirtual   org/apache/catalina/connector/Connector.addSslHostConfig:(Lorg/apache/tomcat/util/net/SSLHostConfig;)V
        //  1887: aload_0         /* this */
        //  1888: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1891: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3100:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Collection;
        //  1894: invokeinterface java/util/Collection.iterator:()Ljava/util/Iterator;
        //  1899: astore          7
        //  1901: aload           7
        //  1903: invokeinterface java/util/Iterator.hasNext:()Z
        //  1908: ifeq            1940
        //  1911: aload           7
        //  1913: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //  1918: checkcast       Lorg/apache/catalina/connector/Connector;
        //  1921: astore          c
        //  1923: aload_0         /* this */
        //  1924: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1927: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getService:()Lorg/apache/catalina/Service;
        //  1930: aload           c
        //  1932: invokeinterface org/apache/catalina/Service.addConnector:(Lorg/apache/catalina/connector/Connector;)V
        //  1937: goto            1901
        //  1940: aload_0         /* this */
        //  1941: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1944: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2200:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //  1947: ifne            2002
        //  1950: aload_0         /* this */
        //  1951: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1954: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$2300:(Lorg/apache/meecrowave/Meecrowave$Builder;)Z
        //  1957: ifne            2002
        //  1960: aload_0         /* this */
        //  1961: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1964: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3100:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Collection;
        //  1967: invokeinterface java/util/Collection.isEmpty:()Z
        //  1972: ifne            2002
        //  1975: aload_0         /* this */
        //  1976: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  1979: aload_0         /* this */
        //  1980: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  1983: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3100:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Collection;
        //  1986: invokeinterface java/util/Collection.iterator:()Ljava/util/Iterator;
        //  1991: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //  1996: checkcast       Lorg/apache/catalina/connector/Connector;
        //  1999: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.setConnector:(Lorg/apache/catalina/connector/Connector;)V
        //  2002: aload_0         /* this */
        //  2003: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  2006: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3200:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Map;
        //  2009: ifnull          2083
        //  2012: aload_0         /* this */
        //  2013: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  2016: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3200:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Map;
        //  2019: invokeinterface java/util/Map.entrySet:()Ljava/util/Set;
        //  2024: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //  2029: astore          7
        //  2031: aload           7
        //  2033: invokeinterface java/util/Iterator.hasNext:()Z
        //  2038: ifeq            2083
        //  2041: aload           7
        //  2043: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //  2048: checkcast       Ljava/util/Map$Entry;
        //  2051: astore          user
        //  2053: aload_0         /* this */
        //  2054: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  2057: aload           user
        //  2059: invokeinterface java/util/Map$Entry.getKey:()Ljava/lang/Object;
        //  2064: checkcast       Ljava/lang/String;
        //  2067: aload           user
        //  2069: invokeinterface java/util/Map$Entry.getValue:()Ljava/lang/Object;
        //  2074: checkcast       Ljava/lang/String;
        //  2077: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.addUser:(Ljava/lang/String;Ljava/lang/String;)V
        //  2080: goto            2031
        //  2083: aload_0         /* this */
        //  2084: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  2087: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3300:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Map;
        //  2090: ifnull          2202
        //  2093: aload_0         /* this */
        //  2094: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  2097: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3300:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Map;
        //  2100: invokeinterface java/util/Map.entrySet:()Ljava/util/Set;
        //  2105: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //  2110: astore          7
        //  2112: aload           7
        //  2114: invokeinterface java/util/Iterator.hasNext:()Z
        //  2119: ifeq            2202
        //  2122: aload           7
        //  2124: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //  2129: checkcast       Ljava/util/Map$Entry;
        //  2132: astore          user
        //  2134: aload           user
        //  2136: invokeinterface java/util/Map$Entry.getValue:()Ljava/lang/Object;
        //  2141: checkcast       Ljava/lang/String;
        //  2144: ldc_w           " *, *"
        //  2147: invokevirtual   java/lang/String.split:(Ljava/lang/String;)[Ljava/lang/String;
        //  2150: astore          9
        //  2152: aload           9
        //  2154: arraylength    
        //  2155: istore          10
        //  2157: iconst_0       
        //  2158: istore          11
        //  2160: iload           11
        //  2162: iload           10
        //  2164: if_icmpge       2199
        //  2167: aload           9
        //  2169: iload           11
        //  2171: aaload         
        //  2172: astore          role
        //  2174: aload_0         /* this */
        //  2175: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  2178: aload           user
        //  2180: invokeinterface java/util/Map$Entry.getKey:()Ljava/lang/Object;
        //  2185: checkcast       Ljava/lang/String;
        //  2188: aload           role
        //  2190: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.addRole:(Ljava/lang/String;Ljava/lang/String;)V
        //  2193: iinc            11, 1
        //  2196: goto            2160
        //  2199: goto            2112
        //  2202: ldc_w           Lorg/apache/meecrowave/Meecrowave$InstanceCustomizer;.class
        //  2205: invokestatic    java/util/ServiceLoader.load:(Ljava/lang/Class;)Ljava/util/ServiceLoader;
        //  2208: invokevirtual   java/util/ServiceLoader.spliterator:()Ljava/util/Spliterator;
        //  2211: iconst_0       
        //  2212: invokestatic    java/util/stream/StreamSupport.stream:(Ljava/util/Spliterator;Z)Ljava/util/stream/Stream;
        //  2215: aload_0         /* this */
        //  2216: invokedynamic   BootstrapMethod #14, accept:(Lorg/apache/meecrowave/Meecrowave;)Ljava/util/function/Consumer;
        //  2221: invokeinterface java/util/stream/Stream.forEach:(Ljava/util/function/Consumer;)V
        //  2226: aload_0         /* this */
        //  2227: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  2230: invokestatic    org/apache/meecrowave/Meecrowave$Builder.access$3400:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/Collection;
        //  2233: aload_0         /* this */
        //  2234: invokedynamic   BootstrapMethod #15, accept:(Lorg/apache/meecrowave/Meecrowave;)Ljava/util/function/Consumer;
        //  2239: invokeinterface java/util/Collection.forEach:(Ljava/util/function/Consumer;)V
        //  2244: aload_0         /* this */
        //  2245: invokevirtual   org/apache/meecrowave/Meecrowave.beforeStart:()V
        //  2248: iload           initialized
        //  2250: ifne            2260
        //  2253: aload_0         /* this */
        //  2254: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  2257: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.init:()V
        //  2260: aload_0         /* this */
        //  2261: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  2264: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.getHost:()Lorg/apache/catalina/Host;
        //  2267: aload_0         /* this */
        //  2268: invokedynamic   BootstrapMethod #16, lifecycleEvent:(Lorg/apache/meecrowave/Meecrowave;)Lorg/apache/catalina/LifecycleListener;
        //  2273: invokeinterface org/apache/catalina/Host.addLifecycleListener:(Lorg/apache/catalina/LifecycleListener;)V
        //  2278: aload_0         /* this */
        //  2279: getfield        org/apache/meecrowave/Meecrowave.tomcat:Lorg/apache/meecrowave/Meecrowave$InternalTomcat;
        //  2282: invokevirtual   org/apache/meecrowave/Meecrowave$InternalTomcat.start:()V
        //  2285: goto            2300
        //  2288: astore          e
        //  2290: new             Ljava/lang/IllegalStateException;
        //  2293: dup            
        //  2294: aload           e
        //  2296: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/Throwable;)V
        //  2299: athrow         
        //  2300: aload_0         /* this */
        //  2301: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  2304: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.getPidFile:()Ljava/io/File;
        //  2307: invokestatic    java/util/Optional.ofNullable:(Ljava/lang/Object;)Ljava/util/Optional;
        //  2310: invokedynamic   BootstrapMethod #17, accept:()Ljava/util/function/Consumer;
        //  2315: invokevirtual   java/util/Optional.ifPresent:(Ljava/util/function/Consumer;)V
        //  2318: aload_0         /* this */
        //  2319: getfield        org/apache/meecrowave/Meecrowave.configuration:Lorg/apache/meecrowave/Meecrowave$Builder;
        //  2322: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.isUseShutdownHook:()Z
        //  2325: ifeq            2358
        //  2328: aload_0         /* this */
        //  2329: new             Ljava/lang/Thread;
        //  2332: dup            
        //  2333: aload_0         /* this */
        //  2334: invokedynamic   BootstrapMethod #18, run:(Lorg/apache/meecrowave/Meecrowave;)Ljava/lang/Runnable;
        //  2339: ldc_w           "meecrowave-stop-hook"
        //  2342: invokespecial   java/lang/Thread.<init>:(Ljava/lang/Runnable;Ljava/lang/String;)V
        //  2345: putfield        org/apache/meecrowave/Meecrowave.hook:Ljava/lang/Thread;
        //  2348: invokestatic    java/lang/Runtime.getRuntime:()Ljava/lang/Runtime;
        //  2351: aload_0         /* this */
        //  2352: getfield        org/apache/meecrowave/Meecrowave.hook:Ljava/lang/Thread;
        //  2355: invokevirtual   java/lang/Runtime.addShutdownHook:(Ljava/lang/Thread;)V
        //  2358: aload_0         /* this */
        //  2359: areturn        
        //    StackMapTable: 00 51 FC 00 30 07 02 A4 11 FB 00 40 5F 07 02 74 FF 00 00 00 02 07 02 74 07 02 A4 00 02 07 02 74 01 1B 0B FE 00 71 07 02 A5 07 02 A6 07 02 A7 FD 00 7F 07 02 73 07 02 73 F9 00 0C FA 00 02 FF 00 99 00 0C 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 A9 07 02 AA 07 02 AB 07 02 AA 00 01 07 02 AA 0B 47 07 02 AA 48 07 02 AA FF 00 13 00 0E 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 A9 07 02 AA 07 02 AB 07 02 AA 00 07 02 AA 00 01 07 02 AA 0B 04 FF 00 02 00 0A 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 A9 07 02 AA 00 00 51 07 02 AA 0B 47 07 02 AA 48 07 02 AA FF 00 13 00 10 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 A9 07 02 AA 00 00 00 00 00 07 02 AA 00 01 07 02 AA 0B 04 FF 00 02 00 08 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 00 00 42 07 02 AC 0B FC 00 33 07 02 AD FF 00 70 00 0E 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 07 02 73 07 02 A9 07 02 AA 07 02 A7 00 00 FA 00 33 51 07 02 AA 0B FF 00 07 00 0D 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 00 07 02 A9 07 02 AA 00 01 07 02 AA 48 07 02 AA FF 00 13 00 12 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 00 07 02 A9 07 02 AA 00 00 00 00 07 02 AA 00 01 07 02 AA 0B 04 FF 00 02 00 0B 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 07 02 73 00 00 FF 00 02 00 0A 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 00 01 07 02 AC FC 00 0B 07 02 73 FF 00 2C 00 0D 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 07 02 73 07 02 AE 07 02 AA 00 01 07 02 AA 0B 47 07 02 AA 48 07 02 AA FF 00 13 00 14 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 07 02 73 07 02 AE 07 02 AA 00 00 00 00 00 00 07 02 AA 00 01 07 02 AA 0B 04 FF 00 02 00 0B 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 00 07 02 A8 07 02 AD 07 02 A4 07 02 73 00 00 42 07 02 AC F9 00 0B F8 00 14 FC 00 15 01 FF 00 85 00 08 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 01 07 02 AF 00 01 07 02 AC 16 FA 00 08 2F FC 00 39 07 02 B0 FA 00 16 FC 00 56 07 02 B0 18 27 18 FA 00 20 32 5D 07 02 B0 16 FC 00 0D 07 02 A7 FA 00 26 3D FC 00 1C 07 02 A7 FA 00 33 FC 00 1C 07 02 A7 FF 00 2F 00 0C 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 01 07 02 A7 07 02 B1 07 00 6A 01 01 00 00 FF 00 26 00 08 07 02 74 07 02 A4 07 02 A5 07 02 A6 07 02 A8 07 02 A8 01 07 02 A7 00 00 FA 00 02 39 5B 07 02 B2 0B 39
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                    
        //  -----  -----  -----  -----  ----------------------------------------
        //  608    613    616    628    Ljava/lang/Throwable;
        //  591    598    636    645    Ljava/lang/Throwable;
        //  591    598    645    685    Any
        //  657    662    665    677    Ljava/lang/Throwable;
        //  636    647    645    685    Any
        //  695    700    703    715    Ljava/lang/Throwable;
        //  577    685    723    732    Ljava/lang/Throwable;
        //  577    685    732    772    Any
        //  744    749    752    764    Ljava/lang/Throwable;
        //  723    734    732    772    Any
        //  558    772    775    787    Ljava/io/IOException;
        //  1014   1019   1022   1034   Ljava/lang/Throwable;
        //  931    1004   1042   1051   Ljava/lang/Throwable;
        //  931    1004   1051   1091   Any
        //  1063   1068   1071   1083   Ljava/lang/Throwable;
        //  1042   1053   1051   1091   Any
        //  917    1091   1094   1106   Ljava/io/IOException;
        //  1143   1148   1151   1163   Ljava/lang/Throwable;
        //  1120   1133   1171   1180   Ljava/lang/Throwable;
        //  1120   1133   1180   1220   Any
        //  1192   1197   1200   1212   Ljava/lang/Throwable;
        //  1171   1182   1180   1220   Any
        //  1106   1220   1223   1235   Ljava/io/IOException;
        //  1388   1409   1412   1435   Ljava/io/IOException;
        //  2248   2285   2288   2300   Lorg/apache/catalina/LifecycleException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void setSystemProperty(final Map<String, String> backupPropertyMap, final String propertyKey, final String newValue) {
        backupPropertyMap.put(propertyKey, System.getProperty(propertyKey));
        System.setProperty(propertyKey, newValue);
    }
    
    private void broadcastHostEvent(final String event, final Host host) {
        switch (event) {
            case "after_start": {
                final Connector connector = this.findFirstConnector();
                this.findContexts(host).forEach(ctx -> this.fire(new StartListening(connector, host, ctx), ctx.getLoader().getClassLoader()));
                break;
            }
            case "before_stop": {
                final Connector connector = this.findFirstConnector();
                final Connector connector2;
                this.findContexts(host).forEach(ctx -> this.fire(new StopListening(connector2, host, ctx), ctx.getLoader().getClassLoader()));
                break;
            }
        }
    }
    
    private Connector findFirstConnector() {
        return Stream.of(this.tomcat.getServer().findServices()).flatMap(s -> Stream.of(s.findConnectors())).findFirst().orElse(null);
    }
    
    private Stream<Context> findContexts(final Host host) {
        return Stream.of(host.findChildren()).filter(Context.class::isInstance).map((Function<? super Container, ? extends Context>)Context.class::cast).filter(ctx -> ctx.getState().isAvailable());
    }
    
    private <T> void fire(final T event, final ClassLoader classLoader) {
        final Thread thread = Thread.currentThread();
        final ClassLoader loader = thread.getContextClassLoader();
        thread.setContextClassLoader(classLoader);
        try {
            WebBeansContext.currentInstance().getBeanManagerImpl().getEvent().select((Class)Class.class.cast(event.getClass()), new Annotation[0]).fire((Object)event);
        }
        finally {
            thread.setContextClassLoader(loader);
        }
    }
    
    private void setupJmx(final boolean skip) {
        try {
            final Field registry = Registry.class.getDeclaredField("registry");
            registry.setAccessible(true);
            registry.set(null, skip ? new NoDescriptorRegistry() : new Registry());
        }
        catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
    
    private SSLHostConfig buildSslHostConfig() {
        final ObjectRecipe recipe = new ObjectRecipe((Class)SSLHostConfig.class);
        for (final String key : this.configuration.properties.stringPropertyNames()) {
            if (!key.startsWith("connector.sslhostconfig.")) {
                continue;
            }
            final String substring = key.substring("connector.sslhostconfig.".length());
            recipe.setProperty(substring, (Object)this.configuration.properties.getProperty(key));
        }
        return SSLHostConfig.class.cast(recipe.create());
    }
    
    protected void beforeStart() {
    }
    
    protected void beforeStop() {
    }
    
    public <T> AutoCloseable inject(final T instance) {
        final BeanManager bm = CDI.current().getBeanManager();
        final AnnotatedType<?> annotatedType = (AnnotatedType<?>)bm.createAnnotatedType((Class)instance.getClass());
        final InjectionTarget injectionTarget = bm.createInjectionTarget((AnnotatedType)annotatedType);
        final CreationalContext<Object> creationalContext = (CreationalContext<Object>)bm.createCreationalContext((Contextual)null);
        injectionTarget.inject((Object)instance, (CreationalContext)creationalContext);
        return creationalContext::release;
    }
    
    @Override
    public void close() {
        if (this.tomcat == null) {
            return;
        }
        if (this.hook != null) {
            Runtime.getRuntime().removeShutdownHook(this.hook);
            this.hook = null;
        }
        this.beforeStop();
        if (MeecrowaveContainerLoader.class.isInstance(this.tomcat.getServer().getParentClassLoader())) {
            try {
                MeecrowaveContainerLoader.class.cast(this.tomcat.getServer().getParentClassLoader()).close();
            }
            catch (IOException e) {
                new LogFacade(Meecrowave.class.getName()).error(e.getMessage(), e);
            }
        }
        try {
            this.contexts.values().forEach(Runnable::run);
        }
        finally {
            try {
                this.tomcat.stop();
                this.tomcat.destroy();
            }
            catch (LifecycleException e2) {
                throw new IllegalStateException((Throwable)e2);
            }
            finally {
                if (this.clearCatalinaSystemProperties) {
                    Stream.of(new String[] { "catalina.base", "catalina.home" }).forEach(System::clearProperty);
                }
                if (this.configuration.isUseLog4j2JulLogManager()) {
                    System.clearProperty("java.util.logging.manager");
                }
                Optional.ofNullable(this.postTask).ifPresent(Runnable::run);
                this.postTask = null;
                try {
                    if (this.base != null) {
                        IO.delete(this.base);
                    }
                    if (this.ownedTempDir != null) {
                        IO.delete(this.ownedTempDir);
                    }
                }
                catch (IllegalArgumentException ex) {
                    this.base = null;
                    Optional.ofNullable(this.configuration.getPidFile()).ifPresent(File::delete);
                }
                finally {
                    this.base = null;
                    Optional.ofNullable(this.configuration.getPidFile()).ifPresent(File::delete);
                }
            }
        }
    }
    
    protected Connector createConnector() {
        final Properties properties = this.configuration.properties;
        Connector connector;
        if (properties != null) {
            final Map<String, String> attributes = new HashMap<String, String>();
            final ObjectRecipe recipe = new ObjectRecipe((Class)Connector.class);
            for (final String key : properties.stringPropertyNames()) {
                if (!key.startsWith("connector.")) {
                    continue;
                }
                final String substring = key.substring("connector.".length());
                if (substring.startsWith("sslhostconfig.")) {
                    continue;
                }
                if (!substring.startsWith("attributes.")) {
                    recipe.setProperty(substring, (Object)properties.getProperty(key));
                }
                else {
                    attributes.put(substring.substring("attributes.".length()), properties.getProperty(key));
                }
            }
            connector = (recipe.getProperties().isEmpty() ? new Connector() : Connector.class.cast(recipe.create()));
            for (final Map.Entry<String, String> attr : attributes.entrySet()) {
                connector.setAttribute((String)attr.getKey(), (Object)attr.getValue());
            }
        }
        else {
            connector = new Connector();
        }
        return connector;
    }
    
    private static Server createServer(final String serverXml) {
        final Catalina catalina = new Catalina() {
            protected void initDirs() {
            }
            
            protected void initStreams() {
            }
            
            protected void initNaming() {
            }
        };
        catalina.setConfigFile(serverXml);
        catalina.load();
        return catalina.getServer();
    }
    
    private File createDirectory(final File parent, final String directory) {
        final File dir = new File(parent, directory);
        IO.mkdirs(dir);
        return dir;
    }
    
    private void synchronize(final File base, final String resourceBase) {
        if (resourceBase == null) {
            return;
        }
        try {
            final Map<String, URL> urls = (Map<String, URL>)new ResourceFinder("").getResourcesMap(resourceBase);
            for (final Map.Entry<String, URL> u : urls.entrySet()) {
                try (final InputStream is = u.getValue().openStream()) {
                    final File to = new File(base, u.getKey());
                    try (final OutputStream os = new FileOutputStream(to)) {
                        IO.copy(is, os);
                    }
                    if ("server.xml".equals(u.getKey())) {
                        this.configuration.setServerXml(to.getAbsolutePath());
                    }
                }
            }
        }
        catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
    
    private String newBaseDir() {
        final String dir = this.configuration.dir;
        if (dir == null) {
            final File file = new File(Stream.of(new String[] { new File(System.getProperty("meecrowave.base", "."), "temp").getAbsolutePath(), "target", "build", "." }).map((Function<? super String, ? extends File>)File::new).filter(File::isDirectory).findFirst().get(), "meecrowave-" + System.nanoTime());
            IO.mkdirs(file);
            return file.getAbsolutePath();
        }
        final File dirFile = new File(dir);
        if (dirFile.exists()) {
            if (this.base.exists() && this.configuration.deleteBaseOnStartup) {
                IO.delete(this.base);
            }
            return dir;
        }
        IO.mkdirs(dirFile);
        return dirFile.getAbsolutePath();
    }
    
    public void await() {
        this.tomcat.getServer().await();
    }
    
    public static class Builder
    {
        @CliOption(name = "pid-file", description = "A file path to write the process id if the server starts")
        private File pidFile;
        @CliOption(name = "watcher-bouncing", description = "Activate redeployment on directories update using this bouncing.")
        private int watcherBouncing;
        @CliOption(name = "http", description = "HTTP port")
        private int httpPort;
        @CliOption(name = "https", description = "HTTPS port")
        private int httpsPort;
        @CliOption(name = "stop", description = "Shutdown port if used or -1")
        private int stopPort;
        @CliOption(name = "host", description = "Default host")
        private String host;
        @CliOption(name = "dir", description = "Root folder if provided otherwise a fake one is created in tmp-dir")
        private String dir;
        @CliOption(name = "server-xml", description = "Provided server.xml")
        private File serverXml;
        @CliOption(name = "keep-server-xml-as-this", description = "Don't replace ports in server.xml")
        private boolean keepServerXmlAsThis;
        @CliOption(name = "properties", description = "Passthrough properties")
        private Properties properties;
        @CliOption(name = "quick-session", description = "Should an unsecured but fast session id generator be used")
        private boolean quickSession;
        @CliOption(name = "skip-http", description = "Skip HTTP connector")
        private boolean skipHttp;
        @CliOption(name = "ssl", description = "Use HTTPS")
        private boolean ssl;
        @CliOption(name = "keystore-file", description = "HTTPS keystore location")
        private String keystoreFile;
        @CliOption(name = "keystore-password", description = "HTTPS keystore password")
        private String keystorePass;
        @CliOption(name = "keystore-type", description = "HTTPS keystore type")
        private String keystoreType;
        @CliOption(name = "client-auth", description = "HTTPS keystore client authentication")
        private String clientAuth;
        @CliOption(name = "keystore-alias", description = "HTTPS keystore alias")
        private String keyAlias;
        @CliOption(name = "ssl-protocol", description = "HTTPS protocol")
        private String sslProtocol;
        @CliOption(name = "web-xml", description = "Global web.xml")
        private String webXml;
        @CliOption(name = "login-config", description = "web.xml login config")
        private LoginConfigBuilder loginConfig;
        @CliOption(name = "security-constraint", description = "web.xml security constraint")
        private Collection<SecurityConstaintBuilder> securityConstraints;
        @CliOption(name = "realm", description = "realm")
        private Realm realm;
        @CliOption(name = "users", description = "In memory users")
        private Map<String, String> users;
        @CliOption(name = "roles", description = "In memory roles")
        private Map<String, String> roles;
        @CliOption(name = "http2", description = "Activate HTTP 2")
        private boolean http2;
        @CliOption(name = "connector", description = "Custom connectors")
        private final Collection<Connector> connectors;
        @CliOption(name = "tmp-dir", description = "Temporary directory")
        private String tempDir;
        @CliOption(name = "web-resource-cached", description = "Cache web resources")
        private boolean webResourceCached;
        @CliOption(name = "conf", description = "Conf folder to synchronize")
        private String conf;
        @CliOption(name = "delete-on-startup", description = "Should the directory be cleaned on startup if existing")
        private boolean deleteBaseOnStartup;
        @CliOption(name = "jaxrs-mapping", description = "Default jaxrs mapping")
        private String jaxrsMapping;
        @CliOption(name = "cdi-conversation", description = "Should CDI conversation be activated")
        private boolean cdiConversation;
        @CliOption(name = "jaxrs-provider-setup", description = "Should default JAX-RS provider be configured")
        private boolean jaxrsProviderSetup;
        @CliOption(name = "jaxrs-default-providers", description = "If jaxrsProviderSetup is true the list of default providers to load (or defaulting to johnson jsonb and jsonp ones)")
        private String jaxrsDefaultProviders;
        @CliOption(name = "jaxrs-beanvalidation", description = "Should bean validation be activated on JAX-RS endpoint if present in the classpath.")
        private boolean jaxrsAutoActivateBeanValidation;
        @CliOption(name = "jaxrs-log-provider", description = "Should JAX-RS providers be logged")
        private boolean jaxrsLogProviders;
        @CliOption(name = "jsonp-buffer-strategy", description = "JSON-P JAX-RS provider buffer strategy (see johnzon)")
        private String jsonpBufferStrategy;
        @CliOption(name = "jsonp-max-string-length", description = "JSON-P JAX-RS provider max string limit size (see johnzon)")
        private int jsonpMaxStringLen;
        @CliOption(name = "jsonp-read-buffer-length", description = "JSON-P JAX-RS provider read buffer limit size (see johnzon)")
        private int jsonpMaxReadBufferLen;
        @CliOption(name = "jsonp-write-buffer-length", description = "JSON-P JAX-RS provider write buffer limit size (see johnzon)")
        private int jsonpMaxWriteBufferLen;
        @CliOption(name = "jsonp-supports-comment", description = "Should JSON-P JAX-RS provider support comments (see johnzon)")
        private boolean jsonpSupportsComment;
        @CliOption(name = "jsonp-supports-comment", description = "Should JSON-P JAX-RS provider prettify the outputs (see johnzon)")
        private boolean jsonpPrettify;
        @CliOption(name = "jsonb-encoding", description = "Which encoding provider JSON-B should use")
        private String jsonbEncoding;
        @CliOption(name = "jsonb-nulls", description = "Should JSON-B provider serialize nulls")
        private boolean jsonbNulls;
        @CliOption(name = "jsonb-ijson", description = "Should JSON-B provider comply to I-JSON")
        private boolean jsonbIJson;
        @CliOption(name = "jsonb-prettify", description = "Should JSON-B provider prettify the output")
        private boolean jsonbPrettify;
        @CliOption(name = "jsonb-binary-strategy", description = "Should JSON-B provider prettify the output")
        private String jsonbBinaryStrategy;
        @CliOption(name = "jsonb-naming-strategy", description = "Should JSON-B provider prettify the output")
        private String jsonbNamingStrategy;
        @CliOption(name = "jsonb-order-strategy", description = "Should JSON-B provider prettify the output")
        private String jsonbOrderStrategy;
        @CliOption(name = "logging-global-setup", description = "Should logging be configured to use log4j2 (it is global)")
        private boolean loggingGlobalSetup;
        @CliOption(name = "cxf-servlet-params", description = "Init parameters passed to CXF servlet")
        private Map<String, String> cxfServletParams;
        @CliOption(name = "tomcat-scanning", description = "Should Tomcat scanning be used (@HandleTypes, @WebXXX)")
        private boolean tomcatScanning;
        @CliOption(name = "tomcat-default-setup", description = "Add default servlet")
        private boolean tomcatAutoSetup;
        @CliOption(name = "use-shutdown-hook", description = "Use shutdown hook to automatically stop the container on Ctrl+C")
        private boolean useShutdownHook;
        @CliOption(name = "tomcat-filter", description = "A Tomcat JarScanFilter")
        private String tomcatFilter;
        @CliOption(name = "scanning-include", description = "A forced include list of jar names (comma separated values)")
        private String scanningIncludes;
        @CliOption(name = "scanning-exclude", description = "A forced exclude list of jar names (comma separated values)")
        private String scanningExcludes;
        @CliOption(name = "scanning-package-include", description = "A forced include list of packages names (comma separated values)")
        private String scanningPackageIncludes;
        @CliOption(name = "scanning-package-exclude", description = "A forced exclude list of packages names (comma separated values)")
        private String scanningPackageExcludes;
        @CliOption(name = "tomcat-default", description = "Should Tomcat default be set (session timeout, mime mapping etc...)")
        private boolean useTomcatDefaults;
        @CliOption(name = "tomcat-wrap-loader", description = "(Experimental) When deploying a classpath (current classloader), should meecrowave wrap the loader to define another loader identity but still use the same classes and resources.")
        private boolean tomcatWrapLoader;
        @CliOption(name = "tomcat-skip-jmx", description = "(Experimental) Should Tomcat MBeans be skipped.")
        private boolean tomcatNoJmx;
        @CliOption(name = "shared-libraries", description = "A folder containing shared libraries.", alias = { "shared-librairies" })
        private String sharedLibraries;
        @CliOption(name = "log4j2-jul-bridge", description = "Should JUL logs be redirected to Log4j2 - only works before JUL usage.")
        private boolean useLog4j2JulLogManager;
        @CliOption(name = "servlet-container-initializer-injection", description = "Should ServletContainerInitialize support injections.")
        private boolean injectServletContainerInitializer;
        @CliOption(name = "tomcat-access-log-pattern", description = "Activates and configure the access log valve. Value example: '%h %l %u %t \"%r\" %s %b \"%{Referer}i\" \"%{User-Agent}i\"'")
        private String tomcatAccessLogPattern;
        @CliOption(name = "meecrowave-properties", description = "Loads a meecrowave properties, defaults to meecrowave.properties.")
        private String meecrowaveProperties;
        @CliOption(name = "jaxws-support-if-present", description = "Should @WebService CDI beans be deployed if cxf-rt-frontend-jaxws is in the classpath.")
        private boolean jaxwsSupportIfAvailable;
        private final Map<Class<?>, Object> extensions;
        private final Collection<Consumer<Tomcat>> instanceCustomizers;
        
        public Builder() {
            this.watcherBouncing = 500;
            this.httpPort = 8080;
            this.httpsPort = 8443;
            this.stopPort = -1;
            this.host = "localhost";
            this.properties = new Properties();
            this.quickSession = true;
            this.keystoreType = "JKS";
            this.securityConstraints = new LinkedList<SecurityConstaintBuilder>();
            this.connectors = new ArrayList<Connector>();
            this.tempDir = System.getProperty("java.io.tmpdir");
            this.webResourceCached = true;
            this.deleteBaseOnStartup = true;
            this.jaxrsMapping = "/*";
            this.jaxrsProviderSetup = true;
            this.jaxrsAutoActivateBeanValidation = true;
            this.jaxrsLogProviders = false;
            this.jsonpBufferStrategy = BufferStrategy.QUEUE.name();
            this.jsonpMaxStringLen = 65536;
            this.jsonpMaxReadBufferLen = 65536;
            this.jsonpMaxWriteBufferLen = 65536;
            this.jsonpSupportsComment = false;
            this.jsonpPrettify = false;
            this.jsonbEncoding = "UTF-8";
            this.jsonbNulls = false;
            this.jsonbIJson = false;
            this.jsonbPrettify = false;
            this.loggingGlobalSetup = true;
            this.tomcatScanning = true;
            this.tomcatAutoSetup = true;
            this.useShutdownHook = true;
            this.useTomcatDefaults = true;
            this.tomcatWrapLoader = false;
            this.tomcatNoJmx = true;
            this.useLog4j2JulLogManager = (System.getProperty("java.util.logging.manager") == null);
            this.injectServletContainerInitializer = true;
            this.meecrowaveProperties = "meecrowave.properties";
            this.jaxwsSupportIfAvailable = true;
            this.extensions = new HashMap<Class<?>, Object>();
            this.instanceCustomizers = new ArrayList<Consumer<Tomcat>>();
            this.extensions.put(ValueTransformers.class, new ValueTransformers());
            StreamSupport.stream(ServiceLoader.load(ConfigurationCustomizer.class).spliterator(), false).forEach(c -> c.accept(this));
            this.loadFrom(this.meecrowaveProperties);
        }
        
        public <T> T getExtension(final Class<T> extension) {
            final ReflectiveOperationException ex;
            ReflectiveOperationException e;
            return extension.cast(this.extensions.computeIfAbsent(extension, k -> {
                try {
                    return this.bind((Object)k.newInstance());
                }
                catch (InstantiationException | IllegalAccessException ex2) {
                    e = ex;
                    throw new IllegalArgumentException(e);
                }
            }));
        }
        
        public boolean isJaxwsSupportIfAvailable() {
            return this.jaxwsSupportIfAvailable;
        }
        
        public void setJaxwsSupportIfAvailable(final boolean jaxwsSupportIfAvailable) {
            this.jaxwsSupportIfAvailable = jaxwsSupportIfAvailable;
        }
        
        public int getWatcherBouncing() {
            return this.watcherBouncing;
        }
        
        public void setWatcherBouncing(final int watcherBouncing) {
            this.watcherBouncing = watcherBouncing;
        }
        
        public String getTomcatAccessLogPattern() {
            return this.tomcatAccessLogPattern;
        }
        
        public void setTomcatAccessLogPattern(final String tomcatAccessLogPattern) {
            this.tomcatAccessLogPattern = tomcatAccessLogPattern;
        }
        
        public boolean isTomcatNoJmx() {
            return this.tomcatNoJmx;
        }
        
        public void setTomcatNoJmx(final boolean tomcatNoJmx) {
            this.tomcatNoJmx = tomcatNoJmx;
        }
        
        public File getPidFile() {
            return this.pidFile;
        }
        
        public void setPidFile(final File pidFile) {
            this.pidFile = pidFile;
        }
        
        public String getScanningPackageIncludes() {
            return this.scanningPackageIncludes;
        }
        
        public void setScanningPackageIncludes(final String scanningPackageIncludes) {
            this.scanningPackageIncludes = scanningPackageIncludes;
        }
        
        public String getScanningPackageExcludes() {
            return this.scanningPackageExcludes;
        }
        
        public void setScanningPackageExcludes(final String scanningPackageExcludes) {
            this.scanningPackageExcludes = scanningPackageExcludes;
        }
        
        public Builder excludePackages(final String packages) {
            this.setScanningPackageExcludes(packages);
            return this;
        }
        
        public Builder includePackages(final String packages) {
            this.setScanningPackageIncludes(packages);
            return this;
        }
        
        public void setExtension(final Class<?> type, final Object value) {
            this.extensions.put(type, value);
        }
        
        public String getScanningIncludes() {
            return this.scanningIncludes;
        }
        
        public void setScanningIncludes(final String scanningIncludes) {
            this.scanningIncludes = scanningIncludes;
        }
        
        public String getScanningExcludes() {
            return this.scanningExcludes;
        }
        
        public void setScanningExcludes(final String scanningExcludes) {
            this.scanningExcludes = scanningExcludes;
        }
        
        public String getJsonpBufferStrategy() {
            return this.jsonpBufferStrategy;
        }
        
        public String getJsonbEncoding() {
            return this.jsonbEncoding;
        }
        
        public void setJsonbEncoding(final String jsonbEncoding) {
            this.jsonbEncoding = jsonbEncoding;
        }
        
        public boolean isJsonbNulls() {
            return this.jsonbNulls;
        }
        
        public void setJsonbNulls(final boolean jsonbNulls) {
            this.jsonbNulls = jsonbNulls;
        }
        
        public boolean isJsonbIJson() {
            return this.jsonbIJson;
        }
        
        public void setJsonbIJson(final boolean jsonbIJson) {
            this.jsonbIJson = jsonbIJson;
        }
        
        public boolean isJsonbPrettify() {
            return this.jsonbPrettify;
        }
        
        public void setJsonbPrettify(final boolean jsonbPrettify) {
            this.jsonbPrettify = jsonbPrettify;
        }
        
        public String getJsonbBinaryStrategy() {
            return this.jsonbBinaryStrategy;
        }
        
        public void setJsonbBinaryStrategy(final String jsonbBinaryStrategy) {
            this.jsonbBinaryStrategy = jsonbBinaryStrategy;
        }
        
        public String getJsonbNamingStrategy() {
            return this.jsonbNamingStrategy;
        }
        
        public void setJsonbNamingStrategy(final String jsonbNamingStrategy) {
            this.jsonbNamingStrategy = jsonbNamingStrategy;
        }
        
        public String getJsonbOrderStrategy() {
            return this.jsonbOrderStrategy;
        }
        
        public void setJsonbOrderStrategy(final String jsonbOrderStrategy) {
            this.jsonbOrderStrategy = jsonbOrderStrategy;
        }
        
        public void setJsonpBufferStrategy(final String jsonpBufferStrategy) {
            this.jsonpBufferStrategy = jsonpBufferStrategy;
        }
        
        public int getJsonpMaxStringLen() {
            return this.jsonpMaxStringLen;
        }
        
        public void setJsonpMaxStringLen(final int jsonpMaxStringLen) {
            this.jsonpMaxStringLen = jsonpMaxStringLen;
        }
        
        public int getJsonpMaxReadBufferLen() {
            return this.jsonpMaxReadBufferLen;
        }
        
        public void setJsonpMaxReadBufferLen(final int jsonpMaxReadBufferLen) {
            this.jsonpMaxReadBufferLen = jsonpMaxReadBufferLen;
        }
        
        public int getJsonpMaxWriteBufferLen() {
            return this.jsonpMaxWriteBufferLen;
        }
        
        public void setJsonpMaxWriteBufferLen(final int jsonpMaxWriteBufferLen) {
            this.jsonpMaxWriteBufferLen = jsonpMaxWriteBufferLen;
        }
        
        public boolean isJsonpSupportsComment() {
            return this.jsonpSupportsComment;
        }
        
        public void setJsonpSupportsComment(final boolean jsonpSupportsComment) {
            this.jsonpSupportsComment = jsonpSupportsComment;
        }
        
        public boolean isJsonpPrettify() {
            return this.jsonpPrettify;
        }
        
        public void setJsonpPrettify(final boolean jsonpPrettify) {
            this.jsonpPrettify = jsonpPrettify;
        }
        
        public String getSharedLibraries() {
            return this.sharedLibraries;
        }
        
        public Builder sharedLibraries(final String sharedLibraries) {
            this.setSharedLibraries(sharedLibraries);
            return this;
        }
        
        public void setSharedLibraries(final String sharedLibraries) {
            this.sharedLibraries = sharedLibraries;
        }
        
        public boolean isJaxrsLogProviders() {
            return this.jaxrsLogProviders;
        }
        
        public void setJaxrsLogProviders(final boolean jaxrsLogProviders) {
            this.jaxrsLogProviders = jaxrsLogProviders;
        }
        
        public boolean isUseTomcatDefaults() {
            return this.useTomcatDefaults;
        }
        
        public void setUseTomcatDefaults(final boolean useTomcatDefaults) {
            this.useTomcatDefaults = useTomcatDefaults;
        }
        
        public String getTomcatFilter() {
            return this.tomcatFilter;
        }
        
        public void setTomcatFilter(final String tomcatFilter) {
            this.tomcatFilter = tomcatFilter;
        }
        
        public boolean isTomcatScanning() {
            return this.tomcatScanning;
        }
        
        public void setTomcatScanning(final boolean tomcatScanning) {
            this.tomcatScanning = tomcatScanning;
        }
        
        public Map<String, String> getCxfServletParams() {
            return this.cxfServletParams;
        }
        
        public void setCxfServletParams(final Map<String, String> cxfServletParams) {
            this.cxfServletParams = cxfServletParams;
        }
        
        public boolean isLoggingGlobalSetup() {
            return this.loggingGlobalSetup;
        }
        
        public void setLoggingGlobalSetup(final boolean loggingGlobalSetup) {
            this.loggingGlobalSetup = loggingGlobalSetup;
        }
        
        public boolean isJaxrsAutoActivateBeanValidation() {
            return this.jaxrsAutoActivateBeanValidation;
        }
        
        public void setJaxrsAutoActivateBeanValidation(final boolean jaxrsAutoActivateBeanValidation) {
            this.jaxrsAutoActivateBeanValidation = jaxrsAutoActivateBeanValidation;
        }
        
        public boolean isJaxrsProviderSetup() {
            return this.jaxrsProviderSetup;
        }
        
        public void setJaxrsProviderSetup(final boolean jaxrsProviderSetup) {
            this.jaxrsProviderSetup = jaxrsProviderSetup;
        }
        
        public int getHttpPort() {
            return this.httpPort;
        }
        
        public void setHttpPort(final int httpPort) {
            this.httpPort = httpPort;
        }
        
        public int getHttpsPort() {
            return this.httpsPort;
        }
        
        public void setHttpsPort(final int httpsPort) {
            this.httpsPort = httpsPort;
        }
        
        public int getStopPort() {
            return this.stopPort;
        }
        
        public void setStopPort(final int stopPort) {
            this.stopPort = stopPort;
        }
        
        public String getHost() {
            return this.host;
        }
        
        public void setHost(final String host) {
            this.host = host;
        }
        
        public String getDir() {
            return this.dir;
        }
        
        public void setDir(final String dir) {
            this.dir = dir;
        }
        
        public File getServerXml() {
            return this.serverXml;
        }
        
        public void setServerXml(final File serverXml) {
            this.serverXml = serverXml;
        }
        
        public boolean isKeepServerXmlAsThis() {
            return this.keepServerXmlAsThis;
        }
        
        public void setKeepServerXmlAsThis(final boolean keepServerXmlAsThis) {
            this.keepServerXmlAsThis = keepServerXmlAsThis;
        }
        
        public Properties getProperties() {
            return this.properties;
        }
        
        public void setProperties(final Properties properties) {
            this.properties = properties;
        }
        
        public boolean isQuickSession() {
            return this.quickSession;
        }
        
        public void setQuickSession(final boolean quickSession) {
            this.quickSession = quickSession;
        }
        
        public boolean isSkipHttp() {
            return this.skipHttp;
        }
        
        public void setSkipHttp(final boolean skipHttp) {
            this.skipHttp = skipHttp;
        }
        
        public boolean isSsl() {
            return this.ssl;
        }
        
        public void setSsl(final boolean ssl) {
            this.ssl = ssl;
        }
        
        public String getKeystoreFile() {
            return this.keystoreFile;
        }
        
        public void setKeystoreFile(final String keystoreFile) {
            this.keystoreFile = keystoreFile;
        }
        
        public String getKeystorePass() {
            return this.keystorePass;
        }
        
        public void setKeystorePass(final String keystorePass) {
            this.keystorePass = keystorePass;
        }
        
        public String getKeystoreType() {
            return this.keystoreType;
        }
        
        public void setKeystoreType(final String keystoreType) {
            this.keystoreType = keystoreType;
        }
        
        public String getClientAuth() {
            return this.clientAuth;
        }
        
        public void setClientAuth(final String clientAuth) {
            this.clientAuth = clientAuth;
        }
        
        public String getKeyAlias() {
            return this.keyAlias;
        }
        
        public void setKeyAlias(final String keyAlias) {
            this.keyAlias = keyAlias;
        }
        
        public String getSslProtocol() {
            return this.sslProtocol;
        }
        
        public void setSslProtocol(final String sslProtocol) {
            this.sslProtocol = sslProtocol;
        }
        
        public String getWebXml() {
            return this.webXml;
        }
        
        public void setWebXml(final String webXml) {
            this.webXml = webXml;
        }
        
        public LoginConfigBuilder getLoginConfig() {
            return this.loginConfig;
        }
        
        public Builder loginConfig(final LoginConfigBuilder loginConfig) {
            this.setLoginConfig(loginConfig);
            return this;
        }
        
        public void setLoginConfig(final LoginConfigBuilder loginConfig) {
            this.loginConfig = loginConfig;
        }
        
        public Collection<SecurityConstaintBuilder> getSecurityConstraints() {
            return this.securityConstraints;
        }
        
        public Builder securityConstraints(final SecurityConstaintBuilder securityConstraint) {
            (this.securityConstraints = ((this.securityConstraints == null) ? new ArrayList<SecurityConstaintBuilder>() : this.securityConstraints)).add(securityConstraint);
            return this;
        }
        
        public void setSecurityConstraints(final Collection<SecurityConstaintBuilder> securityConstraints) {
            this.securityConstraints = securityConstraints;
        }
        
        public Realm getRealm() {
            return this.realm;
        }
        
        public Builder realm(final Realm realm) {
            this.setRealm(realm);
            return this;
        }
        
        public void setRealm(final Realm realm) {
            this.realm = realm;
        }
        
        public Map<String, String> getUsers() {
            return this.users;
        }
        
        public void setUsers(final Map<String, String> users) {
            this.users = users;
        }
        
        public Map<String, String> getRoles() {
            return this.roles;
        }
        
        public void setRoles(final Map<String, String> roles) {
            this.roles = roles;
        }
        
        public boolean isHttp2() {
            return this.http2;
        }
        
        public void setHttp2(final boolean http2) {
            this.http2 = http2;
        }
        
        public Collection<Connector> getConnectors() {
            return this.connectors;
        }
        
        public String getTempDir() {
            return this.tempDir;
        }
        
        public void setTempDir(final String tempDir) {
            this.tempDir = tempDir;
        }
        
        public boolean isWebResourceCached() {
            return this.webResourceCached;
        }
        
        public void setWebResourceCached(final boolean webResourceCached) {
            this.webResourceCached = webResourceCached;
        }
        
        public String getConf() {
            return this.conf;
        }
        
        public void setConf(final String conf) {
            this.conf = conf;
        }
        
        public boolean isDeleteBaseOnStartup() {
            return this.deleteBaseOnStartup;
        }
        
        public void setDeleteBaseOnStartup(final boolean deleteBaseOnStartup) {
            this.deleteBaseOnStartup = deleteBaseOnStartup;
        }
        
        public String getJaxrsMapping() {
            return this.jaxrsMapping;
        }
        
        public void setJaxrsMapping(final String jaxrsMapping) {
            this.jaxrsMapping = jaxrsMapping;
        }
        
        public boolean isCdiConversation() {
            return this.cdiConversation;
        }
        
        public void setCdiConversation(final boolean cdiConversation) {
            this.cdiConversation = cdiConversation;
        }
        
        public Builder randomHttpPort() {
            try (final ServerSocket serverSocket = new ServerSocket(0)) {
                this.httpPort = serverSocket.getLocalPort();
            }
            catch (IOException e) {
                throw new IllegalStateException(e);
            }
            return this;
        }
        
        public Builder loadFrom(final String resource) {
            try (final InputStream is = this.findStream(resource)) {
                if (is != null) {
                    final Properties config = new Properties() {
                        {
                            this.load(is);
                        }
                    };
                    this.loadFromProperties(config);
                }
                return this;
            }
            catch (IOException e) {
                throw new IllegalStateException(e);
            }
        }
        
        public void setServerXml(final String file) {
            if (file == null) {
                this.serverXml = null;
            }
            else {
                final File sXml = new File(file);
                if (sXml.exists()) {
                    this.serverXml = sXml;
                }
            }
        }
        
        public Builder property(final String key, final String value) {
            this.properties.setProperty(key, value);
            return this;
        }
        
        private InputStream findStream(final String resource) throws FileNotFoundException {
            final InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource);
            if (stream == null) {
                final File file = new File(resource);
                if (file.exists()) {
                    return new FileInputStream(file);
                }
            }
            return stream;
        }
        
        public Builder user(final String name, final String pwd) {
            if (this.users == null) {
                this.users = new HashMap<String, String>();
            }
            this.users.put(name, pwd);
            return this;
        }
        
        public Builder role(final String user, final String roles) {
            if (this.roles == null) {
                this.roles = new HashMap<String, String>();
            }
            this.roles.put(user, roles);
            return this;
        }
        
        public Builder cxfServletParam(final String key, final String value) {
            if (this.cxfServletParams == null) {
                this.cxfServletParams = new HashMap<String, String>();
            }
            this.cxfServletParams.put(key, value);
            return this;
        }
        
        public String getActiveProtocol() {
            return this.isSkipHttp() ? "https" : "http";
        }
        
        public int getActivePort() {
            return this.isSkipHttp() ? this.getHttpsPort() : this.getHttpPort();
        }
        
        public boolean isTomcatAutoSetup() {
            return this.tomcatAutoSetup;
        }
        
        public void setTomcatAutoSetup(final boolean tomcatAutoSetup) {
            this.tomcatAutoSetup = tomcatAutoSetup;
        }
        
        public boolean isUseShutdownHook() {
            return this.useShutdownHook;
        }
        
        public void setUseShutdownHook(final boolean useShutdownHook) {
            this.useShutdownHook = useShutdownHook;
        }
        
        public Builder noShutdownHook() {
            this.setUseShutdownHook(false);
            return this;
        }
        
        public boolean isTomcatWrapLoader() {
            return this.tomcatWrapLoader;
        }
        
        public void setTomcatWrapLoader(final boolean tomcatWrapLoader) {
            this.tomcatWrapLoader = tomcatWrapLoader;
        }
        
        public void addInstanceCustomizer(final Consumer<Tomcat> customizer) {
            this.instanceCustomizers.add(customizer);
        }
        
        public Builder instanceCustomizer(final Consumer<Tomcat> customizer) {
            this.addInstanceCustomizer(customizer);
            return this;
        }
        
        public void addCustomizer(final Consumer<Builder> configurationCustomizer) {
            configurationCustomizer.accept(this);
        }
        
        public String getJaxrsDefaultProviders() {
            return this.jaxrsDefaultProviders;
        }
        
        public void setJaxrsDefaultProviders(final String jaxrsDefaultProviders) {
            this.jaxrsDefaultProviders = jaxrsDefaultProviders;
        }
        
        public boolean isUseLog4j2JulLogManager() {
            return this.useLog4j2JulLogManager;
        }
        
        public void setUseLog4j2JulLogManager(final boolean useLog4j2JulLogManager) {
            this.useLog4j2JulLogManager = useLog4j2JulLogManager;
        }
        
        public void loadFromProperties(final Properties config) {
            final StrSubstitutor strSubstitutor = new StrSubstitutor((StrLookup)new StrLookup<String>() {
                public String lookup(final String key) {
                    final String property = System.getProperty(key);
                    return (property == null) ? config.getProperty(key) : null;
                }
            });
            final ValueTransformers transformers = this.getExtension(ValueTransformers.class);
            for (final String key : config.stringPropertyNames()) {
                final String val2 = config.getProperty(key);
                if (val2 != null) {
                    if (val2.trim().isEmpty()) {
                        continue;
                    }
                    final String newVal = transformers.apply(strSubstitutor.replace(config.getProperty(key)));
                    if (val2.equals(newVal)) {
                        continue;
                    }
                    config.setProperty(key, newVal);
                }
            }
            for (final Field field : Builder.class.getDeclaredFields()) {
                final CliOption annotation = field.getAnnotation(CliOption.class);
                if (annotation != null) {
                    final String name = field.getName();
                    final Field field2;
                    Object toSet;
                    final Object anObject;
                    Stream.of((Stream[])new Stream[] { Stream.of(annotation.name()), Stream.of(annotation.alias()) }).flatMap(a -> a).map((Function<? super Object, ?>)config::getProperty).filter(Objects::nonNull).findAny().ifPresent(val -> {
                        if (field2.getType() == String.class) {
                            toSet = val;
                        }
                        else if (field2.getType() == Integer.TYPE) {
                            if ("httpPort".equals(anObject) && "-1".equals(val)) {
                                this.randomHttpPort();
                                toSet = null;
                            }
                            else {
                                toSet = Integer.parseInt(val);
                            }
                        }
                        else if (field2.getType() == Boolean.TYPE) {
                            toSet = Boolean.parseBoolean(val);
                        }
                        else if (field2.getType() == File.class) {
                            toSet = new File(val);
                        }
                        else {
                            toSet = null;
                        }
                        if (toSet == null) {
                            return;
                        }
                        else {
                            if (!field2.isAccessible()) {
                                field2.setAccessible(true);
                            }
                            try {
                                field2.set(this, toSet);
                            }
                            catch (IllegalAccessException e) {
                                throw new IllegalStateException(e);
                            }
                            return;
                        }
                    });
                }
            }
            for (final String prop : config.stringPropertyNames()) {
                if (prop.startsWith("properties.")) {
                    this.property(prop.substring("properties.".length()), config.getProperty(prop));
                }
                else if (prop.startsWith("users.")) {
                    this.user(prop.substring("users.".length()), config.getProperty(prop));
                }
                else if (prop.startsWith("roles.")) {
                    this.role(prop.substring("roles.".length()), config.getProperty(prop));
                }
                else if (prop.startsWith("cxf.servlet.params.")) {
                    this.cxfServletParam(prop.substring("cxf.servlet.params.".length()), config.getProperty(prop));
                }
                else if (prop.startsWith("connector.")) {
                    this.property(prop, config.getProperty(prop));
                }
                else if (prop.equals("realm")) {
                    final ObjectRecipe recipe = new ObjectRecipe(config.getProperty(prop));
                    for (final String realmConfig : config.stringPropertyNames()) {
                        if (realmConfig.startsWith("realm.")) {
                            recipe.setProperty(realmConfig.substring("realm.".length()), (Object)config.getProperty(realmConfig));
                        }
                    }
                    this.realm = Realm.class.cast(recipe.create());
                }
                else if (prop.equals("login")) {
                    final ObjectRecipe recipe = new ObjectRecipe(LoginConfigBuilder.class.getName());
                    for (final String nestedConfig : config.stringPropertyNames()) {
                        if (nestedConfig.startsWith("login.")) {
                            recipe.setProperty(nestedConfig.substring("login.".length()), (Object)config.getProperty(nestedConfig));
                        }
                    }
                    this.loginConfig = LoginConfigBuilder.class.cast(recipe.create());
                }
                else if (prop.equals("securityConstraint")) {
                    final ObjectRecipe recipe = new ObjectRecipe(SecurityConstaintBuilder.class.getName());
                    for (final String nestedConfig : config.stringPropertyNames()) {
                        if (nestedConfig.startsWith("securityConstraint.")) {
                            recipe.setProperty(nestedConfig.substring("securityConstraint.".length()), (Object)config.getProperty(nestedConfig));
                        }
                    }
                    this.securityConstraints.add(SecurityConstaintBuilder.class.cast(recipe.create()));
                }
                else {
                    if (!prop.equals("configurationCustomizer")) {
                        continue;
                    }
                    final ObjectRecipe recipe = new ObjectRecipe(this.properties.getProperty(prop));
                    for (final String nestedConfig : config.stringPropertyNames()) {
                        if (nestedConfig.startsWith(prop + '.')) {
                            recipe.setProperty(nestedConfig.substring(prop.length() + 2), (Object)config.getProperty(nestedConfig));
                        }
                    }
                    this.addCustomizer(Consumer.class.cast(recipe.create()));
                }
            }
        }
        
        public <T> T bind(final T instance) {
            final ValueTransformers transformers = this.getExtension(ValueTransformers.class);
            Class<?> type = instance.getClass();
            do {
                final CliOption annotation;
                String value;
                final ValueTransformers valueTransformers;
                final String value2;
                final Class<?> t;
                final IllegalArgumentException ex;
                Stream.of(type.getDeclaredFields()).filter(f -> f.isAnnotationPresent(CliOption.class)).forEach(f -> {
                    annotation = f.getAnnotation(CliOption.class);
                    value = this.properties.getProperty(annotation.name());
                    if (value == null) {
                        value = Stream.of(annotation.alias()).map((Function<? super String, ? extends String>)this.properties::getProperty).findFirst().orElse(null);
                        if (value == null) {
                            return;
                        }
                    }
                    value2 = valueTransformers.apply(value);
                    if (!f.isAccessible()) {
                        f.setAccessible(true);
                    }
                    t = f.getType();
                    try {
                        if (t == String.class) {
                            f.set(instance, value2);
                        }
                        else if (t == Integer.TYPE) {
                            f.set(instance, Integer.parseInt(value2));
                        }
                        else if (t == Boolean.TYPE) {
                            f.set(instance, Boolean.parseBoolean(value2));
                        }
                        else {
                            new IllegalArgumentException("Unsupported type " + t);
                            throw ex;
                        }
                    }
                    catch (IllegalAccessException iae) {
                        throw new IllegalStateException(iae);
                    }
                    return;
                });
                type = type.getSuperclass();
            } while (type != Object.class);
            return instance;
        }
        
        public boolean isInjectServletContainerInitializer() {
            return this.injectServletContainerInitializer;
        }
        
        public void setInjectServletContainerInitializer(final boolean injectServletContainerInitializer) {
            this.injectServletContainerInitializer = injectServletContainerInitializer;
        }
        
        public String getMeecrowaveProperties() {
            return this.meecrowaveProperties;
        }
        
        public void setMeecrowaveProperties(final String meecrowaveProperties) {
            this.meecrowaveProperties = meecrowaveProperties;
        }
    }
    
    public static class ValueTransformers implements Function<String, String>
    {
        private final Map<String, ValueTransformer> transformers;
        
        public ValueTransformers() {
            this.transformers = new HashMap<String, ValueTransformer>();
        }
        
        @Override
        public String apply(final String value) {
            if (!value.startsWith("decode:")) {
                return value;
            }
            if (this.transformers.isEmpty()) {
                this.transformers.put("Static3DES", new ValueTransformer() {
                    private final SecretKeySpec key = new SecretKeySpec(new byte[] { 118, 111, -70, 57, 49, 47, 13, 74, -93, -112, 85, -2, 85, 101, 97, 19, 52, -126, 18, 23, -84, 119, 57, 25 }, "DESede");
                    
                    @Override
                    public String name() {
                        return "Static3DES";
                    }
                    
                    @Override
                    public String apply(final String encodedPassword) {
                        Objects.requireNonNull(encodedPassword, "value can't be null");
                        try {
                            final byte[] cipherText = Base64.getDecoder().decode(encodedPassword);
                            final Cipher cipher = Cipher.getInstance("DESede");
                            cipher.init(2, this.key);
                            return new String(cipher.doFinal(cipherText), StandardCharsets.UTF_8);
                        }
                        catch (Exception e) {
                            throw new IllegalArgumentException(e);
                        }
                    }
                });
                for (final ValueTransformer t : ServiceLoader.load(ValueTransformer.class)) {
                    this.transformers.put(t.name(), t);
                }
            }
            final String substring = value.substring("decode:".length());
            final int sep = substring.indexOf(58);
            if (sep < 0) {
                throw new IllegalArgumentException("No transformer algorithm for " + value);
            }
            final String algo = substring.substring(0, sep);
            return Objects.requireNonNull(this.transformers.get(algo), "No ValueTransformer for value '" + value + "'").apply(substring.substring(sep + 1));
        }
    }
    
    public static class LoginConfigBuilder
    {
        private final LoginConfig loginConfig;
        
        public LoginConfigBuilder() {
            this.loginConfig = new LoginConfig();
        }
        
        public void setErrorPage(final String errorPage) {
            this.loginConfig.setErrorPage(errorPage);
        }
        
        public void setLoginPage(final String loginPage) {
            this.loginConfig.setLoginPage(loginPage);
        }
        
        public void setRealmName(final String realmName) {
            this.loginConfig.setRealmName(realmName);
        }
        
        public void setAuthMethod(final String authMethod) {
            this.loginConfig.setAuthMethod(authMethod);
        }
        
        public LoginConfigBuilder errorPage(final String errorPage) {
            this.loginConfig.setErrorPage(errorPage);
            return this;
        }
        
        public LoginConfigBuilder loginPage(final String loginPage) {
            this.loginConfig.setLoginPage(loginPage);
            return this;
        }
        
        public LoginConfigBuilder realmName(final String realmName) {
            this.loginConfig.setRealmName(realmName);
            return this;
        }
        
        public LoginConfigBuilder authMethod(final String authMethod) {
            this.loginConfig.setAuthMethod(authMethod);
            return this;
        }
        
        public LoginConfig build() {
            return this.loginConfig;
        }
        
        public LoginConfigBuilder basic() {
            return this.authMethod("BASIC");
        }
        
        public LoginConfigBuilder digest() {
            return this.authMethod("DIGEST");
        }
        
        public LoginConfigBuilder clientCert() {
            return this.authMethod("CLIENT-CERT");
        }
        
        public LoginConfigBuilder form() {
            return this.authMethod("FORM");
        }
    }
    
    public static class SecurityConstaintBuilder
    {
        private final SecurityConstraint securityConstraint;
        
        public SecurityConstaintBuilder() {
            this.securityConstraint = new SecurityConstraint();
        }
        
        public SecurityConstaintBuilder authConstraint(final boolean authConstraint) {
            this.securityConstraint.setAuthConstraint(authConstraint);
            return this;
        }
        
        public SecurityConstaintBuilder displayName(final String displayName) {
            this.securityConstraint.setDisplayName(displayName);
            return this;
        }
        
        public SecurityConstaintBuilder userConstraint(final String constraint) {
            this.securityConstraint.setUserConstraint(constraint);
            return this;
        }
        
        public SecurityConstaintBuilder addAuthRole(final String authRole) {
            this.securityConstraint.addAuthRole(authRole);
            return this;
        }
        
        public SecurityConstaintBuilder addCollection(final String name, final String pattern, final String... methods) {
            final SecurityCollection collection = new SecurityCollection();
            collection.setName(name);
            collection.addPattern(pattern);
            for (final String httpMethod : methods) {
                collection.addMethod(httpMethod);
            }
            this.securityConstraint.addCollection(collection);
            return this;
        }
        
        public void setAuthConstraint(final boolean authConstraint) {
            this.securityConstraint.setAuthConstraint(authConstraint);
        }
        
        public void setDisplayName(final String displayName) {
            this.securityConstraint.setDisplayName(displayName);
        }
        
        public void setUserConstraint(final String userConstraint) {
            this.securityConstraint.setUserConstraint(userConstraint);
        }
        
        public void setAuthRole(final String authRole) {
            this.addAuthRole(authRole);
        }
        
        public void setCollection(final String value) {
            final String[] split = value.split(":");
            if (split.length != 3 && split.length != 2) {
                throw new IllegalArgumentException("Can't parse " + value + ", syntax is: name:pattern:method1/method2");
            }
            this.addCollection(split[0], split[1], (split.length == 2) ? new String[0] : split[2].split("/"));
        }
        
        public SecurityConstraint build() {
            return this.securityConstraint;
        }
    }
    
    private static class InternalTomcat extends Tomcat
    {
        private Connector connector;
        
        private void server(final Server s) {
            this.server = s;
            this.connector = ((this.server != null && this.server.findServices().length > 0 && this.server.findServices()[0].findConnectors().length > 0) ? this.server.findServices()[0].findConnectors()[0] : null);
        }
        
        Connector getRawConnector() {
            return this.connector;
        }
    }
    
    private static class TomcatWithFastSessionIDs extends InternalTomcat
    {
        public void start() throws LifecycleException {
            final Server server = this.getServer();
            for (final Service service : server.findServices()) {
                final Container e = (Container)service.getContainer();
                for (final Container h : e.findChildren()) {
                    for (final Container c : h.findChildren()) {
                        Manager m = ((Context)c).getManager();
                        if (m == null) {
                            m = (Manager)new StandardManager();
                            Context.class.cast(c).setManager(m);
                        }
                        if (m instanceof ManagerBase) {
                            ManagerBase.class.cast(m).setSecureRandomClass("org.apache.catalina.startup.FastNonSecureRandom");
                        }
                    }
                }
            }
            super.start();
        }
    }
    
    private static class QuickServerXmlParser extends DefaultHandler
    {
        private static final SAXParserFactory FACTORY;
        private static final String STOP_KEY = "STOP";
        private static final String HTTP_KEY = "HTTP";
        private static final String SECURED_SUFFIX = "S";
        private static final String HOST_KEY = "host";
        private static final String DEFAULT_CONNECTOR_KEY = "HTTP";
        private static final String DEFAULT_HTTP_PORT = "8080";
        private static final String DEFAULT_HTTPS_PORT = "8443";
        private static final String DEFAULT_STOP_PORT = "8005";
        private static final String DEFAULT_HOST = "localhost";
        private final Map<String, String> values;
        
        private QuickServerXmlParser(final boolean useDefaults) {
            this.values = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
            if (useDefaults) {
                this.values.put("STOP", "8005");
                this.values.put("HTTP", "8080");
                this.values.put("host", "localhost");
            }
        }
        
        @Override
        public void startElement(final String uri, final String localName, final String qName, final Attributes attributes) throws SAXException {
            if ("Server".equalsIgnoreCase(localName)) {
                final String port = attributes.getValue("port");
                if (port != null) {
                    this.values.put("STOP", port);
                }
                else {
                    this.values.put("STOP", "8005");
                }
            }
            else if ("Connector".equalsIgnoreCase(localName)) {
                String protocol = attributes.getValue("protocol");
                if (protocol == null) {
                    protocol = "HTTP";
                }
                else if (protocol.contains("/")) {
                    protocol = protocol.substring(0, protocol.indexOf("/"));
                }
                final String port2 = attributes.getValue("port");
                final String ssl = attributes.getValue("secure");
                if (ssl == null || "false".equalsIgnoreCase(ssl)) {
                    this.values.put(protocol.toUpperCase(), port2);
                }
                else {
                    this.values.put(protocol.toUpperCase() + "S", port2);
                }
            }
            else if ("Host".equalsIgnoreCase(localName)) {
                final String host = attributes.getValue("name");
                if (host != null) {
                    this.values.put("host", host);
                }
            }
        }
        
        private static QuickServerXmlParser parse(final File serverXml) {
            return parse(serverXml, true);
        }
        
        private static QuickServerXmlParser parse(final File serverXml, final boolean defaults) {
            final QuickServerXmlParser handler = new QuickServerXmlParser(defaults);
            try {
                final SAXParser parser = QuickServerXmlParser.FACTORY.newSAXParser();
                parser.parse(serverXml, handler);
            }
            catch (Exception ex) {}
            return handler;
        }
        
        public String http() {
            return this.value("HTTP", "8080");
        }
        
        private String https() {
            return this.securedValue("HTTP", "8443");
        }
        
        private String stop() {
            return this.value("STOP", "8005");
        }
        
        private String value(final String key, final String defaultValue) {
            final String val = this.values.get(key);
            if (val == null) {
                return defaultValue;
            }
            return val;
        }
        
        private String securedValue(final String key, final String defaultValue) {
            return this.value(key + "S", defaultValue);
        }
        
        static {
            (FACTORY = SAXParserFactory.newInstance()).setNamespaceAware(true);
            QuickServerXmlParser.FACTORY.setValidating(false);
        }
    }
    
    public static class DeploymentMeta
    {
        private final String context;
        private final File docBase;
        private final Consumer<Context> consumer;
        
        public DeploymentMeta(final String context, final File docBase, final Consumer<Context> consumer) {
            this.context = context;
            this.docBase = docBase;
            this.consumer = consumer;
        }
    }
    
    private static final class MeecrowaveContainerLoader extends URLClassLoader
    {
        private MeecrowaveContainerLoader(final URL[] urls, final ClassLoader parent) {
            super(urls, parent);
        }
    }
    
    public interface InstanceCustomizer extends Consumer<Tomcat>
    {
    }
    
    public interface ConfigurationCustomizer extends Consumer<Builder>
    {
    }
}
