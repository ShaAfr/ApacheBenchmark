// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.io;

import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.stream.Stream;
import java.util.Optional;
import java.io.File;

public final class IO
{
    private IO() {
    }
    
    public static void delete(final File dir) {
        if (!dir.exists()) {
            return;
        }
        if (dir.isFile()) {
            retryDelete(dir);
            return;
        }
        Stream.of((File[])Optional.ofNullable(dir.listFiles()).orElseGet(() -> new File[0])).forEach(f -> {
            if (f.isFile()) {
                retryDelete(f);
            }
            else {
                delete(f);
            }
            return;
        });
        retryDelete(dir);
    }
    
    private static void retryDelete(final File f) {
        for (int i = 0; i < 3; ++i) {
            if (!f.exists() || f.delete()) {
                return;
            }
            System.gc();
            try {
                Thread.sleep(50L);
            }
            catch (InterruptedException e) {
                Thread.interrupted();
            }
        }
        throw new IllegalStateException("Can't delete " + f);
    }
    
    public static void copy(final InputStream is, final OutputStream os) throws IOException {
        final byte[] buffer = new byte[16384];
        int count;
        while (-1 != (count = is.read(buffer))) {
            os.write(buffer, 0, count);
        }
    }
    
    public static String toString(final InputStream stream) throws IOException {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        copy(stream, baos);
        return new String(baos.toByteArray(), StandardCharsets.UTF_8);
    }
    
    public static void mkdirs(final File d) {
        if (!d.isDirectory() && !d.mkdirs()) {
            throw new IllegalStateException(d + " can't be created");
        }
    }
}
