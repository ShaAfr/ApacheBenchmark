// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.openwebbeans;

import org.apache.webbeans.config.WebBeansContext;
import org.apache.xbean.finder.filter.Filter;
import org.apache.meecrowave.Meecrowave;
import javax.servlet.ServletContext;
import org.apache.tomcat.JarScanType;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Collection;
import org.apache.webbeans.corespi.scanner.xbean.CdiArchive;
import java.net.URI;
import org.apache.xbean.finder.AnnotationFinder;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.Optional;
import org.apache.webbeans.util.WebBeansUtil;
import org.apache.webbeans.spi.BeanArchiveService;
import java.util.Map;
import org.apache.webbeans.corespi.scanner.xbean.OwbAnnotationFinder;
import java.util.HashSet;
import java.io.File;
import java.util.function.Consumer;
import java.util.Set;
import org.apache.tomcat.JarScanFilter;
import org.apache.openwebbeans.se.CDISeScannerService;
import org.apache.meecrowave.logging.tomcat.LogFacade;
import org.apache.webbeans.web.scanner.WebScannerService;

public class OWBTomcatWebScannerService extends WebScannerService
{
    private final LogFacade logger;
    private final CDISeScannerService delegate;
    protected JarScanFilter filter;
    private String jreBase;
    private final Set<String> urls;
    private String docBase;
    private String shared;
    private Consumer<File> fileVisitor;
    
    public OWBTomcatWebScannerService() {
        this(null);
    }
    
    public OWBTomcatWebScannerService(final CDISeScannerService delegate) {
        this.logger = new LogFacade(OWBTomcatWebScannerService.class.getName());
        this.urls = new HashSet<String>();
        this.delegate = delegate;
    }
    
    public void init(final Object context) {
        if (this.delegate != null) {
            this.delegate.init(context);
        }
    }
    
    public OwbAnnotationFinder getFinder() {
        if (this.delegate != null) {
            return this.delegate.getFinder();
        }
        return super.getFinder();
    }
    
    public Map<BeanArchiveService.BeanArchiveInformation, Set<Class<?>>> getBeanClassesPerBda() {
        if (this.delegate != null) {
            return (Map<BeanArchiveService.BeanArchiveInformation, Set<Class<?>>>)this.delegate.getBeanClassesPerBda();
        }
        return (Map<BeanArchiveService.BeanArchiveInformation, Set<Class<?>>>)super.getBeanClassesPerBda();
    }
    
    public void release() {
        if (this.delegate != null) {
            this.delegate.release();
        }
        else {
            super.release();
        }
    }
    
    public Set<Class<?>> getBeanClasses() {
        if (this.delegate != null) {
            return (Set<Class<?>>)this.delegate.getBeanClasses();
        }
        return (Set<Class<?>>)super.getBeanClasses();
    }
    
    public void scan() {
        if (this.delegate != null) {
            if (this.getFinder() == null) {
                this.delegate.scan();
            }
            if (this.finder == null) {
                this.finder = this.getFinder();
            }
        }
        if (this.finder != null) {
            return;
        }
        super.scan();
        this.scanGroovy(WebBeansUtil.getCurrentClassLoader());
        if (!this.urls.isEmpty()) {
            this.logger.info("OpenWebBeans scanning:");
            final String m2 = new File(System.getProperty("user.home", "."), ".m2/repository").getAbsolutePath();
            final String base = Optional.ofNullable(this.docBase).orElse("$$$");
            final String sharedBase = Optional.ofNullable(this.shared).orElse("$$$");
            final String runnerBase = Optional.ofNullable(System.getProperty("meecrowave.base")).orElse("$$$");
            final String runnerHome = Optional.ofNullable(System.getProperty("meecrowave.home")).orElse("$$$");
            String shownValue;
            final String prefix;
            final String s;
            final String s2;
            final String s3;
            final String s4;
            this.urls.stream().map(u -> {
                shownValue = u.replace("file://", "").replace("file:", "").replace("jar:", "").replace("!/META-INF/beans.xml", "").replace("!/", "").replace("META-INF/beans.xml", "");
                if (shownValue.startsWith(prefix)) {
                    shownValue = "${maven}/" + shownValue.substring(shownValue.replace(File.separatorChar, '/').lastIndexOf(47) + 1);
                }
                else if (shownValue.startsWith(s)) {
                    shownValue = "${app}" + shownValue.replace(s, "");
                }
                else if (shownValue.startsWith(s2)) {
                    shownValue = "${shared}" + shownValue.replace(s2, "");
                }
                else if (shownValue.startsWith(s3)) {
                    shownValue = "${base}" + shownValue.replace(s3, "");
                }
                else if (shownValue.startsWith(s4)) {
                    shownValue = "${home}" + shownValue.replace(s4, "");
                }
                return shownValue;
            }).sorted().forEach(v -> this.logger.info("    " + v));
            if (this.fileVisitor != null) {
                this.urls.stream().filter((Predicate<? super Object>)this::isFile).map((Function<? super Object, ?>)this::toFile).filter(File::isDirectory).forEach((Consumer<? super Object>)this.fileVisitor);
            }
        }
        this.urls.clear();
        this.filter = null;
        this.docBase = null;
        this.shared = null;
    }
    
    private File toFile(final String url) {
        try {
            return new File(new URL(url).getFile());
        }
        catch (MalformedURLException e) {
            return new File(url.substring("file://".length(), url.length()));
        }
    }
    
    private boolean isFile(final String url) {
        return url.startsWith("file:") && !url.endsWith("!/") && !url.endsWith("!/META-INF/beans.xml");
    }
    
    private void scanGroovy(final ClassLoader currentClassLoader) {
        if (currentClassLoader == null || !currentClassLoader.getClass().getName().equals("groovy.lang.GroovyClassLoader")) {
            return;
        }
        try {
            final Class<?>[] getLoadedClasses = (Class<?>[])Class[].class.cast(currentClassLoader.getClass().getMethod("getLoadedClasses", (Class<?>[])new Class[0]).invoke(currentClassLoader, new Object[0]));
            this.addClassesToDefault(getLoadedClasses);
        }
        catch (Exception e) {
            new LogFacade(OWBTomcatWebScannerService.class.getName()).warn(e.getMessage());
        }
    }
    
    private void addClassesToDefault(final Class<?>[] all) throws Exception {
        if (all == null || all.length == 0) {
            return;
        }
        final Field linking = AnnotationFinder.class.getDeclaredField("linking");
        final Method readClassDef = AnnotationFinder.class.getDeclaredMethod("readClassDef", Class.class);
        if (!readClassDef.isAccessible()) {
            readClassDef.setAccessible(true);
        }
        if (!linking.isAccessible()) {
            linking.setAccessible(true);
        }
        final URI uri = URI.create("jar:file://!/");
        final URL url = uri.toURL();
        final String key = uri.toASCIIString();
        CdiArchive.FoundClasses foundClasses = this.archive.classesByUrl().get(key);
        if (foundClasses == null) {
            final BeanArchiveService beanArchiveService = this.webBeansContext().getBeanArchiveService();
            foundClasses = CdiArchive.FoundClasses.class.cast(CdiArchive.FoundClasses.class.getConstructor(CdiArchive.class, URL.class, Collection.class, BeanArchiveService.BeanArchiveInformation.class).newInstance(null, url, new HashSet(), beanArchiveService.getBeanArchiveInformation(url)));
            this.archive.classesByUrl().put(key, foundClasses);
        }
        foundClasses.getClassNames().addAll(Stream.of(all).map((Function<? super Class<?>, ?>)Class::getName).collect((Collector<? super Object, ?, Set<? super Object>>)Collectors.toSet()));
        try {
            linking.set(this.finder, true);
            final Method method;
            Stream.of(all).forEach(c -> {
                try {
                    method.invoke(this.finder, c);
                }
                catch (IllegalAccessException e) {
                    throw new IllegalStateException(e);
                }
                catch (InvocationTargetException e2) {
                    throw new IllegalStateException(e2.getCause());
                }
                return;
            });
        }
        finally {
            try {
                linking.set(this.finder, false);
            }
            catch (IllegalAccessException ex) {}
        }
    }
    
    protected void filterExcludedJars(final Set<URL> classPathUrls) {
        String jreBaseTmp;
        try {
            jreBaseTmp = new File(System.getProperty("java.home")).toURI().toURL().toExternalForm();
        }
        catch (MalformedURLException e) {
            jreBaseTmp = System.getProperty("java.home");
        }
        this.jreBase = jreBaseTmp;
        super.filterExcludedJars((Set)classPathUrls);
    }
    
    protected int isExcludedJar(final String path) {
        if (path.startsWith(this.jreBase) || (path.startsWith("jar:") && path.indexOf(this.jreBase) == 4)) {
            return this.jreBase.length();
        }
        if (path.startsWith("jar:file:") && path.endsWith(".jar!/")) {
            final int lastSep = path.substring(0, path.length() - 2).lastIndexOf(47);
            if (lastSep > 0) {
                return (this.filter != null && this.filter.check(JarScanType.PLUGGABILITY, path.substring(lastSep + 1, path.length() - 2))) ? -1 : (path.indexOf(".jar") - 1);
            }
        }
        final int filenameIdx = path.replace(File.separatorChar, '/').replace("!/", "").lastIndexOf(47) + 1;
        if (filenameIdx < 0 || filenameIdx >= path.length()) {
            return -1;
        }
        return (this.filter != null && this.filter.check(JarScanType.PLUGGABILITY, path.substring(filenameIdx))) ? -1 : (path.indexOf(".jar") - 1);
    }
    
    public void setFilter(final JarScanFilter filter, final ServletContext ctx) {
        this.filter = filter;
        super.init((Object)ctx);
        final Meecrowave.Builder config = Meecrowave.Builder.class.cast(ServletContext.class.cast(ctx).getAttribute("meecrowave.configuration"));
        if (this.filter == null) {
            this.filter = (JarScanFilter)new KnownJarsFilter(config);
        }
        final Filter userFilter = (Filter)this.webBeansContext().getService((Class)Filter.class);
        if (KnowClassesFilter.class.isInstance(userFilter)) {
            KnowClassesFilter.class.cast(userFilter).init(config);
        }
    }
    
    protected void addWebBeansXmlLocation(final URL beanArchiveUrl) {
        final String url = beanArchiveUrl.toExternalForm();
        if (this.urls.add(Optional.of(url).map(s -> (s.startsWith("jar:") && s.endsWith("!/META-INF/beans.xml")) ? s.substring("jar:".length(), s.length() - "!/META-INF/beans.xml".length()) : s).get())) {
            super.doAddWebBeansXmlLocation(beanArchiveUrl);
        }
    }
    
    public void setShared(final String shared) {
        this.shared = Optional.ofNullable(shared).map((Function<? super String, ?>)File::new).filter(File::isDirectory).map((Function<? super Object, ? extends String>)File::getAbsolutePath).orElse(null);
    }
    
    public void setDocBase(final String docBase) {
        this.docBase = docBase;
    }
    
    public void setFileVisitor(final Consumer<File> fileVisitor) {
        this.fileVisitor = fileVisitor;
    }
    
    protected WebBeansContext webBeansContext() {
        return WebBeansContext.getInstance();
    }
}
