// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.tomcat;

import org.apache.tomcat.Jar;
import java.net.URISyntaxException;
import java.io.IOException;
import java.net.MalformedURLException;
import org.apache.tomcat.util.buf.UriUtil;
import java.io.File;
import org.apache.tomcat.util.scan.JarFactory;
import java.net.URL;
import org.apache.webbeans.config.WebBeansContext;
import org.apache.webbeans.web.scanner.WebScannerService;
import org.apache.webbeans.corespi.scanner.xbean.CdiArchive;
import org.apache.tomcat.JarScannerCallback;
import javax.servlet.ServletContext;
import org.apache.tomcat.JarScanType;
import org.apache.tomcat.JarScanFilter;
import org.apache.tomcat.JarScanner;

public class OWBJarScanner implements JarScanner
{
    private JarScanFilter filter;
    
    public void scan(final JarScanType jarScanType, final ServletContext servletContext, final JarScannerCallback callback) {
        switch (jarScanType) {
            case PLUGGABILITY: {
                URL url;
                Jar jar;
                final Throwable t2;
                File f;
                Jar jar2;
                final Throwable t4;
                final Exception ex;
                Exception ioe;
                CdiArchive.class.cast(WebScannerService.class.cast(WebBeansContext.getInstance().getScannerService()).getFinder().getArchive()).classesByUrl().keySet().stream().filter(u -> !"jar:file://!/".equals(u)).forEach(u -> {
                    try {
                        url = new URL(u);
                        if ("jar".equals(url.getProtocol()) || url.getPath().endsWith(".jar")) {
                            jar = JarFactory.newInstance(url);
                            try {
                                callback.scan(jar, u, true);
                            }
                            catch (Throwable t) {
                                throw t;
                            }
                            finally {
                                if (jar != null) {
                                    if (t2 != null) {
                                        try {
                                            jar.close();
                                        }
                                        catch (Throwable exception) {
                                            t2.addSuppressed(exception);
                                        }
                                    }
                                    else {
                                        jar.close();
                                    }
                                }
                            }
                        }
                        else if ("file".equals(url.getProtocol())) {
                            f = new File(url.toURI());
                            if (f.isFile()) {
                                jar2 = JarFactory.newInstance(UriUtil.buildJarUrl(f));
                                try {
                                    callback.scan(jar2, f.getAbsolutePath(), true);
                                }
                                catch (Throwable t3) {
                                    throw t3;
                                }
                                finally {
                                    if (jar2 != null) {
                                        if (t4 != null) {
                                            try {
                                                jar2.close();
                                            }
                                            catch (Throwable exception2) {
                                                t4.addSuppressed(exception2);
                                            }
                                        }
                                        else {
                                            jar2.close();
                                        }
                                    }
                                }
                            }
                            else if (f.isDirectory()) {
                                callback.scan(f, f.getAbsolutePath(), true);
                            }
                        }
                    }
                    catch (MalformedURLException ex2) {}
                    catch (IOException | URISyntaxException ex3) {
                        ioe = ex;
                        throw new IllegalArgumentException(ioe);
                    }
                });
            }
            default: {}
        }
    }
    
    public JarScanFilter getJarScanFilter() {
        return this.filter;
    }
    
    public void setJarScanFilter(final JarScanFilter jarScanFilter) {
        this.filter = jarScanFilter;
    }
}
