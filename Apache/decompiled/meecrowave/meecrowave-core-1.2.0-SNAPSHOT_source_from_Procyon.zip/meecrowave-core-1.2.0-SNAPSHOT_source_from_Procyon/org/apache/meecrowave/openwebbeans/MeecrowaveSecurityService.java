// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.openwebbeans;

import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.context.spi.Contextual;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import javax.servlet.http.HttpServletRequest;
import javax.enterprise.inject.spi.CDI;
import java.security.Principal;
import org.apache.webbeans.corespi.security.SimpleSecurityService;

public class MeecrowaveSecurityService extends SimpleSecurityService
{
    public Principal getCurrentPrincipal() {
        return new MeecrowavePrincipal();
    }
    
    private static class MeecrowavePrincipal implements Principal
    {
        @Override
        public String getName() {
            return this.unwrap().getName();
        }
        
        private Principal unwrap() {
            final BeanManager beanManager = CDI.current().getBeanManager();
            return HttpServletRequest.class.cast(beanManager.getReference(beanManager.resolve(beanManager.getBeans((Type)HttpServletRequest.class, new Annotation[0])), (Type)HttpServletRequest.class, beanManager.createCreationalContext((Contextual)null))).getUserPrincipal();
        }
    }
}
