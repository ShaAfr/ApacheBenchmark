// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.cxf;

import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.MessageBodyReader;
import org.apache.johnzon.jaxrs.JsrMessageBodyWriter;
import org.apache.johnzon.jaxrs.JsrMessageBodyReader;
import javax.json.Json;
import java.util.HashMap;
import javax.json.JsonStructure;
import org.apache.johnzon.jaxrs.DelegateProvider;
import java.util.function.Consumer;
import java.util.Optional;
import java.util.Arrays;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.ext.Provider;
import org.apache.johnzon.jaxrs.jsonb.jaxrs.JsonbJaxrsProvider;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.meecrowave.Meecrowave;
import org.apache.cxf.message.Message;
import org.apache.cxf.interceptor.Interceptor;
import java.util.List;
import org.apache.cxf.feature.Feature;
import java.util.Collection;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.ServletContext;
import org.apache.cxf.bus.extension.ExtensionManagerBus;
import org.apache.webbeans.proxy.InterceptorDecoratorProxyFactory;
import org.apache.webbeans.proxy.NormalScopeProxyFactory;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import org.apache.cxf.Bus;

@Named("cxf")
@ApplicationScoped
public class MeecrowaveBus implements Bus
{
    private final Bus delegate;
    private NormalScopeProxyFactory normalScopeProxyFactory;
    private InterceptorDecoratorProxyFactory interceptorDecoratorProxyFactory;
    
    protected MeecrowaveBus() {
        this.delegate = (Bus)new ExtensionManagerBus();
    }
    
    @Inject
    public MeecrowaveBus(final ServletContext context) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   java/lang/Object.<init>:()V
        //     4: aload_0         /* this */
        //     5: new             Lorg/apache/cxf/bus/extension/ExtensionManagerBus;
        //     8: dup            
        //     9: invokespecial   org/apache/cxf/bus/extension/ExtensionManagerBus.<init>:()V
        //    12: putfield        org/apache/meecrowave/cxf/MeecrowaveBus.delegate:Lorg/apache/cxf/Bus;
        //    15: invokestatic    org/apache/webbeans/config/WebBeansContext.currentInstance:()Lorg/apache/webbeans/config/WebBeansContext;
        //    18: astore_2        /* webBeansContext */
        //    19: aload_0         /* this */
        //    20: aload_2         /* webBeansContext */
        //    21: invokevirtual   org/apache/webbeans/config/WebBeansContext.getNormalScopeProxyFactory:()Lorg/apache/webbeans/proxy/NormalScopeProxyFactory;
        //    24: putfield        org/apache/meecrowave/cxf/MeecrowaveBus.normalScopeProxyFactory:Lorg/apache/webbeans/proxy/NormalScopeProxyFactory;
        //    27: aload_0         /* this */
        //    28: aload_2         /* webBeansContext */
        //    29: invokevirtual   org/apache/webbeans/config/WebBeansContext.getInterceptorDecoratorProxyFactory:()Lorg/apache/webbeans/proxy/InterceptorDecoratorProxyFactory;
        //    32: putfield        org/apache/meecrowave/cxf/MeecrowaveBus.interceptorDecoratorProxyFactory:Lorg/apache/webbeans/proxy/InterceptorDecoratorProxyFactory;
        //    35: aload_0         /* this */
        //    36: ldc             Lorg/apache/cxf/common/util/ClassUnwrapper;.class
        //    38: invokevirtual   java/lang/Class.getName:()Ljava/lang/String;
        //    41: aload_0         /* this */
        //    42: invokedynamic   BootstrapMethod #0, getRealClass:(Lorg/apache/meecrowave/cxf/MeecrowaveBus;)Lorg/apache/cxf/common/util/ClassUnwrapper;
        //    47: invokevirtual   org/apache/meecrowave/cxf/MeecrowaveBus.setProperty:(Ljava/lang/String;Ljava/lang/Object;)V
        //    50: ldc             Lorg/apache/meecrowave/Meecrowave$Builder;.class
        //    52: aload_1         /* context */
        //    53: ldc             "meecrowave.configuration"
        //    55: invokeinterface javax/servlet/ServletContext.getAttribute:(Ljava/lang/String;)Ljava/lang/Object;
        //    60: invokevirtual   java/lang/Class.cast:(Ljava/lang/Object;)Ljava/lang/Object;
        //    63: checkcast       Lorg/apache/meecrowave/Meecrowave$Builder;
        //    66: astore_3        /* builder */
        //    67: aload_3         /* builder */
        //    68: ifnull          178
        //    71: aload_3         /* builder */
        //    72: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.isJaxrsProviderSetup:()Z
        //    75: ifeq            178
        //    78: aload_3         /* builder */
        //    79: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.getJaxrsDefaultProviders:()Ljava/lang/String;
        //    82: invokestatic    java/util/Optional.ofNullable:(Ljava/lang/Object;)Ljava/util/Optional;
        //    85: invokedynamic   BootstrapMethod #1, apply:()Ljava/util/function/Function;
        //    90: invokevirtual   java/util/Optional.map:(Ljava/util/function/Function;)Ljava/util/Optional;
        //    93: aload_3         /* builder */
        //    94: invokedynamic   BootstrapMethod #2, get:(Lorg/apache/meecrowave/Meecrowave$Builder;)Ljava/util/function/Supplier;
        //    99: invokevirtual   java/util/Optional.orElseGet:(Ljava/util/function/Supplier;)Ljava/lang/Object;
        //   102: checkcast       Ljava/util/List;
        //   105: astore          providers
        //   107: aload_3         /* builder */
        //   108: invokevirtual   org/apache/meecrowave/Meecrowave$Builder.isJaxrsAutoActivateBeanValidation:()Z
        //   111: ifeq            153
        //   114: invokestatic    java/lang/Thread.currentThread:()Ljava/lang/Thread;
        //   117: invokevirtual   java/lang/Thread.getContextClassLoader:()Ljava/lang/ClassLoader;
        //   120: astore          contextClassLoader
        //   122: aload           contextClassLoader
        //   124: ldc             "javax.validation.Validation"
        //   126: invokevirtual   java/lang/ClassLoader.loadClass:(Ljava/lang/String;)Ljava/lang/Class;
        //   129: pop            
        //   130: aload           providers
        //   132: aload           contextClassLoader
        //   134: ldc             "org.apache.cxf.jaxrs.validation.ValidationExceptionMapper"
        //   136: invokevirtual   java/lang/ClassLoader.loadClass:(Ljava/lang/String;)Ljava/lang/Class;
        //   139: invokevirtual   java/lang/Class.newInstance:()Ljava/lang/Object;
        //   142: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   147: pop            
        //   148: goto            153
        //   151: astore          5
        //   153: aload_0         /* this */
        //   154: ldc             "org.apache.cxf.jaxrs.bus.providers"
        //   156: invokevirtual   org/apache/meecrowave/cxf/MeecrowaveBus.getProperty:(Ljava/lang/String;)Ljava/lang/Object;
        //   159: ifnonnull       178
        //   162: aload_0         /* this */
        //   163: ldc             "skip.default.json.provider.registration"
        //   165: ldc             "true"
        //   167: invokevirtual   org/apache/meecrowave/cxf/MeecrowaveBus.setProperty:(Ljava/lang/String;Ljava/lang/Object;)V
        //   170: aload_0         /* this */
        //   171: ldc             "org.apache.cxf.jaxrs.bus.providers"
        //   173: aload           providers
        //   175: invokevirtual   org/apache/meecrowave/cxf/MeecrowaveBus.setProperty:(Ljava/lang/String;Ljava/lang/Object;)V
        //   178: return         
        //    StackMapTable: 00 03 FF 00 97 00 05 07 00 89 07 00 8A 07 00 8B 07 00 8C 07 00 8D 00 01 07 00 8E 01 FA 00 18
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  114    148    151    153    Ljava/lang/Exception;
        //  114    148    151    153    Ljava/lang/NoClassDefFoundError;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected Class<?> getRealClass(final Object o) {
        final Class<?> aClass = o.getClass();
        if (aClass.getName().contains("$$")) {
            final Class realClass = aClass.getSuperclass();
            if (realClass == Object.class || realClass.isInterface()) {
                final Class<?>[] interfaces = aClass.getInterfaces();
                if (interfaces.length > 0) {
                    Class<?> rootInterface = interfaces[0];
                    for (final Class<?> anInterface : interfaces) {
                        if (rootInterface.isAssignableFrom(anInterface)) {
                            rootInterface = anInterface;
                        }
                    }
                    return rootInterface;
                }
            }
            return (Class<?>)realClass;
        }
        return aClass;
    }
    
    public <T> T getExtension(final Class<T> extensionType) {
        return (T)this.delegate.getExtension((Class)extensionType);
    }
    
    public <T> void setExtension(final T extension, final Class<T> extensionType) {
        this.delegate.setExtension((Object)extension, (Class)extensionType);
    }
    
    public boolean hasExtensionByName(final String name) {
        return this.delegate.hasExtensionByName(name);
    }
    
    public String getId() {
        return this.delegate.getId();
    }
    
    public void setId(final String i) {
        this.delegate.setId(i);
    }
    
    public void shutdown(final boolean wait) {
        this.delegate.shutdown(wait);
    }
    
    public void setProperty(final String s, final Object o) {
        this.delegate.setProperty(s, o);
    }
    
    public Object getProperty(final String s) {
        return this.delegate.getProperty(s);
    }
    
    public void setProperties(final Map<String, Object> properties) {
        this.delegate.setProperties((Map)properties);
    }
    
    public Map<String, Object> getProperties() {
        return (Map<String, Object>)this.delegate.getProperties();
    }
    
    public Collection<Feature> getFeatures() {
        return (Collection<Feature>)this.delegate.getFeatures();
    }
    
    public void setFeatures(final Collection<? extends Feature> features) {
        this.delegate.setFeatures((Collection)features);
    }
    
    public Bus.BusState getState() {
        return this.delegate.getState();
    }
    
    public List<Interceptor<? extends Message>> getInInterceptors() {
        return (List<Interceptor<? extends Message>>)this.delegate.getInInterceptors();
    }
    
    public List<Interceptor<? extends Message>> getOutInterceptors() {
        return (List<Interceptor<? extends Message>>)this.delegate.getOutInterceptors();
    }
    
    public List<Interceptor<? extends Message>> getInFaultInterceptors() {
        return (List<Interceptor<? extends Message>>)this.delegate.getInFaultInterceptors();
    }
    
    public List<Interceptor<? extends Message>> getOutFaultInterceptors() {
        return (List<Interceptor<? extends Message>>)this.delegate.getOutFaultInterceptors();
    }
    
    @Provider
    @Produces({ "application/json", "*/*+json" })
    @Consumes({ "application/json", "*/*+json" })
    public static class ConfiguredJsonbJaxrsProvider<T> extends JsonbJaxrsProvider<T>
    {
        private ConfiguredJsonbJaxrsProvider(final String encoding, final boolean nulls, final boolean iJson, final boolean pretty, final String binaryStrategy, final String namingStrategy, final String orderStrategy) {
            super((Collection)Arrays.asList("[B"));
            Optional.ofNullable(encoding).ifPresent(this::setEncoding);
            Optional.ofNullable(namingStrategy).ifPresent(this::setPropertyNamingStrategy);
            Optional.ofNullable(orderStrategy).ifPresent(this::setPropertyOrderStrategy);
            Optional.ofNullable(binaryStrategy).ifPresent(this::setBinaryDataStrategy);
            this.setNullValues(nulls);
            this.setIJson(iJson);
            this.setPretty(pretty);
        }
    }
    
    @Provider
    @Produces({ "application/json", "application/*+json" })
    @Consumes({ "application/json", "application/*+json" })
    public static class ConfiguredJsrProvider extends DelegateProvider<JsonStructure>
    {
        private ConfiguredJsrProvider(final String bufferStrategy, final int maxStringLen, final int maxReadBufferLen, final int maxWriteBufferLen, final boolean supportsComment, final boolean pretty) {
            super((MessageBodyReader)new JsrMessageBodyReader(Json.createReaderFactory((Map)new HashMap<String, Object>() {
                {
                    ((HashMap<String, Boolean>)this).put("org.apache.johnzon.supports-comments", supportsComment);
                    Optional.of(maxStringLen).filter(v -> v > 0).ifPresent(s -> ((HashMap<String, Integer>)this).put("org.apache.johnzon.max-string-length", s));
                    Optional.of(maxReadBufferLen).filter(v -> v > 0).ifPresent(s -> ((HashMap<String, Integer>)this).put("org.apache.johnzon.default-char-buffer", s));
                    Optional.ofNullable(bufferStrategy).ifPresent(s -> ((HashMap<String, String>)this).put("org.apache.johnzon.buffer-strategy", s));
                }
            }), false), (MessageBodyWriter)new JsrMessageBodyWriter(Json.createWriterFactory((Map)new HashMap<String, Object>() {
                {
                    ((HashMap<String, Boolean>)this).put("javax.json.stream.JsonGenerator.prettyPrinting", pretty);
                    Optional.of(maxWriteBufferLen).filter(v -> v > 0).ifPresent(v -> ((HashMap<String, Integer>)this).put("org.apache.johnzon.default-char-buffer-generator", v));
                    Optional.ofNullable(bufferStrategy).ifPresent(s -> ((HashMap<String, String>)this).put("org.apache.johnzon.buffer-strategy", s));
                }
            }), false));
        }
    }
}
