// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.tomcat;

import java.io.CharArrayWriter;
import org.apache.meecrowave.logging.tomcat.LogFacade;
import org.apache.catalina.valves.AbstractAccessLogValve;

public class LoggingAccessLogPattern extends AbstractAccessLogValve
{
    private final LogFacade logger;
    
    public LoggingAccessLogPattern(final String pattern) {
        this.logger = new LogFacade(LoggingAccessLogPattern.class.getName());
        this.setAsyncSupported(true);
        this.setPattern(pattern);
    }
    
    protected void log(final CharArrayWriter message) {
        this.logger.info(message);
    }
}
