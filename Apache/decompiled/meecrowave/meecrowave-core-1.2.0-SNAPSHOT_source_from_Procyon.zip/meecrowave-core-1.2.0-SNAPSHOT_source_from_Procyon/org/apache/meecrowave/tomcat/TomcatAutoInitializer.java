// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.tomcat;

import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import org.apache.catalina.servlets.DefaultServlet;
import org.apache.meecrowave.Meecrowave;
import javax.servlet.ServletContext;
import java.util.Set;
import javax.servlet.ServletContainerInitializer;

public class TomcatAutoInitializer implements ServletContainerInitializer
{
    public void onStartup(final Set<Class<?>> c, final ServletContext ctx) throws ServletException {
        final Meecrowave.Builder builder = Meecrowave.Builder.class.cast(ctx.getAttribute("meecrowave.configuration"));
        if (!builder.isTomcatAutoSetup()) {
            return;
        }
        final ServletRegistration.Dynamic def = ctx.addServlet("default", (Class)DefaultServlet.class);
        def.setInitParameter("listings", "false");
        def.setInitParameter("debug", "0");
        def.setLoadOnStartup(1);
        def.addMapping(new String[] { "/" });
        try {
            final String jsp = "org.apache.jasper.servlet.JspServlet";
            TomcatAutoInitializer.class.getClassLoader().loadClass("org.apache.jasper.servlet.JspServlet");
            final ServletRegistration.Dynamic jspDef = ctx.addServlet("jsp", "org.apache.jasper.servlet.JspServlet");
            if (jspDef != null) {
                jspDef.setInitParameter("fork", "false");
                jspDef.setInitParameter("xpoweredBy", "false");
                jspDef.setInitParameter("development", "false");
                jspDef.setLoadOnStartup(3);
                def.addMapping(new String[] { "*.jsp" });
                def.addMapping(new String[] { "*.jspx" });
            }
        }
        catch (NoClassDefFoundError noClassDefFoundError) {}
        catch (ClassNotFoundException ex) {}
    }
}
