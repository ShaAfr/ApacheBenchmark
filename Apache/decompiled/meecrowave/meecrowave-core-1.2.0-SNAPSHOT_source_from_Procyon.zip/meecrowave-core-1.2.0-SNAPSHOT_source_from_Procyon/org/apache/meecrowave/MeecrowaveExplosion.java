// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave;

public class MeecrowaveExplosion extends RuntimeException
{
    public MeecrowaveExplosion(final String msg, final Exception e) {
        super(msg, e);
    }
}
