// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.logging.log4j2;

import org.apache.logging.log4j.core.impl.Log4jLogEvent;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.Property;
import java.util.List;
import org.apache.logging.log4j.message.Message;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.impl.DefaultLogEventFactory;

public class MeecrowaveLogEventFactory extends DefaultLogEventFactory
{
    public LogEvent createEvent(final String loggerName, final Marker marker, final String fqcn, final Level level, final Message data, final List<Property> properties, final Throwable t) {
        return (LogEvent)new MeecrowaveLog4jLogEvent(loggerName, marker, fqcn, level, data, properties, t);
    }
    
    public static class MeecrowaveLog4jLogEvent extends Log4jLogEvent
    {
        private StackTraceElement source;
        
        public MeecrowaveLog4jLogEvent(final String loggerName, final Marker marker, final String fqcn, final Level level, final Message data, final List<Property> properties, final Throwable t) {
            super(loggerName, marker, fqcn, level, data, (List)properties, t);
        }
        
        public StackTraceElement getSource() {
            if (this.source != null) {
                return this.source;
            }
            if (this.getLoggerFqcn() == null || !this.isIncludeLocation()) {
                return null;
            }
            final StackTraceElement[] stackTrace = new Throwable().getStackTrace();
            int i = stackTrace.length - 1;
            while (i > 0) {
                final String className = stackTrace[i].getClassName();
                if (this.getLoggerFqcn().equals(className) && stackTrace.length > i + 1) {
                    this.source = stackTrace[i + 1];
                    if (i + 3 < stackTrace.length && stackTrace[i + 2].getClassName().equals("org.apache.meecrowave.logging.tomcat.LogFacade")) {
                        this.source = stackTrace[i + 3];
                        break;
                    }
                    break;
                }
                else {
                    --i;
                }
            }
            return this.source;
        }
    }
}
