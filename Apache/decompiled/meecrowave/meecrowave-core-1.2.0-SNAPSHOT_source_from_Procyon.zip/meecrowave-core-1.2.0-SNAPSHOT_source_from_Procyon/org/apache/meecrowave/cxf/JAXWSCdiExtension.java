// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.cxf;

import org.apache.meecrowave.logging.tomcat.LogFacade;
import javax.enterprise.inject.spi.BeforeShutdown;
import java.lang.reflect.InvocationTargetException;
import org.apache.cxf.endpoint.AbstractEndpointFactory;
import org.apache.webbeans.component.OwbBean;
import javax.enterprise.context.spi.Contextual;
import org.apache.cxf.Bus;
import javax.enterprise.context.spi.CreationalContext;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import org.apache.meecrowave.Meecrowave;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.AfterDeploymentValidation;
import javax.jws.WebService;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.ProcessBean;
import java.util.ArrayList;
import java.util.Collection;
import javax.enterprise.inject.spi.Bean;
import java.util.List;
import javax.enterprise.inject.spi.Extension;

public class JAXWSCdiExtension implements Extension
{
    private boolean active;
    private final List<Bean<?>> serviceBeans;
    private final Collection<Runnable> preShutdownTasks;
    
    public JAXWSCdiExtension() {
        this.serviceBeans = new ArrayList<Bean<?>>();
        this.preShutdownTasks = new ArrayList<Runnable>();
        try {
            final ClassLoader loader = Thread.currentThread().getContextClassLoader();
            loader.loadClass("org.apache.cxf.jaxws.JaxWsServerFactoryBean");
            loader.loadClass("org.apache.cxf.service.model.SchemaInfo");
            this.active = true;
        }
        catch (NoClassDefFoundError | ClassNotFoundException noClassDefFoundError) {
            final Throwable t;
            final Throwable e = t;
            this.active = false;
        }
    }
    
    public <T> void collect(@Observes final ProcessBean<T> processBean) {
        if (this.active && processBean.getAnnotated().isAnnotationPresent((Class)WebService.class)) {
            this.serviceBeans.add((Bean<?>)processBean.getBean());
        }
    }
    
    public void load(@Observes final AfterDeploymentValidation afterDeploymentValidation, final BeanManager beanManager) {
        if (!this.active || this.serviceBeans.isEmpty() || !Meecrowave.Builder.class.cast(beanManager.getReference(beanManager.resolve(beanManager.getBeans((Type)Meecrowave.Builder.class, new Annotation[0])), (Type)Meecrowave.Builder.class, (CreationalContext)null)).isJaxwsSupportIfAvailable()) {
            return;
        }
        final Bean<?> busBean = (Bean<?>)beanManager.resolve(beanManager.getBeans("cxf"));
        final Bus bus = Bus.class.cast(beanManager.getReference((Bean)busBean, (Type)Bus.class, beanManager.createCreationalContext((Contextual)busBean)));
        final Bean<?> mapperBean = (Bean<?>)beanManager.resolve(beanManager.getBeans((Type)JAXWSAddressMapper.class, new Annotation[0]));
        if (mapperBean == null) {
            final WsMapping wsMapping;
            String s;
            final JAXWSAddressMapper mapper = type -> {
                wsMapping = type.getAnnotation(WsMapping.class);
                if (wsMapping != null) {
                    s = wsMapping.value();
                }
                else {
                    s = "/webservices/" + type.getSimpleName();
                }
                return s;
            };
        }
        else {
            final JAXWSAddressMapper mapper = JAXWSAddressMapper.class.cast(beanManager.getReference((Bean)mapperBean, (Type)JAXWSAddressMapper.class, beanManager.createCreationalContext((Contextual)mapperBean)));
        }
        final Class<?> beanClass;
        final ClassLoader loader;
        AbstractEndpointFactory aef;
        final Bus bus2;
        final JAXWSAddressMapper jaxwsAddressMapper;
        Class<? extends AbstractEndpointFactory> factoryClass;
        CreationalContext<Object> creationalContext;
        Object server;
        Class<?> serverClass;
        final Class clazz;
        final Object obj;
        final Throwable t;
        Throwable e;
        final Throwable t2;
        Throwable e3;
        this.serviceBeans.forEach(bean -> {
            beanClass = (Class<?>)(OwbBean.class.isInstance(bean) ? OwbBean.class.cast(bean).getReturnType() : bean.getBeanClass());
            loader = Thread.currentThread().getContextClassLoader();
            try {
                aef = AbstractEndpointFactory.class.cast(loader.loadClass("org.apache.cxf.jaxws.JaxWsServerFactoryBean").getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]));
                aef.setBus(bus2);
                aef.setAddress(jaxwsAddressMapper.map(beanClass));
                factoryClass = aef.getClass();
                factoryClass.getMethod("setStart", Boolean.TYPE).invoke(aef, true);
                factoryClass.getMethod("setServiceClass", Class.class).invoke(aef, beanClass);
                creationalContext = (CreationalContext<Object>)beanManager.createCreationalContext((Contextual)null);
                if (!beanManager.isNormalScope(bean.getScope())) {
                    this.preShutdownTasks.add(creationalContext::release);
                }
                factoryClass.getMethod("setServiceBean", Object.class).invoke(aef, beanManager.getReference(bean, (Type)Object.class, (CreationalContext)creationalContext));
                server = factoryClass.getMethod("create", (Class<?>[])new Class[0]).invoke(aef, new Object[0]);
                serverClass = server.getClass();
                serverClass.getMethod("start", (Class<?>[])new Class[0]).invoke(server, new Object[0]);
                this.preShutdownTasks.add(() -> {
                    try {
                        clazz.getMethod("destroy", (Class[])new Class[0]).invoke(obj, new Object[0]);
                    }
                    catch (NoClassDefFoundError | NoSuchMethodException | IllegalAccessException noClassDefFoundError) {
                        e = t;
                        throw new IllegalStateException(e);
                    }
                    catch (InvocationTargetException e2) {
                        throw new IllegalStateException(e2.getCause());
                    }
                });
            }
            catch (NoClassDefFoundError | ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InstantiationException noClassDefFoundError2) {
                e3 = t2;
                throw new IllegalStateException(e3);
            }
            catch (InvocationTargetException e4) {
                throw new IllegalStateException(e4.getCause());
            }
            return;
        });
        this.serviceBeans.clear();
    }
    
    public void release(@Observes final BeforeShutdown beforeShutdown) {
        this.preShutdownTasks.stream().map(r -> () -> {
            try {
                r.run();
            }
            catch (RuntimeException re) {
                new LogFacade(JAXWSCdiExtension.class.getName()).warn(re.getMessage(), re);
            }
            return;
        }).forEach(Runnable::run);
        this.preShutdownTasks.clear();
    }
}
