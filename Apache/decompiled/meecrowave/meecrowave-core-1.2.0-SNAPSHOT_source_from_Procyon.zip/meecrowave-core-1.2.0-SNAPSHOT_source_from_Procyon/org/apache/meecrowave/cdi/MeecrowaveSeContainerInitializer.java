// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.cdi;

import org.apache.meecrowave.logging.tomcat.Log4j2Log;
import org.apache.meecrowave.logging.jul.Log4j2Logger;
import org.apache.meecrowave.logging.openwebbeans.Log4j2LoggerFactory;
import org.apache.meecrowave.openwebbeans.OWBTomcatWebScannerService;
import org.apache.webbeans.spi.ScannerService;
import org.apache.openwebbeans.se.OWBContainer;
import javax.enterprise.inject.se.SeContainer;
import org.apache.webbeans.config.WebBeansContext;
import org.apache.meecrowave.openwebbeans.KnowClassesFilter;
import org.apache.xbean.finder.filter.Filter;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.Set;
import java.util.Map;
import java.lang.reflect.Method;
import java.util.Optional;
import java.lang.reflect.InvocationTargetException;
import java.util.stream.Stream;
import javax.enterprise.inject.se.SeContainerInitializer;
import org.apache.meecrowave.Meecrowave;
import org.apache.openwebbeans.se.OWBInitializer;

public class MeecrowaveSeContainerInitializer extends OWBInitializer
{
    private Meecrowave.Builder builder;
    
    public MeecrowaveSeContainerInitializer() {
        this.builder = new Meecrowave.Builder();
    }
    
    public SeContainerInitializer addProperty(final String s, final Object o) {
        if (Meecrowave.Builder.class.isInstance(o)) {
            this.builder = Meecrowave.Builder.class.cast(o);
            return (SeContainerInitializer)this;
        }
        final String setter = "set" + Character.toUpperCase(s.charAt(0)) + s.substring(1);
        final Class<? extends Meecrowave.Builder> builderClass = this.builder.getClass();
        final Optional<Method> setterOpt = Stream.of(builderClass.getMethods()).filter(m -> m.getName().equals(setter) && m.getParameterCount() == 1).findFirst();
        if (!setterOpt.isPresent()) {
            super.addProperty(s, o);
            return (SeContainerInitializer)this;
        }
        try {
            builderClass.getMethod(setter, o.getClass()).invoke(this.builder, o);
        }
        catch (NoSuchMethodException nsme) {
            if (Integer.class.isInstance(o)) {
                try {
                    builderClass.getMethod(setter, Integer.TYPE).invoke(this.builder, o);
                    return (SeContainerInitializer)this;
                }
                catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ex7) {
                    final ReflectiveOperationException ex3;
                    final ReflectiveOperationException ex = ex3;
                    throw new IllegalArgumentException(nsme);
                }
            }
            if (Long.class.isInstance(o)) {
                try {
                    builderClass.getMethod(setter, Long.TYPE).invoke(this.builder, o);
                    return (SeContainerInitializer)this;
                }
                catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ex8) {
                    final ReflectiveOperationException ex4;
                    final ReflectiveOperationException ex = ex4;
                    throw new IllegalArgumentException(nsme);
                }
            }
            if (Boolean.class.isInstance(o)) {
                try {
                    builderClass.getMethod(setter, Boolean.TYPE).invoke(this.builder, o);
                    return (SeContainerInitializer)this;
                }
                catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ex9) {
                    final ReflectiveOperationException ex5;
                    final ReflectiveOperationException ex = ex5;
                    throw new IllegalArgumentException(nsme);
                }
            }
            throw new IllegalArgumentException(nsme);
        }
        catch (IllegalAccessException | InvocationTargetException ex10) {
            final ReflectiveOperationException ex6;
            final ReflectiveOperationException ex2 = ex6;
            throw new IllegalArgumentException(ex2);
        }
        return (SeContainerInitializer)this;
    }
    
    protected void addCustomServices(final Map<String, Object> services) {
        final Set<String> forced = this.scannerService.configuredClasses().stream().map((Function<? super Object, ?>)Class::getName).collect((Collector<? super Object, ?, Set<String>>)Collectors.toSet());
        services.put(Filter.class.getName(), new KnowClassesFilter() {
            @Override
            public boolean accept(final String name) {
                return forced.contains(name) || super.accept(name);
            }
        });
    }
    
    protected SeContainer newContainer(final WebBeansContext context) {
        final Meecrowave meecrowave = new Meecrowave(this.builder);
        return (SeContainer)new OWBContainer(context, meecrowave) {
            {
                meecrowave.bake();
            }
            
            protected void doClose() {
                meecrowave.close();
            }
        };
    }
    
    protected ScannerService getScannerService() {
        return (ScannerService)new OWBTomcatWebScannerService(this.scannerService);
    }
    
    static {
        System.setProperty("java.util.logging.manager", System.getProperty("java.util.logging.manager", "org.apache.logging.log4j.jul.LogManager"));
        System.setProperty("openwebbeans.logging.factory", System.getProperty("openwebbeans.logging.factory", Log4j2LoggerFactory.class.getName()));
        System.setProperty("org.apache.cxf.Logger", System.getProperty("org.apache.cxf.Logger", Log4j2Logger.class.getName()));
        System.setProperty("org.apache.tomcat.Logger", System.getProperty("org.apache.tomcat.Logger", Log4j2Log.class.getName()));
    }
}
