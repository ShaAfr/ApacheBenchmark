// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.openwebbeans;

import javax.enterprise.context.spi.CreationalContext;
import org.apache.webbeans.configurator.BeanConfiguratorImpl;
import javax.enterprise.inject.spi.configurator.BeanConfigurator;
import java.util.function.Consumer;
import org.apache.webbeans.intercept.InterceptorsManager;
import org.apache.webbeans.container.BeanManagerImpl;
import org.apache.meecrowave.cxf.JAXRSFieldInjectionInterceptor;
import javax.enterprise.inject.spi.Bean;
import java.lang.reflect.Type;
import org.apache.webbeans.annotation.DefaultLiteral;
import java.lang.annotation.Annotation;
import javax.enterprise.context.ApplicationScoped;
import org.apache.webbeans.config.WebBeansContext;
import javax.enterprise.inject.spi.Extension;
import org.apache.webbeans.servlet.WebBeansConfigurationListener;
import javax.servlet.ServletException;
import javax.servlet.FilterRegistration;
import java.util.EventListener;
import javax.servlet.ServletContextEvent;
import java.util.EnumSet;
import javax.servlet.DispatcherType;
import org.apache.webbeans.web.context.WebConversationFilter;
import org.apache.meecrowave.Meecrowave;
import javax.servlet.ServletContext;
import java.util.Set;
import javax.servlet.ServletContainerInitializer;

public class OWBAutoSetup implements ServletContainerInitializer
{
    public void onStartup(final Set<Class<?>> c, final ServletContext ctx) throws ServletException {
        final Meecrowave.Builder builder = Meecrowave.Builder.class.cast(ctx.getAttribute("meecrowave.configuration"));
        final Meecrowave instance = Meecrowave.class.cast(ctx.getAttribute("meecrowave.instance"));
        if (builder.isCdiConversation()) {
            final FilterRegistration.Dynamic filter = ctx.addFilter("owb-conversation", (Class)WebConversationFilter.class);
            filter.addMappingForUrlPatterns((EnumSet)EnumSet.allOf(DispatcherType.class), false, new String[] { "/*" });
        }
        final EagerBootListener bootListener = new EagerBootListener(instance);
        bootListener.doContextInitialized(new ServletContextEvent(ctx));
        ctx.addListener((EventListener)bootListener);
    }
    
    public static class EagerBootListener extends WebBeansConfigurationListener implements Extension
    {
        private final Meecrowave meecrowave;
        
        private EagerBootListener(final Meecrowave meecrowave) {
            this.meecrowave = meecrowave;
        }
        
        public void contextInitialized(final ServletContextEvent event) {
        }
        
        private void doContextInitialized(final ServletContextEvent event) {
            try {
                final WebBeansContext instance = WebBeansContext.getInstance();
                this.customizeContext(instance);
            }
            catch (IllegalStateException ex) {}
            super.contextInitialized(event);
        }
        
        private void customizeContext(final WebBeansContext instance) {
            final BeanManagerImpl beanManager = instance.getBeanManagerImpl();
            final InterceptorsManager interceptorsManager = instance.getInterceptorsManager();
            beanManager.addInternalBean((Bean)this.newBean(instance, configurator -> configurator.beanClass((Class)Meecrowave.Builder.class).scope((Class)ApplicationScoped.class).qualifiers(new Annotation[] { (Annotation)DefaultLiteral.INSTANCE }).types(new Type[] { Meecrowave.Builder.class, Object.class }).createWith(cc -> this.meecrowave.getConfiguration())));
            beanManager.addInternalBean((Bean)this.newBean(instance, configurator -> configurator.beanClass((Class)Meecrowave.class).scope((Class)ApplicationScoped.class).qualifiers(new Annotation[] { (Annotation)DefaultLiteral.INSTANCE }).types(new Type[] { Meecrowave.class, AutoCloseable.class, Object.class }).createWith(cc -> this.meecrowave)));
            interceptorsManager.addInterceptorBindingType((Class)JAXRSFieldInjectionInterceptor.Binding.class, new Annotation[0]);
            beanManager.addAdditionalAnnotatedType((Object)this, beanManager.createAnnotatedType((Class)JAXRSFieldInjectionInterceptor.class));
        }
        
        private <T> Bean<?> newBean(final WebBeansContext instance, final Consumer<BeanConfigurator<T>> configurer) {
            final BeanConfiguratorImpl<T> meecrowaveBeanBuilder = (BeanConfiguratorImpl<T>)new BeanConfiguratorImpl(instance);
            configurer.accept((BeanConfigurator<T>)meecrowaveBeanBuilder);
            return (Bean<?>)meecrowaveBeanBuilder.getBean();
        }
    }
}
