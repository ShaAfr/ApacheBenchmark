// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.logging.log4j2;

import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.Order;
import org.apache.logging.log4j.core.config.xml.XmlConfigurationFactory;

@Order(100)
@Plugin(name = "MeecrowaveConfigurationFactory", category = "ConfigurationFactory")
public class MeecrowaveLog4j2ConfigurationFactory extends XmlConfigurationFactory
{
    private static final String[] TYPES;
    
    public String[] getSupportedTypes() {
        return MeecrowaveLog4j2ConfigurationFactory.TYPES;
    }
    
    public Configuration getConfiguration(final LoggerContext loggerContext, final ConfigurationSource source) {
        return super.getConfiguration(loggerContext, source);
    }
    
    static {
        TYPES = new String[] { ".xml", ".meecrowave-logging", "*" };
    }
}
