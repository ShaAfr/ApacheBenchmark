// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.openwebbeans;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import org.apache.webbeans.container.AnnotatedTypeWrapper;
import java.lang.annotation.Annotation;
import javax.enterprise.inject.spi.AnnotatedType;
import org.apache.meecrowave.cxf.JAXRSFieldInjectionInterceptor;
import javax.ws.rs.Path;
import javax.enterprise.inject.spi.ProcessAnnotatedType;
import java.util.stream.Stream;
import org.apache.meecrowave.cxf.MeecrowaveBus;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import javax.enterprise.inject.spi.Extension;

public class MeecrowaveExtension implements Extension
{
    void addBeansFromJava(@Observes final BeforeBeanDiscovery bbd, final BeanManager bm) {
        Stream.of(MeecrowaveBus.class).forEach(type -> bbd.addAnnotatedType(bm.createAnnotatedType(type)));
    }
    
    void enableContextFieldInjectionWorks(@Observes final ProcessAnnotatedType<?> pat, final BeanManager bm) {
        final AnnotatedType<?> at = (AnnotatedType<?>)pat.getAnnotatedType();
        if (at.isAnnotationPresent((Class)Path.class) && !at.isAnnotationPresent((Class)JAXRSFieldInjectionInterceptor.Binding.class) && at.getAnnotations().stream().anyMatch(a -> bm.isNormalScope((Class)a.annotationType()))) {
            pat.setAnnotatedType((AnnotatedType)new JAXRSFIeldInjectionAT((Extension)this, (AnnotatedType)at));
        }
    }
    
    private static class JAXRSFIeldInjectionAT<T> extends AnnotatedTypeWrapper<T>
    {
        private final Set<Annotation> annotations;
        
        private JAXRSFIeldInjectionAT(final Extension extension, final AnnotatedType<T> original) {
            super(extension, (AnnotatedType)original);
            (this.annotations = new HashSet<Annotation>(original.getAnnotations().size() + 1)).addAll(original.getAnnotations());
            this.annotations.add(JAXRSFieldInjectionInterceptor.Binding.INSTANCE);
        }
        
        public Set<Annotation> getAnnotations() {
            return this.annotations;
        }
        
        public <T1 extends Annotation> T1 getAnnotation(final Class<T1> t1Class) {
            return (T1)((t1Class == JAXRSFieldInjectionInterceptor.Binding.class) ? ((T1)t1Class.cast(JAXRSFieldInjectionInterceptor.Binding.INSTANCE)) : super.getAnnotation((Class)t1Class));
        }
        
        public boolean isAnnotationPresent(final Class<? extends Annotation> aClass) {
            return JAXRSFieldInjectionInterceptor.Binding.class == aClass || super.isAnnotationPresent((Class)aClass);
        }
    }
}
