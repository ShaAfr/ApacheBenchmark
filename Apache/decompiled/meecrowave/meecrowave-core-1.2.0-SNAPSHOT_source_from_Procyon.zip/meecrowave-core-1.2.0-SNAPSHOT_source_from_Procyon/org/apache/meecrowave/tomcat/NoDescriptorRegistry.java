// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.tomcat;

import javax.management.loading.ClassLoaderRepository;
import javax.management.OperationsException;
import java.io.ObjectInputStream;
import javax.management.IntrospectionException;
import javax.management.MBeanInfo;
import javax.management.ListenerNotFoundException;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;
import javax.management.InvalidAttributeValueException;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.MBeanException;
import java.util.Set;
import javax.management.QueryExp;
import javax.management.InstanceNotFoundException;
import javax.management.NotCompliantMBeanException;
import javax.management.MBeanRegistrationException;
import javax.management.InstanceAlreadyExistsException;
import javax.management.ReflectionException;
import javax.management.ObjectInstance;
import java.util.Collections;
import javax.management.MBeanOperationInfo;
import javax.management.ObjectName;
import java.util.List;
import org.apache.tomcat.util.modeler.ManagedBean;
import javax.management.MBeanServer;
import org.apache.tomcat.util.modeler.Registry;

public class NoDescriptorRegistry extends Registry
{
    private final MBeanServer mBeanServer;
    private final ManagedBean defaultMBean;
    
    public NoDescriptorRegistry() {
        this.mBeanServer = new NoJmxMBeanServer();
        this.defaultMBean = new PassthroughMBean();
    }
    
    public void registerComponent(final Object bean, final String oname, final String type) throws Exception {
    }
    
    public void unregisterComponent(final String oname) {
    }
    
    public void invoke(final List<ObjectName> mbeans, final String operation, final boolean failFirst) throws Exception {
    }
    
    public int getId(final String domain, final String name) {
        return 0;
    }
    
    public void addManagedBean(final ManagedBean bean) {
    }
    
    public ManagedBean findManagedBean(final String name) {
        return this.defaultMBean;
    }
    
    public String getType(final ObjectName oname, final String attName) {
        return null;
    }
    
    public MBeanOperationInfo getMethodInfo(final ObjectName oname, final String opName) {
        return null;
    }
    
    public ManagedBean findManagedBean(final Object bean, final Class<?> beanClass, final String type) throws Exception {
        return null;
    }
    
    public List<ObjectName> load(final String sourceType, final Object source, final String param) throws Exception {
        return Collections.emptyList();
    }
    
    public void loadDescriptors(final String packageName, final ClassLoader classLoader) {
    }
    
    public void registerComponent(final Object bean, final ObjectName oname, final String type) throws Exception {
    }
    
    public void unregisterComponent(final ObjectName oname) {
    }
    
    public MBeanServer getMBeanServer() {
        return this.mBeanServer;
    }
    
    private static class NoJmxMBeanServer implements MBeanServer
    {
        @Override
        public ObjectInstance createMBean(final String className, final ObjectName name) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException {
            return null;
        }
        
        @Override
        public ObjectInstance createMBean(final String className, final ObjectName name, final ObjectName loaderName) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException, InstanceNotFoundException {
            return null;
        }
        
        @Override
        public ObjectInstance createMBean(final String className, final ObjectName name, final Object[] params, final String[] signature) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException {
            return null;
        }
        
        @Override
        public ObjectInstance createMBean(final String className, final ObjectName name, final ObjectName loaderName, final Object[] params, final String[] signature) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException, InstanceNotFoundException {
            return null;
        }
        
        @Override
        public ObjectInstance registerMBean(final Object object, final ObjectName name) throws InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException {
            return null;
        }
        
        @Override
        public void unregisterMBean(final ObjectName name) throws InstanceNotFoundException, MBeanRegistrationException {
        }
        
        @Override
        public ObjectInstance getObjectInstance(final ObjectName name) throws InstanceNotFoundException {
            return null;
        }
        
        @Override
        public Set<ObjectInstance> queryMBeans(final ObjectName name, final QueryExp query) {
            return null;
        }
        
        @Override
        public Set<ObjectName> queryNames(final ObjectName name, final QueryExp query) {
            return null;
        }
        
        @Override
        public boolean isRegistered(final ObjectName name) {
            return false;
        }
        
        @Override
        public Integer getMBeanCount() {
            return null;
        }
        
        @Override
        public Object getAttribute(final ObjectName name, final String attribute) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException {
            return null;
        }
        
        @Override
        public AttributeList getAttributes(final ObjectName name, final String[] attributes) throws InstanceNotFoundException, ReflectionException {
            return null;
        }
        
        @Override
        public void setAttribute(final ObjectName name, final Attribute attribute) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException {
        }
        
        @Override
        public AttributeList setAttributes(final ObjectName name, final AttributeList attributes) throws InstanceNotFoundException, ReflectionException {
            return null;
        }
        
        @Override
        public Object invoke(final ObjectName name, final String operationName, final Object[] params, final String[] signature) throws InstanceNotFoundException, MBeanException, ReflectionException {
            return null;
        }
        
        @Override
        public String getDefaultDomain() {
            return null;
        }
        
        @Override
        public String[] getDomains() {
            return new String[0];
        }
        
        @Override
        public void addNotificationListener(final ObjectName name, final NotificationListener listener, final NotificationFilter filter, final Object handback) throws InstanceNotFoundException {
        }
        
        @Override
        public void addNotificationListener(final ObjectName name, final ObjectName listener, final NotificationFilter filter, final Object handback) throws InstanceNotFoundException {
        }
        
        @Override
        public void removeNotificationListener(final ObjectName name, final ObjectName listener) throws InstanceNotFoundException, ListenerNotFoundException {
        }
        
        @Override
        public void removeNotificationListener(final ObjectName name, final ObjectName listener, final NotificationFilter filter, final Object handback) throws InstanceNotFoundException, ListenerNotFoundException {
        }
        
        @Override
        public void removeNotificationListener(final ObjectName name, final NotificationListener listener) throws InstanceNotFoundException, ListenerNotFoundException {
        }
        
        @Override
        public void removeNotificationListener(final ObjectName name, final NotificationListener listener, final NotificationFilter filter, final Object handback) throws InstanceNotFoundException, ListenerNotFoundException {
        }
        
        @Override
        public MBeanInfo getMBeanInfo(final ObjectName name) throws InstanceNotFoundException, IntrospectionException, ReflectionException {
            return null;
        }
        
        @Override
        public boolean isInstanceOf(final ObjectName name, final String className) throws InstanceNotFoundException {
            return false;
        }
        
        @Override
        public Object instantiate(final String className) throws ReflectionException, MBeanException {
            return null;
        }
        
        @Override
        public Object instantiate(final String className, final ObjectName loaderName) throws ReflectionException, MBeanException, InstanceNotFoundException {
            return null;
        }
        
        @Override
        public Object instantiate(final String className, final Object[] params, final String[] signature) throws ReflectionException, MBeanException {
            return null;
        }
        
        @Override
        public Object instantiate(final String className, final ObjectName loaderName, final Object[] params, final String[] signature) throws ReflectionException, MBeanException, InstanceNotFoundException {
            return null;
        }
        
        @Override
        public ObjectInputStream deserialize(final ObjectName name, final byte[] data) throws InstanceNotFoundException, OperationsException {
            return null;
        }
        
        @Override
        public ObjectInputStream deserialize(final String className, final byte[] data) throws OperationsException, ReflectionException {
            return null;
        }
        
        @Override
        public ObjectInputStream deserialize(final String className, final ObjectName loaderName, final byte[] data) throws InstanceNotFoundException, OperationsException, ReflectionException {
            return null;
        }
        
        @Override
        public ClassLoader getClassLoaderFor(final ObjectName mbeanName) throws InstanceNotFoundException {
            return null;
        }
        
        @Override
        public ClassLoader getClassLoader(final ObjectName loaderName) throws InstanceNotFoundException {
            return null;
        }
        
        @Override
        public ClassLoaderRepository getClassLoaderRepository() {
            return null;
        }
    }
    
    private static class PassthroughMBean extends ManagedBean
    {
    }
}
