// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.tomcat;

import java.util.Optional;
import javax.enterprise.inject.spi.InjectionTarget;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.context.spi.Contextual;
import javax.enterprise.inject.spi.AnnotatedType;
import javax.enterprise.inject.spi.CDI;
import org.apache.webbeans.servlet.WebBeansConfigurationListener;
import javax.naming.NamingException;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import org.apache.tomcat.InstanceManager;

public class CDIInstanceManager implements InstanceManager
{
    private final Map<Object, Runnable> destroyables;
    
    public CDIInstanceManager() {
        this.destroyables = new ConcurrentHashMap<Object, Runnable>();
    }
    
    public Object newInstance(final Class<?> clazz) throws IllegalAccessException, InvocationTargetException, NamingException, InstantiationException {
        final Object newInstance = clazz.newInstance();
        this.newInstance(newInstance);
        return newInstance;
    }
    
    public Object newInstance(final String className) throws IllegalAccessException, InvocationTargetException, NamingException, InstantiationException, ClassNotFoundException {
        return this.newInstance(className, Thread.currentThread().getContextClassLoader());
    }
    
    public Object newInstance(final String fqcn, final ClassLoader classLoader) throws IllegalAccessException, InvocationTargetException, NamingException, InstantiationException, ClassNotFoundException {
        return this.newInstance(classLoader.loadClass(fqcn));
    }
    
    public void newInstance(final Object o) throws IllegalAccessException, InvocationTargetException, NamingException {
        if (WebBeansConfigurationListener.class.isInstance(o) || o.getClass().getName().startsWith("org.apache.catalina.servlets.")) {
            return;
        }
        final BeanManager bm = CDI.current().getBeanManager();
        final AnnotatedType<?> annotatedType = (AnnotatedType<?>)bm.createAnnotatedType((Class)o.getClass());
        final InjectionTarget injectionTarget = bm.createInjectionTarget((AnnotatedType)annotatedType);
        final CreationalContext<Object> creationalContext = (CreationalContext<Object>)bm.createCreationalContext((Contextual)null);
        injectionTarget.inject(o, (CreationalContext)creationalContext);
        try {
            injectionTarget.postConstruct(o);
        }
        catch (RuntimeException e) {
            creationalContext.release();
            throw e;
        }
        final InjectionTarget injectionTarget2;
        final CreationalContext creationalContext2;
        this.destroyables.put(o, () -> {
            try {
                injectionTarget2.preDestroy(o);
            }
            finally {
                creationalContext2.release();
            }
        });
    }
    
    public void destroyInstance(final Object o) throws IllegalAccessException, InvocationTargetException {
        Optional.ofNullable(this.destroyables.remove(o)).ifPresent(Runnable::run);
    }
}
