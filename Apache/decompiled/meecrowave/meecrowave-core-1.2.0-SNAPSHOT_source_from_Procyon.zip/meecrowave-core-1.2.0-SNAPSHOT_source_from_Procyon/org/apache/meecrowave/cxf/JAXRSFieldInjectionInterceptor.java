// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.cxf;

import org.apache.webbeans.annotation.EmptyAnnotationLiteral;
import javax.interceptor.InterceptorBinding;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.Annotation;
import org.apache.cxf.message.Message;
import org.apache.cxf.jaxrs.model.AbstractResourceInfo;
import org.apache.cxf.jaxrs.utils.InjectionUtils;
import org.apache.cxf.jaxrs.provider.ProviderFactory;
import org.apache.cxf.jaxrs.model.MethodInvocationInfo;
import org.apache.cxf.jaxrs.model.ApplicationInfo;
import javax.ws.rs.core.Application;
import org.apache.webbeans.intercept.ConstructorInterceptorInvocationContext;
import org.apache.cxf.jaxrs.model.OperationResourceInfoStack;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import javax.interceptor.AroundInvoke;
import javax.interceptor.AroundConstruct;
import javax.interceptor.InvocationContext;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.Priority;
import javax.interceptor.Interceptor;
import java.io.Serializable;

@Interceptor
@Priority(0)
@Binding
public class JAXRSFieldInjectionInterceptor implements Serializable
{
    private final AtomicBoolean injected;
    
    public JAXRSFieldInjectionInterceptor() {
        this.injected = new AtomicBoolean();
    }
    
    @AroundConstruct
    public Object injectContexts(final InvocationContext ic) throws Exception {
        this.doInject(ic);
        return ic.proceed();
    }
    
    @AroundInvoke
    public Object lazyInjectContexts(final InvocationContext ic) throws Exception {
        if (!this.injected.get()) {
            this.doInject(ic);
        }
        return ic.proceed();
    }
    
    private void doInject(final InvocationContext ic) throws Exception {
        final Message current = JAXRSUtils.getCurrentMessage();
        if (current != null) {
            final OperationResourceInfoStack stack = OperationResourceInfoStack.class.cast(current.get((Object)OperationResourceInfoStack.class.getName()));
            if (stack != null && !stack.isEmpty()) {
                Object instance;
                if (ConstructorInterceptorInvocationContext.class.isInstance(ic)) {
                    final ConstructorInterceptorInvocationContext constructorInterceptorInvocationContext = ConstructorInterceptorInvocationContext.class.cast(ic);
                    constructorInterceptorInvocationContext.directProceed();
                    instance = constructorInterceptorInvocationContext.getNewInstance();
                }
                else {
                    instance = ic.getTarget();
                }
                Application application = null;
                final Object appInfo = current.getExchange().getEndpoint().get((Object)Application.class.getName());
                if (ApplicationInfo.class.isInstance(appInfo)) {
                    application = (Application)ApplicationInfo.class.cast(appInfo).getProvider();
                }
                synchronized (this) {
                    if (this.injected.get()) {
                        return;
                    }
                    InjectionUtils.injectContextProxiesAndApplication((AbstractResourceInfo)((MethodInvocationInfo)stack.lastElement()).getMethodInfo().getClassResourceInfo(), instance, application, ProviderFactory.getInstance(current));
                    this.injected.compareAndSet(false, true);
                }
            }
        }
    }
    
    @Target({ ElementType.TYPE })
    @Retention(RetentionPolicy.RUNTIME)
    @InterceptorBinding
    public @interface Binding {
        public static final Annotation INSTANCE = new EmptyAnnotationLiteral<Binding>() {
            public Class<? extends Annotation> annotationType() {
                return Binding.class;
            }
        };
    }
}
