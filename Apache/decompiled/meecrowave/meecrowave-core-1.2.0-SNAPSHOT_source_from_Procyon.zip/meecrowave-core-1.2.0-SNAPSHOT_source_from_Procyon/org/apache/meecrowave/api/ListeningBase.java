// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.api;

import org.apache.catalina.Host;
import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;

public abstract class ListeningBase
{
    private final Connector connector;
    private final Context context;
    private final Host host;
    
    ListeningBase(final Connector connector, final Host host, final Context context) {
        this.connector = connector;
        this.host = host;
        this.context = context;
    }
    
    public Context getContext() {
        return this.context;
    }
    
    public Connector getConnector() {
        return this.connector;
    }
    
    public Host getHost() {
        return this.host;
    }
    
    public String getFirstBase() {
        return (this.connector.getSecure() ? "https" : "http") + "://" + this.host.getName() + ((this.connector.getPort() > 0) ? (":" + this.connector.getPort()) : "") + this.context.getPath();
    }
}
