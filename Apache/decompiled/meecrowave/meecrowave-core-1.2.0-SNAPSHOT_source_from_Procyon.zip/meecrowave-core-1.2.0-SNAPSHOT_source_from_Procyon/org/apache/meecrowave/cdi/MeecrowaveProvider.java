// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.cdi;

import org.apache.webbeans.container.OwbCDIProvider;

public class MeecrowaveProvider extends OwbCDIProvider
{
}
