// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.logging.openwebbeans;

import org.apache.meecrowave.logging.jul.Log4j2Logger;
import java.util.ResourceBundle;
import java.util.logging.Logger;
import java.util.Locale;
import org.apache.webbeans.logger.WebBeansLoggerFactory;

public class Log4j2LoggerFactory implements WebBeansLoggerFactory
{
    public Logger getLogger(final Class<?> clazz, final Locale desiredLocale) {
        return (Logger)new Log4j2Logger(clazz.getName(), ResourceBundle.getBundle("openwebbeans/Messages", desiredLocale).toString());
    }
    
    public Logger getLogger(final Class<?> clazz) {
        return (Logger)new Log4j2Logger(clazz.getName(), "openwebbeans/Messages");
    }
}
