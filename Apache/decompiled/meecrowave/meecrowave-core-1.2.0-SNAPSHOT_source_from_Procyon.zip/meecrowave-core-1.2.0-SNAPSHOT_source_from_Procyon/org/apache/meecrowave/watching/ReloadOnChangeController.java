// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.watching;

import java.util.Arrays;
import java.nio.file.WatchKey;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.FileVisitResult;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.SimpleFileVisitor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import java.util.Iterator;
import java.io.IOException;
import org.apache.meecrowave.logging.tomcat.LogFacade;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.io.File;
import java.util.ArrayList;
import java.nio.file.WatchService;
import java.nio.file.Path;
import java.util.Collection;
import org.apache.catalina.Context;

public class ReloadOnChangeController implements AutoCloseable, Runnable
{
    private final Context context;
    private final long bouncing;
    private final Collection<Path> paths;
    private WatchService watchService;
    private Thread bouncer;
    private Thread watcher;
    private volatile boolean running;
    private volatile long redeployMarker;
    
    public ReloadOnChangeController(final Context context, final int watcherBouncing) {
        this.paths = new ArrayList<Path>();
        this.running = true;
        this.redeployMarker = System.nanoTime();
        this.context = context;
        this.bouncing = watcherBouncing;
    }
    
    public void register(final File folder) {
        this.paths.add(folder.toPath());
    }
    
    public void start() {
        if (this.paths.isEmpty()) {
            return;
        }
        try {
            this.watchService = this.paths.iterator().next().getFileSystem().newWatchService();
            for (final Path p : this.paths) {
                p.register(this.watchService, (WatchEvent.Kind<?>[])new WatchEvent.Kind[] { StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY, StandardWatchEventKinds.ENTRY_DELETE });
            }
        }
        catch (IOException ex) {
            new LogFacade(ReloadOnChangeController.class.getName()).warn("Hot reloading will not be available", ex);
        }
        (this.watcher = new Thread(this)).setName("meecrowave-watcher-controller");
        this.watcher.start();
    }
    
    protected synchronized void redeploy() {
        this.context.reload();
    }
    
    @Override
    public void close() {
        if (!this.running) {
            return;
        }
        this.running = false;
        final long waitMs = this.bouncing * 2L + 5000L;
        if (this.bouncer != null) {
            try {
                this.bouncer.join(waitMs);
            }
            catch (InterruptedException e) {
                Thread.interrupted();
            }
        }
        if (this.watcher != null) {
            try {
                this.watcher.join(waitMs);
            }
            catch (InterruptedException e) {
                Thread.interrupted();
            }
        }
    }
    
    public boolean shouldRun() {
        return !this.paths.isEmpty();
    }
    
    @Override
    public void run() {
        if (this.watchService == null) {
            return;
        }
        final CountDownLatch latch = new CountDownLatch(1);
        long last;
        final CountDownLatch countDownLatch;
        boolean needsRedeploy;
        long antepenultiem;
        (this.bouncer = new Thread(() -> {
            last = this.redeployMarker;
            countDownLatch.countDown();
            needsRedeploy = false;
            antepenultiem = -1L;
            while (this.running) {
                if (this.redeployMarker > last) {
                    antepenultiem = last;
                    last = this.redeployMarker;
                    needsRedeploy = true;
                }
                else if (needsRedeploy) {
                    antepenultiem = last;
                }
                try {
                    Thread.sleep(this.bouncing);
                }
                catch (InterruptedException e3) {
                    Thread.interrupted();
                    break;
                }
                if (needsRedeploy && last == antepenultiem) {
                    new LogFacade(ReloadOnChangeController.class.getName()).info("Redeploying " + this.context.getName());
                    this.redeploy();
                }
            }
            return;
        })).setName("meecrowave-watcher-redeployer");
        this.bouncer.start();
        try {
            latch.await(1L, TimeUnit.MINUTES);
        }
        catch (InterruptedException e4) {
            Thread.interrupted();
            return;
        }
        this.paths.forEach(p -> {
            try {
                Files.walkFileTree(p, new SimpleFileVisitor<Path>() {
                    @Override
                    public FileVisitResult preVisitDirectory(final Path dir, final BasicFileAttributes attrs) throws IOException {
                        dir.register(ReloadOnChangeController.this.watchService, (WatchEvent.Kind<?>[])new WatchEvent.Kind[] { StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_DELETE, StandardWatchEventKinds.ENTRY_MODIFY });
                        return FileVisitResult.CONTINUE;
                    }
                });
            }
            catch (IOException e) {
                new LogFacade(ReloadOnChangeController.class.getName()).warn(e.getMessage());
            }
            return;
        });
        try {
            while (this.running) {
                final WatchKey watchKey = this.watchService.poll(this.bouncing, TimeUnit.MILLISECONDS);
                if (watchKey == null) {
                    Thread.sleep(this.bouncing);
                }
                else {
                    boolean foundNew = false;
                    for (final WatchEvent<?> event : watchKey.pollEvents()) {
                        final Path path = Path.class.cast(event.context());
                        final WatchEvent.Kind<?> kind = event.kind();
                        if (!this.isIgnored(kind, path)) {
                            foundNew = true;
                            final File file = path.toAbsolutePath().toFile();
                            if (file.isDirectory() && kind == StandardWatchEventKinds.ENTRY_CREATE) {
                                try {
                                    path.register(this.watchService, (WatchEvent.Kind<?>[])new WatchEvent.Kind[] { StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY, StandardWatchEventKinds.ENTRY_DELETE });
                                }
                                catch (IOException e2) {
                                    new LogFacade(ReloadOnChangeController.class.getName()).warn(e2.getMessage());
                                }
                                break;
                            }
                            break;
                        }
                    }
                    if (foundNew) {
                        new LogFacade(ReloadOnChangeController.class.getName()).info("Marking to redeploy " + this.context.getName());
                        this.redeployMarker = System.nanoTime();
                    }
                    if (watchKey.reset()) {
                        continue;
                    }
                    watchKey.cancel();
                }
            }
        }
        catch (InterruptedException ie) {
            Thread.interrupted();
        }
    }
    
    private boolean isIgnored(final WatchEvent.Kind<?> kind, final Path path) {
        final String pathStr = path.toString();
        return pathStr.endsWith("___jb_tmp___") || pathStr.endsWith("___jb_old___") || pathStr.endsWith("~") || this.isResource(pathStr);
    }
    
    private boolean isResource(final String pathStr) {
        final int idx = pathStr.lastIndexOf(46);
        return idx > 0 && Arrays.asList(".html", ".xhtml", ".js", ".ts", ".css", ".png", ".svg", ".jpg", ".jpeg").contains(pathStr.substring(idx));
    }
}
