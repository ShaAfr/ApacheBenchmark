// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.meecrowave.cxf;

import java.lang.reflect.Field;
import org.apache.cxf.jaxrs.model.ProviderInfo;
import java.util.Collection;
import org.apache.cxf.common.util.ReflectionUtil;
import org.apache.cxf.jaxrs.provider.ProviderFactory;
import org.apache.cxf.service.model.EndpointInfo;
import org.apache.cxf.jaxrs.model.MethodDispatcher;
import java.util.Iterator;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.jaxrs.provider.ServerProviderFactory;
import org.apache.cxf.jaxrs.model.AbstractResourceInfo;
import java.util.Collections;
import org.apache.cxf.jaxrs.model.OperationResourceInfo;
import org.apache.cxf.jaxrs.model.ClassResourceInfo;
import java.util.ArrayList;
import org.apache.cxf.jaxrs.JAXRSServiceFactoryBean;
import javax.ws.rs.core.Application;
import org.apache.cxf.jaxrs.model.ApplicationInfo;
import org.apache.cxf.transport.ChainInitiationObserver;
import org.apache.cxf.transport.http.DestinationRegistry;
import java.util.Objects;
import java.util.function.Function;
import org.apache.cxf.transport.servlet.ServletDestination;
import org.apache.meecrowave.logging.tomcat.LogFacade;
import org.apache.cxf.cdi.CXFCdiServlet;
import java.util.List;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.Method;
import java.util.Map;
import javax.servlet.FilterRegistration;
import java.util.function.BiConsumer;
import java.util.EnumSet;
import javax.servlet.DispatcherType;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.function.Predicate;
import java.util.stream.Stream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.FilterChain;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import javax.servlet.ServletException;
import java.util.Enumeration;
import javax.servlet.ServletConfig;
import javax.servlet.FilterConfig;
import javax.servlet.Filter;
import org.apache.meecrowave.Meecrowave;
import javax.servlet.ServletContext;
import java.util.Set;
import javax.servlet.ServletContainerInitializer;

public class CxfCdiAutoSetup implements ServletContainerInitializer
{
    private static final String NAME = "cxf-cdi";
    
    public void onStartup(final Set<Class<?>> c, final ServletContext ctx) throws ServletException {
        final Meecrowave.Builder builder = Meecrowave.Builder.class.cast(ctx.getAttribute("meecrowave.configuration"));
        final MeecrowaveCXFCdiServlet delegate = new MeecrowaveCXFCdiServlet();
        final FilterRegistration.Dynamic jaxrs = ctx.addFilter("cxf-cdi", (Filter)new Filter() {
            private final String servletPath = builder.getJaxrsMapping().endsWith("/*") ? builder.getJaxrsMapping().substring(0, builder.getJaxrsMapping().length() - 2) : builder.getJaxrsMapping();
            
            public void init(final FilterConfig filterConfig) throws ServletException {
                delegate.init((ServletConfig)new ServletConfig() {
                    public String getServletName() {
                        return "cxf-cdi";
                    }
                    
                    public ServletContext getServletContext() {
                        return filterConfig.getServletContext();
                    }
                    
                    public String getInitParameter(final String name) {
                        return filterConfig.getInitParameter(name);
                    }
                    
                    public Enumeration<String> getInitParameterNames() {
                        return (Enumeration<String>)filterConfig.getInitParameterNames();
                    }
                });
            }
            
            public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {
                if (!HttpServletRequest.class.isInstance(request)) {
                    chain.doFilter(request, response);
                    return;
                }
                final HttpServletRequest http = HttpServletRequest.class.cast(request);
                final String path = http.getRequestURI().substring(http.getContextPath().length());
                final Optional<String> app = Stream.of(delegate.prefixes).filter(path::startsWith).findAny();
                if (app.isPresent()) {
                    delegate.service((ServletRequest)new HttpServletRequestWrapper(http) {
                        public String getPathInfo() {
                            return path;
                        }
                        
                        public String getServletPath() {
                            return Filter.this.servletPath;
                        }
                    }, response);
                }
                else {
                    chain.doFilter(request, response);
                }
            }
            
            public void destroy() {
                delegate.destroy();
            }
        });
        jaxrs.setAsyncSupported(true);
        jaxrs.addMappingForUrlPatterns((EnumSet)EnumSet.allOf(DispatcherType.class), true, new String[] { builder.getJaxrsMapping() });
        Optional.ofNullable(builder.getCxfServletParams()).ifPresent(m -> m.forEach(jaxrs::setInitParameter));
    }
    
    private static String uproxyName(final String clazz) {
        if (clazz.contains("$$")) {
            return clazz.substring(0, clazz.indexOf("$$"));
        }
        return clazz;
    }
    
    private static class Logs
    {
        private static String forceLength(final String httpMethod, final int l, final boolean right) {
            String http;
            if (httpMethod == null) {
                http = "";
            }
            else {
                http = httpMethod;
            }
            final StringBuilder builder = new StringBuilder();
            if (!right) {
                for (int i = 0; i < l - http.length(); ++i) {
                    builder.append(" ");
                }
            }
            builder.append(http);
            if (right) {
                for (int i = 0; i < l - http.length(); ++i) {
                    builder.append(" ");
                }
            }
            return builder.toString();
        }
        
        private static String toSimpleString(final Method mtd) {
            try {
                final StringBuilder sb = new StringBuilder();
                final Type[] typeparms = mtd.getTypeParameters();
                if (typeparms.length > 0) {
                    boolean first = true;
                    sb.append("<");
                    for (final Type typeparm : typeparms) {
                        if (!first) {
                            sb.append(",");
                        }
                        sb.append(name(typeparm));
                        first = false;
                    }
                    sb.append("> ");
                }
                final Type genRetType = mtd.getGenericReturnType();
                sb.append(name(genRetType)).append(" ");
                sb.append(mtd.getName()).append("(");
                final Type[] params = mtd.getGenericParameterTypes();
                for (int j = 0; j < params.length; ++j) {
                    sb.append(name(params[j]));
                    if (j < params.length - 1) {
                        sb.append(", ");
                    }
                }
                sb.append(")");
                final Type[] exceptions = mtd.getGenericExceptionTypes();
                if (exceptions.length > 0) {
                    sb.append(" throws ");
                    for (int k = 0; k < exceptions.length; ++k) {
                        sb.append(name(exceptions[k]));
                        if (k < exceptions.length - 1) {
                            sb.append(",");
                        }
                    }
                }
                return sb.toString();
            }
            catch (Exception e) {
                return "<" + e + ">";
            }
        }
        
        private static String name(final Type type) {
            if (type instanceof Class) {
                return ((Class)type).getSimpleName().replace("java.lang.", "").replace("java.util", "");
            }
            if (type instanceof ParameterizedType) {
                final ParameterizedType pt = (ParameterizedType)type;
                final StringBuilder builder = new StringBuilder();
                builder.append(name(pt.getRawType()));
                final Type[] args = pt.getActualTypeArguments();
                if (args != null) {
                    builder.append("<");
                    for (int i = 0; i < args.length; ++i) {
                        builder.append(name(args[i]));
                        if (i < args.length - 1) {
                            builder.append(", ");
                        }
                    }
                    builder.append(">");
                }
                return builder.toString();
            }
            return type.toString();
        }
        
        private static String singleSlash(final String address, final String value) {
            if (address.endsWith("/") && value.startsWith("/")) {
                return address + value.substring(1);
            }
            if (!address.endsWith("/") && !value.startsWith("/")) {
                return address + '/' + value;
            }
            return address + value;
        }
        
        private static class LogOperationEndpointInfo implements Comparable<LogOperationEndpointInfo>
        {
            private final String http;
            private final String address;
            private final String method;
            
            private LogOperationEndpointInfo(final String http, final String address, final String method) {
                this.address = address;
                this.method = method;
                if (http != null) {
                    this.http = http;
                }
                else {
                    this.http = "";
                }
            }
            
            @Override
            public int compareTo(final LogOperationEndpointInfo o) {
                int compare = this.http.compareTo(o.http);
                if (compare != 0) {
                    return compare;
                }
                compare = this.address.compareTo(o.address);
                if (compare != 0) {
                    return compare;
                }
                return this.method.compareTo(o.method);
            }
        }
        
        private static class LogResourceEndpointInfo implements Comparable<LogResourceEndpointInfo>
        {
            private final String address;
            private final String classname;
            private final List<LogOperationEndpointInfo> operations;
            private final int methodSize;
            private final int methodStrSize;
            
            private LogResourceEndpointInfo(final String address, final String classname, final List<LogOperationEndpointInfo> operations, final int methodSize, final int methodStrSize) {
                this.address = address;
                this.classname = classname;
                this.operations = operations;
                this.methodSize = methodSize;
                this.methodStrSize = methodStrSize;
            }
            
            @Override
            public int compareTo(final LogResourceEndpointInfo o) {
                final int compare = this.address.compareTo(o.address);
                if (compare != 0) {
                    return compare;
                }
                return this.classname.compareTo(o.classname);
            }
        }
    }
    
    private static class MeecrowaveCXFCdiServlet extends CXFCdiServlet
    {
        private String[] prefixes;
        
        public void init(final ServletConfig sc) throws ServletException {
            super.init(sc);
            final LogFacade log = new LogFacade(CxfCdiAutoSetup.class.getName());
            final DestinationRegistry registry = this.getDestinationRegistryFromBusOrDefault((String)null);
            this.prefixes = (String[])registry.getDestinations().stream().filter(ServletDestination.class::isInstance).map(ServletDestination.class::cast).map(this.getServletDestinationPath(sc, log)).filter(Objects::nonNull).toArray(String[]::new);
        }
        
        private Function<ServletDestination, String> getServletDestinationPath(final ServletConfig sc, final LogFacade log) {
            final Endpoint endpoint;
            final ApplicationInfo app;
            final JAXRSServiceFactoryBean sfb;
            final String base;
            ArrayList<Logs.LogResourceEndpointInfo> resourcesToLog;
            int classSize;
            int addressSize;
            List resources;
            final Iterator<ClassResourceInfo> iterator;
            ClassResourceInfo info2;
            String address;
            String clazz;
            int methodSize;
            int methodStrSize;
            ArrayList<Logs.LogOperationEndpointInfo> toLog;
            MethodDispatcher md;
            final Iterator<OperationResourceInfo> iterator2;
            OperationResourceInfo ori;
            String httpMethod;
            String currentAddress;
            String methodToStr;
            int fClassSize;
            int fAddressSize;
            final int n;
            ServerProviderFactory spf;
            EndpointInfo endpointInfo;
            return (Function<ServletDestination, String>)(sd -> {
                endpoint = ChainInitiationObserver.class.cast(sd.getMessageObserver()).getEndpoint();
                app = ApplicationInfo.class.cast(endpoint.get((Object)Application.class.getName()));
                sfb = JAXRSServiceFactoryBean.class.cast(endpoint.get((Object)JAXRSServiceFactoryBean.class.getName()));
                base = sd.getEndpointInfo().getAddress();
                if (sfb != null) {
                    resourcesToLog = new ArrayList<Logs.LogResourceEndpointInfo>();
                    classSize = 0;
                    addressSize = 0;
                    resources = sfb.getClassResourceInfo();
                    resources.iterator();
                    while (iterator.hasNext()) {
                        info2 = iterator.next();
                        if (info2.getResourceClass() == null) {
                            continue;
                        }
                        else {
                            address = singleSlash(base, info2.getURITemplate().getValue());
                            clazz = uproxyName(info2.getResourceClass().getName());
                            classSize = Math.max(classSize, clazz.length());
                            addressSize = Math.max(addressSize, address.length());
                            methodSize = 7;
                            methodStrSize = 0;
                            toLog = new ArrayList<Logs.LogOperationEndpointInfo>();
                            md = info2.getMethodDispatcher();
                            md.getOperationResourceInfos().iterator();
                            while (iterator2.hasNext()) {
                                ori = iterator2.next();
                                httpMethod = ori.getHttpMethod();
                                currentAddress = singleSlash(address, ori.getURITemplate().getValue());
                                methodToStr = toSimpleString(ori.getMethodToInvoke());
                                toLog.add(new Logs.LogOperationEndpointInfo(httpMethod, currentAddress, methodToStr));
                                if (httpMethod != null) {
                                    methodSize = Math.max(methodSize, httpMethod.length());
                                }
                                addressSize = Math.max(addressSize, currentAddress.length());
                                methodStrSize = Math.max(methodStrSize, methodToStr.length());
                            }
                            Collections.sort(toLog);
                            resourcesToLog.add(new Logs.LogResourceEndpointInfo(address, clazz, (List)toLog, methodSize, methodStrSize));
                        }
                    }
                    log.info("REST Application: " + endpoint.getEndpointInfo().getAddress() + " -> " + Optional.ofNullable(app).map((Function<? super ApplicationInfo, ?>)AbstractResourceInfo::getResourceClass).map((Function<? super Object, ?>)Class::getName).map(x$0 -> uproxyName(x$0)).orElse(""));
                    Collections.sort(resourcesToLog);
                    fClassSize = classSize;
                    fAddressSize = addressSize;
                    resourcesToLog.forEach(resource -> {
                        log.info("     Service URI: " + forceLength(resource.address, n, true) + " -> " + forceLength(resource.classname, fClassSize, true));
                        resource.operations.forEach(info -> log.info("          " + forceLength(info.http, resource.methodSize, false) + " " + forceLength(info.address, n, true) + " ->      " + forceLength(info.method, resource.methodStrSize, true)));
                        resource.operations.clear();
                        return;
                    });
                    resourcesToLog.clear();
                    if (Meecrowave.Builder.class.cast(sc.getServletContext().getAttribute("meecrowave.configuration")).isJaxrsLogProviders()) {
                        spf = ServerProviderFactory.class.cast(endpoint.get((Object)ServerProviderFactory.class.getName()));
                        this.dump(log, spf, "MessageBodyReaders", "messageReaders");
                        this.dump(log, spf, "MessageBodyWriters", "messageWriters");
                    }
                }
                else {
                    endpointInfo = endpoint.getEndpointInfo();
                    if (endpointInfo.getName() != null) {
                        log.info("@WebService > " + endpointInfo.getName().toString() + " -> " + base);
                    }
                }
                return base;
            });
        }
        
        private void dump(final LogFacade log, final ServerProviderFactory spf, final String description, final String fieldName) {
            final Field field = ReflectionUtil.getDeclaredField((Class)ProviderFactory.class, fieldName);
            if (!field.isAccessible()) {
                field.setAccessible(true);
            }
            try {
                final Collection<ProviderInfo<?>> providers = Collection.class.cast(field.get(spf));
                log.info("     " + description);
                providers.stream().map((Function<? super ProviderInfo<?>, ?>)ProviderInfo::getProvider).forEach(o -> {
                    try {
                        log.info("       - " + o);
                    }
                    catch (RuntimeException ex) {}
                });
            }
            catch (IllegalAccessException ex2) {}
        }
    }
}
