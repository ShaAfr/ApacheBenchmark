/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 */
package org.apache.spark.deploy.history;

import org.apache.spark.deploy.history.CacheKey;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;

public final class CacheKey$
extends AbstractFunction2<String, Option<String>, CacheKey>
implements Serializable {
    public static final CacheKey$ MODULE$;

    public static {
        new org.apache.spark.deploy.history.CacheKey$();
    }

    public final String toString() {
        return "CacheKey";
    }

    public CacheKey apply(String appId, Option<String> attemptId) {
        return new CacheKey(appId, attemptId);
    }

    public Option<Tuple2<String, Option<String>>> unapply(CacheKey x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)x$0.appId(), x$0.attemptId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private CacheKey$() {
        MODULE$ = this;
    }
}

