/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.broadcast;

public final class package$ {
    public static final package$ MODULE$;

    public static {
        new org.apache.spark.broadcast.package$();
    }

    private package$() {
        MODULE$ = this;
    }
}

