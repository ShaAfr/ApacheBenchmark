/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Option
 *  scala.Product2
 *  scala.collection.Iterator
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.shuffle;

import java.io.IOException;
import org.apache.spark.scheduler.MapStatus;
import scala.Option;
import scala.Product2;
import scala.collection.Iterator;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001Y4a!\u0001\u0002\u0002\u0002\u0011Q!!D*ik\u001a4G.Z,sSR,'O\u0003\u0002\u0004\t\u000591\u000f[;gM2,'BA\u0003\u0007\u0003\u0015\u0019\b/\u0019:l\u0015\t9\u0001\"\u0001\u0004ba\u0006\u001c\u0007.\u001a\u0006\u0002\u0013\u0005\u0019qN]4\u0016\u0007-QBe\u0005\u0002\u0001\u0019A\u0011Q\u0002E\u0007\u0002\u001d)\tq\"A\u0003tG\u0006d\u0017-\u0003\u0002\u0012\u001d\t1\u0011I\\=SK\u001aDQa\u0005\u0001\u0005\u0002U\ta\u0001P5oSRt4\u0001\u0001\u000b\u0002-A!q\u0003\u0001\r$\u001b\u0005\u0011\u0001CA\r\u001b\u0019\u0001!Qa\u0007\u0001C\u0002q\u0011\u0011aS\t\u0003;\u0001\u0002\"!\u0004\u0010\n\u0005}q!a\u0002(pi\"Lgn\u001a\t\u0003\u001b\u0005J!A\t\b\u0003\u0007\u0005s\u0017\u0010\u0005\u0002\u001aI\u0011)Q\u0005\u0001b\u00019\t\ta\u000bC\u0003(\u0001\u0019\u0005\u0001&A\u0003xe&$X\r\u0006\u0002*YA\u0011QBK\u0005\u0003W9\u0011A!\u00168ji\")QF\na\u0001]\u00059!/Z2pe\u0012\u001c\bcA\u00188u9\u0011\u0001'\u000e\b\u0003cQj\u0011A\r\u0006\u0003gQ\ta\u0001\u0010:p_Rt\u0014\"A\b\n\u0005Yr\u0011a\u00029bG.\fw-Z\u0005\u0003qe\u0012\u0001\"\u0013;fe\u0006$xN\u001d\u0006\u0003m9\u0001B!D\u001e\u0019G%\u0011AH\u0004\u0002\t!J|G-^2ue!\u001aaEP%\u0011\u00075y\u0014)\u0003\u0002A\u001d\t1A\u000f\u001b:poN\u0004\"AQ$\u000e\u0003\rS!\u0001R#\u0002\u0005%|'\"\u0001$\u0002\t)\fg/Y\u0005\u0003\u0011\u000e\u00131\"S(Fq\u000e,\u0007\u000f^5p]F\"aDS)e!\tYeJ\u0004\u0002\u000e\u0019&\u0011QJD\u0001\u0007!J,G-\u001a4\n\u0005=\u0003&AB*ue&twM\u0003\u0002N\u001dE*1E\u0015,`/V\u00111\u000bV\u000b\u0002\u0015\u0012)Q\u000b\u0006b\u00015\n\tA+\u0003\u0002X1\u0006YB\u0005\\3tg&t\u0017\u000e\u001e\u0013he\u0016\fG/\u001a:%I\u00164\u0017-\u001e7uIER!!\u0017\b\u0002\rQD'o\\<t#\ti2\f\u0005\u0002];:\u0011Q\"N\u0005\u0003=f\u0012\u0011\u0002\u00165s_^\f'\r\\32\u000b\r\u0002\u0017MY-\u000f\u00055\t\u0017BA-\u000fc\u0011\u0011SBD2\u0003\u000bM\u001c\u0017\r\\12\u0005\u0019\n\u0005\"\u00024\u0001\r\u00039\u0017\u0001B:u_B$\"\u0001[9\u0011\u00075I7.\u0003\u0002k\u001d\t1q\n\u001d;j_:\u0004\"\u0001\\8\u000e\u00035T!A\u001c\u0003\u0002\u0013M\u001c\u0007.\u001a3vY\u0016\u0014\u0018B\u00019n\u0005%i\u0015\r]*uCR,8\u000fC\u0003sK\u0002\u00071/A\u0004tk\u000e\u001cWm]:\u0011\u00055!\u0018BA;\u000f\u0005\u001d\u0011un\u001c7fC:\u0004")
public abstract class ShuffleWriter<K, V> {
    public abstract void write(Iterator<Product2<K, V>> var1) throws IOException;

    public abstract Option<MapStatus> stop(boolean var1);
}

