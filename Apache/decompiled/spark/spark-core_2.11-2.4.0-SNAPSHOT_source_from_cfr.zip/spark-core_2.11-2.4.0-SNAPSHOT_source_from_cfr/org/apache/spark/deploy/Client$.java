/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Predef$
 *  scala.sys.SystemProperties
 *  scala.sys.package$
 */
package org.apache.spark.deploy;

import org.apache.spark.SparkConf;
import org.apache.spark.deploy.ClientApp;
import scala.Predef$;
import scala.sys.SystemProperties;
import scala.sys.package$;

public final class Client$ {
    public static final Client$ MODULE$;

    public static {
        new org.apache.spark.deploy.Client$();
    }

    public void main(String[] args) {
        if (!package$.MODULE$.props().contains("SPARK_SUBMIT")) {
            Predef$.MODULE$.println((Object)"WARNING: This client is deprecated and will be removed in a future version of Spark");
            Predef$.MODULE$.println((Object)"Use ./bin/spark-submit with \"--master spark://host:port\"");
        }
        new ClientApp().start(args, new SparkConf());
    }

    private Client$() {
        MODULE$ = this;
    }
}

