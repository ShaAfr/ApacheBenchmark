/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.annotation.DeveloperApi
 *  scala.Product
 *  scala.Product$class
 *  scala.Serializable
 *  scala.collection.Iterator
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.ScalaRunTime$
 */
package org.apache.spark;

import org.apache.spark.TaskFailedReason;
import org.apache.spark.TaskFailedReason$class;
import org.apache.spark.annotation.DeveloperApi;
import scala.Product;
import scala.Serializable;
import scala.collection.Iterator;
import scala.runtime.BoxesRunTime;
import scala.runtime.ScalaRunTime$;

@DeveloperApi
public final class UnknownReason$
implements TaskFailedReason,
Product,
Serializable {
    public static final UnknownReason$ MODULE$;

    public static {
        new org.apache.spark.UnknownReason$();
    }

    @Override
    public boolean countTowardsTaskFailures() {
        return TaskFailedReason$class.countTowardsTaskFailures(this);
    }

    @Override
    public String toErrorString() {
        return "UnknownReason";
    }

    public String productPrefix() {
        return "UnknownReason";
    }

    public int productArity() {
        return 0;
    }

    public Object productElement(int x$1) {
        int n = x$1;
        throw new IndexOutOfBoundsException(((Object)BoxesRunTime.boxToInteger((int)x$1)).toString());
    }

    public Iterator<Object> productIterator() {
        return ScalaRunTime$.MODULE$.typedProductIterator((Product)this);
    }

    public boolean canEqual(Object x$1) {
        return x$1 instanceof UnknownReason$;
    }

    public int hashCode() {
        return -1830061298;
    }

    public String toString() {
        return "UnknownReason";
    }

    private Object readResolve() {
        return MODULE$;
    }

    private UnknownReason$() {
        MODULE$ = this;
        TaskFailedReason$class.$init$(this);
        Product.class.$init$((Product)this);
    }
}

