/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Serializable
 */
package org.apache.spark.shuffle;

import scala.Serializable;

public final class FetchFailedException$
implements Serializable {
    public static final FetchFailedException$ MODULE$;

    public static {
        new org.apache.spark.shuffle.FetchFailedException$();
    }

    public Throwable $lessinit$greater$default$6() {
        return null;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private FetchFailedException$() {
        MODULE$ = this;
    }
}

