/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.ExecutorLossReason;
import org.apache.spark.scheduler.ExecutorLost;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;

public final class ExecutorLost$
extends AbstractFunction2<String, ExecutorLossReason, ExecutorLost>
implements Serializable {
    public static final ExecutorLost$ MODULE$;

    public static {
        new org.apache.spark.scheduler.ExecutorLost$();
    }

    public final String toString() {
        return "ExecutorLost";
    }

    public ExecutorLost apply(String execId, ExecutorLossReason reason) {
        return new ExecutorLost(execId, reason);
    }

    public Option<Tuple2<String, ExecutorLossReason>> unapply(ExecutorLost x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)x$0.execId(), (Object)x$0.reason()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private ExecutorLost$() {
        MODULE$ = this;
    }
}

