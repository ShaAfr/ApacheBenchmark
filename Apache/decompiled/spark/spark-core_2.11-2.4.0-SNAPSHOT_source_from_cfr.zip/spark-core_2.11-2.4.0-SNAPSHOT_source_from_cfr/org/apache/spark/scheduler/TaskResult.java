/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.scheduler;

import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001\u00052\u0001\"\u0001\u0002\u0011\u0002G\u0005BA\u0003\u0002\u000b)\u0006\u001c8NU3tk2$(BA\u0002\u0005\u0003%\u00198\r[3ek2,'O\u0003\u0002\u0006\r\u0005)1\u000f]1sW*\u0011q\u0001C\u0001\u0007CB\f7\r[3\u000b\u0003%\t1a\u001c:h+\tY!c\u0005\u0002\u0001\u0019A\u0011Q\u0002E\u0007\u0002\u001d)\tq\"A\u0003tG\u0006d\u0017-\u0003\u0002\u0012\u001d\t1\u0011I\\=SK\u001a$Qa\u0005\u0001C\u0002U\u0011\u0011\u0001V\u0002\u0001#\t1\u0012\u0004\u0005\u0002\u000e/%\u0011\u0001D\u0004\u0002\b\u001d>$\b.\u001b8h!\ti!$\u0003\u0002\u001c\u001d\t\u0019\u0011I\\=*\u0007\u0001ir$\u0003\u0002\u001f\u0005\t\u0001B)\u001b:fGR$\u0016m]6SKN,H\u000e^\u0005\u0003A\t\u0011!#\u00138eSJ,7\r\u001e+bg.\u0014Vm];mi\u0002")
public interface TaskResult<T> {
}

