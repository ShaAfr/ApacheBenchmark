/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.unsafe.Platform
 *  org.apache.spark.unsafe.array.LongArray
 */
package org.apache.spark.shuffle.sort;

import org.apache.spark.shuffle.sort.PackedRecordPointer;
import org.apache.spark.unsafe.Platform;
import org.apache.spark.unsafe.array.LongArray;
import org.apache.spark.util.collection.SortDataFormat;

final class ShuffleSortDataFormat
extends SortDataFormat<PackedRecordPointer, LongArray> {
    private final LongArray buffer;

    ShuffleSortDataFormat(LongArray buffer) {
        this.buffer = buffer;
    }

    @Override
    public PackedRecordPointer getKey(LongArray data, int pos) {
        throw new UnsupportedOperationException();
    }

    @Override
    public PackedRecordPointer newKey() {
        return new PackedRecordPointer();
    }

    @Override
    public PackedRecordPointer getKey(LongArray data, int pos, PackedRecordPointer reuse) {
        reuse.set(data.get(pos));
        return reuse;
    }

    @Override
    public void swap(LongArray data, int pos0, int pos1) {
        long temp = data.get(pos0);
        data.set(pos0, data.get(pos1));
        data.set(pos1, temp);
    }

    @Override
    public void copyElement(LongArray src, int srcPos, LongArray dst, int dstPos) {
        dst.set(dstPos, src.get(srcPos));
    }

    @Override
    public void copyRange(LongArray src, int srcPos, LongArray dst, int dstPos, int length) {
        Platform.copyMemory((Object)src.getBaseObject(), (long)(src.getBaseOffset() + (long)srcPos * 8L), (Object)dst.getBaseObject(), (long)(dst.getBaseOffset() + (long)dstPos * 8L), (long)((long)length * 8L));
    }

    @Override
    public LongArray allocate(int length) {
        assert ((long)length <= this.buffer.size()) : "the buffer is smaller than required: " + this.buffer.size() + " < " + length;
        return this.buffer;
    }
}

