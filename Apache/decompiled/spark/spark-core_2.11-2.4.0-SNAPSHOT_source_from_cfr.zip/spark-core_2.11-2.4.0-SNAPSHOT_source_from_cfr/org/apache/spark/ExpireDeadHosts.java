/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.collection.Iterator
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark;

import org.apache.spark.ExpireDeadHosts$;
import scala.collection.Iterator;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001I;a!\u0001\u0002\t\u0002\nA\u0011aD#ya&\u0014X\rR3bI\"{7\u000f^:\u000b\u0005\r!\u0011!B:qCJ\\'BA\u0003\u0007\u0003\u0019\t\u0007/Y2iK*\tq!A\u0002pe\u001e\u0004\"!\u0003\u0006\u000e\u0003\t1aa\u0003\u0002\t\u0002\na!aD#ya&\u0014X\rR3bI\"{7\u000f^:\u0014\t)i1C\u0006\t\u0003\u001dEi\u0011a\u0004\u0006\u0002!\u0005)1oY1mC&\u0011!c\u0004\u0002\u0007\u0003:L(+\u001a4\u0011\u00059!\u0012BA\u000b\u0010\u0005\u001d\u0001&o\u001c3vGR\u0004\"AD\f\n\u0005ay!\u0001D*fe&\fG.\u001b>bE2,\u0007\"\u0002\u000e\u000b\t\u0003a\u0012A\u0002\u001fj]&$hh\u0001\u0001\u0015\u0003!AqA\b\u0006\u0002\u0002\u0013\u0005s$A\u0007qe>$Wo\u0019;Qe\u00164\u0017\u000e_\u000b\u0002AA\u0011\u0011EJ\u0007\u0002E)\u00111\u0005J\u0001\u0005Y\u0006twMC\u0001&\u0003\u0011Q\u0017M^1\n\u0005\u001d\u0012#AB*ue&tw\rC\u0004*\u0015\u0005\u0005I\u0011\u0001\u0016\u0002\u0019A\u0014x\u000eZ;di\u0006\u0013\u0018\u000e^=\u0016\u0003-\u0002\"A\u0004\u0017\n\u00055z!aA%oi\"9qFCA\u0001\n\u0003\u0001\u0014A\u00049s_\u0012,8\r^#mK6,g\u000e\u001e\u000b\u0003cQ\u0002\"A\u0004\u001a\n\u0005Mz!aA!os\"9QGLA\u0001\u0002\u0004Y\u0013a\u0001=%c!9qGCA\u0001\n\u0003B\u0014a\u00049s_\u0012,8\r^%uKJ\fGo\u001c:\u0016\u0003e\u00022AO\u001f2\u001b\u0005Y$B\u0001\u001f\u0010\u0003)\u0019w\u000e\u001c7fGRLwN\\\u0005\u0003}m\u0012\u0001\"\u0013;fe\u0006$xN\u001d\u0005\b\u0001*\t\t\u0011\"\u0001B\u0003!\u0019\u0017M\\#rk\u0006dGC\u0001\"F!\tq1)\u0003\u0002E\u001f\t9!i\\8mK\u0006t\u0007bB\u001b@\u0003\u0003\u0005\r!\r\u0005\b\u000f*\t\t\u0011\"\u0011I\u0003!A\u0017m\u001d5D_\u0012,G#A\u0016\t\u000f)S\u0011\u0011!C!\u0017\u0006AAo\\*ue&tw\rF\u0001!\u0011\u001di%\"!A\u0005\n9\u000b1B]3bIJ+7o\u001c7wKR\tq\n\u0005\u0002\"!&\u0011\u0011K\t\u0002\u0007\u001f\nTWm\u0019;")
public final class ExpireDeadHosts {
    public static String toString() {
        return ExpireDeadHosts$.MODULE$.toString();
    }

    public static int hashCode() {
        return ExpireDeadHosts$.MODULE$.hashCode();
    }

    public static boolean canEqual(Object object) {
        return ExpireDeadHosts$.MODULE$.canEqual(object);
    }

    public static Iterator<Object> productIterator() {
        return ExpireDeadHosts$.MODULE$.productIterator();
    }

    public static Object productElement(int n) {
        return ExpireDeadHosts$.MODULE$.productElement(n);
    }

    public static int productArity() {
        return ExpireDeadHosts$.MODULE$.productArity();
    }

    public static String productPrefix() {
        return ExpireDeadHosts$.MODULE$.productPrefix();
    }
}

