/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.hadoop.mapreduce.JobContext
 *  org.apache.hadoop.mapreduce.TaskAttemptContext
 *  org.apache.spark.internal.io.SparkHadoopWriter$$anonfun
 *  org.apache.spark.internal.io.SparkHadoopWriter$$anonfun$write
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function2
 *  scala.MatchError
 *  scala.Predef$
 *  scala.Serializable
 *  scala.Tuple2
 *  scala.collection.Iterator
 *  scala.collection.Seq
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.BoxedUnit
 *  scala.runtime.LongRef
 *  scala.runtime.TraitSetter
 */
package org.apache.spark.internal.io;

import java.util.Date;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.SparkException;
import org.apache.spark.TaskContext;
import org.apache.spark.executor.OutputMetrics;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.internal.io.FileCommitProtocol;
import org.apache.spark.internal.io.HadoopMapReduceCommitProtocol;
import org.apache.spark.internal.io.HadoopWriteConfigUtil;
import org.apache.spark.internal.io.SparkHadoopWriter$;
import org.apache.spark.internal.io.SparkHadoopWriterUtils$;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function2;
import scala.MatchError;
import scala.Predef$;
import scala.Serializable;
import scala.Tuple2;
import scala.collection.Iterator;
import scala.collection.Seq;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.BoxedUnit;
import scala.runtime.LongRef;
import scala.runtime.TraitSetter;

public final class SparkHadoopWriter$
implements Logging {
    public static final SparkHadoopWriter$ MODULE$;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.internal.io.SparkHadoopWriter$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @TraitSetter
    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public <K, V> void write(RDD<Tuple2<K, V>> rdd, HadoopWriteConfigUtil<K, V> config2, ClassTag<V> evidence$1) {
        SparkContext sparkContext = rdd.context();
        int commitJobId = rdd.id();
        String jobTrackerId = SparkHadoopWriterUtils$.MODULE$.createJobTrackerID(new Date());
        JobContext jobContext = config2.createJobContext(jobTrackerId, commitJobId);
        config2.initOutputFormat(jobContext);
        config2.assertConf(jobContext, rdd.conf());
        HadoopMapReduceCommitProtocol committer = config2.createCommitter(commitJobId);
        committer.setupJob(jobContext);
        try {
            FileCommitProtocol.TaskCommitMessage[] ret = (FileCommitProtocol.TaskCommitMessage[])sparkContext.runJob(rdd, new Serializable(config2, evidence$1, commitJobId, jobTrackerId, committer){
                public static final long serialVersionUID = 0L;
                private final HadoopWriteConfigUtil config$1;
                private final ClassTag evidence$1$1;
                private final int commitJobId$1;
                private final String jobTrackerId$1;
                private final HadoopMapReduceCommitProtocol committer$1;

                public final FileCommitProtocol.TaskCommitMessage apply(TaskContext context, Iterator<Tuple2<K, V>> iter) {
                    return SparkHadoopWriter$.MODULE$.org$apache$spark$internal$io$SparkHadoopWriter$$executeTask(context, this.config$1, this.jobTrackerId$1, this.commitJobId$1, context.partitionId(), context.attemptNumber(), this.committer$1, iter, this.evidence$1$1);
                }
                {
                    this.config$1 = config$1;
                    this.evidence$1$1 = evidence$1$1;
                    this.commitJobId$1 = commitJobId$1;
                    this.jobTrackerId$1 = jobTrackerId$1;
                    this.committer$1 = committer$1;
                }
            }, ClassTag$.MODULE$.apply(FileCommitProtocol.TaskCommitMessage.class));
            committer.commitJob(jobContext, (Seq<FileCommitProtocol.TaskCommitMessage>)Predef$.MODULE$.wrapRefArray((Object[])ret));
            this.logInfo((Function0<String>)new Serializable(jobContext){
                public static final long serialVersionUID = 0L;
                private final JobContext jobContext$1;

                public final String apply() {
                    return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Job ", " committed."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.jobContext$1.getJobID()}));
                }
                {
                    this.jobContext$1 = jobContext$1;
                }
            });
            return;
        }
        catch (Throwable throwable) {
            this.logError((Function0<String>)new Serializable(jobContext){
                public static final long serialVersionUID = 0L;
                private final JobContext jobContext$1;

                public final String apply() {
                    return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Aborting job ", "."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.jobContext$1.getJobID()}));
                }
                {
                    this.jobContext$1 = jobContext$1;
                }
            }, throwable);
            committer.abortJob(jobContext);
            throw new SparkException("Job aborted.", throwable);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public <K, V> FileCommitProtocol.TaskCommitMessage org$apache$spark$internal$io$SparkHadoopWriter$$executeTask(TaskContext context, HadoopWriteConfigUtil<K, V> config2, String jobTrackerId, int commitJobId, int sparkPartitionId, int sparkAttemptNumber, FileCommitProtocol committer, Iterator<Tuple2<K, V>> iterator2, ClassTag<V> evidence$2) {
        Tuple2 tuple22;
        TaskAttemptContext taskContext = config2.createTaskAttemptContext(jobTrackerId, commitJobId, sparkPartitionId, sparkAttemptNumber);
        committer.setupTask(taskContext);
        Tuple2<OutputMetrics, Function0<Object>> tuple2 = SparkHadoopWriterUtils$.MODULE$.initHadoopOutputMetrics(context);
        if (tuple2 == null) throw new MatchError(tuple2);
        OutputMetrics outputMetrics = (OutputMetrics)tuple2._1();
        Function0 callback = (Function0)tuple2._2();
        Tuple2 tuple23 = tuple22 = new Tuple2((Object)outputMetrics, (Object)callback);
        OutputMetrics outputMetrics2 = (OutputMetrics)tuple23._1();
        Function0 callback2 = (Function0)tuple23._2();
        config2.initWriter(taskContext, sparkPartitionId);
        LongRef recordsWritten = LongRef.create((long)0L);
        try {
            Serializable x$2 = new Serializable(config2, committer, iterator2, taskContext, outputMetrics2, callback2, recordsWritten){
                public static final long serialVersionUID = 0L;
                private final HadoopWriteConfigUtil config$2;
                private final FileCommitProtocol committer$2;
                private final Iterator iterator$1;
                private final TaskAttemptContext taskContext$1;
                private final OutputMetrics outputMetrics$1;
                private final Function0 callback$1;
                private final LongRef recordsWritten$1;

                public final FileCommitProtocol.TaskCommitMessage apply() {
                    while (this.iterator$1.hasNext()) {
                        Tuple2 pair = (Tuple2)this.iterator$1.next();
                        this.config$2.write(pair);
                        SparkHadoopWriterUtils$.MODULE$.maybeUpdateOutputMetrics(this.outputMetrics$1, (Function0<Object>)this.callback$1, this.recordsWritten$1.elem);
                        ++this.recordsWritten$1.elem;
                    }
                    this.config$2.closeWriter(this.taskContext$1);
                    return this.committer$2.commitTask(this.taskContext$1);
                }
                {
                    this.config$2 = config$2;
                    this.committer$2 = committer$2;
                    this.iterator$1 = iterator$1;
                    this.taskContext$1 = taskContext$1;
                    this.outputMetrics$1 = outputMetrics$1;
                    this.callback$1 = callback$1;
                    this.recordsWritten$1 = recordsWritten$1;
                }
            };
            Serializable x$3 = new Serializable(config2, committer, taskContext){
                public static final long serialVersionUID = 0L;
                private final HadoopWriteConfigUtil config$2;
                private final FileCommitProtocol committer$2;
                public final TaskAttemptContext taskContext$1;

                public final void apply() {
                    this.apply$mcV$sp();
                }

                public void apply$mcV$sp() {
                    try {
                        this.config$2.closeWriter(this.taskContext$1);
                        this.committer$2.abortTask(this.taskContext$1);
                        SparkHadoopWriter$.MODULE$.logError((Function0<String>)new Serializable(this){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ anonfun.1 $outer;

                            public final String apply() {
                                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Task ", " aborted."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.taskContext$1.getTaskAttemptID()}));
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                            }
                        });
                        return;
                    }
                    catch (Throwable throwable) {
                        this.committer$2.abortTask(this.taskContext$1);
                        SparkHadoopWriter$.MODULE$.logError((Function0<String>)new /* invalid duplicate definition of identical inner class */);
                        throw throwable;
                    }
                }
                {
                    this.config$2 = config$2;
                    this.committer$2 = committer$2;
                    this.taskContext$1 = taskContext$1;
                }
            };
            Serializable x$4 = new Serializable((Function0)x$2){
                public static final long serialVersionUID = 0L;
                private final Function0 x$2$1;

                public final void apply() {
                    this.apply$mcV$sp();
                }

                public void apply$mcV$sp() {
                    Utils$.MODULE$.tryWithSafeFinallyAndFailureCallbacks$default$3(this.x$2$1);
                }
                {
                    this.x$2$1 = x$2$1;
                }
            };
            FileCommitProtocol.TaskCommitMessage ret = (FileCommitProtocol.TaskCommitMessage)Utils$.MODULE$.tryWithSafeFinallyAndFailureCallbacks(x$2, (Function0<BoxedUnit>)x$3, (Function0<BoxedUnit>)x$4);
            outputMetrics2.setBytesWritten(callback2.apply$mcJ$sp());
            outputMetrics2.setRecordsWritten(recordsWritten.elem);
            return ret;
        }
        catch (Throwable throwable) {
            throw new SparkException("Task failed while writing rows", throwable);
        }
    }

    private SparkHadoopWriter$() {
        MODULE$ = this;
        Logging$class.$init$(this);
    }
}

