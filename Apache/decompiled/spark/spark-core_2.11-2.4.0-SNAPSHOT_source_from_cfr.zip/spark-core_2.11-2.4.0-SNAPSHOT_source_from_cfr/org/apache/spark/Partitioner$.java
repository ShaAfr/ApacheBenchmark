/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.Partitioner$$anonfun
 *  scala.Function1
 *  scala.None$
 *  scala.Option
 *  scala.Predef$
 *  scala.Serializable
 *  scala.Some
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableLike
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.mutable.WrappedArray
 *  scala.math.Ordering
 *  scala.math.Ordering$Int$
 *  scala.math.package$
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.HashPartitioner;
import org.apache.spark.Partitioner;
import org.apache.spark.Partitioner$;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.rdd.RDD;
import scala.Function1;
import scala.None$;
import scala.Option;
import scala.Predef$;
import scala.Serializable;
import scala.Some;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableLike;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.mutable.WrappedArray;
import scala.math.Ordering;
import scala.math.package$;
import scala.runtime.BoxesRunTime;

public final class Partitioner$
implements Serializable {
    public static final Partitioner$ MODULE$;

    public static {
        new org.apache.spark.Partitioner$();
    }

    public Partitioner defaultPartitioner(RDD<?> rdd, Seq<RDD<?>> others) {
        Seq rdds = (Seq)((TraversableLike)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new RDD[]{rdd}))).$plus$plus(others, Seq$.MODULE$.canBuildFrom());
        Seq hasPartitioner = (Seq)rdds.filter((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply(RDD<?> x$1) {
                return x$1.partitioner().exists((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final boolean apply(Partitioner x$2) {
                        return x$2.numPartitions() > 0;
                    }
                });
            }
        });
        None$ hasMaxPartitioner = hasPartitioner.nonEmpty() ? new Some(hasPartitioner.maxBy((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(RDD<?> x$3) {
                return x$3.partitions().length;
            }
        }, (Ordering)Ordering.Int$.MODULE$)) : None$.MODULE$;
        int defaultNumPartitions = rdd.context().conf().contains("spark.default.parallelism") ? rdd.context().defaultParallelism() : BoxesRunTime.unboxToInt((Object)((TraversableOnce)rdds.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(RDD<?> x$4) {
                return x$4.partitions().length;
            }
        }, Seq$.MODULE$.canBuildFrom())).max((Ordering)Ordering.Int$.MODULE$));
        return hasMaxPartitioner.nonEmpty() && (this.isEligiblePartitioner((RDD)hasMaxPartitioner.get(), rdds) || defaultNumPartitions < ((RDD)hasMaxPartitioner.get()).getNumPartitions()) ? (Partitioner)((RDD)hasMaxPartitioner.get()).partitioner().get() : new HashPartitioner(defaultNumPartitions);
    }

    private boolean isEligiblePartitioner(RDD<?> hasMaxPartitioner, Seq<RDD<?>> rdds) {
        int maxPartitions = BoxesRunTime.unboxToInt((Object)((TraversableOnce)rdds.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(RDD<?> x$5) {
                return x$5.partitions().length;
            }
        }, Seq$.MODULE$.canBuildFrom())).max((Ordering)Ordering.Int$.MODULE$));
        return package$.MODULE$.log10((double)maxPartitions) - package$.MODULE$.log10((double)hasMaxPartitioner.getNumPartitions()) < (double)true;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private Partitioner$() {
        MODULE$ = this;
    }
}

