/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.util.kvstore.KVIndex
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple5
 *  scala.runtime.AbstractFunction5
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy.history;

import org.apache.spark.deploy.history.LogInfo;
import org.apache.spark.util.kvstore.KVIndex;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple5;
import scala.runtime.AbstractFunction5;
import scala.runtime.BoxesRunTime;

public final class LogInfo$
extends AbstractFunction5<String, Object, Option<String>, Option<String>, Object, LogInfo>
implements Serializable {
    public static final LogInfo$ MODULE$;

    public static {
        new org.apache.spark.deploy.history.LogInfo$();
    }

    public final String toString() {
        return "LogInfo";
    }

    public LogInfo apply(@KVIndex String logPath, @KVIndex(value="lastProcessed") long lastProcessed, Option<String> appId, Option<String> attemptId, long fileSize) {
        return new LogInfo(logPath, lastProcessed, appId, attemptId, fileSize);
    }

    public Option<Tuple5<String, Object, Option<String>, Option<String>, Object>> unapply(LogInfo x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple5((Object)x$0.logPath(), (Object)BoxesRunTime.boxToLong((long)x$0.lastProcessed()), x$0.appId(), x$0.attemptId(), (Object)BoxesRunTime.boxToLong((long)x$0.fileSize())));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private LogInfo$() {
        MODULE$ = this;
    }
}

