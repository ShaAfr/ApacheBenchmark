/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerLogStart;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class SparkListenerLogStart$
extends AbstractFunction1<String, SparkListenerLogStart>
implements Serializable {
    public static final SparkListenerLogStart$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerLogStart$();
    }

    public final String toString() {
        return "SparkListenerLogStart";
    }

    public SparkListenerLogStart apply(String sparkVersion) {
        return new SparkListenerLogStart(sparkVersion);
    }

    public Option<String> unapply(SparkListenerLogStart x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.sparkVersion());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerLogStart$() {
        MODULE$ = this;
    }
}

