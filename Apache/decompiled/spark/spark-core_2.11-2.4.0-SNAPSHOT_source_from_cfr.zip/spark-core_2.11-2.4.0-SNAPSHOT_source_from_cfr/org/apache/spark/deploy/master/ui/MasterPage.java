/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 *  org.apache.spark.deploy.master.ui.MasterPage$
 *  org.apache.spark.deploy.master.ui.MasterPage$$anonfun
 *  org.apache.spark.deploy.master.ui.MasterPage$$anonfun$handleAppKillRequest
 *  org.apache.spark.deploy.master.ui.MasterPage$$anonfun$handleDriverKillRequest
 *  org.apache.spark.deploy.master.ui.MasterPage$$anonfun$org$apache$spark$deploy$master$ui$MasterPage$
 *  org.apache.spark.deploy.master.ui.MasterPage$$anonfun$org$apache$spark$deploy$master$ui$MasterPage$$driverRow
 *  org.apache.spark.deploy.master.ui.MasterPage$$anonfun$render
 *  org.json4s.JsonAST
 *  org.json4s.JsonAST$JObject
 *  org.json4s.JsonAST$JValue
 *  scala.Array$
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Option$
 *  scala.Predef$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.collection.GenTraversable
 *  scala.collection.Iterable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.math.Numeric
 *  scala.math.Numeric$IntIsIntegral$
 *  scala.math.Ordering
 *  scala.math.Ordering$Long$
 *  scala.math.Ordering$String$
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.xml.Elem
 *  scala.xml.MetaData
 *  scala.xml.NamespaceBinding
 *  scala.xml.Node
 *  scala.xml.NodeBuffer
 *  scala.xml.Null$
 *  scala.xml.Text
 *  scala.xml.TopScope$
 *  scala.xml.UnprefixedAttribute
 */
package org.apache.spark.deploy.master.ui;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.apache.spark.SecurityManager;
import org.apache.spark.deploy.ApplicationDescription;
import org.apache.spark.deploy.Command;
import org.apache.spark.deploy.DeployMessages;
import org.apache.spark.deploy.DeployMessages$RequestMasterState$;
import org.apache.spark.deploy.DriverDescription;
import org.apache.spark.deploy.JsonProtocol$;
import org.apache.spark.deploy.master.ApplicationInfo;
import org.apache.spark.deploy.master.ApplicationState$;
import org.apache.spark.deploy.master.DriverInfo;
import org.apache.spark.deploy.master.DriverState$;
import org.apache.spark.deploy.master.Master;
import org.apache.spark.deploy.master.WorkerInfo;
import org.apache.spark.deploy.master.ui.MasterPage$;
import org.apache.spark.deploy.master.ui.MasterPage$$anonfun$org$apache$spark$deploy$master$ui$MasterPage$;
import org.apache.spark.deploy.master.ui.MasterWebUI;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.ui.UIUtils$;
import org.apache.spark.ui.WebUIPage;
import org.apache.spark.util.Utils$;
import org.json4s.JsonAST;
import scala.Array$;
import scala.Enumeration;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Option$;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.collection.GenTraversable;
import scala.collection.Iterable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.math.Numeric;
import scala.math.Ordering;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.xml.Elem;
import scala.xml.MetaData;
import scala.xml.NamespaceBinding;
import scala.xml.Node;
import scala.xml.NodeBuffer;
import scala.xml.Null$;
import scala.xml.Text;
import scala.xml.TopScope$;
import scala.xml.UnprefixedAttribute;

@ScalaSignature(bytes="\u0006\u0001\u0005\u0015c!B\u0001\u0003\u0001\tq!AC'bgR,'\u000fU1hK*\u00111\u0001B\u0001\u0003k&T!!\u0002\u0004\u0002\r5\f7\u000f^3s\u0015\t9\u0001\"\u0001\u0004eKBdw.\u001f\u0006\u0003\u0013)\tQa\u001d9be.T!a\u0003\u0007\u0002\r\u0005\u0004\u0018m\u00195f\u0015\u0005i\u0011aA8sON\u0011\u0001a\u0004\t\u0003!Ii\u0011!\u0005\u0006\u0003\u0007!I!aE\t\u0003\u0013]+'-V%QC\u001e,\u0007\u0002C\u000b\u0001\u0005\u0003\u0005\u000b\u0011B\f\u0002\rA\f'/\u001a8u\u0007\u0001\u0001\"\u0001G\r\u000e\u0003\tI!A\u0007\u0002\u0003\u00175\u000b7\u000f^3s/\u0016\u0014W+\u0013\u0005\u00069\u0001!\t!H\u0001\u0007y%t\u0017\u000e\u001e \u0015\u0005yy\u0002C\u0001\r\u0001\u0011\u0015)2\u00041\u0001\u0018\u0011\u001d)\u0001A1A\u0005\n\u0005*\u0012A\t\t\u0003G\u0019j\u0011\u0001\n\u0006\u0003K!\t1A\u001d9d\u0013\t9CE\u0001\bSa\u000e,e\u000e\u001a9pS:$(+\u001a4\t\r%\u0002\u0001\u0015!\u0003#\u0003\u001di\u0017m\u001d;fe\u0002BQa\u000b\u0001\u0005\u00021\nabZ3u\u001b\u0006\u001cH/\u001a:Ti\u0006$X-F\u0001.!\tqCH\u0004\u00020u9\u0011\u0001'\u000f\b\u0003car!AM\u001c\u000f\u0005M2T\"\u0001\u001b\u000b\u0005U2\u0012A\u0002\u001fs_>$h(C\u0001\u000e\u0013\tYA\"\u0003\u0002\n\u0015%\u0011q\u0001C\u0005\u0003w\u0019\ta\u0002R3qY>LX*Z:tC\u001e,7/\u0003\u0002>}\t\u0019R*Y:uKJ\u001cF/\u0019;f%\u0016\u001c\bo\u001c8tK*\u00111H\u0002\u0005\u0006\u0001\u0002!\t%Q\u0001\u000be\u0016tG-\u001a:Kg>tGC\u0001\"N!\t\u0019%J\u0004\u0002E\u000f:\u0011!'R\u0005\u0003\r2\taA[:p]R\u001a\u0018B\u0001%J\u0003\u001d\u0001\u0018mY6bO\u0016T!A\u0012\u0007\n\u0005-c%A\u0002&WC2,XM\u0003\u0002I\u0013\")aj\u0010a\u0001\u001f\u00069!/Z9vKN$\bC\u0001)X\u001b\u0005\t&B\u0001*T\u0003\u0011AG\u000f\u001e9\u000b\u0005Q+\u0016aB:feZdW\r\u001e\u0006\u0002-\u0006)!.\u0019<bq&\u0011\u0001,\u0015\u0002\u0013\u0011R$\boU3sm2,GOU3rk\u0016\u001cH\u000fC\u0003[\u0001\u0011\u00051,\u0001\u000biC:$G.Z!qa.KG\u000e\u001c*fcV,7\u000f\u001e\u000b\u00039\n\u0004\"!\u00181\u000e\u0003yS\u0011aX\u0001\u0006g\u000e\fG.Y\u0005\u0003Cz\u0013A!\u00168ji\")a*\u0017a\u0001\u001f\")A\r\u0001C\u0001K\u00069\u0002.\u00198eY\u0016$%/\u001b<fe.KG\u000e\u001c*fcV,7\u000f\u001e\u000b\u00039\u001aDQAT2A\u0002=CQ\u0001\u001b\u0001\u0005\n%\f\u0011\u0003[1oI2,7*\u001b7m%\u0016\fX/Z:u)\ra&n\u001b\u0005\u0006\u001d\u001e\u0004\ra\u0014\u0005\u0006Y\u001e\u0004\r!\\\u0001\u0007C\u000e$\u0018n\u001c8\u0011\tus\u0007\u000fX\u0005\u0003_z\u0013\u0011BR;oGRLwN\\\u0019\u0011\u0005E$hBA/s\u0013\t\u0019h,\u0001\u0004Qe\u0016$WMZ\u0005\u0003kZ\u0014aa\u0015;sS:<'BA:_\u0011\u0015A\b\u0001\"\u0001z\u0003\u0019\u0011XM\u001c3feR\u0019!0!\u0005\u0011\tm|\u0018Q\u0001\b\u0003yzt!aM?\n\u0003}K!\u0001\u00130\n\t\u0005\u0005\u00111\u0001\u0002\u0004'\u0016\f(B\u0001%_!\u0011\t9!!\u0004\u000e\u0005\u0005%!bAA\u0006=\u0006\u0019\u00010\u001c7\n\t\u0005=\u0011\u0011\u0002\u0002\u0005\u001d>$W\rC\u0003Oo\u0002\u0007q\nC\u0004\u0002\u0016\u0001!I!a\u0006\u0002\u0013]|'o[3s%><Hc\u0001>\u0002\u001a!A\u00111DA\n\u0001\u0004\ti\"\u0001\u0004x_J\\WM\u001d\t\u0005\u0003?\t\t#D\u0001\u0005\u0013\r\t\u0019\u0003\u0002\u0002\u000b/>\u00148.\u001a:J]\u001a|\u0007bBA\u0014\u0001\u0011%\u0011\u0011F\u0001\u0007CB\u0004(k\\<\u0015\u0007i\fY\u0003\u0003\u0005\u0002.\u0005\u0015\u0002\u0019AA\u0018\u0003\r\t\u0007\u000f\u001d\t\u0005\u0003?\t\t$C\u0002\u00024\u0011\u0011q\"\u00119qY&\u001c\u0017\r^5p]&sgm\u001c\u0005\b\u0003o\u0001A\u0011BA\u001d\u0003%!'/\u001b<feJ{w\u000fF\u0002{\u0003wA\u0001\"!\u0010\u00026\u0001\u0007\u0011qH\u0001\u0007IJLg/\u001a:\u0011\t\u0005}\u0011\u0011I\u0005\u0004\u0003\u0007\"!A\u0003#sSZ,'/\u00138g_\u0002")
public class MasterPage
extends WebUIPage {
    public final MasterWebUI org$apache$spark$deploy$master$ui$MasterPage$$parent;
    private final RpcEndpointRef org$apache$spark$deploy$master$ui$MasterPage$$master;

    public RpcEndpointRef org$apache$spark$deploy$master$ui$MasterPage$$master() {
        return this.org$apache$spark$deploy$master$ui$MasterPage$$master;
    }

    public DeployMessages.MasterStateResponse getMasterState() {
        return (DeployMessages.MasterStateResponse)this.org$apache$spark$deploy$master$ui$MasterPage$$master().askSync(DeployMessages$RequestMasterState$.MODULE$, ClassTag$.MODULE$.apply(DeployMessages.MasterStateResponse.class));
    }

    @Override
    public JsonAST.JValue renderJson(HttpServletRequest request) {
        return JsonProtocol$.MODULE$.writeMasterState(this.getMasterState());
    }

    public void handleAppKillRequest(HttpServletRequest request) {
        this.handleKillRequest(request, (Function1<String, BoxedUnit>)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final void apply(String id) {
                this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$parent.master().idToApp().get((Object)id).foreach((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ $anonfun$handleAppKillRequest$1 $outer;

                    public final void apply(ApplicationInfo app) {
                        this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$anonfun$$$outer().org$apache$spark$deploy$master$ui$MasterPage$$parent.master().removeApplication(app, ApplicationState$.MODULE$.KILLED());
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
            }

            public /* synthetic */ MasterPage org$apache$spark$deploy$master$ui$MasterPage$$anonfun$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
    }

    public void handleDriverKillRequest(HttpServletRequest request) {
        this.handleKillRequest(request, (Function1<String, BoxedUnit>)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final void apply(String id) {
                this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$master().ask(new org.apache.spark.deploy.DeployMessages$RequestKillDriver(id), ClassTag$.MODULE$.apply(org.apache.spark.deploy.DeployMessages$KillDriverResponse.class));
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
    }

    private void handleKillRequest(HttpServletRequest request, Function1<String, BoxedUnit> action) {
        if (this.org$apache$spark$deploy$master$ui$MasterPage$$parent.killEnabled() && this.org$apache$spark$deploy$master$ui$MasterPage$$parent.master().securityMgr().checkModifyPermissions(request.getRemoteUser())) {
            boolean killFlag = new StringOps(Predef$.MODULE$.augmentString((String)Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("terminate"))).getOrElse((Function0)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "false";
                }
            }))).toBoolean();
            Option id = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("id")));
            Object object = id.isDefined() && killFlag ? action.apply(id.get()) : BoxedUnit.UNIT;
            Thread.sleep(100L);
        }
    }

    @Override
    public Seq<Node> render(HttpServletRequest request) {
        BoxedUnit boxedUnit;
        BoxedUnit boxedUnit2;
        DeployMessages.MasterStateResponse state = this.getMasterState();
        Seq workerHeaders = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Worker Id", "Address", "State", "Cores", "Memory"}));
        WorkerInfo[] workers = (WorkerInfo[])Predef$.MODULE$.refArrayOps((Object[])state.workers()).sortBy((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final String apply(WorkerInfo x$1) {
                return x$1.id();
            }
        }, (Ordering)Ordering.String$.MODULE$);
        WorkerInfo[] aliveWorkers = (WorkerInfo[])Predef$.MODULE$.refArrayOps((Object[])state.workers()).filter((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(WorkerInfo x$2) {
                Enumeration.Value value2 = org.apache.spark.deploy.master.WorkerState$.MODULE$.ALIVE();
                if (x$2.state() != null) {
                    Enumeration.Value value3;
                    if (!value3.equals((Object)value2)) return false;
                    return true;
                }
                if (value2 == null) return true;
                return false;
            }
        });
        Seq<Node> workerTable = UIUtils$.MODULE$.listingTable((Seq<String>)workerHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final Seq<Node> apply(WorkerInfo worker) {
                return this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$workerRow(worker);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Predef$.MODULE$.wrapRefArray((Object[])workers), UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        Seq appHeaders = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Application ID", "Name", "Cores", "Memory per Executor", "Submitted Time", "User", "State", "Duration"}));
        ApplicationInfo[] activeApps = (ApplicationInfo[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])state.activeApps()).sortBy((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final long apply(ApplicationInfo x$3) {
                return x$3.startTime();
            }
        }, (Ordering)Ordering.Long$.MODULE$)).reverse();
        Seq<Node> activeAppsTable = UIUtils$.MODULE$.listingTable((Seq<String>)appHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final Seq<Node> apply(ApplicationInfo app) {
                return this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$appRow(app);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Predef$.MODULE$.wrapRefArray((Object[])activeApps), UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        ApplicationInfo[] completedApps = (ApplicationInfo[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])state.completedApps()).sortBy((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final long apply(ApplicationInfo x$4) {
                return x$4.endTime();
            }
        }, (Ordering)Ordering.Long$.MODULE$)).reverse();
        Seq<Node> completedAppsTable = UIUtils$.MODULE$.listingTable((Seq<String>)appHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final Seq<Node> apply(ApplicationInfo app) {
                return this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$appRow(app);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Predef$.MODULE$.wrapRefArray((Object[])completedApps), UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        Seq driverHeaders = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Submission ID", "Submitted Time", "Worker", "State", "Cores", "Memory", "Main Class"}));
        DriverInfo[] activeDrivers = (DriverInfo[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])state.activeDrivers()).sortBy((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final long apply(DriverInfo x$5) {
                return x$5.startTime();
            }
        }, (Ordering)Ordering.Long$.MODULE$)).reverse();
        Seq<Node> activeDriversTable = UIUtils$.MODULE$.listingTable((Seq<String>)driverHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final Seq<Node> apply(DriverInfo driver) {
                return this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$driverRow(driver);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Predef$.MODULE$.wrapRefArray((Object[])activeDrivers), UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        DriverInfo[] completedDrivers = (DriverInfo[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])state.completedDrivers()).sortBy((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final long apply(DriverInfo x$6) {
                return x$6.startTime();
            }
        }, (Ordering)Ordering.Long$.MODULE$)).reverse();
        Seq<Node> completedDriversTable = UIUtils$.MODULE$.listingTable((Seq<String>)driverHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final Seq<Node> apply(DriverInfo driver) {
                return this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$driverRow(driver);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Predef$.MODULE$.wrapRefArray((Object[])completedDrivers), UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        NodeBuffer $buf = new NodeBuffer();
        Null$ $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md);
        NodeBuffer $buf2 = new NodeBuffer();
        $buf2.$amp$plus((Object)new Text("\n          "));
        Null$ $md2 = Null$.MODULE$;
        $md2 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md2);
        NodeBuffer $buf3 = new NodeBuffer();
        $buf3.$amp$plus((Object)new Text("\n            "));
        Null$ $md3 = Null$.MODULE$;
        $md3 = new UnprefixedAttribute("class", (Seq)new Text("unstyled"), (MetaData)$md3);
        NodeBuffer $buf4 = new NodeBuffer();
        $buf4.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf5 = new NodeBuffer();
        NodeBuffer $buf6 = new NodeBuffer();
        $buf6.$amp$plus((Object)new Text("URL:"));
        $buf5.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6));
        $buf5.$amp$plus((Object)new Text(" "));
        $buf5.$amp$plus((Object)state.uri());
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5));
        $buf4.$amp$plus((Object)new Text("\n              "));
        $buf4.$amp$plus(state.restUri().map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final Elem apply(String uri) {
                NodeBuffer $buf = new NodeBuffer();
                $buf.$amp$plus((Object)new Text("\n                    "));
                NodeBuffer $buf2 = new NodeBuffer();
                $buf2.$amp$plus((Object)new Text("REST URL:"));
                $buf.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
                $buf.$amp$plus((Object)new Text(" "));
                $buf.$amp$plus((Object)uri);
                $buf.$amp$plus((Object)new Text("\n                    "));
                Null$ $md = Null$.MODULE$;
                $md = new UnprefixedAttribute("class", (Seq)new Text("rest-uri"), (MetaData)$md);
                NodeBuffer $buf3 = new NodeBuffer();
                $buf3.$amp$plus((Object)new Text(" (cluster mode)"));
                $buf.$amp$plus((Object)new Elem(null, "span", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3));
                $buf.$amp$plus((Object)new Text("\n                  "));
                return new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
            }
        }).getOrElse((Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final Seq<scala.runtime.Nothing$> apply() {
                return (Seq)Seq$.MODULE$.empty();
            }
        }));
        $buf4.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf7 = new NodeBuffer();
        NodeBuffer $buf8 = new NodeBuffer();
        $buf8.$amp$plus((Object)new Text("Alive Workers:"));
        $buf7.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf8));
        $buf7.$amp$plus((Object)new Text(" "));
        $buf7.$amp$plus((Object)BoxesRunTime.boxToInteger((int)aliveWorkers.length));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7));
        $buf4.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf9 = new NodeBuffer();
        NodeBuffer $buf10 = new NodeBuffer();
        $buf10.$amp$plus((Object)new Text("Cores in use:"));
        $buf9.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf10));
        $buf9.$amp$plus((Object)new Text(" "));
        $buf9.$amp$plus(Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$7) {
                return x$7.cores();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$));
        $buf9.$amp$plus((Object)new Text(" Total,\n                "));
        $buf9.$amp$plus(Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$8) {
                return x$8.coresUsed();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$));
        $buf9.$amp$plus((Object)new Text(" Used"));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf9));
        $buf4.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf11 = new NodeBuffer();
        NodeBuffer $buf12 = new NodeBuffer();
        $buf12.$amp$plus((Object)new Text("Memory in use:"));
        $buf11.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf12));
        $buf11.$amp$plus((Object)new Text("\n                "));
        $buf11.$amp$plus((Object)Utils$.MODULE$.megabytesToString(BoxesRunTime.unboxToInt((Object)Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$9) {
                return x$9.memory();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$))));
        $buf11.$amp$plus((Object)new Text(" Total,\n                "));
        $buf11.$amp$plus((Object)Utils$.MODULE$.megabytesToString(BoxesRunTime.unboxToInt((Object)Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$10) {
                return x$10.memoryUsed();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$))));
        $buf11.$amp$plus((Object)new Text(" Used"));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf11));
        $buf4.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf13 = new NodeBuffer();
        NodeBuffer $buf14 = new NodeBuffer();
        $buf14.$amp$plus((Object)new Text("Applications:"));
        $buf13.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf14));
        $buf13.$amp$plus((Object)new Text("\n                "));
        $buf13.$amp$plus((Object)BoxesRunTime.boxToInteger((int)state.activeApps().length));
        $buf13.$amp$plus((Object)new Text(" "));
        Null$ $md4 = Null$.MODULE$;
        $md4 = new UnprefixedAttribute("href", (Seq)new Text("#running-app"), (MetaData)$md4);
        NodeBuffer $buf15 = new NodeBuffer();
        $buf15.$amp$plus((Object)new Text("Running"));
        $buf13.$amp$plus((Object)new Elem(null, "a", (MetaData)$md4, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf15));
        $buf13.$amp$plus((Object)new Text(",\n                "));
        $buf13.$amp$plus((Object)BoxesRunTime.boxToInteger((int)state.completedApps().length));
        $buf13.$amp$plus((Object)new Text(" "));
        Null$ $md5 = Null$.MODULE$;
        $md5 = new UnprefixedAttribute("href", (Seq)new Text("#completed-app"), (MetaData)$md5);
        NodeBuffer $buf16 = new NodeBuffer();
        $buf16.$amp$plus((Object)new Text("Completed"));
        $buf13.$amp$plus((Object)new Elem(null, "a", (MetaData)$md5, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf16));
        $buf13.$amp$plus((Object)new Text(" "));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf13));
        $buf4.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf17 = new NodeBuffer();
        NodeBuffer $buf18 = new NodeBuffer();
        $buf18.$amp$plus((Object)new Text("Drivers:"));
        $buf17.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf18));
        $buf17.$amp$plus((Object)new Text("\n                "));
        $buf17.$amp$plus((Object)BoxesRunTime.boxToInteger((int)state.activeDrivers().length));
        $buf17.$amp$plus((Object)new Text(" Running,\n                "));
        $buf17.$amp$plus((Object)BoxesRunTime.boxToInteger((int)state.completedDrivers().length));
        $buf17.$amp$plus((Object)new Text(" Completed "));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf17));
        $buf4.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf19 = new NodeBuffer();
        NodeBuffer $buf20 = new NodeBuffer();
        $buf20.$amp$plus((Object)new Text("Status:"));
        $buf19.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf20));
        $buf19.$amp$plus((Object)new Text(" "));
        $buf19.$amp$plus((Object)state.status());
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf19));
        $buf4.$amp$plus((Object)new Text("\n            "));
        $buf3.$amp$plus((Object)new Elem(null, "ul", (MetaData)$md3, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4));
        $buf3.$amp$plus((Object)new Text("\n          "));
        $buf2.$amp$plus((Object)new Elem(null, "div", (MetaData)$md2, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3));
        $buf2.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
        Null$ $md6 = Null$.MODULE$;
        $md6 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md6);
        NodeBuffer $buf21 = new NodeBuffer();
        $buf21.$amp$plus((Object)new Text("\n          "));
        Null$ $md7 = Null$.MODULE$;
        $md7 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md7);
        NodeBuffer $buf22 = new NodeBuffer();
        $buf22.$amp$plus((Object)new Text("\n            "));
        Null$ $md8 = Null$.MODULE$;
        $md8 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-workers','aggregated-workers')"), (MetaData)$md8);
        $md8 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-workers collapse-table"), (MetaData)$md8);
        NodeBuffer $buf23 = new NodeBuffer();
        $buf23.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf24 = new NodeBuffer();
        $buf24.$amp$plus((Object)new Text("\n                "));
        Null$ $md9 = Null$.MODULE$;
        $md9 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md9);
        $buf24.$amp$plus((Object)new Elem(null, "span", (MetaData)$md9, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
        $buf24.$amp$plus((Object)new Text("\n                "));
        NodeBuffer $buf25 = new NodeBuffer();
        $buf25.$amp$plus((Object)new Text("Workers ("));
        $buf25.$amp$plus((Object)BoxesRunTime.boxToInteger((int)workers.length));
        $buf25.$amp$plus((Object)new Text(")"));
        $buf24.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf25));
        $buf24.$amp$plus((Object)new Text("\n              "));
        $buf23.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf24));
        $buf23.$amp$plus((Object)new Text("\n            "));
        $buf22.$amp$plus((Object)new Elem(null, "span", (MetaData)$md8, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf23));
        $buf22.$amp$plus((Object)new Text("\n            "));
        Null$ $md10 = Null$.MODULE$;
        $md10 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-workers collapsible-table"), (MetaData)$md10);
        NodeBuffer $buf26 = new NodeBuffer();
        $buf26.$amp$plus((Object)new Text("\n              "));
        $buf26.$amp$plus(workerTable);
        $buf26.$amp$plus((Object)new Text("\n            "));
        $buf22.$amp$plus((Object)new Elem(null, "div", (MetaData)$md10, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf26));
        $buf22.$amp$plus((Object)new Text("\n          "));
        $buf21.$amp$plus((Object)new Elem(null, "div", (MetaData)$md7, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf22));
        $buf21.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md6, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf21));
        Null$ $md11 = Null$.MODULE$;
        $md11 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md11);
        NodeBuffer $buf27 = new NodeBuffer();
        $buf27.$amp$plus((Object)new Text("\n          "));
        Null$ $md12 = Null$.MODULE$;
        $md12 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md12);
        NodeBuffer $buf28 = new NodeBuffer();
        $buf28.$amp$plus((Object)new Text("\n            "));
        Null$ $md13 = Null$.MODULE$;
        $md13 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-activeApps','aggregated-activeApps')"), (MetaData)$md13);
        $md13 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-activeApps collapse-table"), (MetaData)$md13);
        $md13 = new UnprefixedAttribute("id", (Seq)new Text("running-app"), (MetaData)$md13);
        NodeBuffer $buf29 = new NodeBuffer();
        $buf29.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf30 = new NodeBuffer();
        $buf30.$amp$plus((Object)new Text("\n                "));
        Null$ $md14 = Null$.MODULE$;
        $md14 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md14);
        $buf30.$amp$plus((Object)new Elem(null, "span", (MetaData)$md14, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
        $buf30.$amp$plus((Object)new Text("\n                "));
        NodeBuffer $buf31 = new NodeBuffer();
        $buf31.$amp$plus((Object)new Text("Running Applications ("));
        $buf31.$amp$plus((Object)BoxesRunTime.boxToInteger((int)activeApps.length));
        $buf31.$amp$plus((Object)new Text(")"));
        $buf30.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf31));
        $buf30.$amp$plus((Object)new Text("\n              "));
        $buf29.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf30));
        $buf29.$amp$plus((Object)new Text("\n            "));
        $buf28.$amp$plus((Object)new Elem(null, "span", (MetaData)$md13, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf29));
        $buf28.$amp$plus((Object)new Text("\n            "));
        Null$ $md15 = Null$.MODULE$;
        $md15 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-activeApps collapsible-table"), (MetaData)$md15);
        NodeBuffer $buf32 = new NodeBuffer();
        $buf32.$amp$plus((Object)new Text("\n              "));
        $buf32.$amp$plus(activeAppsTable);
        $buf32.$amp$plus((Object)new Text("\n            "));
        $buf28.$amp$plus((Object)new Elem(null, "div", (MetaData)$md15, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf32));
        $buf28.$amp$plus((Object)new Text("\n          "));
        $buf27.$amp$plus((Object)new Elem(null, "div", (MetaData)$md12, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf28));
        $buf27.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md11, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf27));
        NodeBuffer $buf33 = new NodeBuffer();
        $buf33.$amp$plus((Object)new Text("\n          "));
        if (this.hasDrivers$1(activeDrivers, completedDrivers)) {
            Elem elem;
            Null$ $md16 = Null$.MODULE$;
            $md16 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md16);
            boxedUnit = elem;
            NodeBuffer $buf34 = new NodeBuffer();
            $buf34.$amp$plus((Object)new Text("\n               "));
            Null$ $md17 = Null$.MODULE$;
            $md17 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md17);
            NodeBuffer $buf35 = new NodeBuffer();
            $buf35.$amp$plus((Object)new Text("\n                 "));
            Null$ $md18 = Null$.MODULE$;
            $md18 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-activeDrivers',\n                     'aggregated-activeDrivers')"), (MetaData)$md18);
            $md18 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-activeDrivers collapse-table"), (MetaData)$md18);
            NodeBuffer $buf36 = new NodeBuffer();
            $buf36.$amp$plus((Object)new Text("\n                   "));
            NodeBuffer $buf37 = new NodeBuffer();
            $buf37.$amp$plus((Object)new Text("\n                     "));
            Null$ $md19 = Null$.MODULE$;
            $md19 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md19);
            $buf37.$amp$plus((Object)new Elem(null, "span", (MetaData)$md19, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf37.$amp$plus((Object)new Text("\n                     "));
            NodeBuffer $buf38 = new NodeBuffer();
            $buf38.$amp$plus((Object)new Text("Running Drivers ("));
            $buf38.$amp$plus((Object)BoxesRunTime.boxToInteger((int)activeDrivers.length));
            $buf38.$amp$plus((Object)new Text(")"));
            $buf37.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf38));
            $buf37.$amp$plus((Object)new Text("\n                   "));
            $buf36.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf37));
            $buf36.$amp$plus((Object)new Text("\n                 "));
            $buf35.$amp$plus((Object)new Elem(null, "span", (MetaData)$md18, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf36));
            $buf35.$amp$plus((Object)new Text("\n                 "));
            Null$ $md20 = Null$.MODULE$;
            $md20 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-activeDrivers collapsible-table"), (MetaData)$md20);
            NodeBuffer $buf39 = new NodeBuffer();
            $buf39.$amp$plus((Object)new Text("\n                   "));
            $buf39.$amp$plus(activeDriversTable);
            $buf39.$amp$plus((Object)new Text("\n                 "));
            $buf35.$amp$plus((Object)new Elem(null, "div", (MetaData)$md20, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf39));
            $buf35.$amp$plus((Object)new Text("\n               "));
            $buf34.$amp$plus((Object)new Elem(null, "div", (MetaData)$md17, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf35));
            $buf34.$amp$plus((Object)new Text("\n             "));
            elem = new Elem(null, "div", (MetaData)$md16, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf34);
        } else {
            boxedUnit = BoxedUnit.UNIT;
        }
        $buf33.$amp$plus((Object)boxedUnit);
        $buf33.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf33));
        Null$ $md21 = Null$.MODULE$;
        $md21 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md21);
        NodeBuffer $buf40 = new NodeBuffer();
        $buf40.$amp$plus((Object)new Text("\n          "));
        Null$ $md22 = Null$.MODULE$;
        $md22 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md22);
        NodeBuffer $buf41 = new NodeBuffer();
        $buf41.$amp$plus((Object)new Text("\n            "));
        Null$ $md23 = Null$.MODULE$;
        $md23 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-completedApps',\n                'aggregated-completedApps')"), (MetaData)$md23);
        $md23 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-completedApps collapse-table"), (MetaData)$md23);
        $md23 = new UnprefixedAttribute("id", (Seq)new Text("completed-app"), (MetaData)$md23);
        NodeBuffer $buf42 = new NodeBuffer();
        $buf42.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf43 = new NodeBuffer();
        $buf43.$amp$plus((Object)new Text("\n                "));
        Null$ $md24 = Null$.MODULE$;
        $md24 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md24);
        $buf43.$amp$plus((Object)new Elem(null, "span", (MetaData)$md24, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
        $buf43.$amp$plus((Object)new Text("\n                "));
        NodeBuffer $buf44 = new NodeBuffer();
        $buf44.$amp$plus((Object)new Text("Completed Applications ("));
        $buf44.$amp$plus((Object)BoxesRunTime.boxToInteger((int)completedApps.length));
        $buf44.$amp$plus((Object)new Text(")"));
        $buf43.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf44));
        $buf43.$amp$plus((Object)new Text("\n              "));
        $buf42.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf43));
        $buf42.$amp$plus((Object)new Text("\n            "));
        $buf41.$amp$plus((Object)new Elem(null, "span", (MetaData)$md23, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf42));
        $buf41.$amp$plus((Object)new Text("\n            "));
        Null$ $md25 = Null$.MODULE$;
        $md25 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-completedApps collapsible-table"), (MetaData)$md25);
        NodeBuffer $buf45 = new NodeBuffer();
        $buf45.$amp$plus((Object)new Text("\n              "));
        $buf45.$amp$plus(completedAppsTable);
        $buf45.$amp$plus((Object)new Text("\n            "));
        $buf41.$amp$plus((Object)new Elem(null, "div", (MetaData)$md25, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf45));
        $buf41.$amp$plus((Object)new Text("\n          "));
        $buf40.$amp$plus((Object)new Elem(null, "div", (MetaData)$md22, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf41));
        $buf40.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md21, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf40));
        NodeBuffer $buf46 = new NodeBuffer();
        $buf46.$amp$plus((Object)new Text("\n          "));
        if (this.hasDrivers$1(activeDrivers, completedDrivers)) {
            Elem elem;
            Null$ $md26 = Null$.MODULE$;
            $md26 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md26);
            boxedUnit2 = elem;
            NodeBuffer $buf47 = new NodeBuffer();
            $buf47.$amp$plus((Object)new Text("\n                "));
            Null$ $md27 = Null$.MODULE$;
            $md27 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md27);
            NodeBuffer $buf48 = new NodeBuffer();
            $buf48.$amp$plus((Object)new Text("\n                  "));
            Null$ $md28 = Null$.MODULE$;
            $md28 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-completedDrivers',\n                      'aggregated-completedDrivers')"), (MetaData)$md28);
            $md28 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-completedDrivers collapse-table"), (MetaData)$md28);
            NodeBuffer $buf49 = new NodeBuffer();
            $buf49.$amp$plus((Object)new Text("\n                    "));
            NodeBuffer $buf50 = new NodeBuffer();
            $buf50.$amp$plus((Object)new Text("\n                      "));
            Null$ $md29 = Null$.MODULE$;
            $md29 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md29);
            $buf50.$amp$plus((Object)new Elem(null, "span", (MetaData)$md29, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf50.$amp$plus((Object)new Text("\n                      "));
            NodeBuffer $buf51 = new NodeBuffer();
            $buf51.$amp$plus((Object)new Text("Completed Drivers ("));
            $buf51.$amp$plus((Object)BoxesRunTime.boxToInteger((int)completedDrivers.length));
            $buf51.$amp$plus((Object)new Text(")"));
            $buf50.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf51));
            $buf50.$amp$plus((Object)new Text("\n                    "));
            $buf49.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf50));
            $buf49.$amp$plus((Object)new Text("\n                  "));
            $buf48.$amp$plus((Object)new Elem(null, "span", (MetaData)$md28, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf49));
            $buf48.$amp$plus((Object)new Text("\n                  "));
            Null$ $md30 = Null$.MODULE$;
            $md30 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-completedDrivers collapsible-table"), (MetaData)$md30);
            NodeBuffer $buf52 = new NodeBuffer();
            $buf52.$amp$plus((Object)new Text("\n                    "));
            $buf52.$amp$plus(completedDriversTable);
            $buf52.$amp$plus((Object)new Text("\n                  "));
            $buf48.$amp$plus((Object)new Elem(null, "div", (MetaData)$md30, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf52));
            $buf48.$amp$plus((Object)new Text("\n                "));
            $buf47.$amp$plus((Object)new Elem(null, "div", (MetaData)$md27, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf48));
            $buf47.$amp$plus((Object)new Text("\n              "));
            elem = new Elem(null, "div", (MetaData)$md26, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf47);
        } else {
            boxedUnit2 = BoxedUnit.UNIT;
        }
        $buf46.$amp$plus((Object)boxedUnit2);
        $buf46.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf46));
        NodeBuffer content = $buf;
        return UIUtils$.MODULE$.basicSparkPage((Function0<Seq<Node>>)new Serializable(this, content){
            public static final long serialVersionUID = 0L;
            private final NodeBuffer content$1;

            public final NodeBuffer apply() {
                return this.content$1;
            }
            {
                this.content$1 = content$1;
            }
        }, new StringBuilder().append((Object)"Spark Master at ").append((Object)state.uri()).toString(), UIUtils$.MODULE$.basicSparkPage$default$3());
    }

    public Seq<Node> org$apache$spark$deploy$master$ui$MasterPage$$workerRow(WorkerInfo worker) {
        String string;
        NodeBuffer $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf2 = new NodeBuffer();
        $buf2.$amp$plus((Object)new Text("\n        "));
        if (worker.isAlive()) {
            Elem elem;
            Null$ $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("href", UIUtils$.MODULE$.makeHref(this.org$apache$spark$deploy$master$ui$MasterPage$$parent.master().reverseProxy(), worker.id(), worker.webUiAddress()), (MetaData)$md);
            string = elem;
            NodeBuffer $buf3 = new NodeBuffer();
            $buf3.$amp$plus((Object)new Text("\n              "));
            $buf3.$amp$plus((Object)worker.id());
            $buf3.$amp$plus((Object)new Text("\n            "));
            elem = new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3);
        } else {
            string = worker.id();
        }
        $buf2.$amp$plus((Object)string);
        $buf2.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf4 = new NodeBuffer();
        $buf4.$amp$plus((Object)worker.host());
        $buf4.$amp$plus((Object)new Text(":"));
        $buf4.$amp$plus((Object)BoxesRunTime.boxToInteger((int)worker.port()));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf5 = new NodeBuffer();
        $buf5.$amp$plus((Object)worker.state());
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf6 = new NodeBuffer();
        $buf6.$amp$plus((Object)BoxesRunTime.boxToInteger((int)worker.cores()));
        $buf6.$amp$plus((Object)new Text(" ("));
        $buf6.$amp$plus((Object)BoxesRunTime.boxToInteger((int)worker.coresUsed()));
        $buf6.$amp$plus((Object)new Text(" Used)"));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6));
        $buf.$amp$plus((Object)new Text("\n      "));
        Null$ $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("sorttable_customkey", new StringOps(Predef$.MODULE$.augmentString("%s.%s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)worker.memory()), BoxesRunTime.boxToInteger((int)worker.memoryUsed())})), (MetaData)$md);
        NodeBuffer $buf7 = new NodeBuffer();
        $buf7.$amp$plus((Object)new Text("\n        "));
        $buf7.$amp$plus((Object)Utils$.MODULE$.megabytesToString(worker.memory()));
        $buf7.$amp$plus((Object)new Text("\n        ("));
        $buf7.$amp$plus((Object)Utils$.MODULE$.megabytesToString(worker.memoryUsed()));
        $buf7.$amp$plus((Object)new Text(" Used)\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7));
        $buf.$amp$plus((Object)new Text("\n    "));
        return new Elem(null, "tr", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public Seq<Node> org$apache$spark$deploy$master$ui$MasterPage$$appRow(ApplicationInfo app) {
        block6 : {
            block5 : {
                block4 : {
                    if (!this.org$apache$spark$deploy$master$ui$MasterPage$$parent.killEnabled()) ** GOTO lbl-1000
                    var3_2 = ApplicationState$.MODULE$.RUNNING();
                    if (app.state() != null) break block4;
                    if (var3_2 == null) ** GOTO lbl-1000
                    break block5;
                }
                if (v0.equals((Object)var3_2)) ** GOTO lbl-1000
            }
            var4_3 = ApplicationState$.MODULE$.WAITING();
            if (app.state() != null) break block6;
            if (var4_3 == null) ** GOTO lbl-1000
            ** GOTO lbl-1000
        }
        if (v1.equals((Object)var4_3)) lbl-1000: // 4 sources:
        {
            confirm = new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"if (window.confirm('Are you sure you want to kill application ", " ?')) "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{app.id()}))).append((Object)"{ this.parentNode.submit(); return true; } else { return false; }").toString();
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("style", (Seq)new Text("display:inline"), (MetaData)$md);
            $md = new UnprefixedAttribute("method", (Seq)new Text("POST"), (MetaData)$md);
            $md = new UnprefixedAttribute("action", (Seq)new Text("app/kill/"), (MetaData)$md);
            v2 = v3;
            $buf = new NodeBuffer();
            $buf.$amp$plus((Object)new Text("\n        "));
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("value", app.id().toString(), (MetaData)$md);
            $md = new UnprefixedAttribute("name", (Seq)new Text("id"), (MetaData)$md);
            $md = new UnprefixedAttribute("type", (Seq)new Text("hidden"), (MetaData)$md);
            $buf.$amp$plus((Object)new Elem(null, "input", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, true, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf.$amp$plus((Object)new Text("\n        "));
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("value", (Seq)new Text("true"), (MetaData)$md);
            $md = new UnprefixedAttribute("name", (Seq)new Text("terminate"), (MetaData)$md);
            $md = new UnprefixedAttribute("type", (Seq)new Text("hidden"), (MetaData)$md);
            $buf.$amp$plus((Object)new Elem(null, "input", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, true, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf.$amp$plus((Object)new Text("\n        "));
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("class", (Seq)new Text("kill-link"), (MetaData)$md);
            $md = new UnprefixedAttribute("onclick", confirm, (MetaData)$md);
            $md = new UnprefixedAttribute("href", (Seq)new Text("#"), (MetaData)$md);
            $buf = new NodeBuffer();
            $buf.$amp$plus((Object)new Text("(kill)"));
            $buf.$amp$plus((Object)new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
            $buf.$amp$plus((Object)new Text("\n      "));
            v3 = new Elem(null, "form", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
        } else lbl-1000: // 3 sources:
        {
            v2 = BoxedUnit.UNIT;
        }
        killLink = v2;
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n        "));
        $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("href", new StringBuilder().append((Object)"app?appId=").append((Object)app.id()).toString(), (MetaData)$md);
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)app.id());
        $buf.$amp$plus((Object)new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)killLink);
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n        "));
        if (app.isFinished()) {
            v4 = app.desc().name();
        } else {
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("href", UIUtils$.MODULE$.makeHref(this.org$apache$spark$deploy$master$ui$MasterPage$$parent.master().reverseProxy(), app.id(), app.desc().appUiUrl()), (MetaData)$md);
            v4 = v5;
            $buf = new NodeBuffer();
            $buf.$amp$plus((Object)app.desc().name());
            v5 = new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
        }
        $buf.$amp$plus((Object)v4);
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)BoxesRunTime.boxToInteger((int)app.coresGranted()));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("sorttable_customkey", BoxesRunTime.boxToInteger((int)app.desc().memoryPerExecutorMB()).toString(), (MetaData)$md);
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)Utils$.MODULE$.megabytesToString(app.desc().memoryPerExecutorMB()));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)UIUtils$.MODULE$.formatDate(app.submitDate()));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)app.desc().user());
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)app.state().toString());
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)UIUtils$.MODULE$.formatDuration(app.duration()));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n    "));
        return new Elem(null, "tr", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public Seq<Node> org$apache$spark$deploy$master$ui$MasterPage$$driverRow(DriverInfo driver) {
        block6 : {
            block5 : {
                block4 : {
                    block3 : {
                        block2 : {
                            if (!this.org$apache$spark$deploy$master$ui$MasterPage$$parent.killEnabled()) ** GOTO lbl-1000
                            var3_2 = DriverState$.MODULE$.RUNNING();
                            if (driver.state() != null) break block2;
                            if (var3_2 == null) ** GOTO lbl-1000
                            break block3;
                        }
                        if (v0.equals((Object)var3_2)) ** GOTO lbl-1000
                    }
                    var4_3 = DriverState$.MODULE$.SUBMITTED();
                    if (driver.state() != null) break block4;
                    if (var4_3 == null) ** GOTO lbl-1000
                    break block5;
                }
                if (v1.equals((Object)var4_3)) ** GOTO lbl-1000
            }
            var5_4 = DriverState$.MODULE$.RELAUNCHING();
            if (driver.state() != null) break block6;
            if (var5_4 == null) ** GOTO lbl-1000
            ** GOTO lbl-1000
        }
        if (v2.equals((Object)var5_4)) lbl-1000: // 6 sources:
        {
            confirm = new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"if (window.confirm('Are you sure you want to kill driver ", " ?')) "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{driver.id()}))).append((Object)"{ this.parentNode.submit(); return true; } else { return false; }").toString();
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("style", (Seq)new Text("display:inline"), (MetaData)$md);
            $md = new UnprefixedAttribute("method", (Seq)new Text("POST"), (MetaData)$md);
            $md = new UnprefixedAttribute("action", (Seq)new Text("driver/kill/"), (MetaData)$md);
            v3 = v4;
            $buf = new NodeBuffer();
            $buf.$amp$plus((Object)new Text("\n        "));
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("value", driver.id().toString(), (MetaData)$md);
            $md = new UnprefixedAttribute("name", (Seq)new Text("id"), (MetaData)$md);
            $md = new UnprefixedAttribute("type", (Seq)new Text("hidden"), (MetaData)$md);
            $buf.$amp$plus((Object)new Elem(null, "input", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, true, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf.$amp$plus((Object)new Text("\n        "));
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("value", (Seq)new Text("true"), (MetaData)$md);
            $md = new UnprefixedAttribute("name", (Seq)new Text("terminate"), (MetaData)$md);
            $md = new UnprefixedAttribute("type", (Seq)new Text("hidden"), (MetaData)$md);
            $buf.$amp$plus((Object)new Elem(null, "input", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, true, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf.$amp$plus((Object)new Text("\n        "));
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("class", (Seq)new Text("kill-link"), (MetaData)$md);
            $md = new UnprefixedAttribute("onclick", confirm, (MetaData)$md);
            $md = new UnprefixedAttribute("href", (Seq)new Text("#"), (MetaData)$md);
            $buf = new NodeBuffer();
            $buf.$amp$plus((Object)new Text("(kill)"));
            $buf.$amp$plus((Object)new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
            $buf.$amp$plus((Object)new Text("\n      "));
            v4 = new Elem(null, "form", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
        } else lbl-1000: // 3 sources:
        {
            v3 = BoxedUnit.UNIT;
        }
        killLink = v3;
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)driver.id());
        $buf.$amp$plus((Object)new Text(" "));
        $buf.$amp$plus((Object)killLink);
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)UIUtils$.MODULE$.formatDate(driver.submitDate()));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus(driver.worker().map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ MasterPage $outer;

            public final Object apply(WorkerInfo w) {
                String string;
                if (w.isAlive()) {
                    Elem elem;
                    Null$ $md = Null$.MODULE$;
                    $md = new UnprefixedAttribute("href", UIUtils$.MODULE$.makeHref(this.$outer.org$apache$spark$deploy$master$ui$MasterPage$$parent.master().reverseProxy(), w.id(), w.webUiAddress()), (MetaData)$md);
                    string = elem;
                    NodeBuffer $buf = new NodeBuffer();
                    $buf.$amp$plus((Object)new Text("\n            "));
                    $buf.$amp$plus((Object)w.id().toString());
                    $buf.$amp$plus((Object)new Text("\n          "));
                    elem = new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
                } else {
                    string = w.id().toString();
                }
                return string;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }).getOrElse((Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "None";
            }
        }));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)driver.state());
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("sorttable_customkey", BoxesRunTime.boxToInteger((int)driver.desc().cores()).toString(), (MetaData)$md);
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)BoxesRunTime.boxToInteger((int)driver.desc().cores()));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("sorttable_customkey", BoxesRunTime.boxToInteger((int)driver.desc().mem()).toString(), (MetaData)$md);
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)Utils$.MODULE$.megabytesToString(driver.desc().mem()));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus(driver.desc().command().arguments().apply(2));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n    "));
        return new Elem(null, "tr", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
    }

    private final boolean hasDrivers$1(DriverInfo[] activeDrivers$1, DriverInfo[] completedDrivers$1) {
        return activeDrivers$1.length > 0 || completedDrivers$1.length > 0;
    }

    public MasterPage(MasterWebUI parent) {
        this.org$apache$spark$deploy$master$ui$MasterPage$$parent = parent;
        super("");
        this.org$apache$spark$deploy$master$ui$MasterPage$$master = parent.masterEndpointRef();
    }
}

