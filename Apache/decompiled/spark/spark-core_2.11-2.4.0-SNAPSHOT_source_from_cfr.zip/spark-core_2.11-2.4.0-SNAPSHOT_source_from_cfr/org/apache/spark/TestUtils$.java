/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.TestUtils$$anon
 *  org.apache.spark.TestUtils$$anonfun
 *  org.apache.spark.TestUtils$$anonfun$assertNotSpilled
 *  org.apache.spark.TestUtils$$anonfun$assertSpilled
 *  org.apache.spark.TestUtils$$anonfun$createCompiledClass
 *  org.apache.spark.TestUtils$$anonfun$createJar
 *  org.apache.spark.TestUtils$$anonfun$createJarWithFiles
 *  org.apache.spark.TestUtils$$anonfun$httpResponseCode
 *  org.spark_project.guava.io.Files
 *  scala.Function0
 *  scala.Function1
 *  scala.None$
 *  scala.Option
 *  scala.Option$
 *  scala.Predef$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.Tuple2
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.JavaConverters$
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableOnce
 *  scala.collection.convert.Decorators
 *  scala.collection.convert.Decorators$AsJava
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.generic.FilterMonadic
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.Nil$
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.runtime.BoxesRunTime
 *  scala.util.Try
 *  scala.util.Try$
 */
package org.apache.spark;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.tools.DiagnosticListener;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileManager;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;
import org.apache.spark.SparkContext;
import org.apache.spark.SparkExecutorInfo;
import org.apache.spark.SparkStatusTracker;
import org.apache.spark.SpillListener;
import org.apache.spark.TestUtils;
import org.apache.spark.TestUtils$;
import org.apache.spark.scheduler.SparkListenerInterface;
import org.apache.spark.util.Utils$;
import org.spark_project.guava.io.Files;
import scala.Function0;
import scala.Function1;
import scala.None$;
import scala.Option;
import scala.Option$;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.Tuple2;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.JavaConverters$;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableOnce;
import scala.collection.convert.Decorators;
import scala.collection.generic.CanBuildFrom;
import scala.collection.generic.FilterMonadic;
import scala.collection.immutable.Map;
import scala.collection.immutable.Nil$;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.runtime.BoxesRunTime;
import scala.util.Try;
import scala.util.Try$;

public final class TestUtils$ {
    public static final TestUtils$ MODULE$;
    private final JavaFileObject.Kind org$apache$spark$TestUtils$$SOURCE;

    public static {
        new org.apache.spark.TestUtils$();
    }

    public URL createJarWithClasses(Seq<String> classNames, String toStringValue, Seq<Tuple2<String, String>> classNamesWithBase, Seq<URL> classpathUrls) {
        File tempDir = Utils$.MODULE$.createTempDir(Utils$.MODULE$.createTempDir$default$1(), Utils$.MODULE$.createTempDir$default$2());
        Seq files1 = (Seq)classNames.map((Function1)new Serializable(toStringValue, classpathUrls, tempDir){
            public static final long serialVersionUID = 0L;
            private final String toStringValue$1;
            private final Seq classpathUrls$1;
            private final File tempDir$1;

            public final File apply(String name2) {
                String x$5 = name2;
                File x$6 = this.tempDir$1;
                String x$7 = this.toStringValue$1;
                Seq x$8 = this.classpathUrls$1;
                String x$9 = TestUtils$.MODULE$.createCompiledClass$default$4();
                return TestUtils$.MODULE$.createCompiledClass(x$5, x$6, x$7, x$9, (Seq<URL>)x$8);
            }
            {
                this.toStringValue$1 = toStringValue$1;
                this.classpathUrls$1 = classpathUrls$1;
                this.tempDir$1 = tempDir$1;
            }
        }, Seq$.MODULE$.canBuildFrom());
        Seq files2 = (Seq)classNamesWithBase.withFilter((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply(Tuple2<String, String> check$ifrefutable$1) {
                Tuple2<String, String> tuple2 = check$ifrefutable$1;
                boolean bl = tuple2 != null;
                return bl;
            }
        }).map((Function1)new Serializable(toStringValue, classpathUrls, tempDir){
            public static final long serialVersionUID = 0L;
            private final String toStringValue$1;
            private final Seq classpathUrls$1;
            private final File tempDir$1;

            public final File apply(Tuple2<String, String> x$1) {
                Tuple2<String, String> tuple2 = x$1;
                if (tuple2 != null) {
                    String childName = (String)tuple2._1();
                    String baseName = (String)tuple2._2();
                    File file = TestUtils$.MODULE$.createCompiledClass(childName, this.tempDir$1, this.toStringValue$1, baseName, (Seq<URL>)this.classpathUrls$1);
                    return file;
                }
                throw new scala.MatchError(tuple2);
            }
            {
                this.toStringValue$1 = toStringValue$1;
                this.classpathUrls$1 = classpathUrls$1;
                this.tempDir$1 = tempDir$1;
            }
        }, Seq$.MODULE$.canBuildFrom());
        File jarFile = new File(tempDir, new StringOps(Predef$.MODULE$.augmentString("testJar-%s.jar")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)System.currentTimeMillis())})));
        return this.createJar((Seq<File>)((Seq)files1.$plus$plus((GenTraversableOnce)files2, Seq$.MODULE$.canBuildFrom())), jarFile, this.createJar$default$3());
    }

    public URL createJarWithFiles(Map<String, String> files, File dir) {
        File tempDir = (File)Option$.MODULE$.apply((Object)dir).getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final File apply() {
                return Utils$.MODULE$.createTempDir(Utils$.MODULE$.createTempDir$default$1(), Utils$.MODULE$.createTempDir$default$2());
            }
        });
        File jarFile = File.createTempFile("testJar", ".jar", tempDir);
        JarOutputStream jarStream = new JarOutputStream(new FileOutputStream(jarFile));
        files.foreach((Function1)new Serializable(jarStream){
            public static final long serialVersionUID = 0L;
            private final JarOutputStream jarStream$1;

            public final long apply(Tuple2<String, String> x0$1) {
                Tuple2<String, String> tuple2 = x0$1;
                if (tuple2 != null) {
                    String k = (String)tuple2._1();
                    String v = (String)tuple2._2();
                    java.util.jar.JarEntry entry = new java.util.jar.JarEntry(k);
                    this.jarStream$1.putNextEntry(entry);
                    long l = org.spark_project.guava.io.ByteStreams.copy((java.io.InputStream)new java.io.ByteArrayInputStream(v.getBytes(java.nio.charset.StandardCharsets.UTF_8)), (OutputStream)this.jarStream$1);
                    return l;
                }
                throw new scala.MatchError(tuple2);
            }
            {
                this.jarStream$1 = jarStream$1;
            }
        });
        jarStream.close();
        return jarFile.toURI().toURL();
    }

    public URL createJar(Seq<File> files, File jarFile, Option<String> directoryPrefix) {
        FileOutputStream jarFileStream = new FileOutputStream(jarFile);
        JarOutputStream jarStream = new JarOutputStream(jarFileStream, new Manifest());
        files.foreach((Function1)new Serializable(directoryPrefix, jarStream){
            public static final long serialVersionUID = 0L;
            private final Option directoryPrefix$1;
            private final JarOutputStream jarStream$2;

            public final void apply(File file) {
                String prefix = (String)this.directoryPrefix$1.map((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final String apply(String d) {
                        return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{d}));
                    }
                }).getOrElse((Function0)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final String apply() {
                        return "";
                    }
                });
                java.util.jar.JarEntry jarEntry = new java.util.jar.JarEntry(new StringBuilder().append((Object)prefix).append((Object)file.getName()).toString());
                this.jarStream$2.putNextEntry(jarEntry);
                java.io.FileInputStream in = new java.io.FileInputStream(file);
                org.spark_project.guava.io.ByteStreams.copy((java.io.InputStream)in, (OutputStream)this.jarStream$2);
                in.close();
            }
            {
                this.directoryPrefix$1 = directoryPrefix$1;
                this.jarStream$2 = jarStream$2;
            }
        });
        jarStream.close();
        jarFileStream.close();
        return jarFile.toURI().toURL();
    }

    public String createJarWithClasses$default$2() {
        return "";
    }

    public Seq<Tuple2<String, String>> createJarWithClasses$default$3() {
        return (Seq)Seq$.MODULE$.empty();
    }

    public Seq<URL> createJarWithClasses$default$4() {
        return (Seq)Seq$.MODULE$.empty();
    }

    public Option<String> createJar$default$3() {
        return None$.MODULE$;
    }

    public File createJarWithFiles$default$2() {
        return null;
    }

    public JavaFileObject.Kind org$apache$spark$TestUtils$$SOURCE() {
        return this.org$apache$spark$TestUtils$$SOURCE;
    }

    public URI org$apache$spark$TestUtils$$createURI(String name2) {
        return URI.create(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"string:///", "", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{name2.replace(".", "/"), this.org$apache$spark$TestUtils$$SOURCE().extension})));
    }

    public File createCompiledClass(String className, File destDir, TestUtils.JavaSourceFromString sourceFile, Seq<URL> classpathUrls) {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        Seq options = classpathUrls.nonEmpty() ? (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"-classpath", ((TraversableOnce)classpathUrls.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(URL x$2) {
                return x$2.getFile();
            }
        }, Seq$.MODULE$.canBuildFrom())).mkString(File.pathSeparator)})) : (Seq)Seq$.MODULE$.empty();
        compiler.getTask(null, null, null, (Iterable)JavaConverters$.MODULE$.seqAsJavaListConverter(options).asJava(), null, Arrays.asList((Object[])new TestUtils.JavaSourceFromString[]{sourceFile})).call();
        String fileName = new StringBuilder().append((Object)className).append((Object)".class").toString();
        File result2 = new File(fileName);
        Predef$.MODULE$.assert(result2.exists(), (Function0)new Serializable(result2){
            public static final long serialVersionUID = 0L;
            private final File result$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Compiled file not found: ").append((Object)this.result$1.getAbsolutePath()).toString();
            }
            {
                this.result$1 = result$1;
            }
        });
        File out = new File(destDir, fileName);
        Files.move((File)result2, (File)out);
        Predef$.MODULE$.assert(out.exists(), (Function0)new Serializable(out){
            public static final long serialVersionUID = 0L;
            private final File out$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Destination file not moved: ").append((Object)this.out$1.getAbsolutePath()).toString();
            }
            {
                this.out$1 = out$1;
            }
        });
        return out;
    }

    public File createCompiledClass(String className, File destDir, String toStringValue, String baseClass, Seq<URL> classpathUrls) {
        String extendsText = (String)Option$.MODULE$.apply((Object)baseClass).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(String c) {
                return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" extends ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{c}));
            }
        }).getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "";
            }
        });
        TestUtils.JavaSourceFromString sourceFile = new TestUtils.JavaSourceFromString(className, new StringBuilder().append((Object)"public class ").append((Object)className).append((Object)extendsText).append((Object)" implements java.io.Serializable {").append((Object)"  @Override public String toString() { return \"").append((Object)toStringValue).append((Object)"\"; }}").toString());
        return this.createCompiledClass(className, destDir, sourceFile, classpathUrls);
    }

    public String createCompiledClass$default$3() {
        return "";
    }

    public String createCompiledClass$default$4() {
        return null;
    }

    public Seq<URL> createCompiledClass$default$5() {
        return (Seq)Seq$.MODULE$.empty();
    }

    public <T> void assertSpilled(SparkContext sc, String identifier, Function0<T> body2) {
        SpillListener spillListener = new SpillListener();
        sc.addSparkListener(spillListener);
        body2.apply();
        Predef$.MODULE$.assert(spillListener.numSpilledStages() > 0, (Function0)new Serializable(identifier){
            public static final long serialVersionUID = 0L;
            private final String identifier$1;

            public final String apply() {
                return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"expected ", " to spill, but did not"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.identifier$1}));
            }
            {
                this.identifier$1 = identifier$1;
            }
        });
    }

    public <T> void assertNotSpilled(SparkContext sc, String identifier, Function0<T> body2) {
        SpillListener spillListener = new SpillListener();
        sc.addSparkListener(spillListener);
        body2.apply();
        Predef$.MODULE$.assert(spillListener.numSpilledStages() == 0, (Function0)new Serializable(identifier){
            public static final long serialVersionUID = 0L;
            private final String identifier$2;

            public final String apply() {
                return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"expected ", " to not spill, but did"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.identifier$2}));
            }
            {
                this.identifier$2 = identifier$2;
            }
        });
    }

    public boolean testCommandAvailable(String command) {
        Try attempt = Try$.MODULE$.apply((Function0)new Serializable(command){
            public static final long serialVersionUID = 0L;
            private final String command$1;

            public final int apply() {
                return this.apply$mcI$sp();
            }

            public int apply$mcI$sp() {
                return scala.sys.process.Process$.MODULE$.apply(this.command$1).run(scala.sys.process.ProcessLogger$.MODULE$.apply((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final void apply(String x$3) {
                    }
                })).exitValue();
            }
            {
                this.command$1 = command$1;
            }
        });
        return attempt.isSuccess() && BoxesRunTime.unboxToInt((Object)attempt.get()) == 0;
    }

    public int httpResponseCode(URL url, String method, Seq<Tuple2<String, String>> headers2) {
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();
        connection.setRequestMethod(method);
        headers2.foreach((Function1)new Serializable(connection){
            public static final long serialVersionUID = 0L;
            private final HttpURLConnection connection$1;

            public final void apply(Tuple2<String, String> x0$2) {
                Tuple2<String, String> tuple2 = x0$2;
                if (tuple2 != null) {
                    String k = (String)tuple2._1();
                    String v = (String)tuple2._2();
                    this.connection$1.setRequestProperty(k, v);
                    scala.runtime.BoxedUnit boxedUnit = scala.runtime.BoxedUnit.UNIT;
                    return;
                }
                throw new scala.MatchError(tuple2);
            }
            {
                this.connection$1 = connection$1;
            }
        });
        if (connection instanceof HttpsURLConnection) {
            SSLContext sslCtx = SSLContext.getInstance("SSL");
            X509TrustManager trustManager = new X509TrustManager(){

                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                public void checkClientTrusted(java.security.cert.X509Certificate[] x509Certificates, String s) {
                }

                public void checkServerTrusted(java.security.cert.X509Certificate[] x509Certificates, String s) {
                }
            };
            HostnameVerifier verifier = new HostnameVerifier(){

                public boolean verify(String hostname, javax.net.ssl.SSLSession session) {
                    return true;
                }
            };
            sslCtx.init(null, new TrustManager[]{trustManager}, new SecureRandom());
            ((HttpsURLConnection)connection).setSSLSocketFactory(sslCtx.getSocketFactory());
            ((HttpsURLConnection)connection).setHostnameVerifier(verifier);
        }
        try {
            connection.connect();
            return connection.getResponseCode();
        }
        finally {
            connection.disconnect();
        }
    }

    public String httpResponseCode$default$2() {
        return "GET";
    }

    public Seq<Tuple2<String, String>> httpResponseCode$default$3() {
        return Nil$.MODULE$;
    }

    public void waitUntilExecutorsUp(SparkContext sc, int numExecutors, long timeout) {
        long finishTime = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeout);
        while (System.nanoTime() < finishTime) {
            if (sc.statusTracker().getExecutorInfos().length > numExecutors) {
                return;
            }
            Thread.sleep(10L);
        }
        throw new TimeoutException(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Can't find ", " executors before ", " milliseconds elapsed"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)numExecutors), BoxesRunTime.boxToLong((long)timeout)})));
    }

    private TestUtils$() {
        MODULE$ = this;
        this.org$apache$spark$TestUtils$$SOURCE = JavaFileObject.Kind.SOURCE;
    }
}

