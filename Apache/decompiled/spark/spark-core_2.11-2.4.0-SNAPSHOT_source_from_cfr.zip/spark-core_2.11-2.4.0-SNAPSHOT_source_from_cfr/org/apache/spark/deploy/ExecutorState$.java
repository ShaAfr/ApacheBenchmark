/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Predef$
 *  scala.collection.GenTraversable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.SeqLike
 *  scala.collection.mutable.WrappedArray
 */
package org.apache.spark.deploy;

import scala.Enumeration;
import scala.Predef$;
import scala.collection.GenTraversable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.SeqLike;
import scala.collection.mutable.WrappedArray;

public final class ExecutorState$
extends Enumeration {
    public static final ExecutorState$ MODULE$;
    private final Enumeration.Value LAUNCHING;
    private final Enumeration.Value RUNNING;
    private final Enumeration.Value KILLED;
    private final Enumeration.Value FAILED;
    private final Enumeration.Value LOST;
    private final Enumeration.Value EXITED;

    public static {
        new org.apache.spark.deploy.ExecutorState$();
    }

    public Enumeration.Value LAUNCHING() {
        return this.LAUNCHING;
    }

    public Enumeration.Value RUNNING() {
        return this.RUNNING;
    }

    public Enumeration.Value KILLED() {
        return this.KILLED;
    }

    public Enumeration.Value FAILED() {
        return this.FAILED;
    }

    public Enumeration.Value LOST() {
        return this.LOST;
    }

    public Enumeration.Value EXITED() {
        return this.EXITED;
    }

    public boolean isFinished(Enumeration.Value state) {
        return ((SeqLike)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new Enumeration.Value[]{this.KILLED(), this.FAILED(), this.LOST(), this.EXITED()}))).contains((Object)state);
    }

    private ExecutorState$() {
        MODULE$ = this;
        this.LAUNCHING = this.Value();
        this.RUNNING = this.Value();
        this.KILLED = this.Value();
        this.FAILED = this.Value();
        this.LOST = this.Value();
        this.EXITED = this.Value();
    }
}

