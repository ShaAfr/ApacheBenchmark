/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.Tuple4
 *  scala.collection.Seq
 *  scala.runtime.AbstractFunction2
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.AccumulableInfo;
import org.apache.spark.scheduler.SparkListenerExecutorMetricsUpdate;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.Tuple4;
import scala.collection.Seq;
import scala.runtime.AbstractFunction2;

public final class SparkListenerExecutorMetricsUpdate$
extends AbstractFunction2<String, Seq<Tuple4<Object, Object, Object, Seq<AccumulableInfo>>>, SparkListenerExecutorMetricsUpdate>
implements Serializable {
    public static final SparkListenerExecutorMetricsUpdate$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerExecutorMetricsUpdate$();
    }

    public final String toString() {
        return "SparkListenerExecutorMetricsUpdate";
    }

    public SparkListenerExecutorMetricsUpdate apply(String execId, Seq<Tuple4<Object, Object, Object, Seq<AccumulableInfo>>> accumUpdates) {
        return new SparkListenerExecutorMetricsUpdate(execId, accumUpdates);
    }

    public Option<Tuple2<String, Seq<Tuple4<Object, Object, Object, Seq<AccumulableInfo>>>>> unapply(SparkListenerExecutorMetricsUpdate x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)x$0.execId(), x$0.accumUpdates()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerExecutorMetricsUpdate$() {
        MODULE$ = this;
    }
}

