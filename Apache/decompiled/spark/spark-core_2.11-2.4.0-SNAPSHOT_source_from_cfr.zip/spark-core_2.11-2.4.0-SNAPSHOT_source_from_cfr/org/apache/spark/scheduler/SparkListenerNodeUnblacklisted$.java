/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerNodeUnblacklisted;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;
import scala.runtime.BoxesRunTime;

public final class SparkListenerNodeUnblacklisted$
extends AbstractFunction2<Object, String, SparkListenerNodeUnblacklisted>
implements Serializable {
    public static final SparkListenerNodeUnblacklisted$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerNodeUnblacklisted$();
    }

    public final String toString() {
        return "SparkListenerNodeUnblacklisted";
    }

    public SparkListenerNodeUnblacklisted apply(long time, String hostId) {
        return new SparkListenerNodeUnblacklisted(time, hostId);
    }

    public Option<Tuple2<Object, String>> unapply(SparkListenerNodeUnblacklisted x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)BoxesRunTime.boxToLong((long)x$0.time()), (Object)x$0.hostId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerNodeUnblacklisted$() {
        MODULE$ = this;
    }
}

