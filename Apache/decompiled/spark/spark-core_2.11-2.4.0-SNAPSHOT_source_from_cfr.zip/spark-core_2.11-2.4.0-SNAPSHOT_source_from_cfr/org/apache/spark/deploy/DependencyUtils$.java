/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.hadoop.conf.Configuration
 *  org.apache.hadoop.fs.Path
 *  org.apache.ivy.core.settings.IvySettings
 *  org.apache.spark.deploy.DependencyUtils$$anonfun
 *  org.apache.spark.deploy.DependencyUtils$$anonfun$addJarsToClassPath
 *  org.apache.spark.deploy.DependencyUtils$$anonfun$downloadFile
 *  org.apache.spark.deploy.DependencyUtils$$anonfun$downloadFileList
 *  org.apache.spark.deploy.DependencyUtils$$anonfun$resolveAndDownloadJars
 *  org.apache.spark.deploy.DependencyUtils$$anonfun$resolveGlobPaths
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Option$
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$$less$colon$less
 *  scala.Serializable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.Nil$
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.WrappedArray
 *  scala.sys.SystemProperties
 *  scala.sys.package$
 */
package org.apache.spark.deploy;

import java.io.File;
import java.net.URI;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.ivy.core.settings.IvySettings;
import org.apache.spark.SecurityManager;
import org.apache.spark.SparkConf;
import org.apache.spark.deploy.DependencyUtils$;
import org.apache.spark.deploy.SparkSubmitUtils$;
import org.apache.spark.util.MutableURLClassLoader;
import org.apache.spark.util.Utils$;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Option$;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.Nil$;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.WrappedArray;
import scala.sys.SystemProperties;
import scala.sys.package$;

public final class DependencyUtils$ {
    public static final DependencyUtils$ MODULE$;

    public static {
        new org.apache.spark.deploy.DependencyUtils$();
    }

    public String resolveMavenDependencies(String packagesExclusions, String packages, String repositories, String ivyRepoPath) {
        Nil$ exclusions = StringUtils.isBlank((CharSequence)packagesExclusions) ? Nil$.MODULE$ : Predef$.MODULE$.wrapRefArray((Object[])packagesExclusions.split(","));
        IvySettings ivySettings = (IvySettings)package$.MODULE$.props().get("spark.jars.ivySettings").map((Function1)new Serializable(repositories, ivyRepoPath){
            public static final long serialVersionUID = 0L;
            private final String repositories$1;
            private final String ivyRepoPath$1;

            public final IvySettings apply(String ivySettingsFile) {
                return SparkSubmitUtils$.MODULE$.loadIvySettings(ivySettingsFile, (Option<String>)Option$.MODULE$.apply((Object)this.repositories$1), (Option<String>)Option$.MODULE$.apply((Object)this.ivyRepoPath$1));
            }
            {
                this.repositories$1 = repositories$1;
                this.ivyRepoPath$1 = ivyRepoPath$1;
            }
        }).getOrElse((Function0)new Serializable(repositories, ivyRepoPath){
            public static final long serialVersionUID = 0L;
            private final String repositories$1;
            private final String ivyRepoPath$1;

            public final IvySettings apply() {
                return SparkSubmitUtils$.MODULE$.buildIvySettings((Option<String>)Option$.MODULE$.apply((Object)this.repositories$1), (Option<String>)Option$.MODULE$.apply((Object)this.ivyRepoPath$1));
            }
            {
                this.repositories$1 = repositories$1;
                this.ivyRepoPath$1 = ivyRepoPath$1;
            }
        });
        return SparkSubmitUtils$.MODULE$.resolveMavenCoordinates(packages, ivySettings, (Seq<String>)exclusions, SparkSubmitUtils$.MODULE$.resolveMavenCoordinates$default$4());
    }

    public String resolveAndDownloadJars(String jars, String userJar, SparkConf sparkConf, Configuration hadoopConf, SecurityManager secMgr) {
        File targetDir = Utils$.MODULE$.createTempDir(Utils$.MODULE$.createTempDir$default$1(), Utils$.MODULE$.createTempDir$default$2());
        return (String)Option$.MODULE$.apply((Object)jars).map((Function1)new Serializable(userJar, hadoopConf){
            public static final long serialVersionUID = 0L;
            public final String userJar$1;
            private final Configuration hadoopConf$1;

            public final String apply(String x$1) {
                return Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])DependencyUtils$.MODULE$.resolveGlobPaths(x$1, this.hadoopConf$1).split(",")).filterNot((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ anonfun.resolveAndDownloadJars.1 $outer;

                    public final boolean apply(String x$2) {
                        return x$2.contains((CharSequence)Predef$.MODULE$.refArrayOps((Object[])this.$outer.userJar$1.split("/")).last());
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                })).mkString(",");
            }
            {
                this.userJar$1 = userJar$1;
                this.hadoopConf$1 = hadoopConf$1;
            }
        }).filterNot((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(String x$3) {
                String string = "";
                if (x$3 != null) {
                    String string2;
                    if (!string2.equals(string)) return false;
                    return true;
                }
                if (string == null) return true;
                return false;
            }
        }).map((Function1)new Serializable(sparkConf, hadoopConf, secMgr, targetDir){
            public static final long serialVersionUID = 0L;
            private final SparkConf sparkConf$1;
            private final Configuration hadoopConf$1;
            private final SecurityManager secMgr$1;
            private final File targetDir$1;

            public final String apply(String x$4) {
                return DependencyUtils$.MODULE$.downloadFileList(x$4, this.targetDir$1, this.sparkConf$1, this.hadoopConf$1, this.secMgr$1);
            }
            {
                this.sparkConf$1 = sparkConf$1;
                this.hadoopConf$1 = hadoopConf$1;
                this.secMgr$1 = secMgr$1;
                this.targetDir$1 = targetDir$1;
            }
        }).orNull(Predef$.MODULE$.$conforms());
    }

    public void addJarsToClassPath(String jars, MutableURLClassLoader loader) {
        if (jars != null) {
            Predef$.MODULE$.refArrayOps((Object[])jars.split(",")).foreach((Function1)new Serializable(loader){
                public static final long serialVersionUID = 0L;
                private final MutableURLClassLoader loader$1;

                public final void apply(String jar) {
                    org.apache.spark.deploy.SparkSubmit$.MODULE$.addJarToClasspath(jar, this.loader$1);
                }
                {
                    this.loader$1 = loader$1;
                }
            });
        }
    }

    public String downloadFileList(String fileList, File targetDir, SparkConf sparkConf, Configuration hadoopConf, SecurityManager secMgr) {
        Predef$.MODULE$.require(fileList != null, (Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "fileList cannot be null.";
            }
        });
        return ((TraversableOnce)Utils$.MODULE$.stringToSeq(fileList).map((Function1)new Serializable(targetDir, sparkConf, hadoopConf, secMgr){
            public static final long serialVersionUID = 0L;
            private final File targetDir$2;
            private final SparkConf sparkConf$2;
            private final Configuration hadoopConf$3;
            private final SecurityManager secMgr$2;

            public final String apply(String x$5) {
                return DependencyUtils$.MODULE$.downloadFile(x$5, this.targetDir$2, this.sparkConf$2, this.hadoopConf$3, this.secMgr$2);
            }
            {
                this.targetDir$2 = targetDir$2;
                this.sparkConf$2 = sparkConf$2;
                this.hadoopConf$3 = hadoopConf$3;
                this.secMgr$2 = secMgr$2;
            }
        }, Seq$.MODULE$.canBuildFrom())).mkString(",");
    }

    public String downloadFile(String path, File targetDir, SparkConf sparkConf, Configuration hadoopConf, SecurityManager secMgr) {
        String string;
        Predef$.MODULE$.require(path != null, (Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "path cannot be null.";
            }
        });
        URI uri = Utils$.MODULE$.resolveURI(path);
        String string2 = uri.getScheme();
        boolean bl = "file".equals(string2) ? true : "local".equals(string2);
        if (bl) {
            string = path;
        } else {
            boolean bl2 = "http".equals(string2) ? true : ("https".equals(string2) ? true : "ftp".equals(string2));
            if (bl2 && Utils$.MODULE$.isTesting()) {
                File file = new File(uri.getPath());
                string = new File(targetDir, file.getName()).toURI().toString();
            } else {
                String fname = new Path(uri).getName();
                File localFile = Utils$.MODULE$.doFetchFile(uri.toString(), targetDir, fname, sparkConf, secMgr, hadoopConf);
                string = localFile.toURI().toString();
            }
        }
        return string;
    }

    public String resolveGlobPaths(String paths, Configuration hadoopConf) {
        Predef$.MODULE$.require(paths != null, (Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "paths cannot be null.";
            }
        });
        return ((TraversableOnce)Utils$.MODULE$.stringToSeq(paths).flatMap((Function1)new Serializable(hadoopConf){
            public static final long serialVersionUID = 0L;
            private final Configuration hadoopConf$2;

            public final ArrayOps<String> apply(String path) {
                ArrayOps arrayOps;
                URI uri = Utils$.MODULE$.resolveURI(path);
                String string = uri.getScheme();
                boolean bl = "local".equals(string) ? true : ("http".equals(string) ? true : ("https".equals(string) ? true : "ftp".equals(string)));
                if (bl) {
                    arrayOps = Predef$.MODULE$.refArrayOps((Object[])new String[]{path});
                } else {
                    org.apache.hadoop.fs.FileSystem fs = org.apache.hadoop.fs.FileSystem.get((URI)uri, (Configuration)this.hadoopConf$2);
                    arrayOps = Predef$.MODULE$.refArrayOps((Object[])Option$.MODULE$.apply((Object)fs.globStatus(new Path(uri))).map((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final String[] apply(org.apache.hadoop.fs.FileStatus[] status) {
                            return (String[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])status).filter((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;

                                public final boolean apply(org.apache.hadoop.fs.FileStatus x$6) {
                                    return x$6.isFile();
                                }
                            })).map((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;

                                public final String apply(org.apache.hadoop.fs.FileStatus x$7) {
                                    return x$7.getPath().toUri().toString();
                                }
                            }, scala.Array$.MODULE$.canBuildFrom(scala.reflect.ClassTag$.MODULE$.apply(String.class)));
                        }
                    }).getOrElse((Function0)new Serializable(this, path){
                        public static final long serialVersionUID = 0L;
                        private final String path$1;

                        public final String[] apply() {
                            return new String[]{this.path$1};
                        }
                        {
                            this.path$1 = path$1;
                        }
                    }));
                }
                return arrayOps;
            }
            {
                this.hadoopConf$2 = hadoopConf$2;
            }
        }, Seq$.MODULE$.canBuildFrom())).mkString(",");
    }

    private DependencyUtils$() {
        MODULE$ = this;
    }
}

