/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.Docker$$anonfun
 *  org.apache.spark.deploy.Docker$$anonfun$getLastProcessId
 *  org.apache.spark.deploy.Docker$$anonfun$makeRunCmd
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function1
 *  scala.Predef$
 *  scala.Serializable
 *  scala.collection.Seq
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.runtime.ObjectRef
 *  scala.sys.process.ProcessBuilder
 *  scala.sys.process.ProcessLogger
 *  scala.sys.process.ProcessLogger$
 *  scala.sys.process.package$
 */
package org.apache.spark.deploy;

import org.apache.spark.deploy.Docker$;
import org.apache.spark.deploy.DockerId;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function1;
import scala.Predef$;
import scala.Serializable;
import scala.collection.Seq;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.runtime.ObjectRef;
import scala.sys.process.ProcessBuilder;
import scala.sys.process.ProcessLogger;
import scala.sys.process.ProcessLogger$;
import scala.sys.process.package$;

public final class Docker$
implements Logging {
    public static final Docker$ MODULE$;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.deploy.Docker$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public ProcessBuilder makeRunCmd(String imageTag, String args, String mountDir) {
        block2 : {
            var5_4 = "";
            if (mountDir != null) break block2;
            if (var5_4 == null) ** GOTO lbl-1000
            ** GOTO lbl-1000
        }
        if (v0.equals(var5_4)) lbl-1000: // 2 sources:
        {
            v1 = "";
        } else lbl-1000: // 2 sources:
        {
            v1 = new StringBuilder().append((Object)" -v ").append((Object)mountDir).toString();
        }
        mountCmd = v1;
        cmd = new StringOps(Predef$.MODULE$.augmentString("docker run -privileged %s %s %s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{mountCmd, imageTag, args}));
        this.logDebug((Function0<String>)new Serializable(cmd){
            public static final long serialVersionUID = 0L;
            private final String cmd$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Run command: ").append((Object)this.cmd$1).toString();
            }
            {
                this.cmd$1 = cmd$1;
            }
        });
        return package$.MODULE$.stringToProcess(cmd);
    }

    public String makeRunCmd$default$2() {
        return "";
    }

    public String makeRunCmd$default$3() {
        return "";
    }

    public void kill(DockerId dockerId) {
        package$.MODULE$.stringToProcess(new StringOps(Predef$.MODULE$.augmentString("docker kill %s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{dockerId.id()}))).$bang();
    }

    public DockerId getLastProcessId() {
        ObjectRef id = ObjectRef.create(null);
        package$.MODULE$.stringToProcess("docker ps -l -q").$bang(ProcessLogger$.MODULE$.apply((Function1)new Serializable(id){
            public static final long serialVersionUID = 0L;
            private final ObjectRef id$1;

            public final void apply(String line) {
                this.id$1.elem = line;
            }
            {
                this.id$1 = id$1;
            }
        }));
        return new DockerId((String)id.elem);
    }

    private Docker$() {
        MODULE$ = this;
        Logging$class.$init$(this);
    }
}

