/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple5
 *  scala.runtime.AbstractFunction5
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy;

import org.apache.spark.deploy.OptionAssigner;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple5;
import scala.runtime.AbstractFunction5;
import scala.runtime.BoxesRunTime;

public final class OptionAssigner$
extends AbstractFunction5<String, Object, Object, String, String, OptionAssigner>
implements Serializable {
    public static final OptionAssigner$ MODULE$;

    public static {
        new org.apache.spark.deploy.OptionAssigner$();
    }

    public final String toString() {
        return "OptionAssigner";
    }

    public OptionAssigner apply(String value2, int clusterManager, int deployMode2, String clOption, String confKey) {
        return new OptionAssigner(value2, clusterManager, deployMode2, clOption, confKey);
    }

    public Option<Tuple5<String, Object, Object, String, String>> unapply(OptionAssigner x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple5((Object)x$0.value(), (Object)BoxesRunTime.boxToInteger((int)x$0.clusterManager()), (Object)BoxesRunTime.boxToInteger((int)x$0.deployMode()), (Object)x$0.clOption(), (Object)x$0.confKey()));
    }

    public String apply$default$4() {
        return null;
    }

    public String apply$default$5() {
        return null;
    }

    public String $lessinit$greater$default$4() {
        return null;
    }

    public String $lessinit$greater$default$5() {
        return null;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private OptionAssigner$() {
        MODULE$ = this;
    }
}

