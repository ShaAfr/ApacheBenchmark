/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.CleanShuffle;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;
import scala.runtime.BoxesRunTime;

public final class CleanShuffle$
extends AbstractFunction1<Object, CleanShuffle>
implements Serializable {
    public static final CleanShuffle$ MODULE$;

    public static {
        new org.apache.spark.CleanShuffle$();
    }

    public final String toString() {
        return "CleanShuffle";
    }

    public CleanShuffle apply(int shuffleId) {
        return new CleanShuffle(shuffleId);
    }

    public Option<Object> unapply(CleanShuffle x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)BoxesRunTime.boxToInteger((int)x$0.shuffleId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private CleanShuffle$() {
        MODULE$ = this;
    }
}

