/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.RangePartitioner$$anonfun
 *  scala.Array$
 *  scala.Function1
 *  scala.Function2
 *  scala.MatchError
 *  scala.Option
 *  scala.Option$
 *  scala.Predef$
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.Tuple3
 *  scala.collection.GenTraversable
 *  scala.collection.Iterator
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.mutable.ArrayBuffer
 *  scala.collection.mutable.ArrayBuffer$
 *  scala.collection.mutable.ArrayOps
 *  scala.math.Numeric
 *  scala.math.Numeric$DoubleIsFractional$
 *  scala.math.Numeric$LongIsIntegral$
 *  scala.math.Ordering
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.RangePartitioner$;
import org.apache.spark.rdd.RDD;
import scala.Array$;
import scala.Function1;
import scala.Function2;
import scala.MatchError;
import scala.Option;
import scala.Option$;
import scala.Predef$;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.Tuple3;
import scala.collection.GenTraversable;
import scala.collection.Iterator;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.mutable.ArrayBuffer;
import scala.collection.mutable.ArrayBuffer$;
import scala.collection.mutable.ArrayOps;
import scala.math.Numeric;
import scala.math.Ordering;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.BoxesRunTime;

public final class RangePartitioner$
implements Serializable {
    public static final RangePartitioner$ MODULE$;

    public static {
        new org.apache.spark.RangePartitioner$();
    }

    public <K> Tuple2<Object, Tuple3<Object, Object, Object>[]> sketch(RDD<K> rdd, int sampleSizePerPartition, ClassTag<K> evidence$5) {
        int shift = rdd.id();
        Tuple3[] sketched = (Tuple3[])rdd.mapPartitionsWithIndex(new Serializable(sampleSizePerPartition, evidence$5, shift){
            public static final long serialVersionUID = 0L;
            private final int sampleSizePerPartition$2;
            private final ClassTag evidence$5$1;
            private final int shift$1;

            public final Iterator<Tuple3<Object, Object, Object>> apply(int idx, Iterator<K> iter) {
                int seed = scala.util.hashing.package$.MODULE$.byteswap32(idx ^ this.shift$1 << 16);
                Tuple2<Object, Object> tuple2 = org.apache.spark.util.random.SamplingUtils$.MODULE$.reservoirSampleAndCount(iter, this.sampleSizePerPartition$2, seed, this.evidence$5$1);
                if (tuple2 != null) {
                    Tuple2 tuple22;
                    Object sample2 = tuple2._1();
                    long n = tuple2._2$mcJ$sp();
                    Tuple2 tuple23 = tuple22 = new Tuple2(sample2, (Object)BoxesRunTime.boxToLong((long)n));
                    Object sample3 = tuple23._1();
                    long n2 = tuple23._2$mcJ$sp();
                    return scala.package$.MODULE$.Iterator().apply((scala.collection.Seq)Predef$.MODULE$.wrapRefArray((Object[])new Tuple3[]{new Tuple3((Object)BoxesRunTime.boxToInteger((int)idx), (Object)BoxesRunTime.boxToLong((long)n2), sample3)}));
                }
                throw new MatchError(tuple2);
            }
            {
                this.sampleSizePerPartition$2 = sampleSizePerPartition$2;
                this.evidence$5$1 = evidence$5$1;
                this.shift$1 = shift$1;
            }
        }, rdd.mapPartitionsWithIndex$default$2(), ClassTag$.MODULE$.apply(Tuple3.class)).collect();
        long numItems = BoxesRunTime.unboxToLong((Object)Predef$.MODULE$.longArrayOps((long[])Predef$.MODULE$.refArrayOps((Object[])sketched).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final long apply(Tuple3<Object, Object, Object> x$10) {
                return BoxesRunTime.unboxToLong((Object)x$10._2());
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Long()))).sum((Numeric)Numeric.LongIsIntegral$.MODULE$));
        return new Tuple2((Object)BoxesRunTime.boxToLong((long)numItems), (Object)sketched);
    }

    public <K> Object determineBounds(ArrayBuffer<Tuple2<K, Object>> candidates, int partitions2, Ordering<K> evidence$6, ClassTag<K> evidence$7) {
        Ordering ordering = (Ordering)Predef$.MODULE$.implicitly(evidence$6);
        ArrayBuffer ordered = (ArrayBuffer)candidates.sortBy((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final K apply(Tuple2<K, Object> x$11) {
                return (K)x$11._1();
            }
        }, evidence$6);
        int numCandidates = ordered.size();
        double sumWeights = BoxesRunTime.unboxToDouble((Object)((TraversableOnce)ordered.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final double apply(Tuple2<K, Object> x$12) {
                return BoxesRunTime.unboxToFloat((Object)x$12._2());
            }
        }, ArrayBuffer$.MODULE$.canBuildFrom())).sum((Numeric)Numeric.DoubleIsFractional$.MODULE$));
        double step = sumWeights / (double)partitions2;
        double cumWeight = 0.0;
        double target = step;
        ArrayBuffer bounds = (ArrayBuffer)ArrayBuffer$.MODULE$.empty();
        int j = 0;
        Option previousBound = Option$.MODULE$.empty();
        for (int i = 0; i < numCandidates && j < partitions2 - 1; ++i) {
            Tuple2 tuple2 = (Tuple2)ordered.apply(i);
            if (tuple2 != null) {
                Tuple2 tuple22;
                Object key = tuple2._1();
                float weight = BoxesRunTime.unboxToFloat((Object)tuple2._2());
                Tuple2 tuple23 = tuple22 = new Tuple2(key, (Object)BoxesRunTime.boxToFloat((float)weight));
                Object key2 = tuple23._1();
                float weight2 = BoxesRunTime.unboxToFloat((Object)tuple23._2());
                if (!((cumWeight += (double)weight2) >= target) || !previousBound.isEmpty() && !ordering.gt(key2, previousBound.get())) continue;
                bounds.$plus$eq(key2);
                target += step;
                ++j;
                previousBound = new Some(key2);
                continue;
            }
            throw new MatchError((Object)tuple2);
        }
        return bounds.toArray(evidence$7);
    }

    public <K, V> boolean $lessinit$greater$default$3() {
        return true;
    }

    public <K, V> int $lessinit$greater$default$4() {
        return 20;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private RangePartitioner$() {
        MODULE$ = this;
    }
}

