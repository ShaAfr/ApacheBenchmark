/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.curator.framework.CuratorFramework
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$getMasterUrls
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$addMasters
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$addWorkers
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$createClient
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$killLeader
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$stateValid
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$stateValid$1
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$$terminateCluster
 *  org.apache.spark.deploy.FaultToleranceTest$$anonfun$test
 *  org.apache.spark.deploy.FaultToleranceTest$delayedInit
 *  org.slf4j.Logger
 *  scala.App
 *  scala.App$class
 *  scala.Function0
 *  scala.Function1
 *  scala.Predef$
 *  scala.Serializable
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.generic.TraversableForwarder
 *  scala.collection.immutable.Nil$
 *  scala.collection.immutable.Range
 *  scala.collection.immutable.Range$Inclusive
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.Buffer
 *  scala.collection.mutable.BufferLike
 *  scala.collection.mutable.ListBuffer
 *  scala.collection.mutable.ListBuffer$
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.concurrent.Awaitable
 *  scala.concurrent.ExecutionContext
 *  scala.concurrent.ExecutionContext$Implicits$
 *  scala.concurrent.ExecutionContextExecutor
 *  scala.concurrent.Future
 *  scala.concurrent.Future$
 *  scala.concurrent.duration.Duration
 *  scala.concurrent.duration.FiniteDuration
 *  scala.concurrent.duration.package
 *  scala.concurrent.duration.package$
 *  scala.concurrent.duration.package$DurationInt
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.IntRef
 *  scala.runtime.Nothing$
 *  scala.runtime.ObjectRef
 *  scala.runtime.RichInt$
 *  scala.sys.package$
 */
package org.apache.spark.deploy;

import java.util.concurrent.TimeoutException;
import org.apache.curator.framework.CuratorFramework;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.deploy.FaultToleranceTest;
import org.apache.spark.deploy.FaultToleranceTest$;
import org.apache.spark.deploy.FaultToleranceTest$$anonfun$org$apache$spark$deploy$FaultToleranceTest$;
import org.apache.spark.deploy.SparkCuratorUtil$;
import org.apache.spark.deploy.TestMasterInfo;
import org.apache.spark.deploy.TestWorkerInfo;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.util.ThreadUtils$;
import org.slf4j.Logger;
import scala.App;
import scala.Function0;
import scala.Function1;
import scala.Predef$;
import scala.Serializable;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.generic.TraversableForwarder;
import scala.collection.immutable.Nil$;
import scala.collection.immutable.Range;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.Buffer;
import scala.collection.mutable.BufferLike;
import scala.collection.mutable.ListBuffer;
import scala.collection.mutable.ListBuffer$;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.concurrent.Awaitable;
import scala.concurrent.ExecutionContext;
import scala.concurrent.ExecutionContextExecutor;
import scala.concurrent.Future;
import scala.concurrent.Future$;
import scala.concurrent.duration.Duration;
import scala.concurrent.duration.FiniteDuration;
import scala.concurrent.duration.package;
import scala.concurrent.duration.package$;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.runtime.IntRef;
import scala.runtime.Nothing$;
import scala.runtime.ObjectRef;
import scala.runtime.RichInt$;

public final class FaultToleranceTest$
implements App,
Logging {
    public static final FaultToleranceTest$ MODULE$;
    private final SparkConf conf;
    private final String ZK_DIR;
    private final ListBuffer<TestMasterInfo> org$apache$spark$deploy$FaultToleranceTest$$masters;
    private final ListBuffer<TestWorkerInfo> org$apache$spark$deploy$FaultToleranceTest$$workers;
    private SparkContext org$apache$spark$deploy$FaultToleranceTest$$sc;
    private final CuratorFramework zk;
    private int org$apache$spark$deploy$FaultToleranceTest$$numPassed;
    private int org$apache$spark$deploy$FaultToleranceTest$$numFailed;
    private final String sparkHome;
    private final String containerSparkHome;
    private final String org$apache$spark$deploy$FaultToleranceTest$$dockerMountDir;
    private transient Logger org$apache$spark$internal$Logging$$log_;
    private final long executionStart;
    private String[] scala$App$$_args;
    private final ListBuffer<Function0<BoxedUnit>> scala$App$$initCode;

    public static {
        new org.apache.spark.deploy.FaultToleranceTest$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public long executionStart() {
        return this.executionStart;
    }

    public String[] scala$App$$_args() {
        return this.scala$App$$_args;
    }

    public void scala$App$$_args_$eq(String[] x$1) {
        this.scala$App$$_args = x$1;
    }

    public ListBuffer<Function0<BoxedUnit>> scala$App$$initCode() {
        return this.scala$App$$initCode;
    }

    public void scala$App$_setter_$executionStart_$eq(long x$1) {
        this.executionStart = x$1;
    }

    public void scala$App$_setter_$scala$App$$initCode_$eq(ListBuffer x$1) {
        this.scala$App$$initCode = x$1;
    }

    public String[] args() {
        return App.class.args((App)this);
    }

    public void delayedInit(Function0<BoxedUnit> body2) {
        App.class.delayedInit((App)this, body2);
    }

    public void main(String[] args) {
        App.class.main((App)this, (String[])args);
    }

    private SparkConf conf() {
        return this.conf;
    }

    private String ZK_DIR() {
        return this.ZK_DIR;
    }

    public ListBuffer<TestMasterInfo> org$apache$spark$deploy$FaultToleranceTest$$masters() {
        return this.org$apache$spark$deploy$FaultToleranceTest$$masters;
    }

    public ListBuffer<TestWorkerInfo> org$apache$spark$deploy$FaultToleranceTest$$workers() {
        return this.org$apache$spark$deploy$FaultToleranceTest$$workers;
    }

    public SparkContext org$apache$spark$deploy$FaultToleranceTest$$sc() {
        return this.org$apache$spark$deploy$FaultToleranceTest$$sc;
    }

    private void org$apache$spark$deploy$FaultToleranceTest$$sc_$eq(SparkContext x$1) {
        this.org$apache$spark$deploy$FaultToleranceTest$$sc = x$1;
    }

    private CuratorFramework zk() {
        return this.zk;
    }

    public int org$apache$spark$deploy$FaultToleranceTest$$numPassed() {
        return this.org$apache$spark$deploy$FaultToleranceTest$$numPassed;
    }

    private void org$apache$spark$deploy$FaultToleranceTest$$numPassed_$eq(int x$1) {
        this.org$apache$spark$deploy$FaultToleranceTest$$numPassed = x$1;
    }

    public int org$apache$spark$deploy$FaultToleranceTest$$numFailed() {
        return this.org$apache$spark$deploy$FaultToleranceTest$$numFailed;
    }

    private void org$apache$spark$deploy$FaultToleranceTest$$numFailed_$eq(int x$1) {
        this.org$apache$spark$deploy$FaultToleranceTest$$numFailed = x$1;
    }

    private String sparkHome() {
        return this.sparkHome;
    }

    private String containerSparkHome() {
        return this.containerSparkHome;
    }

    public String org$apache$spark$deploy$FaultToleranceTest$$dockerMountDir() {
        return this.org$apache$spark$deploy$FaultToleranceTest$$dockerMountDir;
    }

    private void afterEach() {
        if (this.org$apache$spark$deploy$FaultToleranceTest$$sc() != null) {
            this.org$apache$spark$deploy$FaultToleranceTest$$sc().stop();
            this.org$apache$spark$deploy$FaultToleranceTest$$sc_$eq(null);
        }
        this.org$apache$spark$deploy$FaultToleranceTest$$terminateCluster();
        SparkCuratorUtil$.MODULE$.deleteRecursive(this.zk(), new StringBuilder().append((Object)this.ZK_DIR()).append((Object)"/spark_leader").toString());
        SparkCuratorUtil$.MODULE$.deleteRecursive(this.zk(), new StringBuilder().append((Object)this.ZK_DIR()).append((Object)"/master_status").toString());
    }

    private void test(String name2, Function0<BoxedUnit> fn2) {
        try {
            fn2.apply$mcV$sp();
            this.org$apache$spark$deploy$FaultToleranceTest$$numPassed_$eq(this.org$apache$spark$deploy$FaultToleranceTest$$numPassed() + 1);
            this.logInfo((Function0<String>)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "==============================================";
                }
            });
            this.logInfo((Function0<String>)new Serializable(name2){
                public static final long serialVersionUID = 0L;
                private final String name$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"Passed: ").append((Object)this.name$1).toString();
                }
                {
                    this.name$1 = name$1;
                }
            });
            this.logInfo((Function0<String>)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "==============================================";
                }
            });
            this.afterEach();
            return;
        }
        catch (Exception exception2) {
            this.org$apache$spark$deploy$FaultToleranceTest$$numFailed_$eq(this.org$apache$spark$deploy$FaultToleranceTest$$numFailed() + 1);
            this.logInfo((Function0<String>)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
                }
            });
            this.logError((Function0<String>)new Serializable(name2){
                public static final long serialVersionUID = 0L;
                private final String name$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"FAILED: ").append((Object)this.name$1).toString();
                }
                {
                    this.name$1 = name$1;
                }
            }, exception2);
            this.logInfo((Function0<String>)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
                }
            });
            throw scala.sys.package$.MODULE$.exit(1);
        }
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$addMasters(int num) {
        this.logInfo((Function0<String>)new Serializable(num){
            public static final long serialVersionUID = 0L;
            private final int num$1;

            public final String apply() {
                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{">>>>> ADD MASTERS ", " <<<<<"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.num$1)}));
            }
            {
                this.num$1 = num$1;
            }
        });
        RichInt$.MODULE$.to$extension0(Predef$.MODULE$.intWrapper(1), num).foreach((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final ListBuffer<TestMasterInfo> apply(int x$3) {
                return FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$masters().$plus$eq((Object)org.apache.spark.deploy.SparkDocker$.MODULE$.startMaster(FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$dockerMountDir()));
            }
        });
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$addWorkers(int num) {
        this.logInfo((Function0<String>)new Serializable(num){
            public static final long serialVersionUID = 0L;
            private final int num$2;

            public final String apply() {
                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{">>>>> ADD WORKERS ", " <<<<<"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.num$2)}));
            }
            {
                this.num$2 = num$2;
            }
        });
        String masterUrls = this.getMasterUrls((Seq<TestMasterInfo>)this.org$apache$spark$deploy$FaultToleranceTest$$masters());
        RichInt$.MODULE$.to$extension0(Predef$.MODULE$.intWrapper(1), num).foreach((Function1)new Serializable(masterUrls){
            public static final long serialVersionUID = 0L;
            private final String masterUrls$1;

            public final ListBuffer<TestWorkerInfo> apply(int x$4) {
                return FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$workers().$plus$eq((Object)org.apache.spark.deploy.SparkDocker$.MODULE$.startWorker(FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$dockerMountDir(), this.masterUrls$1));
            }
            {
                this.masterUrls$1 = masterUrls$1;
            }
        });
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$createClient() {
        this.logInfo((Function0<String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return ">>>>> CREATE CLIENT <<<<<";
            }
        });
        if (this.org$apache$spark$deploy$FaultToleranceTest$$sc() != null) {
            this.org$apache$spark$deploy$FaultToleranceTest$$sc().stop();
        }
        System.setProperty("spark.driver.port", "0");
        this.org$apache$spark$deploy$FaultToleranceTest$$sc_$eq(new SparkContext(this.getMasterUrls((Seq<TestMasterInfo>)this.org$apache$spark$deploy$FaultToleranceTest$$masters()), "fault-tolerance", this.containerSparkHome()));
    }

    private String getMasterUrls(Seq<TestMasterInfo> masters) {
        return new StringBuilder().append((Object)"spark://").append((Object)((TraversableOnce)masters.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(TestMasterInfo master) {
                return new StringBuilder().append((Object)master.ip()).append((Object)":7077").toString();
            }
        }, Seq$.MODULE$.canBuildFrom())).mkString(",")).toString();
    }

    public TestMasterInfo org$apache$spark$deploy$FaultToleranceTest$$getLeader() {
        ListBuffer leaders = (ListBuffer)this.org$apache$spark$deploy$FaultToleranceTest$$masters().filter((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(TestMasterInfo x$5) {
                scala.Enumeration$Value value2 = org.apache.spark.deploy.master.RecoveryState$.MODULE$.ALIVE();
                if (x$5.state() != null) {
                    scala.Enumeration$Value value3;
                    if (!value3.equals((Object)value2)) return false;
                    return true;
                }
                if (value2 == null) return true;
                return false;
            }
        });
        this.org$apache$spark$deploy$FaultToleranceTest$$assertTrue(leaders.size() == 1, this.org$apache$spark$deploy$FaultToleranceTest$$assertTrue$default$2());
        return (TestMasterInfo)leaders.apply(0);
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$killLeader() {
        this.logInfo((Function0<String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return ">>>>> KILL LEADER <<<<<";
            }
        });
        this.org$apache$spark$deploy$FaultToleranceTest$$masters().foreach((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply(TestMasterInfo x$6) {
                x$6.readState();
            }
        });
        TestMasterInfo leader = this.org$apache$spark$deploy$FaultToleranceTest$$getLeader();
        this.org$apache$spark$deploy$FaultToleranceTest$$masters().$minus$eq((Object)leader);
        leader.kill();
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$delay(Duration secs) {
        Thread.sleep(secs.toMillis());
    }

    public Duration org$apache$spark$deploy$FaultToleranceTest$$delay$default$1() {
        return new package.DurationInt(package$.MODULE$.DurationInt(5)).seconds();
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$terminateCluster() {
        this.logInfo((Function0<String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return ">>>>> TERMINATE CLUSTER <<<<<";
            }
        });
        this.org$apache$spark$deploy$FaultToleranceTest$$masters().foreach((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply(TestMasterInfo x$7) {
                x$7.kill();
            }
        });
        this.org$apache$spark$deploy$FaultToleranceTest$$workers().foreach((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply(TestWorkerInfo x$8) {
                x$8.kill();
            }
        });
        this.org$apache$spark$deploy$FaultToleranceTest$$masters().clear();
        this.org$apache$spark$deploy$FaultToleranceTest$$workers().clear();
    }

    private void assertUsable() {
        Future f = Future$.MODULE$.apply((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply() {
                return this.apply$mcZ$sp();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            public boolean apply$mcZ$sp() {
                try {
                    block4 : {
                        qual$1 = FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$sc();
                        x$15 = RichInt$.MODULE$.until$extension0(Predef$.MODULE$.intWrapper(0), 10);
                        x$16 = qual$1.parallelize$default$2();
                        res = (int[])qual$1.parallelize(x$15, x$16, scala.reflect.ClassTag$.MODULE$.Int()).collect();
                        var6_5 = RichInt$.MODULE$.until$extension0(Predef$.MODULE$.intWrapper(0), 10).toList();
                        if (Predef$.MODULE$.intArrayOps(res).toList() != null) break block4;
                        if (var6_5 == null) ** GOTO lbl-1000
                        ** GOTO lbl-1000
                    }
                    if (v0.equals((Object)var6_5)) lbl-1000: // 2 sources:
                    {
                        v1 = true;
                    } else lbl-1000: // 2 sources:
                    {
                        v1 = false;
                    }
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertTrue(v1, FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertTrue$default$2());
                    return true;
                }
                catch (Exception var1_6) {
                    FaultToleranceTest$.MODULE$.logError((Function0<String>)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final String apply() {
                            return "assertUsable() had exception";
                        }
                    }, var1_6);
                    var1_6.printStackTrace();
                    return false;
                }
            }
        }, (ExecutionContext)ExecutionContext.Implicits$.MODULE$.global());
        this.org$apache$spark$deploy$FaultToleranceTest$$assertTrue(BoxesRunTime.unboxToBoolean(ThreadUtils$.MODULE$.awaitResult(f, (Duration)new package.DurationInt(package$.MODULE$.DurationInt(120)).seconds())), this.org$apache$spark$deploy$FaultToleranceTest$$assertTrue$default$2());
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState() {
        this.logInfo((Function0<String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return ">>>>> ASSERT VALID CLUSTER STATE <<<<<";
            }
        });
        this.assertUsable();
        IntRef numAlive = IntRef.create((int)0);
        IntRef numStandby = IntRef.create((int)0);
        IntRef numLiveApps = IntRef.create((int)0);
        ObjectRef liveWorkerIPs = ObjectRef.create((Object)Nil$.MODULE$);
        Future f = Future$.MODULE$.apply((Function0)new Serializable(numAlive, numStandby, numLiveApps, liveWorkerIPs){
            public static final long serialVersionUID = 0L;
            public final IntRef numAlive$1;
            public final IntRef numStandby$1;
            public final IntRef numLiveApps$1;
            public final ObjectRef liveWorkerIPs$1;

            public final boolean apply() {
                return this.apply$mcZ$sp();
            }

            public boolean apply$mcZ$sp() {
                boolean bl;
                try {
                    do {
                        if (FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$stateValid$1(this.numAlive$1, this.numStandby$1, this.numLiveApps$1, this.liveWorkerIPs$1)) {
                            bl = true;
                            break;
                        }
                        Thread.sleep(1000L);
                        this.numAlive$1.elem = 0;
                        this.numStandby$1.elem = 0;
                        this.numLiveApps$1.elem = 0;
                        FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$masters().foreach((Function1)new Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final void apply(TestMasterInfo x$10) {
                                x$10.readState();
                            }
                        });
                        FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$masters().foreach((Function1)new Serializable(this){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ anonfun.9 $outer;

                            /*
                             * Unable to fully structure code
                             * Enabled aggressive block sorting
                             * Lifted jumps to return sites
                             */
                            public final void apply(TestMasterInfo master) {
                                block5 : {
                                    block6 : {
                                        block4 : {
                                            block3 : {
                                                block2 : {
                                                    var2_2 = master.state();
                                                    var3_3 = var2_2;
                                                    if (org.apache.spark.deploy.master.RecoveryState$.MODULE$.ALIVE() != null) break block2;
                                                    if (var3_3 == null) break block3;
                                                    break block4;
                                                }
                                                if (!v0.equals((Object)var3_3)) break block4;
                                            }
                                            ++this.$outer.numAlive$1.elem;
                                            this.$outer.liveWorkerIPs$1.elem = master.liveWorkerIPs();
                                            var4_4 = BoxedUnit.UNIT;
                                            break block5;
                                        }
                                        var5_7 = var2_2;
                                        if (org.apache.spark.deploy.master.RecoveryState$.MODULE$.STANDBY() != null) break block6;
                                        if (var5_7 == null) ** GOTO lbl-1000
                                        ** GOTO lbl-1000
                                    }
                                    if (v1.equals((Object)var5_7)) lbl-1000: // 2 sources:
                                    {
                                        ++this.$outer.numStandby$1.elem;
                                        var4_5 = BoxedUnit.UNIT;
                                    } else lbl-1000: // 2 sources:
                                    {
                                        var4_6 = BoxedUnit.UNIT;
                                    }
                                }
                                this.$outer.numLiveApps$1.elem += master.numLiveApps();
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                            }
                        });
                    } while (true);
                }
                catch (Exception exception2) {
                    FaultToleranceTest$.MODULE$.logError((Function0<String>)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final String apply() {
                            return "assertValidClusterState() had exception";
                        }
                    }, exception2);
                    bl = false;
                }
                return bl;
            }
            {
                this.numAlive$1 = numAlive$1;
                this.numStandby$1 = numStandby$1;
                this.numLiveApps$1 = numLiveApps$1;
                this.liveWorkerIPs$1 = liveWorkerIPs$1;
            }
        }, (ExecutionContext)ExecutionContext.Implicits$.MODULE$.global());
        try {
            this.org$apache$spark$deploy$FaultToleranceTest$$assertTrue(BoxesRunTime.unboxToBoolean(ThreadUtils$.MODULE$.awaitResult(f, (Duration)new package.DurationInt(package$.MODULE$.DurationInt(120)).seconds())), this.org$apache$spark$deploy$FaultToleranceTest$$assertTrue$default$2());
            return;
        }
        catch (TimeoutException timeoutException) {
            this.logError((Function0<String>)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return new StringBuilder().append((Object)"Master states: ").append(FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$masters().map((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final scala.Enumeration$Value apply(TestMasterInfo x$11) {
                            return x$11.state();
                        }
                    }, ListBuffer$.MODULE$.canBuildFrom())).toString();
                }
            });
            this.logError((Function0<String>)new Serializable(numLiveApps){
                public static final long serialVersionUID = 0L;
                private final IntRef numLiveApps$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"Num apps: ").append((Object)BoxesRunTime.boxToInteger((int)this.numLiveApps$1.elem)).toString();
                }
                {
                    this.numLiveApps$1 = numLiveApps$1;
                }
            });
            this.logError((Function0<String>)new Serializable(liveWorkerIPs){
                public static final long serialVersionUID = 0L;
                private final ObjectRef liveWorkerIPs$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"IPs expected: ").append(FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$workers().map((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final String apply(TestWorkerInfo x$12) {
                            return x$12.ip();
                        }
                    }, ListBuffer$.MODULE$.canBuildFrom())).append((Object)" / found: ").append((Object)((Seq)this.liveWorkerIPs$1.elem)).toString();
                }
                {
                    this.liveWorkerIPs$1 = liveWorkerIPs$1;
                }
            });
            throw new RuntimeException("Failed to get into acceptable cluster state after 2 min.", timeoutException);
        }
    }

    public void org$apache$spark$deploy$FaultToleranceTest$$assertTrue(boolean bool, String message) {
        if (bool) {
            return;
        }
        throw new IllegalStateException(new StringBuilder().append((Object)"Assertion failed: ").append((Object)message).toString());
    }

    public String org$apache$spark$deploy$FaultToleranceTest$$assertTrue$default$2() {
        return "";
    }

    public final boolean org$apache$spark$deploy$FaultToleranceTest$$stateValid$1(IntRef numAlive$1, IntRef numStandby$1, IntRef numLiveApps$1, ObjectRef liveWorkerIPs$1) {
        return ((TraversableForwarder)((BufferLike)this.org$apache$spark$deploy$FaultToleranceTest$$workers().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(TestWorkerInfo x$9) {
                return x$9.ip();
            }
        }, ListBuffer$.MODULE$.canBuildFrom())).$minus$minus((GenTraversableOnce)((Seq)liveWorkerIPs$1.elem))).isEmpty() && numAlive$1.elem == 1 && numStandby$1.elem == this.org$apache$spark$deploy$FaultToleranceTest$$masters().size() - 1 && numLiveApps$1.elem >= 1;
    }

    public final void delayedEndpoint$org$apache$spark$deploy$FaultToleranceTest$1() {
        this.conf = new SparkConf();
        this.ZK_DIR = this.conf().get("spark.deploy.zookeeper.dir", "/spark");
        this.org$apache$spark$deploy$FaultToleranceTest$$masters = (ListBuffer)ListBuffer$.MODULE$.apply((Seq)Nil$.MODULE$);
        this.org$apache$spark$deploy$FaultToleranceTest$$workers = (ListBuffer)ListBuffer$.MODULE$.apply((Seq)Nil$.MODULE$);
        this.zk = SparkCuratorUtil$.MODULE$.newClient(this.conf(), SparkCuratorUtil$.MODULE$.newClient$default$2());
        this.org$apache$spark$deploy$FaultToleranceTest$$numPassed = 0;
        this.org$apache$spark$deploy$FaultToleranceTest$$numFailed = 0;
        this.sparkHome = System.getenv("SPARK_HOME");
        this.org$apache$spark$deploy$FaultToleranceTest$$assertTrue(this.sparkHome() != null, "Run with a valid SPARK_HOME");
        this.containerSparkHome = "/opt/spark";
        this.org$apache$spark$deploy$FaultToleranceTest$$dockerMountDir = new StringOps(Predef$.MODULE$.augmentString("%s:%s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.sparkHome(), this.containerSparkHome()}));
        System.setProperty("spark.driver.host", "172.17.42.1");
        this.test("sanity-basic", (Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(1);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
            }
        });
        this.test("sanity-many-masters", (Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(3);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(3);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
            }
        });
        this.test("single-master-halt", (Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(3);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$killLeader();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay((Duration)new package.DurationInt(package$.MODULE$.DurationInt(30)).seconds());
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
            }
        });
        this.test("single-master-restart", (Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$killLeader();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay((Duration)new package.DurationInt(package$.MODULE$.DurationInt(30)).seconds());
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$killLeader();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay((Duration)new package.DurationInt(package$.MODULE$.DurationInt(30)).seconds());
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
            }
        });
        this.test("cluster-failure", (Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$terminateCluster();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
            }
        });
        this.test("all-but-standby-failure", (Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$killLeader();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$workers().foreach((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final void apply(TestWorkerInfo x$1) {
                        x$1.kill();
                    }
                });
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$workers().clear();
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay((Duration)new package.DurationInt(package$.MODULE$.DurationInt(30)).seconds());
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(2);
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
            }
        });
        this.test("rolling-outage", (Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public void apply$mcV$sp() {
                block2 : {
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay(FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay$default$1());
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay(FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay$default$1());
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addWorkers(2);
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$createClient();
                    FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                    var1_1 = FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$masters().head();
                    if (FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$getLeader() != null) break block2;
                    if (var1_1 == null) ** GOTO lbl-1000
                    ** GOTO lbl-1000
                }
                if (v0.equals(var1_1)) lbl-1000: // 2 sources:
                {
                    v1 = true;
                } else lbl-1000: // 2 sources:
                {
                    v1 = false;
                }
                FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertTrue(v1, FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertTrue$default$2());
                RichInt$.MODULE$.to$extension0(Predef$.MODULE$.intWrapper(1), 3).foreach$mVc$sp((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final void apply(int x$2) {
                        this.apply$mcVI$sp(x$2);
                    }

                    /*
                     * Unable to fully structure code
                     * Enabled aggressive block sorting
                     * Lifted jumps to return sites
                     */
                    public void apply$mcVI$sp(int x$2) {
                        block2 : {
                            FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$killLeader();
                            FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$delay((Duration)new package.DurationInt(package$.MODULE$.DurationInt(30)).seconds());
                            FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertValidClusterState();
                            var2_2 = FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$masters().head();
                            if (FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$getLeader() != null) break block2;
                            if (var2_2 == null) ** GOTO lbl-1000
                            ** GOTO lbl-1000
                        }
                        if (v0.equals(var2_2)) lbl-1000: // 2 sources:
                        {
                            v1 = true;
                        } else lbl-1000: // 2 sources:
                        {
                            v1 = false;
                        }
                        FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertTrue(v1, FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$assertTrue$default$2());
                        FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$addMasters(1);
                    }
                });
            }
        });
        this.logInfo((Function0<String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return new StringOps(Predef$.MODULE$.augmentString("Ran %s tests, %s passed and %s failed")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)(FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$numPassed() + FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$numFailed())), BoxesRunTime.boxToInteger((int)FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$numPassed()), BoxesRunTime.boxToInteger((int)FaultToleranceTest$.MODULE$.org$apache$spark$deploy$FaultToleranceTest$$numFailed())}));
            }
        });
    }

    private FaultToleranceTest$() {
        MODULE$ = this;
        App.class.$init$((App)this);
        Logging$class.$init$(this);
        this.delayedInit((Function0<BoxedUnit>)new FaultToleranceTest.delayedInit.body(this));
    }
}

