/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.AskPermissionToCommitOutput;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;
import scala.runtime.BoxesRunTime;

public final class AskPermissionToCommitOutput$
extends AbstractFunction3<Object, Object, Object, AskPermissionToCommitOutput>
implements Serializable {
    public static final AskPermissionToCommitOutput$ MODULE$;

    public static {
        new org.apache.spark.scheduler.AskPermissionToCommitOutput$();
    }

    public final String toString() {
        return "AskPermissionToCommitOutput";
    }

    public AskPermissionToCommitOutput apply(int stage, int partition2, int attemptNumber) {
        return new AskPermissionToCommitOutput(stage, partition2, attemptNumber);
    }

    public Option<Tuple3<Object, Object, Object>> unapply(AskPermissionToCommitOutput x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)BoxesRunTime.boxToInteger((int)x$0.stage()), (Object)BoxesRunTime.boxToInteger((int)x$0.partition()), (Object)BoxesRunTime.boxToInteger((int)x$0.attemptNumber())));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private AskPermissionToCommitOutput$() {
        MODULE$ = this;
    }
}

