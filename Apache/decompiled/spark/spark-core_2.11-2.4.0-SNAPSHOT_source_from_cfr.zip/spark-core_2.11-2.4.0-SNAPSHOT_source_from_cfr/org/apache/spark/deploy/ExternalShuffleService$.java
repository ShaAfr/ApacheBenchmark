/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.ExternalShuffleService$$anonfun
 *  org.apache.spark.deploy.ExternalShuffleService$$anonfun$main
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function2
 *  scala.Option
 *  scala.Serializable
 *  scala.runtime.BoxedUnit
 */
package org.apache.spark.deploy;

import java.util.concurrent.CountDownLatch;
import org.apache.spark.SecurityManager;
import org.apache.spark.SecurityManager$;
import org.apache.spark.SparkConf;
import org.apache.spark.deploy.ExternalShuffleService;
import org.apache.spark.deploy.ExternalShuffleService$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.util.ShutdownHookManager$;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function2;
import scala.Option;
import scala.Serializable;
import scala.runtime.BoxedUnit;

public final class ExternalShuffleService$
implements Logging {
    public static final ExternalShuffleService$ MODULE$;
    private volatile ExternalShuffleService org$apache$spark$deploy$ExternalShuffleService$$server;
    private final CountDownLatch org$apache$spark$deploy$ExternalShuffleService$$barrier;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.deploy.ExternalShuffleService$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public ExternalShuffleService org$apache$spark$deploy$ExternalShuffleService$$server() {
        return this.org$apache$spark$deploy$ExternalShuffleService$$server;
    }

    private void org$apache$spark$deploy$ExternalShuffleService$$server_$eq(ExternalShuffleService x$1) {
        this.org$apache$spark$deploy$ExternalShuffleService$$server = x$1;
    }

    public CountDownLatch org$apache$spark$deploy$ExternalShuffleService$$barrier() {
        return this.org$apache$spark$deploy$ExternalShuffleService$$barrier;
    }

    public void main(String[] args) {
        this.main(args, (Function2<SparkConf, SecurityManager, ExternalShuffleService>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final ExternalShuffleService apply(SparkConf conf, SecurityManager sm) {
                return new ExternalShuffleService(conf, sm);
            }
        });
    }

    public void main(String[] args, Function2<SparkConf, SecurityManager, ExternalShuffleService> newShuffleService) {
        Utils$.MODULE$.initDaemon(this.log());
        SparkConf sparkConf = new SparkConf();
        Utils$.MODULE$.loadDefaultSparkProperties(sparkConf, Utils$.MODULE$.loadDefaultSparkProperties$default$2());
        SecurityManager securityManager = new SecurityManager(sparkConf, SecurityManager$.MODULE$.$lessinit$greater$default$2());
        sparkConf.set("spark.shuffle.service.enabled", "true");
        this.org$apache$spark$deploy$ExternalShuffleService$$server_$eq((ExternalShuffleService)newShuffleService.apply((Object)sparkConf, (Object)securityManager));
        this.org$apache$spark$deploy$ExternalShuffleService$$server().start();
        this.logDebug((Function0<String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "Adding shutdown hook";
            }
        });
        ShutdownHookManager$.MODULE$.addShutdownHook((Function0<BoxedUnit>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                ExternalShuffleService$.MODULE$.logInfo((Function0<String>)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final String apply() {
                        return "Shutting down shuffle service.";
                    }
                });
                ExternalShuffleService$.MODULE$.org$apache$spark$deploy$ExternalShuffleService$$server().stop();
                ExternalShuffleService$.MODULE$.org$apache$spark$deploy$ExternalShuffleService$$barrier().countDown();
            }
        });
        this.org$apache$spark$deploy$ExternalShuffleService$$barrier().await();
    }

    private ExternalShuffleService$() {
        MODULE$ = this;
        Logging$class.$init$(this);
        this.org$apache$spark$deploy$ExternalShuffleService$$barrier = new CountDownLatch(1);
    }
}

