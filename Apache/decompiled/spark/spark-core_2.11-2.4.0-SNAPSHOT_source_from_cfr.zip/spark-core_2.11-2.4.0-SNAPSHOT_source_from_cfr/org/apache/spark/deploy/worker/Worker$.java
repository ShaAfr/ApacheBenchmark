/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.worker.Worker$$anonfun
 *  org.apache.spark.deploy.worker.Worker$$anonfun$isUseLocalNodeSSLConfig
 *  org.apache.spark.deploy.worker.Worker$$anonfun$main
 *  org.slf4j.Logger
 *  scala.Array$
 *  scala.Function0
 *  scala.Function1
 *  scala.None$
 *  scala.Option
 *  scala.PartialFunction
 *  scala.Predef$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.Tuple2
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Map
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.SeqLike
 *  scala.collection.TraversableLike
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.BoxesRunTime
 *  scala.sys.package$
 *  scala.util.matching.Regex
 */
package org.apache.spark.deploy.worker;

import org.apache.spark.SecurityManager;
import org.apache.spark.SecurityManager$;
import org.apache.spark.SparkConf;
import org.apache.spark.deploy.Command;
import org.apache.spark.deploy.worker.Worker;
import org.apache.spark.deploy.worker.Worker$;
import org.apache.spark.deploy.worker.WorkerArguments;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.rpc.RpcAddress;
import org.apache.spark.rpc.RpcEndpoint;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.rpc.RpcEnv;
import org.apache.spark.rpc.RpcEnv$;
import org.apache.spark.util.SparkUncaughtExceptionHandler;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Array$;
import scala.Function0;
import scala.Function1;
import scala.None$;
import scala.Option;
import scala.PartialFunction;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.Tuple2;
import scala.collection.GenTraversableOnce;
import scala.collection.Map;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.SeqLike;
import scala.collection.TraversableLike;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.BoxesRunTime;
import scala.sys.package$;
import scala.util.matching.Regex;

public final class Worker$
implements Logging {
    public static final Worker$ MODULE$;
    private final String SYSTEM_NAME;
    private final String ENDPOINT_NAME;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.deploy.worker.Worker$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public String SYSTEM_NAME() {
        return this.SYSTEM_NAME;
    }

    public String ENDPOINT_NAME() {
        return this.ENDPOINT_NAME;
    }

    public void main(String[] argStrings) {
        Thread.setDefaultUncaughtExceptionHandler(new SparkUncaughtExceptionHandler(false));
        Utils$.MODULE$.initDaemon(this.log());
        SparkConf conf = new SparkConf();
        WorkerArguments args = new WorkerArguments(argStrings, conf);
        String x$36 = args.host();
        int x$37 = args.port();
        int x$38 = args.webUiPort();
        int x$39 = args.cores();
        int x$40 = args.memory();
        String[] x$41 = args.masters();
        String x$42 = args.workDir();
        SparkConf x$43 = conf;
        Option<Object> x$44 = this.startRpcEnvAndEndpoint$default$8();
        RpcEnv rpcEnv = this.startRpcEnvAndEndpoint(x$36, x$37, x$38, x$39, x$40, x$41, x$42, x$44, x$43);
        boolean externalShuffleServiceEnabled = conf.getBoolean("spark.shuffle.service.enabled", false);
        int sparkWorkerInstances = new StringOps(Predef$.MODULE$.augmentString((String)package$.MODULE$.env().getOrElse((Object)"SPARK_WORKER_INSTANCES", (Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "1";
            }
        }))).toInt();
        Predef$.MODULE$.require(!externalShuffleServiceEnabled || sparkWorkerInstances <= 1, (Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "Starting multiple workers on one host is failed because we may launch no more than one external shuffle service on each host, please set spark.shuffle.service.enabled to false or set SPARK_WORKER_INSTANCES to 1 to resolve the conflict.";
            }
        });
        rpcEnv.awaitTermination();
    }

    public RpcEnv startRpcEnvAndEndpoint(String host, int port, int webUiPort, int cores, int memory, String[] masterUrls, String workDir, Option<Object> workerNumber, SparkConf conf) {
        String systemName = new StringBuilder().append((Object)this.SYSTEM_NAME()).append(workerNumber.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(int x$19) {
                return ((Object)BoxesRunTime.boxToInteger((int)x$19)).toString();
            }
        }).getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "";
            }
        })).toString();
        SecurityManager securityMgr = new SecurityManager(conf, SecurityManager$.MODULE$.$lessinit$greater$default$2());
        RpcEnv rpcEnv = RpcEnv$.MODULE$.create(systemName, host, port, conf, securityMgr, RpcEnv$.MODULE$.create$default$6());
        RpcAddress[] masterAddresses = (RpcAddress[])Predef$.MODULE$.refArrayOps((Object[])masterUrls).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final RpcAddress apply(String x$20) {
                return org.apache.spark.rpc.RpcAddress$.MODULE$.fromSparkURL(x$20);
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.apply(RpcAddress.class)));
        rpcEnv.setupEndpoint(this.ENDPOINT_NAME(), new Worker(rpcEnv, webUiPort, cores, memory, masterAddresses, this.ENDPOINT_NAME(), workDir, conf, securityMgr));
        return rpcEnv;
    }

    public Option<Object> startRpcEnvAndEndpoint$default$8() {
        return None$.MODULE$;
    }

    public SparkConf startRpcEnvAndEndpoint$default$9() {
        return new SparkConf();
    }

    public boolean isUseLocalNodeSSLConfig(Command cmd) {
        Regex pattern = new StringOps(Predef$.MODULE$.augmentString("\\-Dspark\\.ssl\\.useNodeLocalConf\\=(.+)")).r();
        Option result2 = cmd.javaOpts().collectFirst((PartialFunction)new Serializable(pattern){
            public static final long serialVersionUID = 0L;
            private final Regex pattern$1;

            public final <A1 extends String, B1> B1 applyOrElse(A1 x3, Function1<A1, B1> function1) {
                Object object;
                A1 A1 = x3;
                Option option = this.pattern$1.unapplySeq(A1);
                if (!option.isEmpty() && option.get() != null && ((scala.collection.LinearSeqOptimized)option.get()).lengthCompare(1) == 0) {
                    String _result = (String)((scala.collection.LinearSeqOptimized)option.get()).apply(0);
                    object = BoxesRunTime.boxToBoolean((boolean)new StringOps(Predef$.MODULE$.augmentString(_result)).toBoolean());
                } else {
                    object = function1.apply(x3);
                }
                return (B1)object;
            }

            public final boolean isDefinedAt(String x3) {
                String string = x3;
                Option option = this.pattern$1.unapplySeq((java.lang.CharSequence)string);
                boolean bl = !option.isEmpty() && option.get() != null && ((scala.collection.LinearSeqOptimized)option.get()).lengthCompare(1) == 0;
                return bl;
            }
            {
                this.pattern$1 = pattern$1;
            }
        });
        return BoxesRunTime.unboxToBoolean((Object)result2.getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply() {
                return this.apply$mcZ$sp();
            }

            public boolean apply$mcZ$sp() {
                return false;
            }
        }));
    }

    public Command maybeUpdateSSLSettings(Command cmd, SparkConf conf) {
        Command command;
        String prefix = "spark.ssl.";
        String useNLC = "spark.ssl.useNodeLocalConf";
        if (this.isUseLocalNodeSSLConfig(cmd)) {
            Seq newJavaOpts;
            Seq x$45 = newJavaOpts = (Seq)((SeqLike)((TraversableLike)cmd.javaOpts().filter((Function1)new Serializable(prefix){
                public static final long serialVersionUID = 0L;
                private final String prefix$1;

                public final boolean apply(String opt) {
                    return !opt.startsWith(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"-D", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.prefix$1})));
                }
                {
                    this.prefix$1 = prefix$1;
                }
            })).$plus$plus((GenTraversableOnce)Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])conf.getAll()).collect((PartialFunction)new Serializable(prefix){
                public static final long serialVersionUID = 0L;
                private final String prefix$1;

                /*
                 * Enabled aggressive block sorting
                 */
                public final <A1 extends Tuple2<String, String>, B1> B1 applyOrElse(A1 x4, Function1<A1, B1> function1) {
                    Object object;
                    A1 A1 = x4;
                    if (A1 != null) {
                        String key = (String)A1._1();
                        String value2 = (String)A1._2();
                        if (key.startsWith(this.prefix$1)) {
                            object = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"-D", "=", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{key, value2}));
                            return (B1)object;
                        }
                    }
                    object = function1.apply(x4);
                    return (B1)object;
                }

                public final boolean isDefinedAt(Tuple2<String, String> x4) {
                    String key;
                    Tuple2<String, String> tuple2 = x4;
                    boolean bl = tuple2 != null && (key = (String)tuple2._1()).startsWith(this.prefix$1);
                    return bl;
                }
                {
                    this.prefix$1 = prefix$1;
                }
            }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.apply(String.class)))), Seq$.MODULE$.canBuildFrom())).$colon$plus((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"-D", "=true"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{useNLC})), Seq$.MODULE$.canBuildFrom());
            String x$46 = cmd.copy$default$1();
            Seq<String> x$47 = cmd.copy$default$2();
            Map<String, String> x$48 = cmd.copy$default$3();
            Seq<String> x$49 = cmd.copy$default$4();
            Seq<String> x$50 = cmd.copy$default$5();
            command = cmd.copy(x$46, x$47, x$48, x$49, x$50, (Seq<String>)x$45);
        } else {
            command = cmd;
        }
        return command;
    }

    public String $lessinit$greater$default$7() {
        return null;
    }

    private Worker$() {
        MODULE$ = this;
        Logging$class.$init$(this);
        this.SYSTEM_NAME = "sparkWorker";
        this.ENDPOINT_NAME = "Worker";
    }
}

