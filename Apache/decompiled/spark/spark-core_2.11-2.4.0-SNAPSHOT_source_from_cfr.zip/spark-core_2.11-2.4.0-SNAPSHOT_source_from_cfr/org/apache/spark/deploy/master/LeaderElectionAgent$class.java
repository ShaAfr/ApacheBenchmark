/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.deploy.master;

import org.apache.spark.deploy.master.LeaderElectionAgent;

public abstract class LeaderElectionAgent$class {
    public static void stop(LeaderElectionAgent $this) {
    }

    public static void $init$(LeaderElectionAgent $this) {
    }
}

