/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.commons.crypto.random.CryptoRandomFactory
 *  org.apache.commons.crypto.stream.CryptoInputStream
 *  org.apache.commons.crypto.stream.CryptoOutputStream
 *  org.apache.spark.network.util.CryptoUtils
 *  org.apache.spark.network.util.JavaUtils
 *  org.apache.spark.security.CryptoStreamUtils$$anonfun
 *  org.apache.spark.security.CryptoStreamUtils$$anonfun$createInitializationVector
 *  org.slf4j.Logger
 *  org.spark_project.guava.io.ByteStreams
 *  scala.Function0
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$$less$colon$less
 *  scala.Serializable
 *  scala.Tuple2
 *  scala.collection.JavaConverters$
 *  scala.collection.Map
 *  scala.collection.convert.Decorators
 *  scala.collection.convert.Decorators$AsJava
 *  scala.collection.immutable.Map
 *  scala.collection.mutable.ArrayOps
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.TraitSetter
 */
package org.apache.spark.security;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.security.Key;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.crypto.random.CryptoRandomFactory;
import org.apache.commons.crypto.stream.CryptoInputStream;
import org.apache.commons.crypto.stream.CryptoOutputStream;
import org.apache.spark.SparkConf;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.internal.config.ConfigEntry;
import org.apache.spark.internal.config.package$;
import org.apache.spark.network.util.CryptoUtils;
import org.apache.spark.network.util.JavaUtils;
import org.apache.spark.security.CryptoStreamUtils;
import org.apache.spark.security.CryptoStreamUtils$;
import org.slf4j.Logger;
import org.spark_project.guava.io.ByteStreams;
import scala.Function0;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.Tuple2;
import scala.collection.JavaConverters$;
import scala.collection.Map;
import scala.collection.convert.Decorators;
import scala.collection.mutable.ArrayOps;
import scala.runtime.BoxesRunTime;
import scala.runtime.TraitSetter;

public final class CryptoStreamUtils$
implements Logging {
    public static final CryptoStreamUtils$ MODULE$;
    private final int IV_LENGTH_IN_BYTES;
    private final String SPARK_IO_ENCRYPTION_COMMONS_CONFIG_PREFIX;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.security.CryptoStreamUtils$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @TraitSetter
    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public int IV_LENGTH_IN_BYTES() {
        return this.IV_LENGTH_IN_BYTES;
    }

    public String SPARK_IO_ENCRYPTION_COMMONS_CONFIG_PREFIX() {
        return this.SPARK_IO_ENCRYPTION_COMMONS_CONFIG_PREFIX;
    }

    public OutputStream createCryptoOutputStream(OutputStream os, SparkConf sparkConf, byte[] key) {
        CryptoStreamUtils.CryptoParams params = new CryptoStreamUtils.CryptoParams(key, sparkConf);
        byte[] iv = this.createInitializationVector(params.conf());
        os.write(iv);
        return new CryptoOutputStream(params.transformation(), params.conf(), os, (Key)params.keySpec(), (AlgorithmParameterSpec)new IvParameterSpec(iv));
    }

    public WritableByteChannel createWritableChannel(WritableByteChannel channel, SparkConf sparkConf, byte[] key) {
        CryptoStreamUtils.CryptoParams params = new CryptoStreamUtils.CryptoParams(key, sparkConf);
        byte[] iv = this.createInitializationVector(params.conf());
        CryptoStreamUtils.CryptoHelperChannel helper = new CryptoStreamUtils.CryptoHelperChannel(channel);
        helper.write(ByteBuffer.wrap(iv));
        return new CryptoOutputStream(params.transformation(), params.conf(), (WritableByteChannel)helper, (Key)params.keySpec(), (AlgorithmParameterSpec)new IvParameterSpec(iv));
    }

    public InputStream createCryptoInputStream(InputStream is, SparkConf sparkConf, byte[] key) {
        byte[] iv = new byte[this.IV_LENGTH_IN_BYTES()];
        ByteStreams.readFully((InputStream)is, (byte[])iv);
        CryptoStreamUtils.CryptoParams params = new CryptoStreamUtils.CryptoParams(key, sparkConf);
        return new CryptoInputStream(params.transformation(), params.conf(), is, (Key)params.keySpec(), (AlgorithmParameterSpec)new IvParameterSpec(iv));
    }

    public ReadableByteChannel createReadableChannel(ReadableByteChannel channel, SparkConf sparkConf, byte[] key) {
        byte[] iv = new byte[this.IV_LENGTH_IN_BYTES()];
        ByteBuffer buf = ByteBuffer.wrap(iv);
        JavaUtils.readFully((ReadableByteChannel)channel, (ByteBuffer)buf);
        CryptoStreamUtils.CryptoParams params = new CryptoStreamUtils.CryptoParams(key, sparkConf);
        return new CryptoInputStream(params.transformation(), params.conf(), channel, (Key)params.keySpec(), (AlgorithmParameterSpec)new IvParameterSpec(iv));
    }

    public Properties toCryptoConf(SparkConf conf) {
        return CryptoUtils.toCryptoConf((String)this.SPARK_IO_ENCRYPTION_COMMONS_CONFIG_PREFIX(), ((java.util.Map)JavaConverters$.MODULE$.mapAsJavaMapConverter((Map)Predef$.MODULE$.refArrayOps((Object[])conf.getAll()).toMap(Predef$.MODULE$.$conforms())).asJava()).entrySet());
    }

    public byte[] createKey(SparkConf conf) {
        int keyLen = BoxesRunTime.unboxToInt((Object)conf.get(package$.MODULE$.IO_ENCRYPTION_KEY_SIZE_BITS()));
        String ioKeyGenAlgorithm = conf.get(package$.MODULE$.IO_ENCRYPTION_KEYGEN_ALGORITHM());
        KeyGenerator keyGen = KeyGenerator.getInstance(ioKeyGenAlgorithm);
        keyGen.init(keyLen);
        return keyGen.generateKey().getEncoded();
    }

    private byte[] createInitializationVector(Properties properties) {
        byte[] iv = new byte[this.IV_LENGTH_IN_BYTES()];
        long initialIVStart = System.currentTimeMillis();
        CryptoRandomFactory.getCryptoRandom((Properties)properties).nextBytes(iv);
        long initialIVFinish = System.currentTimeMillis();
        long initialIVTime = initialIVFinish - initialIVStart;
        if (initialIVTime > 2000L) {
            this.logWarning((Function0<String>)new Serializable(initialIVTime){
                public static final long serialVersionUID = 0L;
                private final long initialIVTime$1;

                public final String apply() {
                    return new scala.collection.mutable.StringBuilder().append((Object)new scala.StringContext((scala.collection.Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"It costs ", " milliseconds to create the Initialization Vector "})).s((scala.collection.Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)this.initialIVTime$1)}))).append((Object)new scala.StringContext((scala.collection.Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"used by CryptoStream"})).s((scala.collection.Seq)scala.collection.immutable.Nil$.MODULE$)).toString();
                }
                {
                    this.initialIVTime$1 = initialIVTime$1;
                }
            });
        }
        return iv;
    }

    private CryptoStreamUtils$() {
        MODULE$ = this;
        Logging$class.$init$(this);
        this.IV_LENGTH_IN_BYTES = 16;
        this.SPARK_IO_ENCRYPTION_COMMONS_CONFIG_PREFIX = "spark.io.encryption.commons.config.";
    }
}

