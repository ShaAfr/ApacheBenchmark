/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.GetMapOutputStatuses;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;
import scala.runtime.BoxesRunTime;

public final class GetMapOutputStatuses$
extends AbstractFunction1<Object, GetMapOutputStatuses>
implements Serializable {
    public static final GetMapOutputStatuses$ MODULE$;

    public static {
        new org.apache.spark.GetMapOutputStatuses$();
    }

    public final String toString() {
        return "GetMapOutputStatuses";
    }

    public GetMapOutputStatuses apply(int shuffleId) {
        return new GetMapOutputStatuses(shuffleId);
    }

    public Option<Object> unapply(GetMapOutputStatuses x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)BoxesRunTime.boxToInteger((int)x$0.shuffleId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private GetMapOutputStatuses$() {
        MODULE$ = this;
    }
}

