/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.JobCancelled;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;
import scala.runtime.BoxesRunTime;

public final class JobCancelled$
extends AbstractFunction2<Object, Option<String>, JobCancelled>
implements Serializable {
    public static final JobCancelled$ MODULE$;

    public static {
        new org.apache.spark.scheduler.JobCancelled$();
    }

    public final String toString() {
        return "JobCancelled";
    }

    public JobCancelled apply(int jobId, Option<String> reason) {
        return new JobCancelled(jobId, reason);
    }

    public Option<Tuple2<Object, Option<String>>> unapply(JobCancelled x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)x$0.jobId()), x$0.reason()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private JobCancelled$() {
        MODULE$ = this;
    }
}

