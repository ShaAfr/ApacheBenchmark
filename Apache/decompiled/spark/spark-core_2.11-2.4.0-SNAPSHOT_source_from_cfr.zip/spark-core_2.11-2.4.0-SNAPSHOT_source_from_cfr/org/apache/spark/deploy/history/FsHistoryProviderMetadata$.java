/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy.history;

import org.apache.spark.deploy.history.FsHistoryProviderMetadata;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;
import scala.runtime.BoxesRunTime;

public final class FsHistoryProviderMetadata$
extends AbstractFunction3<Object, Object, String, FsHistoryProviderMetadata>
implements Serializable {
    public static final FsHistoryProviderMetadata$ MODULE$;

    public static {
        new org.apache.spark.deploy.history.FsHistoryProviderMetadata$();
    }

    public final String toString() {
        return "FsHistoryProviderMetadata";
    }

    public FsHistoryProviderMetadata apply(long version, long uiVersion, String logDir) {
        return new FsHistoryProviderMetadata(version, uiVersion, logDir);
    }

    public Option<Tuple3<Object, Object, String>> unapply(FsHistoryProviderMetadata x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)BoxesRunTime.boxToLong((long)x$0.version()), (Object)BoxesRunTime.boxToLong((long)x$0.uiVersion()), (Object)x$0.logDir()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private FsHistoryProviderMetadata$() {
        MODULE$ = this;
    }
}

