/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.GetMapOutputMessage;
import org.apache.spark.rpc.RpcCallContext;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;
import scala.runtime.BoxesRunTime;

public final class GetMapOutputMessage$
extends AbstractFunction2<Object, RpcCallContext, GetMapOutputMessage>
implements Serializable {
    public static final GetMapOutputMessage$ MODULE$;

    public static {
        new org.apache.spark.GetMapOutputMessage$();
    }

    public final String toString() {
        return "GetMapOutputMessage";
    }

    public GetMapOutputMessage apply(int shuffleId, RpcCallContext context) {
        return new GetMapOutputMessage(shuffleId, context);
    }

    public Option<Tuple2<Object, RpcCallContext>> unapply(GetMapOutputMessage x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)x$0.shuffleId()), (Object)x$0.context()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private GetMapOutputMessage$() {
        MODULE$ = this;
    }
}

