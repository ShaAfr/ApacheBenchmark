/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.deploy.rest;

import org.apache.spark.deploy.rest.SubmitRestProtocolException$;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001]3Q!\u0001\u0002\u0001\u00051\u00111dU;c[&$(+Z:u!J|Go\\2pY\u0016C8-\u001a9uS>t'BA\u0002\u0005\u0003\u0011\u0011Xm\u001d;\u000b\u0005\u00151\u0011A\u00023fa2|\u0017P\u0003\u0002\b\u0011\u0005)1\u000f]1sW*\u0011\u0011BC\u0001\u0007CB\f7\r[3\u000b\u0003-\t1a\u001c:h'\t\u0001Q\u0002\u0005\u0002\u000f39\u0011qB\u0006\b\u0003!Qi\u0011!\u0005\u0006\u0003%M\ta\u0001\u0010:p_Rt4\u0001A\u0005\u0002+\u0005)1oY1mC&\u0011q\u0003G\u0001\ba\u0006\u001c7.Y4f\u0015\u0005)\u0012B\u0001\u000e\u001c\u0005%)\u0005pY3qi&|gN\u0003\u0002\u00181!AQ\u0004\u0001B\u0001B\u0003%a$A\u0004nKN\u001c\u0018mZ3\u0011\u0005}\u0019cB\u0001\u0011\"\u001b\u0005A\u0012B\u0001\u0012\u0019\u0003\u0019\u0001&/\u001a3fM&\u0011A%\n\u0002\u0007'R\u0014\u0018N\\4\u000b\u0005\tB\u0002\u0002C\u0014\u0001\u0005\u0003\u0005\u000b\u0011\u0002\u0015\u0002\u000b\r\fWo]3\u0011\u00059I\u0013B\u0001\u0016\u001c\u0005%!\u0006N]8xC\ndW\rC\u0003-\u0001\u0011\u0005Q&\u0001\u0004=S:LGO\u0010\u000b\u0004]A\n\u0004CA\u0018\u0001\u001b\u0005\u0011\u0001\"B\u000f,\u0001\u0004q\u0002bB\u0014,!\u0003\u0005\r\u0001K\u0004\tg\t\t\t\u0011#\u0001\u0003i\u0005Y2+\u001e2nSR\u0014Vm\u001d;Qe>$xnY8m\u000bb\u001cW\r\u001d;j_:\u0004\"aL\u001b\u0007\u0011\u0005\u0011\u0011\u0011!E\u0001\u0005Y\u001a2!N\u001c;!\t\u0001\u0003(\u0003\u0002:1\t1\u0011I\\=SK\u001a\u0004\"\u0001I\u001e\n\u0005qB\"\u0001D*fe&\fG.\u001b>bE2,\u0007\"\u0002\u00176\t\u0003qD#\u0001\u001b\t\u000f\u0001+\u0014\u0013!C\u0001\u0003\u0006YB\u0005\\3tg&t\u0017\u000e\u001e\u0013he\u0016\fG/\u001a:%I\u00164\u0017-\u001e7uII*\u0012A\u0011\u0016\u0003Q\r[\u0013\u0001\u0012\t\u0003\u000b*k\u0011A\u0012\u0006\u0003\u000f\"\u000b\u0011\"\u001e8dQ\u0016\u001c7.\u001a3\u000b\u0005%C\u0012AC1o]>$\u0018\r^5p]&\u00111J\u0012\u0002\u0012k:\u001c\u0007.Z2lK\u00124\u0016M]5b]\u000e,\u0007bB'6\u0003\u0003%IAT\u0001\fe\u0016\fGMU3t_24X\rF\u0001P!\t\u0001V+D\u0001R\u0015\t\u00116+\u0001\u0003mC:<'\"\u0001+\u0002\t)\fg/Y\u0005\u0003-F\u0013aa\u00142kK\u000e$\b")
public class SubmitRestProtocolException
extends Exception {
    public static Throwable $lessinit$greater$default$2() {
        return SubmitRestProtocolException$.MODULE$.$lessinit$greater$default$2();
    }

    public SubmitRestProtocolException(String message, Throwable cause) {
        super(message, cause);
    }
}

