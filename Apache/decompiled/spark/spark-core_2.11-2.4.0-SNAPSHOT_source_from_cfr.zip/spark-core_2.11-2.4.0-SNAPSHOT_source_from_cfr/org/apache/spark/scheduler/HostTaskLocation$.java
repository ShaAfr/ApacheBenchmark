/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.HostTaskLocation;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class HostTaskLocation$
extends AbstractFunction1<String, HostTaskLocation>
implements Serializable {
    public static final HostTaskLocation$ MODULE$;

    public static {
        new org.apache.spark.scheduler.HostTaskLocation$();
    }

    public final String toString() {
        return "HostTaskLocation";
    }

    public HostTaskLocation apply(String host) {
        return new HostTaskLocation(host);
    }

    public Option<String> unapply(HostTaskLocation x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.host());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private HostTaskLocation$() {
        MODULE$ = this;
    }
}

