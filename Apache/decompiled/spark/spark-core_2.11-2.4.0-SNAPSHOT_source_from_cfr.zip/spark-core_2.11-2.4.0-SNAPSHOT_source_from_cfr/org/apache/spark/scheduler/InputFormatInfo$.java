/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.scheduler.InputFormatInfo$$anonfun
 *  org.apache.spark.scheduler.InputFormatInfo$$anonfun$computePreferredLocations
 *  scala.Function1
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$$less$colon$less
 *  scala.Serializable
 *  scala.collection.Map
 *  scala.collection.Seq
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.Set
 *  scala.collection.mutable.HashMap
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.InputFormatInfo;
import org.apache.spark.scheduler.InputFormatInfo$;
import org.apache.spark.scheduler.SplitInfo;
import scala.Function1;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.collection.Map;
import scala.collection.Seq;
import scala.collection.immutable.Set;
import scala.collection.mutable.HashMap;

public final class InputFormatInfo$ {
    public static final InputFormatInfo$ MODULE$;

    public static {
        new org.apache.spark.scheduler.InputFormatInfo$();
    }

    public scala.collection.immutable.Map<String, Set<SplitInfo>> computePreferredLocations(Seq<InputFormatInfo> formats) {
        HashMap nodeToSplit = new HashMap();
        formats.foreach((Function1)new Serializable(nodeToSplit){
            public static final long serialVersionUID = 0L;
            public final HashMap nodeToSplit$1;

            public final void apply(InputFormatInfo inputSplit) {
                Set<SplitInfo> splits = inputSplit.org$apache$spark$scheduler$InputFormatInfo$$findPreferredLocations();
                splits.foreach((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ anonfun.computePreferredLocations.1 $outer;

                    public final scala.collection.mutable.HashSet<SplitInfo> apply(SplitInfo split) {
                        String location = split.hostLocation();
                        scala.collection.mutable.HashSet set2 = (scala.collection.mutable.HashSet)this.$outer.nodeToSplit$1.getOrElseUpdate((Object)location, (scala.Function0)new Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final scala.collection.mutable.HashSet<SplitInfo> apply() {
                                return new scala.collection.mutable.HashSet();
                            }
                        });
                        return set2.$plus$eq((Object)split);
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
            }
            {
                this.nodeToSplit$1 = nodeToSplit$1;
            }
        });
        return nodeToSplit.mapValues((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final Set<SplitInfo> apply(scala.collection.mutable.HashSet<SplitInfo> x$1) {
                return x$1.toSet();
            }
        }).toMap(Predef$.MODULE$.$conforms());
    }

    private InputFormatInfo$() {
        MODULE$ = this;
    }
}

