/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.JobResult;
import org.apache.spark.scheduler.SparkListenerJobEnd;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;
import scala.runtime.BoxesRunTime;

public final class SparkListenerJobEnd$
extends AbstractFunction3<Object, Object, JobResult, SparkListenerJobEnd>
implements Serializable {
    public static final SparkListenerJobEnd$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerJobEnd$();
    }

    public final String toString() {
        return "SparkListenerJobEnd";
    }

    public SparkListenerJobEnd apply(int jobId, long time, JobResult jobResult) {
        return new SparkListenerJobEnd(jobId, time, jobResult);
    }

    public Option<Tuple3<Object, Object, JobResult>> unapply(SparkListenerJobEnd x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)BoxesRunTime.boxToInteger((int)x$0.jobId()), (Object)BoxesRunTime.boxToLong((long)x$0.time()), (Object)x$0.jobResult()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerJobEnd$() {
        MODULE$ = this;
    }
}

