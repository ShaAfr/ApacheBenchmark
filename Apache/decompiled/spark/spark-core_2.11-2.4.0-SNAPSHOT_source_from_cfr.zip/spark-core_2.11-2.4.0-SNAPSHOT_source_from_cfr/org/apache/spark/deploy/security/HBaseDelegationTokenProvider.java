/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.hadoop.conf.Configuration
 *  org.apache.hadoop.io.Text
 *  org.apache.hadoop.security.Credentials
 *  org.apache.hadoop.security.token.Token
 *  org.apache.spark.deploy.security.HBaseDelegationTokenProvider$
 *  org.apache.spark.deploy.security.HBaseDelegationTokenProvider$$anonfun
 *  org.apache.spark.deploy.security.HBaseDelegationTokenProvider$$anonfun$hbaseConf
 *  org.apache.spark.deploy.security.HBaseDelegationTokenProvider$$anonfun$obtainDelegationTokens
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.reflect.ScalaSignature
 *  scala.reflect.api.JavaUniverse
 *  scala.reflect.api.JavaUniverse$JavaMirror
 *  scala.reflect.runtime.package$
 *  scala.runtime.BoxedUnit
 *  scala.util.control.NonFatal$
 */
package org.apache.spark.deploy.security;

import java.lang.reflect.Method;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.security.Credentials;
import org.apache.hadoop.security.token.Token;
import org.apache.spark.SparkConf;
import org.apache.spark.deploy.security.HBaseDelegationTokenProvider$;
import org.apache.spark.deploy.security.HadoopDelegationTokenProvider;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Function0;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.reflect.ScalaSignature;
import scala.reflect.api.JavaUniverse;
import scala.reflect.runtime.package$;
import scala.runtime.BoxedUnit;
import scala.util.control.NonFatal$;

@ScalaSignature(bytes="\u0006\u0001a3Q!\u0001\u0002\u0001\u00051\u0011A\u0004\u0013\"bg\u0016$U\r\\3hCRLwN\u001c+pW\u0016t\u0007K]8wS\u0012,'O\u0003\u0002\u0004\t\u0005A1/Z2ve&$\u0018P\u0003\u0002\u0006\r\u00051A-\u001a9m_fT!a\u0002\u0005\u0002\u000bM\u0004\u0018M]6\u000b\u0005%Q\u0011AB1qC\u000eDWMC\u0001\f\u0003\ry'oZ\n\u0005\u00015\u0019r\u0003\u0005\u0002\u000f#5\tqBC\u0001\u0011\u0003\u0015\u00198-\u00197b\u0013\t\u0011rB\u0001\u0004B]f\u0014VM\u001a\t\u0003)Ui\u0011AA\u0005\u0003-\t\u0011Q\u0004S1e_>\u0004H)\u001a7fO\u0006$\u0018n\u001c8U_.,g\u000e\u0015:pm&$WM\u001d\t\u00031mi\u0011!\u0007\u0006\u00035\u0019\t\u0001\"\u001b8uKJt\u0017\r\\\u0005\u00039e\u0011q\u0001T8hO&tw\rC\u0003\u001f\u0001\u0011\u0005\u0001%\u0001\u0004=S:LGOP\u0002\u0001)\u0005\t\u0003C\u0001\u000b\u0001\u0011\u0015\u0019\u0003\u0001\"\u0011%\u0003-\u0019XM\u001d<jG\u0016t\u0015-\\3\u0016\u0003\u0015\u0002\"AJ\u0015\u000f\u000599\u0013B\u0001\u0015\u0010\u0003\u0019\u0001&/\u001a3fM&\u0011!f\u000b\u0002\u0007'R\u0014\u0018N\\4\u000b\u0005!z\u0001\"B\u0017\u0001\t\u0003r\u0013AF8ci\u0006Lg\u000eR3mK\u001e\fG/[8o)>\\WM\\:\u0015\t=*t(\u0012\t\u0004\u001dA\u0012\u0014BA\u0019\u0010\u0005\u0019y\u0005\u000f^5p]B\u0011abM\u0005\u0003i=\u0011A\u0001T8oO\")a\u0007\fa\u0001o\u0005Q\u0001.\u00193p_B\u001cuN\u001c4\u0011\u0005ajT\"A\u001d\u000b\u0005iZ\u0014\u0001B2p]\u001aT!\u0001\u0010\u0005\u0002\r!\fGm\\8q\u0013\tq\u0014HA\u0007D_:4\u0017nZ;sCRLwN\u001c\u0005\u0006\u00012\u0002\r!Q\u0001\ngB\f'o[\"p]\u001a\u0004\"AQ\"\u000e\u0003\u0019I!\u0001\u0012\u0004\u0003\u0013M\u0003\u0018M]6D_:4\u0007\"\u0002$-\u0001\u00049\u0015!B2sK\u0012\u001c\bC\u0001%K\u001b\u0005I%BA\u0002<\u0013\tY\u0015JA\u0006De\u0016$WM\u001c;jC2\u001c\b\"B'\u0001\t\u0003r\u0015\u0001\u00073fY\u0016<\u0017\r^5p]R{7.\u001a8t%\u0016\fX/\u001b:fIR\u0019qJU*\u0011\u00059\u0001\u0016BA)\u0010\u0005\u001d\u0011un\u001c7fC:DQ\u0001\u0011'A\u0002\u0005CQA\u000e'A\u0002]BQ!\u0016\u0001\u0005\nY\u000b\u0011\u0002\u001b2bg\u0016\u001cuN\u001c4\u0015\u0005]:\u0006\"\u0002\u001eU\u0001\u00049\u0004")
public class HBaseDelegationTokenProvider
implements HadoopDelegationTokenProvider,
Logging {
    private transient Logger org$apache$spark$internal$Logging$$log_;

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    @Override
    public String serviceName() {
        return "hbase";
    }

    @Override
    public Option<Object> obtainDelegationTokens(Configuration hadoopConf, SparkConf sparkConf, Credentials creds) {
        try {
            JavaUniverse.JavaMirror mirror = package$.MODULE$.universe().runtimeMirror(Utils$.MODULE$.getContextOrSparkClassLoader());
            Method obtainToken = mirror.classLoader().loadClass("org.apache.hadoop.hbase.security.token.TokenUtil").getMethod("obtainToken", Configuration.class);
            this.logDebug((Function0<String>)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "Attempting to fetch HBase security token.";
                }
            });
            Token token = (Token)obtainToken.invoke(null, new Object[]{this.hbaseConf(hadoopConf)});
            this.logInfo((Function0<String>)new Serializable(this, token){
                public static final long serialVersionUID = 0L;
                private final Token token$1;

                public final String apply() {
                    return new scala.StringContext((scala.collection.Seq)scala.Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Get token from HBase: ", ""})).s((scala.collection.Seq)scala.Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.token$1.toString()}));
                }
                {
                    this.token$1 = token$1;
                }
            });
            creds.addToken(token.getService(), token);
        }
        catch (Throwable throwable) {
            Throwable throwable2 = throwable;
            Option option = NonFatal$.MODULE$.unapply(throwable2);
            if (option.isEmpty()) {
                throw throwable;
            }
            Throwable e = (Throwable)option.get();
            this.logDebug((Function0<String>)new Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ HBaseDelegationTokenProvider $outer;

                public final String apply() {
                    return new scala.StringContext((scala.collection.Seq)scala.Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Failed to get token from service ", ""})).s((scala.collection.Seq)scala.Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.serviceName()}));
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            }, e);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        }
        return None$.MODULE$;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean delegationTokensRequired(SparkConf sparkConf, Configuration hadoopConf) {
        String string = "kerberos";
        if (this.hbaseConf(hadoopConf).get("hbase.security.authentication") != null) {
            String string2;
            if (!string2.equals(string)) return false;
            return true;
        }
        if (string == null) return true;
        return false;
    }

    private Configuration hbaseConf(Configuration conf) {
        Configuration configuration;
        try {
            JavaUniverse.JavaMirror mirror = package$.MODULE$.universe().runtimeMirror(Utils$.MODULE$.getContextOrSparkClassLoader());
            Method confCreate = mirror.classLoader().loadClass("org.apache.hadoop.hbase.HBaseConfiguration").getMethod("create", Configuration.class);
            configuration = (Configuration)confCreate.invoke(null, new Object[]{conf});
        }
        catch (Throwable throwable) {
            Configuration configuration2;
            Throwable throwable2 = throwable;
            Option option = NonFatal$.MODULE$.unapply(throwable2);
            if (option.isEmpty()) {
                throw throwable;
            }
            Throwable e = (Throwable)option.get();
            this.logDebug((Function0<String>)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "Fail to invoke HBaseConfiguration";
                }
            }, e);
            configuration = configuration2 = conf;
        }
        return configuration;
    }

    public HBaseDelegationTokenProvider() {
        Logging$class.$init$(this);
    }
}

