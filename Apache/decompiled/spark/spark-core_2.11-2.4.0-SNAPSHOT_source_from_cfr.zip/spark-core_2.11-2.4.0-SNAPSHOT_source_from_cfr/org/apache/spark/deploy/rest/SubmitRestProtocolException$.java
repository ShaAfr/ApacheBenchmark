/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Serializable
 */
package org.apache.spark.deploy.rest;

import scala.Serializable;

public final class SubmitRestProtocolException$
implements Serializable {
    public static final SubmitRestProtocolException$ MODULE$;

    public static {
        new org.apache.spark.deploy.rest.SubmitRestProtocolException$();
    }

    public Throwable $lessinit$greater$default$2() {
        return null;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SubmitRestProtocolException$() {
        MODULE$ = this;
    }
}

