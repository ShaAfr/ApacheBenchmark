/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.partial;

public final class package$ {
    public static final package$ MODULE$;

    public static {
        new org.apache.spark.partial.package$();
    }

    private package$() {
        MODULE$ = this;
    }
}

