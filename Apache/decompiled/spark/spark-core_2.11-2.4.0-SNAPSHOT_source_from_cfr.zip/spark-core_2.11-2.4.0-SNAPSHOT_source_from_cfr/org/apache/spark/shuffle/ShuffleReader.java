/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Product2
 *  scala.collection.Iterator
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.shuffle;

import scala.Product2;
import scala.collection.Iterator;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001M2\u0001\"\u0001\u0002\u0011\u0002G\u0005AA\u0003\u0002\u000e'\",hM\u001a7f%\u0016\fG-\u001a:\u000b\u0005\r!\u0011aB:ik\u001a4G.\u001a\u0006\u0003\u000b\u0019\tQa\u001d9be.T!a\u0002\u0005\u0002\r\u0005\u0004\u0018m\u00195f\u0015\u0005I\u0011aA8sOV\u00191bJ\u0019\u0014\u0005\u0001a\u0001CA\u0007\u0011\u001b\u0005q!\"A\b\u0002\u000bM\u001c\u0017\r\\1\n\u0005Eq!AB!osJ+g\rC\u0003\u0014\u0001\u0019\u0005Q#\u0001\u0003sK\u0006$7\u0001\u0001\u000b\u0002-A\u0019qc\b\u0012\u000f\u0005aibBA\r\u001d\u001b\u0005Q\"BA\u000e\u0015\u0003\u0019a$o\\8u}%\tq\"\u0003\u0002\u001f\u001d\u00059\u0001/Y2lC\u001e,\u0017B\u0001\u0011\"\u0005!IE/\u001a:bi>\u0014(B\u0001\u0010\u000f!\u0011i1%\n\u0019\n\u0005\u0011r!\u0001\u0003)s_\u0012,8\r\u001e\u001a\u0011\u0005\u0019:C\u0002\u0001\u0003\u0006Q\u0001\u0011\r!\u000b\u0002\u0002\u0017F\u0011!&\f\t\u0003\u001b-J!\u0001\f\b\u0003\u000f9{G\u000f[5oOB\u0011QBL\u0005\u0003_9\u00111!\u00118z!\t1\u0013\u0007B\u00033\u0001\t\u0007\u0011FA\u0001D\u0001")
public interface ShuffleReader<K, C> {
    public Iterator<Product2<K, C>> read();
}

