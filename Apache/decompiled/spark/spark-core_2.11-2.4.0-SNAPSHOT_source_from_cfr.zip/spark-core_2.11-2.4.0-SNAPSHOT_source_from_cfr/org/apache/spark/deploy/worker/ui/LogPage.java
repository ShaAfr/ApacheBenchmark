/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 *  org.apache.spark.deploy.worker.ui.LogPage$
 *  org.apache.spark.deploy.worker.ui.LogPage$$anonfun
 *  org.apache.spark.deploy.worker.ui.LogPage$$anonfun$getLog
 *  org.apache.spark.deploy.worker.ui.LogPage$$anonfun$render
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function1
 *  scala.MatchError
 *  scala.None$
 *  scala.Option
 *  scala.Option$
 *  scala.Predef$
 *  scala.Serializable
 *  scala.Some
 *  scala.StringContext
 *  scala.Tuple3
 *  scala.Tuple4
 *  scala.collection.GenTraversable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.Set
 *  scala.collection.immutable.Set$
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.math.Numeric
 *  scala.math.Numeric$LongIsIntegral$
 *  scala.math.package$
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxesRunTime
 *  scala.xml.Elem
 *  scala.xml.MetaData
 *  scala.xml.NamespaceBinding
 *  scala.xml.Node
 *  scala.xml.NodeBuffer
 *  scala.xml.Null$
 *  scala.xml.Text
 *  scala.xml.TopScope$
 *  scala.xml.Unparsed
 *  scala.xml.Unparsed$
 *  scala.xml.UnprefixedAttribute
 */
package org.apache.spark.deploy.worker.ui;

import java.io.File;
import java.net.URI;
import javax.servlet.http.HttpServletRequest;
import org.apache.spark.deploy.worker.Worker;
import org.apache.spark.deploy.worker.ui.LogPage$;
import org.apache.spark.deploy.worker.ui.WorkerWebUI;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.ui.UIUtils$;
import org.apache.spark.ui.WebUIPage;
import org.apache.spark.util.Utils$;
import org.apache.spark.util.logging.RollingFileAppender$;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function1;
import scala.MatchError;
import scala.None$;
import scala.Option;
import scala.Option$;
import scala.Predef$;
import scala.Serializable;
import scala.Some;
import scala.StringContext;
import scala.Tuple3;
import scala.Tuple4;
import scala.collection.GenTraversable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.Set;
import scala.collection.immutable.Set$;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.math.Numeric;
import scala.math.package$;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxesRunTime;
import scala.xml.Elem;
import scala.xml.MetaData;
import scala.xml.NamespaceBinding;
import scala.xml.Node;
import scala.xml.NodeBuffer;
import scala.xml.Null$;
import scala.xml.Text;
import scala.xml.TopScope$;
import scala.xml.Unparsed;
import scala.xml.Unparsed$;
import scala.xml.UnprefixedAttribute;

@ScalaSignature(bytes="\u0006\u0001\u0005Eb!B\u0001\u0003\u0001\tq!a\u0002'pOB\u000bw-\u001a\u0006\u0003\u0007\u0011\t!!^5\u000b\u0005\u00151\u0011AB<pe.,'O\u0003\u0002\b\u0011\u00051A-\u001a9m_fT!!\u0003\u0006\u0002\u000bM\u0004\u0018M]6\u000b\u0005-a\u0011AB1qC\u000eDWMC\u0001\u000e\u0003\ry'oZ\n\u0004\u0001=!\u0002C\u0001\t\u0013\u001b\u0005\t\"BA\u0002\t\u0013\t\u0019\u0012CA\u0005XK\n,\u0016\nU1hKB\u0011Q\u0003G\u0007\u0002-)\u0011q\u0003C\u0001\tS:$XM\u001d8bY&\u0011\u0011D\u0006\u0002\b\u0019><w-\u001b8h\u0011!Y\u0002A!A!\u0002\u0013i\u0012A\u00029be\u0016tGo\u0001\u0001\u0011\u0005yyR\"\u0001\u0002\n\u0005\u0001\u0012!aC,pe.,'oV3c+&CQA\t\u0001\u0005\u0002\r\na\u0001P5oSRtDC\u0001\u0013&!\tq\u0002\u0001C\u0003\u001cC\u0001\u0007Q\u0004C\u0004\u0006\u0001\t\u0007I\u0011B\u0014\u0016\u0003!\u0002\"!\u000b\u0016\u000e\u0003\u0011I!a\u000b\u0003\u0003\r]{'o[3s\u0011\u0019i\u0003\u0001)A\u0005Q\u00059qo\u001c:lKJ\u0004\u0003bB\u0018\u0001\u0005\u0004%I\u0001M\u0001\bo>\u00148\u000eR5s+\u0005\t\u0004C\u0001\u001a8\u001b\u0005\u0019$B\u0001\u001b6\u0003\tIwNC\u00017\u0003\u0011Q\u0017M^1\n\u0005a\u001a$\u0001\u0002$jY\u0016DaA\u000f\u0001!\u0002\u0013\t\u0014\u0001C<pe.$\u0015N\u001d\u0011\t\u000fq\u0002!\u0019!C\u0005{\u0005\t2/\u001e9q_J$X\r\u001a'pORK\b/Z:\u0016\u0003y\u00022a\u0010$I\u001b\u0005\u0001%BA!C\u0003%IW.\\;uC\ndWM\u0003\u0002D\t\u0006Q1m\u001c7mK\u000e$\u0018n\u001c8\u000b\u0003\u0015\u000bQa]2bY\u0006L!a\u0012!\u0003\u0007M+G\u000f\u0005\u0002J\u00196\t!J\u0003\u0002Lk\u0005!A.\u00198h\u0013\ti%J\u0001\u0004TiJLgn\u001a\u0005\u0007\u001f\u0002\u0001\u000b\u0011\u0002 \u0002%M,\b\u000f]8si\u0016$Gj\\4UsB,7\u000f\t\u0005\b#\u0002\u0011\r\u0011\"\u0003S\u00031!WMZ1vYR\u0014\u0015\u0010^3t+\u0005\u0019\u0006C\u0001+V\u001b\u0005!\u0015B\u0001,E\u0005\rIe\u000e\u001e\u0005\u00071\u0002\u0001\u000b\u0011B*\u0002\u001b\u0011,g-Y;mi\nKH/Z:!\u0011\u0015Q\u0006\u0001\"\u0001\\\u0003%\u0011XM\u001c3fe2{w\r\u0006\u0002]EB\u0011Q\f\u0019\b\u0003)zK!a\u0018#\u0002\rA\u0013X\rZ3g\u0013\ti\u0015M\u0003\u0002`\t\")1-\u0017a\u0001I\u00069!/Z9vKN$\bCA3m\u001b\u00051'BA4i\u0003\u0011AG\u000f\u001e9\u000b\u0005%T\u0017aB:feZdW\r\u001e\u0006\u0002W\u0006)!.\u0019<bq&\u0011QN\u001a\u0002\u0013\u0011R$\boU3sm2,GOU3rk\u0016\u001cH\u000fC\u0003p\u0001\u0011\u0005\u0001/\u0001\u0004sK:$WM\u001d\u000b\u0004c\u0006\u001d\u0001c\u0001:{{:\u00111\u000f\u001f\b\u0003i^l\u0011!\u001e\u0006\u0003mr\ta\u0001\u0010:p_Rt\u0014\"A#\n\u0005e$\u0015a\u00029bG.\fw-Z\u0005\u0003wr\u00141aU3r\u0015\tIH\tE\u0002\u0003\u0007i\u0011a \u0006\u0004\u0003\u0003!\u0015a\u0001=nY&\u0019\u0011QA@\u0003\t9{G-\u001a\u0005\u0006G:\u0004\r\u0001\u001a\u0005\b\u0003\u0017\u0001A\u0011BA\u0007\u0003\u00199W\r\u001e'pORQ\u0011qBA\u000e\u0003?\t\u0019#!\f\u0011\u0015Q\u000b\t\u0002XA\u000b\u0003+\t)\"C\u0002\u0002\u0014\u0011\u0013a\u0001V;qY\u0016$\u0004c\u0001+\u0002\u0018%\u0019\u0011\u0011\u0004#\u0003\t1{gn\u001a\u0005\b\u0003;\tI\u00011\u0001]\u00031awn\u001a#je\u0016\u001cGo\u001c:z\u0011\u001d\t\t#!\u0003A\u0002q\u000bq\u0001\\8h)f\u0004X\r\u0003\u0005\u0002&\u0005%\u0001\u0019AA\u0014\u00031ygMZ:fi>\u0003H/[8o!\u0015!\u0016\u0011FA\u000b\u0013\r\tY\u0003\u0012\u0002\u0007\u001fB$\u0018n\u001c8\t\u000f\u0005=\u0012\u0011\u0002a\u0001'\u0006Q!-\u001f;f\u0019\u0016tw\r\u001e5")
public class LogPage
extends WebUIPage
implements Logging {
    private final Worker org$apache$spark$deploy$worker$ui$LogPage$$worker;
    private final File workDir;
    private final Set<String> supportedLogTypes;
    private final int org$apache$spark$deploy$worker$ui$LogPage$$defaultBytes;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public Worker org$apache$spark$deploy$worker$ui$LogPage$$worker() {
        return this.org$apache$spark$deploy$worker$ui$LogPage$$worker;
    }

    private File workDir() {
        return this.workDir;
    }

    private Set<String> supportedLogTypes() {
        return this.supportedLogTypes;
    }

    public int org$apache$spark$deploy$worker$ui$LogPage$$defaultBytes() {
        return this.org$apache$spark$deploy$worker$ui$LogPage$$defaultBytes;
    }

    public String renderLog(HttpServletRequest request) {
        block6 : {
            String logType;
            String string;
            Option offset;
            int byteLength;
            block5 : {
                Tuple3 tuple3;
                block4 : {
                    Option appId = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("appId")));
                    Option executorId = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("executorId")));
                    Option driverId = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("driverId")));
                    logType = UIUtils$.MODULE$.stripXSS(request.getParameter("logType"));
                    offset = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("offset"))).map((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final long apply(String x$1) {
                            return new StringOps(Predef$.MODULE$.augmentString(x$1)).toLong();
                        }
                    });
                    byteLength = BoxesRunTime.unboxToInt((Object)Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("byteLength"))).map((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final int apply(String x$2) {
                            return new StringOps(Predef$.MODULE$.augmentString(x$2)).toInt();
                        }
                    }).getOrElse((Function0)new Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ LogPage $outer;

                        public final int apply() {
                            return this.apply$mcI$sp();
                        }

                        public int apply$mcI$sp() {
                            return this.$outer.org$apache$spark$deploy$worker$ui$LogPage$$defaultBytes();
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    }));
                    tuple3 = new Tuple3((Object)appId, (Object)executorId, (Object)driverId);
                    if (tuple3 == null) break block4;
                    Option option = (Option)tuple3._1();
                    Option option2 = (Option)tuple3._2();
                    Option option3 = (Option)tuple3._3();
                    if (!(option instanceof Some)) break block4;
                    Some some = (Some)option;
                    String a = (String)some.x();
                    if (!(option2 instanceof Some)) break block4;
                    Some some2 = (Some)option2;
                    String e = (String)some2.x();
                    if (!None$.MODULE$.equals((Object)option3)) break block4;
                    string = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/", "/", "/"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workDir().getPath(), a, e}));
                    break block5;
                }
                if (tuple3 == null) break block6;
                Option option = (Option)tuple3._1();
                Option option4 = (Option)tuple3._2();
                Option option5 = (Option)tuple3._3();
                if (!None$.MODULE$.equals((Object)option) || !None$.MODULE$.equals((Object)option4) || !(option5 instanceof Some)) break block6;
                Some some = (Some)option5;
                String d = (String)some.x();
                string = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/", "/"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workDir().getPath(), d}));
            }
            String logDir = string;
            Tuple4<String, Object, Object, Object> tuple4 = this.getLog(logDir, logType, (Option<Object>)offset, byteLength);
            if (tuple4 != null) {
                Tuple4 tuple42;
                String logText = (String)tuple4._1();
                long startByte = BoxesRunTime.unboxToLong((Object)tuple4._2());
                long endByte = BoxesRunTime.unboxToLong((Object)tuple4._3());
                long logLength = BoxesRunTime.unboxToLong((Object)tuple4._4());
                Tuple4 tuple43 = tuple42 = new Tuple4((Object)logText, (Object)BoxesRunTime.boxToLong((long)startByte), (Object)BoxesRunTime.boxToLong((long)endByte), (Object)BoxesRunTime.boxToLong((long)logLength));
                String logText2 = (String)tuple43._1();
                long startByte2 = BoxesRunTime.unboxToLong((Object)tuple43._2());
                long endByte2 = BoxesRunTime.unboxToLong((Object)tuple43._3());
                long logLength2 = BoxesRunTime.unboxToLong((Object)tuple43._4());
                String pre = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"==== Bytes ", "-", " of ", " of ", "", " ====\\n"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)startByte2), BoxesRunTime.boxToLong((long)endByte2), BoxesRunTime.boxToLong((long)logLength2), logDir, logType}));
                return new StringBuilder().append((Object)pre).append((Object)logText2).toString();
            }
            throw new MatchError(tuple4);
        }
        throw new Exception("Request must specify either application or driver identifiers");
    }

    @Override
    public Seq<Node> render(HttpServletRequest request) {
        block7 : {
            String logType;
            Option offset;
            Tuple3 tuple3;
            int byteLength;
            block6 : {
                Tuple3 tuple32;
                block5 : {
                    Option appId = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("appId")));
                    Option executorId = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("executorId")));
                    Option driverId = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("driverId")));
                    logType = UIUtils$.MODULE$.stripXSS(request.getParameter("logType"));
                    offset = Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("offset"))).map((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final long apply(String x$4) {
                            return new StringOps(Predef$.MODULE$.augmentString(x$4)).toLong();
                        }
                    });
                    byteLength = BoxesRunTime.unboxToInt((Object)Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("byteLength"))).map((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final int apply(String x$5) {
                            return new StringOps(Predef$.MODULE$.augmentString(x$5)).toInt();
                        }
                    }).getOrElse((Function0)new Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ LogPage $outer;

                        public final int apply() {
                            return this.apply$mcI$sp();
                        }

                        public int apply$mcI$sp() {
                            return this.$outer.org$apache$spark$deploy$worker$ui$LogPage$$defaultBytes();
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    }));
                    tuple32 = new Tuple3((Object)appId, (Object)executorId, (Object)driverId);
                    if (tuple32 == null) break block5;
                    Option option = (Option)tuple32._1();
                    Option option2 = (Option)tuple32._2();
                    Option option3 = (Option)tuple32._3();
                    if (!(option instanceof Some)) break block5;
                    Some some = (Some)option;
                    String a = (String)some.x();
                    if (!(option2 instanceof Some)) break block5;
                    Some some2 = (Some)option2;
                    String e = (String)some2.x();
                    if (!None$.MODULE$.equals((Object)option3)) break block5;
                    tuple3 = new Tuple3((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/", "/", "/"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workDir().getPath(), a, e})), (Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"appId=", "&executorId=", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{a, e})), (Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{a, e})));
                    break block6;
                }
                if (tuple32 == null) break block7;
                Option option = (Option)tuple32._1();
                Option option4 = (Option)tuple32._2();
                Option option5 = (Option)tuple32._3();
                if (!None$.MODULE$.equals((Object)option) || !None$.MODULE$.equals((Object)option4) || !(option5 instanceof Some)) break block7;
                Some some = (Some)option5;
                String d = (String)some.x();
                tuple3 = new Tuple3((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/", "/"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workDir().getPath(), d})), (Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"driverId=", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{d})), (Object)d);
            }
            Tuple3 tuple33 = tuple3;
            if (tuple33 != null) {
                Tuple3 tuple34;
                String logDir = (String)tuple33._1();
                String params = (String)tuple33._2();
                String pageName = (String)tuple33._3();
                Tuple3 tuple35 = tuple34 = new Tuple3((Object)logDir, (Object)params, (Object)pageName);
                String logDir2 = (String)tuple35._1();
                String params2 = (String)tuple35._2();
                String pageName2 = (String)tuple35._3();
                Tuple4<String, Object, Object, Object> tuple4 = this.getLog(logDir2, logType, (Option<Object>)offset, byteLength);
                if (tuple4 != null) {
                    Tuple4 tuple42;
                    String logText = (String)tuple4._1();
                    long startByte = BoxesRunTime.unboxToLong((Object)tuple4._2());
                    long endByte = BoxesRunTime.unboxToLong((Object)tuple4._3());
                    long logLength = BoxesRunTime.unboxToLong((Object)tuple4._4());
                    Tuple4 tuple43 = tuple42 = new Tuple4((Object)logText, (Object)BoxesRunTime.boxToLong((long)startByte), (Object)BoxesRunTime.boxToLong((long)endByte), (Object)BoxesRunTime.boxToLong((long)logLength));
                    String logText2 = (String)tuple43._1();
                    long startByte2 = BoxesRunTime.unboxToLong((Object)tuple43._2());
                    long endByte2 = BoxesRunTime.unboxToLong((Object)tuple43._3());
                    long logLength2 = BoxesRunTime.unboxToLong((Object)tuple43._4());
                    NodeBuffer $buf = new NodeBuffer();
                    Null$ $md = Null$.MODULE$;
                    $md = new UnprefixedAttribute("href", this.org$apache$spark$deploy$worker$ui$LogPage$$worker().activeMasterWebUiUrl(), (MetaData)$md);
                    NodeBuffer $buf2 = new NodeBuffer();
                    $buf2.$amp$plus((Object)new Text("Back to Master"));
                    $buf.$amp$plus((Object)new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
                    Elem linkToMaster = new Elem(null, "p", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
                    long curLogLength = endByte2 - startByte2;
                    Null$ $md2 = Null$.MODULE$;
                    $md2 = new UnprefixedAttribute("id", (Seq)new Text("log-data"), (MetaData)$md2);
                    NodeBuffer $buf3 = new NodeBuffer();
                    $buf3.$amp$plus((Object)new Text("\n        Showing "));
                    $buf3.$amp$plus((Object)BoxesRunTime.boxToLong((long)curLogLength));
                    $buf3.$amp$plus((Object)new Text(" Bytes: "));
                    $buf3.$amp$plus((Object)((Object)BoxesRunTime.boxToLong((long)startByte2)).toString());
                    $buf3.$amp$plus((Object)new Text(" - "));
                    $buf3.$amp$plus((Object)((Object)BoxesRunTime.boxToLong((long)endByte2)).toString());
                    $buf3.$amp$plus((Object)new Text(" of "));
                    $buf3.$amp$plus((Object)BoxesRunTime.boxToLong((long)logLength2));
                    $buf3.$amp$plus((Object)new Text("\n      "));
                    Elem range2 = new Elem(null, "span", (MetaData)$md2, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3);
                    Null$ $md3 = Null$.MODULE$;
                    $md3 = new UnprefixedAttribute("class", (Seq)new Text("log-more-btn btn btn-default"), (MetaData)$md3);
                    $md3 = new UnprefixedAttribute("onclick", "loadMore()", (MetaData)$md3);
                    $md3 = new UnprefixedAttribute("type", (Seq)new Text("button"), (MetaData)$md3);
                    NodeBuffer $buf4 = new NodeBuffer();
                    $buf4.$amp$plus((Object)new Text("\n        Load More\n      "));
                    Elem moreButton = new Elem(null, "button", (MetaData)$md3, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4);
                    Null$ $md4 = Null$.MODULE$;
                    $md4 = new UnprefixedAttribute("class", (Seq)new Text("log-new-btn btn btn-default"), (MetaData)$md4);
                    $md4 = new UnprefixedAttribute("onclick", "loadNew()", (MetaData)$md4);
                    $md4 = new UnprefixedAttribute("type", (Seq)new Text("button"), (MetaData)$md4);
                    NodeBuffer $buf5 = new NodeBuffer();
                    $buf5.$amp$plus((Object)new Text("\n        Load New\n      "));
                    Elem newButton = new Elem(null, "button", (MetaData)$md4, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5);
                    Null$ $md5 = Null$.MODULE$;
                    $md5 = new UnprefixedAttribute("style", (Seq)new Text("display: none;"), (MetaData)$md5);
                    $md5 = new UnprefixedAttribute("class", (Seq)new Text("no-new-alert alert alert-info"), (MetaData)$md5);
                    NodeBuffer $buf6 = new NodeBuffer();
                    $buf6.$amp$plus((Object)new Text("\n        End of Log\n      "));
                    Elem alert = new Elem(null, "div", (MetaData)$md5, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6);
                    String logParams = new StringOps(Predef$.MODULE$.augmentString("?%s&logType=%s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{params2, logType}));
                    String jsOnload = new StringBuilder().append((Object)"window.onload = ").append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"initLogPage('", "', ", ", ", ", ", ", ", ", ", ");"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{logParams, BoxesRunTime.boxToLong((long)curLogLength), BoxesRunTime.boxToLong((long)startByte2), BoxesRunTime.boxToLong((long)endByte2), BoxesRunTime.boxToLong((long)logLength2), BoxesRunTime.boxToInteger((int)byteLength)}))).toString();
                    NodeBuffer $buf7 = new NodeBuffer();
                    $buf7.$amp$plus((Object)new Text("\n        "));
                    $buf7.$amp$plus((Object)linkToMaster);
                    $buf7.$amp$plus((Object)new Text("\n        "));
                    $buf7.$amp$plus((Object)range2);
                    $buf7.$amp$plus((Object)new Text("\n        "));
                    Null$ $md6 = Null$.MODULE$;
                    $md6 = new UnprefixedAttribute("style", (Seq)new Text("height:80vh; overflow:auto; padding:5px;"), (MetaData)$md6);
                    $md6 = new UnprefixedAttribute("class", (Seq)new Text("log-content"), (MetaData)$md6);
                    NodeBuffer $buf8 = new NodeBuffer();
                    $buf8.$amp$plus((Object)new Text("\n          "));
                    NodeBuffer $buf9 = new NodeBuffer();
                    $buf9.$amp$plus((Object)moreButton);
                    $buf8.$amp$plus((Object)new Elem(null, "div", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf9));
                    $buf8.$amp$plus((Object)new Text("\n          "));
                    NodeBuffer $buf10 = new NodeBuffer();
                    $buf10.$amp$plus((Object)logText2);
                    $buf8.$amp$plus((Object)new Elem(null, "pre", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf10));
                    $buf8.$amp$plus((Object)new Text("\n          "));
                    $buf8.$amp$plus((Object)alert);
                    $buf8.$amp$plus((Object)new Text("\n          "));
                    NodeBuffer $buf11 = new NodeBuffer();
                    $buf11.$amp$plus((Object)newButton);
                    $buf8.$amp$plus((Object)new Elem(null, "div", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf11));
                    $buf8.$amp$plus((Object)new Text("\n        "));
                    $buf7.$amp$plus((Object)new Elem(null, "div", (MetaData)$md6, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf8));
                    $buf7.$amp$plus((Object)new Text("\n        "));
                    NodeBuffer $buf12 = new NodeBuffer();
                    $buf12.$amp$plus((Object)Unparsed$.MODULE$.apply(jsOnload));
                    $buf7.$amp$plus((Object)new Elem(null, "script", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf12));
                    $buf7.$amp$plus((Object)new Text("\n      "));
                    Elem content = new Elem(null, "div", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7);
                    return UIUtils$.MODULE$.basicSparkPage((Function0<Seq<Node>>)new Serializable(this, content){
                        public static final long serialVersionUID = 0L;
                        private final Elem content$1;

                        public final Elem apply() {
                            return this.content$1;
                        }
                        {
                            this.content$1 = content$1;
                        }
                    }, new StringBuilder().append((Object)logType).append((Object)" log page for ").append((Object)pageName2).toString(), UIUtils$.MODULE$.basicSparkPage$default$3());
                }
                throw new MatchError(tuple4);
            }
            throw new MatchError((Object)tuple33);
        }
        throw new Exception("Request must specify either application or driver identifiers");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Tuple4<String, Object, Object, Object> getLog(String logDirectory, String logType, Option<Object> offsetOption, int byteLength) {
        Tuple4 tuple4;
        if (!this.supportedLogTypes().contains((Object)logType)) return new Tuple4((Object)new StringBuilder().append((Object)"Error: Log type must be one of ").append((Object)this.supportedLogTypes().mkString(", ")).toString(), (Object)BoxesRunTime.boxToLong((long)0L), (Object)BoxesRunTime.boxToLong((long)0L), (Object)BoxesRunTime.boxToLong((long)0L));
        URI normalizedUri = new File(logDirectory).toURI().normalize();
        File normalizedLogDir = new File(normalizedUri.getPath());
        if (!Utils$.MODULE$.isInDirectory(this.workDir(), normalizedLogDir)) return new Tuple4((Object)new StringBuilder().append((Object)"Error: invalid log directory ").append((Object)logDirectory).toString(), (Object)BoxesRunTime.boxToLong((long)0L), (Object)BoxesRunTime.boxToLong((long)0L), (Object)BoxesRunTime.boxToLong((long)0L));
        try {
            Seq<File> files = RollingFileAppender$.MODULE$.getSortedRolledOverFiles(logDirectory, logType);
            this.logDebug((Function0<String>)new Serializable(this, logDirectory, logType, files){
                public static final long serialVersionUID = 0L;
                private final String logDirectory$1;
                private final String logType$1;
                private final Seq files$1;

                public final String apply() {
                    return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Sorted log files of type ", " in ", ":\\n", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.logType$1, this.logDirectory$1, this.files$1.mkString("\n")}));
                }
                {
                    this.logDirectory$1 = logDirectory$1;
                    this.logType$1 = logType$1;
                    this.files$1 = files$1;
                }
            });
            Seq fileLengths = (Seq)files.map((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ LogPage $outer;

                public final long apply(File x$8) {
                    return Utils$.MODULE$.getFileLength(x$8, this.$outer.org$apache$spark$deploy$worker$ui$LogPage$$worker().conf());
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            }, Seq$.MODULE$.canBuildFrom());
            long totalLength = BoxesRunTime.unboxToLong((Object)fileLengths.sum((Numeric)Numeric.LongIsIntegral$.MODULE$));
            long offset = BoxesRunTime.unboxToLong((Object)offsetOption.getOrElse((Function0)new Serializable(this, byteLength, totalLength){
                public static final long serialVersionUID = 0L;
                private final int byteLength$1;
                private final long totalLength$1;

                public final long apply() {
                    return this.apply$mcJ$sp();
                }

                public long apply$mcJ$sp() {
                    return this.totalLength$1 - (long)this.byteLength$1;
                }
                {
                    this.byteLength$1 = byteLength$1;
                    this.totalLength$1 = totalLength$1;
                }
            }));
            long startIndex = offset < 0L ? 0L : (offset > totalLength ? totalLength : offset);
            long endIndex = package$.MODULE$.min(startIndex + (long)byteLength, totalLength);
            this.logDebug((Function0<String>)new Serializable(this, startIndex, endIndex){
                public static final long serialVersionUID = 0L;
                private final long startIndex$1;
                private final long endIndex$1;

                public final String apply() {
                    return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Getting log from ", " to ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)this.startIndex$1), BoxesRunTime.boxToLong((long)this.endIndex$1)}));
                }
                {
                    this.startIndex$1 = startIndex$1;
                    this.endIndex$1 = endIndex$1;
                }
            });
            String logText = Utils$.MODULE$.offsetBytes(files, (Seq<Object>)fileLengths, startIndex, endIndex);
            this.logDebug((Function0<String>)new Serializable(this, logText){
                public static final long serialVersionUID = 0L;
                private final String logText$1;

                public final String apply() {
                    return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Got log of length ", " bytes"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.logText$1.length())}));
                }
                {
                    this.logText$1 = logText$1;
                }
            });
            tuple4 = new Tuple4((Object)logText, (Object)BoxesRunTime.boxToLong((long)startIndex), (Object)BoxesRunTime.boxToLong((long)endIndex), (Object)BoxesRunTime.boxToLong((long)totalLength));
            return tuple4;
        }
        catch (Exception exception2) {
            this.logError((Function0<String>)new Serializable(this, logDirectory, logType){
                public static final long serialVersionUID = 0L;
                private final String logDirectory$1;
                private final String logType$1;

                public final String apply() {
                    return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Error getting ", " logs from directory ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.logType$1, this.logDirectory$1}));
                }
                {
                    this.logDirectory$1 = logDirectory$1;
                    this.logType$1 = logType$1;
                }
            }, exception2);
            tuple4 = new Tuple4((Object)new StringBuilder().append((Object)"Error getting logs due to exception: ").append((Object)exception2.getMessage()).toString(), (Object)BoxesRunTime.boxToLong((long)0L), (Object)BoxesRunTime.boxToLong((long)0L), (Object)BoxesRunTime.boxToLong((long)0L));
        }
        return tuple4;
    }

    public LogPage(WorkerWebUI parent) {
        super("logPage");
        Logging$class.$init$(this);
        this.org$apache$spark$deploy$worker$ui$LogPage$$worker = parent.worker();
        this.workDir = new File(parent.workDir().toURI().normalize().getPath());
        this.supportedLogTypes = (Set)Predef$.MODULE$.Set().apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"stderr", "stdout"}));
        this.org$apache$spark$deploy$worker$ui$LogPage$$defaultBytes = 102400;
    }
}

