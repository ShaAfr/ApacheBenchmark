/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.deploy;

public final class DeployMessages$ {
    public static final DeployMessages$ MODULE$;

    public static {
        new org.apache.spark.deploy.DeployMessages$();
    }

    private DeployMessages$() {
        MODULE$ = this;
    }
}

