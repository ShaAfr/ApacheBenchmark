/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.scheduler.StageInfo$$anonfun
 *  org.apache.spark.scheduler.StageInfo$$anonfun$fromStage
 *  scala.Function0
 *  scala.Function1
 *  scala.None$
 *  scala.Option
 *  scala.Predef$
 *  scala.Serializable
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableLike
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.List
 *  scala.collection.immutable.List$
 *  scala.collection.mutable.WrappedArray
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.executor.TaskMetrics;
import org.apache.spark.rdd.RDD;
import org.apache.spark.scheduler.Stage;
import org.apache.spark.scheduler.StageInfo;
import org.apache.spark.scheduler.StageInfo$;
import org.apache.spark.scheduler.TaskLocation;
import org.apache.spark.storage.RDDInfo;
import org.apache.spark.storage.RDDInfo$;
import scala.Function0;
import scala.Function1;
import scala.None$;
import scala.Option;
import scala.Predef$;
import scala.Serializable;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableLike;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.List;
import scala.collection.immutable.List$;
import scala.collection.mutable.WrappedArray;
import scala.runtime.BoxesRunTime;

public final class StageInfo$ {
    public static final StageInfo$ MODULE$;

    public static {
        new org.apache.spark.scheduler.StageInfo$();
    }

    public StageInfo fromStage(Stage stage, int attemptId, Option<Object> numTasks, TaskMetrics taskMetrics, Seq<Seq<TaskLocation>> taskLocalityPreferences) {
        Seq ancestorRddInfos = (Seq)stage.rdd().getNarrowAncestors().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final RDDInfo apply(RDD<?> rdd) {
                return RDDInfo$.MODULE$.fromRdd(rdd);
            }
        }, Seq$.MODULE$.canBuildFrom());
        Seq rddInfos = (Seq)((TraversableLike)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new RDDInfo[]{RDDInfo$.MODULE$.fromRdd(stage.rdd())}))).$plus$plus((GenTraversableOnce)ancestorRddInfos, Seq$.MODULE$.canBuildFrom());
        return new StageInfo(stage.id(), attemptId, stage.name(), BoxesRunTime.unboxToInt((Object)numTasks.getOrElse((Function0)new Serializable(stage){
            public static final long serialVersionUID = 0L;
            private final Stage stage$1;

            public final int apply() {
                return this.apply$mcI$sp();
            }

            public int apply$mcI$sp() {
                return this.stage$1.numTasks();
            }
            {
                this.stage$1 = stage$1;
            }
        })), (Seq<RDDInfo>)rddInfos, (Seq<Object>)((Seq)stage.parents().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(Stage x$1) {
                return x$1.id();
            }
        }, List$.MODULE$.canBuildFrom())), stage.details(), taskMetrics, taskLocalityPreferences);
    }

    public Option<Object> fromStage$default$3() {
        return None$.MODULE$;
    }

    public TaskMetrics fromStage$default$4() {
        return null;
    }

    public Seq<Seq<TaskLocation>> fromStage$default$5() {
        return (Seq)Seq$.MODULE$.empty();
    }

    public TaskMetrics $lessinit$greater$default$8() {
        return null;
    }

    public Seq<Seq<TaskLocation>> $lessinit$greater$default$9() {
        return (Seq)Seq$.MODULE$.empty();
    }

    private StageInfo$() {
        MODULE$ = this;
    }
}

