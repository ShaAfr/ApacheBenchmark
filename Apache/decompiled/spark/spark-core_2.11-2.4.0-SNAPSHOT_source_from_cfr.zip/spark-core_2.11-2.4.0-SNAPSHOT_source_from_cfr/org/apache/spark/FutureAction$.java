/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Function1
 *  scala.concurrent.ExecutionContext
 *  scala.concurrent.Future
 *  scala.util.Try
 */
package org.apache.spark;

import java.lang.reflect.Method;
import scala.Function1;
import scala.concurrent.ExecutionContext;
import scala.concurrent.Future;
import scala.util.Try;

public final class FutureAction$ {
    public static final FutureAction$ MODULE$;
    private final Method transformTryMethod;
    private final Method transformWithTryMethod;

    public static {
        new org.apache.spark.FutureAction$();
    }

    private Method transformTryMethod() {
        return this.transformTryMethod;
    }

    private Method transformWithTryMethod() {
        return this.transformWithTryMethod;
    }

    public <T, S> Future<S> transform(Future<T> future, Function1<Try<T>, Try<S>> f, ExecutionContext executor) {
        return (Future)this.transformTryMethod().invoke(future, new Object[]{f, executor});
    }

    public <T, S> Future<S> transformWith(Future<T> future, Function1<Try<T>, Future<S>> f, ExecutionContext executor) {
        return (Future)this.transformWithTryMethod().invoke(future, new Object[]{f, executor});
    }

    private final Method liftedTree1$1() {
        Method method;
        try {
            method = Future.class.getMethod("transform", Function1.class, ExecutionContext.class);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            method = null;
        }
        return method;
    }

    private final Method liftedTree2$1() {
        Method method;
        try {
            method = Future.class.getMethod("transformWith", Function1.class, ExecutionContext.class);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            method = null;
        }
        return method;
    }

    private FutureAction$() {
        MODULE$ = this;
        this.transformTryMethod = this.liftedTree1$1();
        this.transformWithTryMethod = this.liftedTree2$1();
    }
}

