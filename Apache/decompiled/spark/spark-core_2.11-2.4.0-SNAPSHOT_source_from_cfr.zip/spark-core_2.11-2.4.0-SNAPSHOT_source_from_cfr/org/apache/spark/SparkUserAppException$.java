/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.SparkUserAppException;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;
import scala.runtime.BoxesRunTime;

public final class SparkUserAppException$
extends AbstractFunction1<Object, SparkUserAppException>
implements Serializable {
    public static final SparkUserAppException$ MODULE$;

    public static {
        new org.apache.spark.SparkUserAppException$();
    }

    public final String toString() {
        return "SparkUserAppException";
    }

    public SparkUserAppException apply(int exitCode) {
        return new SparkUserAppException(exitCode);
    }

    public Option<Object> unapply(SparkUserAppException x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)BoxesRunTime.boxToInteger((int)x$0.exitCode()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkUserAppException$() {
        MODULE$ = this;
    }
}

