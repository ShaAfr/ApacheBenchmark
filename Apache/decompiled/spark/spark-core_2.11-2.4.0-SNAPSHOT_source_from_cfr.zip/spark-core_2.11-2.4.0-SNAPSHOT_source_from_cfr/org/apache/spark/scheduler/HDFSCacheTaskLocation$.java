/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.HDFSCacheTaskLocation;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class HDFSCacheTaskLocation$
extends AbstractFunction1<String, HDFSCacheTaskLocation>
implements Serializable {
    public static final HDFSCacheTaskLocation$ MODULE$;

    public static {
        new org.apache.spark.scheduler.HDFSCacheTaskLocation$();
    }

    public final String toString() {
        return "HDFSCacheTaskLocation";
    }

    public HDFSCacheTaskLocation apply(String host) {
        return new HDFSCacheTaskLocation(host);
    }

    public Option<String> unapply(HDFSCacheTaskLocation x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.host());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private HDFSCacheTaskLocation$() {
        MODULE$ = this;
    }
}

