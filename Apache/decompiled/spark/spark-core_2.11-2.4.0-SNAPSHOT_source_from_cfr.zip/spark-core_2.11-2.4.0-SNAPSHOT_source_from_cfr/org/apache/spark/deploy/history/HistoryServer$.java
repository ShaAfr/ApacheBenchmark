/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.history.HistoryServer$$anonfun
 *  org.apache.spark.deploy.history.HistoryServer$$anonfun$createSecurityManager
 *  org.apache.spark.deploy.history.HistoryServer$$anonfun$main
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Predef$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.collection.Seq
 *  scala.collection.mutable.WrappedArray
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy.history;

import java.lang.reflect.Constructor;
import org.apache.spark.SecurityManager;
import org.apache.spark.SecurityManager$;
import org.apache.spark.SparkConf;
import org.apache.spark.deploy.SparkHadoopUtil;
import org.apache.spark.deploy.SparkHadoopUtil$;
import org.apache.spark.deploy.history.ApplicationHistoryProvider;
import org.apache.spark.deploy.history.HistoryServer;
import org.apache.spark.deploy.history.HistoryServer$;
import org.apache.spark.deploy.history.HistoryServerArguments;
import org.apache.spark.deploy.history.config$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.internal.config.ConfigEntry;
import org.apache.spark.util.ShutdownHookManager$;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.collection.Seq;
import scala.collection.mutable.WrappedArray;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;

public final class HistoryServer$
implements Logging {
    public static final HistoryServer$ MODULE$;
    private final SparkConf conf;
    private final String UI_PATH_PREFIX;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.deploy.history.HistoryServer$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    private SparkConf conf() {
        return this.conf;
    }

    public String UI_PATH_PREFIX() {
        return this.UI_PATH_PREFIX;
    }

    public void main(String[] argStrings) {
        Utils$.MODULE$.initDaemon(this.log());
        new HistoryServerArguments(this.conf(), argStrings);
        this.initSecurity();
        SecurityManager securityManager = this.createSecurityManager(this.conf());
        String providerName = (String)this.conf().getOption("spark.history.provider").getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return org.apache.spark.deploy.history.FsHistoryProvider.class.getName();
            }
        });
        ApplicationHistoryProvider provider = (ApplicationHistoryProvider)Utils$.MODULE$.classForName(providerName).getConstructor(SparkConf.class).newInstance(this.conf());
        int port = BoxesRunTime.unboxToInt((Object)this.conf().get(config$.MODULE$.HISTORY_SERVER_UI_PORT()));
        HistoryServer server = new HistoryServer(this.conf(), provider, securityManager, port);
        server.bind();
        ShutdownHookManager$.MODULE$.addShutdownHook((Function0<BoxedUnit>)new Serializable(server){
            public static final long serialVersionUID = 0L;
            private final HistoryServer server$1;

            public final void apply() {
                this.apply$mcV$sp();
            }

            public void apply$mcV$sp() {
                this.server$1.stop();
            }
            {
                this.server$1 = server$1;
            }
        });
        do {
            Thread.sleep(Integer.MAX_VALUE);
        } while (true);
    }

    public SecurityManager createSecurityManager(SparkConf config2) {
        Object object;
        Object object2;
        if (config2.getBoolean(SecurityManager$.MODULE$.SPARK_AUTH_CONF(), false)) {
            this.logDebug((Function0<String>)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Clearing ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{SecurityManager$.MODULE$.SPARK_AUTH_CONF()}));
                }
            });
            object = config2.set(SecurityManager$.MODULE$.SPARK_AUTH_CONF(), "false");
        } else {
            object = BoxedUnit.UNIT;
        }
        if (config2.getBoolean("spark.acls.enable", config2.getBoolean("spark.ui.acls.enable", false))) {
            this.logInfo((Function0<String>)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "Either spark.acls.enable or spark.ui.acls.enable is configured, clearing it and only using spark.history.ui.acl.enable";
                }
            });
            config2.set("spark.acls.enable", "false");
            object2 = config2.set("spark.ui.acls.enable", "false");
        } else {
            object2 = BoxedUnit.UNIT;
        }
        return new SecurityManager(config2, SecurityManager$.MODULE$.$lessinit$greater$default$2());
    }

    public void initSecurity() {
        if (this.conf().getBoolean("spark.history.kerberos.enabled", false)) {
            String principalName = this.conf().get("spark.history.kerberos.principal");
            String keytabFilename = this.conf().get("spark.history.kerberos.keytab");
            SparkHadoopUtil$.MODULE$.get().loginUserFromKeytab(principalName, keytabFilename);
        }
    }

    public String getAttemptURI(String appId, Option<String> attemptId) {
        String attemptSuffix = (String)attemptId.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(String id) {
                return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"/", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{id}));
            }
        }).getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "";
            }
        });
        return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/", "", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.UI_PATH_PREFIX(), appId, attemptSuffix}));
    }

    private HistoryServer$() {
        MODULE$ = this;
        Logging$class.$init$(this);
        this.conf = new SparkConf();
        this.UI_PATH_PREFIX = "/history";
    }
}

