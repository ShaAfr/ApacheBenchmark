/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.Tuple3
 *  scala.collection.Seq
 *  scala.runtime.AbstractFunction3
 */
package org.apache.spark;

import org.apache.spark.Heartbeat;
import org.apache.spark.storage.BlockManagerId;
import org.apache.spark.util.AccumulatorV2;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.Tuple3;
import scala.collection.Seq;
import scala.runtime.AbstractFunction3;

public final class Heartbeat$
extends AbstractFunction3<String, Tuple2<Object, Seq<AccumulatorV2<?, ?>>>[], BlockManagerId, Heartbeat>
implements Serializable {
    public static final Heartbeat$ MODULE$;

    public static {
        new org.apache.spark.Heartbeat$();
    }

    public final String toString() {
        return "Heartbeat";
    }

    public Heartbeat apply(String executorId, Tuple2<Object, Seq<AccumulatorV2<?, ?>>>[] accumUpdates, BlockManagerId blockManagerId) {
        return new Heartbeat(executorId, accumUpdates, blockManagerId);
    }

    public Option<Tuple3<String, Tuple2<Object, Seq<AccumulatorV2<?, ?>>>[], BlockManagerId>> unapply(Heartbeat x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)x$0.executorId(), x$0.accumUpdates(), (Object)x$0.blockManagerId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private Heartbeat$() {
        MODULE$ = this;
    }
}

