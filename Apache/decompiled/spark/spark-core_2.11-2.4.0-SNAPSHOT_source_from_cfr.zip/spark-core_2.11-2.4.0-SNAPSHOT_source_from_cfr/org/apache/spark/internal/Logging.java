/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.reflect.ScalaSignature
 *  scala.runtime.TraitSetter
 */
package org.apache.spark.internal;

import org.slf4j.Logger;
import scala.Function0;
import scala.reflect.ScalaSignature;
import scala.runtime.TraitSetter;

@ScalaSignature(bytes="\u0006\u0001\u0005-faB\u0001\u0003!\u0003\r\ta\u0003\u0002\b\u0019><w-\u001b8h\u0015\t\u0019A!\u0001\u0005j]R,'O\\1m\u0015\t)a!A\u0003ta\u0006\u00148N\u0003\u0002\b\u0011\u00051\u0011\r]1dQ\u0016T\u0011!C\u0001\u0004_J<7\u0001A\n\u0003\u00011\u0001\"!\u0004\t\u000e\u00039Q\u0011aD\u0001\u0006g\u000e\fG.Y\u0005\u0003#9\u0011a!\u00118z%\u00164\u0007\"B\n\u0001\t\u0003!\u0012A\u0002\u0013j]&$H\u0005F\u0001\u0016!\tia#\u0003\u0002\u0018\u001d\t!QK\\5u\u0011\u001dI\u0002\u00011A\u0005\ni\tA\u0001\\8h?V\t1\u0004\u0005\u0002\u001d?5\tQD\u0003\u0002\u001f\u0011\u0005)1\u000f\u001c45U&\u0011\u0001%\b\u0002\u0007\u0019><w-\u001a:\t\u000f\t\u0002\u0001\u0019!C\u0005G\u0005AAn\\4`?\u0012*\u0017\u000f\u0006\u0002\u0016I!9Q%IA\u0001\u0002\u0004Y\u0012a\u0001=%c!1q\u0005\u0001Q!\nm\tQ\u0001\\8h?\u0002B#AJ\u0015\u0011\u00055Q\u0013BA\u0016\u000f\u0005%!(/\u00198tS\u0016tG\u000fC\u0003.\u0001\u0011Ea&A\u0004m_\u001et\u0015-\\3\u0016\u0003=\u0002\"\u0001M\u001b\u000e\u0003ER!AM\u001a\u0002\t1\fgn\u001a\u0006\u0002i\u0005!!.\u0019<b\u0013\t1\u0014G\u0001\u0004TiJLgn\u001a\u0005\u0006q\u0001!\tBG\u0001\u0004Y><\u0007\"\u0002\u001e\u0001\t#Y\u0014a\u00027pO&sgm\u001c\u000b\u0003+qBa!P\u001d\u0005\u0002\u0004q\u0014aA7tOB\u0019QbP!\n\u0005\u0001s!\u0001\u0003\u001fcs:\fW.\u001a \u0011\u0005\t+eBA\u0007D\u0013\t!e\"\u0001\u0004Qe\u0016$WMZ\u0005\u0003m\u0019S!\u0001\u0012\b\t\u000b!\u0003A\u0011C%\u0002\u00111|w\rR3ck\u001e$\"!\u0006&\t\ru:E\u00111\u0001?\u0011\u0015a\u0005\u0001\"\u0005N\u0003!awn\u001a+sC\u000e,GCA\u000bO\u0011\u0019i4\n\"a\u0001}!)\u0001\u000b\u0001C\t#\u0006QAn\\4XCJt\u0017N\\4\u0015\u0005U\u0011\u0006BB\u001fP\t\u0003\u0007a\bC\u0003U\u0001\u0011EQ+\u0001\u0005m_\u001e,%O]8s)\t)b\u000b\u0003\u0004>'\u0012\u0005\rA\u0010\u0005\u0006u\u0001!\t\u0002\u0017\u000b\u0004+eS\u0006BB\u001fX\t\u0003\u0007a\bC\u0003\\/\u0002\u0007A,A\u0005uQJ|w/\u00192mKB\u0011Q,\u001a\b\u0003=\u000et!a\u00182\u000e\u0003\u0001T!!\u0019\u0006\u0002\rq\u0012xn\u001c;?\u0013\u0005y\u0011B\u00013\u000f\u0003\u001d\u0001\u0018mY6bO\u0016L!AZ4\u0003\u0013QC'o\\<bE2,'B\u00013\u000f\u0011\u0015A\u0005\u0001\"\u0005j)\r)\"n\u001b\u0005\u0007{!$\t\u0019\u0001 \t\u000bmC\u0007\u0019\u0001/\t\u000b1\u0003A\u0011C7\u0015\u0007Uqw\u000e\u0003\u0004>Y\u0012\u0005\rA\u0010\u0005\u000672\u0004\r\u0001\u0018\u0005\u0006!\u0002!\t\"\u001d\u000b\u0004+I\u001c\bBB\u001fq\t\u0003\u0007a\bC\u0003\\a\u0002\u0007A\fC\u0003U\u0001\u0011EQ\u000fF\u0002\u0016m^Da!\u0010;\u0005\u0002\u0004q\u0004\"B.u\u0001\u0004a\u0006\"B=\u0001\t#Q\u0018AD5t)J\f7-Z#oC\ndW\r\u001a\u000b\u0002wB\u0011Q\u0002`\u0005\u0003{:\u0011qAQ8pY\u0016\fg\u000e\u0003\u0004\u0000\u0001\u0011E\u0011\u0011A\u0001\u0019S:LG/[1mSj,Gj\\4JM:+7-Z:tCJLHcA\u000b\u0002\u0004!1\u0011Q\u0001@A\u0002m\fQ\"[:J]R,'\u000f\u001d:fi\u0016\u0014\bBB@\u0001\t#\tI\u0001F\u0003|\u0003\u0017\ti\u0001C\u0004\u0002\u0006\u0005\u001d\u0001\u0019A>\t\u0013\u0005=\u0011q\u0001I\u0001\u0002\u0004Y\u0018AB:jY\u0016tG\u000fC\u0004\u0002\u0014\u0001!I!!\u0006\u0002#%t\u0017\u000e^5bY&TX\rT8hO&tw\rF\u0003\u0016\u0003/\tI\u0002C\u0004\u0002\u0006\u0005E\u0001\u0019A>\t\u000f\u0005=\u0011\u0011\u0003a\u0001w\"I\u0011Q\u0004\u0001\u0012\u0002\u0013E\u0011qD\u0001#S:LG/[1mSj,Gj\\4JM:+7-Z:tCJLH\u0005Z3gCVdG\u000f\n\u001a\u0016\u0005\u0005\u0005\"fA>\u0002$-\u0012\u0011Q\u0005\t\u0005\u0003O\t\t$\u0004\u0002\u0002*)!\u00111FA\u0017\u0003%)hn\u00195fG.,GMC\u0002\u000209\t!\"\u00198o_R\fG/[8o\u0013\u0011\t\u0019$!\u000b\u0003#Ut7\r[3dW\u0016$g+\u0019:jC:\u001cWm\u0002\u0005\u00028\tA\t\u0001BA\u001d\u0003\u001daunZ4j]\u001e\u0004B!a\u000f\u0002>5\t!AB\u0004\u0002\u0005!\u0005A!a\u0010\u0014\u0007\u0005uB\u0002\u0003\u0005\u0002D\u0005uB\u0011AA#\u0003\u0019a\u0014N\\5u}Q\u0011\u0011\u0011\b\u0005\u000b\u0003\u0013\ni\u00041A\u0005\n\u0005-\u0013aC5oSRL\u0017\r\\5{K\u0012,\u0012a\u001f\u0005\u000b\u0003\u001f\ni\u00041A\u0005\n\u0005E\u0013aD5oSRL\u0017\r\\5{K\u0012|F%Z9\u0015\u0007U\t\u0019\u0006\u0003\u0005&\u0003\u001b\n\t\u00111\u0001|\u0011!\t9&!\u0010!B\u0013Y\u0018\u0001D5oSRL\u0017\r\\5{K\u0012\u0004\u0003\u0006BA+\u00037\u00022!DA/\u0013\r\tyF\u0004\u0002\tm>d\u0017\r^5mK\"Q\u00111MA\u001f\u0001\u0004%I!!\u001a\u0002!\u0011,g-Y;miJ{w\u000e\u001e'fm\u0016dWCAA4!\u0011\tI'a\u001c\u000e\u0005\u0005-$bAA7\r\u0005)An\\45U&!\u0011\u0011OA6\u0005\u0015aUM^3m\u0011)\t)(!\u0010A\u0002\u0013%\u0011qO\u0001\u0015I\u00164\u0017-\u001e7u%>|G\u000fT3wK2|F%Z9\u0015\u0007U\tI\bC\u0005&\u0003g\n\t\u00111\u0001\u0002h!I\u0011QPA\u001fA\u0003&\u0011qM\u0001\u0012I\u00164\u0017-\u001e7u%>|G\u000fT3wK2\u0004\u0003\u0006BA>\u00037B!\"a!\u0002>\u0001\u0007I\u0011BA&\u0003]!WMZ1vYR\u001c\u0006/\u0019:l\u0019><GG[\"p]\u001aLw\r\u0003\u0006\u0002\b\u0006u\u0002\u0019!C\u0005\u0003\u0013\u000b1\u0004Z3gCVdGo\u00159be.dun\u001a\u001bk\u0007>tg-[4`I\u0015\fHcA\u000b\u0002\f\"AQ%!\"\u0002\u0002\u0003\u00071\u0010\u0003\u0005\u0002\u0010\u0006u\u0002\u0015)\u0003|\u0003a!WMZ1vYR\u001c\u0006/\u0019:l\u0019><GG[\"p]\u001aLw\r\t\u0015\u0005\u0003\u001b\u000bY\u0006\u0003\u0006\u0002\u0016\u0006u\"\u0019!C\u0001\u0003/\u000b\u0001\"\u001b8ji2{7m[\u000b\u0003\u00033\u00032\u0001MAN\u0013\r\ti*\r\u0002\u0007\u001f\nTWm\u0019;\t\u0013\u0005\u0005\u0016Q\bQ\u0001\n\u0005e\u0015!C5oSRdunY6!\u0011\u001d\t)+!\u0010\u0005\u0002Q\tA\"\u001e8j]&$\u0018.\u00197ju\u0016Dq!!+\u0002>\u0011%!0A\u0005jg2{w\r\u000e62e\u0001")
public interface Logging {
    public Logger org$apache$spark$internal$Logging$$log_();

    @TraitSetter
    public void org$apache$spark$internal$Logging$$log__$eq(Logger var1);

    public String logName();

    public Logger log();

    public void logInfo(Function0<String> var1);

    public void logDebug(Function0<String> var1);

    public void logTrace(Function0<String> var1);

    public void logWarning(Function0<String> var1);

    public void logError(Function0<String> var1);

    public void logInfo(Function0<String> var1, Throwable var2);

    public void logDebug(Function0<String> var1, Throwable var2);

    public void logTrace(Function0<String> var1, Throwable var2);

    public void logWarning(Function0<String> var1, Throwable var2);

    public void logError(Function0<String> var1, Throwable var2);

    public boolean isTraceEnabled();

    public void initializeLogIfNecessary(boolean var1);

    public boolean initializeLogIfNecessary(boolean var1, boolean var2);

    public boolean initializeLogIfNecessary$default$2();
}

