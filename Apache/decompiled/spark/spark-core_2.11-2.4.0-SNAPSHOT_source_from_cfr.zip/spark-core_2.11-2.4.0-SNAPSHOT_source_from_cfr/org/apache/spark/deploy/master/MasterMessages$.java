/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Serializable
 */
package org.apache.spark.deploy.master;

import scala.Serializable;

public final class MasterMessages$
implements Serializable {
    public static final MasterMessages$ MODULE$;

    public static {
        new org.apache.spark.deploy.master.MasterMessages$();
    }

    private Object readResolve() {
        return MODULE$;
    }

    private MasterMessages$() {
        MODULE$ = this;
    }
}

