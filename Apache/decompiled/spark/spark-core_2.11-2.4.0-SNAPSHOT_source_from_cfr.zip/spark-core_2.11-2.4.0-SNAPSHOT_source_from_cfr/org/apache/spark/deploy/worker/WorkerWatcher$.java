/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.deploy.worker;

public final class WorkerWatcher$ {
    public static final WorkerWatcher$ MODULE$;

    public static {
        new org.apache.spark.deploy.worker.WorkerWatcher$();
    }

    public boolean $lessinit$greater$default$3() {
        return false;
    }

    private WorkerWatcher$() {
        MODULE$ = this;
    }
}

