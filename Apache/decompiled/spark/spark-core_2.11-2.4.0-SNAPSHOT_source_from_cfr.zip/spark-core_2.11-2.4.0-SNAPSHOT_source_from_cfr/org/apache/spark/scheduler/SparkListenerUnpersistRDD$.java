/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerUnpersistRDD;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;
import scala.runtime.BoxesRunTime;

public final class SparkListenerUnpersistRDD$
extends AbstractFunction1<Object, SparkListenerUnpersistRDD>
implements Serializable {
    public static final SparkListenerUnpersistRDD$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerUnpersistRDD$();
    }

    public final String toString() {
        return "SparkListenerUnpersistRDD";
    }

    public SparkListenerUnpersistRDD apply(int rddId) {
        return new SparkListenerUnpersistRDD(rddId);
    }

    public Option<Object> unapply(SparkListenerUnpersistRDD x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)BoxesRunTime.boxToInteger((int)x$0.rddId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerUnpersistRDD$() {
        MODULE$ = this;
    }
}

