/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 *  org.apache.spark.deploy.worker.ui.WorkerPage$
 *  org.apache.spark.deploy.worker.ui.WorkerPage$$anonfun
 *  org.apache.spark.deploy.worker.ui.WorkerPage$$anonfun$driverRow
 *  org.apache.spark.deploy.worker.ui.WorkerPage$$anonfun$render
 *  org.json4s.JsonAST
 *  org.json4s.JsonAST$JObject
 *  org.json4s.JsonAST$JValue
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Predef$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Iterable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.List
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.WrappedArray
 *  scala.math.Ordering
 *  scala.math.Ordering$String$
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.xml.Comment
 *  scala.xml.Elem
 *  scala.xml.MetaData
 *  scala.xml.NamespaceBinding
 *  scala.xml.Node
 *  scala.xml.NodeBuffer
 *  scala.xml.NodeSeq$
 *  scala.xml.Null$
 *  scala.xml.Text
 *  scala.xml.TopScope$
 *  scala.xml.UnprefixedAttribute
 */
package org.apache.spark.deploy.worker.ui;

import javax.servlet.http.HttpServletRequest;
import org.apache.spark.deploy.ApplicationDescription;
import org.apache.spark.deploy.Command;
import org.apache.spark.deploy.DeployMessages;
import org.apache.spark.deploy.DeployMessages$RequestWorkerState$;
import org.apache.spark.deploy.DriverDescription;
import org.apache.spark.deploy.ExecutorState$;
import org.apache.spark.deploy.JsonProtocol$;
import org.apache.spark.deploy.worker.DriverRunner;
import org.apache.spark.deploy.worker.ExecutorRunner;
import org.apache.spark.deploy.worker.Worker;
import org.apache.spark.deploy.worker.ui.WorkerPage$;
import org.apache.spark.deploy.worker.ui.WorkerWebUI;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.ui.UIUtils$;
import org.apache.spark.ui.WebUIPage;
import org.apache.spark.util.Utils$;
import org.json4s.JsonAST;
import scala.Enumeration;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.Iterable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.List;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.WrappedArray;
import scala.math.Ordering;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.xml.Comment;
import scala.xml.Elem;
import scala.xml.MetaData;
import scala.xml.NamespaceBinding;
import scala.xml.Node;
import scala.xml.NodeBuffer;
import scala.xml.NodeSeq$;
import scala.xml.Null$;
import scala.xml.Text;
import scala.xml.TopScope$;
import scala.xml.UnprefixedAttribute;

@ScalaSignature(bytes="\u0006\u0001e4Q!\u0001\u0002\u0001\u00059\u0011!bV8sW\u0016\u0014\b+Y4f\u0015\t\u0019A!\u0001\u0002vS*\u0011QAB\u0001\u0007o>\u00148.\u001a:\u000b\u0005\u001dA\u0011A\u00023fa2|\u0017P\u0003\u0002\n\u0015\u0005)1\u000f]1sW*\u00111\u0002D\u0001\u0007CB\f7\r[3\u000b\u00035\t1a\u001c:h'\t\u0001q\u0002\u0005\u0002\u0011%5\t\u0011C\u0003\u0002\u0004\u0011%\u00111#\u0005\u0002\n/\u0016\u0014W+\u0013)bO\u0016D\u0001\"\u0006\u0001\u0003\u0002\u0003\u0006IaF\u0001\u0007a\u0006\u0014XM\u001c;\u0004\u0001A\u0011\u0001$G\u0007\u0002\u0005%\u0011!D\u0001\u0002\f/>\u00148.\u001a:XK\n,\u0016\nC\u0003\u001d\u0001\u0011\u0005Q$\u0001\u0004=S:LGO\u0010\u000b\u0003=}\u0001\"\u0001\u0007\u0001\t\u000bUY\u0002\u0019A\f\t\u000f\u0005\u0002!\u0019!C\u0005E\u0005qqo\u001c:lKJ,e\u000e\u001a9pS:$X#A\u0012\u0011\u0005\u0011:S\"A\u0013\u000b\u0005\u0019B\u0011a\u0001:qG&\u0011\u0001&\n\u0002\u000f%B\u001cWI\u001c3q_&tGOU3g\u0011\u0019Q\u0003\u0001)A\u0005G\u0005yqo\u001c:lKJ,e\u000e\u001a9pS:$\b\u0005C\u0003-\u0001\u0011\u0005S&\u0001\u0006sK:$WM\u001d&t_:$\"A\f \u0011\u0005=ZdB\u0001\u00199\u001d\t\tdG\u0004\u00023k5\t1G\u0003\u00025-\u00051AH]8pizJ\u0011!D\u0005\u0003o1\taA[:p]R\u001a\u0018BA\u001d;\u0003\u001d\u0001\u0018mY6bO\u0016T!a\u000e\u0007\n\u0005qj$A\u0002&WC2,XM\u0003\u0002:u!)qh\u000ba\u0001\u0001\u00069!/Z9vKN$\bCA!I\u001b\u0005\u0011%BA\"E\u0003\u0011AG\u000f\u001e9\u000b\u0005\u00153\u0015aB:feZdW\r\u001e\u0006\u0002\u000f\u0006)!.\u0019<bq&\u0011\u0011J\u0011\u0002\u0013\u0011R$\boU3sm2,GOU3rk\u0016\u001cH\u000fC\u0003L\u0001\u0011\u0005A*\u0001\u0004sK:$WM\u001d\u000b\u0003\u001bv\u00032A\u0014+X\u001d\ty%K\u0004\u00023!&\t\u0011+A\u0003tG\u0006d\u0017-\u0003\u0002:'*\t\u0011+\u0003\u0002V-\n\u00191+Z9\u000b\u0005e\u001a\u0006C\u0001-\\\u001b\u0005I&B\u0001.T\u0003\rAX\u000e\\\u0005\u00039f\u0013AAT8eK\")qH\u0013a\u0001\u0001\")q\f\u0001C\u0001A\u0006YQ\r_3dkR|'OU8x)\ti\u0015\rC\u0003c=\u0002\u00071-\u0001\u0005fq\u0016\u001cW\u000f^8s!\t!W-D\u0001\u0005\u0013\t1GA\u0001\bFq\u0016\u001cW\u000f^8s%Vtg.\u001a:\t\u000b!\u0004A\u0011A5\u0002\u0013\u0011\u0014\u0018N^3s%><HcA'ki\")1n\u001aa\u0001Y\u0006Aqo\u001c:lKJLE\r\u0005\u0002nc:\u0011an\\\u0007\u0002'&\u0011\u0001oU\u0001\u0007!J,G-\u001a4\n\u0005I\u001c(AB*ue&twM\u0003\u0002q'\")Qo\u001aa\u0001m\u00061AM]5wKJ\u0004\"\u0001Z<\n\u0005a$!\u0001\u0004#sSZ,'OU;o]\u0016\u0014\b")
public class WorkerPage
extends WebUIPage {
    private final WorkerWebUI parent;
    private final RpcEndpointRef workerEndpoint;

    private RpcEndpointRef workerEndpoint() {
        return this.workerEndpoint;
    }

    @Override
    public JsonAST.JValue renderJson(HttpServletRequest request) {
        DeployMessages.WorkerStateResponse workerState = (DeployMessages.WorkerStateResponse)this.workerEndpoint().askSync(DeployMessages$RequestWorkerState$.MODULE$, ClassTag$.MODULE$.apply(DeployMessages.WorkerStateResponse.class));
        return JsonProtocol$.MODULE$.writeWorkerState(workerState);
    }

    @Override
    public Seq<Node> render(HttpServletRequest request) {
        Object object;
        Object object2;
        Object object3;
        DeployMessages.WorkerStateResponse workerState = (DeployMessages.WorkerStateResponse)this.workerEndpoint().askSync(DeployMessages$RequestWorkerState$.MODULE$, ClassTag$.MODULE$.apply(DeployMessages.WorkerStateResponse.class));
        Seq executorHeaders = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"ExecutorID", "Cores", "State", "Memory", "Job Details", "Logs"}));
        List<ExecutorRunner> runningExecutors = workerState.executors();
        Seq<Node> runningExecutorTable = UIUtils$.MODULE$.listingTable((Seq<String>)executorHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ WorkerPage $outer;

            public final Seq<Node> apply(ExecutorRunner executor) {
                return this.$outer.executorRow(executor);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, runningExecutors, UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        List<ExecutorRunner> finishedExecutors = workerState.finishedExecutors();
        Seq<Node> finishedExecutorTable = UIUtils$.MODULE$.listingTable((Seq<String>)executorHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ WorkerPage $outer;

            public final Seq<Node> apply(ExecutorRunner executor) {
                return this.$outer.executorRow(executor);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, finishedExecutors, UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        Seq driverHeaders = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"DriverID", "Main Class", "State", "Cores", "Memory", "Logs", "Notes"}));
        List runningDrivers = ((List)workerState.drivers().sortBy((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final String apply(DriverRunner x$1) {
                return x$1.driverId();
            }
        }, (Ordering)Ordering.String$.MODULE$)).reverse();
        Seq<Node> runningDriverTable = UIUtils$.MODULE$.listingTable((Seq<String>)driverHeaders, new Serializable(this, workerState){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ WorkerPage $outer;
            private final DeployMessages.WorkerStateResponse workerState$1;

            public final Seq<Node> apply(DriverRunner x$2) {
                return this.$outer.driverRow(this.workerState$1.workerId(), x$2);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.workerState$1 = workerState$1;
            }
        }, runningDrivers, UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        List finishedDrivers = ((List)workerState.finishedDrivers().sortBy((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final String apply(DriverRunner x$3) {
                return x$3.driverId();
            }
        }, (Ordering)Ordering.String$.MODULE$)).reverse();
        Seq<Node> finishedDriverTable = UIUtils$.MODULE$.listingTable((Seq<String>)driverHeaders, new Serializable(this, workerState){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ WorkerPage $outer;
            private final DeployMessages.WorkerStateResponse workerState$1;

            public final Seq<Node> apply(DriverRunner x$4) {
                return this.$outer.driverRow(this.workerState$1.workerId(), x$4);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.workerState$1 = workerState$1;
            }
        }, finishedDrivers, UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        NodeBuffer $buf = new NodeBuffer();
        Null$ $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md);
        NodeBuffer $buf2 = new NodeBuffer();
        $buf2.$amp$plus((Object)new Text(" "));
        $buf2.$amp$plus((Object)new Comment(" Worker Details "));
        $buf2.$amp$plus((Object)new Text("\n        "));
        Null$ $md2 = Null$.MODULE$;
        $md2 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md2);
        NodeBuffer $buf3 = new NodeBuffer();
        $buf3.$amp$plus((Object)new Text("\n          "));
        Null$ $md3 = Null$.MODULE$;
        $md3 = new UnprefixedAttribute("class", (Seq)new Text("unstyled"), (MetaData)$md3);
        NodeBuffer $buf4 = new NodeBuffer();
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf5 = new NodeBuffer();
        NodeBuffer $buf6 = new NodeBuffer();
        $buf6.$amp$plus((Object)new Text("ID:"));
        $buf5.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6));
        $buf5.$amp$plus((Object)new Text(" "));
        $buf5.$amp$plus((Object)workerState.workerId());
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf7 = new NodeBuffer();
        NodeBuffer $buf8 = new NodeBuffer();
        $buf8.$amp$plus((Object)new Text("\n              Master URL:"));
        $buf7.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf8));
        $buf7.$amp$plus((Object)new Text(" "));
        $buf7.$amp$plus((Object)workerState.masterUrl());
        $buf7.$amp$plus((Object)new Text("\n            "));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf9 = new NodeBuffer();
        NodeBuffer $buf10 = new NodeBuffer();
        $buf10.$amp$plus((Object)new Text("Cores:"));
        $buf9.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf10));
        $buf9.$amp$plus((Object)new Text(" "));
        $buf9.$amp$plus((Object)BoxesRunTime.boxToInteger((int)workerState.cores()));
        $buf9.$amp$plus((Object)new Text(" ("));
        $buf9.$amp$plus((Object)BoxesRunTime.boxToInteger((int)workerState.coresUsed()));
        $buf9.$amp$plus((Object)new Text(" Used)"));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf9));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf11 = new NodeBuffer();
        NodeBuffer $buf12 = new NodeBuffer();
        $buf12.$amp$plus((Object)new Text("Memory:"));
        $buf11.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf12));
        $buf11.$amp$plus((Object)new Text(" "));
        $buf11.$amp$plus((Object)Utils$.MODULE$.megabytesToString(workerState.memory()));
        $buf11.$amp$plus((Object)new Text("\n              ("));
        $buf11.$amp$plus((Object)Utils$.MODULE$.megabytesToString(workerState.memoryUsed()));
        $buf11.$amp$plus((Object)new Text(" Used)"));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf11));
        $buf4.$amp$plus((Object)new Text("\n          "));
        $buf3.$amp$plus((Object)new Elem(null, "ul", (MetaData)$md3, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4));
        $buf3.$amp$plus((Object)new Text("\n          "));
        NodeBuffer $buf13 = new NodeBuffer();
        Null$ $md4 = Null$.MODULE$;
        $md4 = new UnprefixedAttribute("href", workerState.masterWebUiUrl(), (MetaData)$md4);
        NodeBuffer $buf14 = new NodeBuffer();
        $buf14.$amp$plus((Object)new Text("Back to Master"));
        $buf13.$amp$plus((Object)new Elem(null, "a", (MetaData)$md4, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf14));
        $buf3.$amp$plus((Object)new Elem(null, "p", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf13));
        $buf3.$amp$plus((Object)new Text("\n        "));
        $buf2.$amp$plus((Object)new Elem(null, "div", (MetaData)$md2, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3));
        $buf2.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
        Null$ $md5 = Null$.MODULE$;
        $md5 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md5);
        NodeBuffer $buf15 = new NodeBuffer();
        $buf15.$amp$plus((Object)new Text(" "));
        $buf15.$amp$plus((Object)new Comment(" Executors and Drivers "));
        $buf15.$amp$plus((Object)new Text("\n        "));
        Null$ $md6 = Null$.MODULE$;
        $md6 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md6);
        NodeBuffer $buf16 = new NodeBuffer();
        $buf16.$amp$plus((Object)new Text("\n          "));
        Null$ $md7 = Null$.MODULE$;
        $md7 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-runningExecutors',\n              'aggregated-runningExecutors')"), (MetaData)$md7);
        $md7 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-runningExecutors collapse-table"), (MetaData)$md7);
        NodeBuffer $buf17 = new NodeBuffer();
        $buf17.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf18 = new NodeBuffer();
        $buf18.$amp$plus((Object)new Text("\n              "));
        Null$ $md8 = Null$.MODULE$;
        $md8 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md8);
        $buf18.$amp$plus((Object)new Elem(null, "span", (MetaData)$md8, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
        $buf18.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf19 = new NodeBuffer();
        $buf19.$amp$plus((Object)new Text("Running Executors ("));
        $buf19.$amp$plus((Object)BoxesRunTime.boxToInteger((int)runningExecutors.size()));
        $buf19.$amp$plus((Object)new Text(")"));
        $buf18.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf19));
        $buf18.$amp$plus((Object)new Text("\n            "));
        $buf17.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf18));
        $buf17.$amp$plus((Object)new Text("\n          "));
        $buf16.$amp$plus((Object)new Elem(null, "span", (MetaData)$md7, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf17));
        $buf16.$amp$plus((Object)new Text("\n          "));
        Null$ $md9 = Null$.MODULE$;
        $md9 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-runningExecutors collapsible-table"), (MetaData)$md9);
        NodeBuffer $buf20 = new NodeBuffer();
        $buf20.$amp$plus((Object)new Text("\n            "));
        $buf20.$amp$plus(runningExecutorTable);
        $buf20.$amp$plus((Object)new Text("\n          "));
        $buf16.$amp$plus((Object)new Elem(null, "div", (MetaData)$md9, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf20));
        $buf16.$amp$plus((Object)new Text("\n          "));
        if (runningDrivers.nonEmpty()) {
            Null$ $md10 = Null$.MODULE$;
            $md10 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-runningDrivers',\n                  'aggregated-runningDrivers')"), (MetaData)$md10);
            $md10 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-runningDrivers collapse-table"), (MetaData)$md10);
            NodeBuffer $buf21 = new NodeBuffer();
            $buf21.$amp$plus((Object)new Text("\n                "));
            NodeBuffer $buf22 = new NodeBuffer();
            $buf22.$amp$plus((Object)new Text("\n                  "));
            Null$ $md11 = Null$.MODULE$;
            $md11 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md11);
            $buf22.$amp$plus((Object)new Elem(null, "span", (MetaData)$md11, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf22.$amp$plus((Object)new Text("\n                  "));
            NodeBuffer $buf23 = new NodeBuffer();
            $buf23.$amp$plus((Object)new Text("Running Drivers ("));
            $buf23.$amp$plus((Object)BoxesRunTime.boxToInteger((int)runningDrivers.size()));
            $buf23.$amp$plus((Object)new Text(")"));
            $buf22.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf23));
            $buf22.$amp$plus((Object)new Text("\n                "));
            $buf21.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf22));
            $buf21.$amp$plus((Object)new Text("\n              "));
            Null$ $md12 = Null$.MODULE$;
            $md12 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-runningDrivers collapsible-table"), (MetaData)$md12);
            NodeBuffer $buf24 = new NodeBuffer();
            $buf24.$amp$plus((Object)new Text("\n                "));
            $buf24.$amp$plus(runningDriverTable);
            $buf24.$amp$plus((Object)new Text("\n              "));
            object2 = new Elem(null, "span", (MetaData)$md10, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf21).$plus$plus((GenTraversableOnce)new Elem(null, "div", (MetaData)$md12, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf24), NodeSeq$.MODULE$.canBuildFrom());
        } else {
            object2 = BoxedUnit.UNIT;
        }
        $buf16.$amp$plus(object2);
        $buf16.$amp$plus((Object)new Text("\n          "));
        if (finishedExecutors.nonEmpty()) {
            Null$ $md13 = Null$.MODULE$;
            $md13 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-finishedExecutors',\n                  'aggregated-finishedExecutors')"), (MetaData)$md13);
            $md13 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-finishedExecutors collapse-table"), (MetaData)$md13);
            NodeBuffer $buf25 = new NodeBuffer();
            $buf25.$amp$plus((Object)new Text("\n                "));
            NodeBuffer $buf26 = new NodeBuffer();
            $buf26.$amp$plus((Object)new Text("\n                  "));
            Null$ $md14 = Null$.MODULE$;
            $md14 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md14);
            $buf26.$amp$plus((Object)new Elem(null, "span", (MetaData)$md14, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf26.$amp$plus((Object)new Text("\n                  "));
            NodeBuffer $buf27 = new NodeBuffer();
            $buf27.$amp$plus((Object)new Text("Finished Executors ("));
            $buf27.$amp$plus((Object)BoxesRunTime.boxToInteger((int)finishedExecutors.size()));
            $buf27.$amp$plus((Object)new Text(")"));
            $buf26.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf27));
            $buf26.$amp$plus((Object)new Text("\n                "));
            $buf25.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf26));
            $buf25.$amp$plus((Object)new Text("\n              "));
            Null$ $md15 = Null$.MODULE$;
            $md15 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-finishedExecutors collapsible-table"), (MetaData)$md15);
            NodeBuffer $buf28 = new NodeBuffer();
            $buf28.$amp$plus((Object)new Text("\n                "));
            $buf28.$amp$plus(finishedExecutorTable);
            $buf28.$amp$plus((Object)new Text("\n              "));
            object = new Elem(null, "span", (MetaData)$md13, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf25).$plus$plus((GenTraversableOnce)new Elem(null, "div", (MetaData)$md15, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf28), NodeSeq$.MODULE$.canBuildFrom());
        } else {
            object = BoxedUnit.UNIT;
        }
        $buf16.$amp$plus(object);
        $buf16.$amp$plus((Object)new Text("\n          "));
        if (finishedDrivers.nonEmpty()) {
            Null$ $md16 = Null$.MODULE$;
            $md16 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-finishedDrivers',\n                  'aggregated-finishedDrivers')"), (MetaData)$md16);
            $md16 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-finishedDrivers collapse-table"), (MetaData)$md16);
            NodeBuffer $buf29 = new NodeBuffer();
            $buf29.$amp$plus((Object)new Text("\n                "));
            NodeBuffer $buf30 = new NodeBuffer();
            $buf30.$amp$plus((Object)new Text("\n                  "));
            Null$ $md17 = Null$.MODULE$;
            $md17 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md17);
            $buf30.$amp$plus((Object)new Elem(null, "span", (MetaData)$md17, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf30.$amp$plus((Object)new Text("\n                  "));
            NodeBuffer $buf31 = new NodeBuffer();
            $buf31.$amp$plus((Object)new Text("Finished Drivers ("));
            $buf31.$amp$plus((Object)BoxesRunTime.boxToInteger((int)finishedDrivers.size()));
            $buf31.$amp$plus((Object)new Text(")"));
            $buf30.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf31));
            $buf30.$amp$plus((Object)new Text("\n                "));
            $buf29.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf30));
            $buf29.$amp$plus((Object)new Text("\n              "));
            Null$ $md18 = Null$.MODULE$;
            $md18 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-finishedDrivers collapsible-table"), (MetaData)$md18);
            NodeBuffer $buf32 = new NodeBuffer();
            $buf32.$amp$plus((Object)new Text("\n                "));
            $buf32.$amp$plus(finishedDriverTable);
            $buf32.$amp$plus((Object)new Text("\n              "));
            object3 = new Elem(null, "span", (MetaData)$md16, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf29).$plus$plus((GenTraversableOnce)new Elem(null, "div", (MetaData)$md18, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf32), NodeSeq$.MODULE$.canBuildFrom());
        } else {
            object3 = BoxedUnit.UNIT;
        }
        $buf16.$amp$plus(object3);
        $buf16.$amp$plus((Object)new Text("\n        "));
        $buf15.$amp$plus((Object)new Elem(null, "div", (MetaData)$md6, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf16));
        $buf15.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md5, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf15));
        NodeBuffer content = $buf;
        return UIUtils$.MODULE$.basicSparkPage((Function0<Seq<Node>>)new Serializable(this, content){
            public static final long serialVersionUID = 0L;
            private final NodeBuffer content$1;

            public final NodeBuffer apply() {
                return this.content$1;
            }
            {
                this.content$1 = content$1;
            }
        }, new StringOps(Predef$.MODULE$.augmentString("Spark Worker at %s:%s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{workerState.host(), BoxesRunTime.boxToInteger((int)workerState.port())})), UIUtils$.MODULE$.basicSparkPage$default$3());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public Seq<Node> executorRow(ExecutorRunner executor) {
        block3 : {
            block2 : {
                workerUrlRef = UIUtils$.MODULE$.makeHref(this.parent.worker().reverseProxy(), executor.workerId(), this.parent.webUrl());
                appUrlRef = UIUtils$.MODULE$.makeHref(this.parent.worker().reverseProxy(), executor.appId(), executor.appDesc().appUiUrl());
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)new Text("\n      "));
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)BoxesRunTime.boxToInteger((int)executor.execId()));
                $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
                $buf.$amp$plus((Object)new Text("\n      "));
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)BoxesRunTime.boxToInteger((int)executor.cores()));
                $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
                $buf.$amp$plus((Object)new Text("\n      "));
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)executor.state());
                $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
                $buf.$amp$plus((Object)new Text("\n      "));
                $md = Null$.MODULE$;
                $md = new UnprefixedAttribute("sorttable_customkey", BoxesRunTime.boxToInteger((int)executor.memory()).toString(), (MetaData)$md);
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)new Text("\n        "));
                $buf.$amp$plus((Object)Utils$.MODULE$.megabytesToString(executor.memory()));
                $buf.$amp$plus((Object)new Text("\n      "));
                $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
                $buf.$amp$plus((Object)new Text("\n      "));
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)new Text("\n        "));
                $md = Null$.MODULE$;
                $md = new UnprefixedAttribute("class", (Seq)new Text("unstyled"), (MetaData)$md);
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)new Text("\n          "));
                $buf = new NodeBuffer();
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)new Text("ID:"));
                $buf.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
                $buf.$amp$plus((Object)new Text(" "));
                $buf.$amp$plus((Object)executor.appId());
                $buf.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
                $buf.$amp$plus((Object)new Text("\n          "));
                $buf = new NodeBuffer();
                $buf = new NodeBuffer();
                $buf.$amp$plus((Object)new Text("Name:"));
                $buf.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
                $buf.$amp$plus((Object)new Text("\n          "));
                var17_17 = ExecutorState$.MODULE$.RUNNING();
                if (executor.state() != null) break block2;
                if (var17_17 == null) break block3;
                ** GOTO lbl-1000
            }
            if (!v0.equals((Object)var17_17)) ** GOTO lbl-1000
        }
        if (new StringOps(Predef$.MODULE$.augmentString(executor.appDesc().appUiUrl())).nonEmpty()) {
            $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("href", appUrlRef, (MetaData)$md);
            v1 = v2;
            $buf = new NodeBuffer();
            $buf.$amp$plus((Object)new Text(" "));
            $buf.$amp$plus((Object)executor.appDesc().name());
            v2 = new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
        } else lbl-1000: // 3 sources:
        {
            v1 = executor.appDesc().name();
        }
        $buf.$amp$plus((Object)v1);
        $buf.$amp$plus((Object)new Text("\n          "));
        $buf.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n          "));
        $buf = new NodeBuffer();
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("User:"));
        $buf.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text(" "));
        $buf.$amp$plus((Object)executor.appDesc().user());
        $buf.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n        "));
        $buf.$amp$plus((Object)new Elem(null, "ul", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n        "));
        $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("href", new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/logPage?appId=", "&executorId=", "&logType=stdout"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{workerUrlRef, executor.appId(), BoxesRunTime.boxToInteger((int)executor.execId())})), (MetaData)$md);
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("stdout"));
        $buf.$amp$plus((Object)new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n        "));
        $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("href", new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/logPage?appId=", "&executorId=", "&logType=stderr"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{workerUrlRef, executor.appId(), BoxesRunTime.boxToInteger((int)executor.execId())})), (MetaData)$md);
        $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("stderr"));
        $buf.$amp$plus((Object)new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf));
        $buf.$amp$plus((Object)new Text("\n    "));
        return new Elem(null, "tr", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
    }

    public Seq<Node> driverRow(String workerId, DriverRunner driver) {
        String workerUrlRef = UIUtils$.MODULE$.makeHref(this.parent.worker().reverseProxy(), workerId, this.parent.webUrl());
        NodeBuffer $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf2 = new NodeBuffer();
        $buf2.$amp$plus((Object)driver.driverId());
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf3 = new NodeBuffer();
        $buf3.$amp$plus(driver.driverDesc().command().arguments().apply(2));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf4 = new NodeBuffer();
        $buf4.$amp$plus(driver.finalState().getOrElse((Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final Enumeration.Value apply() {
                return org.apache.spark.deploy.master.DriverState$.MODULE$.RUNNING();
            }
        }));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4));
        $buf.$amp$plus((Object)new Text("\n      "));
        Null$ $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("sorttable_customkey", ((Object)BoxesRunTime.boxToInteger((int)driver.driverDesc().cores())).toString(), (MetaData)$md);
        NodeBuffer $buf5 = new NodeBuffer();
        $buf5.$amp$plus((Object)new Text("\n        "));
        $buf5.$amp$plus((Object)((Object)BoxesRunTime.boxToInteger((int)driver.driverDesc().cores())).toString());
        $buf5.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5));
        $buf.$amp$plus((Object)new Text("\n      "));
        Null$ $md2 = Null$.MODULE$;
        $md2 = new UnprefixedAttribute("sorttable_customkey", ((Object)BoxesRunTime.boxToInteger((int)driver.driverDesc().mem())).toString(), (MetaData)$md2);
        NodeBuffer $buf6 = new NodeBuffer();
        $buf6.$amp$plus((Object)new Text("\n        "));
        $buf6.$amp$plus((Object)Utils$.MODULE$.megabytesToString(driver.driverDesc().mem()));
        $buf6.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)$md2, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf7 = new NodeBuffer();
        $buf7.$amp$plus((Object)new Text("\n        "));
        Null$ $md3 = Null$.MODULE$;
        $md3 = new UnprefixedAttribute("href", new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/logPage?driverId=", "&logType=stdout"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{workerUrlRef, driver.driverId()})), (MetaData)$md3);
        NodeBuffer $buf8 = new NodeBuffer();
        $buf8.$amp$plus((Object)new Text("stdout"));
        $buf7.$amp$plus((Object)new Elem(null, "a", (MetaData)$md3, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf8));
        $buf7.$amp$plus((Object)new Text("\n        "));
        Null$ $md4 = Null$.MODULE$;
        $md4 = new UnprefixedAttribute("href", new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/logPage?driverId=", "&logType=stderr"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{workerUrlRef, driver.driverId()})), (MetaData)$md4);
        NodeBuffer $buf9 = new NodeBuffer();
        $buf9.$amp$plus((Object)new Text("stderr"));
        $buf7.$amp$plus((Object)new Elem(null, "a", (MetaData)$md4, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf9));
        $buf7.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf10 = new NodeBuffer();
        $buf10.$amp$plus((Object)new Text("\n        "));
        $buf10.$amp$plus(driver.finalException().getOrElse((Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "";
            }
        }));
        $buf10.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf10));
        $buf.$amp$plus((Object)new Text("\n    "));
        return new Elem(null, "tr", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
    }

    public WorkerPage(WorkerWebUI parent) {
        this.parent = parent;
        super("");
        this.workerEndpoint = parent.worker().self();
    }
}

