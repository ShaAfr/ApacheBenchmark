/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.TaskSet;
import org.apache.spark.scheduler.TaskSetFailed;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;

public final class TaskSetFailed$
extends AbstractFunction3<TaskSet, String, Option<Throwable>, TaskSetFailed>
implements Serializable {
    public static final TaskSetFailed$ MODULE$;

    public static {
        new org.apache.spark.scheduler.TaskSetFailed$();
    }

    public final String toString() {
        return "TaskSetFailed";
    }

    public TaskSetFailed apply(TaskSet taskSet, String reason, Option<Throwable> exception2) {
        return new TaskSetFailed(taskSet, reason, exception2);
    }

    public Option<Tuple3<TaskSet, String, Option<Throwable>>> unapply(TaskSetFailed x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)x$0.taskSet(), (Object)x$0.reason(), x$0.exception()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private TaskSetFailed$() {
        MODULE$ = this;
    }
}

