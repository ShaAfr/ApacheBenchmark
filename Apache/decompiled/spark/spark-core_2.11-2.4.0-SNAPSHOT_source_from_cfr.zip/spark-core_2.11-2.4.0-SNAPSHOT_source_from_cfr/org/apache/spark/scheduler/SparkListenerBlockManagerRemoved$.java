/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerBlockManagerRemoved;
import org.apache.spark.storage.BlockManagerId;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;
import scala.runtime.BoxesRunTime;

public final class SparkListenerBlockManagerRemoved$
extends AbstractFunction2<Object, BlockManagerId, SparkListenerBlockManagerRemoved>
implements Serializable {
    public static final SparkListenerBlockManagerRemoved$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerBlockManagerRemoved$();
    }

    public final String toString() {
        return "SparkListenerBlockManagerRemoved";
    }

    public SparkListenerBlockManagerRemoved apply(long time, BlockManagerId blockManagerId) {
        return new SparkListenerBlockManagerRemoved(time, blockManagerId);
    }

    public Option<Tuple2<Object, BlockManagerId>> unapply(SparkListenerBlockManagerRemoved x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)BoxesRunTime.boxToLong((long)x$0.time()), (Object)x$0.blockManagerId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerBlockManagerRemoved$() {
        MODULE$ = this;
    }
}

