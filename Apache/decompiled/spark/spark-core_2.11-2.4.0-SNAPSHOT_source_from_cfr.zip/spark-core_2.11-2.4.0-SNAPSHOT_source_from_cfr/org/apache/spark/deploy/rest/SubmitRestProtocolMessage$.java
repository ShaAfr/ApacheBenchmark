/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.databind.DeserializationFeature
 *  com.fasterxml.jackson.databind.Module
 *  com.fasterxml.jackson.databind.ObjectMapper
 *  com.fasterxml.jackson.databind.SerializationFeature
 *  com.fasterxml.jackson.module.scala.DefaultScalaModule$
 *  org.apache.spark.deploy.rest.SubmitRestProtocolMessage$$anonfun
 *  org.apache.spark.deploy.rest.SubmitRestProtocolMessage$$anonfun$parseAction
 *  org.json4s.JsonAST
 *  org.json4s.JsonAST$JObject
 *  org.json4s.JsonAST$JValue
 *  org.json4s.JsonInput
 *  org.json4s.jackson.JsonMethods$
 *  org.json4s.package$
 *  scala.Function0
 *  scala.None$
 *  scala.Option
 *  scala.PartialFunction
 *  scala.Serializable
 *  scala.collection.immutable.List
 *  scala.collection.mutable.StringBuilder
 */
package org.apache.spark.deploy.rest;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.module.scala.DefaultScalaModule$;
import org.apache.spark.deploy.rest.SubmitRestProtocolMessage;
import org.apache.spark.deploy.rest.SubmitRestProtocolMessage$;
import org.apache.spark.util.Utils$;
import org.json4s.JsonAST;
import org.json4s.JsonInput;
import org.json4s.jackson.JsonMethods$;
import org.json4s.package$;
import scala.Function0;
import scala.None$;
import scala.Option;
import scala.PartialFunction;
import scala.Serializable;
import scala.collection.immutable.List;
import scala.collection.mutable.StringBuilder;

public final class SubmitRestProtocolMessage$ {
    public static final SubmitRestProtocolMessage$ MODULE$;
    private final String packagePrefix;
    private final ObjectMapper org$apache$spark$deploy$rest$SubmitRestProtocolMessage$$mapper;

    public static {
        new org.apache.spark.deploy.rest.SubmitRestProtocolMessage$();
    }

    private String packagePrefix() {
        return this.packagePrefix;
    }

    public ObjectMapper org$apache$spark$deploy$rest$SubmitRestProtocolMessage$$mapper() {
        return this.org$apache$spark$deploy$rest$SubmitRestProtocolMessage$$mapper;
    }

    public String parseAction(String json) {
        None$ none$;
        JsonAST.JValue jValue = JsonMethods$.MODULE$.parse(package$.MODULE$.string2JsonInput(json), JsonMethods$.MODULE$.parse$default$2(), JsonMethods$.MODULE$.parse$default$3());
        if (jValue instanceof JsonAST.JObject) {
            JsonAST.JObject jObject = (JsonAST.JObject)jValue;
            List fields = jObject.obj();
            none$ = fields.collectFirst((PartialFunction)new Serializable(){
                public static final long serialVersionUID = 0L;

                /*
                 * Enabled aggressive block sorting
                 */
                public final <A1 extends scala.Tuple2<String, JsonAST.JValue>, B1> B1 applyOrElse(A1 x1, scala.Function1<A1, B1> function1) {
                    Object object;
                    A1 A1 = x1;
                    if (A1 != null) {
                        String string = (String)A1._1();
                        JsonAST.JValue v = (JsonAST.JValue)A1._2();
                        if ("action".equals(string)) {
                            object = v;
                            return (B1)object;
                        }
                    }
                    object = function1.apply(x1);
                    return (B1)object;
                }

                public final boolean isDefinedAt(scala.Tuple2<String, JsonAST.JValue> x1) {
                    String string;
                    scala.Tuple2<String, JsonAST.JValue> tuple2 = x1;
                    boolean bl = tuple2 != null && "action".equals(string = (String)tuple2._1());
                    return bl;
                }
            }).collect((PartialFunction)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final <A1 extends JsonAST.JValue, B1> B1 applyOrElse(A1 x2, scala.Function1<A1, B1> function1) {
                    Object object;
                    A1 A1 = x2;
                    if (A1 instanceof org.json4s.JsonAST$JString) {
                        org.json4s.JsonAST$JString jString = (org.json4s.JsonAST$JString)A1;
                        String s = jString.s();
                        object = s;
                    } else {
                        object = function1.apply(x2);
                    }
                    return (B1)object;
                }

                public final boolean isDefinedAt(JsonAST.JValue x2) {
                    JsonAST.JValue jValue = x2;
                    boolean bl = jValue instanceof org.json4s.JsonAST$JString;
                    return bl;
                }
            });
        } else {
            none$ = None$.MODULE$;
        }
        None$ value2 = none$;
        return (String)value2.getOrElse((Function0)new Serializable(json){
            public static final long serialVersionUID = 0L;
            private final String json$1;

            public final scala.runtime.Nothing$ apply() {
                throw new org.apache.spark.deploy.rest.SubmitRestMissingFieldException(new scala.StringContext((scala.collection.Seq)scala.Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Action field not found in JSON:\\n", ""})).s((scala.collection.Seq)scala.Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.json$1})));
            }
            {
                this.json$1 = json$1;
            }
        });
    }

    public SubmitRestProtocolMessage fromJson(String json) {
        String className = this.parseAction(json);
        Class<SubmitRestProtocolMessage> clazz = Utils$.MODULE$.classForName(new StringBuilder().append((Object)this.packagePrefix()).append((Object)".").append((Object)className).toString()).asSubclass(SubmitRestProtocolMessage.class);
        return this.fromJson(json, clazz);
    }

    public <T extends SubmitRestProtocolMessage> T fromJson(String json, Class<T> clazz) {
        return (T)((SubmitRestProtocolMessage)this.org$apache$spark$deploy$rest$SubmitRestProtocolMessage$$mapper().readValue(json, clazz));
    }

    private SubmitRestProtocolMessage$() {
        MODULE$ = this;
        this.packagePrefix = this.getClass().getPackage().getName();
        this.org$apache$spark$deploy$rest$SubmitRestProtocolMessage$$mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).enable(SerializationFeature.INDENT_OUTPUT).registerModule((Module)DefaultScalaModule$.MODULE$);
    }
}

