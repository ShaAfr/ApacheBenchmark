/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.MatchError
 *  scala.Option
 *  scala.Tuple3
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy.master;

import org.apache.spark.SecurityManager;
import org.apache.spark.SecurityManager$;
import org.apache.spark.SparkConf;
import org.apache.spark.deploy.master.Master;
import org.apache.spark.deploy.master.MasterArguments;
import org.apache.spark.deploy.master.MasterMessages;
import org.apache.spark.deploy.master.MasterMessages$BoundPortsRequest$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.rpc.RpcAddress;
import org.apache.spark.rpc.RpcEndpoint;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.rpc.RpcEnv;
import org.apache.spark.rpc.RpcEnv$;
import org.apache.spark.util.SparkUncaughtExceptionHandler;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Function0;
import scala.MatchError;
import scala.Option;
import scala.Tuple3;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.BoxesRunTime;

public final class Master$
implements Logging {
    public static final Master$ MODULE$;
    private final String SYSTEM_NAME;
    private final String ENDPOINT_NAME;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.deploy.master.Master$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public String SYSTEM_NAME() {
        return this.SYSTEM_NAME;
    }

    public String ENDPOINT_NAME() {
        return this.ENDPOINT_NAME;
    }

    public void main(String[] argStrings) {
        Thread.setDefaultUncaughtExceptionHandler(new SparkUncaughtExceptionHandler(false));
        Utils$.MODULE$.initDaemon(this.log());
        SparkConf conf = new SparkConf();
        MasterArguments args = new MasterArguments(argStrings, conf);
        Tuple3<RpcEnv, Object, Option<Object>> tuple3 = this.startRpcEnvAndEndpoint(args.host(), args.port(), args.webUiPort(), conf);
        if (tuple3 != null) {
            RpcEnv rpcEnv;
            RpcEnv rpcEnv2;
            RpcEnv rpcEnv3 = rpcEnv2 = (rpcEnv = (RpcEnv)tuple3._1());
            rpcEnv3.awaitTermination();
            return;
        }
        throw new MatchError(tuple3);
    }

    public Tuple3<RpcEnv, Object, Option<Object>> startRpcEnvAndEndpoint(String host, int port, int webUiPort, SparkConf conf) {
        SecurityManager securityMgr = new SecurityManager(conf, SecurityManager$.MODULE$.$lessinit$greater$default$2());
        RpcEnv rpcEnv = RpcEnv$.MODULE$.create(this.SYSTEM_NAME(), host, port, conf, securityMgr, RpcEnv$.MODULE$.create$default$6());
        RpcEndpointRef masterEndpoint = rpcEnv.setupEndpoint(this.ENDPOINT_NAME(), new Master(rpcEnv, rpcEnv.address(), webUiPort, securityMgr, conf));
        MasterMessages.BoundPortsResponse portsResponse = (MasterMessages.BoundPortsResponse)masterEndpoint.askSync(MasterMessages$BoundPortsRequest$.MODULE$, ClassTag$.MODULE$.apply(MasterMessages.BoundPortsResponse.class));
        return new Tuple3((Object)rpcEnv, (Object)BoxesRunTime.boxToInteger((int)portsResponse.webUIPort()), portsResponse.restPort());
    }

    private Master$() {
        MODULE$ = this;
        Logging$class.$init$(this);
        this.SYSTEM_NAME = "sparkMaster";
        this.ENDPOINT_NAME = "Master";
    }
}

