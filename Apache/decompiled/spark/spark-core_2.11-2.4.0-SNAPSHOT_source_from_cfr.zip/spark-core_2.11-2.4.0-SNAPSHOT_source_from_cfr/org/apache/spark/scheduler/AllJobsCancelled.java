/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.collection.Iterator
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.AllJobsCancelled$;
import scala.collection.Iterator;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001];a!\u0001\u0002\t\u0002\nQ\u0011\u0001E!mY*{'m]\"b]\u000e,G\u000e\\3e\u0015\t\u0019A!A\u0005tG\",G-\u001e7fe*\u0011QAB\u0001\u0006gB\f'o\u001b\u0006\u0003\u000f!\ta!\u00199bG\",'\"A\u0005\u0002\u0007=\u0014x\r\u0005\u0002\f\u00195\t!A\u0002\u0004\u000e\u0005!\u0005%A\u0004\u0002\u0011\u00032d'j\u001c2t\u0007\u0006t7-\u001a7mK\u0012\u001cR\u0001D\b\u00161m\u0001\"\u0001E\n\u000e\u0003EQ\u0011AE\u0001\u0006g\u000e\fG.Y\u0005\u0003)E\u0011a!\u00118z%\u00164\u0007CA\u0006\u0017\u0013\t9\"AA\tE\u0003\u001e\u001b6\r[3ek2,'/\u0012<f]R\u0004\"\u0001E\r\n\u0005i\t\"a\u0002)s_\u0012,8\r\u001e\t\u0003!qI!!H\t\u0003\u0019M+'/[1mSj\f'\r\\3\t\u000b}aA\u0011A\u0011\u0002\rqJg.\u001b;?\u0007\u0001!\u0012A\u0003\u0005\bG1\t\t\u0011\"\u0011%\u00035\u0001(o\u001c3vGR\u0004&/\u001a4jqV\tQ\u0005\u0005\u0002'W5\tqE\u0003\u0002)S\u0005!A.\u00198h\u0015\u0005Q\u0013\u0001\u00026bm\u0006L!\u0001L\u0014\u0003\rM#(/\u001b8h\u0011\u001dqC\"!A\u0005\u0002=\nA\u0002\u001d:pIV\u001cG/\u0011:jif,\u0012\u0001\r\t\u0003!EJ!AM\t\u0003\u0007%sG\u000fC\u00045\u0019\u0005\u0005I\u0011A\u001b\u0002\u001dA\u0014x\u000eZ;di\u0016cW-\\3oiR\u0011a'\u000f\t\u0003!]J!\u0001O\t\u0003\u0007\u0005s\u0017\u0010C\u0004;g\u0005\u0005\t\u0019\u0001\u0019\u0002\u0007a$\u0013\u0007C\u0004=\u0019\u0005\u0005I\u0011I\u001f\u0002\u001fA\u0014x\u000eZ;di&#XM]1u_J,\u0012A\u0010\t\u0004\t3T\"\u0001!\u000b\u0005\u0005\u000b\u0012AC2pY2,7\r^5p]&\u00111\t\u0011\u0002\t\u0013R,'/\u0019;pe\"9Q\tDA\u0001\n\u00031\u0015\u0001C2b]\u0016\u000bX/\u00197\u0015\u0005\u001dS\u0005C\u0001\tI\u0013\tI\u0015CA\u0004C_>dW-\u00198\t\u000fi\"\u0015\u0011!a\u0001m!9A\nDA\u0001\n\u0003j\u0015\u0001\u00035bg\"\u001cu\u000eZ3\u0015\u0003ABqa\u0014\u0007\u0002\u0002\u0013\u0005\u0003+\u0001\u0005u_N#(/\u001b8h)\u0005)\u0003b\u0002*\r\u0003\u0003%IaU\u0001\fe\u0016\fGMU3t_24X\rF\u0001U!\t1S+\u0003\u0002WO\t1qJ\u00196fGR\u0004")
public final class AllJobsCancelled {
    public static String toString() {
        return AllJobsCancelled$.MODULE$.toString();
    }

    public static int hashCode() {
        return AllJobsCancelled$.MODULE$.hashCode();
    }

    public static boolean canEqual(Object object) {
        return AllJobsCancelled$.MODULE$.canEqual(object);
    }

    public static Iterator<Object> productIterator() {
        return AllJobsCancelled$.MODULE$.productIterator();
    }

    public static Object productElement(int n) {
        return AllJobsCancelled$.MODULE$.productElement(n);
    }

    public static int productArity() {
        return AllJobsCancelled$.MODULE$.productArity();
    }

    public static String productPrefix() {
        return AllJobsCancelled$.MODULE$.productPrefix();
    }
}

