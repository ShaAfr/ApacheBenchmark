/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.CleanAccum;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;
import scala.runtime.BoxesRunTime;

public final class CleanAccum$
extends AbstractFunction1<Object, CleanAccum>
implements Serializable {
    public static final CleanAccum$ MODULE$;

    public static {
        new org.apache.spark.CleanAccum$();
    }

    public final String toString() {
        return "CleanAccum";
    }

    public CleanAccum apply(long accId) {
        return new CleanAccum(accId);
    }

    public Option<Object> unapply(CleanAccum x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)BoxesRunTime.boxToLong((long)x$0.accId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private CleanAccum$() {
        MODULE$ = this;
    }
}

