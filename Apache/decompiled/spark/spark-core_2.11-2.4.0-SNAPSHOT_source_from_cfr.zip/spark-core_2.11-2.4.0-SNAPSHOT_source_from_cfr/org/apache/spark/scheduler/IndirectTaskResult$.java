/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.IndirectTaskResult;
import org.apache.spark.storage.BlockId;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.BoxesRunTime;

public final class IndirectTaskResult$
implements Serializable {
    public static final IndirectTaskResult$ MODULE$;

    public static {
        new org.apache.spark.scheduler.IndirectTaskResult$();
    }

    public final String toString() {
        return "IndirectTaskResult";
    }

    public <T> IndirectTaskResult<T> apply(BlockId blockId, int size) {
        return new IndirectTaskResult(blockId, size);
    }

    public <T> Option<Tuple2<BlockId, Object>> unapply(IndirectTaskResult<T> x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)x$0.blockId(), (Object)BoxesRunTime.boxToInteger((int)x$0.size())));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private IndirectTaskResult$() {
        MODULE$ = this;
    }
}

