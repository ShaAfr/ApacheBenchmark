/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.network.netty.SparkTransportConf$$anon
 *  org.apache.spark.network.util.ConfigProvider
 *  org.apache.spark.network.util.TransportConf
 *  scala.Predef$
 *  scala.StringContext
 *  scala.collection.Seq
 *  scala.collection.mutable.WrappedArray
 *  scala.math.package$
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.network.netty;

import org.apache.spark.SparkConf;
import org.apache.spark.network.netty.SparkTransportConf$;
import org.apache.spark.network.util.ConfigProvider;
import org.apache.spark.network.util.TransportConf;
import scala.Predef$;
import scala.StringContext;
import scala.collection.Seq;
import scala.collection.mutable.WrappedArray;
import scala.math.package$;
import scala.runtime.BoxesRunTime;

public final class SparkTransportConf$ {
    public static final SparkTransportConf$ MODULE$;
    private final int MAX_DEFAULT_NETTY_THREADS;

    public static {
        new org.apache.spark.network.netty.SparkTransportConf$();
    }

    private int MAX_DEFAULT_NETTY_THREADS() {
        return this.MAX_DEFAULT_NETTY_THREADS;
    }

    public TransportConf fromSparkConf(SparkConf _conf, String module, int numUsableCores) {
        SparkConf conf = _conf.clone();
        int numThreads = this.defaultNumThreads(numUsableCores);
        conf.setIfMissing(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"spark.", ".io.serverThreads"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{module})), ((Object)BoxesRunTime.boxToInteger((int)numThreads)).toString());
        conf.setIfMissing(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"spark.", ".io.clientThreads"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{module})), ((Object)BoxesRunTime.boxToInteger((int)numThreads)).toString());
        return new TransportConf(module, new ConfigProvider(conf){
            private final SparkConf conf$1;

            public String get(String name2) {
                return this.conf$1.get(name2);
            }

            public String get(String name2, String defaultValue) {
                return this.conf$1.get(name2, defaultValue);
            }

            public java.lang.Iterable<java.util.Map$Entry<String, String>> getAll() {
                return ((java.util.Map)scala.collection.JavaConverters$.MODULE$.mapAsJavaMapConverter((scala.collection.Map)Predef$.MODULE$.refArrayOps((Object[])this.conf$1.getAll()).toMap(Predef$.MODULE$.$conforms())).asJava()).entrySet();
            }
            {
                this.conf$1 = conf$1;
            }
        });
    }

    public int fromSparkConf$default$3() {
        return 0;
    }

    private int defaultNumThreads(int numUsableCores) {
        int availableCores = numUsableCores > 0 ? numUsableCores : Runtime.getRuntime().availableProcessors();
        return package$.MODULE$.min(availableCores, this.MAX_DEFAULT_NETTY_THREADS());
    }

    private SparkTransportConf$() {
        MODULE$ = this;
        this.MAX_DEFAULT_NETTY_THREADS = 8;
    }
}

