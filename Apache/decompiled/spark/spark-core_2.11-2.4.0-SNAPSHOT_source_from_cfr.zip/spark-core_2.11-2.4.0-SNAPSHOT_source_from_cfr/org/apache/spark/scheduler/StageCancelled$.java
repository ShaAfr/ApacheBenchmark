/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.StageCancelled;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;
import scala.runtime.BoxesRunTime;

public final class StageCancelled$
extends AbstractFunction2<Object, Option<String>, StageCancelled>
implements Serializable {
    public static final StageCancelled$ MODULE$;

    public static {
        new org.apache.spark.scheduler.StageCancelled$();
    }

    public final String toString() {
        return "StageCancelled";
    }

    public StageCancelled apply(int stageId, Option<String> reason) {
        return new StageCancelled(stageId, reason);
    }

    public Option<Tuple2<Object, Option<String>>> unapply(StageCancelled x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)x$0.stageId()), x$0.reason()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private StageCancelled$() {
        MODULE$ = this;
    }
}

