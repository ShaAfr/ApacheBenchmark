/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Function1
 *  scala.Option
 *  scala.Product
 *  scala.Product$class
 *  scala.Serializable
 *  scala.Tuple6
 *  scala.collection.Iterator
 *  scala.collection.Map
 *  scala.collection.Seq
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.ScalaRunTime$
 */
package org.apache.spark.deploy;

import org.apache.spark.deploy.Command$;
import scala.Function1;
import scala.Option;
import scala.Product;
import scala.Serializable;
import scala.Tuple6;
import scala.collection.Iterator;
import scala.collection.Map;
import scala.collection.Seq;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxesRunTime;
import scala.runtime.ScalaRunTime$;

@ScalaSignature(bytes="\u0006\u0001\u0005\u0015f!B\u0001\u0003\u0001\u0012Q!aB\"p[6\fg\u000e\u001a\u0006\u0003\u0007\u0011\ta\u0001Z3qY>L(BA\u0003\u0007\u0003\u0015\u0019\b/\u0019:l\u0015\t9\u0001\"\u0001\u0004ba\u0006\u001c\u0007.\u001a\u0006\u0002\u0013\u0005\u0019qN]4\u0014\t\u0001Y\u0011\u0003\u0006\t\u0003\u0019=i\u0011!\u0004\u0006\u0002\u001d\u0005)1oY1mC&\u0011\u0001#\u0004\u0002\u0007\u0003:L(+\u001a4\u0011\u00051\u0011\u0012BA\n\u000e\u0005\u001d\u0001&o\u001c3vGR\u0004\"\u0001D\u000b\n\u0005Yi!\u0001D*fe&\fG.\u001b>bE2,\u0007\u0002\u0003\r\u0001\u0005+\u0007I\u0011\u0001\u000e\u0002\u00135\f\u0017N\\\"mCN\u001c8\u0001A\u000b\u00027A\u0011Ad\b\b\u0003\u0019uI!AH\u0007\u0002\rA\u0013X\rZ3g\u0013\t\u0001\u0013E\u0001\u0004TiJLgn\u001a\u0006\u0003=5A\u0001b\t\u0001\u0003\u0012\u0003\u0006IaG\u0001\u000b[\u0006Lgn\u00117bgN\u0004\u0003\u0002C\u0013\u0001\u0005+\u0007I\u0011\u0001\u0014\u0002\u0013\u0005\u0014x-^7f]R\u001cX#A\u0014\u0011\u0007!\u00024D\u0004\u0002*]9\u0011!&L\u0007\u0002W)\u0011A&G\u0001\u0007yI|w\u000e\u001e \n\u00039I!aL\u0007\u0002\u000fA\f7m[1hK&\u0011\u0011G\r\u0002\u0004'\u0016\f(BA\u0018\u000e\u0011!!\u0004A!E!\u0002\u00139\u0013AC1sOVlWM\u001c;tA!Aa\u0007\u0001BK\u0002\u0013\u0005q'A\u0006f]ZL'o\u001c8nK:$X#\u0001\u001d\u0011\teb4dG\u0007\u0002u)\u00111(D\u0001\u000bG>dG.Z2uS>t\u0017BA\u001f;\u0005\ri\u0015\r\u001d\u0005\t\u0001\u0011\t\u0012)A\u0005q\u0005aQM\u001c<je>tW.\u001a8uA!A\u0011\t\u0001BK\u0002\u0013\u0005a%\u0001\tdY\u0006\u001c8\u000fU1uQ\u0016sGO]5fg\"A1\t\u0001B\tB\u0003%q%A\tdY\u0006\u001c8\u000fU1uQ\u0016sGO]5fg\u0002B\u0001\"\u0012\u0001\u0003\u0016\u0004%\tAJ\u0001\u0013Y&\u0014'/\u0019:z!\u0006$\b.\u00128ue&,7\u000f\u0003\u0005H\u0001\tE\t\u0015!\u0003(\u0003Ma\u0017N\u0019:bef\u0004\u0016\r\u001e5F]R\u0014\u0018.Z:!\u0011!I\u0005A!f\u0001\n\u00031\u0013\u0001\u00036bm\u0006|\u0005\u000f^:\t\u0011-\u0003!\u0011#Q\u0001\n\u001d\n\u0011B[1wC>\u0003Ho\u001d\u0011\t\u000b5\u0003A\u0011\u0001(\u0002\rqJg.\u001b;?)\u001dy\u0015KU*U+Z\u0003\"\u0001\u0015\u0001\u000e\u0003\tAQ\u0001\u0007'A\u0002mAQ!\n'A\u0002\u001dBQA\u000e'A\u0002aBQ!\u0011'A\u0002\u001dBQ!\u0012'A\u0002\u001dBQ!\u0013'A\u0002\u001dBq\u0001\u0017\u0001\u0002\u0002\u0013\u0005\u0011,\u0001\u0003d_BLHcB([7rkfl\u0018\u0005\b1]\u0003\n\u00111\u0001\u001c\u0011\u001d)s\u000b%AA\u0002\u001dBqAN,\u0011\u0002\u0003\u0007\u0001\bC\u0004B/B\u0005\t\u0019A\u0014\t\u000f\u0015;\u0006\u0013!a\u0001O!9\u0011j\u0016I\u0001\u0002\u00049\u0003bB1\u0001#\u0003%\tAY\u0001\u000fG>\u0004\u0018\u0010\n3fM\u0006,H\u000e\u001e\u00132+\u0005\u0019'FA\u000eeW\u0005)\u0007C\u00014l\u001b\u00059'B\u00015j\u0003%)hn\u00195fG.,GM\u0003\u0002k\u001b\u0005Q\u0011M\u001c8pi\u0006$\u0018n\u001c8\n\u00051<'!E;oG\",7m[3e-\u0006\u0014\u0018.\u00198dK\"9a\u000eAI\u0001\n\u0003y\u0017AD2paf$C-\u001a4bk2$HEM\u000b\u0002a*\u0012q\u0005\u001a\u0005\be\u0002\t\n\u0011\"\u0001t\u00039\u0019w\u000e]=%I\u00164\u0017-\u001e7uIM*\u0012\u0001\u001e\u0016\u0003q\u0011DqA\u001e\u0001\u0012\u0002\u0013\u0005q.\u0001\bd_BLH\u0005Z3gCVdG\u000f\n\u001b\t\u000fa\u0004\u0011\u0013!C\u0001_\u0006q1m\u001c9zI\u0011,g-Y;mi\u0012*\u0004b\u0002>\u0001#\u0003%\ta\\\u0001\u000fG>\u0004\u0018\u0010\n3fM\u0006,H\u000e\u001e\u00137\u0011\u001da\b!!A\u0005Bu\fQ\u0002\u001d:pIV\u001cG\u000f\u0015:fM&DX#\u0001@\u0011\u0007}\fI!\u0004\u0002\u0002\u0002)!\u00111AA\u0003\u0003\u0011a\u0017M\\4\u000b\u0005\u0005\u001d\u0011\u0001\u00026bm\u0006L1\u0001IA\u0001\u0011%\ti\u0001AA\u0001\n\u0003\ty!\u0001\u0007qe>$Wo\u0019;Be&$\u00180\u0006\u0002\u0002\u0012A\u0019A\"a\u0005\n\u0007\u0005UQBA\u0002J]RD\u0011\"!\u0007\u0001\u0003\u0003%\t!a\u0007\u0002\u001dA\u0014x\u000eZ;di\u0016cW-\\3oiR!\u0011QDA\u0012!\ra\u0011qD\u0005\u0004\u0003Ci!aA!os\"Q\u0011QEA\f\u0003\u0003\u0005\r!!\u0005\u0002\u0007a$\u0013\u0007C\u0005\u0002*\u0001\t\t\u0011\"\u0011\u0002,\u0005y\u0001O]8ek\u000e$\u0018\n^3sCR|'/\u0006\u0002\u0002.A)\u0011(a\f\u0002\u001e%\u0019\u0011\u0011\u0007\u001e\u0003\u0011%#XM]1u_JD\u0011\"!\u000e\u0001\u0003\u0003%\t!a\u000e\u0002\u0011\r\fg.R9vC2$B!!\u000f\u0002@A\u0019A\"a\u000f\n\u0007\u0005uRBA\u0004C_>dW-\u00198\t\u0015\u0005\u0015\u00121GA\u0001\u0002\u0004\ti\u0002C\u0005\u0002D\u0001\t\t\u0011\"\u0011\u0002F\u0005A\u0001.Y:i\u0007>$W\r\u0006\u0002\u0002\u0012!I\u0011\u0011\n\u0001\u0002\u0002\u0013\u0005\u00131J\u0001\ti>\u001cFO]5oOR\ta\u0010C\u0005\u0002P\u0001\t\t\u0011\"\u0011\u0002R\u00051Q-];bYN$B!!\u000f\u0002T!Q\u0011QEA'\u0003\u0003\u0005\r!!\b\b\u0015\u0005]#!!A\t\u0002\u0011\tI&A\u0004D_6l\u0017M\u001c3\u0011\u0007A\u000bYFB\u0005\u0002\u0005\u0005\u0005\t\u0012\u0001\u0003\u0002^M)\u00111LA0)AY\u0011\u0011MA47\u001dBteJ\u0014P\u001b\t\t\u0019GC\u0002\u0002f5\tqA];oi&lW-\u0003\u0003\u0002j\u0005\r$!E!cgR\u0014\u0018m\u0019;Gk:\u001cG/[8om!9Q*a\u0017\u0005\u0002\u00055DCAA-\u0011)\tI%a\u0017\u0002\u0002\u0013\u0015\u00131\n\u0005\u000b\u0003g\nY&!A\u0005\u0002\u0006U\u0014!B1qa2LH#D(\u0002x\u0005e\u00141PA?\u0003\n\t\t\u0003\u0004\u0019\u0003c\u0002\ra\u0007\u0005\u0007K\u0005E\u0004\u0019A\u0014\t\rY\n\t\b1\u00019\u0011\u0019\t\u0015\u0011\u000fa\u0001O!1Q)!\u001dA\u0002\u001dBa!SA9\u0001\u00049\u0003BCAC\u00037\n\t\u0011\"!\u0002\b\u00069QO\\1qa2LH\u0003BAE\u0003+\u0003R\u0001DAF\u0003\u001fK1!!$\u000e\u0005\u0019y\u0005\u000f^5p]BIA\"!%\u001cOa:seJ\u0005\u0004\u0003'k!A\u0002+va2,g\u0007C\u0005\u0002\u0018\u0006\r\u0015\u0011!a\u0001\u001f\u0006\u0019\u0001\u0010\n\u0019\t\u0015\u0005m\u00151LA\u0001\n\u0013\ti*A\u0006sK\u0006$'+Z:pYZ,GCAAP!\ry\u0018\u0011U\u0005\u0005\u0003G\u000b\tA\u0001\u0004PE*,7\r\u001e")
public class Command
implements Product,
Serializable {
    private final String mainClass;
    private final Seq<String> arguments;
    private final Map<String, String> environment;
    private final Seq<String> classPathEntries;
    private final Seq<String> libraryPathEntries;
    private final Seq<String> javaOpts;

    public static Option<Tuple6<String, Seq<String>, Map<String, String>, Seq<String>, Seq<String>, Seq<String>>> unapply(Command command) {
        return Command$.MODULE$.unapply(command);
    }

    public static Command apply(String string, Seq<String> seq, Map<String, String> map2, Seq<String> seq2, Seq<String> seq3, Seq<String> seq4) {
        return Command$.MODULE$.apply(string, seq, map2, seq2, seq3, seq4);
    }

    public static Function1<Tuple6<String, Seq<String>, Map<String, String>, Seq<String>, Seq<String>, Seq<String>>, Command> tupled() {
        return Command$.MODULE$.tupled();
    }

    public static Function1<String, Function1<Seq<String>, Function1<Map<String, String>, Function1<Seq<String>, Function1<Seq<String>, Function1<Seq<String>, Command>>>>>> curried() {
        return Command$.MODULE$.curried();
    }

    public String mainClass() {
        return this.mainClass;
    }

    public Seq<String> arguments() {
        return this.arguments;
    }

    public Map<String, String> environment() {
        return this.environment;
    }

    public Seq<String> classPathEntries() {
        return this.classPathEntries;
    }

    public Seq<String> libraryPathEntries() {
        return this.libraryPathEntries;
    }

    public Seq<String> javaOpts() {
        return this.javaOpts;
    }

    public Command copy(String mainClass, Seq<String> arguments, Map<String, String> environment, Seq<String> classPathEntries, Seq<String> libraryPathEntries, Seq<String> javaOpts) {
        return new Command(mainClass, arguments, environment, classPathEntries, libraryPathEntries, javaOpts);
    }

    public String copy$default$1() {
        return this.mainClass();
    }

    public Seq<String> copy$default$2() {
        return this.arguments();
    }

    public Map<String, String> copy$default$3() {
        return this.environment();
    }

    public Seq<String> copy$default$4() {
        return this.classPathEntries();
    }

    public Seq<String> copy$default$5() {
        return this.libraryPathEntries();
    }

    public Seq<String> copy$default$6() {
        return this.javaOpts();
    }

    public String productPrefix() {
        return "Command";
    }

    public int productArity() {
        return 6;
    }

    public Object productElement(int x$1) {
        Object object;
        int n = x$1;
        switch (n) {
            default: {
                throw new IndexOutOfBoundsException(((Object)BoxesRunTime.boxToInteger((int)x$1)).toString());
            }
            case 5: {
                object = this.javaOpts();
                break;
            }
            case 4: {
                object = this.libraryPathEntries();
                break;
            }
            case 3: {
                object = this.classPathEntries();
                break;
            }
            case 2: {
                object = this.environment();
                break;
            }
            case 1: {
                object = this.arguments();
                break;
            }
            case 0: {
                object = this.mainClass();
            }
        }
        return object;
    }

    public Iterator<Object> productIterator() {
        return ScalaRunTime$.MODULE$.typedProductIterator((Product)this);
    }

    public boolean canEqual(Object x$1) {
        return x$1 instanceof Command;
    }

    public int hashCode() {
        return ScalaRunTime$.MODULE$._hashCode((Product)this);
    }

    public String toString() {
        return ScalaRunTime$.MODULE$._toString((Product)this);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object x$1) {
        Seq<String> seq;
        Seq<String> seq2;
        Seq<String> seq3;
        Seq<String> seq4;
        String string;
        Map<String, String> map2;
        if (this == x$1) return true;
        Object object = x$1;
        if (!(object instanceof Command)) return false;
        boolean bl = true;
        if (!bl) return false;
        Command command = (Command)x$1;
        String string2 = command.mainClass();
        if (this.mainClass() == null) {
            if (string2 != null) {
                return false;
            }
        } else if (!string.equals(string2)) return false;
        Seq<String> seq5 = command.arguments();
        if (this.arguments() == null) {
            if (seq5 != null) {
                return false;
            }
        } else if (!seq.equals(seq5)) return false;
        Map<String, String> map3 = command.environment();
        if (this.environment() == null) {
            if (map3 != null) {
                return false;
            }
        } else if (!map2.equals(map3)) return false;
        Seq<String> seq6 = command.classPathEntries();
        if (this.classPathEntries() == null) {
            if (seq6 != null) {
                return false;
            }
        } else if (!seq2.equals(seq6)) return false;
        Seq<String> seq7 = command.libraryPathEntries();
        if (this.libraryPathEntries() == null) {
            if (seq7 != null) {
                return false;
            }
        } else if (!seq3.equals(seq7)) return false;
        Seq<String> seq8 = command.javaOpts();
        if (this.javaOpts() == null) {
            if (seq8 != null) {
                return false;
            }
        } else if (!seq4.equals(seq8)) return false;
        if (!command.canEqual(this)) return false;
        return true;
    }

    public Command(String mainClass, Seq<String> arguments, Map<String, String> environment, Seq<String> classPathEntries, Seq<String> libraryPathEntries, Seq<String> javaOpts) {
        this.mainClass = mainClass;
        this.arguments = arguments;
        this.environment = environment;
        this.classPathEntries = classPathEntries;
        this.libraryPathEntries = libraryPathEntries;
        this.javaOpts = javaOpts;
        Product.class.$init$((Product)this);
    }
}

