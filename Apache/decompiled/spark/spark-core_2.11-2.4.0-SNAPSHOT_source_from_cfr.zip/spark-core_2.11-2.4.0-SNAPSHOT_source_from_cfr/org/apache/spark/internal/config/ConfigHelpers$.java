/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.internal.config.ConfigHelpers$$anonfun
 *  org.apache.spark.internal.config.ConfigHelpers$$anonfun$stringToSeq
 *  org.apache.spark.network.util.ByteUnit
 *  org.apache.spark.network.util.JavaUtils
 *  scala.Array$
 *  scala.Function1
 *  scala.MatchError
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$DummyImplicit
 *  scala.Predef$DummyImplicit$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.Tuple2
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.BoxesRunTime
 *  scala.util.matching.Regex
 */
package org.apache.spark.internal.config;

import java.util.concurrent.TimeUnit;
import java.util.regex.PatternSyntaxException;
import org.apache.spark.internal.config.ConfigHelpers$;
import org.apache.spark.network.util.ByteUnit;
import org.apache.spark.network.util.JavaUtils;
import scala.Array$;
import scala.Function1;
import scala.MatchError;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.Tuple2;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.BoxesRunTime;
import scala.util.matching.Regex;

public final class ConfigHelpers$ {
    public static final ConfigHelpers$ MODULE$;

    public static {
        new org.apache.spark.internal.config.ConfigHelpers$();
    }

    public <T> T toNumber(String s, Function1<String, T> converter, String key, String configType) {
        try {
            return (T)converter.apply((Object)s.trim());
        }
        catch (NumberFormatException numberFormatException) {
            throw new IllegalArgumentException(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " should be ", ", but was ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{key, configType, s})));
        }
    }

    public boolean toBoolean(String s, String key) {
        try {
            return new StringOps(Predef$.MODULE$.augmentString(s.trim())).toBoolean();
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw new IllegalArgumentException(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " should be boolean, but was ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{key, s})));
        }
    }

    public <T> Seq<T> stringToSeq(String str, Function1<String, T> converter) {
        return (Seq)Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])str.split(",")).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(String x$1) {
                return x$1.trim();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.apply(String.class)))).filter((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply(String x$2) {
                return new StringOps(Predef$.MODULE$.augmentString(x$2)).nonEmpty();
            }
        })).map(converter, Array$.MODULE$.fallbackCanBuildFrom(Predef.DummyImplicit$.MODULE$.dummyImplicit()));
    }

    public <T> String seqToString(Seq<T> v, Function1<T, String> stringConverter) {
        return ((TraversableOnce)v.map(stringConverter, Seq$.MODULE$.canBuildFrom())).mkString(",");
    }

    public long timeFromString(String str, TimeUnit unit) {
        return JavaUtils.timeStringAs((String)str, (TimeUnit)unit);
    }

    public String timeToString(long v, TimeUnit unit) {
        return new StringBuilder().append(TimeUnit.MILLISECONDS.convert(v, unit)).append((Object)"ms").toString();
    }

    public long byteFromString(String str, ByteUnit unit) {
        Tuple2 tuple2;
        Tuple2 tuple22 = tuple2 = str.length() > 0 && str.charAt(0) == '-' ? new Tuple2((Object)str.substring(1), (Object)BoxesRunTime.boxToInteger((int)-1)) : new Tuple2((Object)str, (Object)BoxesRunTime.boxToInteger((int)1));
        if (tuple2 != null) {
            Tuple2 tuple23;
            String input = (String)tuple2._1();
            int multiplier = tuple2._2$mcI$sp();
            Tuple2 tuple24 = tuple23 = new Tuple2((Object)input, (Object)BoxesRunTime.boxToInteger((int)multiplier));
            String input2 = (String)tuple24._1();
            int multiplier2 = tuple24._2$mcI$sp();
            return (long)multiplier2 * JavaUtils.byteStringAs((String)input2, (ByteUnit)unit);
        }
        throw new MatchError((Object)tuple2);
    }

    public String byteToString(long v, ByteUnit unit) {
        return new StringBuilder().append(unit.convertTo(v, ByteUnit.BYTE)).append((Object)"b").toString();
    }

    public Regex regexFromString(String str, String key) {
        try {
            return new StringOps(Predef$.MODULE$.augmentString(str)).r();
        }
        catch (PatternSyntaxException patternSyntaxException) {
            throw new IllegalArgumentException(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " should be a regex, but was ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{key, str})), patternSyntaxException);
        }
    }

    private ConfigHelpers$() {
        MODULE$ = this;
    }
}

