/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.scheduler.ReplayListenerBus$$anonfun
 *  scala.Function1
 *  scala.Serializable
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.ReplayListenerBus$;
import scala.Function1;
import scala.Serializable;

public final class ReplayListenerBus$ {
    public static final ReplayListenerBus$ MODULE$;
    private final Function1<String, Object> SELECT_ALL_FILTER;

    public static {
        new org.apache.spark.scheduler.ReplayListenerBus$();
    }

    public Function1<String, Object> SELECT_ALL_FILTER() {
        return this.SELECT_ALL_FILTER;
    }

    private ReplayListenerBus$() {
        MODULE$ = this;
        this.SELECT_ALL_FILTER = new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply(String eventString) {
                return true;
            }
        };
    }
}

