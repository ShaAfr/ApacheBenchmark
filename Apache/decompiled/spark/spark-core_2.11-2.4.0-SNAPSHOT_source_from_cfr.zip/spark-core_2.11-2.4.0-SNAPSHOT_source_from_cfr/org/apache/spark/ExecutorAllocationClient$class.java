/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Predef$
 *  scala.collection.GenTraversable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.mutable.WrappedArray
 */
package org.apache.spark;

import org.apache.spark.ExecutorAllocationClient;
import scala.Predef$;
import scala.collection.GenTraversable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.mutable.WrappedArray;

public abstract class ExecutorAllocationClient$class {
    public static boolean killExecutor(ExecutorAllocationClient $this, String executorId) {
        Seq<String> killedExecutors = $this.killExecutors((Seq<String>)((Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{executorId}))), $this.killExecutors$default$2(), $this.killExecutors$default$3());
        return killedExecutors.nonEmpty() && ((String)killedExecutors.apply(0)).equals(executorId);
    }

    public static boolean killExecutors$default$2(ExecutorAllocationClient $this) {
        return false;
    }

    public static boolean killExecutors$default$3(ExecutorAllocationClient $this) {
        return false;
    }

    public static void $init$(ExecutorAllocationClient $this) {
    }
}

