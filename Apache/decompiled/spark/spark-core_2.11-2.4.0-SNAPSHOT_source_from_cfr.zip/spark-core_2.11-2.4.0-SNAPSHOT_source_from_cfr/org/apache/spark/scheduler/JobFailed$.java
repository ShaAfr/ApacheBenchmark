/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.JobFailed;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class JobFailed$
extends AbstractFunction1<Exception, JobFailed>
implements Serializable {
    public static final JobFailed$ MODULE$;

    public static {
        new org.apache.spark.scheduler.JobFailed$();
    }

    public final String toString() {
        return "JobFailed";
    }

    public JobFailed apply(Exception exception2) {
        return new JobFailed(exception2);
    }

    public Option<Exception> unapply(JobFailed x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.exception());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private JobFailed$() {
        MODULE$ = this;
    }
}

