/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.scheduler;

import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001E2\u0001\"\u0001\u0002\u0011\u0002G\u0005\"A\u0003\u0002\u0012\t\u0006;5k\u00195fIVdWM]#wK:$(BA\u0002\u0005\u0003%\u00198\r[3ek2,'O\u0003\u0002\u0006\r\u0005)1\u000f]1sW*\u0011q\u0001C\u0001\u0007CB\f7\r[3\u000b\u0003%\t1a\u001c:h'\t\u00011\u0002\u0005\u0002\r\u001f5\tQBC\u0001\u000f\u0003\u0015\u00198-\u00197b\u0013\t\u0001RB\u0001\u0004B]f\u0014VMZ\u0002\u0001SA\u00011#F\f\u001a7uy\u0012eI\u0013(S-jsF\u0003\u0002\u0015\u0005\u0005\u0001\u0012\t\u001c7K_\n\u001c8)\u00198dK2dW\rZ\u0005\u0003-\t\u0011!BQ3hS:,e/\u001a8u\u0013\tA\"AA\bD_6\u0004H.\u001a;j_:,e/\u001a8u\u0013\tQ\"AA\u0007Fq\u0016\u001cW\u000f^8s\u0003\u0012$W\rZ\u0005\u00039\t\u0011A\"\u0012=fGV$xN\u001d'pgRL!A\b\u0002\u0003%\u001d+G\u000f^5oOJ+7/\u001e7u\u000bZ,g\u000e^\u0005\u0003A\t\u0011ABS8c\u0007\u0006t7-\u001a7mK\u0012L!A\t\u0002\u0003#){'m\u0012:pkB\u001c\u0015M\\2fY2,G-\u0003\u0002%\u0005\ta!j\u001c2Tk\nl\u0017\u000e\u001e;fI&\u0011aE\u0001\u0002\u0012\u001b\u0006\u00048\u000b^1hKN+(-\\5ui\u0016$'B\u0001\u0015\u0003\u0003Q\u0011Vm];c[&$h)Y5mK\u0012\u001cF/Y4fg&\u0011!F\u0001\u0002\u0019'B,7-\u001e7bi&4X\rV1tWN+(-\\5ui\u0016$\u0017B\u0001\u0017\u0003\u00059\u0019F/Y4f\u0007\u0006t7-\u001a7mK\u0012L!A\f\u0002\u0003\u001bQ\u000b7o[*fi\u001a\u000b\u0017\u000e\\3e\u0013\t\u0001$AA\u0007X_J\\WM\u001d*f[>4X\r\u001a")
public interface DAGSchedulerEvent {
}

