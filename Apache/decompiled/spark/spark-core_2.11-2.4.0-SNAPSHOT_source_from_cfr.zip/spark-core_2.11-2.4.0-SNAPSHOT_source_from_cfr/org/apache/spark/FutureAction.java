/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Function1
 *  scala.Option
 *  scala.collection.Seq
 *  scala.concurrent.CanAwait
 *  scala.concurrent.ExecutionContext
 *  scala.concurrent.Future
 *  scala.concurrent.duration.Duration
 *  scala.reflect.ScalaSignature
 *  scala.util.Try
 */
package org.apache.spark;

import org.apache.spark.SparkException;
import scala.Function1;
import scala.Option;
import scala.collection.Seq;
import scala.concurrent.CanAwait;
import scala.concurrent.ExecutionContext;
import scala.concurrent.Future;
import scala.concurrent.duration.Duration;
import scala.reflect.ScalaSignature;
import scala.util.Try;

@ScalaSignature(bytes="\u0006\u0001\u0005ufaB\u0001\u0003!\u0003\r\t!\u0003\u0002\r\rV$XO]3BGRLwN\u001c\u0006\u0003\u0007\u0011\tQa\u001d9be.T!!\u0002\u0004\u0002\r\u0005\u0004\u0018m\u00195f\u0015\u00059\u0011aA8sO\u000e\u0001QC\u0001\u0006\u001a'\r\u00011\"\u0005\t\u0003\u0019=i\u0011!\u0004\u0006\u0002\u001d\u0005)1oY1mC&\u0011\u0001#\u0004\u0002\u0007\u0003:L(+\u001a4\u0011\u0007I)r#D\u0001\u0014\u0015\t!R\"\u0001\u0006d_:\u001cWO\u001d:f]RL!AF\n\u0003\r\u0019+H/\u001e:f!\tA\u0012\u0004\u0004\u0001\u0005\u000bi\u0001!\u0019A\u000e\u0003\u0003Q\u000b\"\u0001H\u0010\u0011\u00051i\u0012B\u0001\u0010\u000e\u0005\u001dqu\u000e\u001e5j]\u001e\u0004\"\u0001\u0004\u0011\n\u0005\u0005j!aA!os\")1\u0005\u0001C\u0001I\u00051A%\u001b8ji\u0012\"\u0012!\n\t\u0003\u0019\u0019J!aJ\u0007\u0003\tUs\u0017\u000e\u001e\u0005\u0006S\u00011\t\u0001J\u0001\u0007G\u0006t7-\u001a7\t\u000b-\u0002a\u0011\t\u0017\u0002\u000bI,\u0017\rZ=\u0015\u00055\"DC\u0001\u00180\u001b\u0005\u0001\u0001\"\u0002\u0019+\u0001\b\t\u0014A\u00029fe6LG\u000f\u0005\u0002\u0013e%\u00111g\u0005\u0002\t\u0007\u0006t\u0017i^1ji\")QG\u000ba\u0001m\u00051\u0011\r^'pgR\u0004\"a\u000e\u001e\u000e\u0003aR!!O\n\u0002\u0011\u0011,(/\u0019;j_:L!a\u000f\u001d\u0003\u0011\u0011+(/\u0019;j_:DQ!\u0010\u0001\u0007By\naA]3tk2$HCA B)\t9\u0002\tC\u00031y\u0001\u000f\u0011\u0007C\u00036y\u0001\u0007a\u0007K\u0002=\u0007J\u00032\u0001\u0004#G\u0013\t)UB\u0001\u0004uQJ|wo\u001d\t\u0003\u000f>s!\u0001S'\u000f\u0005%cU\"\u0001&\u000b\u0005-C\u0011A\u0002\u001fs_>$h(C\u0001\u000f\u0013\tqU\"A\u0004qC\u000e\\\u0017mZ3\n\u0005A\u000b&!C#yG\u0016\u0004H/[8o\u0015\tqUbI\u0001G\u0011\u0015!\u0006A\"\u0001V\u0003)ygnQ8na2,G/Z\u000b\u0003-&$\"aV/\u0015\u0005\u0015B\u0006\"B-T\u0001\bQ\u0016\u0001C3yK\u000e,Ho\u001c:\u0011\u0005IY\u0016B\u0001/\u0014\u0005A)\u00050Z2vi&|gnQ8oi\u0016DH\u000fC\u0003_'\u0002\u0007q,\u0001\u0003gk:\u001c\u0007\u0003\u0002\u0007aE\"L!!Y\u0007\u0003\u0013\u0019+hn\u0019;j_:\f\u0004cA2g/5\tAM\u0003\u0002f\u001b\u0005!Q\u000f^5m\u0013\t9GMA\u0002Uef\u0004\"\u0001G5\u0005\u000b)\u001c&\u0019A\u000e\u0003\u0003UCQ\u0001\u001c\u0001\u0007B5\f1\"[:D_6\u0004H.\u001a;fIV\ta\u000e\u0005\u0002\r_&\u0011\u0001/\u0004\u0002\b\u0005>|G.Z1o\u0011\u0015\u0011\bA\"\u0001n\u0003-I7oQ1oG\u0016dG.\u001a3\t\u000bQ\u0004a\u0011I;\u0002\u000bY\fG.^3\u0016\u0003Y\u00042\u0001D<c\u0013\tAXB\u0001\u0004PaRLwN\u001c\u0005\u0006u\u0002!\ta_\u0001\niJ\fgn\u001d4pe6,2\u0001`A\u0001)\ri\u0018q\u0001\u000b\u0004}\u0006\u0015\u0001c\u0001\n\u0016B\u0019\u0001$!\u0001\u0005\r\u0005\r\u0011P1\u0001\u001c\u0005\u0005\u0019\u0006\"B-z\u0001\bQ\u0006bBA\u0005s\u0002\u0007\u00111B\u0001\u0002MB)A\u0002\u00192\u0002\u000eA\u00191MZ@\t\u000f\u0005E\u0001\u0001\"\u0001\u0002\u0014\u0005iAO]1og\u001a|'/\\,ji\",B!!\u0006\u0002\u001eQ!\u0011qCA\u0011)\u0011\tI\"a\b\u0011\tI)\u00121\u0004\t\u00041\u0005uAaBA\u0002\u0003\u001f\u0011\ra\u0007\u0005\u00073\u0006=\u00019\u0001.\t\u0011\u0005%\u0011q\u0002a\u0001\u0003G\u0001R\u0001\u00041c\u00033Aq!a\n\u0001\t\u0003\tI#A\u0002hKR$\u0012a\u0006\u0015\u0007\u0003K\ti#a\u000e\u0011\t1!\u0015q\u0006\t\u0005\u0003c\t\u0019$D\u0001\u0003\u0013\r\t)D\u0001\u0002\u000f'B\f'o[#yG\u0016\u0004H/[8oG\t\ty\u0003C\u0004\u0002<\u00011\t!!\u0010\u0002\r)|'-\u00133t+\t\ty\u0004E\u0003H\u0003\u0003\n)%C\u0002\u0002DE\u00131aU3r!\ra\u0011qI\u0005\u0004\u0003\u0013j!aA%oi\u001eA\u0011Q\n\u0002\t\u0002\t\ty%\u0001\u0007GkR,(/Z!di&|g\u000e\u0005\u0003\u00022\u0005EcaB\u0001\u0003\u0011\u0003\u0011\u00111K\n\u0004\u0003#Z\u0001\u0002CA,\u0003#\"\t!!\u0017\u0002\rqJg.\u001b;?)\t\ty\u0005\u0003\u0006\u0002^\u0005E#\u0019!C\u0005\u0003?\n!\u0003\u001e:b]N4wN]7UeflU\r\u001e5pIV\u0011\u0011\u0011\r\t\u0005\u0003G\n\t(\u0004\u0002\u0002f)!\u0011qMA5\u0003\u001d\u0011XM\u001a7fGRTA!a\u001b\u0002n\u0005!A.\u00198h\u0015\t\ty'\u0001\u0003kCZ\f\u0017\u0002BA:\u0003K\u0012a!T3uQ>$\u0007\"CA<\u0003#\u0002\u000b\u0011BA1\u0003M!(/\u00198tM>\u0014X\u000e\u0016:z\u001b\u0016$\bn\u001c3!\u0011)\tY(!\u0015C\u0002\u0013%\u0011qL\u0001\u0017iJ\fgn\u001d4pe6<\u0016\u000e\u001e5UeflU\r\u001e5pI\"I\u0011qPA)A\u0003%\u0011\u0011M\u0001\u0018iJ\fgn\u001d4pe6<\u0016\u000e\u001e5UeflU\r\u001e5pI\u0002B\u0001B_A)\t\u0003\u0011\u00111Q\u000b\u0007\u0003\u000b\u000b)*a#\u0015\u0011\u0005\u001d\u0015QRAL\u0003?\u0003BAE\u000b\u0002\nB\u0019\u0001$a#\u0005\u000f\u0005\r\u0011\u0011\u0011b\u00017!A\u0011qRAA\u0001\u0004\t\t*\u0001\u0004gkR,(/\u001a\t\u0005%U\t\u0019\nE\u0002\u0019\u0003+#aAGAA\u0005\u0004Y\u0002\u0002CA\u0005\u0003\u0003\u0003\r!!'\u0011\r1\u0001\u00171TAO!\u0011\u0019g-a%\u0011\t\r4\u0017\u0011\u0012\u0005\u00073\u0006\u0005\u0005\u0019\u0001.\t\u0013\u0005E\u0011\u0011\u000bC\u0001\u0005\u0005\rVCBAS\u0003g\u000bY\u000b\u0006\u0005\u0002(\u00065\u0016QWA^!\u0011\u0011R#!+\u0011\u0007a\tY\u000bB\u0004\u0002\u0004\u0005\u0005&\u0019A\u000e\t\u0011\u0005=\u0015\u0011\u0015a\u0001\u0003_\u0003BAE\u000b\u00022B\u0019\u0001$a-\u0005\ri\t\tK1\u0001\u001c\u0011!\tI!!)A\u0002\u0005]\u0006C\u0002\u0007a\u0003s\u000b9\u000b\u0005\u0003dM\u0006E\u0006BB-\u0002\"\u0002\u0007!\f")
public interface FutureAction<T>
extends Future<T> {
    public void cancel();

    public FutureAction<T> ready(Duration var1, CanAwait var2);

    public T result(Duration var1, CanAwait var2) throws Exception;

    public <U> void onComplete(Function1<Try<T>, U> var1, ExecutionContext var2);

    public boolean isCompleted();

    public boolean isCancelled();

    public Option<Try<T>> value();

    public <S> Future<S> transform(Function1<Try<T>, Try<S>> var1, ExecutionContext var2);

    public <S> Future<S> transformWith(Function1<Try<T>, Future<S>> var1, ExecutionContext var2);

    public T get() throws SparkException;

    public Seq<Object> jobIds();
}

