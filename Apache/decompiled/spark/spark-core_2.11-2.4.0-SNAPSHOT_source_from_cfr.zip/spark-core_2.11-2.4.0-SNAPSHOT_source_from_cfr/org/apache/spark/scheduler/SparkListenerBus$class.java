/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.runtime.BoxedUnit
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerApplicationEnd;
import org.apache.spark.scheduler.SparkListenerApplicationStart;
import org.apache.spark.scheduler.SparkListenerBlockManagerAdded;
import org.apache.spark.scheduler.SparkListenerBlockManagerRemoved;
import org.apache.spark.scheduler.SparkListenerBlockUpdated;
import org.apache.spark.scheduler.SparkListenerBus;
import org.apache.spark.scheduler.SparkListenerEnvironmentUpdate;
import org.apache.spark.scheduler.SparkListenerEvent;
import org.apache.spark.scheduler.SparkListenerExecutorAdded;
import org.apache.spark.scheduler.SparkListenerExecutorBlacklisted;
import org.apache.spark.scheduler.SparkListenerExecutorBlacklistedForStage;
import org.apache.spark.scheduler.SparkListenerExecutorMetricsUpdate;
import org.apache.spark.scheduler.SparkListenerExecutorRemoved;
import org.apache.spark.scheduler.SparkListenerExecutorUnblacklisted;
import org.apache.spark.scheduler.SparkListenerInterface;
import org.apache.spark.scheduler.SparkListenerJobEnd;
import org.apache.spark.scheduler.SparkListenerJobStart;
import org.apache.spark.scheduler.SparkListenerNodeBlacklisted;
import org.apache.spark.scheduler.SparkListenerNodeBlacklistedForStage;
import org.apache.spark.scheduler.SparkListenerNodeUnblacklisted;
import org.apache.spark.scheduler.SparkListenerSpeculativeTaskSubmitted;
import org.apache.spark.scheduler.SparkListenerStageCompleted;
import org.apache.spark.scheduler.SparkListenerStageSubmitted;
import org.apache.spark.scheduler.SparkListenerTaskEnd;
import org.apache.spark.scheduler.SparkListenerTaskGettingResult;
import org.apache.spark.scheduler.SparkListenerTaskStart;
import org.apache.spark.scheduler.SparkListenerUnpersistRDD;
import scala.runtime.BoxedUnit;

public abstract class SparkListenerBus$class {
    public static void doPostEvent(SparkListenerBus $this, SparkListenerInterface listener, SparkListenerEvent event) {
        SparkListenerEvent sparkListenerEvent = event;
        if (sparkListenerEvent instanceof SparkListenerStageSubmitted) {
            SparkListenerStageSubmitted sparkListenerStageSubmitted = (SparkListenerStageSubmitted)sparkListenerEvent;
            listener.onStageSubmitted(sparkListenerStageSubmitted);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerStageCompleted) {
            SparkListenerStageCompleted sparkListenerStageCompleted = (SparkListenerStageCompleted)sparkListenerEvent;
            listener.onStageCompleted(sparkListenerStageCompleted);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerJobStart) {
            SparkListenerJobStart sparkListenerJobStart = (SparkListenerJobStart)sparkListenerEvent;
            listener.onJobStart(sparkListenerJobStart);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerJobEnd) {
            SparkListenerJobEnd sparkListenerJobEnd = (SparkListenerJobEnd)sparkListenerEvent;
            listener.onJobEnd(sparkListenerJobEnd);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerTaskStart) {
            SparkListenerTaskStart sparkListenerTaskStart = (SparkListenerTaskStart)sparkListenerEvent;
            listener.onTaskStart(sparkListenerTaskStart);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerTaskGettingResult) {
            SparkListenerTaskGettingResult sparkListenerTaskGettingResult = (SparkListenerTaskGettingResult)sparkListenerEvent;
            listener.onTaskGettingResult(sparkListenerTaskGettingResult);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerTaskEnd) {
            SparkListenerTaskEnd sparkListenerTaskEnd = (SparkListenerTaskEnd)sparkListenerEvent;
            listener.onTaskEnd(sparkListenerTaskEnd);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerEnvironmentUpdate) {
            SparkListenerEnvironmentUpdate sparkListenerEnvironmentUpdate = (SparkListenerEnvironmentUpdate)sparkListenerEvent;
            listener.onEnvironmentUpdate(sparkListenerEnvironmentUpdate);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerBlockManagerAdded) {
            SparkListenerBlockManagerAdded sparkListenerBlockManagerAdded = (SparkListenerBlockManagerAdded)sparkListenerEvent;
            listener.onBlockManagerAdded(sparkListenerBlockManagerAdded);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerBlockManagerRemoved) {
            SparkListenerBlockManagerRemoved sparkListenerBlockManagerRemoved = (SparkListenerBlockManagerRemoved)sparkListenerEvent;
            listener.onBlockManagerRemoved(sparkListenerBlockManagerRemoved);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerUnpersistRDD) {
            SparkListenerUnpersistRDD sparkListenerUnpersistRDD = (SparkListenerUnpersistRDD)sparkListenerEvent;
            listener.onUnpersistRDD(sparkListenerUnpersistRDD);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerApplicationStart) {
            SparkListenerApplicationStart sparkListenerApplicationStart = (SparkListenerApplicationStart)sparkListenerEvent;
            listener.onApplicationStart(sparkListenerApplicationStart);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerApplicationEnd) {
            SparkListenerApplicationEnd sparkListenerApplicationEnd = (SparkListenerApplicationEnd)sparkListenerEvent;
            listener.onApplicationEnd(sparkListenerApplicationEnd);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerExecutorMetricsUpdate) {
            SparkListenerExecutorMetricsUpdate sparkListenerExecutorMetricsUpdate = (SparkListenerExecutorMetricsUpdate)sparkListenerEvent;
            listener.onExecutorMetricsUpdate(sparkListenerExecutorMetricsUpdate);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerExecutorAdded) {
            SparkListenerExecutorAdded sparkListenerExecutorAdded = (SparkListenerExecutorAdded)sparkListenerEvent;
            listener.onExecutorAdded(sparkListenerExecutorAdded);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerExecutorRemoved) {
            SparkListenerExecutorRemoved sparkListenerExecutorRemoved = (SparkListenerExecutorRemoved)sparkListenerEvent;
            listener.onExecutorRemoved(sparkListenerExecutorRemoved);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerExecutorBlacklistedForStage) {
            SparkListenerExecutorBlacklistedForStage sparkListenerExecutorBlacklistedForStage = (SparkListenerExecutorBlacklistedForStage)sparkListenerEvent;
            listener.onExecutorBlacklistedForStage(sparkListenerExecutorBlacklistedForStage);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerNodeBlacklistedForStage) {
            SparkListenerNodeBlacklistedForStage sparkListenerNodeBlacklistedForStage = (SparkListenerNodeBlacklistedForStage)sparkListenerEvent;
            listener.onNodeBlacklistedForStage(sparkListenerNodeBlacklistedForStage);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerExecutorBlacklisted) {
            SparkListenerExecutorBlacklisted sparkListenerExecutorBlacklisted = (SparkListenerExecutorBlacklisted)sparkListenerEvent;
            listener.onExecutorBlacklisted(sparkListenerExecutorBlacklisted);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerExecutorUnblacklisted) {
            SparkListenerExecutorUnblacklisted sparkListenerExecutorUnblacklisted = (SparkListenerExecutorUnblacklisted)sparkListenerEvent;
            listener.onExecutorUnblacklisted(sparkListenerExecutorUnblacklisted);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerNodeBlacklisted) {
            SparkListenerNodeBlacklisted sparkListenerNodeBlacklisted = (SparkListenerNodeBlacklisted)sparkListenerEvent;
            listener.onNodeBlacklisted(sparkListenerNodeBlacklisted);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerNodeUnblacklisted) {
            SparkListenerNodeUnblacklisted sparkListenerNodeUnblacklisted = (SparkListenerNodeUnblacklisted)sparkListenerEvent;
            listener.onNodeUnblacklisted(sparkListenerNodeUnblacklisted);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerBlockUpdated) {
            SparkListenerBlockUpdated sparkListenerBlockUpdated = (SparkListenerBlockUpdated)sparkListenerEvent;
            listener.onBlockUpdated(sparkListenerBlockUpdated);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else if (sparkListenerEvent instanceof SparkListenerSpeculativeTaskSubmitted) {
            SparkListenerSpeculativeTaskSubmitted sparkListenerSpeculativeTaskSubmitted = (SparkListenerSpeculativeTaskSubmitted)sparkListenerEvent;
            listener.onSpeculativeTaskSubmitted(sparkListenerSpeculativeTaskSubmitted);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        } else {
            listener.onOtherEvent(event);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        }
    }

    public static void $init$(SparkListenerBus $this) {
    }
}

