/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.scheduler.AsyncEventQueue$$anon
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.AsyncEventQueue$;
import org.apache.spark.scheduler.SparkListenerEvent;

public final class AsyncEventQueue$ {
    public static final AsyncEventQueue$ MODULE$;
    private final SparkListenerEvent POISON_PILL;

    public static {
        new org.apache.spark.scheduler.AsyncEventQueue$();
    }

    public SparkListenerEvent POISON_PILL() {
        return this.POISON_PILL;
    }

    private AsyncEventQueue$() {
        MODULE$ = this;
        this.POISON_PILL = new SparkListenerEvent(){

            public boolean logEvent() {
                return org.apache.spark.scheduler.SparkListenerEvent$class.logEvent(this);
            }
            {
                org.apache.spark.scheduler.SparkListenerEvent$class.$init$(this);
            }
        };
    }
}

