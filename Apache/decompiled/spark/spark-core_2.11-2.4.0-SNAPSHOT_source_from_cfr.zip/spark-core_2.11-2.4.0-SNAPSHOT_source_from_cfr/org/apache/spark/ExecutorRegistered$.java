/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark;

import org.apache.spark.ExecutorRegistered;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class ExecutorRegistered$
extends AbstractFunction1<String, ExecutorRegistered>
implements Serializable {
    public static final ExecutorRegistered$ MODULE$;

    public static {
        new org.apache.spark.ExecutorRegistered$();
    }

    public final String toString() {
        return "ExecutorRegistered";
    }

    public ExecutorRegistered apply(String executorId) {
        return new ExecutorRegistered(executorId);
    }

    public Option<String> unapply(ExecutorRegistered x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.executorId());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private ExecutorRegistered$() {
        MODULE$ = this;
    }
}

