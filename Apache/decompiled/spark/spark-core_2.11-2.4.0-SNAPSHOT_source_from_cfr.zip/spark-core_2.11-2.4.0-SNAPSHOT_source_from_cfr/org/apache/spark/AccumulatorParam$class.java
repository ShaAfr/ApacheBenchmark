/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark;

import org.apache.spark.AccumulatorParam;

public abstract class AccumulatorParam$class {
    public static Object addAccumulator(AccumulatorParam $this, Object t1, Object t2) {
        return $this.addInPlace(t1, t2);
    }

    public static void $init$(AccumulatorParam $this) {
    }
}

