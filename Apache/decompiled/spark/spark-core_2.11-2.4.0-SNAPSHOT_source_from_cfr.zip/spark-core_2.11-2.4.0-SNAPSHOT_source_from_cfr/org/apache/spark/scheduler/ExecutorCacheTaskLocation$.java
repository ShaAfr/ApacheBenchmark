/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.ExecutorCacheTaskLocation;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;

public final class ExecutorCacheTaskLocation$
extends AbstractFunction2<String, String, ExecutorCacheTaskLocation>
implements Serializable {
    public static final ExecutorCacheTaskLocation$ MODULE$;

    public static {
        new org.apache.spark.scheduler.ExecutorCacheTaskLocation$();
    }

    public final String toString() {
        return "ExecutorCacheTaskLocation";
    }

    public ExecutorCacheTaskLocation apply(String host, String executorId) {
        return new ExecutorCacheTaskLocation(host, executorId);
    }

    public Option<Tuple2<String, String>> unapply(ExecutorCacheTaskLocation x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)x$0.host(), (Object)x$0.executorId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private ExecutorCacheTaskLocation$() {
        MODULE$ = this;
    }
}

