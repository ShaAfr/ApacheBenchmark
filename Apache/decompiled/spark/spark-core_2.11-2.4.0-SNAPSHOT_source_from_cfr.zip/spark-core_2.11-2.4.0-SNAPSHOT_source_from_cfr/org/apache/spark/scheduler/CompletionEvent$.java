/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple5
 *  scala.collection.Seq
 *  scala.runtime.AbstractFunction5
 */
package org.apache.spark.scheduler;

import org.apache.spark.TaskEndReason;
import org.apache.spark.scheduler.CompletionEvent;
import org.apache.spark.scheduler.Task;
import org.apache.spark.scheduler.TaskInfo;
import org.apache.spark.util.AccumulatorV2;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple5;
import scala.collection.Seq;
import scala.runtime.AbstractFunction5;

public final class CompletionEvent$
extends AbstractFunction5<Task<?>, TaskEndReason, Object, Seq<AccumulatorV2<?, ?>>, TaskInfo, CompletionEvent>
implements Serializable {
    public static final CompletionEvent$ MODULE$;

    public static {
        new org.apache.spark.scheduler.CompletionEvent$();
    }

    public final String toString() {
        return "CompletionEvent";
    }

    public CompletionEvent apply(Task<?> task, TaskEndReason reason, Object result2, Seq<AccumulatorV2<?, ?>> accumUpdates, TaskInfo taskInfo) {
        return new CompletionEvent(task, reason, result2, accumUpdates, taskInfo);
    }

    public Option<Tuple5<Task<Object>, TaskEndReason, Object, Seq<AccumulatorV2<?, ?>>, TaskInfo>> unapply(CompletionEvent x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple5(x$0.task(), (Object)x$0.reason(), x$0.result(), x$0.accumUpdates(), (Object)x$0.taskInfo()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private CompletionEvent$() {
        MODULE$ = this;
    }
}

