/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.SparkConf$$anonfun
 *  org.apache.spark.SparkConf$$anonfun$getDeprecatedConfig
 *  org.apache.spark.SparkConf$$anonfun$logDeprecationWarning
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$$less$colon$less
 *  scala.Predef$ArrowAssoc$
 *  scala.Serializable
 *  scala.Tuple2
 *  scala.collection.GenMap
 *  scala.collection.GenTraversable
 *  scala.collection.Iterable
 *  scala.collection.Iterable$
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.Map$
 *  scala.collection.mutable.WrappedArray
 *  scala.runtime.NonLocalReturnControl
 */
package org.apache.spark;

import java.util.Map;
import org.apache.spark.SecurityManager$;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkConf$;
import org.apache.spark.SparkConf$AlternateConfig$;
import org.apache.spark.deploy.history.config$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.internal.config.ConfigEntry;
import org.apache.spark.internal.config.OptionalConfigEntry;
import org.apache.spark.internal.config.package$;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.Tuple2;
import scala.collection.GenMap;
import scala.collection.GenTraversable;
import scala.collection.Iterable;
import scala.collection.Iterable$;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.Map$;
import scala.collection.mutable.WrappedArray;
import scala.runtime.NonLocalReturnControl;

public final class SparkConf$
implements Logging,
Serializable {
    public static final SparkConf$ MODULE$;
    private final scala.collection.immutable.Map<String, SparkConf.DeprecatedConfig> deprecatedConfigs;
    private final scala.collection.immutable.Map<String, Seq<SparkConf.AlternateConfig>> org$apache$spark$SparkConf$$configsWithAlternatives;
    private final scala.collection.immutable.Map<String, Tuple2<String, SparkConf.AlternateConfig>> allAlternatives;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.SparkConf$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    private scala.collection.immutable.Map<String, SparkConf.DeprecatedConfig> deprecatedConfigs() {
        return this.deprecatedConfigs;
    }

    public scala.collection.immutable.Map<String, Seq<SparkConf.AlternateConfig>> org$apache$spark$SparkConf$$configsWithAlternatives() {
        return this.org$apache$spark$SparkConf$$configsWithAlternatives;
    }

    private scala.collection.immutable.Map<String, Tuple2<String, SparkConf.AlternateConfig>> allAlternatives() {
        return this.allAlternatives;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean isExecutorStartupConf(String name2) {
        if (name2.startsWith("spark.auth")) {
            String string;
            String string2 = SecurityManager$.MODULE$.SPARK_AUTH_SECRET_CONF();
            if (name2 == null) {
                if (string2 != null) {
                    return true;
                }
            } else if (!string.equals(string2)) return true;
        }
        if (name2.startsWith("spark.ssl")) return true;
        if (name2.startsWith("spark.rpc")) return true;
        if (name2.startsWith("spark.network")) return true;
        if (!this.isSparkPortConf(name2)) return false;
        return true;
    }

    public boolean isSparkPortConf(String name2) {
        return name2.startsWith("spark.") && name2.endsWith(".port") || name2.startsWith("spark.port.");
    }

    public Option<String> getDeprecatedConfig(String key, Map<String, String> conf) {
        return this.org$apache$spark$SparkConf$$configsWithAlternatives().get((Object)key).flatMap((Function1)new Serializable(conf){
            public static final long serialVersionUID = 0L;
            public final Map conf$1;

            public final Option<String> apply(Seq<SparkConf.AlternateConfig> alts) {
                return alts.collectFirst((scala.PartialFunction)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ anonfun.getDeprecatedConfig.1 $outer;

                    public final <A1 extends SparkConf.AlternateConfig, B1> B1 applyOrElse(A1 x1, Function1<A1, B1> function1) {
                        Object object;
                        A1 A1 = x1;
                        if (this.$outer.conf$1.containsKey(((SparkConf.AlternateConfig)A1).key())) {
                            String value2 = (String)this.$outer.conf$1.get(((SparkConf.AlternateConfig)A1).key());
                            object = ((SparkConf.AlternateConfig)A1).translation() == null ? value2 : ((SparkConf.AlternateConfig)A1).translation().apply((Object)value2);
                        } else {
                            object = function1.apply(x1);
                        }
                        return (B1)object;
                    }

                    public final boolean isDefinedAt(SparkConf.AlternateConfig x1) {
                        SparkConf.AlternateConfig alternateConfig = x1;
                        boolean bl = this.$outer.conf$1.containsKey(alternateConfig.key());
                        return bl;
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
            }
            {
                this.conf$1 = conf$1;
            }
        });
    }

    public void logDeprecationWarning(String key) {
        NonLocalReturnControl nonLocalReturnControl2;
        block3 : {
            Object object = new Object();
            try {
                this.deprecatedConfigs().get((Object)key).foreach((Function1)new Serializable(key, object){
                    public static final long serialVersionUID = 0L;
                    public final String key$3;
                    private final Object nonLocalReturnKey1$1;

                    public final scala.runtime.Nothing$ apply(SparkConf.DeprecatedConfig cfg) {
                        SparkConf$.MODULE$.logWarning((Function0<String>)new Serializable(this, cfg){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ anonfun.logDeprecationWarning.1 $outer;
                            private final SparkConf.DeprecatedConfig cfg$2;

                            public final String apply() {
                                return new scala.collection.mutable.StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"The configuration key '", "' has been deprecated as of Spark ", " and "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.key$3, this.cfg$2.version()}))).append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"may be removed in the future. ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.cfg$2.deprecationMessage()}))).toString();
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.cfg$2 = cfg$2;
                            }
                        });
                        throw new scala.runtime.NonLocalReturnControl$mcV$sp(this.nonLocalReturnKey1$1, scala.runtime.BoxedUnit.UNIT);
                    }
                    {
                        this.key$3 = key$3;
                        this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                    }
                });
                this.allAlternatives().get((Object)key).foreach((Function1)new Serializable(key, object){
                    public static final long serialVersionUID = 0L;
                    public final String key$3;
                    private final Object nonLocalReturnKey1$1;

                    public final scala.runtime.Nothing$ apply(Tuple2<String, SparkConf.AlternateConfig> x0$7) {
                        Tuple2<String, SparkConf.AlternateConfig> tuple2 = x0$7;
                        if (tuple2 != null) {
                            String newKey = (String)tuple2._1();
                            SparkConf.AlternateConfig cfg = (SparkConf.AlternateConfig)tuple2._2();
                            SparkConf$.MODULE$.logWarning((Function0<String>)new Serializable(this, newKey, cfg){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ anonfun.logDeprecationWarning.2 $outer;
                                private final String newKey$1;
                                private final SparkConf.AlternateConfig cfg$1;

                                public final String apply() {
                                    return new scala.collection.mutable.StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"The configuration key '", "' has been deprecated as of Spark ", " and "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.key$3, this.cfg$1.version()}))).append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"may be removed in the future. Please use the new key '", "' instead."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.newKey$1}))).toString();
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                    this.newKey$1 = newKey$1;
                                    this.cfg$1 = cfg$1;
                                }
                            });
                            throw new scala.runtime.NonLocalReturnControl$mcV$sp(this.nonLocalReturnKey1$1, scala.runtime.BoxedUnit.UNIT);
                        }
                        throw new scala.MatchError(tuple2);
                    }
                    {
                        this.key$3 = key$3;
                        this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                    }
                });
                if (key.startsWith("spark.akka") || key.startsWith("spark.ssl.akka")) {
                    this.logWarning((Function0<String>)new Serializable(key){
                        public static final long serialVersionUID = 0L;
                        private final String key$3;

                        public final String apply() {
                            return new scala.collection.mutable.StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"The configuration key ", " is not supported any more "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.key$3}))).append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"because Spark doesn't use Akka since 2.0"})).s((Seq)scala.collection.immutable.Nil$.MODULE$)).toString();
                        }
                        {
                            this.key$3 = key$3;
                        }
                    });
                }
            }
            catch (NonLocalReturnControl nonLocalReturnControl2) {
                if (nonLocalReturnControl2.key() != object) break block3;
                nonLocalReturnControl2.value$mcV$sp();
            }
            return;
        }
        throw nonLocalReturnControl2;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkConf$() {
        MODULE$ = this;
        Logging$class.$init$(this);
        Seq configs = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.DeprecatedConfig[]{new SparkConf.DeprecatedConfig("spark.cache.class", "0.8", "The spark.cache.class property is no longer being used! Specify storage levels using the RDD.persist() method instead."), new SparkConf.DeprecatedConfig("spark.yarn.user.classpath.first", "1.3", "Please use spark.{driver,executor}.userClassPathFirst instead."), new SparkConf.DeprecatedConfig("spark.kryoserializer.buffer.mb", "1.4", "Please use spark.kryoserializer.buffer instead. The default value for spark.kryoserializer.buffer.mb was previously specified as '0.064'. Fractional values are no longer accepted. To specify the equivalent now, one may use '64k'."), new SparkConf.DeprecatedConfig("spark.rpc", "2.0", "Not used any more."), new SparkConf.DeprecatedConfig("spark.scheduler.executorTaskBlacklistTime", "2.1.0", "Please use the new blacklisting options, spark.blacklist.*"), new SparkConf.DeprecatedConfig("spark.yarn.am.port", "2.0.0", "Not used any more"), new SparkConf.DeprecatedConfig("spark.executor.port", "2.0.0", "Not used any more"), new SparkConf.DeprecatedConfig("spark.shuffle.service.index.cache.entries", "2.3.0", "Not used any more. Please use spark.shuffle.service.index.cache.size")}));
        this.deprecatedConfigs = (scala.collection.immutable.Map)Predef$.MODULE$.Map().apply((Seq)configs.map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final Tuple2<String, SparkConf.DeprecatedConfig> apply(SparkConf.DeprecatedConfig cfg) {
                return Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)cfg.key()), (Object)cfg);
            }
        }, Seq$.MODULE$.canBuildFrom()));
        this.org$apache$spark$SparkConf$$configsWithAlternatives = (scala.collection.immutable.Map)Predef$.MODULE$.Map().apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new Tuple2[]{Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.executor.userClassPathFirst"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.files.userClassPathFirst", "1.3", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.history.fs.update.interval"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.history.fs.update.interval.seconds", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3()), new SparkConf.AlternateConfig("spark.history.fs.updateInterval", "1.3", SparkConf$AlternateConfig$.MODULE$.apply$default$3()), new SparkConf.AlternateConfig("spark.history.updateInterval", "1.3", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.history.fs.cleaner.interval"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.history.fs.cleaner.interval.seconds", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)config$.MODULE$.MAX_LOG_AGE_S().key()), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.history.fs.cleaner.maxAge.seconds", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.yarn.am.waitTime"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.yarn.applicationMaster.waitTries", "1.3", (Function1<String, String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(String s) {
                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "s"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{scala.runtime.BoxesRunTime.boxToLong((long)(new scala.collection.immutable.StringOps(Predef$.MODULE$.augmentString(s)).toLong() * 10L))}));
            }
        })}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.reducer.maxSizeInFlight"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.reducer.maxMbInFlight", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.kryoserializer.buffer"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.kryoserializer.buffer.mb", "1.4", (Function1<String, String>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(String s) {
                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "k"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{scala.runtime.BoxesRunTime.boxToInteger((int)((int)(new scala.collection.immutable.StringOps(Predef$.MODULE$.augmentString(s)).toDouble() * (double)1000)))}));
            }
        })}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.kryoserializer.buffer.max"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.kryoserializer.buffer.max.mb", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.shuffle.file.buffer"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.shuffle.file.buffer.kb", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.executor.logs.rolling.maxSize"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.executor.logs.rolling.size.maxBytes", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.io.compression.snappy.blockSize"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.io.compression.snappy.block.size", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.io.compression.lz4.blockSize"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.io.compression.lz4.block.size", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.rpc.numRetries"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.akka.num.retries", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.rpc.retry.wait"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.akka.retry.wait", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.rpc.askTimeout"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.akka.askTimeout", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.rpc.lookupTimeout"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.akka.lookupTimeout", "1.4", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.streaming.fileStream.minRememberDuration"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.streaming.minRememberDuration", "1.5", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.yarn.max.executor.failures"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.yarn.max.worker.failures", "1.5", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)package$.MODULE$.MEMORY_OFFHEAP_ENABLED().key()), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.unsafe.offHeap", "1.6", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.rpc.message.maxSize"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.akka.frameSize", "1.6", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.yarn.jars"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.yarn.jar", "2.0", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"spark.yarn.access.hadoopFileSystems"), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.yarn.access.namenodes", "2.2", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)package$.MODULE$.MAX_REMOTE_BLOCK_SIZE_FETCH_TO_MEM().key()), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.reducer.maxReqSizeShuffleToMem", "2.3", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)package$.MODULE$.LISTENER_BUS_EVENT_QUEUE_CAPACITY().key()), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.scheduler.listenerbus.eventqueue.size", "2.3", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)package$.MODULE$.DRIVER_MEMORY_OVERHEAD().key()), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.yarn.driver.memoryOverhead", "2.3", SparkConf$AlternateConfig$.MODULE$.apply$default$3())}))), Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)package$.MODULE$.EXECUTOR_MEMORY_OVERHEAD().key()), (Object)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new SparkConf.AlternateConfig[]{new SparkConf.AlternateConfig("spark.yarn.executor.memoryOverhead", "2.3", SparkConf$AlternateConfig$.MODULE$.apply$default$3())})))}));
        this.allAlternatives = ((TraversableOnce)this.org$apache$spark$SparkConf$$configsWithAlternatives().keys().flatMap((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final Seq<Tuple2<String, Tuple2<String, SparkConf.AlternateConfig>>> apply(String key) {
                return (Seq)((scala.collection.TraversableLike)SparkConf$.MODULE$.org$apache$spark$SparkConf$$configsWithAlternatives().apply((Object)key)).map((Function1)new Serializable(this, key){
                    public static final long serialVersionUID = 0L;
                    private final String key$4;

                    public final Tuple2<String, Tuple2<String, SparkConf.AlternateConfig>> apply(SparkConf.AlternateConfig cfg) {
                        return Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)cfg.key()), (Object)Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)this.key$4), (Object)cfg));
                    }
                    {
                        this.key$4 = key$4;
                    }
                }, Seq$.MODULE$.canBuildFrom());
            }
        }, Iterable$.MODULE$.canBuildFrom())).toMap(Predef$.MODULE$.$conforms());
    }
}

