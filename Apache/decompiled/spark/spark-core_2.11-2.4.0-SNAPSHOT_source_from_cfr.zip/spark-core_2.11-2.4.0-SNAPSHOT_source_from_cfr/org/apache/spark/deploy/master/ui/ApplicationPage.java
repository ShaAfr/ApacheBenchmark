/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 *  org.apache.spark.deploy.master.ui.ApplicationPage$
 *  org.apache.spark.deploy.master.ui.ApplicationPage$$anonfun
 *  org.apache.spark.deploy.master.ui.ApplicationPage$$anonfun$render
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Predef$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.collection.GenSeq
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Iterable
 *  scala.collection.Iterable$
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.Set
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayBuffer
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.HashMap
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.xml.Comment
 *  scala.xml.Elem
 *  scala.xml.MetaData
 *  scala.xml.NamespaceBinding
 *  scala.xml.Node
 *  scala.xml.NodeBuffer
 *  scala.xml.NodeSeq$
 *  scala.xml.Null$
 *  scala.xml.Text
 *  scala.xml.TopScope$
 *  scala.xml.UnprefixedAttribute
 */
package org.apache.spark.deploy.master.ui;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.apache.spark.deploy.ApplicationDescription;
import org.apache.spark.deploy.DeployMessages;
import org.apache.spark.deploy.DeployMessages$RequestMasterState$;
import org.apache.spark.deploy.master.ApplicationInfo;
import org.apache.spark.deploy.master.ExecutorDesc;
import org.apache.spark.deploy.master.Master;
import org.apache.spark.deploy.master.WorkerInfo;
import org.apache.spark.deploy.master.ui.ApplicationPage$;
import org.apache.spark.deploy.master.ui.MasterWebUI;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.ui.ToolTips$;
import org.apache.spark.ui.UIUtils$;
import org.apache.spark.ui.WebUIPage;
import org.apache.spark.util.Utils$;
import scala.Enumeration;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.collection.GenSeq;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.Iterable;
import scala.collection.Iterable$;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.Set;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayBuffer;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.HashMap;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.xml.Comment;
import scala.xml.Elem;
import scala.xml.MetaData;
import scala.xml.NamespaceBinding;
import scala.xml.Node;
import scala.xml.NodeBuffer;
import scala.xml.NodeSeq$;
import scala.xml.Null$;
import scala.xml.Text;
import scala.xml.TopScope$;
import scala.xml.UnprefixedAttribute;

@ScalaSignature(bytes="\u0006\u0001Y3Q!\u0001\u0002\u0001\u00059\u0011q\"\u00119qY&\u001c\u0017\r^5p]B\u000bw-\u001a\u0006\u0003\u0007\u0011\t!!^5\u000b\u0005\u00151\u0011AB7bgR,'O\u0003\u0002\b\u0011\u00051A-\u001a9m_fT!!\u0003\u0006\u0002\u000bM\u0004\u0018M]6\u000b\u0005-a\u0011AB1qC\u000eDWMC\u0001\u000e\u0003\ry'oZ\n\u0003\u0001=\u0001\"\u0001\u0005\n\u000e\u0003EQ!a\u0001\u0005\n\u0005M\t\"!C,fEVK\u0005+Y4f\u0011!)\u0002A!A!\u0002\u00139\u0012A\u00029be\u0016tGo\u0001\u0001\u0011\u0005aIR\"\u0001\u0002\n\u0005i\u0011!aC'bgR,'oV3c+&CQ\u0001\b\u0001\u0005\u0002u\ta\u0001P5oSRtDC\u0001\u0010 !\tA\u0002\u0001C\u0003\u00167\u0001\u0007q\u0003C\u0004\u0006\u0001\t\u0007I\u0011B\u0011\u0016\u0003\t\u0002\"a\t\u0014\u000e\u0003\u0011R!!\n\u0005\u0002\u0007I\u00048-\u0003\u0002(I\tq!\u000b]2F]\u0012\u0004x.\u001b8u%\u00164\u0007BB\u0015\u0001A\u0003%!%A\u0004nCN$XM\u001d\u0011\t\u000b-\u0002A\u0011\u0001\u0017\u0002\rI,g\u000eZ3s)\ti\u0013\tE\u0002/qmr!aL\u001b\u000f\u0005A\u001aT\"A\u0019\u000b\u0005I2\u0012A\u0002\u001fs_>$h(C\u00015\u0003\u0015\u00198-\u00197b\u0013\t1t'A\u0004qC\u000e\\\u0017mZ3\u000b\u0003QJ!!\u000f\u001e\u0003\u0007M+\u0017O\u0003\u00027oA\u0011AhP\u0007\u0002{)\u0011ahN\u0001\u0004q6d\u0017B\u0001!>\u0005\u0011qu\u000eZ3\t\u000b\tS\u0003\u0019A\"\u0002\u000fI,\u0017/^3tiB\u0011AiS\u0007\u0002\u000b*\u0011aiR\u0001\u0005QR$\bO\u0003\u0002I\u0013\u000691/\u001a:wY\u0016$(\"\u0001&\u0002\u000b)\fg/\u0019=\n\u00051+%A\u0005%uiB\u001cVM\u001d<mKR\u0014V-];fgRDQA\u0014\u0001\u0005\n=\u000b1\"\u001a=fGV$xN\u001d*poR\u0011Q\u0006\u0015\u0005\u0006#6\u0003\rAU\u0001\tKb,7-\u001e;peB\u00111\u000bV\u0007\u0002\t%\u0011Q\u000b\u0002\u0002\r\u000bb,7-\u001e;pe\u0012+7o\u0019")
public class ApplicationPage
extends WebUIPage {
    private final MasterWebUI parent;
    private final RpcEndpointRef master;

    private RpcEndpointRef master() {
        return this.master;
    }

    @Override
    public Seq<Node> render(HttpServletRequest request) {
        BoxedUnit boxedUnit;
        Object object;
        String appId = UIUtils$.MODULE$.stripXSS(request.getParameter("appId"));
        DeployMessages.MasterStateResponse state = (DeployMessages.MasterStateResponse)this.master().askSync(DeployMessages$RequestMasterState$.MODULE$, ClassTag$.MODULE$.apply(DeployMessages.MasterStateResponse.class));
        ApplicationInfo app = (ApplicationInfo)Predef$.MODULE$.refArrayOps((Object[])state.activeApps()).find((Function1)new Serializable(this, appId){
            public static final long serialVersionUID = 0L;
            private final String appId$1;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(ApplicationInfo x$1) {
                String string = this.appId$1;
                if (x$1.id() != null) {
                    String string2;
                    if (!string2.equals(string)) return false;
                    return true;
                }
                if (string == null) return true;
                return false;
            }
            {
                this.appId$1 = appId$1;
            }
        }).getOrElse((Function0)new Serializable(this, appId, state){
            public static final long serialVersionUID = 0L;
            public final String appId$1;
            private final DeployMessages.MasterStateResponse state$1;

            public final ApplicationInfo apply() {
                return (ApplicationInfo)Predef$.MODULE$.refArrayOps((Object[])this.state$1.completedApps()).find((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ $anonfun$2 $outer;

                    /*
                     * Enabled force condition propagation
                     * Lifted jumps to return sites
                     */
                    public final boolean apply(ApplicationInfo x$2) {
                        String string = this.$outer.appId$1;
                        if (x$2.id() != null) {
                            String string2;
                            if (!string2.equals(string)) return false;
                            return true;
                        }
                        if (string == null) return true;
                        return false;
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                }).orNull(Predef$.MODULE$.$conforms());
            }
            {
                this.appId$1 = appId$1;
                this.state$1 = state$1;
            }
        });
        if (app == null) {
            Null$ $md = Null$.MODULE$;
            $md = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md);
            NodeBuffer $buf = new NodeBuffer();
            $buf.$amp$plus((Object)new Text("No running application with ID "));
            $buf.$amp$plus((Object)appId);
            Elem msg = new Elem(null, "div", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
            return UIUtils$.MODULE$.basicSparkPage((Function0<Seq<Node>>)new Serializable(this, msg){
                public static final long serialVersionUID = 0L;
                private final Elem msg$1;

                public final Elem apply() {
                    return this.msg$1;
                }
                {
                    this.msg$1 = msg$1;
                }
            }, "Not Found", UIUtils$.MODULE$.basicSparkPage$default$3());
        }
        Seq executorHeaders = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"ExecutorID", "Worker", "Cores", "Memory", "State", "Logs"}));
        Seq allExecutors = ((TraversableOnce)app.executors().values().$plus$plus(app.removedExecutors(), Iterable$.MODULE$.canBuildFrom())).toSet().toSeq();
        Seq executors = (Seq)allExecutors.filter((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(ExecutorDesc exec) {
                Enumeration.Value value2;
                if (!org.apache.spark.deploy.ExecutorState$.MODULE$.isFinished(exec.state())) return true;
                Enumeration.Value value3 = org.apache.spark.deploy.ExecutorState$.MODULE$.EXITED();
                if (exec.state() == null) {
                    if (value3 == null) return true;
                    return false;
                } else if (value2.equals((Object)value3)) return true;
                return false;
            }
        });
        Seq removedExecutors = (Seq)allExecutors.diff((GenSeq)executors);
        Seq<Node> executorsTable = UIUtils$.MODULE$.listingTable((Seq<String>)executorHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ ApplicationPage $outer;

            public final Seq<Node> apply(ExecutorDesc executor) {
                return this.$outer.org$apache$spark$deploy$master$ui$ApplicationPage$$executorRow(executor);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, executors, UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        Seq<Node> removedExecutorsTable = UIUtils$.MODULE$.listingTable((Seq<String>)executorHeaders, new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ ApplicationPage $outer;

            public final Seq<Node> apply(ExecutorDesc executor) {
                return this.$outer.org$apache$spark$deploy$master$ui$ApplicationPage$$executorRow(executor);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, removedExecutors, UIUtils$.MODULE$.listingTable$default$4(), UIUtils$.MODULE$.listingTable$default$5(), UIUtils$.MODULE$.listingTable$default$6(), UIUtils$.MODULE$.listingTable$default$7(), UIUtils$.MODULE$.listingTable$default$8());
        NodeBuffer $buf = new NodeBuffer();
        Null$ $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md);
        NodeBuffer $buf2 = new NodeBuffer();
        $buf2.$amp$plus((Object)new Text("\n        "));
        Null$ $md2 = Null$.MODULE$;
        $md2 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md2);
        NodeBuffer $buf3 = new NodeBuffer();
        $buf3.$amp$plus((Object)new Text("\n          "));
        Null$ $md3 = Null$.MODULE$;
        $md3 = new UnprefixedAttribute("class", (Seq)new Text("unstyled"), (MetaData)$md3);
        NodeBuffer $buf4 = new NodeBuffer();
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf5 = new NodeBuffer();
        NodeBuffer $buf6 = new NodeBuffer();
        $buf6.$amp$plus((Object)new Text("ID:"));
        $buf5.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6));
        $buf5.$amp$plus((Object)new Text(" "));
        $buf5.$amp$plus((Object)app.id());
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf7 = new NodeBuffer();
        NodeBuffer $buf8 = new NodeBuffer();
        $buf8.$amp$plus((Object)new Text("Name:"));
        $buf7.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf8));
        $buf7.$amp$plus((Object)new Text(" "));
        $buf7.$amp$plus((Object)app.desc().name());
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf9 = new NodeBuffer();
        NodeBuffer $buf10 = new NodeBuffer();
        $buf10.$amp$plus((Object)new Text("User:"));
        $buf9.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf10));
        $buf9.$amp$plus((Object)new Text(" "));
        $buf9.$amp$plus((Object)app.desc().user());
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf9));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf11 = new NodeBuffer();
        NodeBuffer $buf12 = new NodeBuffer();
        $buf12.$amp$plus((Object)new Text("Cores:"));
        $buf11.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf12));
        $buf11.$amp$plus((Object)new Text("\n            "));
        $buf11.$amp$plus((Object)(app.desc().maxCores().isEmpty() ? new StringOps(Predef$.MODULE$.augmentString("Unlimited (%s granted)")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)app.coresGranted())})) : new StringOps(Predef$.MODULE$.augmentString("%s (%s granted, %s left)")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{app.desc().maxCores().get(), BoxesRunTime.boxToInteger((int)app.coresGranted()), BoxesRunTime.boxToInteger((int)app.coresLeft())}))));
        $buf11.$amp$plus((Object)new Text("\n            "));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf11));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf13 = new NodeBuffer();
        $buf13.$amp$plus((Object)new Text("\n              "));
        Null$ $md4 = Null$.MODULE$;
        $md4 = new UnprefixedAttribute("data-placement", (Seq)new Text("right"), (MetaData)$md4);
        $md4 = new UnprefixedAttribute("title", ToolTips$.MODULE$.APPLICATION_EXECUTOR_LIMIT(), (MetaData)$md4);
        $md4 = new UnprefixedAttribute("data-toggle", (Seq)new Text("tooltip"), (MetaData)$md4);
        NodeBuffer $buf14 = new NodeBuffer();
        $buf14.$amp$plus((Object)new Text("\n                "));
        NodeBuffer $buf15 = new NodeBuffer();
        $buf15.$amp$plus((Object)new Text("Executor Limit: "));
        $buf14.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf15));
        $buf14.$amp$plus((Object)new Text("\n                "));
        $buf14.$amp$plus(app.executorLimit() == Integer.MAX_VALUE ? "Unlimited" : BoxesRunTime.boxToInteger((int)app.executorLimit()));
        $buf14.$amp$plus((Object)new Text("\n                ("));
        $buf14.$amp$plus((Object)BoxesRunTime.boxToInteger((int)app.executors().size()));
        $buf14.$amp$plus((Object)new Text(" granted)\n              "));
        $buf13.$amp$plus((Object)new Elem(null, "span", (MetaData)$md4, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf14));
        $buf13.$amp$plus((Object)new Text("\n            "));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf13));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf16 = new NodeBuffer();
        $buf16.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf17 = new NodeBuffer();
        $buf17.$amp$plus((Object)new Text("Executor Memory:"));
        $buf16.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf17));
        $buf16.$amp$plus((Object)new Text("\n              "));
        $buf16.$amp$plus((Object)Utils$.MODULE$.megabytesToString(app.desc().memoryPerExecutorMB()));
        $buf16.$amp$plus((Object)new Text("\n            "));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf16));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf18 = new NodeBuffer();
        NodeBuffer $buf19 = new NodeBuffer();
        $buf19.$amp$plus((Object)new Text("Submit Date:"));
        $buf18.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf19));
        $buf18.$amp$plus((Object)new Text(" "));
        $buf18.$amp$plus((Object)UIUtils$.MODULE$.formatDate(app.submitDate()));
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf18));
        $buf4.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf20 = new NodeBuffer();
        NodeBuffer $buf21 = new NodeBuffer();
        $buf21.$amp$plus((Object)new Text("State:"));
        $buf20.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf21));
        $buf20.$amp$plus((Object)new Text(" "));
        $buf20.$amp$plus((Object)app.state());
        $buf4.$amp$plus((Object)new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf20));
        $buf4.$amp$plus((Object)new Text("\n            "));
        if (app.isFinished()) {
            boxedUnit = BoxedUnit.UNIT;
        } else {
            Elem elem;
            boxedUnit = elem;
            NodeBuffer $buf22 = new NodeBuffer();
            NodeBuffer $buf23 = new NodeBuffer();
            $buf23.$amp$plus((Object)new Text("\n                    "));
            Null$ $md5 = Null$.MODULE$;
            $md5 = new UnprefixedAttribute("href", UIUtils$.MODULE$.makeHref(this.parent.master().reverseProxy(), app.id(), app.desc().appUiUrl()), (MetaData)$md5);
            NodeBuffer $buf24 = new NodeBuffer();
            $buf24.$amp$plus((Object)new Text("Application Detail UI"));
            $buf23.$amp$plus((Object)new Elem(null, "a", (MetaData)$md5, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf24));
            $buf23.$amp$plus((Object)new Text("\n                "));
            $buf22.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf23));
            elem = new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf22);
        }
        $buf4.$amp$plus((Object)boxedUnit);
        $buf4.$amp$plus((Object)new Text("\n          "));
        $buf3.$amp$plus((Object)new Elem(null, "ul", (MetaData)$md3, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4));
        $buf3.$amp$plus((Object)new Text("\n        "));
        $buf2.$amp$plus((Object)new Elem(null, "div", (MetaData)$md2, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3));
        $buf2.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
        Null$ $md6 = Null$.MODULE$;
        $md6 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md6);
        NodeBuffer $buf25 = new NodeBuffer();
        $buf25.$amp$plus((Object)new Text(" "));
        $buf25.$amp$plus((Object)new Comment(" Executors "));
        $buf25.$amp$plus((Object)new Text("\n        "));
        Null$ $md7 = Null$.MODULE$;
        $md7 = new UnprefixedAttribute("class", (Seq)new Text("span12"), (MetaData)$md7);
        NodeBuffer $buf26 = new NodeBuffer();
        $buf26.$amp$plus((Object)new Text("\n          "));
        Null$ $md8 = Null$.MODULE$;
        $md8 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-executors','aggregated-executors')"), (MetaData)$md8);
        $md8 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-executors collapse-table"), (MetaData)$md8);
        NodeBuffer $buf27 = new NodeBuffer();
        $buf27.$amp$plus((Object)new Text("\n            "));
        NodeBuffer $buf28 = new NodeBuffer();
        $buf28.$amp$plus((Object)new Text("\n              "));
        Null$ $md9 = Null$.MODULE$;
        $md9 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md9);
        $buf28.$amp$plus((Object)new Elem(null, "span", (MetaData)$md9, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
        $buf28.$amp$plus((Object)new Text("\n              "));
        NodeBuffer $buf29 = new NodeBuffer();
        $buf29.$amp$plus((Object)new Text("Executor Summary ("));
        $buf29.$amp$plus((Object)BoxesRunTime.boxToInteger((int)allExecutors.length()));
        $buf29.$amp$plus((Object)new Text(")"));
        $buf28.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf29));
        $buf28.$amp$plus((Object)new Text("\n            "));
        $buf27.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf28));
        $buf27.$amp$plus((Object)new Text("\n          "));
        $buf26.$amp$plus((Object)new Elem(null, "span", (MetaData)$md8, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf27));
        $buf26.$amp$plus((Object)new Text("\n          "));
        Null$ $md10 = Null$.MODULE$;
        $md10 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-executors collapsible-table"), (MetaData)$md10);
        NodeBuffer $buf30 = new NodeBuffer();
        $buf30.$amp$plus((Object)new Text("\n            "));
        $buf30.$amp$plus(executorsTable);
        $buf30.$amp$plus((Object)new Text("\n          "));
        $buf26.$amp$plus((Object)new Elem(null, "div", (MetaData)$md10, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf30));
        $buf26.$amp$plus((Object)new Text("\n          "));
        if (removedExecutors.nonEmpty()) {
            Null$ $md11 = Null$.MODULE$;
            $md11 = new UnprefixedAttribute("onClick", (Seq)new Text("collapseTable('collapse-aggregated-removedExecutors',\n                  'aggregated-removedExecutors')"), (MetaData)$md11);
            $md11 = new UnprefixedAttribute("class", (Seq)new Text("collapse-aggregated-removedExecutors collapse-table"), (MetaData)$md11);
            NodeBuffer $buf31 = new NodeBuffer();
            $buf31.$amp$plus((Object)new Text("\n                "));
            NodeBuffer $buf32 = new NodeBuffer();
            $buf32.$amp$plus((Object)new Text("\n                  "));
            Null$ $md12 = Null$.MODULE$;
            $md12 = new UnprefixedAttribute("class", (Seq)new Text("collapse-table-arrow arrow-open"), (MetaData)$md12);
            $buf32.$amp$plus((Object)new Elem(null, "span", (MetaData)$md12, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
            $buf32.$amp$plus((Object)new Text("\n                  "));
            NodeBuffer $buf33 = new NodeBuffer();
            $buf33.$amp$plus((Object)new Text("Removed Executors ("));
            $buf33.$amp$plus((Object)BoxesRunTime.boxToInteger((int)removedExecutors.length()));
            $buf33.$amp$plus((Object)new Text(")"));
            $buf32.$amp$plus((Object)new Elem(null, "a", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf33));
            $buf32.$amp$plus((Object)new Text("\n                "));
            $buf31.$amp$plus((Object)new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf32));
            $buf31.$amp$plus((Object)new Text("\n              "));
            Null$ $md13 = Null$.MODULE$;
            $md13 = new UnprefixedAttribute("class", (Seq)new Text("aggregated-removedExecutors collapsible-table"), (MetaData)$md13);
            NodeBuffer $buf34 = new NodeBuffer();
            $buf34.$amp$plus((Object)new Text("\n                "));
            $buf34.$amp$plus(removedExecutorsTable);
            $buf34.$amp$plus((Object)new Text("\n              "));
            object = new Elem(null, "span", (MetaData)$md11, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf31).$plus$plus((GenTraversableOnce)new Elem(null, "div", (MetaData)$md13, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf34), NodeSeq$.MODULE$.canBuildFrom());
        } else {
            object = BoxedUnit.UNIT;
        }
        $buf26.$amp$plus(object);
        $buf26.$amp$plus((Object)new Text("\n        "));
        $buf25.$amp$plus((Object)new Elem(null, "div", (MetaData)$md7, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf26));
        $buf25.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)$md6, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf25));
        NodeBuffer content = $buf;
        return UIUtils$.MODULE$.basicSparkPage((Function0<Seq<Node>>)new Serializable(this, content){
            public static final long serialVersionUID = 0L;
            private final NodeBuffer content$1;

            public final NodeBuffer apply() {
                return this.content$1;
            }
            {
                this.content$1 = content$1;
            }
        }, new StringBuilder().append((Object)"Application: ").append((Object)app.desc().name()).toString(), UIUtils$.MODULE$.basicSparkPage$default$3());
    }

    public Seq<Node> org$apache$spark$deploy$master$ui$ApplicationPage$$executorRow(ExecutorDesc executor) {
        String workerUrlRef = UIUtils$.MODULE$.makeHref(this.parent.master().reverseProxy(), executor.worker().id(), executor.worker().webUiAddress());
        NodeBuffer $buf = new NodeBuffer();
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf2 = new NodeBuffer();
        $buf2.$amp$plus((Object)BoxesRunTime.boxToInteger((int)executor.id()));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf3 = new NodeBuffer();
        $buf3.$amp$plus((Object)new Text("\n        "));
        Null$ $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("href", workerUrlRef, (MetaData)$md);
        NodeBuffer $buf4 = new NodeBuffer();
        $buf4.$amp$plus((Object)executor.worker().id());
        $buf3.$amp$plus((Object)new Elem(null, "a", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4));
        $buf3.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf5 = new NodeBuffer();
        $buf5.$amp$plus((Object)BoxesRunTime.boxToInteger((int)executor.cores()));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf6 = new NodeBuffer();
        $buf6.$amp$plus((Object)BoxesRunTime.boxToInteger((int)executor.memory()));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf7 = new NodeBuffer();
        $buf7.$amp$plus((Object)executor.state());
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7));
        $buf.$amp$plus((Object)new Text("\n      "));
        NodeBuffer $buf8 = new NodeBuffer();
        $buf8.$amp$plus((Object)new Text("\n        "));
        Null$ $md2 = Null$.MODULE$;
        $md2 = new UnprefixedAttribute("href", new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/logPage?appId=", "&executorId=", "&logType=stdout"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{workerUrlRef, executor.application().id(), BoxesRunTime.boxToInteger((int)executor.id())})), (MetaData)$md2);
        NodeBuffer $buf9 = new NodeBuffer();
        $buf9.$amp$plus((Object)new Text("stdout"));
        $buf8.$amp$plus((Object)new Elem(null, "a", (MetaData)$md2, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf9));
        $buf8.$amp$plus((Object)new Text("\n        "));
        Null$ $md3 = Null$.MODULE$;
        $md3 = new UnprefixedAttribute("href", new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "/logPage?appId=", "&executorId=", "&logType=stderr"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{workerUrlRef, executor.application().id(), BoxesRunTime.boxToInteger((int)executor.id())})), (MetaData)$md3);
        NodeBuffer $buf10 = new NodeBuffer();
        $buf10.$amp$plus((Object)new Text("stderr"));
        $buf8.$amp$plus((Object)new Elem(null, "a", (MetaData)$md3, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf10));
        $buf8.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "td", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf8));
        $buf.$amp$plus((Object)new Text("\n    "));
        return new Elem(null, "tr", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
    }

    public ApplicationPage(MasterWebUI parent) {
        this.parent = parent;
        super("app");
        this.master = parent.masterEndpointRef();
    }
}

