/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.rest.RestSubmissionClient$$anonfun
 *  org.apache.spark.deploy.rest.RestSubmissionClient$$anonfun$filterSystemEnvironment
 *  scala.Function1
 *  scala.Serializable
 *  scala.collection.immutable.Map
 */
package org.apache.spark.deploy.rest;

import org.apache.spark.deploy.rest.RestSubmissionClient$;
import scala.Function1;
import scala.Serializable;
import scala.collection.immutable.Map;

public final class RestSubmissionClient$ {
    public static final RestSubmissionClient$ MODULE$;
    private final int org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_INTERVAL;
    private final int org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_MAX_TRIES;
    private final String PROTOCOL_VERSION;

    public static {
        new org.apache.spark.deploy.rest.RestSubmissionClient$();
    }

    public int org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_INTERVAL() {
        return this.org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_INTERVAL;
    }

    public int org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_MAX_TRIES() {
        return this.org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_MAX_TRIES;
    }

    public String PROTOCOL_VERSION() {
        return this.PROTOCOL_VERSION;
    }

    public Map<String, String> filterSystemEnvironment(Map<String, String> env) {
        return env.filterKeys((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(String k) {
                block5 : {
                    String string;
                    block7 : {
                        String string2;
                        String string3;
                        block6 : {
                            if (!k.startsWith("SPARK_")) break block5;
                            string2 = "SPARK_ENV_LOADED";
                            if (k != null) break block6;
                            if (string2 == null) break block5;
                            break block7;
                        }
                        if (string3.equals(string2)) break block5;
                    }
                    String string4 = "SPARK_HOME";
                    if (k == null) {
                        if (string4 != null) {
                            return true;
                        }
                    } else if (!string.equals(string4)) return true;
                }
                if (!k.startsWith("MESOS_")) return false;
                return true;
            }
        });
    }

    private RestSubmissionClient$() {
        MODULE$ = this;
        this.org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_INTERVAL = 1000;
        this.org$apache$spark$deploy$rest$RestSubmissionClient$$REPORT_DRIVER_STATUS_MAX_TRIES = 10;
        this.PROTOCOL_VERSION = "v1";
    }
}

