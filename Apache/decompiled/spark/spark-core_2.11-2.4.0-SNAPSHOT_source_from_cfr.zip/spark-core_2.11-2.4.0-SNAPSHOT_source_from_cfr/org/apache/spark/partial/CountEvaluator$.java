/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.commons.math3.distribution.PoissonDistribution
 */
package org.apache.spark.partial;

import org.apache.commons.math3.distribution.PoissonDistribution;
import org.apache.spark.partial.BoundedDouble;

public final class CountEvaluator$ {
    public static final CountEvaluator$ MODULE$;

    public static {
        new org.apache.spark.partial.CountEvaluator$();
    }

    public BoundedDouble bound(double confidence, long sum2, double p) {
        PoissonDistribution dist = new PoissonDistribution((double)sum2 * ((double)true - p) / p);
        int low = dist.inverseCumulativeProbability(((double)true - confidence) / (double)2);
        int high = dist.inverseCumulativeProbability(((double)true + confidence) / (double)2);
        return new BoundedDouble((double)sum2 + dist.getNumericalMean(), confidence, sum2 + (long)low, sum2 + (long)high);
    }

    private CountEvaluator$() {
        MODULE$ = this;
    }
}

