/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.internal.config.ConfigEntry$$anonfun
 *  org.apache.spark.internal.config.ConfigEntry$$anonfun$registerEntry
 *  scala.Function0
 *  scala.Predef$
 *  scala.Serializable
 */
package org.apache.spark.internal.config;

import java.util.concurrent.ConcurrentHashMap;
import org.apache.spark.internal.config.ConfigEntry;
import org.apache.spark.internal.config.ConfigEntry$;
import scala.Function0;
import scala.Predef$;
import scala.Serializable;

public final class ConfigEntry$ {
    public static final ConfigEntry$ MODULE$;
    private final String UNDEFINED;
    private final ConcurrentHashMap<String, ConfigEntry<?>> knownConfigs;

    public static {
        new org.apache.spark.internal.config.ConfigEntry$();
    }

    public String UNDEFINED() {
        return this.UNDEFINED;
    }

    private ConcurrentHashMap<String, ConfigEntry<?>> knownConfigs() {
        return this.knownConfigs;
    }

    public void registerEntry(ConfigEntry<?> entry) {
        ConfigEntry<?> existing = this.knownConfigs().putIfAbsent(entry.key(), entry);
        Predef$.MODULE$.require(existing == null, (Function0)new Serializable(entry){
            public static final long serialVersionUID = 0L;
            private final ConfigEntry entry$1;

            public final String apply() {
                return new scala.StringContext((scala.collection.Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Config entry ", " already registered!"})).s((scala.collection.Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.entry$1.key()}));
            }
            {
                this.entry$1 = entry$1;
            }
        });
    }

    public ConfigEntry<?> findEntry(String key) {
        return this.knownConfigs().get(key);
    }

    private ConfigEntry$() {
        MODULE$ = this;
        this.UNDEFINED = "<undefined>";
        this.knownConfigs = new ConcurrentHashMap();
    }
}

