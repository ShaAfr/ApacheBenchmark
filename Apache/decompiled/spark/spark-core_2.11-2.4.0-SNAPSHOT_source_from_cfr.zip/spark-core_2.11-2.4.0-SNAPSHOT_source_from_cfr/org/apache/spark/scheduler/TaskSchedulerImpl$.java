/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.scheduler.TaskSchedulerImpl$$anonfun
 *  org.apache.spark.scheduler.TaskSchedulerImpl$$anonfun$prioritizeContainers
 *  scala.Function1
 *  scala.Function2
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.collection.Iterable
 *  scala.collection.TraversableOnce
 *  scala.collection.immutable.List
 *  scala.collection.mutable.ArrayBuffer
 *  scala.collection.mutable.HashMap
 *  scala.runtime.BooleanRef
 *  scala.runtime.IntRef
 */
package org.apache.spark.scheduler;

import org.apache.spark.ExecutorAllocationClient;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.scheduler.BlacklistTracker;
import org.apache.spark.scheduler.BlacklistTracker$;
import org.apache.spark.scheduler.SchedulerBackend;
import org.apache.spark.scheduler.TaskSchedulerImpl$;
import scala.Function1;
import scala.Function2;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.collection.Iterable;
import scala.collection.TraversableOnce;
import scala.collection.immutable.List;
import scala.collection.mutable.ArrayBuffer;
import scala.collection.mutable.HashMap;
import scala.runtime.BooleanRef;
import scala.runtime.IntRef;

public final class TaskSchedulerImpl$ {
    public static final TaskSchedulerImpl$ MODULE$;
    private final String SCHEDULER_MODE_PROPERTY;

    public static {
        new org.apache.spark.scheduler.TaskSchedulerImpl$();
    }

    public String SCHEDULER_MODE_PROPERTY() {
        return this.SCHEDULER_MODE_PROPERTY;
    }

    public <K, T> List<T> prioritizeContainers(HashMap<K, ArrayBuffer<T>> map2) {
        ArrayBuffer _keyList = new ArrayBuffer(map2.size());
        _keyList.$plus$plus$eq((TraversableOnce)map2.keys());
        ArrayBuffer keyList = (ArrayBuffer)_keyList.sortWith((Function2)new Serializable(map2){
            public static final long serialVersionUID = 0L;
            private final HashMap map$1;

            public final boolean apply(K left, K right) {
                return ((scala.collection.SeqLike)this.map$1.apply(left)).size() > ((scala.collection.SeqLike)this.map$1.apply(right)).size();
            }
            {
                this.map$1 = map$1;
            }
        });
        ArrayBuffer retval = new ArrayBuffer(keyList.size() * 2);
        IntRef index = IntRef.create((int)0);
        BooleanRef found = BooleanRef.create((boolean)true);
        while (found.elem) {
            found.elem = false;
            keyList.foreach((Function1)new Serializable(map2, retval, index, found){
                public static final long serialVersionUID = 0L;
                private final HashMap map$1;
                private final ArrayBuffer retval$1;
                private final IntRef index$1;
                private final BooleanRef found$1;

                public final void apply(K key) {
                    ArrayBuffer containerList = (ArrayBuffer)this.map$1.getOrElse(key, (scala.Function0)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final scala.runtime.Null$ apply() {
                            return null;
                        }
                    });
                    scala.Predef$.MODULE$.assert(containerList != null);
                    if (this.index$1.elem < containerList.size()) {
                        this.retval$1.$plus$eq(containerList.apply(this.index$1.elem));
                        this.found$1.elem = true;
                    }
                }
                {
                    this.map$1 = map$1;
                    this.retval$1 = retval$1;
                    this.index$1 = index$1;
                    this.found$1 = found$1;
                }
            });
            ++index.elem;
        }
        return retval.toList();
    }

    public Option<BlacklistTracker> org$apache$spark$scheduler$TaskSchedulerImpl$$maybeCreateBlacklistTracker(SparkContext sc) {
        None$ none$;
        if (BlacklistTracker$.MODULE$.isBlacklistEnabled(sc.conf())) {
            None$ none$2;
            SchedulerBackend schedulerBackend = sc.schedulerBackend();
            if (schedulerBackend instanceof ExecutorAllocationClient) {
                SchedulerBackend schedulerBackend2 = schedulerBackend;
                none$2 = new Some((Object)schedulerBackend2);
            } else {
                none$2 = None$.MODULE$;
            }
            None$ executorAllocClient = none$2;
            none$ = new Some((Object)new BlacklistTracker(sc, (Option<ExecutorAllocationClient>)executorAllocClient));
        } else {
            none$ = None$.MODULE$;
        }
        return none$;
    }

    public boolean $lessinit$greater$default$3() {
        return false;
    }

    private TaskSchedulerImpl$() {
        MODULE$ = this;
        this.SCHEDULER_MODE_PROPERTY = "spark.scheduler.mode";
    }
}

