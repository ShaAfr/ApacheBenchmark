/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 */
package org.apache.spark.scheduler;

import java.util.Properties;
import org.apache.spark.scheduler.SparkListenerStageSubmitted;
import org.apache.spark.scheduler.StageInfo;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;

public final class SparkListenerStageSubmitted$
extends AbstractFunction2<StageInfo, Properties, SparkListenerStageSubmitted>
implements Serializable {
    public static final SparkListenerStageSubmitted$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerStageSubmitted$();
    }

    public final String toString() {
        return "SparkListenerStageSubmitted";
    }

    public SparkListenerStageSubmitted apply(StageInfo stageInfo, Properties properties) {
        return new SparkListenerStageSubmitted(stageInfo, properties);
    }

    public Option<Tuple2<StageInfo, Properties>> unapply(SparkListenerStageSubmitted x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)x$0.stageInfo(), (Object)x$0.properties()));
    }

    public Properties apply$default$2() {
        return null;
    }

    public Properties $lessinit$greater$default$2() {
        return null;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerStageSubmitted$() {
        MODULE$ = this;
    }
}

