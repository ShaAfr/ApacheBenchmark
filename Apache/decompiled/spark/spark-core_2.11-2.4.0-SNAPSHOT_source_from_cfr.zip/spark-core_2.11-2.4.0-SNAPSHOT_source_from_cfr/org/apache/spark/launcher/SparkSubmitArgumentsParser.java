/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.launcher.SparkSubmitOptionParser
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.launcher;

import org.apache.spark.launcher.SparkSubmitOptionParser;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001Q1a!\u0001\u0002\u0002\u0002\u0011Q!AG*qCJ\\7+\u001e2nSR\f%oZ;nK:$8\u000fU1sg\u0016\u0014(BA\u0002\u0005\u0003!a\u0017-\u001e8dQ\u0016\u0014(BA\u0003\u0007\u0003\u0015\u0019\b/\u0019:l\u0015\t9\u0001\"\u0001\u0004ba\u0006\u001c\u0007.\u001a\u0006\u0002\u0013\u0005\u0019qN]4\u0014\u0005\u0001Y\u0001C\u0001\u0007\u000e\u001b\u0005\u0011\u0011B\u0001\b\u0003\u0005]\u0019\u0006/\u0019:l'V\u0014W.\u001b;PaRLwN\u001c)beN,'\u000fC\u0003\u0011\u0001\u0011\u0005!#\u0001\u0004=S:LGOP\u0002\u0001)\u0005\u0019\u0002C\u0001\u0007\u0001\u0001")
public abstract class SparkSubmitArgumentsParser
extends SparkSubmitOptionParser {
}

