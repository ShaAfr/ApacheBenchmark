/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.apache.spark.deploy.rest.ErrorServlet$
 *  org.apache.spark.deploy.rest.ErrorServlet$$anonfun
 *  scala.Function1
 *  scala.Predef$
 *  scala.Serializable
 *  scala.StringContext
 *  scala.collection.Seq
 *  scala.collection.immutable.
 *  scala.collection.immutable.$colon
 *  scala.collection.immutable.$colon$colon
 *  scala.collection.immutable.List
 *  scala.collection.immutable.Nil$
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.deploy.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.spark.deploy.rest.ErrorResponse;
import org.apache.spark.deploy.rest.ErrorServlet$;
import org.apache.spark.deploy.rest.RestServlet;
import org.apache.spark.deploy.rest.RestSubmissionServer$;
import org.apache.spark.deploy.rest.SubmitRestProtocolResponse;
import scala.Function1;
import scala.Predef$;
import scala.Serializable;
import scala.StringContext;
import scala.collection.Seq;
import scala.collection.immutable.;
import scala.collection.immutable.List;
import scala.collection.immutable.Nil$;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001u2A!\u0001\u0002\u0005\u001b\taQI\u001d:peN+'O\u001e7fi*\u00111\u0001B\u0001\u0005e\u0016\u001cHO\u0003\u0002\u0006\r\u00051A-\u001a9m_fT!a\u0002\u0005\u0002\u000bM\u0004\u0018M]6\u000b\u0005%Q\u0011AB1qC\u000eDWMC\u0001\f\u0003\ry'oZ\u0002\u0001'\t\u0001a\u0002\u0005\u0002\u0010!5\t!!\u0003\u0002\u0012\u0005\tY!+Z:u'\u0016\u0014h\u000f\\3u\u0011\u0015\u0019\u0002\u0001\"\u0001\u0015\u0003\u0019a\u0014N\\5u}Q\tQ\u0003\u0005\u0002\u0010\u0001!9q\u0003\u0001b\u0001\n\u0013A\u0012!D:feZ,'OV3sg&|g.F\u0001\u001a!\tQr$D\u0001\u001c\u0015\taR$\u0001\u0003mC:<'\"\u0001\u0010\u0002\t)\fg/Y\u0005\u0003Am\u0011aa\u0015;sS:<\u0007B\u0002\u0012\u0001A\u0003%\u0011$\u0001\btKJ4XM\u001d,feNLwN\u001c\u0011\t\u000b\u0011\u0002A\u0011K\u0013\u0002\u000fM,'O^5dKR\u0019a\u0005\f\u001d\u0011\u0005\u001dRS\"\u0001\u0015\u000b\u0003%\nQa]2bY\u0006L!a\u000b\u0015\u0003\tUs\u0017\u000e\u001e\u0005\u0006[\r\u0002\rAL\u0001\be\u0016\fX/Z:u!\tyc'D\u00011\u0015\t\t$'\u0001\u0003iiR\u0004(BA\u001a5\u0003\u001d\u0019XM\u001d<mKRT\u0011!N\u0001\u0006U\u00064\u0018\r_\u0005\u0003oA\u0012!\u0003\u0013;uaN+'O\u001e7fiJ+\u0017/^3ti\")\u0011h\ta\u0001u\u0005A!/Z:q_:\u001cX\r\u0005\u00020w%\u0011A\b\r\u0002\u0014\u0011R$\boU3sm2,GOU3ta>t7/\u001a")
public class ErrorServlet
extends RestServlet {
    private final String serverVersion = RestSubmissionServer$.MODULE$.PROTOCOL_VERSION();

    private String serverVersion() {
        return this.serverVersion;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void service(HttpServletRequest request, HttpServletResponse response) {
        block7 : {
            block12 : {
                block11 : {
                    block8 : {
                        block10 : {
                            block9 : {
                                block6 : {
                                    path = request.getPathInfo();
                                    parts = Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])new StringOps(Predef$.MODULE$.augmentString(path)).stripPrefix("/").split("/")).filter((Function1)new Serializable(this){
                                        public static final long serialVersionUID = 0L;

                                        public final boolean apply(String x$5) {
                                            return new StringOps(Predef$.MODULE$.augmentString(x$5)).nonEmpty();
                                        }
                                    })).toList();
                                    versionMismatch = false;
                                    var7_6 = false;
                                    var8_7 = null;
                                    var9_8 = parts;
                                    if (!Nil$.MODULE$.equals((Object)var9_8)) break block6;
                                    var10_9 = "Missing protocol version.";
                                    break block7;
                                }
                                if (!(var9_8 instanceof .colon.colon)) break block8;
                                var7_6 = true;
                                var8_7 = (.colon.colon)var9_8;
                                var11_10 = (String)var8_7.head();
                                var12_11 = var8_7.tl$1();
                                var13_12 = var11_10;
                                if (this.serverVersion() != null) break block9;
                                if (var13_12 == null) break block10;
                                break block8;
                            }
                            if (!v0.equals(var13_12)) break block8;
                        }
                        if (!Nil$.MODULE$.equals((Object)var12_11)) break block8;
                        var10_9 = "Missing the /submissions prefix.";
                        break block7;
                    }
                    if (!var7_6) ** GOTO lbl-1000
                    var14_13 = (String)var8_7.head();
                    var15_14 = var8_7.tl$1();
                    var16_15 = var14_13;
                    if (this.serverVersion() != null) break block11;
                    if (var16_15 == null) break block12;
                    ** GOTO lbl-1000
                }
                if (!v1.equals(var16_15)) ** GOTO lbl-1000
            }
            if (var15_14 instanceof .colon.colon && "submissions".equals(var18_17 = (String)(var17_16 = (.colon.colon)var15_14).head())) {
                var10_9 = "Missing an action: please specify one of /create, /kill, or /status.";
            } else if (var7_6) {
                unknownVersion = (String)var8_7.head();
                versionMismatch = true;
                var10_9 = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Unknown protocol version '", "'."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{unknownVersion}));
            } else {
                var10_9 = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Malformed path ", "."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{path}));
            }
        }
        msg = var10_9;
        msg = new StringBuilder().append((Object)msg).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" Please submit requests through http://[host]:[port]/", "/submissions/..."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.serverVersion()}))).toString();
        error = this.handleError(msg);
        if (versionMismatch) {
            error.highestProtocolVersion_$eq(this.serverVersion());
            response.setStatus(RestSubmissionServer$.MODULE$.SC_UNKNOWN_PROTOCOL_VERSION());
        } else {
            response.setStatus(400);
        }
        this.sendResponse(error, response);
    }
}

