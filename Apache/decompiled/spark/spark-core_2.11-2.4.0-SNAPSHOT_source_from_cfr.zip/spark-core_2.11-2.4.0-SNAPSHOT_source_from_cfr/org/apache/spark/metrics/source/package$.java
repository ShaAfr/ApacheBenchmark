/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.metrics.source;

public final class package$ {
    public static final package$ MODULE$;

    public static {
        new org.apache.spark.metrics.source.package$();
    }

    private package$() {
        MODULE$ = this;
    }
}

