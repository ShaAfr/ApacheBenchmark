/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.JsonProtocol$$anonfun
 *  org.apache.spark.deploy.JsonProtocol$$anonfun$writeApplicationDescription
 *  org.apache.spark.deploy.JsonProtocol$$anonfun$writeApplicationInfo
 *  org.apache.spark.deploy.JsonProtocol$$anonfun$writeDriverInfo
 *  org.apache.spark.deploy.JsonProtocol$$anonfun$writeExecutorRunner
 *  org.apache.spark.deploy.JsonProtocol$$anonfun$writeMasterState
 *  org.apache.spark.deploy.JsonProtocol$$anonfun$writeWorkerInfo
 *  org.apache.spark.deploy.JsonProtocol$$anonfun$writeWorkerState
 *  org.json4s.JsonAST
 *  org.json4s.JsonAST$JObject
 *  org.json4s.JsonDSL
 *  org.json4s.JsonDSL$
 *  org.json4s.JsonDSL$JsonAssoc
 *  org.json4s.JsonDSL$JsonListAssoc
 *  scala.Array$
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$ArrowAssoc$
 *  scala.Serializable
 *  scala.Tuple2
 *  scala.collection.Seq
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.List
 *  scala.collection.immutable.List$
 *  scala.collection.mutable.ArrayOps
 *  scala.math.Numeric
 *  scala.math.Numeric$IntIsIntegral$
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy;

import java.util.Date;
import org.apache.spark.deploy.ApplicationDescription;
import org.apache.spark.deploy.Command;
import org.apache.spark.deploy.DeployMessages;
import org.apache.spark.deploy.DriverDescription;
import org.apache.spark.deploy.JsonProtocol$;
import org.apache.spark.deploy.master.ApplicationInfo;
import org.apache.spark.deploy.master.DriverInfo;
import org.apache.spark.deploy.master.WorkerInfo;
import org.apache.spark.deploy.worker.ExecutorRunner;
import org.json4s.JsonAST;
import org.json4s.JsonDSL;
import org.json4s.JsonDSL$;
import scala.Array$;
import scala.Enumeration;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.Tuple2;
import scala.collection.Seq;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.List;
import scala.collection.immutable.List$;
import scala.collection.mutable.ArrayOps;
import scala.math.Numeric;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.BoxesRunTime;

public final class JsonProtocol$ {
    public static final JsonProtocol$ MODULE$;

    public static {
        new org.apache.spark.deploy.JsonProtocol$();
    }

    public JsonAST.JObject writeWorkerInfo(WorkerInfo obj) {
        return JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.pair2Assoc(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"id"), (Object)obj.id()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"host"), (Object)obj.host()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        })).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"port"), (Object)BoxesRunTime.boxToInteger((int)obj.port())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"webuiaddress"), (Object)obj.webUiAddress()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"cores"), (Object)BoxesRunTime.boxToInteger((int)obj.cores())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"coresused"), (Object)BoxesRunTime.boxToInteger((int)obj.coresUsed())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"coresfree"), (Object)BoxesRunTime.boxToInteger((int)obj.coresFree())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memory"), (Object)BoxesRunTime.boxToInteger((int)obj.memory())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memoryused"), (Object)BoxesRunTime.boxToInteger((int)obj.memoryUsed())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memoryfree"), (Object)BoxesRunTime.boxToInteger((int)obj.memoryFree())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"state"), (Object)obj.state().toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"lastheartbeat"), (Object)BoxesRunTime.boxToLong((long)obj.lastHeartbeat())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(long x) {
                return JsonDSL$.MODULE$.long2jvalue(x);
            }
        }));
    }

    public JsonAST.JObject writeApplicationInfo(ApplicationInfo obj) {
        return JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.pair2Assoc(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"id"), (Object)obj.id()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"starttime"), (Object)BoxesRunTime.boxToLong((long)obj.startTime())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(long x) {
                return JsonDSL$.MODULE$.long2jvalue(x);
            }
        })).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"name"), (Object)obj.desc().name()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"cores"), (Object)BoxesRunTime.boxToInteger((int)obj.coresGranted())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"user"), (Object)obj.desc().user()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memoryperslave"), (Object)BoxesRunTime.boxToInteger((int)obj.desc().memoryPerExecutorMB())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"submitdate"), (Object)obj.submitDate().toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"state"), (Object)obj.state().toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"duration"), (Object)BoxesRunTime.boxToLong((long)obj.duration())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(long x) {
                return JsonDSL$.MODULE$.long2jvalue(x);
            }
        }));
    }

    public JsonAST.JObject writeApplicationDescription(ApplicationDescription obj) {
        return JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.pair2Assoc(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"name"), (Object)obj.name()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"cores"), obj.maxCores().getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply() {
                return this.apply$mcI$sp();
            }

            public int apply$mcI$sp() {
                return 0;
            }
        })), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        })).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memoryperslave"), (Object)BoxesRunTime.boxToInteger((int)obj.memoryPerExecutorMB())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"user"), (Object)obj.user()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"command"), (Object)obj.command().toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }));
    }

    public JsonAST.JObject writeExecutorRunner(ExecutorRunner obj) {
        return JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.pair2Assoc(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"id"), (Object)BoxesRunTime.boxToInteger((int)obj.execId())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memory"), (Object)BoxesRunTime.boxToInteger((int)obj.memory())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        })).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"appid"), (Object)obj.appId()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"appdesc"), (Object)this.writeApplicationDescription(obj.appDesc())));
    }

    public JsonAST.JObject writeDriverInfo(DriverInfo obj) {
        return JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.pair2Assoc(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"id"), (Object)obj.id()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"starttime"), (Object)((Object)BoxesRunTime.boxToLong((long)obj.startTime())).toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        })).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"state"), (Object)obj.state().toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"cores"), (Object)BoxesRunTime.boxToInteger((int)obj.desc().cores())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memory"), (Object)BoxesRunTime.boxToInteger((int)obj.desc().mem())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"submitdate"), (Object)obj.submitDate().toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"worker"), obj.worker().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(WorkerInfo x$1) {
                return x$1.id();
            }
        }).getOrElse((Function0)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "None";
            }
        })), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"mainclass"), obj.desc().command().arguments().apply(2)), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }));
    }

    public JsonAST.JObject writeMasterState(DeployMessages.MasterStateResponse obj) {
        WorkerInfo[] aliveWorkers = (WorkerInfo[])Predef$.MODULE$.refArrayOps((Object[])obj.workers()).filter((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply(WorkerInfo x$2) {
                return x$2.isAlive();
            }
        });
        return JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.pair2Assoc(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"url"), (Object)obj.uri()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"workers"), Predef$.MODULE$.refArrayOps((Object[])obj.workers()).toList().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final JsonAST.JObject apply(WorkerInfo obj) {
                return JsonProtocol$.MODULE$.writeWorkerInfo(obj);
            }
        }, List$.MODULE$.canBuildFrom())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JArray apply(scala.collection.Traversable<JsonAST.JObject> s) {
                return JsonDSL$.MODULE$.seq2jvalue(s, (Function1)Predef$.MODULE$.$conforms());
            }
        })).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"aliveworkers"), (Object)BoxesRunTime.boxToInteger((int)aliveWorkers.length)), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"cores"), Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$3) {
                return x$3.cores();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$)), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"coresused"), Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$4) {
                return x$4.coresUsed();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$)), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memory"), Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$5) {
                return x$5.memory();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$)), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memoryused"), Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])aliveWorkers).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$6) {
                return x$6.memoryUsed();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$)), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"activeapps"), Predef$.MODULE$.refArrayOps((Object[])obj.activeApps()).toList().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final JsonAST.JObject apply(ApplicationInfo obj) {
                return JsonProtocol$.MODULE$.writeApplicationInfo(obj);
            }
        }, List$.MODULE$.canBuildFrom())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JArray apply(scala.collection.Traversable<JsonAST.JObject> s) {
                return JsonDSL$.MODULE$.seq2jvalue(s, (Function1)Predef$.MODULE$.$conforms());
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"completedapps"), Predef$.MODULE$.refArrayOps((Object[])obj.completedApps()).toList().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final JsonAST.JObject apply(ApplicationInfo obj) {
                return JsonProtocol$.MODULE$.writeApplicationInfo(obj);
            }
        }, List$.MODULE$.canBuildFrom())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JArray apply(scala.collection.Traversable<JsonAST.JObject> s) {
                return JsonDSL$.MODULE$.seq2jvalue(s, (Function1)Predef$.MODULE$.$conforms());
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"activedrivers"), Predef$.MODULE$.refArrayOps((Object[])obj.activeDrivers()).toList().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final JsonAST.JObject apply(DriverInfo obj) {
                return JsonProtocol$.MODULE$.writeDriverInfo(obj);
            }
        }, List$.MODULE$.canBuildFrom())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JArray apply(scala.collection.Traversable<JsonAST.JObject> s) {
                return JsonDSL$.MODULE$.seq2jvalue(s, (Function1)Predef$.MODULE$.$conforms());
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"completeddrivers"), Predef$.MODULE$.refArrayOps((Object[])obj.completedDrivers()).toList().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final JsonAST.JObject apply(DriverInfo obj) {
                return JsonProtocol$.MODULE$.writeDriverInfo(obj);
            }
        }, List$.MODULE$.canBuildFrom())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JArray apply(scala.collection.Traversable<JsonAST.JObject> s) {
                return JsonDSL$.MODULE$.seq2jvalue(s, (Function1)Predef$.MODULE$.$conforms());
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"status"), (Object)obj.status().toString()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }));
    }

    public JsonAST.JObject writeWorkerState(DeployMessages.WorkerStateResponse obj) {
        return JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.jobject2assoc(JsonDSL$.MODULE$.pair2Assoc(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"id"), (Object)obj.workerId()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }).$tilde(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"masterurl"), (Object)obj.masterUrl()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        })).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"masterwebuiurl"), (Object)obj.masterWebUiUrl()), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(String x) {
                return JsonDSL$.MODULE$.string2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"cores"), (Object)BoxesRunTime.boxToInteger((int)obj.cores())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"coresused"), (Object)BoxesRunTime.boxToInteger((int)obj.coresUsed())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memory"), (Object)BoxesRunTime.boxToInteger((int)obj.memory())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"memoryused"), (Object)BoxesRunTime.boxToInteger((int)obj.memoryUsed())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JValue apply(int x) {
                return JsonDSL$.MODULE$.int2jvalue(x);
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"executors"), obj.executors().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final JsonAST.JObject apply(ExecutorRunner obj) {
                return JsonProtocol$.MODULE$.writeExecutorRunner(obj);
            }
        }, List$.MODULE$.canBuildFrom())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JArray apply(scala.collection.Traversable<JsonAST.JObject> s) {
                return JsonDSL$.MODULE$.seq2jvalue(s, (Function1)Predef$.MODULE$.$conforms());
            }
        }))).$tilde(JsonDSL$.MODULE$.pair2jvalue(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)"finishedexecutors"), obj.finishedExecutors().map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final JsonAST.JObject apply(ExecutorRunner obj) {
                return JsonProtocol$.MODULE$.writeExecutorRunner(obj);
            }
        }, List$.MODULE$.canBuildFrom())), (Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final org.json4s.JsonAST$JArray apply(scala.collection.Traversable<JsonAST.JObject> s) {
                return JsonDSL$.MODULE$.seq2jvalue(s, (Function1)Predef$.MODULE$.$conforms());
            }
        }));
    }

    private JsonProtocol$() {
        MODULE$ = this;
    }
}

