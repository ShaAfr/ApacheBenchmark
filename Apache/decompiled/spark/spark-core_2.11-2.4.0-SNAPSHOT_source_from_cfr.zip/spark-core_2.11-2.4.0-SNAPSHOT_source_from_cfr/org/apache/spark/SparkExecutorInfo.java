/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark;

import java.io.Serializable;

public interface SparkExecutorInfo
extends Serializable {
    public String host();

    public int port();

    public long cacheSize();

    public int numRunningTasks();
}

