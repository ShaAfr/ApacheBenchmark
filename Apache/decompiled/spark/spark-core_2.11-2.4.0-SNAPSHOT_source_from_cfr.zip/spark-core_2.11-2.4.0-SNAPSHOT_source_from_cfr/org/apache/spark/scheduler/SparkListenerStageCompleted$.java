/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerStageCompleted;
import org.apache.spark.scheduler.StageInfo;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class SparkListenerStageCompleted$
extends AbstractFunction1<StageInfo, SparkListenerStageCompleted>
implements Serializable {
    public static final SparkListenerStageCompleted$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerStageCompleted$();
    }

    public final String toString() {
        return "SparkListenerStageCompleted";
    }

    public SparkListenerStageCompleted apply(StageInfo stageInfo) {
        return new SparkListenerStageCompleted(stageInfo);
    }

    public Option<StageInfo> unapply(SparkListenerStageCompleted x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.stageInfo());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerStageCompleted$() {
        MODULE$ = this;
    }
}

