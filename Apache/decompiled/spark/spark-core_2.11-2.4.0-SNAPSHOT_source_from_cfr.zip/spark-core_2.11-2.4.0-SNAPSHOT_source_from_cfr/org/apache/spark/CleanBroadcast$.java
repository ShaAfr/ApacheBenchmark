/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.CleanBroadcast;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;
import scala.runtime.BoxesRunTime;

public final class CleanBroadcast$
extends AbstractFunction1<Object, CleanBroadcast>
implements Serializable {
    public static final CleanBroadcast$ MODULE$;

    public static {
        new org.apache.spark.CleanBroadcast$();
    }

    public final String toString() {
        return "CleanBroadcast";
    }

    public CleanBroadcast apply(long broadcastId) {
        return new CleanBroadcast(broadcastId);
    }

    public Option<Object> unapply(CleanBroadcast x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)BoxesRunTime.boxToLong((long)x$0.broadcastId()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private CleanBroadcast$() {
        MODULE$ = this;
    }
}

