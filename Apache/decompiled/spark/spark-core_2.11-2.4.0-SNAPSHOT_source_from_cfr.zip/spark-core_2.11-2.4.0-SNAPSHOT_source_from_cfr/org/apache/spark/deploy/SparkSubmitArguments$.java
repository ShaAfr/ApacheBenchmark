/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.collection.immutable.Map
 *  scala.sys.package$
 */
package org.apache.spark.deploy;

import scala.collection.immutable.Map;
import scala.sys.package$;

public final class SparkSubmitArguments$ {
    public static final SparkSubmitArguments$ MODULE$;

    public static {
        new org.apache.spark.deploy.SparkSubmitArguments$();
    }

    public Map<String, String> $lessinit$greater$default$2() {
        return package$.MODULE$.env();
    }

    private SparkSubmitArguments$() {
        MODULE$ = this;
    }
}

