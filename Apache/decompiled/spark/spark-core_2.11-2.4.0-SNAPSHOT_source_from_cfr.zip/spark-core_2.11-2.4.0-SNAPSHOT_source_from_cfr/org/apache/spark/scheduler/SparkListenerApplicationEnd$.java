/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerApplicationEnd;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;
import scala.runtime.BoxesRunTime;

public final class SparkListenerApplicationEnd$
extends AbstractFunction1<Object, SparkListenerApplicationEnd>
implements Serializable {
    public static final SparkListenerApplicationEnd$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerApplicationEnd$();
    }

    public final String toString() {
        return "SparkListenerApplicationEnd";
    }

    public SparkListenerApplicationEnd apply(long time) {
        return new SparkListenerApplicationEnd(time);
    }

    public Option<Object> unapply(SparkListenerApplicationEnd x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)BoxesRunTime.boxToLong((long)x$0.time()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerApplicationEnd$() {
        MODULE$ = this;
    }
}

