/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.shuffle.sort.SortShuffleWriter$$anonfun
 *  org.apache.spark.shuffle.sort.SortShuffleWriter$$anonfun$shouldBypassMergeSort
 *  scala.Function0
 *  scala.Option
 *  scala.Predef$
 *  scala.Serializable
 */
package org.apache.spark.shuffle.sort;

import org.apache.spark.Aggregator;
import org.apache.spark.Partitioner;
import org.apache.spark.ShuffleDependency;
import org.apache.spark.SparkConf;
import org.apache.spark.shuffle.sort.SortShuffleWriter$;
import scala.Function0;
import scala.Option;
import scala.Predef$;
import scala.Serializable;

public final class SortShuffleWriter$ {
    public static final SortShuffleWriter$ MODULE$;

    public static {
        new org.apache.spark.shuffle.sort.SortShuffleWriter$();
    }

    public boolean shouldBypassMergeSort(SparkConf conf, ShuffleDependency<?, ?, ?> dep) {
        boolean bl;
        if (dep.mapSideCombine()) {
            Predef$.MODULE$.require(dep.aggregator().isDefined(), (Function0)new Serializable(){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "Map-side combine without Aggregator specified!";
                }
            });
            bl = false;
        } else {
            int bypassMergeThreshold = conf.getInt("spark.shuffle.sort.bypassMergeThreshold", 200);
            bl = dep.partitioner().numPartitions() <= bypassMergeThreshold;
        }
        return bl;
    }

    private SortShuffleWriter$() {
        MODULE$ = this;
    }
}

