/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.internal.io;

import java.lang.reflect.Constructor;
import org.apache.spark.internal.io.FileCommitProtocol;
import org.apache.spark.util.Utils$;
import scala.runtime.BoxesRunTime;

public final class FileCommitProtocol$ {
    public static final FileCommitProtocol$ MODULE$;

    public static {
        new org.apache.spark.internal.io.FileCommitProtocol$();
    }

    public FileCommitProtocol instantiate(String className, String jobId, String outputPath, boolean dynamicPartitionOverwrite) {
        FileCommitProtocol fileCommitProtocol;
        Class<?> clazz = Utils$.MODULE$.classForName(className);
        try {
            Constructor<?> ctor = clazz.getDeclaredConstructor(String.class, String.class, Boolean.TYPE);
            fileCommitProtocol = (FileCommitProtocol)ctor.newInstance(jobId, outputPath, BoxesRunTime.boxToBoolean((boolean)dynamicPartitionOverwrite));
        }
        catch (NoSuchMethodException noSuchMethodException) {
            Constructor<?> ctor = clazz.getDeclaredConstructor(String.class, String.class);
            fileCommitProtocol = (FileCommitProtocol)ctor.newInstance(jobId, outputPath);
        }
        return fileCommitProtocol;
    }

    public boolean instantiate$default$4() {
        return false;
    }

    private FileCommitProtocol$() {
        MODULE$ = this;
    }
}

