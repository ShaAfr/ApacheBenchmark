/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Option$
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple7
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.AccumulableInfo;
import scala.None$;
import scala.Option;
import scala.Option$;
import scala.Serializable;
import scala.Some;
import scala.Tuple7;
import scala.runtime.BoxesRunTime;

public final class AccumulableInfo$
implements Serializable {
    public static final AccumulableInfo$ MODULE$;

    public static {
        new org.apache.spark.scheduler.AccumulableInfo$();
    }

    public AccumulableInfo apply(long id, String name2, Option<String> update2, String value2, boolean internal) {
        return new AccumulableInfo(id, (Option<String>)Option$.MODULE$.apply((Object)name2), update2, (Option<Object>)Option$.MODULE$.apply((Object)value2), internal, false, this.$lessinit$greater$default$7());
    }

    public AccumulableInfo apply(long id, String name2, Option<String> update2, String value2) {
        return new AccumulableInfo(id, (Option<String>)Option$.MODULE$.apply((Object)name2), update2, (Option<Object>)Option$.MODULE$.apply((Object)value2), false, false, this.$lessinit$greater$default$7());
    }

    public AccumulableInfo apply(long id, String name2, String value2) {
        return new AccumulableInfo(id, (Option<String>)Option$.MODULE$.apply((Object)name2), (Option<Object>)None$.MODULE$, (Option<Object>)Option$.MODULE$.apply((Object)value2), false, false, this.$lessinit$greater$default$7());
    }

    public Option<String> apply$default$7() {
        return None$.MODULE$;
    }

    public AccumulableInfo apply(long id, Option<String> name2, Option<Object> update2, Option<Object> value2, boolean internal, boolean countFailedValues, Option<String> metadata) {
        return new AccumulableInfo(id, name2, update2, value2, internal, countFailedValues, metadata);
    }

    public Option<Tuple7<Object, Option<String>, Option<Object>, Option<Object>, Object, Object, Option<String>>> unapply(AccumulableInfo x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple7((Object)BoxesRunTime.boxToLong((long)x$0.id()), x$0.name(), x$0.update(), x$0.value(), (Object)BoxesRunTime.boxToBoolean((boolean)x$0.internal()), (Object)BoxesRunTime.boxToBoolean((boolean)x$0.countFailedValues()), x$0.metadata()));
    }

    public Option<String> $lessinit$greater$default$7() {
        return None$.MODULE$;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private AccumulableInfo$() {
        MODULE$ = this;
    }
}

