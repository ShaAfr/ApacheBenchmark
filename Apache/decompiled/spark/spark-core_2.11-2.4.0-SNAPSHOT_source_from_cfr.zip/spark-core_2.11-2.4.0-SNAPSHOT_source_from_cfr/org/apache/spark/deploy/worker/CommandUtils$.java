/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.worker.CommandUtils$$anon
 *  org.apache.spark.deploy.worker.CommandUtils$$anonfun
 *  org.apache.spark.deploy.worker.CommandUtils$$anonfun$buildLocalCommand
 *  org.apache.spark.deploy.worker.CommandUtils$$anonfun$buildProcessBuilder
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Option$
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$ArrowAssoc$
 *  scala.Serializable
 *  scala.Tuple2
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Iterable
 *  scala.collection.JavaConverters$
 *  scala.collection.Map
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableLike
 *  scala.collection.convert.Decorators
 *  scala.collection.convert.Decorators$AsScala
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.generic.FilterMonadic
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.Buffer
 *  scala.collection.mutable.BufferLike
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.sys.package$
 */
package org.apache.spark.deploy.worker;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import org.apache.spark.SecurityManager;
import org.apache.spark.SecurityManager$;
import org.apache.spark.deploy.Command;
import org.apache.spark.deploy.worker.CommandUtils$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.launcher.WorkerCommandBuilder;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Option$;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.Tuple2;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.Iterable;
import scala.collection.JavaConverters$;
import scala.collection.Map;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableLike;
import scala.collection.convert.Decorators;
import scala.collection.generic.CanBuildFrom;
import scala.collection.generic.FilterMonadic;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.Buffer;
import scala.collection.mutable.BufferLike;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.sys.package$;

public final class CommandUtils$
implements Logging {
    public static final CommandUtils$ MODULE$;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.deploy.worker.CommandUtils$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public ProcessBuilder buildProcessBuilder(Command command, SecurityManager securityMgr, int memory, String sparkHome, Function1<String, String> substituteArguments, Seq<String> classPaths, Map<String, String> env) {
        Command localCommand = this.buildLocalCommand(command, securityMgr, substituteArguments, classPaths, env);
        Seq<String> commandSeq = this.buildCommandSeq(localCommand, memory, sparkHome);
        ProcessBuilder builder = new ProcessBuilder((String[])commandSeq.toArray(ClassTag$.MODULE$.apply(String.class)));
        java.util.Map<String, String> environment = builder.environment();
        localCommand.environment().withFilter((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply(Tuple2<String, String> check$ifrefutable$1) {
                Tuple2<String, String> tuple2 = check$ifrefutable$1;
                boolean bl = tuple2 != null;
                return bl;
            }
        }).foreach((Function1)new Serializable(environment){
            public static final long serialVersionUID = 0L;
            private final java.util.Map environment$1;

            public final String apply(Tuple2<String, String> x$1) {
                Tuple2<String, String> tuple2 = x$1;
                if (tuple2 != null) {
                    String key = (String)tuple2._1();
                    String value2 = (String)tuple2._2();
                    String string = this.environment$1.put(key, value2);
                    return string;
                }
                throw new scala.MatchError(tuple2);
            }
            {
                this.environment$1 = environment$1;
            }
        });
        return builder;
    }

    public Seq<String> buildProcessBuilder$default$6() {
        return (Seq)Seq$.MODULE$.empty();
    }

    public Map<String, String> buildProcessBuilder$default$7() {
        return package$.MODULE$.env();
    }

    private Seq<String> buildCommandSeq(Command command, int memory, String sparkHome) {
        List<String> cmd = new WorkerCommandBuilder(sparkHome, memory, command).buildCommand();
        return ((BufferLike)JavaConverters$.MODULE$.asScalaBufferConverter(cmd).asScala()).$plus$plus((GenTraversableOnce)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{command.mainClass()}))).$plus$plus(command.arguments());
    }

    private Command buildLocalCommand(Command command, SecurityManager securityMgr, Function1<String, String> substituteArguments, Seq<String> classPath, Map<String, String> env) {
        Map newEnvironment;
        Map map2;
        String libraryPathName = Utils$.MODULE$.libraryPathEnvName();
        Seq<String> libraryPathEntries = command.libraryPathEntries();
        Option cmdLibraryPath = command.environment().get((Object)libraryPathName);
        if (libraryPathEntries.nonEmpty() && new StringOps(Predef$.MODULE$.augmentString(libraryPathName)).nonEmpty()) {
            Seq libraryPaths = (Seq)((TraversableLike)libraryPathEntries.$plus$plus((GenTraversableOnce)Option$.MODULE$.option2Iterable(cmdLibraryPath), Seq$.MODULE$.canBuildFrom())).$plus$plus((GenTraversableOnce)Option$.MODULE$.option2Iterable(env.get((Object)libraryPathName)), Seq$.MODULE$.canBuildFrom());
            map2 = command.environment().$plus(new Tuple2((Object)libraryPathName, (Object)libraryPaths.mkString(File.pathSeparator)));
        } else {
            map2 = newEnvironment = command.environment();
        }
        if (securityMgr.isAuthenticationEnabled()) {
            newEnvironment = newEnvironment.$plus(Predef.ArrowAssoc$.MODULE$.$minus$greater$extension(Predef$.MODULE$.ArrowAssoc((Object)SecurityManager$.MODULE$.ENV_AUTH_SECRET()), (Object)securityMgr.getSecretKey()));
        }
        return new Command(command.mainClass(), (Seq<String>)((Seq)command.arguments().map(substituteArguments, Seq$.MODULE$.canBuildFrom())), (Map<String, String>)newEnvironment, (Seq<String>)((Seq)command.classPathEntries().$plus$plus(classPath, Seq$.MODULE$.canBuildFrom())), (Seq<String>)((Seq)Seq$.MODULE$.empty()), (Seq<String>)((Seq)command.javaOpts().filterNot((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final boolean apply(String x$2) {
                return x$2.startsWith(new scala.collection.mutable.StringBuilder().append((Object)"-D").append((Object)SecurityManager$.MODULE$.SPARK_AUTH_SECRET_CONF()).toString());
            }
        })));
    }

    private Seq<String> buildLocalCommand$default$4() {
        return (Seq)Seq$.MODULE$.empty();
    }

    public void redirectStream(InputStream in, File file) {
        FileOutputStream out = new FileOutputStream(file, true);
        new Thread(in, file, out){
            private final InputStream in$1;
            public final File file$1;
            private final FileOutputStream out$1;

            public void run() {
                try {
                    Utils$.MODULE$.copyStream(this.in$1, this.out$1, true, Utils$.MODULE$.copyStream$default$4());
                }
                catch (java.io.IOException iOException) {
                    CommandUtils$.MODULE$.logInfo((Function0<String>)new Serializable(this, iOException){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ anon.1 $outer;
                        private final java.io.IOException e$1;

                        public final String apply() {
                            return new scala.collection.mutable.StringBuilder().append((Object)"Redirection to ").append((Object)this.$outer.file$1).append((Object)" closed: ").append((Object)this.e$1.getMessage()).toString();
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.e$1 = e$1;
                        }
                    });
                }
            }
            {
                this.in$1 = in$1;
                this.file$1 = file$1;
                this.out$1 = out$1;
                super(new scala.collection.mutable.StringBuilder().append((Object)"redirect output to ").append((Object)file$1).toString());
            }
        }.start();
    }

    private CommandUtils$() {
        MODULE$ = this;
        Logging$class.$init$(this);
    }
}

