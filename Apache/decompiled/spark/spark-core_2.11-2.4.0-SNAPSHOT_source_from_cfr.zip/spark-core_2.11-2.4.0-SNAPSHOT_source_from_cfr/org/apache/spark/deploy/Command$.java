/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple6
 *  scala.collection.Map
 *  scala.collection.Seq
 *  scala.runtime.AbstractFunction6
 */
package org.apache.spark.deploy;

import org.apache.spark.deploy.Command;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple6;
import scala.collection.Map;
import scala.collection.Seq;
import scala.runtime.AbstractFunction6;

public final class Command$
extends AbstractFunction6<String, Seq<String>, Map<String, String>, Seq<String>, Seq<String>, Seq<String>, Command>
implements Serializable {
    public static final Command$ MODULE$;

    public static {
        new org.apache.spark.deploy.Command$();
    }

    public final String toString() {
        return "Command";
    }

    public Command apply(String mainClass, Seq<String> arguments, Map<String, String> environment, Seq<String> classPathEntries, Seq<String> libraryPathEntries, Seq<String> javaOpts) {
        return new Command(mainClass, arguments, environment, classPathEntries, libraryPathEntries, javaOpts);
    }

    public Option<Tuple6<String, Seq<String>, Map<String, String>, Seq<String>, Seq<String>, Seq<String>>> unapply(Command x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple6((Object)x$0.mainClass(), x$0.arguments(), x$0.environment(), x$0.classPathEntries(), x$0.libraryPathEntries(), x$0.javaOpts()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private Command$() {
        MODULE$ = this;
    }
}

