/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.worker.ProcessBuilderLike$$anon
 */
package org.apache.spark.deploy.worker;

import org.apache.spark.deploy.worker.ProcessBuilderLike;
import org.apache.spark.deploy.worker.ProcessBuilderLike$;

public final class ProcessBuilderLike$ {
    public static final ProcessBuilderLike$ MODULE$;

    public static {
        new org.apache.spark.deploy.worker.ProcessBuilderLike$();
    }

    public ProcessBuilderLike apply(ProcessBuilder processBuilder) {
        return new ProcessBuilderLike(processBuilder){
            private final ProcessBuilder processBuilder$1;

            public java.lang.Process start() {
                return this.processBuilder$1.start();
            }

            public scala.collection.Seq<java.lang.String> command() {
                return (scala.collection.Seq)scala.collection.JavaConverters$.MODULE$.asScalaBufferConverter(this.processBuilder$1.command()).asScala();
            }
            {
                this.processBuilder$1 = processBuilder$1;
            }
        };
    }

    private ProcessBuilderLike$() {
        MODULE$ = this;
    }
}

