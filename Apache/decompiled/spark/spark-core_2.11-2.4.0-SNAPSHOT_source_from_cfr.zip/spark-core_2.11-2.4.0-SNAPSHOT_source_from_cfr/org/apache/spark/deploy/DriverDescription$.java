/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple5
 *  scala.runtime.AbstractFunction5
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy;

import org.apache.spark.deploy.Command;
import org.apache.spark.deploy.DriverDescription;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple5;
import scala.runtime.AbstractFunction5;
import scala.runtime.BoxesRunTime;

public final class DriverDescription$
extends AbstractFunction5<String, Object, Object, Object, Command, DriverDescription>
implements Serializable {
    public static final DriverDescription$ MODULE$;

    public static {
        new org.apache.spark.deploy.DriverDescription$();
    }

    public final String toString() {
        return "DriverDescription";
    }

    public DriverDescription apply(String jarUrl, int mem, int cores, boolean supervise, Command command) {
        return new DriverDescription(jarUrl, mem, cores, supervise, command);
    }

    public Option<Tuple5<String, Object, Object, Object, Command>> unapply(DriverDescription x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple5((Object)x$0.jarUrl(), (Object)BoxesRunTime.boxToInteger((int)x$0.mem()), (Object)BoxesRunTime.boxToInteger((int)x$0.cores()), (Object)BoxesRunTime.boxToBoolean((boolean)x$0.supervise()), (Object)x$0.command()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private DriverDescription$() {
        MODULE$ = this;
    }
}

