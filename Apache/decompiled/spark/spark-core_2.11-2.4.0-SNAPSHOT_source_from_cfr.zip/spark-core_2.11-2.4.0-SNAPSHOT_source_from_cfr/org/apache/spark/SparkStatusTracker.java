/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.SparkStatusTracker$
 *  org.apache.spark.SparkStatusTracker$$anonfun
 *  org.apache.spark.SparkStatusTracker$$anonfun$getActiveJobIds
 *  org.apache.spark.SparkStatusTracker$$anonfun$getActiveStageIds
 *  org.apache.spark.SparkStatusTracker$$anonfun$getExecutorInfos
 *  org.apache.spark.SparkStatusTracker$$anonfun$getJobIdsForGroup
 *  org.apache.spark.SparkStatusTracker$$anonfun$getJobInfo
 *  org.apache.spark.SparkStatusTracker$$anonfun$getStageInfo
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Option$
 *  scala.Serializable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableLike
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark;

import java.util.Arrays;
import java.util.List;
import org.apache.spark.JobExecutionStatus;
import org.apache.spark.SparkContext;
import org.apache.spark.SparkExecutorInfo;
import org.apache.spark.SparkJobInfo;
import org.apache.spark.SparkStageInfo;
import org.apache.spark.SparkStatusTracker$;
import org.apache.spark.status.AppStatusStore;
import org.apache.spark.status.api.v1.ExecutorSummary;
import org.apache.spark.status.api.v1.JobData;
import org.apache.spark.status.api.v1.StageData;
import org.apache.spark.status.api.v1.StageStatus;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Option$;
import scala.Serializable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableLike;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001Y3A!\u0001\u0002\u0001\u0013\t\u00112\u000b]1sWN#\u0018\r^;t)J\f7m[3s\u0015\t\u0019A!A\u0003ta\u0006\u00148N\u0003\u0002\u0006\r\u00051\u0011\r]1dQ\u0016T\u0011aB\u0001\u0004_J<7\u0001A\n\u0003\u0001)\u0001\"a\u0003\b\u000e\u00031Q\u0011!D\u0001\u0006g\u000e\fG.Y\u0005\u0003\u001f1\u0011a!\u00118z%\u00164\u0007\u0002C\t\u0001\u0005\u0003\u0005\u000b\u0011\u0002\n\u0002\u0005M\u001c\u0007CA\n\u0015\u001b\u0005\u0011\u0011BA\u000b\u0003\u00051\u0019\u0006/\u0019:l\u0007>tG/\u001a=u\u0011!9\u0002A!A!\u0002\u0013A\u0012!B:u_J,\u0007CA\r\u001d\u001b\u0005Q\"BA\u000e\u0003\u0003\u0019\u0019H/\u0019;vg&\u0011QD\u0007\u0002\u000f\u0003B\u00048\u000b^1ukN\u001cFo\u001c:f\u0011\u0019y\u0002\u0001\"\u0001\u0003A\u00051A(\u001b8jiz\"2!\t\u0012$!\t\u0019\u0002\u0001C\u0003\u0012=\u0001\u0007!\u0003C\u0003\u0018=\u0001\u0007\u0001\u0004C\u0003&\u0001\u0011\u0005a%A\thKRTuNY%eg\u001a{'o\u0012:pkB$\"aJ\u0017\u0011\u0007-A#&\u0003\u0002*\u0019\t)\u0011I\u001d:bsB\u00111bK\u0005\u0003Y1\u00111!\u00138u\u0011\u0015qC\u00051\u00010\u0003!QwNY$s_V\u0004\bC\u0001\u00194\u001d\tY\u0011'\u0003\u00023\u0019\u00051\u0001K]3eK\u001aL!\u0001N\u001b\u0003\rM#(/\u001b8h\u0015\t\u0011D\u0002C\u00038\u0001\u0011\u0005\u0001(A\thKR\f5\r^5wKN#\u0018mZ3JIN$\u0012a\n\u0005\u0006u\u0001!\t\u0001O\u0001\u0010O\u0016$\u0018i\u0019;jm\u0016TuNY%eg\")A\b\u0001C\u0001{\u0005Qq-\u001a;K_\nLeNZ8\u0015\u0005y\"\u0005cA\u0006@\u0003&\u0011\u0001\t\u0004\u0002\u0007\u001fB$\u0018n\u001c8\u0011\u0005M\u0011\u0015BA\"\u0003\u00051\u0019\u0006/\u0019:l\u0015>\u0014\u0017J\u001c4p\u0011\u0015)5\b1\u0001+\u0003\u0015QwNY%e\u0011\u00159\u0005\u0001\"\u0001I\u000319W\r^*uC\u001e,\u0017J\u001c4p)\tIU\nE\u0002\f)\u0003\"aE&\n\u00051\u0013!AD*qCJ\\7\u000b^1hK&sgm\u001c\u0005\u0006\u001d\u001a\u0003\rAK\u0001\bgR\fw-Z%e\u0011\u0015\u0001\u0006\u0001\"\u0001R\u0003A9W\r^#yK\u000e,Ho\u001c:J]\u001a|7/F\u0001S!\rY\u0001f\u0015\t\u0003'QK!!\u0016\u0002\u0003#M\u0003\u0018M]6Fq\u0016\u001cW\u000f^8s\u0013:4w\u000e")
public class SparkStatusTracker {
    public final AppStatusStore org$apache$spark$SparkStatusTracker$$store;

    public int[] getJobIdsForGroup(String jobGroup) {
        Option expected = Option$.MODULE$.apply((Object)jobGroup);
        return (int[])((TraversableOnce)((TraversableLike)this.org$apache$spark$SparkStatusTracker$$store.jobsList(null).filter((Function1)new Serializable(this, expected){
            public static final long serialVersionUID = 0L;
            private final Option expected$1;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(JobData x$1) {
                Option option = this.expected$1;
                if (x$1.jobGroup() != null) {
                    Option<String> option2;
                    if (!option2.equals((Object)option)) return false;
                    return true;
                }
                if (option == null) return true;
                return false;
            }
            {
                this.expected$1 = expected$1;
            }
        })).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(JobData x$2) {
                return x$2.jobId();
            }
        }, Seq$.MODULE$.canBuildFrom())).toArray(ClassTag$.MODULE$.Int());
    }

    public int[] getActiveStageIds() {
        return (int[])((TraversableOnce)this.org$apache$spark$SparkStatusTracker$$store.stageList(Arrays.asList((Object[])new StageStatus[]{StageStatus.ACTIVE})).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(StageData x$3) {
                return x$3.stageId();
            }
        }, Seq$.MODULE$.canBuildFrom())).toArray(ClassTag$.MODULE$.Int());
    }

    public int[] getActiveJobIds() {
        return (int[])((TraversableOnce)this.org$apache$spark$SparkStatusTracker$$store.jobsList(Arrays.asList((Object[])new JobExecutionStatus[]{JobExecutionStatus.RUNNING})).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(JobData x$4) {
                return x$4.jobId();
            }
        }, Seq$.MODULE$.canBuildFrom())).toArray(ClassTag$.MODULE$.Int());
    }

    public Option<SparkJobInfo> getJobInfo(int jobId) {
        return this.org$apache$spark$SparkStatusTracker$$store.asOption(new Serializable(this, jobId){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ SparkStatusTracker $outer;
            private final int jobId$1;

            public final JobData apply() {
                return this.$outer.org$apache$spark$SparkStatusTracker$$store.job(this.jobId$1);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.jobId$1 = jobId$1;
            }
        }).map((Function1)new Serializable(this, jobId){
            public static final long serialVersionUID = 0L;
            private final int jobId$1;

            public final org.apache.spark.SparkJobInfoImpl apply(JobData job) {
                return new org.apache.spark.SparkJobInfoImpl(this.jobId$1, (int[])job.stageIds().toArray(ClassTag$.MODULE$.Int()), job.status());
            }
            {
                this.jobId$1 = jobId$1;
            }
        });
    }

    public Option<SparkStageInfo> getStageInfo(int stageId) {
        return this.org$apache$spark$SparkStatusTracker$$store.asOption(new Serializable(this, stageId){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ SparkStatusTracker $outer;
            private final int stageId$1;

            public final StageData apply() {
                return this.$outer.org$apache$spark$SparkStatusTracker$$store.lastStageAttempt(this.stageId$1);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.stageId$1 = stageId$1;
            }
        }).map((Function1)new Serializable(this, stageId){
            public static final long serialVersionUID = 0L;
            private final int stageId$1;

            public final org.apache.spark.SparkStageInfoImpl apply(StageData stage) {
                return new org.apache.spark.SparkStageInfoImpl(this.stageId$1, stage.attemptId(), scala.runtime.BoxesRunTime.unboxToLong((Object)stage.submissionTime().map((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final long apply(java.util.Date x$5) {
                        return x$5.getTime();
                    }
                }).getOrElse((Function0)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final long apply() {
                        return this.apply$mcJ$sp();
                    }

                    public long apply$mcJ$sp() {
                        return 0L;
                    }
                })), stage.name(), stage.numTasks(), stage.numActiveTasks(), stage.numCompleteTasks(), stage.numFailedTasks());
            }
            {
                this.stageId$1 = stageId$1;
            }
        });
    }

    public SparkExecutorInfo[] getExecutorInfos() {
        return (SparkExecutorInfo[])((TraversableOnce)this.org$apache$spark$SparkStatusTracker$$store.executorList(true).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final org.apache.spark.SparkExecutorInfoImpl apply(ExecutorSummary exec) {
                String[] arrstring;
                block6 : {
                    scala.Tuple2 tuple2;
                    block5 : {
                        block4 : {
                            arrstring = exec.hostPort().split(":", 2);
                            Option option = scala.Array$.MODULE$.unapplySeq((Object)arrstring);
                            if (option.isEmpty() || option.get() == null || ((scala.collection.SeqLike)option.get()).lengthCompare(2) != 0) break block4;
                            String h = (String)((scala.collection.SeqLike)option.get()).apply(0);
                            String p = (String)((scala.collection.SeqLike)option.get()).apply(1);
                            tuple2 = new scala.Tuple2((Object)h, (Object)scala.runtime.BoxesRunTime.boxToInteger((int)new scala.collection.immutable.StringOps(scala.Predef$.MODULE$.augmentString(p)).toInt()));
                            break block5;
                        }
                        Option option = scala.Array$.MODULE$.unapplySeq((Object)arrstring);
                        if (option.isEmpty() || option.get() == null || ((scala.collection.SeqLike)option.get()).lengthCompare(1) != 0) break block6;
                        String h = (String)((scala.collection.SeqLike)option.get()).apply(0);
                        tuple2 = new scala.Tuple2((Object)h, (Object)scala.runtime.BoxesRunTime.boxToInteger((int)-1));
                    }
                    scala.Tuple2 tuple22 = tuple2;
                    if (tuple22 != null) {
                        scala.Tuple2 tuple23;
                        String host = (String)tuple22._1();
                        int port = tuple22._2$mcI$sp();
                        scala.Tuple2 tuple24 = tuple23 = new scala.Tuple2((Object)host, (Object)scala.runtime.BoxesRunTime.boxToInteger((int)port));
                        String host2 = (String)tuple24._1();
                        int port2 = tuple24._2$mcI$sp();
                        long cachedMem = scala.runtime.BoxesRunTime.unboxToLong((Object)exec.memoryMetrics().map((Function1)new Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final long apply(org.apache.spark.status.api.v1.MemoryMetrics mem) {
                                return mem.usedOnHeapStorageMemory() + mem.usedOffHeapStorageMemory();
                            }
                        }).getOrElse((Function0)new Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final long apply() {
                                return this.apply$mcJ$sp();
                            }

                            public long apply$mcJ$sp() {
                                return 0L;
                            }
                        }));
                        return new org.apache.spark.SparkExecutorInfoImpl(host2, port2, cachedMem, exec.activeTasks());
                    }
                    throw new scala.MatchError((Object)tuple22);
                }
                throw new scala.MatchError((Object)arrstring);
            }
        }, Seq$.MODULE$.canBuildFrom())).toArray(ClassTag$.MODULE$.apply(SparkExecutorInfo.class));
    }

    public SparkStatusTracker(SparkContext sc, AppStatusStore store) {
        this.org$apache$spark$SparkStatusTracker$$store = store;
    }
}

