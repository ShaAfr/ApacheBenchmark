/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.annotation.DeveloperApi
 *  scala.Function0
 *  scala.Function1
 *  scala.Function2
 *  scala.Option
 *  scala.PartialFunction
 *  scala.Predef
 *  scala.Predef$$less$colon$less
 *  scala.Tuple2
 *  scala.collection.BufferedIterator
 *  scala.collection.GenIterable
 *  scala.collection.GenMap
 *  scala.collection.GenSeq
 *  scala.collection.GenSet
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Iterable
 *  scala.collection.Iterator
 *  scala.collection.Iterator$class
 *  scala.collection.Seq
 *  scala.collection.Traversable
 *  scala.collection.TraversableOnce
 *  scala.collection.TraversableOnce$class
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.IndexedSeq
 *  scala.collection.immutable.List
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.Set
 *  scala.collection.immutable.Stream
 *  scala.collection.immutable.Vector
 *  scala.collection.mutable.Buffer
 *  scala.collection.mutable.StringBuilder
 *  scala.math.Numeric
 *  scala.math.Ordering
 *  scala.reflect.ClassTag
 *  scala.reflect.ScalaSignature
 *  scala.runtime.Nothing$
 */
package org.apache.spark;

import org.apache.spark.TaskContext;
import org.apache.spark.annotation.DeveloperApi;
import scala.Function0;
import scala.Function1;
import scala.Function2;
import scala.Option;
import scala.PartialFunction;
import scala.Predef;
import scala.Tuple2;
import scala.collection.BufferedIterator;
import scala.collection.GenIterable;
import scala.collection.GenMap;
import scala.collection.GenSeq;
import scala.collection.GenSet;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.Iterable;
import scala.collection.Iterator;
import scala.collection.Seq;
import scala.collection.Traversable;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.IndexedSeq;
import scala.collection.immutable.List;
import scala.collection.immutable.Map;
import scala.collection.immutable.Set;
import scala.collection.immutable.Stream;
import scala.collection.immutable.Vector;
import scala.collection.mutable.Buffer;
import scala.collection.mutable.StringBuilder;
import scala.math.Numeric;
import scala.math.Ordering;
import scala.reflect.ClassTag;
import scala.reflect.ScalaSignature;
import scala.runtime.Nothing$;

@DeveloperApi
@ScalaSignature(bytes="\u0006\u000113A!\u0001\u0002\u0001\u0013\t)\u0012J\u001c;feJ,\b\u000f^5cY\u0016LE/\u001a:bi>\u0014(BA\u0002\u0005\u0003\u0015\u0019\b/\u0019:l\u0015\t)a!\u0001\u0004ba\u0006\u001c\u0007.\u001a\u0006\u0002\u000f\u0005\u0019qN]4\u0004\u0001U\u0011!bH\n\u0004\u0001-\t\u0002C\u0001\u0007\u0010\u001b\u0005i!\"\u0001\b\u0002\u000bM\u001c\u0017\r\\1\n\u0005Ai!AB!osJ+g\rE\u0002\u00135uq!a\u0005\r\u000f\u0005Q9R\"A\u000b\u000b\u0005YA\u0011A\u0002\u001fs_>$h(C\u0001\u000f\u0013\tIR\"A\u0004qC\u000e\\\u0017mZ3\n\u0005ma\"\u0001C%uKJ\fGo\u001c:\u000b\u0005ei\u0001C\u0001\u0010 \u0019\u0001!a\u0001\t\u0001\u0005\u0006\u0004\t#!\u0001+\u0012\u0005\t*\u0003C\u0001\u0007$\u0013\t!SBA\u0004O_RD\u0017N\\4\u0011\u000511\u0013BA\u0014\u000e\u0005\r\te.\u001f\u0005\tS\u0001\u0011)\u0019!C\u0001U\u000591m\u001c8uKb$X#A\u0016\u0011\u00051jS\"\u0001\u0002\n\u00059\u0012!a\u0003+bg.\u001cuN\u001c;fqRD\u0001\u0002\r\u0001\u0003\u0002\u0003\u0006IaK\u0001\tG>tG/\u001a=uA!A!\u0007\u0001BC\u0002\u0013\u00051'\u0001\u0005eK2,w-\u0019;f+\u0005\t\u0002\u0002C\u001b\u0001\u0005\u0003\u0005\u000b\u0011B\t\u0002\u0013\u0011,G.Z4bi\u0016\u0004\u0003\"B\u001c\u0001\t\u0003A\u0014A\u0002\u001fj]&$h\bF\u0002:um\u00022\u0001\f\u0001\u001e\u0011\u0015Ic\u00071\u0001,\u0011\u0015\u0011d\u00071\u0001\u0012\u0011\u0015i\u0004\u0001\"\u0001?\u0003\u001dA\u0017m\u001d(fqR,\u0012a\u0010\t\u0003\u0019\u0001K!!Q\u0007\u0003\u000f\t{w\u000e\\3b]\")1\t\u0001C\u0001\t\u0006!a.\u001a=u)\u0005i\u0002F\u0001\u0001G!\t9%*D\u0001I\u0015\tI%!\u0001\u0006b]:|G/\u0019;j_:L!a\u0013%\u0003\u0019\u0011+g/\u001a7pa\u0016\u0014\u0018\t]5")
public class InterruptibleIterator<T>
implements Iterator<T> {
    private final TaskContext context;
    private final Iterator<T> delegate;

    public Iterator<T> seq() {
        return Iterator.class.seq((Iterator)this);
    }

    public boolean isEmpty() {
        return Iterator.class.isEmpty((Iterator)this);
    }

    public boolean isTraversableAgain() {
        return Iterator.class.isTraversableAgain((Iterator)this);
    }

    public boolean hasDefiniteSize() {
        return Iterator.class.hasDefiniteSize((Iterator)this);
    }

    public Iterator<T> take(int n) {
        return Iterator.class.take((Iterator)this, (int)n);
    }

    public Iterator<T> drop(int n) {
        return Iterator.class.drop((Iterator)this, (int)n);
    }

    public Iterator<T> slice(int from, int until) {
        return Iterator.class.slice((Iterator)this, (int)from, (int)until);
    }

    public <B> Iterator<B> map(Function1<T, B> f) {
        return Iterator.class.map((Iterator)this, f);
    }

    public <B> Iterator<B> $plus$plus(Function0<GenTraversableOnce<B>> that) {
        return Iterator.class.$plus$plus((Iterator)this, that);
    }

    public <B> Iterator<B> flatMap(Function1<T, GenTraversableOnce<B>> f) {
        return Iterator.class.flatMap((Iterator)this, f);
    }

    public Iterator<T> filter(Function1<T, Object> p) {
        return Iterator.class.filter((Iterator)this, p);
    }

    public <B> boolean corresponds(GenTraversableOnce<B> that, Function2<T, B, Object> p) {
        return Iterator.class.corresponds((Iterator)this, that, p);
    }

    public Iterator<T> withFilter(Function1<T, Object> p) {
        return Iterator.class.withFilter((Iterator)this, p);
    }

    public Iterator<T> filterNot(Function1<T, Object> p) {
        return Iterator.class.filterNot((Iterator)this, p);
    }

    public <B> Iterator<B> collect(PartialFunction<T, B> pf) {
        return Iterator.class.collect((Iterator)this, pf);
    }

    public <B> Iterator<B> scanLeft(B z, Function2<B, T, B> op) {
        return Iterator.class.scanLeft((Iterator)this, z, op);
    }

    public <B> Iterator<B> scanRight(B z, Function2<T, B, B> op) {
        return Iterator.class.scanRight((Iterator)this, z, op);
    }

    public Iterator<T> takeWhile(Function1<T, Object> p) {
        return Iterator.class.takeWhile((Iterator)this, p);
    }

    public Tuple2<Iterator<T>, Iterator<T>> partition(Function1<T, Object> p) {
        return Iterator.class.partition((Iterator)this, p);
    }

    public Tuple2<Iterator<T>, Iterator<T>> span(Function1<T, Object> p) {
        return Iterator.class.span((Iterator)this, p);
    }

    public Iterator<T> dropWhile(Function1<T, Object> p) {
        return Iterator.class.dropWhile((Iterator)this, p);
    }

    public <B> Iterator<Tuple2<T, B>> zip(Iterator<B> that) {
        return Iterator.class.zip((Iterator)this, that);
    }

    public <A1> Iterator<A1> padTo(int len, A1 elem) {
        return Iterator.class.padTo((Iterator)this, (int)len, elem);
    }

    public Iterator<Tuple2<T, Object>> zipWithIndex() {
        return Iterator.class.zipWithIndex((Iterator)this);
    }

    public <B, A1, B1> Iterator<Tuple2<A1, B1>> zipAll(Iterator<B> that, A1 thisElem, B1 thatElem) {
        return Iterator.class.zipAll((Iterator)this, that, thisElem, thatElem);
    }

    public <U> void foreach(Function1<T, U> f) {
        Iterator.class.foreach((Iterator)this, f);
    }

    public boolean forall(Function1<T, Object> p) {
        return Iterator.class.forall((Iterator)this, p);
    }

    public boolean exists(Function1<T, Object> p) {
        return Iterator.class.exists((Iterator)this, p);
    }

    public boolean contains(Object elem) {
        return Iterator.class.contains((Iterator)this, (Object)elem);
    }

    public Option<T> find(Function1<T, Object> p) {
        return Iterator.class.find((Iterator)this, p);
    }

    public int indexWhere(Function1<T, Object> p) {
        return Iterator.class.indexWhere((Iterator)this, p);
    }

    public <B> int indexOf(B elem) {
        return Iterator.class.indexOf((Iterator)this, elem);
    }

    public BufferedIterator<T> buffered() {
        return Iterator.class.buffered((Iterator)this);
    }

    public <B> Iterator<T> grouped(int size) {
        return Iterator.class.grouped((Iterator)this, (int)size);
    }

    public <B> Iterator<T> sliding(int size, int step) {
        return Iterator.class.sliding((Iterator)this, (int)size, (int)step);
    }

    public int length() {
        return Iterator.class.length((Iterator)this);
    }

    public Tuple2<Iterator<T>, Iterator<T>> duplicate() {
        return Iterator.class.duplicate((Iterator)this);
    }

    public <B> Iterator<B> patch(int from, Iterator<B> patchElems, int replaced) {
        return Iterator.class.patch((Iterator)this, (int)from, patchElems, (int)replaced);
    }

    public <B> void copyToArray(Object xs, int start2, int len) {
        Iterator.class.copyToArray((Iterator)this, (Object)xs, (int)start2, (int)len);
    }

    public boolean sameElements(Iterator<?> that) {
        return Iterator.class.sameElements((Iterator)this, that);
    }

    public Traversable<T> toTraversable() {
        return Iterator.class.toTraversable((Iterator)this);
    }

    public Iterator<T> toIterator() {
        return Iterator.class.toIterator((Iterator)this);
    }

    public Stream<T> toStream() {
        return Iterator.class.toStream((Iterator)this);
    }

    public String toString() {
        return Iterator.class.toString((Iterator)this);
    }

    public <B> int sliding$default$2() {
        return Iterator.class.sliding$default$2((Iterator)this);
    }

    public List<T> reversed() {
        return TraversableOnce.class.reversed((TraversableOnce)this);
    }

    public int size() {
        return TraversableOnce.class.size((TraversableOnce)this);
    }

    public boolean nonEmpty() {
        return TraversableOnce.class.nonEmpty((TraversableOnce)this);
    }

    public int count(Function1<T, Object> p) {
        return TraversableOnce.class.count((TraversableOnce)this, p);
    }

    public <B> Option<B> collectFirst(PartialFunction<T, B> pf) {
        return TraversableOnce.class.collectFirst((TraversableOnce)this, pf);
    }

    public <B> B $div$colon(B z, Function2<B, T, B> op) {
        return (B)TraversableOnce.class.$div$colon((TraversableOnce)this, z, op);
    }

    public <B> B $colon$bslash(B z, Function2<T, B, B> op) {
        return (B)TraversableOnce.class.$colon$bslash((TraversableOnce)this, z, op);
    }

    public <B> B foldLeft(B z, Function2<B, T, B> op) {
        return (B)TraversableOnce.class.foldLeft((TraversableOnce)this, z, op);
    }

    public <B> B foldRight(B z, Function2<T, B, B> op) {
        return (B)TraversableOnce.class.foldRight((TraversableOnce)this, z, op);
    }

    public <B> B reduceLeft(Function2<B, T, B> op) {
        return (B)TraversableOnce.class.reduceLeft((TraversableOnce)this, op);
    }

    public <B> B reduceRight(Function2<T, B, B> op) {
        return (B)TraversableOnce.class.reduceRight((TraversableOnce)this, op);
    }

    public <B> Option<B> reduceLeftOption(Function2<B, T, B> op) {
        return TraversableOnce.class.reduceLeftOption((TraversableOnce)this, op);
    }

    public <B> Option<B> reduceRightOption(Function2<T, B, B> op) {
        return TraversableOnce.class.reduceRightOption((TraversableOnce)this, op);
    }

    public <A1> A1 reduce(Function2<A1, A1, A1> op) {
        return (A1)TraversableOnce.class.reduce((TraversableOnce)this, op);
    }

    public <A1> Option<A1> reduceOption(Function2<A1, A1, A1> op) {
        return TraversableOnce.class.reduceOption((TraversableOnce)this, op);
    }

    public <A1> A1 fold(A1 z, Function2<A1, A1, A1> op) {
        return (A1)TraversableOnce.class.fold((TraversableOnce)this, z, op);
    }

    public <B> B aggregate(Function0<B> z, Function2<B, T, B> seqop, Function2<B, B, B> combop) {
        return (B)TraversableOnce.class.aggregate((TraversableOnce)this, z, seqop, combop);
    }

    public <B> B sum(Numeric<B> num) {
        return (B)TraversableOnce.class.sum((TraversableOnce)this, num);
    }

    public <B> B product(Numeric<B> num) {
        return (B)TraversableOnce.class.product((TraversableOnce)this, num);
    }

    public <B> T min(Ordering<B> cmp) {
        return (T)TraversableOnce.class.min((TraversableOnce)this, cmp);
    }

    public <B> T max(Ordering<B> cmp) {
        return (T)TraversableOnce.class.max((TraversableOnce)this, cmp);
    }

    public <B> T maxBy(Function1<T, B> f, Ordering<B> cmp) {
        return (T)TraversableOnce.class.maxBy((TraversableOnce)this, f, cmp);
    }

    public <B> T minBy(Function1<T, B> f, Ordering<B> cmp) {
        return (T)TraversableOnce.class.minBy((TraversableOnce)this, f, cmp);
    }

    public <B> void copyToBuffer(Buffer<B> dest) {
        TraversableOnce.class.copyToBuffer((TraversableOnce)this, dest);
    }

    public <B> void copyToArray(Object xs, int start2) {
        TraversableOnce.class.copyToArray((TraversableOnce)this, (Object)xs, (int)start2);
    }

    public <B> void copyToArray(Object xs) {
        TraversableOnce.class.copyToArray((TraversableOnce)this, (Object)xs);
    }

    public <B> Object toArray(ClassTag<B> evidence$1) {
        return TraversableOnce.class.toArray((TraversableOnce)this, evidence$1);
    }

    public List<T> toList() {
        return TraversableOnce.class.toList((TraversableOnce)this);
    }

    public Iterable<T> toIterable() {
        return TraversableOnce.class.toIterable((TraversableOnce)this);
    }

    public Seq<T> toSeq() {
        return TraversableOnce.class.toSeq((TraversableOnce)this);
    }

    public IndexedSeq<T> toIndexedSeq() {
        return TraversableOnce.class.toIndexedSeq((TraversableOnce)this);
    }

    public <B> Buffer<B> toBuffer() {
        return TraversableOnce.class.toBuffer((TraversableOnce)this);
    }

    public <B> Set<B> toSet() {
        return TraversableOnce.class.toSet((TraversableOnce)this);
    }

    public Vector<T> toVector() {
        return TraversableOnce.class.toVector((TraversableOnce)this);
    }

    public <Col> Col to(CanBuildFrom<Nothing$, T, Col> cbf) {
        return (Col)TraversableOnce.class.to((TraversableOnce)this, cbf);
    }

    public <T, U> Map<T, U> toMap(Predef.$less$colon$less<T, Tuple2<T, U>> ev) {
        return TraversableOnce.class.toMap((TraversableOnce)this, ev);
    }

    public String mkString(String start2, String sep, String end) {
        return TraversableOnce.class.mkString((TraversableOnce)this, (String)start2, (String)sep, (String)end);
    }

    public String mkString(String sep) {
        return TraversableOnce.class.mkString((TraversableOnce)this, (String)sep);
    }

    public String mkString() {
        return TraversableOnce.class.mkString((TraversableOnce)this);
    }

    public StringBuilder addString(StringBuilder b, String start2, String sep, String end) {
        return TraversableOnce.class.addString((TraversableOnce)this, (StringBuilder)b, (String)start2, (String)sep, (String)end);
    }

    public StringBuilder addString(StringBuilder b, String sep) {
        return TraversableOnce.class.addString((TraversableOnce)this, (StringBuilder)b, (String)sep);
    }

    public StringBuilder addString(StringBuilder b) {
        return TraversableOnce.class.addString((TraversableOnce)this, (StringBuilder)b);
    }

    public TaskContext context() {
        return this.context;
    }

    public Iterator<T> delegate() {
        return this.delegate;
    }

    public boolean hasNext() {
        this.context().killTaskIfInterrupted();
        return this.delegate().hasNext();
    }

    public T next() {
        return (T)this.delegate().next();
    }

    public InterruptibleIterator(TaskContext context, Iterator<T> delegate) {
        this.context = context;
        this.delegate = delegate;
        TraversableOnce.class.$init$((TraversableOnce)this);
        Iterator.class.$init$((Iterator)this);
    }
}

