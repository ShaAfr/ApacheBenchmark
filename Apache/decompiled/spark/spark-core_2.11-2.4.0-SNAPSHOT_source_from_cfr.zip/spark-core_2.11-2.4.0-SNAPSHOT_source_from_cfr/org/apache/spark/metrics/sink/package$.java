/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.metrics.sink;

public final class package$ {
    public static final package$ MODULE$;

    public static {
        new org.apache.spark.metrics.sink.package$();
    }

    private package$() {
        MODULE$ = this;
    }
}

