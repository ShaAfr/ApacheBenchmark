/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark;

import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001m1q!\u0001\u0002\u0011\u0002G%\u0012BA\u0006DY\u0016\fg.\u001e9UCN\\'BA\u0002\u0005\u0003\u0015\u0019\b/\u0019:l\u0015\t)a!\u0001\u0004ba\u0006\u001c\u0007.\u001a\u0006\u0002\u000f\u0005\u0019qN]4\u0004\u0001M\u0011\u0001A\u0003\t\u0003\u00179i\u0011\u0001\u0004\u0006\u0002\u001b\u0005)1oY1mC&\u0011q\u0002\u0004\u0002\u0007\u0003:L(+\u001a4*\r\u0001\t2#F\f\u001a\u0013\t\u0011\"A\u0001\u0006DY\u0016\fg.Q2dk6L!\u0001\u0006\u0002\u0003\u001d\rcW-\u00198Ce>\fGmY1ti&\u0011aC\u0001\u0002\u0010\u00072,\u0017M\\\"iK\u000e\\\u0007o\\5oi&\u0011\u0001D\u0001\u0002\t\u00072,\u0017M\u001c*E\t&\u0011!D\u0001\u0002\r\u00072,\u0017M\\*ik\u001a4G.\u001a")
public interface CleanupTask {
}

