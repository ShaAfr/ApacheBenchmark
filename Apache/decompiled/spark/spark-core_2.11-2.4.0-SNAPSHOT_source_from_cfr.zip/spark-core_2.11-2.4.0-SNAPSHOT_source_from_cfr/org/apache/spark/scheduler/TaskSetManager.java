/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$abortIfCompletelyBlacklisted
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$addPendingTask
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$canFetchMoreResults
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$checkSpeculatableTasks
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$computeValidLocalityLevels
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$dequeueSpeculativeTask
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$dequeueTask
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$executorLost
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$getAllowedLocalityLevel
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$getPendingTasksForExecutor
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$getPendingTasksForHost
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$handleFailedTask
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$handleSuccessfulTask
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$hasAttemptOnHost
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$isTaskBlacklistedOnExecOrNode
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$maybeFinishTaskSet
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$moreTasksToRunIn
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$moreTasksToRunIn$1
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$org$apache$spark$scheduler$TaskSetManager$
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$org$apache$spark$scheduler$TaskSetManager$$getPendingTasksForRack
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$recomputeLocality
 *  org.apache.spark.scheduler.TaskSetManager$$anonfun$resourceOffer
 *  org.slf4j.Logger
 *  scala.Array$
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Function0
 *  scala.Function1
 *  scala.MatchError
 *  scala.None$
 *  scala.Option
 *  scala.Predef$
 *  scala.Serializable
 *  scala.Some
 *  scala.StringContext
 *  scala.Tuple2
 *  scala.Tuple2$mcIJ
 *  scala.Tuple2$mcIJ$sp
 *  scala.Tuple2$mcZI
 *  scala.Tuple2$mcZI$sp
 *  scala.Tuple3
 *  scala.collection.GenMap
 *  scala.collection.GenTraversable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.Set
 *  scala.collection.concurrent.Map
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.generic.FilterMonadic
 *  scala.collection.immutable.List
 *  scala.collection.immutable.Nil$
 *  scala.collection.immutable.Range
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayBuffer
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.HashMap
 *  scala.collection.mutable.HashMap$
 *  scala.collection.mutable.HashSet
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.math.Ordering
 *  scala.math.Ordering$Double$
 *  scala.math.package$
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BooleanRef
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.NonLocalReturnControl
 *  scala.runtime.RichDouble$
 *  scala.runtime.RichInt$
 *  scala.runtime.TraitSetter
 */
package org.apache.spark.scheduler;

import java.io.NotSerializableException;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.apache.spark.ExceptionFailure;
import org.apache.spark.ExecutorLostFailure;
import org.apache.spark.FetchFailed;
import org.apache.spark.MapOutputTrackerMaster;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.SparkEnv;
import org.apache.spark.SparkEnv$;
import org.apache.spark.Success$;
import org.apache.spark.TaskEndReason;
import org.apache.spark.TaskFailedReason;
import org.apache.spark.TaskNotSerializableException;
import org.apache.spark.TaskState$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.internal.config.ConfigEntry;
import org.apache.spark.scheduler.BlacklistTracker;
import org.apache.spark.scheduler.DAGScheduler;
import org.apache.spark.scheduler.DirectTaskResult;
import org.apache.spark.scheduler.ExecutorLossReason;
import org.apache.spark.scheduler.Pool;
import org.apache.spark.scheduler.Schedulable;
import org.apache.spark.scheduler.SchedulingMode$;
import org.apache.spark.scheduler.ShuffleMapTask;
import org.apache.spark.scheduler.Task;
import org.apache.spark.scheduler.TaskDescription;
import org.apache.spark.scheduler.TaskInfo;
import org.apache.spark.scheduler.TaskLocality$;
import org.apache.spark.scheduler.TaskLocation;
import org.apache.spark.scheduler.TaskSchedulerImpl;
import org.apache.spark.scheduler.TaskSet;
import org.apache.spark.scheduler.TaskSetBlacklist;
import org.apache.spark.scheduler.TaskSetManager$;
import org.apache.spark.scheduler.TaskSetManager$$anonfun$org$apache$spark$scheduler$TaskSetManager$;
import org.apache.spark.serializer.Serializer;
import org.apache.spark.serializer.SerializerInstance;
import org.apache.spark.storage.BlockManager;
import org.apache.spark.storage.BlockManagerId;
import org.apache.spark.util.AccumulatorV2;
import org.apache.spark.util.Clock;
import org.apache.spark.util.Utils$;
import org.apache.spark.util.collection.MedianHeap;
import org.slf4j.Logger;
import scala.Array$;
import scala.Enumeration;
import scala.Function0;
import scala.Function1;
import scala.MatchError;
import scala.None$;
import scala.Option;
import scala.Predef$;
import scala.Serializable;
import scala.Some;
import scala.StringContext;
import scala.Tuple2;
import scala.Tuple3;
import scala.collection.GenMap;
import scala.collection.GenTraversable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.Set;
import scala.collection.concurrent.Map;
import scala.collection.generic.CanBuildFrom;
import scala.collection.generic.FilterMonadic;
import scala.collection.immutable.List;
import scala.collection.immutable.Nil$;
import scala.collection.immutable.Range;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayBuffer;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.HashMap;
import scala.collection.mutable.HashMap$;
import scala.collection.mutable.HashSet;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.math.Ordering;
import scala.math.package$;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.reflect.ScalaSignature;
import scala.runtime.BooleanRef;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.runtime.NonLocalReturnControl;
import scala.runtime.RichDouble$;
import scala.runtime.RichInt$;
import scala.runtime.TraitSetter;

@ScalaSignature(bytes="\u0006\u0001\u0015mf!B\u0001\u0003\u0001\u0011Q!A\u0004+bg.\u001cV\r^'b]\u0006<WM\u001d\u0006\u0003\u0007\u0011\t\u0011b]2iK\u0012,H.\u001a:\u000b\u0005\u00151\u0011!B:qCJ\\'BA\u0004\t\u0003\u0019\t\u0007/Y2iK*\t\u0011\"A\u0002pe\u001e\u001cB\u0001A\u0006\u0012+A\u0011AbD\u0007\u0002\u001b)\ta\"A\u0003tG\u0006d\u0017-\u0003\u0002\u0011\u001b\t1\u0011I\\=SK\u001a\u0004\"AE\n\u000e\u0003\tI!\u0001\u0006\u0002\u0003\u0017M\u001b\u0007.\u001a3vY\u0006\u0014G.\u001a\t\u0003-ei\u0011a\u0006\u0006\u00031\u0011\t\u0001\"\u001b8uKJt\u0017\r\\\u0005\u00035]\u0011q\u0001T8hO&tw\r\u0003\u0005\u001d\u0001\t\u0005\t\u0015!\u0003\u001f\u0003\u0015\u00198\r[3e\u0007\u0001\u0001\"AE\u0010\n\u0005\u0001\u0012!!\u0005+bg.\u001c6\r[3ek2,'/S7qY\"A!\u0005\u0001BC\u0002\u0013\u00051%A\u0004uCN\\7+\u001a;\u0016\u0003\u0011\u0002\"AE\u0013\n\u0005\u0019\u0012!a\u0002+bg.\u001cV\r\u001e\u0005\tQ\u0001\u0011\t\u0011)A\u0005I\u0005AA/Y:l'\u0016$\b\u0005\u0003\u0005+\u0001\t\u0015\r\u0011\"\u0001,\u0003=i\u0017\r\u001f+bg.4\u0015-\u001b7ve\u0016\u001cX#\u0001\u0017\u0011\u00051i\u0013B\u0001\u0018\u000e\u0005\rIe\u000e\u001e\u0005\ta\u0001\u0011\t\u0011)A\u0005Y\u0005\u0001R.\u0019=UCN\\g)Y5mkJ,7\u000f\t\u0005\te\u0001\u0011\t\u0011)A\u0005g\u0005\u0001\"\r\\1dW2L7\u000f\u001e+sC\u000e\\WM\u001d\t\u0004\u0019Q2\u0014BA\u001b\u000e\u0005\u0019y\u0005\u000f^5p]B\u0011!cN\u0005\u0003q\t\u0011\u0001C\u00117bG.d\u0017n\u001d;Ue\u0006\u001c7.\u001a:\t\u0011i\u0002!\u0011!Q\u0001\nm\nQa\u00197pG.\u0004\"\u0001P \u000e\u0003uR!A\u0010\u0003\u0002\tU$\u0018\u000e\\\u0005\u0003\u0001v\u0012Qa\u00117pG.DQA\u0011\u0001\u0005\u0002\r\u000ba\u0001P5oSRtDC\u0002#F\r\u001eC\u0015\n\u0005\u0002\u0013\u0001!)A$\u0011a\u0001=!)!%\u0011a\u0001I!)!&\u0011a\u0001Y!9!'\u0011I\u0001\u0002\u0004\u0019\u0004b\u0002\u001eB!\u0003\u0005\ra\u000f\u0005\b\u0017\u0002\u0011\r\u0011\"\u0003M\u0003\u0011\u0019wN\u001c4\u0016\u00035\u0003\"AT(\u000e\u0003\u0011I!\u0001\u0015\u0003\u0003\u0013M\u0003\u0018M]6D_:4\u0007B\u0002*\u0001A\u0003%Q*A\u0003d_:4\u0007\u0005C\u0004U\u0001\t\u0007I\u0011B+\u0002\u0013\u0005$G-\u001a3KCJ\u001cX#\u0001,\u0011\t]cf,Z\u0007\u00021*\u0011\u0011LW\u0001\b[V$\u0018M\u00197f\u0015\tYV\"\u0001\u0006d_2dWm\u0019;j_:L!!\u0018-\u0003\u000f!\u000b7\u000f['baB\u0011qL\u0019\b\u0003\u0019\u0001L!!Y\u0007\u0002\rA\u0013X\rZ3g\u0013\t\u0019GM\u0001\u0004TiJLgn\u001a\u0006\u0003C6\u0001\"\u0001\u00044\n\u0005\u001dl!\u0001\u0002'p]\u001eDa!\u001b\u0001!\u0002\u00131\u0016AC1eI\u0016$'*\u0019:tA!91\u000e\u0001b\u0001\n\u0013)\u0016AC1eI\u0016$g)\u001b7fg\"1Q\u000e\u0001Q\u0001\nY\u000b1\"\u00193eK\u00124\u0015\u000e\\3tA!9q\u000e\u0001b\u0001\n\u0003\u0001\u0018\u0001F*Q\u000b\u000e+F*\u0011+J\u001f:{\u0016+V!O)&cU)F\u0001r!\ta!/\u0003\u0002t\u001b\t1Ai\\;cY\u0016Da!\u001e\u0001!\u0002\u0013\t\u0018!F*Q\u000b\u000e+F*\u0011+J\u001f:{\u0016+V!O)&cU\t\t\u0005\bo\u0002\u0011\r\u0011\"\u0001q\u0003Y\u0019\u0006+R\"V\u0019\u0006#\u0016j\u0014(`\u001bVcE+\u0013)M\u0013\u0016\u0013\u0006BB=\u0001A\u0003%\u0011/A\fT!\u0016\u001bU\u000bT!U\u0013>su,T+M)&\u0003F*S#SA!91\u0010\u0001b\u0001\n\u0003a\u0018!D7bqJ+7/\u001e7u'&TX-F\u0001f\u0011\u0019q\b\u0001)A\u0005K\u0006qQ.\u0019=SKN,H\u000e^*ju\u0016\u0004\u0003\"CA\u0001\u0001\t\u0007I\u0011AA\u0002\u0003I\u0019\b/Z2vY\u0006$\u0018n\u001c8F]\u0006\u0014G.\u001a3\u0016\u0005\u0005\u0015\u0001c\u0001\u0007\u0002\b%\u0019\u0011\u0011B\u0007\u0003\u000f\t{w\u000e\\3b]\"A\u0011Q\u0002\u0001!\u0002\u0013\t)!A\nta\u0016\u001cW\u000f\\1uS>tWI\\1cY\u0016$\u0007\u0005C\u0005\u0002\u0012\u0001\u0011\r\u0011\"\u0001\u0002\u0014\u0005\u0019QM\u001c<\u0016\u0005\u0005U\u0001c\u0001(\u0002\u0018%\u0019\u0011\u0011\u0004\u0003\u0003\u0011M\u0003\u0018M]6F]ZD\u0001\"!\b\u0001A\u0003%\u0011QC\u0001\u0005K:4\b\u0005C\u0005\u0002\"\u0001\u0011\r\u0011\"\u0001\u0002$\u0005\u00191/\u001a:\u0016\u0005\u0005\u0015\u0002\u0003BA\u0014\u0003[i!!!\u000b\u000b\u0007\u0005-B!\u0001\u0006tKJL\u0017\r\\5{KJLA!a\f\u0002*\t\u00112+\u001a:jC2L'0\u001a:J]N$\u0018M\\2f\u0011!\t\u0019\u0004\u0001Q\u0001\n\u0005\u0015\u0012\u0001B:fe\u0002B\u0011\"a\u000e\u0001\u0005\u0004%\t!!\u000f\u0002\u000bQ\f7o[:\u0016\u0005\u0005m\u0002#\u0002\u0007\u0002>\u0005\u0005\u0013bAA \u001b\t)\u0011I\u001d:bsB\"\u00111IA'!\u0015\u0011\u0012QIA%\u0013\r\t9E\u0001\u0002\u0005)\u0006\u001c8\u000e\u0005\u0003\u0002L\u00055C\u0002\u0001\u0003\f\u0003\u001f\u0002\u0011\u0011!A\u0001\u0006\u0003\t)FA\u0002`IEJ1!a\u0015&\u0003\u0019!\u0018m]6tAE!\u0011qKA/!\ra\u0011\u0011L\u0005\u0004\u00037j!a\u0002(pi\"Lgn\u001a\t\u0004\u0019\u0005}\u0013bAA1\u001b\t\u0019\u0011I\\=\t\u0011\u0005M\u0003\u0001)A\u0005\u0003wA\u0001\"a\u001a\u0001\u0005\u0004%\taK\u0001\t]VlG+Y:lg\"9\u00111\u000e\u0001!\u0002\u0013a\u0013!\u00038v[R\u000b7o[:!\u0011%\ty\u0007\u0001b\u0001\n\u0003\t\t(A\u0007d_BLWm\u001d*v]:LgnZ\u000b\u0003\u0003g\u0002B\u0001DA\u001fY!A\u0011q\u000f\u0001!\u0002\u0013\t\u0019(\u0001\bd_BLWm\u001d*v]:Lgn\u001a\u0011\t\u0013\u0005m\u0004A1A\u0005\u0002\u0005u\u0014AC:vG\u000e,7o\u001d4vYV\u0011\u0011q\u0010\t\u0006\u0019\u0005u\u0012Q\u0001\u0005\t\u0003\u0007\u0003\u0001\u0015!\u0003\u0002\u0000\u0005Y1/^2dKN\u001ch-\u001e7!\u0011%\t9\t\u0001b\u0001\n\u0013\t\t(A\u0006ok64\u0015-\u001b7ve\u0016\u001c\b\u0002CAF\u0001\u0001\u0006I!a\u001d\u0002\u00199,XNR1jYV\u0014Xm\u001d\u0011\t\u0013\u0005=\u0005A1A\u0005\n\u0005u\u0014\u0001F6jY2,GMQ=Pi\",'/\u0011;uK6\u0004H\u000f\u0003\u0005\u0002\u0014\u0002\u0001\u000b\u0011BA@\u0003UY\u0017\u000e\u001c7fI\nKx\n\u001e5fe\u0006#H/Z7qi\u0002B\u0011\"a&\u0001\u0005\u0004%\t!!'\u0002\u0019Q\f7o[!ui\u0016l\u0007\u000f^:\u0016\u0005\u0005m\u0005#\u0002\u0007\u0002>\u0005u\u0005CBAP\u0003_\u000b)L\u0004\u0003\u0002\"\u0006-f\u0002BAR\u0003Sk!!!*\u000b\u0007\u0005\u001dV$\u0001\u0004=e>|GOP\u0005\u0002\u001d%\u0019\u0011QV\u0007\u0002\u000fA\f7m[1hK&!\u0011\u0011WAZ\u0005\u0011a\u0015n\u001d;\u000b\u0007\u00055V\u0002E\u0002\u0013\u0003oK1!!/\u0003\u0005!!\u0016m]6J]\u001a|\u0007\u0002CA_\u0001\u0001\u0006I!a'\u0002\u001bQ\f7o[!ui\u0016l\u0007\u000f^:!\u0011%\t\t\r\u0001a\u0001\n\u0003\u00111&A\buCN\\7oU;dG\u0016\u001c8OZ;m\u0011)\t)\r\u0001a\u0001\n\u0003\u0011\u0011qY\u0001\u0014i\u0006\u001c8n]*vG\u000e,7o\u001d4vY~#S-\u001d\u000b\u0005\u0003\u0013\fy\rE\u0002\r\u0003\u0017L1!!4\u000e\u0005\u0011)f.\u001b;\t\u0013\u0005E\u00171YA\u0001\u0002\u0004a\u0013a\u0001=%c!9\u0011Q\u001b\u0001!B\u0013a\u0013\u0001\u0005;bg.\u001c8+^2dKN\u001ch-\u001e7!\u0011!\tI\u000e\u0001b\u0001\n\u0003Y\u0013AB<fS\u001eDG\u000fC\u0004\u0002^\u0002\u0001\u000b\u0011\u0002\u0017\u0002\u000f],\u0017n\u001a5uA!A\u0011\u0011\u001d\u0001C\u0002\u0013\u00051&\u0001\u0005nS:\u001c\u0006.\u0019:f\u0011\u001d\t)\u000f\u0001Q\u0001\n1\n\u0011\"\\5o'\"\f'/\u001a\u0011\t\u0011\u0005%\b\u00011A\u0005\u0002-\n\u0001\u0002\u001d:j_JLG/\u001f\u0005\n\u0003[\u0004\u0001\u0019!C\u0001\u0003_\fA\u0002\u001d:j_JLG/_0%KF$B!!3\u0002r\"I\u0011\u0011[Av\u0003\u0003\u0005\r\u0001\f\u0005\b\u0003k\u0004\u0001\u0015)\u0003-\u0003%\u0001(/[8sSRL\b\u0005\u0003\u0005\u0002z\u0002\u0001\r\u0011\"\u0001,\u0003\u001d\u0019H/Y4f\u0013\u0012D\u0011\"!@\u0001\u0001\u0004%\t!a@\u0002\u0017M$\u0018mZ3JI~#S-\u001d\u000b\u0005\u0003\u0013\u0014\t\u0001C\u0005\u0002R\u0006m\u0018\u0011!a\u0001Y!9!Q\u0001\u0001!B\u0013a\u0013\u0001C:uC\u001e,\u0017\n\u001a\u0011\t\u0013\t%\u0001A1A\u0005\u0002\t-\u0011\u0001\u00028b[\u0016,\"A!\u0004\u0011\t\t=!\u0011D\u0007\u0003\u0005#QAAa\u0005\u0003\u0016\u0005!A.\u00198h\u0015\t\u00119\"\u0001\u0003kCZ\f\u0017bA2\u0003\u0012!A!Q\u0004\u0001!\u0002\u0013\u0011i!A\u0003oC6,\u0007\u0005C\u0005\u0003\"\u0001\u0001\r\u0011\"\u0001\u0003$\u00051\u0001/\u0019:f]R,\"A!\n\u0011\u0007I\u00119#C\u0002\u0003*\t\u0011A\u0001U8pY\"I!Q\u0006\u0001A\u0002\u0013\u0005!qF\u0001\u000ba\u0006\u0014XM\u001c;`I\u0015\fH\u0003BAe\u0005cA!\"!5\u0003,\u0005\u0005\t\u0019\u0001B\u0013\u0011!\u0011)\u0004\u0001Q!\n\t\u0015\u0012a\u00029be\u0016tG\u000f\t\u0005\t\u0005s\u0001\u0001\u0019!C\u0005y\u0006yAo\u001c;bYJ+7/\u001e7u'&TX\rC\u0005\u0003>\u0001\u0001\r\u0011\"\u0003\u0003@\u0005\u0019Bo\u001c;bYJ+7/\u001e7u'&TXm\u0018\u0013fcR!\u0011\u0011\u001aB!\u0011%\t\tNa\u000f\u0002\u0002\u0003\u0007Q\rC\u0004\u0003F\u0001\u0001\u000b\u0015B3\u0002!Q|G/\u00197SKN,H\u000e^*ju\u0016\u0004\u0003\u0002\u0003B%\u0001\u0001\u0007I\u0011B\u0016\u0002\u001f\r\fGnY;mCR,G\rV1tWND\u0011B!\u0014\u0001\u0001\u0004%IAa\u0014\u0002'\r\fGnY;mCR,G\rV1tWN|F%Z9\u0015\t\u0005%'\u0011\u000b\u0005\n\u0003#\u0014Y%!AA\u00021BqA!\u0016\u0001A\u0003&A&\u0001\tdC2\u001cW\u000f\\1uK\u0012$\u0016m]6tA!Q!\u0011\f\u0001C\u0002\u0013\u0005!Aa\u0017\u00023Q\f7o[*fi\nc\u0017mY6mSN$\b*\u001a7qKJ|\u0005\u000f^\u000b\u0003\u0005;\u0002B\u0001\u0004\u001b\u0003`A\u0019!C!\u0019\n\u0007\t\r$A\u0001\tUCN\\7+\u001a;CY\u0006\u001c7\u000e\\5ti\"A!q\r\u0001!\u0002\u0013\u0011i&\u0001\u000euCN\\7+\u001a;CY\u0006\u001c7\u000e\\5ti\"+G\u000e]3s\u001fB$\b\u0005\u0003\u0006\u0003l\u0001\u0011\r\u0011\"\u0001\u0003\u0005[\nqB];o]&tw\rV1tWN\u001cV\r^\u000b\u0003\u0005_\u0002Ba\u0016B9K&\u0019!1\u000f-\u0003\u000f!\u000b7\u000f[*fi\"A!q\u000f\u0001!\u0002\u0013\u0011y'\u0001\tsk:t\u0017N\\4UCN\\7oU3uA!1!1\u0010\u0001\u0005B-\nAB];o]&tw\rV1tWNDqAa \u0001\t\u0003\u0011\t)\u0001\u000bt_6,\u0017\t\u001e;f[B$8+^2dK\u0016$W\r\u001a\u000b\u0005\u0003\u000b\u0011\u0019\tC\u0004\u0003\u0006\nu\u0004\u0019A3\u0002\u0007QLG\r\u0003\u0006\u0003\n\u0002\u0001\r\u0011\"\u0001\u0003\u0003\u0007\t\u0001\"[:[_6\u0014\u0017.\u001a\u0005\u000b\u0005\u001b\u0003\u0001\u0019!C\u0001\u0005\t=\u0015\u0001D5t5>l'-[3`I\u0015\fH\u0003BAe\u0005#C!\"!5\u0003\f\u0006\u0005\t\u0019AA\u0003\u0011!\u0011)\n\u0001Q!\n\u0005\u0015\u0011!C5t5>l'-[3!\u0011%\u0011I\n\u0001b\u0001\n\u0013\u0011Y*A\fqK:$\u0017N\\4UCN\\7OR8s\u000bb,7-\u001e;peV\u0011!Q\u0014\t\u0006/rs&q\u0014\t\u0005/\n\u0005F&C\u0002\u0003$b\u00131\"\u0011:sCf\u0014UO\u001a4fe\"A!q\u0015\u0001!\u0002\u0013\u0011i*\u0001\rqK:$\u0017N\\4UCN\\7OR8s\u000bb,7-\u001e;pe\u0002B\u0011Ba+\u0001\u0005\u0004%IAa'\u0002'A,g\u000eZ5oOR\u000b7o[:G_JDun\u001d;\t\u0011\t=\u0006\u0001)A\u0005\u0005;\u000bA\u0003]3oI&tw\rV1tWN4uN\u001d%pgR\u0004\u0003\"\u0003BZ\u0001\t\u0007I\u0011\u0002BN\u0003M\u0001XM\u001c3j]\u001e$\u0016m]6t\r>\u0014(+Y2l\u0011!\u00119\f\u0001Q\u0001\n\tu\u0015\u0001\u00069f]\u0012Lgn\u001a+bg.\u001chi\u001c:SC\u000e\\\u0007\u0005\u0003\u0006\u0003<\u0002\u0001\r\u0011\"\u0001\u0003\u0005{\u000bq\u0003]3oI&tw\rV1tWN<\u0016\u000e\u001e5O_B\u0013XMZ:\u0016\u0005\t}\u0005B\u0003Ba\u0001\u0001\u0007I\u0011\u0001\u0002\u0003D\u0006Y\u0002/\u001a8eS:<G+Y:lg^KG\u000f\u001b(p!J,gm]0%KF$B!!3\u0003F\"Q\u0011\u0011\u001bB`\u0003\u0003\u0005\rAa(\t\u0011\t%\u0007\u0001)Q\u0005\u0005?\u000b\u0001\u0004]3oI&tw\rV1tWN<\u0016\u000e\u001e5O_B\u0013XMZ:!\u0011%\u0011i\r\u0001b\u0001\n\u0013\u0011i,A\bbY2\u0004VM\u001c3j]\u001e$\u0016m]6t\u0011!\u0011\t\u000e\u0001Q\u0001\n\t}\u0015\u0001E1mYB+g\u000eZ5oOR\u000b7o[:!\u0011)\u0011)\u000e\u0001b\u0001\n\u0003\u0011!q[\u0001\u0012gB,7-\u001e7bi\u0006\u0014G.\u001a+bg.\u001cXC\u0001Bm!\u00119&\u0011\u000f\u0017\t\u0011\tu\u0007\u0001)A\u0005\u00053\f!c\u001d9fGVd\u0017\r^1cY\u0016$\u0016m]6tA!I!\u0011\u001d\u0001C\u0002\u0013%!1]\u0001\ni\u0006\u001c8.\u00138g_N,\"A!:\u0011\u000b]cV-!.\t\u0011\t%\b\u0001)A\u0005\u0005K\f!\u0002^1tW&sgm\\:!\u0011%\u0011i\u000f\u0001b\u0001\n\u0003\u0011y/A\ftk\u000e\u001cWm]:gk2$\u0016m]6EkJ\fG/[8ogV\u0011!\u0011\u001f\t\u0005\u0005g\u001490\u0004\u0002\u0003v*\u00111,P\u0005\u0005\u0005s\u0014)P\u0001\u0006NK\u0012L\u0017M\u001c%fCBD\u0001B!@\u0001A\u0003%!\u0011_\u0001\u0019gV\u001c7-Z:tMVdG+Y:l\tV\u0014\u0018\r^5p]N\u0004\u0003\u0002CB\u0001\u0001\t\u0007I\u0011\u0001?\u00021\u0015C6)\u0012)U\u0013>su\f\u0015*J\u001dR{\u0016J\u0014+F%Z\u000bE\nC\u0004\u0004\u0006\u0001\u0001\u000b\u0011B3\u00023\u0015C6)\u0012)U\u0013>su\f\u0015*J\u001dR{\u0016J\u0014+F%Z\u000bE\n\t\u0005\n\u0007\u0013\u0001!\u0019!C\u0005\u0007\u0017\t\u0001C]3dK:$X\t_2faRLwN\\:\u0016\u0005\r5\u0001#B,]=\u000e=\u0001#\u0002\u0007\u0004\u00121*\u0017bAB\n\u001b\t1A+\u001e9mKJB\u0001ba\u0006\u0001A\u0003%1QB\u0001\u0012e\u0016\u001cWM\u001c;Fq\u000e,\u0007\u000f^5p]N\u0004\u0003\u0002CB\u000e\u0001\t\u0007I\u0011\u0001?\u0002\u000b\u0015\u0004xn\u00195\t\u000f\r}\u0001\u0001)A\u0005K\u00061Q\r]8dQ\u0002B!ba\t\u0001\u0001\u0004%\tAAB\u0013\u0003Ai\u0017\u0010T8dC2LG/\u001f'fm\u0016d7/\u0006\u0002\u0004(A)A\"!\u0010\u0004*A!11FB\u0019\u001d\r\u00112QF\u0005\u0004\u0007_\u0011\u0011\u0001\u0004+bg.dunY1mSRL\u0018\u0002BB\u001a\u0007k\u0011A\u0002V1tW2{7-\u00197jifT1aa\f\u0003\u0011)\u0019I\u0004\u0001a\u0001\n\u0003\u001111H\u0001\u0015[fdunY1mSRLH*\u001a<fYN|F%Z9\u0015\t\u0005%7Q\b\u0005\u000b\u0003#\u001c9$!AA\u0002\r\u001d\u0002\u0002CB!\u0001\u0001\u0006Kaa\n\u0002#5LHj\\2bY&$\u0018\u0010T3wK2\u001c\b\u0005\u0003\u0006\u0004F\u0001\u0001\r\u0011\"\u0001\u0003\u0007\u000f\nQ\u0002\\8dC2LG/_,bSR\u001cXCAB%!\u0011a\u0011QH3\t\u0015\r5\u0003\u00011A\u0005\u0002\t\u0019y%A\tm_\u000e\fG.\u001b;z/\u0006LGo]0%KF$B!!3\u0004R!Q\u0011\u0011[B&\u0003\u0003\u0005\ra!\u0013\t\u0011\rU\u0003\u0001)Q\u0005\u0007\u0013\na\u0002\\8dC2LG/_,bSR\u001c\b\u0005\u0003\u0005\u0004Z\u0001\u0001\r\u0011\"\u0003,\u0003Q\u0019WO\u001d:f]RdunY1mSRL\u0018J\u001c3fq\"I1Q\f\u0001A\u0002\u0013%1qL\u0001\u0019GV\u0014(/\u001a8u\u0019>\u001c\u0017\r\\5us&sG-\u001a=`I\u0015\fH\u0003BAe\u0007CB\u0011\"!5\u0004\\\u0005\u0005\t\u0019\u0001\u0017\t\u000f\r\u0015\u0004\u0001)Q\u0005Y\u0005)2-\u001e:sK:$Hj\\2bY&$\u00180\u00138eKb\u0004\u0003\u0002CB5\u0001\u0001\u0007I\u0011\u0002?\u0002\u001d1\f7\u000f\u001e'bk:\u001c\u0007\u000eV5nK\"I1Q\u000e\u0001A\u0002\u0013%1qN\u0001\u0013Y\u0006\u001cH\u000fT1v]\u000eDG+[7f?\u0012*\u0017\u000f\u0006\u0003\u0002J\u000eE\u0004\"CAi\u0007W\n\t\u00111\u0001f\u0011\u001d\u0019)\b\u0001Q!\n\u0015\fq\u0002\\1ti2\u000bWO\\2i)&lW\r\t\u0005\b\u0007s\u0002A\u0011IB>\u0003A\u00198\r[3ek2\f'\r\\3Rk\u0016,X-\u0006\u0002\u0004~A)1qPBD#5\u00111\u0011\u0011\u0006\u0005\u0007\u0007\u001b))\u0001\u0006d_:\u001cWO\u001d:f]RT1A\u0010B\u000b\u0013\u0011\u0019Ii!!\u0003+\r{gnY;se\u0016tG\u000fT5oW\u0016$\u0017+^3vK\"91Q\u0012\u0001\u0005B\r=\u0015AD:dQ\u0016$W\u000f\\5oO6{G-Z\u000b\u0003\u0007#\u0003Baa%\u0004*:!1QSBS\u001d\u0011\u00199ja)\u000f\t\re5\u0011\u0015\b\u0005\u00077\u001byJ\u0004\u0003\u0002$\u000eu\u0015\"A\u0005\n\u0005\u001dA\u0011BA\u0003\u0007\u0013\t\u0019A!C\u0002\u0004(\n\tabU2iK\u0012,H.\u001b8h\u001b>$W-\u0003\u0003\u0004,\u000e5&AD*dQ\u0016$W\u000f\\5oO6{G-\u001a\u0006\u0004\u0007O\u0013\u0001BCBY\u0001\u0001\u0007I\u0011\u0001\u0002\u0002\u0004\u00051R-\\5ui\u0016$G+Y:l'&TXmV1s]&tw\r\u0003\u0006\u00046\u0002\u0001\r\u0011\"\u0001\u0003\u0007o\u000b!$Z7jiR,G\rV1tWNK'0Z,be:LgnZ0%KF$B!!3\u0004:\"Q\u0011\u0011[BZ\u0003\u0003\u0005\r!!\u0002\t\u0011\ru\u0006\u0001)Q\u0005\u0003\u000b\tq#Z7jiR,G\rV1tWNK'0Z,be:Lgn\u001a\u0011\t\u0011\r\u0005\u0007\u0001\"\u0001\u0005\u0007\u0007\fa\"\u00193e!\u0016tG-\u001b8h)\u0006\u001c8\u000e\u0006\u0003\u0002J\u000e\u0015\u0007bBBd\u0007\u0003\r\u0001L\u0001\u0006S:$W\r\u001f\u0005\b\u0007\u0017\u0004A\u0011BBg\u0003i9W\r\u001e)f]\u0012Lgn\u001a+bg.\u001chi\u001c:Fq\u0016\u001cW\u000f^8s)\u0011\u0011yja4\t\u000f\rE7\u0011\u001aa\u0001=\u0006QQ\r_3dkR|'/\u00133\t\u000f\rU\u0007\u0001\"\u0003\u0004X\u00061r-\u001a;QK:$\u0017N\\4UCN\\7OR8s\u0011>\u001cH\u000f\u0006\u0003\u0003 \u000ee\u0007bBBn\u0007'\u0004\rAX\u0001\u0005Q>\u001cH\u000fC\u0004\u0004`\u0002!Ia!9\u0002-\u001d,G\u000fU3oI&tw\rV1tWN4uN\u001d*bG.$BAa(\u0004d\"91Q]Bo\u0001\u0004q\u0016\u0001\u0002:bG.Dqa!;\u0001\t\u0013\u0019Y/A\neKF,X-^3UCN\\gI]8n\u0019&\u001cH\u000f\u0006\u0005\u0004n\u000e=81_B{!\raA\u0007\f\u0005\b\u0007c\u001c9\u000f1\u0001_\u0003\u0019)\u00070Z2JI\"911\\Bt\u0001\u0004q\u0006\u0002CB|\u0007O\u0004\rAa(\u0002\t1L7\u000f\u001e\u0005\b\u0007w\u0004A\u0011BB\u0003AA\u0017m]!ui\u0016l\u0007\u000f^(o\u0011>\u001cH\u000f\u0006\u0004\u0002\u0006\r}H1\u0001\u0005\b\t\u0003\u0019I\u00101\u0001-\u0003%!\u0018m]6J]\u0012,\u0007\u0010C\u0004\u0004\\\u000ee\b\u0019\u00010\t\u000f\u0011\u001d\u0001\u0001\"\u0003\u0005\n\u0005i\u0012n\u001d+bg.\u0014E.Y2lY&\u001cH/\u001a3P]\u0016CXmY(s\u001d>$W\r\u0006\u0005\u0002\u0006\u0011-AQ\u0002C\b\u0011\u001d\u00199\r\"\u0002A\u00021Bqa!=\u0005\u0006\u0001\u0007a\fC\u0004\u0004\\\u0012\u0015\u0001\u0019\u00010\t\u000f\u0011M\u0001\u0001\"\u0005\u0005\u0016\u00051B-Z9vKV,7\u000b]3dk2\fG/\u001b<f)\u0006\u001c8\u000e\u0006\u0005\u0005\u0018\u0011\u0015Bq\u0005C\u0015!\u0011aA\u0007\"\u0007\u0011\r1\u0019\t\u0002\fC\u000e!\u0011\u0019Y\u0003\"\b\n\t\u0011}A\u0011\u0005\u0002\u0006-\u0006dW/Z\u0005\u0004\tGi!aC#ok6,'/\u0019;j_:Dqa!=\u0005\u0012\u0001\u0007a\fC\u0004\u0004\\\u0012E\u0001\u0019\u00010\t\u0011\u0011-B\u0011\u0003a\u0001\t7\t\u0001\u0002\\8dC2LG/\u001f\u0005\b\t_\u0001A\u0011\u0002C\u0019\u0003-!W-];fk\u0016$\u0016m]6\u0015\u0011\u0011MB1\bC\u001f\t\u0001B\u0001\u0004\u001b\u00056AAA\u0002b\u000e-\t7\t)!C\u0002\u0005:5\u0011a\u0001V;qY\u0016\u001c\u0004bBBy\t[\u0001\rA\u0018\u0005\b\u00077$i\u00031\u0001_\u0011!!\t\u0005\"\fA\u0002\u0011m\u0011aC7bq2{7-\u00197jifDq\u0001\"\u0012\u0001\t\u0003!9%A\u0007sKN|WO]2f\u001f\u001a4WM\u001d\u000b\t\t\u0013\"\t\u0006b\u0015\u0005VA!A\u0002\u000eC&!\r\u0011BQJ\u0005\u0004\t\u001f\u0012!a\u0004+bg.$Um]2sSB$\u0018n\u001c8\t\u000f\rEH1\ta\u0001=\"911\u001cC\"\u0001\u0004q\u0006\u0002\u0003C!\t\u0007\u0002\ra!\u000b)\r\u0011\rC\u0011\fC3!\u0015aA1\fC0\u0013\r!i&\u0004\u0002\u0007i\"\u0014xn^:\u0011\u00079#\t'C\u0002\u0005d\u0011\u0011A\u0004V1tW:{GoU3sS\u0006d\u0017N_1cY\u0016,\u0005pY3qi&|g.\r\u0004\u001f=\u0012\u001dDQR\u0019\nG\u0011%D\u0011\u000fCB\tg*B\u0001b\u001b\u0005nU\ta\fB\u0004\u0005pu\u0011\r\u0001\"\u001f\u0003\u0003QKA\u0001b\u001d\u0005v\u0005YB\u0005\\3tg&t\u0017\u000e\u001e\u0013he\u0016\fG/\u001a:%I\u00164\u0017-\u001e7uIER1\u0001b\u001e\u000e\u0003\u0019!\bN]8xgF!\u0011q\u000bC>!\u0011!i\bb \u000f\u00071\tY+\u0003\u0003\u0005\u0002\u0006M&!\u0003+ie><\u0018M\u00197fc%\u0019CQ\u0011CD\t\u0013#9HD\u0002\r\t\u000fK1\u0001b\u001e\u000ec\u0015\u0011C\"\u0004CF\u0005\u0015\u00198-\u00197bc\r1Cq\f\u0005\b\t#\u0003A\u0011\u0002CJ\u0003Ii\u0017-\u001f2f\r&t\u0017n\u001d5UCN\\7+\u001a;\u0015\u0005\u0005%\u0007b\u0002CL\u0001\u0011%A\u0011T\u0001\u0018O\u0016$\u0018\t\u001c7po\u0016$Gj\\2bY&$\u0018\u0010T3wK2$Ba!\u000b\u0005\u001c\"9AQ\u0014CK\u0001\u0004)\u0017aB2veRKW.\u001a\u0005\b\tC\u0003A\u0011\u0001CR\u0003A9W\r\u001e'pG\u0006d\u0017\u000e^=J]\u0012,\u0007\u0010F\u0002-\tKC\u0001\u0002b\u000b\u0005 \u0002\u00071\u0011\u0006\u0005\t\tS\u0003A\u0011\u0001\u0002\u0005,\u0006a\u0012MY8si&37i\\7qY\u0016$X\r\\=CY\u0006\u001c7\u000e\\5ti\u0016$G\u0003BAe\t[C\u0001\u0002b,\u0005(\u0002\u0007A\u0011W\u0001\u0010Q>\u001cH\u000fV8Fq\u0016\u001cW\u000f^8sgB)q\u000b\u00180\u00054B!qK!\u001d_\u0011\u001d!9\f\u0001C\u0001\ts\u000bq\u0003[1oI2,G+Y:l\u000f\u0016$H/\u001b8h%\u0016\u001cX\u000f\u001c;\u0015\t\u0005%G1\u0018\u0005\b\u0005\u000b#)\f1\u0001f\u0011\u001d!y\f\u0001C\u0001\t\u0003\f1cY1o\r\u0016$8\r['pe\u0016\u0014Vm];miN$B!!\u0002\u0005D\"9AQ\u0019C_\u0001\u0004)\u0017\u0001B:ju\u0016Dq\u0001\"3\u0001\t\u0003!Y-\u0001\u000biC:$G.Z*vG\u000e,7o\u001d4vYR\u000b7o\u001b\u000b\u0007\u0003\u0013$i\rb4\t\u000f\t\u0015Eq\u0019a\u0001K\"AA\u0011\u001bCd\u0001\u0004!\u0019.\u0001\u0004sKN,H\u000e\u001e\u0019\u0005\t+$i\u000eE\u0003\u0013\t/$Y.C\u0002\u0005Z\n\u0011\u0001\u0003R5sK\u000e$H+Y:l%\u0016\u001cX\u000f\u001c;\u0011\t\u0005-CQ\u001c\u0003\r\u0003\u001f\"y-!A\u0001\u0002\u000b\u0005\u0011Q\u000b\u0005\b\tC\u0004A\u0011\u0001Cr\u0003AA\u0017M\u001c3mK\u001a\u000b\u0017\u000e\\3e)\u0006\u001c8\u000e\u0006\u0005\u0002J\u0012\u0015Hq\u001dC}\u0011\u001d\u0011)\tb8A\u0002\u0015D\u0001\u0002\";\u0005`\u0002\u0007A1^\u0001\u0006gR\fG/\u001a\t\u0005\t[$\u0019P\u0004\u0003\u0004\u0018\u0012=\u0018b\u0001Cy\t\u0005IA+Y:l'R\fG/Z\u0005\u0005\tk$9PA\u0005UCN\\7\u000b^1uK*\u0019A\u0011\u001f\u0003\t\u0011\u0011mHq\u001ca\u0001\t{\faA]3bg>t\u0007c\u0001(\u0005\u0000&\u0019Q\u0011\u0001\u0003\u0003!Q\u000b7o\u001b$bS2,GMU3bg>t\u0007bBC\u0003\u0001\u0011\u0005QqA\u0001\u0006C\n|'\u000f\u001e\u000b\u0007\u0003\u0013,I!\"\u0004\t\u000f\u0015-Q1\u0001a\u0001=\u00069Q.Z:tC\u001e,\u0007BCC\b\u000b\u0007\u0001\n\u00111\u0001\u0006\u0012\u0005IQ\r_2faRLwN\u001c\t\u0005\u0019Q*\u0019\u0002\u0005\u0003\u0002 \u0012}\u0004bBC\f\u0001\u0011\u0005Q\u0011D\u0001\u000fC\u0012$'+\u001e8oS:<G+Y:l)\u0011\tI-b\u0007\t\u000f\t\u0015UQ\u0003a\u0001K\"9Qq\u0004\u0001\u0005\u0002\u0015\u0005\u0012!\u0005:f[>4XMU;o]&tw\rV1tWR!\u0011\u0011ZC\u0012\u0011\u001d\u0011))\"\bA\u0002\u0015Dq!b\n\u0001\t\u0003*I#\u0001\u000bhKR\u001c6\r[3ek2\f'\r\\3Cs:\u000bW.\u001a\u000b\u0004#\u0015-\u0002b\u0002B\u0005\u000bK\u0001\rA\u0018\u0005\b\u000b_\u0001A\u0011IC\u0019\u00039\tG\rZ*dQ\u0016$W\u000f\\1cY\u0016$B!!3\u00064!9QQGC\u0017\u0001\u0004\t\u0012aC:dQ\u0016$W\u000f\\1cY\u0016Dq!\"\u000f\u0001\t\u0003*Y$A\tsK6|g/Z*dQ\u0016$W\u000f\\1cY\u0016$B!!3\u0006>!9QQGC\u001c\u0001\u0004\t\u0002bBC!\u0001\u0011\u0005S1I\u0001\u0016O\u0016$8k\u001c:uK\u0012$\u0016m]6TKR\fV/Z;f)\t))\u0005\u0005\u0003X\u0005C#\u0005bBC%\u0001\u0011\u0005S1J\u0001\rKb,7-\u001e;pe2{7\u000f\u001e\u000b\t\u0003\u0013,i%b\u0014\u0006R!91\u0011_C$\u0001\u0004q\u0006bBBn\u000b\u000f\u0002\rA\u0018\u0005\t\tw,9\u00051\u0001\u0006TA\u0019!#\"\u0016\n\u0007\u0015]#A\u0001\nFq\u0016\u001cW\u000f^8s\u0019>\u001c8OU3bg>t\u0007bBC.\u0001\u0011\u0005SQL\u0001\u0017G\",7m[*qK\u000e,H.\u0019;bE2,G+Y:lgR!\u0011QAC0\u0011\u001d)\t'\"\u0017A\u00021\nA#\\5o)&lW\rV8Ta\u0016\u001cW\u000f\\1uS>t\u0007bBC3\u0001\u0011%QqM\u0001\u0010O\u0016$Hj\\2bY&$\u0018pV1jiR\u0019Q-\"\u001b\t\u0011\u0015-T1\ra\u0001\u0007S\tQ\u0001\\3wK2Dq!b\u001c\u0001\t\u0013)\t(\u0001\u000ed_6\u0004X\u000f^3WC2LG\rT8dC2LG/\u001f'fm\u0016d7\u000f\u0006\u0002\u0004(!9QQ\u000f\u0001\u0005\u0002\u0011M\u0015!\u0005:fG>l\u0007/\u001e;f\u0019>\u001c\u0017\r\\5us\"9Q\u0011\u0010\u0001\u0005\u0002\u0011M\u0015!D3yK\u000e,Ho\u001c:BI\u0012,G\rC\u0005\u0006~\u0001\t\n\u0011\"\u0001\u0006\u0000\u0005y\u0011MY8si\u0012\"WMZ1vYR$#'\u0006\u0002\u0006\u0002*\"Q\u0011CCBW\t))\t\u0005\u0003\u0006\b\u0016EUBACE\u0015\u0011)Y)\"$\u0002\u0013Ut7\r[3dW\u0016$'bACH\u001b\u0005Q\u0011M\u001c8pi\u0006$\u0018n\u001c8\n\t\u0015MU\u0011\u0012\u0002\u0012k:\u001c\u0007.Z2lK\u00124\u0016M]5b]\u000e,w\u0001CCL\u0005!\u0005A!\"'\u0002\u001dQ\u000b7o[*fi6\u000bg.Y4feB\u0019!#b'\u0007\u000f\u0005\u0011\u0001\u0012\u0001\u0003\u0006\u001eN\u0019Q1T\u0006\t\u000f\t+Y\n\"\u0001\u0006\"R\u0011Q\u0011\u0014\u0005\n\u000bK+YJ1A\u0005\u0002-\nA\u0003V!T\u0017~\u001b\u0016JW#`)>{v+\u0011*O?.\u0013\u0005\u0002CCU\u000b7\u0003\u000b\u0011\u0002\u0017\u0002+Q\u000b5kS0T\u0013j+u\fV(`/\u0006\u0013fjX&CA!QQQVCN#\u0003%\t!b,\u00027\u0011bWm]:j]&$He\u001a:fCR,'\u000f\n3fM\u0006,H\u000e\u001e\u00135+\t)\tLK\u00024\u000b\u0007C!\"\".\u0006\u001cF\u0005I\u0011AC\\\u0003m!C.Z:tS:LG\u000fJ4sK\u0006$XM\u001d\u0013eK\u001a\fW\u000f\u001c;%kU\u0011Q\u0011\u0018\u0016\u0004w\u0015\r\u0005")
public class TaskSetManager
implements Schedulable,
Logging {
    public final TaskSchedulerImpl org$apache$spark$scheduler$TaskSetManager$$sched;
    private final TaskSet taskSet;
    private final int maxTaskFailures;
    public final Option<BlacklistTracker> org$apache$spark$scheduler$TaskSetManager$$blacklistTracker;
    public final Clock org$apache$spark$scheduler$TaskSetManager$$clock;
    private final SparkConf org$apache$spark$scheduler$TaskSetManager$$conf;
    private final HashMap<String, Object> org$apache$spark$scheduler$TaskSetManager$$addedJars;
    private final HashMap<String, Object> org$apache$spark$scheduler$TaskSetManager$$addedFiles;
    private final double SPECULATION_QUANTILE;
    private final double SPECULATION_MULTIPLIER;
    private final long maxResultSize;
    private final boolean speculationEnabled;
    private final SparkEnv env;
    private final SerializerInstance ser;
    private final Task<?>[] tasks;
    private final int numTasks;
    private final int[] copiesRunning;
    private final boolean[] successful;
    private final int[] numFailures;
    private final boolean[] org$apache$spark$scheduler$TaskSetManager$$killedByOtherAttempt;
    private final List<TaskInfo>[] taskAttempts;
    private int tasksSuccessful;
    private final int weight;
    private final int minShare;
    private int priority;
    private int stageId;
    private final String name;
    private Pool parent;
    private long totalResultSize;
    private int calculatedTasks;
    private final Option<TaskSetBlacklist> taskSetBlacklistHelperOpt;
    private final HashSet<Object> runningTasksSet;
    private boolean isZombie;
    private final HashMap<String, ArrayBuffer<Object>> org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor;
    private final HashMap<String, ArrayBuffer<Object>> org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost;
    private final HashMap<String, ArrayBuffer<Object>> org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack;
    private ArrayBuffer<Object> pendingTasksWithNoPrefs;
    private final ArrayBuffer<Object> org$apache$spark$scheduler$TaskSetManager$$allPendingTasks;
    private final HashSet<Object> speculatableTasks;
    private final HashMap<Object, TaskInfo> org$apache$spark$scheduler$TaskSetManager$$taskInfos;
    private final MedianHeap successfulTaskDurations;
    private final long EXCEPTION_PRINT_INTERVAL;
    private final HashMap<String, Tuple2<Object, Object>> recentExceptions;
    private final long epoch;
    private Enumeration.Value[] myLocalityLevels;
    private long[] localityWaits;
    private int org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex;
    private long org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime;
    private boolean emittedTaskSizeWarning;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static Clock $lessinit$greater$default$5() {
        return TaskSetManager$.MODULE$.$lessinit$greater$default$5();
    }

    public static Option<BlacklistTracker> $lessinit$greater$default$4() {
        return TaskSetManager$.MODULE$.$lessinit$greater$default$4();
    }

    public static int TASK_SIZE_TO_WARN_KB() {
        return TaskSetManager$.MODULE$.TASK_SIZE_TO_WARN_KB();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @TraitSetter
    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public TaskSet taskSet() {
        return this.taskSet;
    }

    public int maxTaskFailures() {
        return this.maxTaskFailures;
    }

    public SparkConf org$apache$spark$scheduler$TaskSetManager$$conf() {
        return this.org$apache$spark$scheduler$TaskSetManager$$conf;
    }

    public HashMap<String, Object> org$apache$spark$scheduler$TaskSetManager$$addedJars() {
        return this.org$apache$spark$scheduler$TaskSetManager$$addedJars;
    }

    public HashMap<String, Object> org$apache$spark$scheduler$TaskSetManager$$addedFiles() {
        return this.org$apache$spark$scheduler$TaskSetManager$$addedFiles;
    }

    public double SPECULATION_QUANTILE() {
        return this.SPECULATION_QUANTILE;
    }

    public double SPECULATION_MULTIPLIER() {
        return this.SPECULATION_MULTIPLIER;
    }

    public long maxResultSize() {
        return this.maxResultSize;
    }

    public boolean speculationEnabled() {
        return this.speculationEnabled;
    }

    public SparkEnv env() {
        return this.env;
    }

    public SerializerInstance ser() {
        return this.ser;
    }

    public Task<?>[] tasks() {
        return this.tasks;
    }

    public int numTasks() {
        return this.numTasks;
    }

    public int[] copiesRunning() {
        return this.copiesRunning;
    }

    public boolean[] successful() {
        return this.successful;
    }

    private int[] numFailures() {
        return this.numFailures;
    }

    public boolean[] org$apache$spark$scheduler$TaskSetManager$$killedByOtherAttempt() {
        return this.org$apache$spark$scheduler$TaskSetManager$$killedByOtherAttempt;
    }

    public List<TaskInfo>[] taskAttempts() {
        return this.taskAttempts;
    }

    public int tasksSuccessful() {
        return this.tasksSuccessful;
    }

    public void tasksSuccessful_$eq(int x$1) {
        this.tasksSuccessful = x$1;
    }

    @Override
    public int weight() {
        return this.weight;
    }

    @Override
    public int minShare() {
        return this.minShare;
    }

    @Override
    public int priority() {
        return this.priority;
    }

    public void priority_$eq(int x$1) {
        this.priority = x$1;
    }

    @Override
    public int stageId() {
        return this.stageId;
    }

    public void stageId_$eq(int x$1) {
        this.stageId = x$1;
    }

    @Override
    public String name() {
        return this.name;
    }

    @Override
    public Pool parent() {
        return this.parent;
    }

    @Override
    public void parent_$eq(Pool x$1) {
        this.parent = x$1;
    }

    private long totalResultSize() {
        return this.totalResultSize;
    }

    private void totalResultSize_$eq(long x$1) {
        this.totalResultSize = x$1;
    }

    private int calculatedTasks() {
        return this.calculatedTasks;
    }

    private void calculatedTasks_$eq(int x$1) {
        this.calculatedTasks = x$1;
    }

    public Option<TaskSetBlacklist> taskSetBlacklistHelperOpt() {
        return this.taskSetBlacklistHelperOpt;
    }

    public HashSet<Object> runningTasksSet() {
        return this.runningTasksSet;
    }

    @Override
    public int runningTasks() {
        return this.runningTasksSet().size();
    }

    public boolean someAttemptSucceeded(long tid) {
        return this.successful()[((TaskInfo)this.org$apache$spark$scheduler$TaskSetManager$$taskInfos().apply((Object)BoxesRunTime.boxToLong((long)tid))).index()];
    }

    public boolean isZombie() {
        return this.isZombie;
    }

    public void isZombie_$eq(boolean x$1) {
        this.isZombie = x$1;
    }

    public HashMap<String, ArrayBuffer<Object>> org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor() {
        return this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor;
    }

    public HashMap<String, ArrayBuffer<Object>> org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost() {
        return this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost;
    }

    public HashMap<String, ArrayBuffer<Object>> org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack() {
        return this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack;
    }

    public ArrayBuffer<Object> pendingTasksWithNoPrefs() {
        return this.pendingTasksWithNoPrefs;
    }

    public void pendingTasksWithNoPrefs_$eq(ArrayBuffer<Object> x$1) {
        this.pendingTasksWithNoPrefs = x$1;
    }

    public ArrayBuffer<Object> org$apache$spark$scheduler$TaskSetManager$$allPendingTasks() {
        return this.org$apache$spark$scheduler$TaskSetManager$$allPendingTasks;
    }

    public HashSet<Object> speculatableTasks() {
        return this.speculatableTasks;
    }

    public HashMap<Object, TaskInfo> org$apache$spark$scheduler$TaskSetManager$$taskInfos() {
        return this.org$apache$spark$scheduler$TaskSetManager$$taskInfos;
    }

    public MedianHeap successfulTaskDurations() {
        return this.successfulTaskDurations;
    }

    public long EXCEPTION_PRINT_INTERVAL() {
        return this.EXCEPTION_PRINT_INTERVAL;
    }

    private HashMap<String, Tuple2<Object, Object>> recentExceptions() {
        return this.recentExceptions;
    }

    public long epoch() {
        return this.epoch;
    }

    public Enumeration.Value[] myLocalityLevels() {
        return this.myLocalityLevels;
    }

    public void myLocalityLevels_$eq(Enumeration.Value[] x$1) {
        this.myLocalityLevels = x$1;
    }

    public long[] localityWaits() {
        return this.localityWaits;
    }

    public void localityWaits_$eq(long[] x$1) {
        this.localityWaits = x$1;
    }

    public int org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex() {
        return this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex;
    }

    public void org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex_$eq(int x$1) {
        this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex = x$1;
    }

    private long org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime() {
        return this.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime;
    }

    public void org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime_$eq(long x$1) {
        this.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime = x$1;
    }

    @Override
    public ConcurrentLinkedQueue<Schedulable> schedulableQueue() {
        return null;
    }

    @Override
    public Enumeration.Value schedulingMode() {
        return SchedulingMode$.MODULE$.NONE();
    }

    public boolean emittedTaskSizeWarning() {
        return this.emittedTaskSizeWarning;
    }

    public void emittedTaskSizeWarning_$eq(boolean x$1) {
        this.emittedTaskSizeWarning = x$1;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void addPendingTask(int index) {
        block2 : {
            this.tasks()[index].preferredLocations().foreach((Function1)new Serializable(this, index){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ TaskSetManager $outer;
                public final int index$1;

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final void apply(TaskLocation loc) {
                    BoxedUnit boxedUnit;
                    TaskLocation taskLocation = loc;
                    if (taskLocation instanceof org.apache.spark.scheduler.ExecutorCacheTaskLocation) {
                        org.apache.spark.scheduler.ExecutorCacheTaskLocation executorCacheTaskLocation = (org.apache.spark.scheduler.ExecutorCacheTaskLocation)taskLocation;
                        boxedUnit = ((ArrayBuffer)this.$outer.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor().getOrElseUpdate((Object)executorCacheTaskLocation.executorId(), (Function0)new Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final ArrayBuffer<Object> apply() {
                                return new ArrayBuffer();
                            }
                        })).$plus$eq((Object)BoxesRunTime.boxToInteger((int)this.index$1));
                    } else if (taskLocation instanceof org.apache.spark.scheduler.HDFSCacheTaskLocation) {
                        org.apache.spark.scheduler.HDFSCacheTaskLocation hDFSCacheTaskLocation = (org.apache.spark.scheduler.HDFSCacheTaskLocation)taskLocation;
                        Option<Set<String>> exe = this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.getExecutorsAliveOnHost(loc.host());
                        Option<Set<String>> option = exe;
                        if (option instanceof Some) {
                            Some some = (Some)option;
                            Set set2 = (Set)some.x();
                            set2.foreach((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ $anonfun$addPendingTask$1 $outer;

                                public final ArrayBuffer<Object> apply(String e) {
                                    return ((ArrayBuffer)this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor().getOrElseUpdate((Object)e, (Function0)new Serializable(this){
                                        public static final long serialVersionUID = 0L;

                                        public final ArrayBuffer<Object> apply() {
                                            return new ArrayBuffer();
                                        }
                                    })).$plus$eq((Object)BoxesRunTime.boxToInteger((int)this.$outer.index$1));
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                }
                            });
                            this.$outer.logInfo((Function0<String>)new Serializable(this, set2, hDFSCacheTaskLocation){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ $anonfun$addPendingTask$1 $outer;
                                private final Set set$1;
                                private final org.apache.spark.scheduler.HDFSCacheTaskLocation x3$1;

                                public final String apply() {
                                    return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Pending task ", " has a cached location at ", " "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.index$1), this.x3$1.host()}))).append((Object)", where there are executors ").append((Object)this.set$1.mkString(",")).toString();
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                    this.set$1 = set$1;
                                    this.x3$1 = x3$1;
                                }
                            });
                            BoxedUnit boxedUnit2 = BoxedUnit.UNIT;
                        } else {
                            if (!None$.MODULE$.equals(option)) throw new MatchError(option);
                            this.$outer.logDebug((Function0<String>)new Serializable(this, hDFSCacheTaskLocation){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ $anonfun$addPendingTask$1 $outer;
                                private final org.apache.spark.scheduler.HDFSCacheTaskLocation x3$1;

                                public final String apply() {
                                    return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Pending task ", " has a cached location at ", " "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.index$1), this.x3$1.host()}))).append((Object)", but there are no executors alive there.").toString();
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                    this.x3$1 = x3$1;
                                }
                            });
                            BoxedUnit boxedUnit3 = BoxedUnit.UNIT;
                        }
                        boxedUnit = BoxedUnit.UNIT;
                    } else {
                        boxedUnit = BoxedUnit.UNIT;
                    }
                    ((ArrayBuffer)this.$outer.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost().getOrElseUpdate((Object)loc.host(), (Function0)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final ArrayBuffer<Object> apply() {
                            return new ArrayBuffer();
                        }
                    })).$plus$eq((Object)BoxesRunTime.boxToInteger((int)this.index$1));
                    this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.getRackForHost(loc.host()).foreach((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ $anonfun$addPendingTask$1 $outer;

                        public final ArrayBuffer<Object> apply(String rack) {
                            return ((ArrayBuffer)this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack().getOrElseUpdate((Object)rack, (Function0)new Serializable(this){
                                public static final long serialVersionUID = 0L;

                                public final ArrayBuffer<Object> apply() {
                                    return new ArrayBuffer();
                                }
                            })).$plus$eq((Object)BoxesRunTime.boxToInteger((int)this.$outer.index$1));
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    });
                }

                public /* synthetic */ TaskSetManager org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer() {
                    return this.$outer;
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.index$1 = index$1;
                }
            });
            var2_2 = Nil$.MODULE$;
            if (this.tasks()[index].preferredLocations() != null) break block2;
            if (var2_2 == null) ** GOTO lbl-1000
            ** GOTO lbl-1000
        }
        if (v0.equals((Object)var2_2)) lbl-1000: // 2 sources:
        {
            v1 = this.pendingTasksWithNoPrefs().$plus$eq((Object)BoxesRunTime.boxToInteger((int)index));
        } else lbl-1000: // 2 sources:
        {
            v1 = BoxedUnit.UNIT;
        }
        this.org$apache$spark$scheduler$TaskSetManager$$allPendingTasks().$plus$eq((Object)BoxesRunTime.boxToInteger((int)index));
    }

    private ArrayBuffer<Object> getPendingTasksForExecutor(String executorId) {
        return (ArrayBuffer)this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor().getOrElse((Object)executorId, (Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final ArrayBuffer<Object> apply() {
                return (ArrayBuffer)scala.collection.mutable.ArrayBuffer$.MODULE$.apply((Seq)Nil$.MODULE$);
            }
        });
    }

    private ArrayBuffer<Object> getPendingTasksForHost(String host) {
        return (ArrayBuffer)this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost().getOrElse((Object)host, (Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final ArrayBuffer<Object> apply() {
                return (ArrayBuffer)scala.collection.mutable.ArrayBuffer$.MODULE$.apply((Seq)Nil$.MODULE$);
            }
        });
    }

    public ArrayBuffer<Object> org$apache$spark$scheduler$TaskSetManager$$getPendingTasksForRack(String rack) {
        return (ArrayBuffer)this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack().getOrElse((Object)rack, (Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final ArrayBuffer<Object> apply() {
                return (ArrayBuffer)scala.collection.mutable.ArrayBuffer$.MODULE$.apply((Seq)Nil$.MODULE$);
            }
        });
    }

    public Option<Object> org$apache$spark$scheduler$TaskSetManager$$dequeueTaskFromList(String execId, String host, ArrayBuffer<Object> list) {
        int indexOffset = list.size();
        while (indexOffset > 0) {
            int index;
            if (this.isTaskBlacklistedOnExecOrNode(index = BoxesRunTime.unboxToInt((Object)list.apply(--indexOffset)), execId, host)) continue;
            list.remove(indexOffset);
            if (this.copiesRunning()[index] != 0 || this.successful()[index]) continue;
            return new Some((Object)BoxesRunTime.boxToInteger((int)index));
        }
        return None$.MODULE$;
    }

    private boolean hasAttemptOnHost(int taskIndex, String host) {
        return this.taskAttempts()[taskIndex].exists((Function1)new Serializable(this, host){
            public static final long serialVersionUID = 0L;
            private final String host$3;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(TaskInfo x$2) {
                String string = this.host$3;
                if (x$2.host() != null) {
                    String string2;
                    if (!string2.equals(string)) return false;
                    return true;
                }
                if (string == null) return true;
                return false;
            }
            {
                this.host$3 = host$3;
            }
        });
    }

    private boolean isTaskBlacklistedOnExecOrNode(int index, String execId, String host) {
        return this.taskSetBlacklistHelperOpt().exists((Function1)new Serializable(this, index, execId, host){
            public static final long serialVersionUID = 0L;
            private final int index$2;
            private final String execId$2;
            private final String host$2;

            public final boolean apply(TaskSetBlacklist blacklist) {
                return blacklist.isNodeBlacklistedForTask(this.host$2, this.index$2) || blacklist.isExecutorBlacklistedForTask(this.execId$2, this.index$2);
            }
            {
                this.index$2 = index$2;
                this.execId$2 = execId$2;
                this.host$2 = host$2;
            }
        });
    }

    public Option<Tuple2<Object, Enumeration.Value>> dequeueSpeculativeTask(String execId, String host, Enumeration.Value locality) {
        NonLocalReturnControl nonLocalReturnControl2;
        block7 : {
            Option option;
            Object object = new Object();
            try {
                this.speculatableTasks().retain((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ TaskSetManager $outer;

                    public final boolean apply(int index) {
                        return this.apply$mcZI$sp(index);
                    }

                    public boolean apply$mcZI$sp(int index) {
                        return !this.$outer.successful()[index];
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
                if (!this.speculatableTasks().isEmpty()) {
                    this.speculatableTasks().withFilter((Function1)new Serializable(this, execId, host){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ TaskSetManager $outer;
                        private final String execId$3;
                        private final String host$4;

                        public final boolean apply(int index) {
                            return this.apply$mcZI$sp(index);
                        }

                        public boolean apply$mcZI$sp(int index) {
                            return this.$outer.org$apache$spark$scheduler$TaskSetManager$$canRunOnHost$1(index, this.execId$3, this.host$4);
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.execId$3 = execId$3;
                            this.host$4 = host$4;
                        }
                    }).foreach((Function1)new Serializable(this, execId, object){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ TaskSetManager $outer;
                        private final String execId$3;
                        private final Object nonLocalReturnKey1$1;

                        public final void apply(int index) {
                            this.apply$mcVI$sp(index);
                        }

                        public void apply$mcVI$sp(int index) {
                            Seq<TaskLocation> prefs = this.$outer.tasks()[index].preferredLocations();
                            Seq executors = (Seq)prefs.flatMap((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;

                                public final scala.collection.Iterable<String> apply(TaskLocation x$3) {
                                    scala.collection.Iterable iterable;
                                    TaskLocation taskLocation = x$3;
                                    if (taskLocation instanceof org.apache.spark.scheduler.ExecutorCacheTaskLocation) {
                                        org.apache.spark.scheduler.ExecutorCacheTaskLocation executorCacheTaskLocation = (org.apache.spark.scheduler.ExecutorCacheTaskLocation)taskLocation;
                                        iterable = scala.Option$.MODULE$.option2Iterable((Option)new Some((Object)executorCacheTaskLocation.executorId()));
                                    } else {
                                        iterable = scala.Option$.MODULE$.option2Iterable((Option)None$.MODULE$);
                                    }
                                    return iterable;
                                }
                            }, Seq$.MODULE$.canBuildFrom());
                            if (executors.contains((Object)this.execId$3)) {
                                this.$outer.speculatableTasks().$minus$eq((Object)BoxesRunTime.boxToInteger((int)index));
                                throw new NonLocalReturnControl(this.nonLocalReturnKey1$1, (Object)new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.PROCESS_LOCAL())));
                            }
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.execId$3 = execId$3;
                            this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                        }
                    });
                    if (TaskLocality$.MODULE$.isAllowed(locality, TaskLocality$.MODULE$.NODE_LOCAL())) {
                        this.speculatableTasks().withFilter((Function1)new Serializable(this, execId, host){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;
                            private final String execId$3;
                            private final String host$4;

                            public final boolean apply(int index) {
                                return this.apply$mcZI$sp(index);
                            }

                            public boolean apply$mcZI$sp(int index) {
                                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$canRunOnHost$1(index, this.execId$3, this.host$4);
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.execId$3 = execId$3;
                                this.host$4 = host$4;
                            }
                        }).foreach((Function1)new Serializable(this, host, object){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;
                            private final String host$4;
                            private final Object nonLocalReturnKey1$1;

                            public final void apply(int index) {
                                this.apply$mcVI$sp(index);
                            }

                            public void apply$mcVI$sp(int index) {
                                Seq locations = (Seq)this.$outer.tasks()[index].preferredLocations().map((Function1)new Serializable(this){
                                    public static final long serialVersionUID = 0L;

                                    public final String apply(TaskLocation x$4) {
                                        return x$4.host();
                                    }
                                }, Seq$.MODULE$.canBuildFrom());
                                if (locations.contains((Object)this.host$4)) {
                                    this.$outer.speculatableTasks().$minus$eq((Object)BoxesRunTime.boxToInteger((int)index));
                                    throw new NonLocalReturnControl(this.nonLocalReturnKey1$1, (Object)new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.NODE_LOCAL())));
                                }
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.host$4 = host$4;
                                this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                            }
                        });
                    }
                    if (TaskLocality$.MODULE$.isAllowed(locality, TaskLocality$.MODULE$.NO_PREF())) {
                        this.speculatableTasks().withFilter((Function1)new Serializable(this, execId, host){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;
                            private final String execId$3;
                            private final String host$4;

                            public final boolean apply(int index) {
                                return this.apply$mcZI$sp(index);
                            }

                            public boolean apply$mcZI$sp(int index) {
                                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$canRunOnHost$1(index, this.execId$3, this.host$4);
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.execId$3 = execId$3;
                                this.host$4 = host$4;
                            }
                        }).foreach((Function1)new Serializable(this, object){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;
                            private final Object nonLocalReturnKey1$1;

                            public final void apply(int index) {
                                this.apply$mcVI$sp(index);
                            }

                            public void apply$mcVI$sp(int index) {
                                Seq<TaskLocation> locations = this.$outer.tasks()[index].preferredLocations();
                                if (locations.size() == 0) {
                                    this.$outer.speculatableTasks().$minus$eq((Object)BoxesRunTime.boxToInteger((int)index));
                                    throw new NonLocalReturnControl(this.nonLocalReturnKey1$1, (Object)new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.PROCESS_LOCAL())));
                                }
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                            }
                        });
                    }
                    if (TaskLocality$.MODULE$.isAllowed(locality, TaskLocality$.MODULE$.RACK_LOCAL())) {
                        this.org$apache$spark$scheduler$TaskSetManager$$sched.getRackForHost(host).foreach((Function1)new Serializable(this, execId, host, object){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;
                            public final String execId$3;
                            public final String host$4;
                            public final Object nonLocalReturnKey1$1;

                            public final void apply(String rack) {
                                this.$outer.speculatableTasks().withFilter((Function1)new Serializable(this){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ $anonfun$dequeueSpeculativeTask$9 $outer;

                                    public final boolean apply(int index) {
                                        return this.apply$mcZI$sp(index);
                                    }

                                    public boolean apply$mcZI$sp(int index) {
                                        return this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().org$apache$spark$scheduler$TaskSetManager$$canRunOnHost$1(index, this.$outer.execId$3, this.$outer.host$4);
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                    }
                                }).foreach((Function1)new Serializable(this, rack){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ $anonfun$dequeueSpeculativeTask$9 $outer;
                                    private final String rack$1;

                                    public final void apply(int index) {
                                        this.apply$mcVI$sp(index);
                                    }

                                    public void apply$mcVI$sp(int index) {
                                        Seq racks = (Seq)((scala.collection.TraversableLike)this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().tasks()[index].preferredLocations().map((Function1)new Serializable(this){
                                            public static final long serialVersionUID = 0L;

                                            public final String apply(TaskLocation x$5) {
                                                return x$5.host();
                                            }
                                        }, Seq$.MODULE$.canBuildFrom())).flatMap((Function1)new Serializable(this){
                                            public static final long serialVersionUID = 0L;
                                            private final /* synthetic */ org.apache.spark.scheduler.TaskSetManager$$anonfun$dequeueSpeculativeTask$9$$anonfun$apply$2 $outer;

                                            public final scala.collection.Iterable<String> apply(String value2) {
                                                return scala.Option$.MODULE$.option2Iterable(this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$anonfun$$$outer().org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().org$apache$spark$scheduler$TaskSetManager$$sched.getRackForHost(value2));
                                            }
                                            {
                                                if ($outer == null) {
                                                    throw null;
                                                }
                                                this.$outer = $outer;
                                            }
                                        }, Seq$.MODULE$.canBuildFrom());
                                        if (racks.contains((Object)this.rack$1)) {
                                            this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().speculatableTasks().$minus$eq((Object)BoxesRunTime.boxToInteger((int)index));
                                            throw new NonLocalReturnControl(this.$outer.nonLocalReturnKey1$1, (Object)new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.RACK_LOCAL())));
                                        }
                                    }

                                    public /* synthetic */ $anonfun$dequeueSpeculativeTask$9 org$apache$spark$scheduler$TaskSetManager$$anonfun$$anonfun$$$outer() {
                                        return this.$outer;
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                        this.rack$1 = rack$1;
                                    }
                                });
                            }

                            public /* synthetic */ TaskSetManager org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer() {
                                return this.$outer;
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.execId$3 = execId$3;
                                this.host$4 = host$4;
                                this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                            }
                        });
                    }
                    if (TaskLocality$.MODULE$.isAllowed(locality, TaskLocality$.MODULE$.ANY())) {
                        this.speculatableTasks().withFilter((Function1)new Serializable(this, execId, host){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;
                            private final String execId$3;
                            private final String host$4;

                            public final boolean apply(int index) {
                                return this.apply$mcZI$sp(index);
                            }

                            public boolean apply$mcZI$sp(int index) {
                                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$canRunOnHost$1(index, this.execId$3, this.host$4);
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.execId$3 = execId$3;
                                this.host$4 = host$4;
                            }
                        }).foreach((Function1)new Serializable(this, object){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;
                            private final Object nonLocalReturnKey1$1;

                            public final scala.runtime.Nothing$ apply(int index) {
                                this.$outer.speculatableTasks().$minus$eq((Object)BoxesRunTime.boxToInteger((int)index));
                                throw new NonLocalReturnControl(this.nonLocalReturnKey1$1, (Object)new Some((Object)new Tuple2((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.ANY())));
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                            }
                        });
                    }
                }
                option = None$.MODULE$;
            }
            catch (NonLocalReturnControl nonLocalReturnControl2) {
                if (nonLocalReturnControl2.key() != object) break block7;
                option = (Option)nonLocalReturnControl2.value();
            }
            return option;
        }
        throw nonLocalReturnControl2;
    }

    private Option<Tuple3<Object, Enumeration.Value, Object>> dequeueTask(String execId, String host, Enumeration.Value maxLocality) {
        NonLocalReturnControl nonLocalReturnControl2;
        block6 : {
            Option option;
            Object object = new Object();
            try {
                this.org$apache$spark$scheduler$TaskSetManager$$dequeueTaskFromList(execId, host, this.getPendingTasksForExecutor(execId)).foreach((Function1)new Serializable(this, object){
                    public static final long serialVersionUID = 0L;
                    private final Object nonLocalReturnKey2$1;

                    public final scala.runtime.Nothing$ apply(int index) {
                        throw new NonLocalReturnControl(this.nonLocalReturnKey2$1, (Object)new Some((Object)new Tuple3((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.PROCESS_LOCAL(), (Object)BoxesRunTime.boxToBoolean((boolean)false))));
                    }
                    {
                        this.nonLocalReturnKey2$1 = nonLocalReturnKey2$1;
                    }
                });
                if (TaskLocality$.MODULE$.isAllowed(maxLocality, TaskLocality$.MODULE$.NODE_LOCAL())) {
                    this.org$apache$spark$scheduler$TaskSetManager$$dequeueTaskFromList(execId, host, this.getPendingTasksForHost(host)).foreach((Function1)new Serializable(this, object){
                        public static final long serialVersionUID = 0L;
                        private final Object nonLocalReturnKey2$1;

                        public final scala.runtime.Nothing$ apply(int index) {
                            throw new NonLocalReturnControl(this.nonLocalReturnKey2$1, (Object)new Some((Object)new Tuple3((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.NODE_LOCAL(), (Object)BoxesRunTime.boxToBoolean((boolean)false))));
                        }
                        {
                            this.nonLocalReturnKey2$1 = nonLocalReturnKey2$1;
                        }
                    });
                }
                if (TaskLocality$.MODULE$.isAllowed(maxLocality, TaskLocality$.MODULE$.NO_PREF())) {
                    this.org$apache$spark$scheduler$TaskSetManager$$dequeueTaskFromList(execId, host, this.pendingTasksWithNoPrefs()).foreach((Function1)new Serializable(this, object){
                        public static final long serialVersionUID = 0L;
                        private final Object nonLocalReturnKey2$1;

                        public final scala.runtime.Nothing$ apply(int index) {
                            throw new NonLocalReturnControl(this.nonLocalReturnKey2$1, (Object)new Some((Object)new Tuple3((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.PROCESS_LOCAL(), (Object)BoxesRunTime.boxToBoolean((boolean)false))));
                        }
                        {
                            this.nonLocalReturnKey2$1 = nonLocalReturnKey2$1;
                        }
                    });
                }
                if (TaskLocality$.MODULE$.isAllowed(maxLocality, TaskLocality$.MODULE$.RACK_LOCAL())) {
                    this.org$apache$spark$scheduler$TaskSetManager$$sched.getRackForHost(host).foreach((Function1)new Serializable(this, execId, host, object){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ TaskSetManager $outer;
                        private final String execId$4;
                        private final String host$5;
                        public final Object nonLocalReturnKey2$1;

                        public final void apply(String rack) {
                            this.$outer.org$apache$spark$scheduler$TaskSetManager$$dequeueTaskFromList(this.execId$4, this.host$5, this.$outer.org$apache$spark$scheduler$TaskSetManager$$getPendingTasksForRack(rack)).foreach((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ $anonfun$dequeueTask$4 $outer;

                                public final scala.runtime.Nothing$ apply(int index) {
                                    throw new NonLocalReturnControl(this.$outer.nonLocalReturnKey2$1, (Object)new Some((Object)new Tuple3((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.RACK_LOCAL(), (Object)BoxesRunTime.boxToBoolean((boolean)false))));
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                }
                            });
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.execId$4 = execId$4;
                            this.host$5 = host$5;
                            this.nonLocalReturnKey2$1 = nonLocalReturnKey2$1;
                        }
                    });
                }
                if (TaskLocality$.MODULE$.isAllowed(maxLocality, TaskLocality$.MODULE$.ANY())) {
                    this.org$apache$spark$scheduler$TaskSetManager$$dequeueTaskFromList(execId, host, this.org$apache$spark$scheduler$TaskSetManager$$allPendingTasks()).foreach((Function1)new Serializable(this, object){
                        public static final long serialVersionUID = 0L;
                        private final Object nonLocalReturnKey2$1;

                        public final scala.runtime.Nothing$ apply(int index) {
                            throw new NonLocalReturnControl(this.nonLocalReturnKey2$1, (Object)new Some((Object)new Tuple3((Object)BoxesRunTime.boxToInteger((int)index), (Object)TaskLocality$.MODULE$.ANY(), (Object)BoxesRunTime.boxToBoolean((boolean)false))));
                        }
                        {
                            this.nonLocalReturnKey2$1 = nonLocalReturnKey2$1;
                        }
                    });
                }
                option = this.dequeueSpeculativeTask(execId, host, maxLocality).map((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final Tuple3<Object, Enumeration.Value, Object> apply(Tuple2<Object, Enumeration.Value> x0$1) {
                        Tuple2<Object, Enumeration.Value> tuple2 = x0$1;
                        if (tuple2 != null) {
                            int taskIndex = tuple2._1$mcI$sp();
                            Enumeration.Value allowedLocality = (Enumeration.Value)tuple2._2();
                            Tuple3 tuple3 = new Tuple3((Object)BoxesRunTime.boxToInteger((int)taskIndex), (Object)allowedLocality, (Object)BoxesRunTime.boxToBoolean((boolean)true));
                            return tuple3;
                        }
                        throw new MatchError(tuple2);
                    }
                });
            }
            catch (NonLocalReturnControl nonLocalReturnControl2) {
                if (nonLocalReturnControl2.key() != object) break block6;
                option = (Option)nonLocalReturnControl2.value();
            }
            return option;
        }
        throw nonLocalReturnControl2;
    }

    public Option<TaskDescription> resourceOffer(String execId, String host, Enumeration.Value maxLocality) throws TaskNotSerializableException {
        None$ none$;
        block5 : {
            long curTime;
            Enumeration.Value allowedLocality;
            block7 : {
                block8 : {
                    Enumeration.Value value2;
                    Enumeration.Value value3;
                    block6 : {
                        block4 : {
                            boolean offerBlacklisted = this.taskSetBlacklistHelperOpt().exists((Function1)new Serializable(this, execId, host){
                                public static final long serialVersionUID = 0L;
                                private final String execId$1;
                                private final String host$1;

                                public final boolean apply(TaskSetBlacklist blacklist) {
                                    return blacklist.isNodeBlacklistedForTaskSet(this.host$1) || blacklist.isExecutorBlacklistedForTaskSet(this.execId$1);
                                }
                                {
                                    this.execId$1 = execId$1;
                                    this.host$1 = host$1;
                                }
                            });
                            if (!this.isZombie() && !offerBlacklisted) break block4;
                            none$ = None$.MODULE$;
                            break block5;
                        }
                        curTime = this.org$apache$spark$scheduler$TaskSetManager$$clock.getTimeMillis();
                        allowedLocality = maxLocality;
                        value3 = TaskLocality$.MODULE$.NO_PREF();
                        if (maxLocality != null) break block6;
                        if (value3 == null) break block7;
                        break block8;
                    }
                    if (value2.equals((Object)value3)) break block7;
                }
                allowedLocality = this.getAllowedLocalityLevel(curTime);
                if (allowedLocality.$greater((Object)maxLocality)) {
                    allowedLocality = maxLocality;
                }
            }
            none$ = this.dequeueTask(execId, host, allowedLocality).map((Function1)new Serializable(this, execId, host, maxLocality, curTime){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ TaskSetManager $outer;
                private final String execId$1;
                public final String host$1;
                private final Enumeration.Value maxLocality$1;
                private final long curTime$1;

                public final TaskDescription apply(Tuple3<Object, Enumeration.Value, Object> x0$2) {
                    Tuple3<Object, Enumeration.Value, Object> tuple3;
                    block7 : {
                        Enumeration.Value taskLocality;
                        int attemptNum;
                        Task<?> task;
                        int index;
                        long taskId;
                        TaskInfo info;
                        java.nio.ByteBuffer serializedTask;
                        block9 : {
                            block10 : {
                                Enumeration.Value value2;
                                Enumeration.Value value3;
                                block8 : {
                                    tuple3 = x0$2;
                                    if (tuple3 == null) break block7;
                                    index = BoxesRunTime.unboxToInt((Object)tuple3._1());
                                    taskLocality = (Enumeration.Value)tuple3._2();
                                    boolean speculative = BoxesRunTime.unboxToBoolean((Object)tuple3._3());
                                    task = this.$outer.tasks()[index];
                                    taskId = this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.newTaskId();
                                    this.$outer.copiesRunning()[index] = this.$outer.copiesRunning()[index] + 1;
                                    attemptNum = this.$outer.taskAttempts()[index].size();
                                    info = new TaskInfo(taskId, index, attemptNum, this.curTime$1, this.execId$1, this.host$1, taskLocality, speculative);
                                    this.$outer.org$apache$spark$scheduler$TaskSetManager$$taskInfos().update((Object)BoxesRunTime.boxToLong((long)taskId), (Object)info);
                                    TaskInfo taskInfo = info;
                                    this.$outer.taskAttempts()[index] = this.$outer.taskAttempts()[index].$colon$colon((Object)taskInfo);
                                    value3 = TaskLocality$.MODULE$.NO_PREF();
                                    if (this.maxLocality$1 != null) break block8;
                                    if (value3 == null) break block9;
                                    break block10;
                                }
                                if (value2.equals((Object)value3)) break block9;
                            }
                            this.$outer.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex_$eq(this.$outer.getLocalityIndex(taskLocality));
                            this.$outer.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime_$eq(this.curTime$1);
                        }
                        try {
                            serializedTask = this.$outer.ser().serialize(task, ClassTag$.MODULE$.apply(Task.class));
                        }
                        catch (Throwable throwable) {
                            Throwable throwable2 = throwable;
                            Option option = scala.util.control.NonFatal$.MODULE$.unapply(throwable2);
                            if (option.isEmpty()) {
                                throw throwable;
                            }
                            Throwable e = (Throwable)option.get();
                            String msg = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Failed to serialize task ", ", not attempting to retry it."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)taskId)}));
                            this.$outer.logError((Function0<String>)new Serializable(this, msg){
                                public static final long serialVersionUID = 0L;
                                private final String msg$1;

                                public final String apply() {
                                    return this.msg$1;
                                }
                                {
                                    this.msg$1 = msg$1;
                                }
                            }, e);
                            this.$outer.abort(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " Exception during serialization: ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{msg, e})), this.$outer.abort$default$2());
                            throw new TaskNotSerializableException(e);
                        }
                        if (serializedTask.limit() > TaskSetManager$.MODULE$.TASK_SIZE_TO_WARN_KB() * 1024 && !this.$outer.emittedTaskSizeWarning()) {
                            this.$outer.emittedTaskSizeWarning_$eq(true);
                            this.$outer.logWarning((Function0<String>)new Serializable(this, task, serializedTask){
                                public static final long serialVersionUID = 0L;
                                private final Task task$1;
                                private final java.nio.ByteBuffer serializedTask$1;

                                public final String apply() {
                                    return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Stage ", " contains a task of very large size "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.task$1.stageId())}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"(", " KB). The maximum recommended task size is "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)(this.serializedTask$1.limit() / 1024))}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " KB."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)TaskSetManager$.MODULE$.TASK_SIZE_TO_WARN_KB())}))).toString();
                                }
                                {
                                    this.task$1 = task$1;
                                    this.serializedTask$1 = serializedTask$1;
                                }
                            });
                        }
                        this.$outer.addRunningTask(taskId);
                        String taskName = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"task ", " in stage ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{info.id(), this.$outer.taskSet().id()}));
                        this.$outer.logInfo((Function0<String>)new Serializable(this, taskLocality, task, taskId, info, serializedTask, taskName){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anonfun$resourceOffer$1 $outer;
                            private final Enumeration.Value taskLocality$1;
                            private final Task task$1;
                            private final long taskId$1;
                            private final TaskInfo info$1;
                            private final java.nio.ByteBuffer serializedTask$1;
                            private final String taskName$1;

                            public final String apply() {
                                return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Starting ", " (TID ", ", ", ", executor ", ", "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.taskName$1, BoxesRunTime.boxToLong((long)this.taskId$1), this.$outer.host$1, this.info$1.executorId()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"partition ", ", ", ", ", " bytes)"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.task$1.partitionId()), this.taskLocality$1, BoxesRunTime.boxToInteger((int)this.serializedTask$1.limit())}))).toString();
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.taskLocality$1 = taskLocality$1;
                                this.task$1 = task$1;
                                this.taskId$1 = taskId$1;
                                this.info$1 = info$1;
                                this.serializedTask$1 = serializedTask$1;
                                this.taskName$1 = taskName$1;
                            }
                        });
                        this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.dagScheduler().taskStarted(task, info);
                        TaskDescription taskDescription = new TaskDescription(taskId, attemptNum, this.execId$1, taskName, index, (scala.collection.mutable.Map<String, Object>)this.$outer.org$apache$spark$scheduler$TaskSetManager$$addedFiles(), (scala.collection.mutable.Map<String, Object>)this.$outer.org$apache$spark$scheduler$TaskSetManager$$addedJars(), task.localProperties(), serializedTask);
                        return taskDescription;
                    }
                    throw new MatchError(tuple3);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.execId$1 = execId$1;
                    this.host$1 = host$1;
                    this.maxLocality$1 = maxLocality$1;
                    this.curTime$1 = curTime$1;
                }
            });
        }
        return none$;
    }

    private void maybeFinishTaskSet() {
        if (this.isZombie() && this.runningTasks() == 0) {
            this.org$apache$spark$scheduler$TaskSetManager$$sched.taskSetFinished(this);
            if (this.tasksSuccessful() == this.numTasks()) {
                this.org$apache$spark$scheduler$TaskSetManager$$blacklistTracker.foreach((Function1)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ TaskSetManager $outer;

                    public final void apply(BlacklistTracker x$7) {
                        x$7.updateBlacklistForSuccessfulTaskSet(this.$outer.taskSet().stageId(), this.$outer.taskSet().stageAttemptId(), ((TaskSetBlacklist)this.$outer.taskSetBlacklistHelperOpt().get()).execToFailures());
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
            }
        }
    }

    private Enumeration.Value getAllowedLocalityLevel(long curTime) {
        while (this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex() < this.myLocalityLevels().length - 1) {
            Enumeration.Value value2;
            block18 : {
                boolean bl;
                block9 : {
                    block17 : {
                        Enumeration.Value value3;
                        Enumeration.Value value4;
                        block16 : {
                            block15 : {
                                block14 : {
                                    Enumeration.Value value5;
                                    Enumeration.Value value6;
                                    block13 : {
                                        block12 : {
                                            block11 : {
                                                Enumeration.Value value7;
                                                Enumeration.Value value8;
                                                block10 : {
                                                    block8 : {
                                                        block7 : {
                                                            Enumeration.Value value9;
                                                            Enumeration.Value value10;
                                                            block6 : {
                                                                value2 = this.myLocalityLevels()[this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()];
                                                                value10 = value2;
                                                                if (TaskLocality$.MODULE$.PROCESS_LOCAL() != null) break block6;
                                                                if (value10 == null) break block7;
                                                                break block8;
                                                            }
                                                            if (!value9.equals((Object)value10)) break block8;
                                                        }
                                                        bl = this.moreTasksToRunIn$1(this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor());
                                                        break block9;
                                                    }
                                                    value8 = value2;
                                                    if (TaskLocality$.MODULE$.NODE_LOCAL() != null) break block10;
                                                    if (value8 == null) break block11;
                                                    break block12;
                                                }
                                                if (!value7.equals((Object)value8)) break block12;
                                            }
                                            bl = this.moreTasksToRunIn$1(this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost());
                                            break block9;
                                        }
                                        value5 = value2;
                                        if (TaskLocality$.MODULE$.NO_PREF() != null) break block13;
                                        if (value5 == null) break block14;
                                        break block15;
                                    }
                                    if (!value6.equals((Object)value5)) break block15;
                                }
                                bl = this.pendingTasksWithNoPrefs().nonEmpty();
                                break block9;
                            }
                            value3 = value2;
                            if (TaskLocality$.MODULE$.RACK_LOCAL() != null) break block16;
                            if (value3 == null) break block17;
                            break block18;
                        }
                        if (!value4.equals((Object)value3)) break block18;
                    }
                    bl = this.moreTasksToRunIn$1(this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack());
                }
                boolean moreTasks = bl;
                if (moreTasks) {
                    if (curTime - this.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime() >= this.localityWaits()[this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()]) {
                        this.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime_$eq(this.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime() + this.localityWaits()[this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()]);
                        this.logDebug((Function0<String>)new Serializable(this){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ TaskSetManager $outer;

                            public final String apply() {
                                return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Moving to ", " after waiting for "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.myLocalityLevels()[this.$outer.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex() + 1]}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", "ms"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)this.$outer.localityWaits()[this.$outer.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()])}))).toString();
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                            }
                        });
                        this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex_$eq(this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex() + 1);
                        continue;
                    }
                    return this.myLocalityLevels()[this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()];
                }
                this.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime_$eq(curTime);
                this.logDebug((Function0<String>)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ TaskSetManager $outer;

                    public final String apply() {
                        return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"No tasks for locality level ", ", "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.myLocalityLevels()[this.$outer.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()]}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"so moving to locality level ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.myLocalityLevels()[this.$outer.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex() + 1]}))).toString();
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
                this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex_$eq(this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex() + 1);
                continue;
            }
            throw new MatchError((Object)value2);
        }
        return this.myLocalityLevels()[this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()];
    }

    public int getLocalityIndex(Enumeration.Value locality) {
        int index = 0;
        while (locality.$greater((Object)this.myLocalityLevels()[index])) {
            ++index;
        }
        return index;
    }

    public void abortIfCompletelyBlacklisted(HashMap<String, HashSet<String>> hostToExecutors) {
        this.taskSetBlacklistHelperOpt().foreach((Function1)new Serializable(this, hostToExecutors){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;
            public final HashMap hostToExecutors$1;

            public final void apply(TaskSetBlacklist taskSetBlacklist) {
                BlacklistTracker appBlacklist = (BlacklistTracker)this.$outer.org$apache$spark$scheduler$TaskSetManager$$blacklistTracker.get();
                if (this.hostToExecutors$1.nonEmpty()) {
                    int indexOffset = this.$outer.org$apache$spark$scheduler$TaskSetManager$$allPendingTasks().lastIndexWhere((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ $anonfun$abortIfCompletelyBlacklisted$1 $outer;

                        public final boolean apply(int indexInTaskSet) {
                            return this.apply$mcZI$sp(indexInTaskSet);
                        }

                        public boolean apply$mcZI$sp(int indexInTaskSet) {
                            return this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().copiesRunning()[indexInTaskSet] == 0 && !this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().successful()[indexInTaskSet];
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    });
                    None$ pendingTask = indexOffset == -1 ? None$.MODULE$ : new Some(this.$outer.org$apache$spark$scheduler$TaskSetManager$$allPendingTasks().apply(indexOffset));
                    pendingTask.foreach((Function1)new Serializable(this, appBlacklist, taskSetBlacklist){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ $anonfun$abortIfCompletelyBlacklisted$1 $outer;
                        public final BlacklistTracker appBlacklist$1;
                        public final TaskSetBlacklist taskSetBlacklist$1;

                        public final void apply(int indexInTaskSet) {
                            this.apply$mcVI$sp(indexInTaskSet);
                        }

                        public void apply$mcVI$sp(int indexInTaskSet) {
                            boolean blacklistedEverywhere = this.$outer.hostToExecutors$1.forall((Function1)new Serializable(this, indexInTaskSet){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ org.apache.spark.scheduler.TaskSetManager$$anonfun$abortIfCompletelyBlacklisted$1$$anonfun$apply$3 $outer;
                                public final int indexInTaskSet$1;

                                public final boolean apply(Tuple2<String, HashSet<String>> x0$4) {
                                    Tuple2<String, HashSet<String>> tuple2 = x0$4;
                                    if (tuple2 != null) {
                                        String host = (String)tuple2._1();
                                        HashSet execsOnHost = (HashSet)tuple2._2();
                                        boolean nodeBlacklisted = this.$outer.appBlacklist$1.isNodeBlacklisted(host) || this.$outer.taskSetBlacklist$1.isNodeBlacklistedForTaskSet(host) || this.$outer.taskSetBlacklist$1.isNodeBlacklistedForTask(host, this.indexInTaskSet$1);
                                        boolean bl = nodeBlacklisted ? true : execsOnHost.forall((Function1)new Serializable(this){
                                            public static final long serialVersionUID = 0L;
                                            private final /* synthetic */ org.apache.spark.scheduler.TaskSetManager$$anonfun$abortIfCompletelyBlacklisted$1$$anonfun$apply$3$$anonfun$15 $outer;

                                            public final boolean apply(String exec) {
                                                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$anonfun$$anonfun$$$outer().appBlacklist$1.isExecutorBlacklisted(exec) || this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$anonfun$$anonfun$$$outer().taskSetBlacklist$1.isExecutorBlacklistedForTaskSet(exec) || this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$anonfun$$anonfun$$$outer().taskSetBlacklist$1.isExecutorBlacklistedForTask(exec, this.$outer.indexInTaskSet$1);
                                            }
                                            {
                                                if ($outer == null) {
                                                    throw null;
                                                }
                                                this.$outer = $outer;
                                            }
                                        });
                                        return bl;
                                    }
                                    throw new MatchError(tuple2);
                                }

                                public /* synthetic */ org.apache.spark.scheduler.TaskSetManager$$anonfun$abortIfCompletelyBlacklisted$1$$anonfun$apply$3 org$apache$spark$scheduler$TaskSetManager$$anonfun$$anonfun$$anonfun$$$outer() {
                                    return this.$outer;
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                    this.indexInTaskSet$1 = indexInTaskSet$1;
                                }
                            });
                            if (blacklistedEverywhere) {
                                int partition2 = this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().tasks()[indexInTaskSet].partitionId();
                                this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().abort(new StringOps(Predef$.MODULE$.augmentString(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"\n              |Aborting ", " because task ", " (partition ", ")\n              |cannot run anywhere due to node and executor blacklist.\n              |Most recent failure:\n              |", "\n              |\n              |Blacklisting behavior can be configured via spark.blacklist.*.\n              |"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().taskSet(), BoxesRunTime.boxToInteger((int)indexInTaskSet), BoxesRunTime.boxToInteger((int)partition2), this.taskSetBlacklist$1.getLatestFailureReason()})))).stripMargin(), this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().abort$default$2());
                            }
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.appBlacklist$1 = appBlacklist$1;
                            this.taskSetBlacklist$1 = taskSetBlacklist$1;
                        }
                    });
                }
            }

            public /* synthetic */ TaskSetManager org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.hostToExecutors$1 = hostToExecutors$1;
            }
        });
    }

    public void handleTaskGettingResult(long tid) {
        TaskInfo info = (TaskInfo)this.org$apache$spark$scheduler$TaskSetManager$$taskInfos().apply((Object)BoxesRunTime.boxToLong((long)tid));
        info.markGettingResult(this.org$apache$spark$scheduler$TaskSetManager$$clock.getTimeMillis());
        this.org$apache$spark$scheduler$TaskSetManager$$sched.dagScheduler().taskGettingResult(info);
    }

    public boolean canFetchMoreResults(long size) {
        TaskSchedulerImpl taskSchedulerImpl = this.org$apache$spark$scheduler$TaskSetManager$$sched;
        synchronized (taskSchedulerImpl) {
            Boolean bl;
            this.totalResultSize_$eq(this.totalResultSize() + size);
            this.calculatedTasks_$eq(this.calculatedTasks() + 1);
            if (this.maxResultSize() > 0L && this.totalResultSize() > this.maxResultSize()) {
                String msg = new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Total size of serialized results of ", " tasks "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.calculatedTasks())}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"(", ") is bigger than spark.driver.maxResultSize "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{Utils$.MODULE$.bytesToString(this.totalResultSize())}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"(", ")"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{Utils$.MODULE$.bytesToString(this.maxResultSize())}))).toString();
                this.logError((Function0<String>)new Serializable(this, msg){
                    public static final long serialVersionUID = 0L;
                    private final String msg$2;

                    public final String apply() {
                        return this.msg$2;
                    }
                    {
                        this.msg$2 = msg$2;
                    }
                });
                this.abort(msg, this.abort$default$2());
                bl = BoxesRunTime.boxToBoolean((boolean)false);
            } else {
                bl = BoxesRunTime.boxToBoolean((boolean)true);
            }
            Boolean bl2 = bl;
            return BoxesRunTime.unboxToBoolean((Object)bl2);
        }
    }

    public void handleSuccessfulTask(long tid, DirectTaskResult<?> result2) {
        TaskInfo info = (TaskInfo)this.org$apache$spark$scheduler$TaskSetManager$$taskInfos().apply((Object)BoxesRunTime.boxToLong((long)tid));
        int index = info.index();
        info.markFinished(TaskState$.MODULE$.FINISHED(), this.org$apache$spark$scheduler$TaskSetManager$$clock.getTimeMillis());
        if (this.speculationEnabled()) {
            this.successfulTaskDurations().insert(info.duration());
        }
        this.removeRunningTask(tid);
        this.taskAttempts()[index].withFilter((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final boolean apply(TaskInfo attemptInfo) {
                return attemptInfo.running();
            }
        }).foreach((Function1)new Serializable(this, info, index){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;
            public final TaskInfo info$2;
            private final int index$3;

            public final void apply(TaskInfo attemptInfo) {
                this.$outer.logInfo((Function0<String>)new Serializable(this, attemptInfo){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ $anonfun$handleSuccessfulTask$2 $outer;
                    private final TaskInfo attemptInfo$1;

                    public final String apply() {
                        return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Killing attempt ", " for task ", " "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.attemptInfo$1.attemptNumber()), this.attemptInfo$1.id()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"in stage ", " (TID ", ") on ", " "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().taskSet().id(), BoxesRunTime.boxToLong((long)this.attemptInfo$1.taskId()), this.attemptInfo$1.host()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"as the attempt ", " succeeded on ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.info$2.attemptNumber()), this.$outer.info$2.host()}))).toString();
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.attemptInfo$1 = attemptInfo$1;
                    }
                });
                this.$outer.org$apache$spark$scheduler$TaskSetManager$$killedByOtherAttempt()[this.index$3] = true;
                this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.backend().killTask(attemptInfo.taskId(), attemptInfo.executorId(), true, "another attempt succeeded");
            }

            public /* synthetic */ TaskSetManager org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.info$2 = info$2;
                this.index$3 = index$3;
            }
        });
        if (this.successful()[index]) {
            this.logInfo((Function0<String>)new Serializable(this, info, index){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ TaskSetManager $outer;
                private final TaskInfo info$2;
                private final int index$3;

                public final String apply() {
                    return new StringBuilder().append((Object)"Ignoring task-finished event for ").append((Object)this.info$2.id()).append((Object)" in stage ").append((Object)this.$outer.taskSet().id()).append((Object)" because task ").append((Object)BoxesRunTime.boxToInteger((int)this.index$3)).append((Object)" has already completed successfully").toString();
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.info$2 = info$2;
                    this.index$3 = index$3;
                }
            });
        } else {
            this.tasksSuccessful_$eq(this.tasksSuccessful() + 1);
            this.logInfo((Function0<String>)new Serializable(this, info){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ TaskSetManager $outer;
                private final TaskInfo info$2;

                public final String apply() {
                    return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Finished task ", " in stage ", " (TID ", ") in"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.info$2.id(), this.$outer.taskSet().id(), BoxesRunTime.boxToLong((long)this.info$2.taskId())}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" ", " ms on ", " (executor ", ")"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)this.info$2.duration()), this.info$2.host(), this.info$2.executorId()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" (", "/", ")"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.tasksSuccessful()), BoxesRunTime.boxToInteger((int)this.$outer.numTasks())}))).toString();
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.info$2 = info$2;
                }
            });
            this.successful()[index] = true;
            if (this.tasksSuccessful() == this.numTasks()) {
                this.isZombie_$eq(true);
            }
        }
        this.org$apache$spark$scheduler$TaskSetManager$$sched.dagScheduler().taskEnded(this.tasks()[index], Success$.MODULE$, result2.value(result2.value$default$1()), result2.accumUpdates(), info);
        this.maybeFinishTaskSet();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void handleFailedTask(long tid, Enumeration.Value state, TaskFailedReason reason) {
        String failureReason;
        int index;
        Option<Throwable> option;
        TaskInfo info;
        Seq<AccumulatorV2<?, ?>> accumUpdates;
        block19 : {
            ExecutorLostFailure executorLostFailure;
            TaskFailedReason taskFailedReason;
            block20 : {
                Tuple2.mcZI.sp sp2;
                Tuple2.mcZI.sp sp3;
                ExceptionFailure exceptionFailure;
                Tuple2.mcZI.sp sp4;
                block23 : {
                    block22 : {
                        String string;
                        String string2;
                        block21 : {
                            block18 : {
                                info = (TaskInfo)this.org$apache$spark$scheduler$TaskSetManager$$taskInfos().apply((Object)BoxesRunTime.boxToLong((long)tid));
                                if (info.failed() || info.killed()) {
                                    return;
                                }
                                this.removeRunningTask(tid);
                                info.markFinished(state, this.org$apache$spark$scheduler$TaskSetManager$$clock.getTimeMillis());
                                index = info.index();
                                this.copiesRunning()[index] = this.copiesRunning()[index] - 1;
                                accumUpdates = (Seq<AccumulatorV2<?, ?>>)Seq$.MODULE$.empty();
                                failureReason = new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Lost task ", " in stage ", " (TID ", ", ", ","})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{info.id(), this.taskSet().id(), BoxesRunTime.boxToLong((long)tid), info.host()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" executor ", "): ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{info.executorId(), reason.toErrorString()}))).toString();
                                taskFailedReason = reason;
                                if (!(taskFailedReason instanceof FetchFailed)) break block18;
                                FetchFailed fetchFailed = (FetchFailed)taskFailedReason;
                                this.logWarning((Function0<String>)new Serializable(this, failureReason){
                                    public static final long serialVersionUID = 0L;
                                    private final String failureReason$1;

                                    public final String apply() {
                                        return this.failureReason$1;
                                    }
                                    {
                                        this.failureReason$1 = failureReason$1;
                                    }
                                });
                                if (!this.successful()[index]) {
                                    this.successful()[index] = true;
                                    this.tasksSuccessful_$eq(this.tasksSuccessful() + 1);
                                }
                                this.isZombie_$eq(true);
                                if (fetchFailed.bmAddress() != null) {
                                    this.org$apache$spark$scheduler$TaskSetManager$$blacklistTracker.foreach((Function1)new Serializable(this, fetchFailed){
                                        public static final long serialVersionUID = 0L;
                                        private final FetchFailed x2$1;

                                        public final void apply(BlacklistTracker x$8) {
                                            x$8.updateBlacklistForFetchFailure(this.x2$1.bmAddress().host(), this.x2$1.bmAddress().executorId());
                                        }
                                        {
                                            this.x2$1 = x2$1;
                                        }
                                    });
                                }
                                option = None$.MODULE$;
                                break block19;
                            }
                            if (!(taskFailedReason instanceof ExceptionFailure)) break block20;
                            exceptionFailure = (ExceptionFailure)taskFailedReason;
                            accumUpdates = exceptionFailure.accums();
                            string2 = NotSerializableException.class.getName();
                            if (exceptionFailure.className() != null) break block21;
                            if (string2 == null) break block22;
                            break block23;
                        }
                        if (!string.equals(string2)) break block23;
                    }
                    this.logError((Function0<String>)new Serializable(this, tid, info, exceptionFailure){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ TaskSetManager $outer;
                        private final long tid$1;
                        private final TaskInfo info$3;
                        private final ExceptionFailure x3$2;

                        public final String apply() {
                            return new StringOps(Predef$.MODULE$.augmentString("Task %s in stage %s (TID %d) had a not serializable result: %s; not retrying")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.info$3.id(), this.$outer.taskSet().id(), BoxesRunTime.boxToLong((long)this.tid$1), this.x3$2.description()}));
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.tid$1 = tid$1;
                            this.info$3 = info$3;
                            this.x3$2 = x3$2;
                        }
                    });
                    this.abort(new StringOps(Predef$.MODULE$.augmentString("Task %s in stage %s (TID %d) had a not serializable result: %s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{info.id(), this.taskSet().id(), BoxesRunTime.boxToLong((long)tid), exceptionFailure.description()})), this.abort$default$2());
                    return;
                }
                String key = exceptionFailure.description();
                long now = this.org$apache$spark$scheduler$TaskSetManager$$clock.getTimeMillis();
                if (this.recentExceptions().contains((Object)key)) {
                    Tuple2.mcIJ.sp sp5;
                    Tuple2 tuple2 = (Tuple2)this.recentExceptions().apply((Object)key);
                    if (tuple2 == null) throw new MatchError((Object)tuple2);
                    int dupCount = tuple2._1$mcI$sp();
                    long printTime = tuple2._2$mcJ$sp();
                    Tuple2.mcIJ.sp sp6 = sp5 = new Tuple2.mcIJ.sp(dupCount, printTime);
                    int dupCount2 = sp6._1$mcI$sp();
                    long printTime2 = sp6._2$mcJ$sp();
                    if (now - printTime2 > this.EXCEPTION_PRINT_INTERVAL()) {
                        this.recentExceptions().update((Object)key, (Object)new Tuple2.mcIJ.sp(0, now));
                        sp2 = new Tuple2.mcZI.sp(true, 0);
                    } else {
                        this.recentExceptions().update((Object)key, (Object)new Tuple2.mcIJ.sp(dupCount2 + 1, printTime2));
                        sp2 = new Tuple2.mcZI.sp(false, dupCount2 + 1);
                    }
                } else {
                    this.recentExceptions().update((Object)key, (Object)new Tuple2.mcIJ.sp(0, now));
                    sp2 = sp4 = new Tuple2.mcZI.sp(true, 0);
                }
                if (sp4 == null) throw new MatchError((Object)sp4);
                boolean printFull = sp4._1$mcZ$sp();
                int dupCount = sp4._2$mcI$sp();
                Tuple2.mcZI.sp sp7 = sp3 = new Tuple2.mcZI.sp(printFull, dupCount);
                boolean printFull2 = sp7._1$mcZ$sp();
                int dupCount3 = sp7._2$mcI$sp();
                if (printFull2) {
                    this.logWarning((Function0<String>)new Serializable(this, failureReason){
                        public static final long serialVersionUID = 0L;
                        private final String failureReason$1;

                        public final String apply() {
                            return this.failureReason$1;
                        }
                        {
                            this.failureReason$1 = failureReason$1;
                        }
                    });
                } else {
                    this.logInfo((Function0<String>)new Serializable(this, tid, info, dupCount3, exceptionFailure){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ TaskSetManager $outer;
                        private final long tid$1;
                        private final TaskInfo info$3;
                        private final int dupCount$1;
                        private final ExceptionFailure x3$2;

                        public final String apply() {
                            return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Lost task ", " in stage ", " (TID ", ") on ", ", executor"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.info$3.id(), this.$outer.taskSet().id(), BoxesRunTime.boxToLong((long)this.tid$1), this.info$3.host()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" ", ": ", " (", ") [duplicate ", "]"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.info$3.executorId(), this.x3$2.className(), this.x3$2.description(), BoxesRunTime.boxToInteger((int)this.dupCount$1)}))).toString();
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.tid$1 = tid$1;
                            this.info$3 = info$3;
                            this.dupCount$1 = dupCount$1;
                            this.x3$2 = x3$2;
                        }
                    });
                }
                option = exceptionFailure.exception();
                break block19;
            }
            if (taskFailedReason instanceof ExecutorLostFailure && !(executorLostFailure = (ExecutorLostFailure)taskFailedReason).exitCausedByApp()) {
                this.logInfo((Function0<String>)new Serializable(this, tid){
                    public static final long serialVersionUID = 0L;
                    private final long tid$1;

                    public final String apply() {
                        return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Task ", " failed because while it was being computed, its executor "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)this.tid$1)}))).append((Object)"exited for a reason unrelated to the task. Not counting this failure towards the ").append((Object)"maximum number of failures for the task.").toString();
                    }
                    {
                        this.tid$1 = tid$1;
                    }
                });
                option = None$.MODULE$;
            } else {
                if (taskFailedReason == null) throw new MatchError((Object)taskFailedReason);
                this.logWarning((Function0<String>)new Serializable(this, failureReason){
                    public static final long serialVersionUID = 0L;
                    private final String failureReason$1;

                    public final String apply() {
                        return this.failureReason$1;
                    }
                    {
                        this.failureReason$1 = failureReason$1;
                    }
                });
                option = None$.MODULE$;
            }
        }
        Option<Throwable> failureException = option;
        this.org$apache$spark$scheduler$TaskSetManager$$sched.dagScheduler().taskEnded(this.tasks()[index], reason, null, accumUpdates, info);
        if (!this.isZombie() && reason.countTowardsTaskFailures()) {
            Predef$.MODULE$.assert(failureReason != null);
            this.taskSetBlacklistHelperOpt().foreach((Function1)new Serializable(this, info, index, failureReason){
                public static final long serialVersionUID = 0L;
                private final TaskInfo info$3;
                private final int index$4;
                private final String failureReason$1;

                public final void apply(TaskSetBlacklist x$11) {
                    x$11.updateBlacklistForFailedTask(this.info$3.host(), this.info$3.executorId(), this.index$4, this.failureReason$1);
                }
                {
                    this.info$3 = info$3;
                    this.index$4 = index$4;
                    this.failureReason$1 = failureReason$1;
                }
            });
            this.numFailures()[index] = this.numFailures()[index] + 1;
            if (this.numFailures()[index] >= this.maxTaskFailures()) {
                this.logError((Function0<String>)new Serializable(this, index){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ TaskSetManager $outer;
                    private final int index$4;

                    public final String apply() {
                        return new StringOps(Predef$.MODULE$.augmentString("Task %d in stage %s failed %d times; aborting job")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.index$4), this.$outer.taskSet().id(), BoxesRunTime.boxToInteger((int)this.$outer.maxTaskFailures())}));
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.index$4 = index$4;
                    }
                });
                this.abort(new StringOps(Predef$.MODULE$.augmentString("Task %d in stage %s failed %d times, most recent failure: %s\nDriver stacktrace:")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)index), this.taskSet().id(), BoxesRunTime.boxToInteger((int)this.maxTaskFailures()), failureReason})), failureException);
                return;
            }
        }
        if (this.successful()[index]) {
            this.logInfo((Function0<String>)new Serializable(this, tid, info){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ TaskSetManager $outer;
                private final long tid$1;
                private final TaskInfo info$3;

                public final String apply() {
                    return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Task ", " in stage ", " (TID ", ") failed, but the task will not"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.info$3.id(), this.$outer.taskSet().id(), BoxesRunTime.boxToLong((long)this.tid$1)}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" be re-executed (either because the task failed with a shuffle data fetch failure,"})).s((Seq)Nil$.MODULE$)).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" so the previous stage needs to be re-run, or because a different copy of the task"})).s((Seq)Nil$.MODULE$)).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" has already succeeded)."})).s((Seq)Nil$.MODULE$)).toString();
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.tid$1 = tid$1;
                    this.info$3 = info$3;
                }
            });
        } else {
            this.addPendingTask(index);
        }
        this.maybeFinishTaskSet();
    }

    public void abort(String message, Option<Throwable> exception2) {
        TaskSchedulerImpl taskSchedulerImpl = this.org$apache$spark$scheduler$TaskSetManager$$sched;
        synchronized (taskSchedulerImpl) {
            this.org$apache$spark$scheduler$TaskSetManager$$sched.dagScheduler().taskSetFailed(this.taskSet(), message, exception2);
            this.isZombie_$eq(true);
            this.maybeFinishTaskSet();
            return;
        }
    }

    public Option<Throwable> abort$default$2() {
        return None$.MODULE$;
    }

    public void addRunningTask(long tid) {
        if (this.runningTasksSet().add((Object)BoxesRunTime.boxToLong((long)tid)) && this.parent() != null) {
            this.parent().increaseRunningTasks(1);
        }
    }

    public void removeRunningTask(long tid) {
        if (this.runningTasksSet().remove((Object)BoxesRunTime.boxToLong((long)tid)) && this.parent() != null) {
            this.parent().decreaseRunningTasks(1);
        }
    }

    @Override
    public Schedulable getSchedulableByName(String name2) {
        return null;
    }

    @Override
    public void addSchedulable(Schedulable schedulable) {
    }

    @Override
    public void removeSchedulable(Schedulable schedulable) {
    }

    @Override
    public ArrayBuffer<TaskSetManager> getSortedTaskSetQueue() {
        ArrayBuffer sortedTaskSetQueue = new ArrayBuffer();
        sortedTaskSetQueue.$plus$eq((Object)this);
        return sortedTaskSetQueue;
    }

    @Override
    public void executorLost(String execId, String host, ExecutorLossReason reason) {
        if (this.tasks()[0] instanceof ShuffleMapTask && !this.env().blockManager().externalShuffleServiceEnabled() && !this.isZombie()) {
            this.org$apache$spark$scheduler$TaskSetManager$$taskInfos().withFilter((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final boolean apply(Tuple2<Object, TaskInfo> check$ifrefutable$1) {
                    Tuple2<Object, TaskInfo> tuple2 = check$ifrefutable$1;
                    boolean bl = tuple2 != null;
                    return bl;
                }
            }).withFilter((Function1)new Serializable(this, execId){
                public static final long serialVersionUID = 0L;
                private final String execId$5;

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final boolean apply(Tuple2<Object, TaskInfo> x$12) {
                    Tuple2<Object, TaskInfo> tuple2 = x$12;
                    if (tuple2 == null) throw new MatchError(tuple2);
                    TaskInfo info = (TaskInfo)tuple2._2();
                    String string = this.execId$5;
                    if (info.executorId() != null) {
                        String string2;
                        if (!string2.equals(string)) return false;
                        return true;
                    }
                    if (string == null) return true;
                    return false;
                }
                {
                    this.execId$5 = execId$5;
                }
            }).foreach((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ TaskSetManager $outer;

                public final void apply(Tuple2<Object, TaskInfo> x$13) {
                    Tuple2<Object, TaskInfo> tuple2 = x$13;
                    if (tuple2 != null) {
                        BoxedUnit boxedUnit;
                        long tid = tuple2._1$mcJ$sp();
                        TaskInfo info = (TaskInfo)tuple2._2();
                        int index = ((TaskInfo)this.$outer.org$apache$spark$scheduler$TaskSetManager$$taskInfos().apply((Object)BoxesRunTime.boxToLong((long)tid))).index();
                        if (this.$outer.successful()[index] && !this.$outer.org$apache$spark$scheduler$TaskSetManager$$killedByOtherAttempt()[index]) {
                            this.$outer.successful()[index] = false;
                            this.$outer.copiesRunning()[index] = this.$outer.copiesRunning()[index] - 1;
                            this.$outer.tasksSuccessful_$eq(this.$outer.tasksSuccessful() - 1);
                            this.$outer.addPendingTask(index);
                            this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.dagScheduler().taskEnded(this.$outer.tasks()[index], org.apache.spark.Resubmitted$.MODULE$, null, (Seq)Seq$.MODULE$.empty(), info);
                            boxedUnit = BoxedUnit.UNIT;
                        } else {
                            boxedUnit = BoxedUnit.UNIT;
                        }
                        BoxedUnit boxedUnit2 = boxedUnit;
                        return;
                    }
                    throw new MatchError(tuple2);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            });
        }
        this.org$apache$spark$scheduler$TaskSetManager$$taskInfos().withFilter((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final boolean apply(Tuple2<Object, TaskInfo> check$ifrefutable$2) {
                Tuple2<Object, TaskInfo> tuple2 = check$ifrefutable$2;
                boolean bl = tuple2 != null;
                return bl;
            }
        }).withFilter((Function1)new Serializable(this, execId){
            public static final long serialVersionUID = 0L;
            private final String execId$5;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(Tuple2<Object, TaskInfo> x$14) {
                Tuple2<Object, TaskInfo> tuple2 = x$14;
                if (tuple2 == null) throw new MatchError(tuple2);
                TaskInfo info = (TaskInfo)tuple2._2();
                if (!info.running()) return false;
                String string = this.execId$5;
                if (info.executorId() != null) {
                    String string2;
                    if (!string2.equals(string)) return false;
                    return true;
                }
                if (string == null) return true;
                return false;
            }
            {
                this.execId$5 = execId$5;
            }
        }).foreach((Function1)new Serializable(this, reason){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;
            private final ExecutorLossReason reason$1;

            public final void apply(Tuple2<Object, TaskInfo> x$15) {
                Tuple2<Object, TaskInfo> tuple2 = x$15;
                if (tuple2 != null) {
                    boolean bl;
                    long tid = tuple2._1$mcJ$sp();
                    TaskInfo info = (TaskInfo)tuple2._2();
                    ExecutorLossReason executorLossReason = this.reason$1;
                    if (executorLossReason instanceof org.apache.spark.scheduler.ExecutorExited) {
                        org.apache.spark.scheduler.ExecutorExited executorExited = (org.apache.spark.scheduler.ExecutorExited)executorLossReason;
                        bl = executorExited.exitCausedByApp();
                    } else {
                        bl = !org.apache.spark.scheduler.ExecutorKilled$.MODULE$.equals(executorLossReason);
                    }
                    boolean exitCausedByApp = bl;
                    this.$outer.handleFailedTask(tid, TaskState$.MODULE$.FAILED(), new ExecutorLostFailure(info.executorId(), exitCausedByApp, (Option<String>)new Some((Object)this.reason$1.toString())));
                    BoxedUnit boxedUnit = BoxedUnit.UNIT;
                    return;
                }
                throw new MatchError(tuple2);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.reason$1 = reason$1;
            }
        });
        this.recomputeLocality();
    }

    @Override
    public boolean checkSpeculatableTasks(int minTimeToSpeculation) {
        if (this.isZombie() || this.numTasks() == 1) {
            return false;
        }
        BooleanRef foundTasks = BooleanRef.create((boolean)false);
        int minFinishedForSpeculation = (int)RichDouble$.MODULE$.floor$extension(Predef$.MODULE$.doubleWrapper(this.SPECULATION_QUANTILE() * (double)this.numTasks()));
        this.logDebug((Function0<String>)new Serializable(this, minFinishedForSpeculation){
            public static final long serialVersionUID = 0L;
            private final int minFinishedForSpeculation$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Checking for speculative tasks: minFinished = ").append((Object)BoxesRunTime.boxToInteger((int)this.minFinishedForSpeculation$1)).toString();
            }
            {
                this.minFinishedForSpeculation$1 = minFinishedForSpeculation$1;
            }
        });
        if (this.tasksSuccessful() >= minFinishedForSpeculation && this.tasksSuccessful() > 0) {
            long time = this.org$apache$spark$scheduler$TaskSetManager$$clock.getTimeMillis();
            double medianDuration = this.successfulTaskDurations().median();
            double threshold = package$.MODULE$.max(this.SPECULATION_MULTIPLIER() * medianDuration, (double)minTimeToSpeculation);
            this.logDebug((Function0<String>)new Serializable(this, threshold){
                public static final long serialVersionUID = 0L;
                private final double threshold$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"Task length threshold for speculation: ").append((Object)BoxesRunTime.boxToDouble((double)this.threshold$1)).toString();
                }
                {
                    this.threshold$1 = threshold$1;
                }
            });
            this.runningTasksSet().foreach((Function1)new Serializable(this, foundTasks, time, threshold){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ TaskSetManager $outer;
                private final BooleanRef foundTasks$1;
                private final long time$1;
                public final double threshold$1;

                public final void apply(long tid) {
                    this.apply$mcVJ$sp(tid);
                }

                public void apply$mcVJ$sp(long tid) {
                    TaskInfo info = (TaskInfo)this.$outer.org$apache$spark$scheduler$TaskSetManager$$taskInfos().apply((Object)BoxesRunTime.boxToLong((long)tid));
                    int index = info.index();
                    if (!this.$outer.successful()[index] && this.$outer.copiesRunning()[index] == 1 && (double)info.timeRunning(this.time$1) > this.threshold$1 && !this.$outer.speculatableTasks().contains((Object)BoxesRunTime.boxToInteger((int)index))) {
                        this.$outer.logInfo((Function0<String>)new Serializable(this, info, index){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anonfun$checkSpeculatableTasks$1 $outer;
                            private final TaskInfo info$4;
                            private final int index$5;

                            public final String apply() {
                                return new StringOps(Predef$.MODULE$.augmentString("Marking task %d in stage %s (on %s) as speculatable because it ran more than %.0f ms")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.index$5), this.$outer.org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer().taskSet().id(), this.info$4.host(), BoxesRunTime.boxToDouble((double)this.$outer.threshold$1)}));
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.info$4 = info$4;
                                this.index$5 = index$5;
                            }
                        });
                        this.$outer.speculatableTasks().$plus$eq((Object)BoxesRunTime.boxToInteger((int)index));
                        this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.dagScheduler().speculativeTaskSubmitted(this.$outer.tasks()[index]);
                        this.foundTasks$1.elem = true;
                    }
                }

                public /* synthetic */ TaskSetManager org$apache$spark$scheduler$TaskSetManager$$anonfun$$$outer() {
                    return this.$outer;
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.foundTasks$1 = foundTasks$1;
                    this.time$1 = time$1;
                    this.threshold$1 = threshold$1;
                }
            });
        }
        return foundTasks.elem;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public long org$apache$spark$scheduler$TaskSetManager$$getLocalityWait(Enumeration.Value level) {
        block9 : {
            block10 : {
                block8 : {
                    block7 : {
                        block6 : {
                            defaultWait = BoxesRunTime.unboxToLong((Object)this.org$apache$spark$scheduler$TaskSetManager$$conf().get(org.apache.spark.internal.config.package$.MODULE$.LOCALITY_WAIT()));
                            var5_3 = level;
                            var6_4 = var5_3;
                            if (TaskLocality$.MODULE$.PROCESS_LOCAL() != null) break block6;
                            if (var6_4 == null) break block7;
                            break block8;
                        }
                        if (!v0.equals((Object)var6_4)) break block8;
                    }
                    var7_5 = "spark.locality.wait.process";
                    break block9;
                }
                var8_6 = var5_3;
                if (TaskLocality$.MODULE$.NODE_LOCAL() != null) break block10;
                if (var8_6 == null) ** GOTO lbl-1000
                ** GOTO lbl-1000
            }
            if (v1.equals((Object)var8_6)) lbl-1000: // 2 sources:
            {
                var7_5 = "spark.locality.wait.node";
            } else lbl-1000: // 2 sources:
            {
                var9_7 = var5_3;
                if (TaskLocality$.MODULE$.RACK_LOCAL() == null) {
                    if (var9_7 != null) {
                        return 0L;
                    }
                } else if (v2.equals((Object)var9_7) == false) return 0L;
                var7_5 = "spark.locality.wait.rack";
            }
        }
        localityWaitKey = var7_5;
        if (localityWaitKey == null) {
            return 0L;
        }
        v3 = this.org$apache$spark$scheduler$TaskSetManager$$conf().getTimeAsMs(localityWaitKey, BoxesRunTime.boxToLong((long)defaultWait).toString());
        return v3;
    }

    private Enumeration.Value[] computeValidLocalityLevels() {
        ArrayBuffer levels = new ArrayBuffer();
        Object object = !this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor().isEmpty() && this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor().keySet().exists((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final boolean apply(String x$16) {
                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.isExecutorAlive(x$16);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }) ? levels.$plus$eq((Object)TaskLocality$.MODULE$.PROCESS_LOCAL()) : BoxedUnit.UNIT;
        Object object2 = !this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost().isEmpty() && this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost().keySet().exists((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final boolean apply(String x$17) {
                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.hasExecutorsAliveOnHost(x$17);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }) ? levels.$plus$eq((Object)TaskLocality$.MODULE$.NODE_LOCAL()) : BoxedUnit.UNIT;
        Object object3 = this.pendingTasksWithNoPrefs().isEmpty() ? BoxedUnit.UNIT : levels.$plus$eq((Object)TaskLocality$.MODULE$.NO_PREF());
        Object object4 = !this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack().isEmpty() && this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack().keySet().exists((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final boolean apply(String x$18) {
                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.hasHostAliveOnRack(x$18);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }) ? levels.$plus$eq((Object)TaskLocality$.MODULE$.RACK_LOCAL()) : BoxedUnit.UNIT;
        levels.$plus$eq((Object)TaskLocality$.MODULE$.ANY());
        this.logDebug((Function0<String>)new Serializable(this, levels){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;
            private final ArrayBuffer levels$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Valid locality levels for ").append((Object)this.$outer.taskSet()).append((Object)": ").append((Object)this.levels$1.mkString(", ")).toString();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.levels$1 = levels$1;
            }
        });
        return (Enumeration.Value[])levels.toArray(ClassTag$.MODULE$.apply(Enumeration.Value.class));
    }

    public void recomputeLocality() {
        Enumeration.Value previousLocalityLevel = this.myLocalityLevels()[this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex()];
        this.myLocalityLevels_$eq(this.computeValidLocalityLevels());
        this.localityWaits_$eq((long[])Predef$.MODULE$.refArrayOps((Object[])this.myLocalityLevels()).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final long apply(Enumeration.Value level) {
                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$getLocalityWait(level);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Long())));
        this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex_$eq(this.getLocalityIndex(previousLocalityLevel));
    }

    public void executorAdded() {
        this.recomputeLocality();
    }

    public final boolean org$apache$spark$scheduler$TaskSetManager$$canRunOnHost$1(int index, String execId$3, String host$4) {
        return !this.hasAttemptOnHost(index, host$4) && !this.isTaskBlacklistedOnExecOrNode(index, execId$3, host$4);
    }

    public final boolean org$apache$spark$scheduler$TaskSetManager$$tasksNeedToBeScheduledFrom$1(ArrayBuffer pendingTaskIds) {
        int indexOffset = pendingTaskIds.size();
        while (indexOffset > 0) {
            int index = BoxesRunTime.unboxToInt((Object)pendingTaskIds.apply(--indexOffset));
            if (this.copiesRunning()[index] == 0 && !this.successful()[index]) {
                return true;
            }
            pendingTaskIds.remove(indexOffset);
        }
        return false;
    }

    private final boolean moreTasksToRunIn$1(HashMap pendingTasks2) {
        ArrayBuffer emptyKeys = new ArrayBuffer();
        boolean hasTasks = pendingTasks2.exists((Function1)new Serializable(this, emptyKeys){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;
            private final ArrayBuffer emptyKeys$1;

            public final boolean apply(Tuple2<String, ArrayBuffer<Object>> x0$3) {
                Tuple2<String, ArrayBuffer<Object>> tuple2 = x0$3;
                if (tuple2 != null) {
                    String id = (String)tuple2._1();
                    ArrayBuffer tasks = (ArrayBuffer)tuple2._2();
                    if (id != null) {
                        String string = id;
                        if (tasks != null) {
                            boolean bl;
                            ArrayBuffer arrayBuffer = tasks;
                            if (this.$outer.org$apache$spark$scheduler$TaskSetManager$$tasksNeedToBeScheduledFrom$1(arrayBuffer)) {
                                bl = true;
                            } else {
                                this.emptyKeys$1.$plus$eq((Object)string);
                                bl = false;
                            }
                            boolean bl2 = bl;
                            return bl2;
                        }
                    }
                }
                throw new MatchError(tuple2);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.emptyKeys$1 = emptyKeys$1;
            }
        });
        emptyKeys.foreach((Function1)new Serializable(this, pendingTasks2){
            public static final long serialVersionUID = 0L;
            private final HashMap pendingTasks$1;

            public final Option<ArrayBuffer<Object>> apply(String id) {
                return this.pendingTasks$1.remove((Object)id);
            }
            {
                this.pendingTasks$1 = pendingTasks$1;
            }
        });
        return hasTasks;
    }

    public TaskSetManager(TaskSchedulerImpl sched, TaskSet taskSet, int maxTaskFailures, Option<BlacklistTracker> blacklistTracker, Clock clock) {
        this.org$apache$spark$scheduler$TaskSetManager$$sched = sched;
        this.taskSet = taskSet;
        this.maxTaskFailures = maxTaskFailures;
        this.org$apache$spark$scheduler$TaskSetManager$$blacklistTracker = blacklistTracker;
        this.org$apache$spark$scheduler$TaskSetManager$$clock = clock;
        Logging$class.$init$(this);
        this.org$apache$spark$scheduler$TaskSetManager$$conf = sched.sc().conf();
        this.org$apache$spark$scheduler$TaskSetManager$$addedJars = (HashMap)HashMap$.MODULE$.apply(sched.sc().addedJars().toSeq());
        this.org$apache$spark$scheduler$TaskSetManager$$addedFiles = (HashMap)HashMap$.MODULE$.apply(sched.sc().addedFiles().toSeq());
        this.SPECULATION_QUANTILE = this.org$apache$spark$scheduler$TaskSetManager$$conf().getDouble("spark.speculation.quantile", 0.75);
        this.SPECULATION_MULTIPLIER = this.org$apache$spark$scheduler$TaskSetManager$$conf().getDouble("spark.speculation.multiplier", 1.5);
        this.maxResultSize = Utils$.MODULE$.getMaxResultSize(this.org$apache$spark$scheduler$TaskSetManager$$conf());
        this.speculationEnabled = this.org$apache$spark$scheduler$TaskSetManager$$conf().getBoolean("spark.speculation", false);
        this.env = SparkEnv$.MODULE$.get();
        this.ser = this.env().closureSerializer().newInstance();
        this.tasks = taskSet.tasks();
        this.numTasks = this.tasks().length;
        this.copiesRunning = new int[this.numTasks()];
        this.successful = new boolean[this.numTasks()];
        this.numFailures = new int[this.numTasks()];
        this.org$apache$spark$scheduler$TaskSetManager$$killedByOtherAttempt = new boolean[this.numTasks()];
        this.taskAttempts = (List[])Array$.MODULE$.fill(this.numTasks(), (Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final Nil$ apply() {
                return Nil$.MODULE$;
            }
        }, ClassTag$.MODULE$.apply(List.class));
        this.tasksSuccessful = 0;
        this.weight = 1;
        this.minShare = 0;
        this.priority = taskSet.priority();
        this.stageId = taskSet.stageId();
        this.name = new StringBuilder().append((Object)"TaskSet_").append((Object)taskSet.id()).toString();
        this.parent = null;
        this.totalResultSize = 0L;
        this.calculatedTasks = 0;
        this.taskSetBlacklistHelperOpt = blacklistTracker.map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final TaskSetBlacklist apply(BlacklistTracker x$1) {
                return new TaskSetBlacklist(this.$outer.org$apache$spark$scheduler$TaskSetManager$$sched.sc().listenerBus(), this.$outer.org$apache$spark$scheduler$TaskSetManager$$conf(), this.$outer.stageId(), this.$outer.taskSet().stageAttemptId(), this.$outer.org$apache$spark$scheduler$TaskSetManager$$clock);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        this.runningTasksSet = new HashSet();
        this.isZombie = false;
        this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForExecutor = new HashMap();
        this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForHost = new HashMap();
        this.org$apache$spark$scheduler$TaskSetManager$$pendingTasksForRack = new HashMap();
        this.pendingTasksWithNoPrefs = new ArrayBuffer();
        this.org$apache$spark$scheduler$TaskSetManager$$allPendingTasks = new ArrayBuffer();
        this.speculatableTasks = new HashSet();
        this.org$apache$spark$scheduler$TaskSetManager$$taskInfos = new HashMap();
        this.successfulTaskDurations = new MedianHeap((Ordering<Object>)Ordering.Double$.MODULE$);
        this.EXCEPTION_PRINT_INTERVAL = this.org$apache$spark$scheduler$TaskSetManager$$conf().getLong("spark.logging.exceptionPrintInterval", 10000L);
        this.recentExceptions = (HashMap)HashMap$.MODULE$.apply((Seq)Nil$.MODULE$);
        this.epoch = sched.mapOutputTracker().getEpoch();
        this.logDebug((Function0<String>)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final String apply() {
                return new StringBuilder().append((Object)"Epoch for ").append((Object)this.$outer.taskSet()).append((Object)": ").append((Object)BoxesRunTime.boxToLong((long)this.$outer.epoch())).toString();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        Predef$.MODULE$.refArrayOps((Object[])this.tasks()).foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final void apply(Task<?> t) {
                t.epoch_$eq(this.$outer.epoch());
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        RichInt$.MODULE$.until$extension0(Predef$.MODULE$.intWrapper(0), this.numTasks()).reverse().foreach$mVc$sp((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final void apply(int i) {
                this.apply$mcVI$sp(i);
            }

            public void apply$mcVI$sp(int i) {
                this.$outer.addPendingTask(i);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        this.myLocalityLevels = this.computeValidLocalityLevels();
        this.localityWaits = (long[])Predef$.MODULE$.refArrayOps((Object[])this.myLocalityLevels()).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ TaskSetManager $outer;

            public final long apply(Enumeration.Value level) {
                return this.$outer.org$apache$spark$scheduler$TaskSetManager$$getLocalityWait(level);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Long()));
        this.org$apache$spark$scheduler$TaskSetManager$$currentLocalityIndex = 0;
        this.org$apache$spark$scheduler$TaskSetManager$$lastLaunchTime = clock.getTimeMillis();
        this.emittedTaskSizeWarning = false;
    }
}

