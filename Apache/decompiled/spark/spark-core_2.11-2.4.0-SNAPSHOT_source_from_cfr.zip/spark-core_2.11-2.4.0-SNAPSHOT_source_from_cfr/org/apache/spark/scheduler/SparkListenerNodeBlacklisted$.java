/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerNodeBlacklisted;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;
import scala.runtime.BoxesRunTime;

public final class SparkListenerNodeBlacklisted$
extends AbstractFunction3<Object, String, Object, SparkListenerNodeBlacklisted>
implements Serializable {
    public static final SparkListenerNodeBlacklisted$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerNodeBlacklisted$();
    }

    public final String toString() {
        return "SparkListenerNodeBlacklisted";
    }

    public SparkListenerNodeBlacklisted apply(long time, String hostId, int executorFailures) {
        return new SparkListenerNodeBlacklisted(time, hostId, executorFailures);
    }

    public Option<Tuple3<Object, String, Object>> unapply(SparkListenerNodeBlacklisted x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)BoxesRunTime.boxToLong((long)x$0.time()), (Object)x$0.hostId(), (Object)BoxesRunTime.boxToInteger((int)x$0.executorFailures())));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerNodeBlacklisted$() {
        MODULE$ = this;
    }
}

