/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark;

import org.apache.spark.scheduler.SparkListenerApplicationEnd;
import org.apache.spark.scheduler.SparkListenerApplicationStart;
import org.apache.spark.scheduler.SparkListenerBlockManagerAdded;
import org.apache.spark.scheduler.SparkListenerBlockManagerRemoved;
import org.apache.spark.scheduler.SparkListenerBlockUpdated;
import org.apache.spark.scheduler.SparkListenerEnvironmentUpdate;
import org.apache.spark.scheduler.SparkListenerEvent;
import org.apache.spark.scheduler.SparkListenerExecutorAdded;
import org.apache.spark.scheduler.SparkListenerExecutorBlacklisted;
import org.apache.spark.scheduler.SparkListenerExecutorBlacklistedForStage;
import org.apache.spark.scheduler.SparkListenerExecutorMetricsUpdate;
import org.apache.spark.scheduler.SparkListenerExecutorRemoved;
import org.apache.spark.scheduler.SparkListenerExecutorUnblacklisted;
import org.apache.spark.scheduler.SparkListenerInterface;
import org.apache.spark.scheduler.SparkListenerJobEnd;
import org.apache.spark.scheduler.SparkListenerJobStart;
import org.apache.spark.scheduler.SparkListenerNodeBlacklisted;
import org.apache.spark.scheduler.SparkListenerNodeBlacklistedForStage;
import org.apache.spark.scheduler.SparkListenerNodeUnblacklisted;
import org.apache.spark.scheduler.SparkListenerSpeculativeTaskSubmitted;
import org.apache.spark.scheduler.SparkListenerStageCompleted;
import org.apache.spark.scheduler.SparkListenerStageSubmitted;
import org.apache.spark.scheduler.SparkListenerTaskEnd;
import org.apache.spark.scheduler.SparkListenerTaskGettingResult;
import org.apache.spark.scheduler.SparkListenerTaskStart;
import org.apache.spark.scheduler.SparkListenerUnpersistRDD;

public class SparkFirehoseListener
implements SparkListenerInterface {
    public void onEvent(SparkListenerEvent event) {
    }

    @Override
    public final void onStageCompleted(SparkListenerStageCompleted stageCompleted) {
        this.onEvent(stageCompleted);
    }

    @Override
    public final void onStageSubmitted(SparkListenerStageSubmitted stageSubmitted) {
        this.onEvent(stageSubmitted);
    }

    @Override
    public final void onTaskStart(SparkListenerTaskStart taskStart) {
        this.onEvent(taskStart);
    }

    @Override
    public final void onTaskGettingResult(SparkListenerTaskGettingResult taskGettingResult) {
        this.onEvent(taskGettingResult);
    }

    @Override
    public final void onTaskEnd(SparkListenerTaskEnd taskEnd) {
        this.onEvent(taskEnd);
    }

    @Override
    public final void onJobStart(SparkListenerJobStart jobStart) {
        this.onEvent(jobStart);
    }

    @Override
    public final void onJobEnd(SparkListenerJobEnd jobEnd) {
        this.onEvent(jobEnd);
    }

    @Override
    public final void onEnvironmentUpdate(SparkListenerEnvironmentUpdate environmentUpdate) {
        this.onEvent(environmentUpdate);
    }

    @Override
    public final void onBlockManagerAdded(SparkListenerBlockManagerAdded blockManagerAdded) {
        this.onEvent(blockManagerAdded);
    }

    @Override
    public final void onBlockManagerRemoved(SparkListenerBlockManagerRemoved blockManagerRemoved) {
        this.onEvent(blockManagerRemoved);
    }

    @Override
    public final void onUnpersistRDD(SparkListenerUnpersistRDD unpersistRDD) {
        this.onEvent(unpersistRDD);
    }

    @Override
    public final void onApplicationStart(SparkListenerApplicationStart applicationStart) {
        this.onEvent(applicationStart);
    }

    @Override
    public final void onApplicationEnd(SparkListenerApplicationEnd applicationEnd) {
        this.onEvent(applicationEnd);
    }

    @Override
    public final void onExecutorMetricsUpdate(SparkListenerExecutorMetricsUpdate executorMetricsUpdate) {
        this.onEvent(executorMetricsUpdate);
    }

    @Override
    public final void onExecutorAdded(SparkListenerExecutorAdded executorAdded2) {
        this.onEvent(executorAdded2);
    }

    @Override
    public final void onExecutorRemoved(SparkListenerExecutorRemoved executorRemoved2) {
        this.onEvent(executorRemoved2);
    }

    @Override
    public final void onExecutorBlacklisted(SparkListenerExecutorBlacklisted executorBlacklisted) {
        this.onEvent(executorBlacklisted);
    }

    @Override
    public void onExecutorBlacklistedForStage(SparkListenerExecutorBlacklistedForStage executorBlacklistedForStage) {
        this.onEvent(executorBlacklistedForStage);
    }

    @Override
    public void onNodeBlacklistedForStage(SparkListenerNodeBlacklistedForStage nodeBlacklistedForStage) {
        this.onEvent(nodeBlacklistedForStage);
    }

    @Override
    public final void onExecutorUnblacklisted(SparkListenerExecutorUnblacklisted executorUnblacklisted) {
        this.onEvent(executorUnblacklisted);
    }

    @Override
    public final void onNodeBlacklisted(SparkListenerNodeBlacklisted nodeBlacklisted) {
        this.onEvent(nodeBlacklisted);
    }

    @Override
    public final void onNodeUnblacklisted(SparkListenerNodeUnblacklisted nodeUnblacklisted) {
        this.onEvent(nodeUnblacklisted);
    }

    @Override
    public void onBlockUpdated(SparkListenerBlockUpdated blockUpdated) {
        this.onEvent(blockUpdated);
    }

    @Override
    public void onSpeculativeTaskSubmitted(SparkListenerSpeculativeTaskSubmitted speculativeTask) {
        this.onEvent(speculativeTask);
    }

    @Override
    public void onOtherEvent(SparkListenerEvent event) {
        this.onEvent(event);
    }
}

