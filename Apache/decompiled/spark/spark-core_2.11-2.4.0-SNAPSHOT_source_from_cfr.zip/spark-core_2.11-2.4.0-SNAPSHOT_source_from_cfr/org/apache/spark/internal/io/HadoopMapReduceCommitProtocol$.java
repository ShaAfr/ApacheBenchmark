/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Serializable
 */
package org.apache.spark.internal.io;

import scala.Serializable;

public final class HadoopMapReduceCommitProtocol$
implements Serializable {
    public static final HadoopMapReduceCommitProtocol$ MODULE$;

    public static {
        new org.apache.spark.internal.io.HadoopMapReduceCommitProtocol$();
    }

    public boolean $lessinit$greater$default$3() {
        return false;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private HadoopMapReduceCommitProtocol$() {
        MODULE$ = this;
    }
}

