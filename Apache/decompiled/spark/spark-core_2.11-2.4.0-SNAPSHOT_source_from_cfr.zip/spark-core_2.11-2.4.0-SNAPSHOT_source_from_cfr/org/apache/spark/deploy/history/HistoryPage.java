/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 *  org.apache.spark.deploy.history.HistoryPage$
 *  org.apache.spark.deploy.history.HistoryPage$$anonfun
 *  org.apache.spark.deploy.history.HistoryPage$$anonfun$render
 *  scala.Function0
 *  scala.Function1
 *  scala.Option
 *  scala.Option$
 *  scala.Predef$
 *  scala.Serializable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.Iterator
 *  scala.collection.Seq
 *  scala.collection.TraversableLike
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.Iterable$
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.xml.Elem
 *  scala.xml.MetaData
 *  scala.xml.NamespaceBinding
 *  scala.xml.Node
 *  scala.xml.NodeBuffer
 *  scala.xml.NodeSeq$
 *  scala.xml.Null$
 *  scala.xml.Text
 *  scala.xml.TopScope$
 *  scala.xml.UnprefixedAttribute
 */
package org.apache.spark.deploy.history;

import javax.servlet.http.HttpServletRequest;
import org.apache.spark.deploy.history.HistoryPage$;
import org.apache.spark.deploy.history.HistoryServer;
import org.apache.spark.status.api.v1.ApplicationAttemptInfo;
import org.apache.spark.status.api.v1.ApplicationInfo;
import org.apache.spark.ui.UIUtils$;
import org.apache.spark.ui.WebUIPage;
import scala.Function0;
import scala.Function1;
import scala.Option;
import scala.Option$;
import scala.Predef$;
import scala.Serializable;
import scala.collection.GenTraversableOnce;
import scala.collection.Iterator;
import scala.collection.Seq;
import scala.collection.TraversableLike;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.Iterable$;
import scala.collection.immutable.Map;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.xml.Elem;
import scala.xml.MetaData;
import scala.xml.NamespaceBinding;
import scala.xml.Node;
import scala.xml.NodeBuffer;
import scala.xml.NodeSeq$;
import scala.xml.Null$;
import scala.xml.Text;
import scala.xml.TopScope$;
import scala.xml.UnprefixedAttribute;

@ScalaSignature(bytes="\u0006\u0001\u00054Q!\u0001\u0002\u0001\u00051\u00111\u0002S5ti>\u0014\u0018\u0010U1hK*\u00111\u0001B\u0001\bQ&\u001cHo\u001c:z\u0015\t)a!\u0001\u0004eKBdw.\u001f\u0006\u0003\u000f!\tQa\u001d9be.T!!\u0003\u0006\u0002\r\u0005\u0004\u0018m\u00195f\u0015\u0005Y\u0011aA8sON\u0011\u0001!\u0004\t\u0003\u001dEi\u0011a\u0004\u0006\u0003!\u0019\t!!^5\n\u0005Iy!!C,fEVK\u0005+Y4f\u0011!!\u0002A!A!\u0002\u00131\u0012A\u00029be\u0016tGo\u0001\u0001\u0011\u0005]AR\"\u0001\u0002\n\u0005e\u0011!!\u0004%jgR|'/_*feZ,'\u000fC\u0003\u001c\u0001\u0011\u0005A$\u0001\u0004=S:LGO\u0010\u000b\u0003;y\u0001\"a\u0006\u0001\t\u000bQQ\u0002\u0019\u0001\f\t\u000b\u0001\u0002A\u0011A\u0011\u0002\rI,g\u000eZ3s)\t\u0011c\u0007E\u0002$[Ar!\u0001\n\u0016\u000f\u0005\u0015BS\"\u0001\u0014\u000b\u0005\u001d*\u0012A\u0002\u001fs_>$h(C\u0001*\u0003\u0015\u00198-\u00197b\u0013\tYC&A\u0004qC\u000e\\\u0017mZ3\u000b\u0003%J!AL\u0018\u0003\u0007M+\u0017O\u0003\u0002,YA\u0011\u0011\u0007N\u0007\u0002e)\u00111\u0007L\u0001\u0004q6d\u0017BA\u001b3\u0005\u0011qu\u000eZ3\t\u000b]z\u0002\u0019\u0001\u001d\u0002\u000fI,\u0017/^3tiB\u0011\u0011\bQ\u0007\u0002u)\u00111\bP\u0001\u0005QR$\bO\u0003\u0002>}\u000591/\u001a:wY\u0016$(\"A \u0002\u000b)\fg/\u0019=\n\u0005\u0005S$A\u0005%uiB\u001cVM\u001d<mKR\u0014V-];fgRDQa\u0011\u0001\u0005\n\u0011\u000bA\"\\1lKB\u000bw-\u001a'j].$\"!R'\u0011\u0005\u0019SeBA$I\u001b\u0005a\u0013BA%-\u0003\u0019\u0001&/\u001a3fM&\u00111\n\u0014\u0002\u0007'R\u0014\u0018N\\4\u000b\u0005%c\u0003\"\u0002(C\u0001\u0004y\u0015AD:i_^LenY8na2,G/\u001a\t\u0003\u000fBK!!\u0015\u0017\u0003\u000f\t{w\u000e\\3b]\")1\u000b\u0001C\u0005)\u00061\u0012n]!qa2L7-\u0019;j_:\u001cu.\u001c9mKR,G\r\u0006\u0002P+\")aK\u0015a\u0001/\u00069\u0011\r\u001d9J]\u001a|\u0007C\u0001-`\u001b\u0005I&B\u0001.\\\u0003\t1\u0018G\u0003\u0002];\u0006\u0019\u0011\r]5\u000b\u0005y3\u0011AB:uCR,8/\u0003\u0002a3\ny\u0011\t\u001d9mS\u000e\fG/[8o\u0013:4w\u000e")
public class HistoryPage
extends WebUIPage {
    private final HistoryServer parent;

    @Override
    public Seq<Node> render(HttpServletRequest request) {
        BoxedUnit boxedUnit;
        BoxedUnit boxedUnit2;
        Object object;
        boolean requestedIncomplete = new StringOps(Predef$.MODULE$.augmentString((String)Option$.MODULE$.apply((Object)UIUtils$.MODULE$.stripXSS(request.getParameter("showIncomplete"))).getOrElse((Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return "false";
            }
        }))).toBoolean();
        int allAppsSize = this.parent.getApplicationList().count((Function1)new Serializable(this, requestedIncomplete){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ HistoryPage $outer;
            private final boolean requestedIncomplete$1;

            public final boolean apply(ApplicationInfo x$1) {
                return this.$outer.org$apache$spark$deploy$history$HistoryPage$$isApplicationCompleted(x$1) != this.requestedIncomplete$1;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.requestedIncomplete$1 = requestedIncomplete$1;
            }
        });
        int eventLogsUnderProcessCount = this.parent.getEventLogsUnderProcess();
        long lastUpdatedTime = this.parent.getLastUpdatedTime();
        Map<String, String> providerConfig = this.parent.getProviderConfig();
        NodeBuffer $buf = new NodeBuffer();
        Null$ $md = Null$.MODULE$;
        $md = new UnprefixedAttribute("src", UIUtils$.MODULE$.prependBaseUri("/static/historypage-common.js", UIUtils$.MODULE$.prependBaseUri$default$2()), (MetaData)$md);
        $buf.$amp$plus((Object)new Elem(null, "script", (MetaData)$md, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
        NodeBuffer $buf2 = new NodeBuffer();
        $buf2.$amp$plus((Object)new Text("\n          "));
        Null$ $md2 = Null$.MODULE$;
        $md2 = new UnprefixedAttribute("class", (Seq)new Text("container-fluid"), (MetaData)$md2);
        NodeBuffer $buf3 = new NodeBuffer();
        $buf3.$amp$plus((Object)new Text("\n            "));
        Null$ $md3 = Null$.MODULE$;
        $md3 = new UnprefixedAttribute("class", (Seq)new Text("unstyled"), (MetaData)$md3);
        NodeBuffer $buf4 = new NodeBuffer();
        $buf4.$amp$plus((Object)new Text("\n              "));
        $buf4.$amp$plus(providerConfig.map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final Elem apply(scala.Tuple2<String, String> x0$1) {
                scala.Tuple2<String, String> tuple2 = x0$1;
                if (tuple2 != null) {
                    String k = (String)tuple2._1();
                    String v = (String)tuple2._2();
                    NodeBuffer $buf = new NodeBuffer();
                    NodeBuffer $buf2 = new NodeBuffer();
                    $buf2.$amp$plus((Object)k);
                    $buf2.$amp$plus((Object)new Text(":"));
                    $buf.$amp$plus((Object)new Elem(null, "strong", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
                    $buf.$amp$plus((Object)new Text(" "));
                    $buf.$amp$plus((Object)v);
                    Elem elem = new Elem(null, "li", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf);
                    return elem;
                }
                throw new scala.MatchError(tuple2);
            }
        }, Iterable$.MODULE$.canBuildFrom()));
        $buf4.$amp$plus((Object)new Text("\n            "));
        $buf3.$amp$plus((Object)new Elem(null, "ul", (MetaData)$md3, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf4));
        $buf3.$amp$plus((Object)new Text("\n            "));
        if (eventLogsUnderProcessCount > 0) {
            Elem elem;
            boxedUnit2 = elem;
            NodeBuffer $buf5 = new NodeBuffer();
            $buf5.$amp$plus((Object)new Text("There are "));
            $buf5.$amp$plus((Object)BoxesRunTime.boxToInteger((int)eventLogsUnderProcessCount));
            $buf5.$amp$plus((Object)new Text(" event log(s) currently being\n                processed which may result in additional applications getting listed on this page.\n                Refresh the page to view updates. "));
            elem = new Elem(null, "p", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf5);
        } else {
            boxedUnit2 = BoxedUnit.UNIT;
        }
        $buf3.$amp$plus((Object)boxedUnit2);
        $buf3.$amp$plus((Object)new Text("\n\n            "));
        if (lastUpdatedTime > 0L) {
            Elem elem;
            boxedUnit = elem;
            NodeBuffer $buf6 = new NodeBuffer();
            $buf6.$amp$plus((Object)new Text("Last updated: "));
            Null$ $md4 = Null$.MODULE$;
            $md4 = new UnprefixedAttribute("id", (Seq)new Text("last-updated"), (MetaData)$md4);
            NodeBuffer $buf7 = new NodeBuffer();
            $buf7.$amp$plus((Object)BoxesRunTime.boxToLong((long)lastUpdatedTime));
            $buf6.$amp$plus((Object)new Elem(null, "span", (MetaData)$md4, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf7));
            elem = new Elem(null, "p", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf6);
        } else {
            boxedUnit = BoxedUnit.UNIT;
        }
        $buf3.$amp$plus((Object)boxedUnit);
        $buf3.$amp$plus((Object)new Text("\n\n            "));
        NodeBuffer $buf8 = new NodeBuffer();
        $buf8.$amp$plus((Object)new Text("Client local time zone: "));
        Null$ $md5 = Null$.MODULE$;
        $md5 = new UnprefixedAttribute("id", (Seq)new Text("time-zone"), (MetaData)$md5);
        $buf8.$amp$plus((Object)new Elem(null, "span", (MetaData)$md5, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])));
        $buf3.$amp$plus((Object)new Elem(null, "p", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf8));
        $buf3.$amp$plus((Object)new Text("\n\n            "));
        if (allAppsSize > 0) {
            Null$ $md6 = Null$.MODULE$;
            $md6 = new UnprefixedAttribute("src", UIUtils$.MODULE$.prependBaseUri("/static/dataTables.rowsGroup.js", UIUtils$.MODULE$.prependBaseUri$default$2()), (MetaData)$md6);
            Null$ $md7 = Null$.MODULE$;
            $md7 = new UnprefixedAttribute("class", (Seq)new Text("row-fluid"), (MetaData)$md7);
            $md7 = new UnprefixedAttribute("id", (Seq)new Text("history-summary"), (MetaData)$md7);
            Null$ $md8 = Null$.MODULE$;
            $md8 = new UnprefixedAttribute("src", UIUtils$.MODULE$.prependBaseUri("/static/utils.js", UIUtils$.MODULE$.prependBaseUri$default$2()), (MetaData)$md8);
            Null$ $md9 = Null$.MODULE$;
            $md9 = new UnprefixedAttribute("src", UIUtils$.MODULE$.prependBaseUri("/static/historypage.js", UIUtils$.MODULE$.prependBaseUri$default$2()), (MetaData)$md9);
            NodeBuffer $buf9 = new NodeBuffer();
            $buf9.$amp$plus((Object)new Text("setAppLimit("));
            $buf9.$amp$plus((Object)BoxesRunTime.boxToInteger((int)this.parent.maxApplications()));
            $buf9.$amp$plus((Object)new Text(")"));
            object = ((TraversableLike)((TraversableLike)((TraversableLike)new Elem(null, "script", (MetaData)$md6, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])).$plus$plus((GenTraversableOnce)new Elem(null, "div", (MetaData)$md7, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])), NodeSeq$.MODULE$.canBuildFrom())).$plus$plus((GenTraversableOnce)new Elem(null, "script", (MetaData)$md8, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])), NodeSeq$.MODULE$.canBuildFrom())).$plus$plus((GenTraversableOnce)new Elem(null, "script", (MetaData)$md9, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)Predef$.MODULE$.wrapRefArray((Object[])new Node[0])), NodeSeq$.MODULE$.canBuildFrom())).$plus$plus((GenTraversableOnce)new Elem(null, "script", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf9), NodeSeq$.MODULE$.canBuildFrom());
        } else if (requestedIncomplete) {
            Elem elem;
            object = elem;
            NodeBuffer $buf10 = new NodeBuffer();
            $buf10.$amp$plus((Object)new Text("No incomplete applications found!"));
            elem = new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf10);
        } else if (eventLogsUnderProcessCount > 0) {
            Elem elem;
            object = elem;
            NodeBuffer $buf11 = new NodeBuffer();
            $buf11.$amp$plus((Object)new Text("No completed applications found!"));
            elem = new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf11);
        } else {
            NodeBuffer $buf12 = new NodeBuffer();
            $buf12.$amp$plus((Object)new Text("No completed applications found!"));
            object = new Elem(null, "h4", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf12).$plus$plus(this.parent.emptyListingHtml(), NodeSeq$.MODULE$.canBuildFrom());
        }
        $buf3.$amp$plus(object);
        $buf3.$amp$plus((Object)new Text("\n\n            "));
        Null$ $md10 = Null$.MODULE$;
        $md10 = new UnprefixedAttribute("href", this.makePageLink(!requestedIncomplete), (MetaData)$md10);
        NodeBuffer $buf13 = new NodeBuffer();
        $buf13.$amp$plus((Object)new Text("\n              "));
        $buf13.$amp$plus((Object)(requestedIncomplete ? "Back to completed applications" : "Show incomplete applications"));
        $buf13.$amp$plus((Object)new Text("\n            "));
        $buf3.$amp$plus((Object)new Elem(null, "a", (MetaData)$md10, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf13));
        $buf3.$amp$plus((Object)new Text("\n          "));
        $buf2.$amp$plus((Object)new Elem(null, "div", (MetaData)$md2, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf3));
        $buf2.$amp$plus((Object)new Text("\n      "));
        $buf.$amp$plus((Object)new Elem(null, "div", (MetaData)Null$.MODULE$, (NamespaceBinding)TopScope$.MODULE$, false, (Seq)$buf2));
        NodeBuffer content = $buf;
        return UIUtils$.MODULE$.basicSparkPage((Function0<Seq<Node>>)new Serializable(this, content){
            public static final long serialVersionUID = 0L;
            private final NodeBuffer content$1;

            public final NodeBuffer apply() {
                return this.content$1;
            }
            {
                this.content$1 = content$1;
            }
        }, "History Server", true);
    }

    private String makePageLink(boolean showIncomplete) {
        return UIUtils$.MODULE$.prependBaseUri(new StringBuilder().append((Object)"/?showIncomplete=").append((Object)BoxesRunTime.boxToBoolean((boolean)showIncomplete)).toString(), UIUtils$.MODULE$.prependBaseUri$default$2());
    }

    public boolean org$apache$spark$deploy$history$HistoryPage$$isApplicationCompleted(ApplicationInfo appInfo) {
        return appInfo.attempts().nonEmpty() && ((ApplicationAttemptInfo)appInfo.attempts().head()).completed();
    }

    public HistoryPage(HistoryServer parent) {
        this.parent = parent;
        super("");
    }
}

