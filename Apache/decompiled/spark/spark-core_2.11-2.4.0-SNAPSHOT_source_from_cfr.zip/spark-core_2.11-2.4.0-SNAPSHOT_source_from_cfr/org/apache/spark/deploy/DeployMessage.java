/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Serializable
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.deploy;

import scala.Serializable;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001\u00013\u0001\"\u0001\u0002\u0011\u0002G\u0005\"A\u0003\u0002\u000e\t\u0016\u0004Hn\\=NKN\u001c\u0018mZ3\u000b\u0005\r!\u0011A\u00023fa2|\u0017P\u0003\u0002\u0006\r\u0005)1\u000f]1sW*\u0011q\u0001C\u0001\u0007CB\f7\r[3\u000b\u0003%\t1a\u001c:h'\r\u00011\"\u0005\t\u0003\u0019=i\u0011!\u0004\u0006\u0002\u001d\u0005)1oY1mC&\u0011\u0001#\u0004\u0002\u0007\u0003:L(+\u001a4\u0011\u00051\u0011\u0012BA\n\u000e\u00051\u0019VM]5bY&T\u0018M\u00197f\u0007\u0001IS\u0003\u0001\f\u001b9y\u0001#\u0005\n\u0014)U1r\u0003G\r\u001b7qibd(\u0003\u0002\u00181\t\u0011BI]5wKJ\u001cF/\u0019;f\u0007\"\fgnZ3e\u0015\tI\"!\u0001\bEKBdw._'fgN\fw-Z:\n\u0005mA\"\u0001F#yK\u000e,Ho\u001c:Ti\u0006$Xm\u00115b]\u001e,G-\u0003\u0002\u001e1\tI\u0001*Z1si\n,\u0017\r^\u0005\u0003?a\u0011!bS5mY\u0012\u0013\u0018N^3s\u0013\t\t\u0003D\u0001\nLS2dGI]5wKJ\u0014Vm\u001d9p]N,\u0017BA\u0012\u0019\u00051Y\u0015\u000e\u001c7Fq\u0016\u001cW\u000f^8s\u0013\t)\u0003D\u0001\u0007MCVt7\r\u001b#sSZ,'/\u0003\u0002(1\tqA*Y;oG\",\u00050Z2vi>\u0014(BA\u0015\u0019\u0003=i\u0015m\u001d;fe&s7\u000b^1oI\nL\u0018BA\u0016\u0019\u0005=\u0011VmY8o]\u0016\u001cGoV8sW\u0016\u0014\u0018BA\u0017\u0019\u0005M\u0011VmZ5ti\u0016\u0014\u0018\t\u001d9mS\u000e\fG/[8o\u0013\ty\u0003D\u0001\bSK\u001eL7\u000f^3s/>\u00148.\u001a:\n\u0005EB\"\u0001\u0006*fO&\u001cH/\u001a:X_J\\WM\u001d$bS2,G-\u0003\u000241\t)\"+Z4jgR,'/\u001a3BaBd\u0017nY1uS>t\u0017BA\u001b\u0019\u0005A\u0011VmZ5ti\u0016\u0014X\rZ,pe.,'/\u0003\u000281\t\u0019\"+Z9vKN$HI]5wKJ\u001cF/\u0019;vg&\u0011\u0011\b\u0007\u0002\u0012%\u0016\fX/Z:u\u0017&dG\u000e\u0012:jm\u0016\u0014\u0018BA\u001e\u0019\u0005M\u0011V-];fgR\u001cVOY7ji\u0012\u0013\u0018N^3s\u0013\ti\u0004D\u0001\u000bTk\nl\u0017\u000e\u001e#sSZ,'OU3ta>t7/Z\u0005\u0003a\u0011\u0011cV8sW\u0016\u0014H*\u0019;fgR\u001cF/\u0019;f\u0001")
public interface DeployMessage
extends Serializable {
}

