/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerTaskGettingResult;
import org.apache.spark.scheduler.TaskInfo;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class SparkListenerTaskGettingResult$
extends AbstractFunction1<TaskInfo, SparkListenerTaskGettingResult>
implements Serializable {
    public static final SparkListenerTaskGettingResult$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerTaskGettingResult$();
    }

    public final String toString() {
        return "SparkListenerTaskGettingResult";
    }

    public SparkListenerTaskGettingResult apply(TaskInfo taskInfo) {
        return new SparkListenerTaskGettingResult(taskInfo);
    }

    public Option<TaskInfo> unapply(SparkListenerTaskGettingResult x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.taskInfo());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerTaskGettingResult$() {
        MODULE$ = this;
    }
}

