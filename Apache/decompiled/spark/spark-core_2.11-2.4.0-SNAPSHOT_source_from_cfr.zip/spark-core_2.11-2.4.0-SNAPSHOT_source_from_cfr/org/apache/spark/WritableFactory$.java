/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.hadoop.io.BooleanWritable
 *  org.apache.hadoop.io.BytesWritable
 *  org.apache.hadoop.io.DoubleWritable
 *  org.apache.hadoop.io.FloatWritable
 *  org.apache.hadoop.io.IntWritable
 *  org.apache.hadoop.io.LongWritable
 *  org.apache.hadoop.io.Text
 *  org.apache.hadoop.io.Writable
 *  org.apache.spark.WritableFactory$$anonfun
 *  org.apache.spark.WritableFactory$$anonfun$booleanWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$bytesWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$doubleWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$floatWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$intWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$longWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$simpleWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$stringWritableFactory
 *  org.apache.spark.WritableFactory$$anonfun$writableWritableFactory
 *  scala.Function1
 *  scala.Predef$
 *  scala.Serializable
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.ScalaRunTime$
 */
package org.apache.spark;

import org.apache.hadoop.io.BooleanWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.spark.WritableFactory;
import org.apache.spark.WritableFactory$;
import scala.Function1;
import scala.Predef$;
import scala.Serializable;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.ScalaRunTime$;

public final class WritableFactory$
implements Serializable {
    public static final WritableFactory$ MODULE$;

    public static {
        new org.apache.spark.WritableFactory$();
    }

    public <T, W extends Writable> WritableFactory<T> simpleWritableFactory(Function1<T, W> convert2, ClassTag<T> evidence$22, ClassTag<W> evidence$23) {
        Class writableClass = ((ClassTag)Predef$.MODULE$.implicitly(evidence$23)).runtimeClass();
        return new WritableFactory<T>((Function1<ClassTag<T>, Class<Writable>>)new Serializable(writableClass){
            public static final long serialVersionUID = 0L;
            private final Class writableClass$1;

            public final Class<W> apply(ClassTag<T> x$53) {
                return this.writableClass$1;
            }
            {
                this.writableClass$1 = writableClass$1;
            }
        }, (Function1<T, Writable>)convert2);
    }

    public WritableFactory<Object> intWritableFactory() {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final IntWritable apply(int x$54) {
                return new IntWritable(x$54);
            }
        }, (ClassTag<T>)ClassTag$.MODULE$.Int(), (ClassTag<W>)ClassTag$.MODULE$.apply(IntWritable.class));
    }

    public WritableFactory<Object> longWritableFactory() {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final LongWritable apply(long x$55) {
                return new LongWritable(x$55);
            }
        }, (ClassTag<T>)ClassTag$.MODULE$.Long(), (ClassTag<W>)ClassTag$.MODULE$.apply(LongWritable.class));
    }

    public WritableFactory<Object> floatWritableFactory() {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final FloatWritable apply(float x$56) {
                return new FloatWritable(x$56);
            }
        }, (ClassTag<T>)ClassTag$.MODULE$.Float(), (ClassTag<W>)ClassTag$.MODULE$.apply(FloatWritable.class));
    }

    public WritableFactory<Object> doubleWritableFactory() {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final DoubleWritable apply(double x$57) {
                return new DoubleWritable(x$57);
            }
        }, (ClassTag<T>)ClassTag$.MODULE$.Double(), (ClassTag<W>)ClassTag$.MODULE$.apply(DoubleWritable.class));
    }

    public WritableFactory<Object> booleanWritableFactory() {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final BooleanWritable apply(boolean x$58) {
                return new BooleanWritable(x$58);
            }
        }, (ClassTag<T>)ClassTag$.MODULE$.Boolean(), (ClassTag<W>)ClassTag$.MODULE$.apply(BooleanWritable.class));
    }

    public WritableFactory<byte[]> bytesWritableFactory() {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final BytesWritable apply(byte[] x$59) {
                return new BytesWritable(x$59);
            }
        }, (ClassTag<T>)ClassTag$.MODULE$.apply(ScalaRunTime$.MODULE$.arrayClass(Byte.TYPE)), (ClassTag<W>)ClassTag$.MODULE$.apply(BytesWritable.class));
    }

    public WritableFactory<String> stringWritableFactory() {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final Text apply(String x$60) {
                return new Text(x$60);
            }
        }, (ClassTag<T>)ClassTag$.MODULE$.apply(String.class), (ClassTag<W>)ClassTag$.MODULE$.apply(Text.class));
    }

    public <T extends Writable> WritableFactory<T> writableWritableFactory(ClassTag<T> evidence$24) {
        return this.simpleWritableFactory((Function1<T, W>)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final T apply(T w) {
                return w;
            }
        }, evidence$24, (ClassTag<W>)evidence$24);
    }

    private Object readResolve() {
        return MODULE$;
    }

    private WritableFactory$() {
        MODULE$ = this;
    }
}

