/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark;

import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001U1\u0001\"\u0001\u0002\u0011\u0002G\u0005\"\u0001\u0003\u0002\u0018\u001b\u0006\u0004x*\u001e;qkR$&/Y2lKJlUm]:bO\u0016T!a\u0001\u0003\u0002\u000bM\u0004\u0018M]6\u000b\u0005\u00151\u0011AB1qC\u000eDWMC\u0001\b\u0003\ry'oZ\n\u0003\u0001%\u0001\"AC\u0007\u000e\u0003-Q\u0011\u0001D\u0001\u0006g\u000e\fG.Y\u0005\u0003\u001d-\u0011a!\u00118z%\u001647\u0001A\u0015\u0004\u0001E\u0019\u0012B\u0001\n\u0003\u0005Q9U\r^'ba>+H\u000f];u'R\fG/^:fg*\u0011ACA\u0001\u0015'R|\u0007/T1q\u001fV$\b/\u001e;Ue\u0006\u001c7.\u001a:")
public interface MapOutputTrackerMessage {
}

