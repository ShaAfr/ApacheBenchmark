/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.util.kvstore.KVIndex
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple5
 *  scala.runtime.AbstractFunction5
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.deploy.history;

import org.apache.spark.deploy.history.ApplicationStoreInfo;
import org.apache.spark.util.kvstore.KVIndex;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple5;
import scala.runtime.AbstractFunction5;
import scala.runtime.BoxesRunTime;

public final class ApplicationStoreInfo$
extends AbstractFunction5<String, Object, String, Option<String>, Object, ApplicationStoreInfo>
implements Serializable {
    public static final ApplicationStoreInfo$ MODULE$;

    public static {
        new org.apache.spark.deploy.history.ApplicationStoreInfo$();
    }

    public final String toString() {
        return "ApplicationStoreInfo";
    }

    public ApplicationStoreInfo apply(@KVIndex String path, @KVIndex(value="lastAccess") long lastAccess, String appId, Option<String> attemptId, long size) {
        return new ApplicationStoreInfo(path, lastAccess, appId, attemptId, size);
    }

    public Option<Tuple5<String, Object, String, Option<String>, Object>> unapply(ApplicationStoreInfo x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple5((Object)x$0.path(), (Object)BoxesRunTime.boxToLong((long)x$0.lastAccess()), (Object)x$0.appId(), x$0.attemptId(), (Object)BoxesRunTime.boxToLong((long)x$0.size())));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private ApplicationStoreInfo$() {
        MODULE$ = this;
    }
}

