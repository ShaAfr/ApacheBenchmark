/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Serializable
 */
package org.apache.spark;

import org.apache.spark.executor.TaskMetrics;
import org.apache.spark.executor.TaskMetrics$;
import scala.Serializable;

public final class TaskContextImpl$
implements Serializable {
    public static final TaskContextImpl$ MODULE$;

    public static {
        new org.apache.spark.TaskContextImpl$();
    }

    public TaskMetrics $lessinit$greater$default$9() {
        return TaskMetrics$.MODULE$.empty();
    }

    private Object readResolve() {
        return MODULE$;
    }

    private TaskContextImpl$() {
        MODULE$ = this;
    }
}

