/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerApplicationEnd;
import org.apache.spark.scheduler.SparkListenerApplicationStart;
import org.apache.spark.scheduler.SparkListenerBlockManagerAdded;
import org.apache.spark.scheduler.SparkListenerBlockManagerRemoved;
import org.apache.spark.scheduler.SparkListenerBlockUpdated;
import org.apache.spark.scheduler.SparkListenerEnvironmentUpdate;
import org.apache.spark.scheduler.SparkListenerEvent;
import org.apache.spark.scheduler.SparkListenerExecutorAdded;
import org.apache.spark.scheduler.SparkListenerExecutorBlacklisted;
import org.apache.spark.scheduler.SparkListenerExecutorBlacklistedForStage;
import org.apache.spark.scheduler.SparkListenerExecutorMetricsUpdate;
import org.apache.spark.scheduler.SparkListenerExecutorRemoved;
import org.apache.spark.scheduler.SparkListenerExecutorUnblacklisted;
import org.apache.spark.scheduler.SparkListenerJobEnd;
import org.apache.spark.scheduler.SparkListenerJobStart;
import org.apache.spark.scheduler.SparkListenerNodeBlacklisted;
import org.apache.spark.scheduler.SparkListenerNodeBlacklistedForStage;
import org.apache.spark.scheduler.SparkListenerNodeUnblacklisted;
import org.apache.spark.scheduler.SparkListenerSpeculativeTaskSubmitted;
import org.apache.spark.scheduler.SparkListenerStageCompleted;
import org.apache.spark.scheduler.SparkListenerStageSubmitted;
import org.apache.spark.scheduler.SparkListenerTaskEnd;
import org.apache.spark.scheduler.SparkListenerTaskGettingResult;
import org.apache.spark.scheduler.SparkListenerTaskStart;
import org.apache.spark.scheduler.SparkListenerUnpersistRDD;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001\u0005uf\u0001C\u0001\u0003!\u0003\r\n\u0001\u0002\u0006\u0003-M\u0003\u0018M]6MSN$XM\\3s\u0013:$XM\u001d4bG\u0016T!a\u0001\u0003\u0002\u0013M\u001c\u0007.\u001a3vY\u0016\u0014(BA\u0003\u0007\u0003\u0015\u0019\b/\u0019:l\u0015\t9\u0001\"\u0001\u0004ba\u0006\u001c\u0007.\u001a\u0006\u0002\u0013\u0005\u0019qN]4\u0014\u0005\u0001Y\u0001C\u0001\u0007\u0010\u001b\u0005i!\"\u0001\b\u0002\u000bM\u001c\u0017\r\\1\n\u0005Ai!AB!osJ+g\rC\u0003\u0013\u0001\u0019\u0005A#\u0001\tp]N#\u0018mZ3D_6\u0004H.\u001a;fI\u000e\u0001ACA\u000b\u0019!\taa#\u0003\u0002\u0018\u001b\t!QK\\5u\u0011\u0015I\u0012\u00031\u0001\u001b\u00039\u0019H/Y4f\u0007>l\u0007\u000f\\3uK\u0012\u0004\"a\u0007\u000f\u000e\u0003\tI!!\b\u0002\u00037M\u0003\u0018M]6MSN$XM\\3s'R\fw-Z\"p[BdW\r^3e\u0011\u0015y\u0002A\"\u0001!\u0003Aygn\u0015;bO\u0016\u001cVOY7jiR,G\r\u0006\u0002\u0016C!)!E\ba\u0001G\u0005q1\u000f^1hKN+(-\\5ui\u0016$\u0007CA\u000e%\u0013\t)#AA\u000eTa\u0006\u00148\u000eT5ti\u0016tWM]*uC\u001e,7+\u001e2nSR$X\r\u001a\u0005\u0006O\u00011\t\u0001K\u0001\f_:$\u0016m]6Ti\u0006\u0014H\u000f\u0006\u0002\u0016S!)!F\na\u0001W\u0005IA/Y:l'R\f'\u000f\u001e\t\u000371J!!\f\u0002\u0003-M\u0003\u0018M]6MSN$XM\\3s)\u0006\u001c8n\u0015;beRDQa\f\u0001\u0007\u0002A\n1c\u001c8UCN\\w)\u001a;uS:<'+Z:vYR$\"!F\u0019\t\u000bIr\u0003\u0019A\u001a\u0002#Q\f7o[$fiRLgn\u001a*fgVdG\u000f\u0005\u0002\u001ci%\u0011QG\u0001\u0002\u001f'B\f'o\u001b'jgR,g.\u001a:UCN\\w)\u001a;uS:<'+Z:vYRDQa\u000e\u0001\u0007\u0002a\n\u0011b\u001c8UCN\\WI\u001c3\u0015\u0005UI\u0004\"\u0002\u001e7\u0001\u0004Y\u0014a\u0002;bg.,e\u000e\u001a\t\u00037qJ!!\u0010\u0002\u0003)M\u0003\u0018M]6MSN$XM\\3s)\u0006\u001c8.\u00128e\u0011\u0015y\u0004A\"\u0001A\u0003)ygNS8c'R\f'\u000f\u001e\u000b\u0003+\u0005CQA\u0011 A\u0002\r\u000b\u0001B[8c'R\f'\u000f\u001e\t\u00037\u0011K!!\u0012\u0002\u0003+M\u0003\u0018M]6MSN$XM\\3s\u0015>\u00147\u000b^1si\")q\t\u0001D\u0001\u0011\u0006AqN\u001c&pE\u0016sG\r\u0006\u0002\u0016\u0013\")!J\u0012a\u0001\u0017\u00061!n\u001c2F]\u0012\u0004\"a\u0007'\n\u00055\u0013!aE*qCJ\\G*[:uK:,'OS8c\u000b:$\u0007\"B(\u0001\r\u0003\u0001\u0016aE8o\u000b:4\u0018N]8o[\u0016tG/\u00169eCR,GCA\u000bR\u0011\u0015\u0011f\n1\u0001T\u0003E)gN^5s_:lWM\u001c;Va\u0012\fG/\u001a\t\u00037QK!!\u0016\u0002\u0003=M\u0003\u0018M]6MSN$XM\\3s\u000b:4\u0018N]8o[\u0016tG/\u00169eCR,\u0007\"B,\u0001\r\u0003A\u0016aE8o\u00052|7m['b]\u0006<WM]!eI\u0016$GCA\u000bZ\u0011\u0015Qf\u000b1\u0001\\\u0003E\u0011Gn\\2l\u001b\u0006t\u0017mZ3s\u0003\u0012$W\r\u001a\t\u00037qK!!\u0018\u0002\u0003=M\u0003\u0018M]6MSN$XM\\3s\u00052|7m['b]\u0006<WM]!eI\u0016$\u0007\"B0\u0001\r\u0003\u0001\u0017!F8o\u00052|7m['b]\u0006<WM\u001d*f[>4X\r\u001a\u000b\u0003+\u0005DQA\u00190A\u0002\r\f1C\u00197pG.l\u0015M\\1hKJ\u0014V-\\8wK\u0012\u0004\"a\u00073\n\u0005\u0015\u0014!\u0001I*qCJ\\G*[:uK:,'O\u00117pG.l\u0015M\\1hKJ\u0014V-\\8wK\u0012DQa\u001a\u0001\u0007\u0002!\fab\u001c8V]B,'o]5tiJ#E\t\u0006\u0002\u0016S\")!N\u001aa\u0001W\u0006aQO\u001c9feNL7\u000f\u001e*E\tB\u00111\u0004\\\u0005\u0003[\n\u0011\u0011d\u00159be.d\u0015n\u001d;f]\u0016\u0014XK\u001c9feNL7\u000f\u001e*E\t\")q\u000e\u0001D\u0001a\u0006\u0011rN\\!qa2L7-\u0019;j_:\u001cF/\u0019:u)\t)\u0012\u000fC\u0003s]\u0002\u00071/\u0001\tbaBd\u0017nY1uS>t7\u000b^1siB\u00111\u0004^\u0005\u0003k\n\u0011Qd\u00159be.d\u0015n\u001d;f]\u0016\u0014\u0018\t\u001d9mS\u000e\fG/[8o'R\f'\u000f\u001e\u0005\u0006o\u00021\t\u0001_\u0001\u0011_:\f\u0005\u000f\u001d7jG\u0006$\u0018n\u001c8F]\u0012$\"!F=\t\u000bi4\b\u0019A>\u0002\u001d\u0005\u0004\b\u000f\\5dCRLwN\\#oIB\u00111\u0004`\u0005\u0003{\n\u00111d\u00159be.d\u0015n\u001d;f]\u0016\u0014\u0018\t\u001d9mS\u000e\fG/[8o\u000b:$\u0007BB@\u0001\r\u0003\t\t!A\fp]\u0016CXmY;u_JlU\r\u001e:jGN,\u0006\u000fZ1uKR\u0019Q#a\u0001\t\u000f\u0005\u0015a\u00101\u0001\u0002\b\u0005)R\r_3dkR|'/T3ue&\u001c7/\u00169eCR,\u0007cA\u000e\u0002\n%\u0019\u00111\u0002\u0002\u0003EM\u0003\u0018M]6MSN$XM\\3s\u000bb,7-\u001e;pe6+GO]5dgV\u0003H-\u0019;f\u0011\u001d\ty\u0001\u0001D\u0001\u0003#\tqb\u001c8Fq\u0016\u001cW\u000f^8s\u0003\u0012$W\r\u001a\u000b\u0004+\u0005M\u0001\u0002CA\u000b\u0003\u001b\u0001\r!a\u0006\u0002\u001b\u0015DXmY;u_J\fE\rZ3e!\rY\u0012\u0011D\u0005\u0004\u00037\u0011!AG*qCJ\\G*[:uK:,'/\u0012=fGV$xN]!eI\u0016$\u0007bBA\u0010\u0001\u0019\u0005\u0011\u0011E\u0001\u0012_:,\u00050Z2vi>\u0014(+Z7pm\u0016$GcA\u000b\u0002$!A\u0011QEA\u000f\u0001\u0004\t9#A\bfq\u0016\u001cW\u000f^8s%\u0016lwN^3e!\rY\u0012\u0011F\u0005\u0004\u0003W\u0011!\u0001H*qCJ\\G*[:uK:,'/\u0012=fGV$xN\u001d*f[>4X\r\u001a\u0005\b\u0003_\u0001a\u0011AA\u0019\u0003Uyg.\u0012=fGV$xN\u001d\"mC\u000e\\G.[:uK\u0012$2!FA\u001a\u0011!\t)$!\fA\u0002\u0005]\u0012aE3yK\u000e,Ho\u001c:CY\u0006\u001c7\u000e\\5ti\u0016$\u0007cA\u000e\u0002:%\u0019\u00111\b\u0002\u0003AM\u0003\u0018M]6MSN$XM\\3s\u000bb,7-\u001e;pe\nc\u0017mY6mSN$X\r\u001a\u0005\b\u0003\u0001a\u0011AA!\u0003uyg.\u0012=fGV$xN\u001d\"mC\u000e\\G.[:uK\u00124uN]*uC\u001e,GcA\u000b\u0002D!A\u0011QIA\u001f\u0001\u0004\t9%A\u000efq\u0016\u001cW\u000f^8s\u00052\f7m\u001b7jgR,GMR8s'R\fw-\u001a\t\u00047\u0005%\u0013bAA&\u0005\tA3\u000b]1sW2K7\u000f^3oKJ,\u00050Z2vi>\u0014(\t\\1dW2L7\u000f^3e\r>\u00148\u000b^1hK\"9\u0011q\n\u0001\u0007\u0002\u0005E\u0013!G8o\u001d>$WM\u00117bG.d\u0017n\u001d;fI\u001a{'o\u0015;bO\u0016$2!FA*\u0011!\t)&!\u0014A\u0002\u0005]\u0013a\u00068pI\u0016\u0014E.Y2lY&\u001cH/\u001a3G_J\u001cF/Y4f!\rY\u0012\u0011L\u0005\u0004\u00037\u0012!\u0001J*qCJ\\G*[:uK:,'OT8eK\nc\u0017mY6mSN$X\r\u001a$peN#\u0018mZ3\t\u000f\u0005}\u0003A\"\u0001\u0002b\u00059rN\\#yK\u000e,Ho\u001c:V]\nd\u0017mY6mSN$X\r\u001a\u000b\u0004+\u0005\r\u0004\u0002CA3\u0003;\u0002\r!a\u001a\u0002+\u0015DXmY;u_J,fN\u00197bG.d\u0017n\u001d;fIB\u00191$!\u001b\n\u0007\u0005-$A\u0001\u0012Ta\u0006\u00148\u000eT5ti\u0016tWM]#yK\u000e,Ho\u001c:V]\nd\u0017mY6mSN$X\r\u001a\u0005\b\u0003_\u0002a\u0011AA9\u0003EygNT8eK\nc\u0017mY6mSN$X\r\u001a\u000b\u0004+\u0005M\u0004\u0002CA;\u0003[\u0002\r!a\u001e\u0002\u001f9|G-\u001a\"mC\u000e\\G.[:uK\u0012\u00042aGA=\u0013\r\tYH\u0001\u0002\u001d'B\f'o\u001b'jgR,g.\u001a:O_\u0012,'\t\\1dW2L7\u000f^3e\u0011\u001d\ty\b\u0001D\u0001\u0003\u0003\u000b1c\u001c8O_\u0012,WK\u001c2mC\u000e\\G.[:uK\u0012$2!FAB\u0011!\t))! A\u0002\u0005\u001d\u0015!\u00058pI\u0016,fN\u00197bG.d\u0017n\u001d;fIB\u00191$!#\n\u0007\u0005-%A\u0001\u0010Ta\u0006\u00148\u000eT5ti\u0016tWM\u001d(pI\u0016,fN\u00197bG.d\u0017n\u001d;fI\"9\u0011q\u0012\u0001\u0007\u0002\u0005E\u0015AD8o\u00052|7m[+qI\u0006$X\r\u001a\u000b\u0004+\u0005M\u0005\u0002CAK\u0003\u001b\u0003\r!a&\u0002\u0019\tdwnY6Va\u0012\fG/\u001a3\u0011\u0007m\tI*C\u0002\u0002\u001c\n\u0011\u0011d\u00159be.d\u0015n\u001d;f]\u0016\u0014(\t\\8dWV\u0003H-\u0019;fI\"9\u0011q\u0014\u0001\u0007\u0002\u0005\u0005\u0016AG8o'B,7-\u001e7bi&4X\rV1tWN+(-\\5ui\u0016$GcA\u000b\u0002$\"A\u0011QUAO\u0001\u0004\t9+A\bta\u0016\u001cW\u000f\\1uSZ,G+Y:l!\rY\u0012\u0011V\u0005\u0004\u0003W\u0013!!J*qCJ\\G*[:uK:,'o\u00159fGVd\u0017\r^5wKR\u000b7o[*vE6LG\u000f^3e\u0011\u001d\ty\u000b\u0001D\u0001\u0003c\u000bAb\u001c8Pi\",'/\u0012<f]R$2!FAZ\u0011!\t),!,A\u0002\u0005]\u0016!B3wK:$\bcA\u000e\u0002:&\u0019\u00111\u0018\u0002\u0003%M\u0003\u0018M]6MSN$XM\\3s\u000bZ,g\u000e\u001e")
public interface SparkListenerInterface {
    public void onStageCompleted(SparkListenerStageCompleted var1);

    public void onStageSubmitted(SparkListenerStageSubmitted var1);

    public void onTaskStart(SparkListenerTaskStart var1);

    public void onTaskGettingResult(SparkListenerTaskGettingResult var1);

    public void onTaskEnd(SparkListenerTaskEnd var1);

    public void onJobStart(SparkListenerJobStart var1);

    public void onJobEnd(SparkListenerJobEnd var1);

    public void onEnvironmentUpdate(SparkListenerEnvironmentUpdate var1);

    public void onBlockManagerAdded(SparkListenerBlockManagerAdded var1);

    public void onBlockManagerRemoved(SparkListenerBlockManagerRemoved var1);

    public void onUnpersistRDD(SparkListenerUnpersistRDD var1);

    public void onApplicationStart(SparkListenerApplicationStart var1);

    public void onApplicationEnd(SparkListenerApplicationEnd var1);

    public void onExecutorMetricsUpdate(SparkListenerExecutorMetricsUpdate var1);

    public void onExecutorAdded(SparkListenerExecutorAdded var1);

    public void onExecutorRemoved(SparkListenerExecutorRemoved var1);

    public void onExecutorBlacklisted(SparkListenerExecutorBlacklisted var1);

    public void onExecutorBlacklistedForStage(SparkListenerExecutorBlacklistedForStage var1);

    public void onNodeBlacklistedForStage(SparkListenerNodeBlacklistedForStage var1);

    public void onExecutorUnblacklisted(SparkListenerExecutorUnblacklisted var1);

    public void onNodeBlacklisted(SparkListenerNodeBlacklisted var1);

    public void onNodeUnblacklisted(SparkListenerNodeUnblacklisted var1);

    public void onBlockUpdated(SparkListenerBlockUpdated var1);

    public void onSpeculativeTaskSubmitted(SparkListenerSpeculativeTaskSubmitted var1);

    public void onOtherEvent(SparkListenerEvent var1);
}

