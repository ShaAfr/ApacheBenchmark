/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark;

import java.io.Serializable;

public interface SparkStageInfo
extends Serializable {
    public int stageId();

    public int currentAttemptId();

    public long submissionTime();

    public String name();

    public int numTasks();

    public int numActiveTasks();

    public int numCompletedTasks();

    public int numFailedTasks();
}

