/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.WorkerRemoved;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;

public final class WorkerRemoved$
extends AbstractFunction3<String, String, String, WorkerRemoved>
implements Serializable {
    public static final WorkerRemoved$ MODULE$;

    public static {
        new org.apache.spark.scheduler.WorkerRemoved$();
    }

    public final String toString() {
        return "WorkerRemoved";
    }

    public WorkerRemoved apply(String workerId, String host, String message) {
        return new WorkerRemoved(workerId, host, message);
    }

    public Option<Tuple3<String, String, String>> unapply(WorkerRemoved x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)x$0.workerId(), (Object)x$0.host(), (Object)x$0.message()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private WorkerRemoved$() {
        MODULE$ = this;
    }
}

