/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.scheduler.TaskResultGetter$
 *  org.apache.spark.scheduler.TaskResultGetter$$anon
 *  org.slf4j.Logger
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Function0
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxedUnit
 *  scala.runtime.ObjectRef
 *  scala.runtime.TraitSetter
 */
package org.apache.spark.scheduler;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkEnv;
import org.apache.spark.UnknownReason$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.scheduler.TaskResultGetter$;
import org.apache.spark.scheduler.TaskSchedulerImpl;
import org.apache.spark.scheduler.TaskSetManager;
import org.apache.spark.serializer.SerializerInstance;
import org.apache.spark.util.ThreadUtils$;
import org.slf4j.Logger;
import scala.Enumeration;
import scala.Function0;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxedUnit;
import scala.runtime.ObjectRef;
import scala.runtime.TraitSetter;

@ScalaSignature(bytes="\u0006\u0001\u0005=a!B\u0001\u0003\u0001\u0011Q!\u0001\u0005+bg.\u0014Vm];mi\u001e+G\u000f^3s\u0015\t\u0019A!A\u0005tG\",G-\u001e7fe*\u0011QAB\u0001\u0006gB\f'o\u001b\u0006\u0003\u000f!\ta!\u00199bG\",'\"A\u0005\u0002\u0007=\u0014xmE\u0002\u0001\u0017E\u0001\"\u0001D\b\u000e\u00035Q\u0011AD\u0001\u0006g\u000e\fG.Y\u0005\u0003!5\u0011a!\u00118z%\u00164\u0007C\u0001\n\u0016\u001b\u0005\u0019\"B\u0001\u000b\u0005\u0003!Ig\u000e^3s]\u0006d\u0017B\u0001\f\u0014\u0005\u001daunZ4j]\u001eD\u0001\u0002\u0007\u0001\u0003\u0002\u0003\u0006IAG\u0001\tgB\f'o[#om\u000e\u0001\u0001CA\u000e\u001d\u001b\u0005!\u0011BA\u000f\u0005\u0005!\u0019\u0006/\u0019:l\u000b:4\b\u0002C\u0002\u0001\u0005\u0003\u0005\u000b\u0011B\u0010\u0011\u0005\u0001\nS\"\u0001\u0002\n\u0005\t\u0012!!\u0005+bg.\u001c6\r[3ek2,'/S7qY\")A\u0005\u0001C\u0001K\u00051A(\u001b8jiz\"2AJ\u0014)!\t\u0001\u0003\u0001C\u0003\u0019G\u0001\u0007!\u0004C\u0003\u0004G\u0001\u0007q\u0004C\u0004+\u0001\t\u0007I\u0011B\u0016\u0002\u000fQC%+R!E'V\tA\u0006\u0005\u0002\r[%\u0011a&\u0004\u0002\u0004\u0013:$\bB\u0002\u0019\u0001A\u0003%A&\u0001\u0005U\u0011J+\u0015\tR*!\u0011\u001d\u0011\u0004A1A\u0005\u0012M\nQcZ3u)\u0006\u001c8NU3tk2$X\t_3dkR|'/F\u00015!\t)D(D\u00017\u0015\t9\u0004(\u0001\u0006d_:\u001cWO\u001d:f]RT!!\u000f\u001e\u0002\tU$\u0018\u000e\u001c\u0006\u0002w\u0005!!.\u0019<b\u0013\tidGA\bFq\u0016\u001cW\u000f^8s'\u0016\u0014h/[2f\u0011\u0019y\u0004\u0001)A\u0005i\u00051r-\u001a;UCN\\'+Z:vYR,\u00050Z2vi>\u0014\b\u0005C\u0004B\u0001\t\u0007I\u0011\u0003\"\u0002\u0015M,'/[1mSj,'/F\u0001D!\r!u)S\u0007\u0002\u000b*\u0011aIO\u0001\u0005Y\u0006tw-\u0003\u0002I\u000b\nYA\u000b\u001b:fC\u0012dunY1m!\tQE*D\u0001L\u0015\t\tE!\u0003\u0002N\u0017\n\u00112+\u001a:jC2L'0\u001a:J]N$\u0018M\\2f\u0011\u0019y\u0005\u0001)A\u0005\u0007\u0006Y1/\u001a:jC2L'0\u001a:!\u0011\u001d\t\u0006A1A\u0005\u0012\t\u000bA\u0003^1tWJ+7/\u001e7u'\u0016\u0014\u0018.\u00197ju\u0016\u0014\bBB*\u0001A\u0003%1)A\u000buCN\\'+Z:vYR\u001cVM]5bY&TXM\u001d\u0011\t\u000bU\u0003A\u0011\u0001,\u0002+\u0015t\u0017/^3vKN+8mY3tg\u001a,H\u000eV1tWR!qKW0e!\ta\u0001,\u0003\u0002Z\u001b\t!QK\\5u\u0011\u0015YF\u000b1\u0001]\u00039!\u0018m]6TKRl\u0015M\\1hKJ\u0004\"\u0001I/\n\u0005y\u0013!A\u0004+bg.\u001cV\r^'b]\u0006<WM\u001d\u0005\u0006AR\u0003\r!Y\u0001\u0004i&$\u0007C\u0001\u0007c\u0013\t\u0019WB\u0001\u0003M_:<\u0007\"B3U\u0001\u00041\u0017AD:fe&\fG.\u001b>fI\u0012\u000bG/\u0019\t\u0003O*l\u0011\u0001\u001b\u0006\u0003Sj\n1A\\5p\u0013\tY\u0007N\u0001\u0006CsR,')\u001e4gKJDQ!\u001c\u0001\u0005\u00029\f\u0011#\u001a8rk\u0016,XMR1jY\u0016$G+Y:l)\u00199v\u000e]9\u0002\b!)1\f\u001ca\u00019\")\u0001\r\u001ca\u0001C\")!\u000f\u001ca\u0001g\u0006IA/Y:l'R\fG/\u001a\t\u0004i\u0006\u0005aBA;\u001d\t1XP\u0004\u0002xy:\u0011\u0001p_\u0007\u0002s*\u0011!0G\u0001\u0007yI|w\u000e\u001e \n\u0003%I!a\u0002\u0005\n\u0005\u00151\u0011BA@\u0005\u0003%!\u0016m]6Ti\u0006$X-\u0003\u0003\u0002\u0004\u0005\u0015!!\u0003+bg.\u001cF/\u0019;f\u0015\tyH\u0001C\u0003fY\u0002\u0007a\rC\u0004\u0002\f\u0001!\t!!\u0004\u0002\tM$x\u000e\u001d\u000b\u0002/\u0002")
public class TaskResultGetter
implements Logging {
    public final SparkEnv org$apache$spark$scheduler$TaskResultGetter$$sparkEnv;
    public final TaskSchedulerImpl org$apache$spark$scheduler$TaskResultGetter$$scheduler;
    private final int THREADS;
    private final ExecutorService getTaskResultExecutor;
    private final ThreadLocal<SerializerInstance> serializer;
    private final ThreadLocal<SerializerInstance> taskResultSerializer;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @TraitSetter
    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    private int THREADS() {
        return this.THREADS;
    }

    public ExecutorService getTaskResultExecutor() {
        return this.getTaskResultExecutor;
    }

    public ThreadLocal<SerializerInstance> serializer() {
        return this.serializer;
    }

    public ThreadLocal<SerializerInstance> taskResultSerializer() {
        return this.taskResultSerializer;
    }

    public void enqueueSuccessfulTask(TaskSetManager taskSetManager, long tid, ByteBuffer serializedData) {
        this.getTaskResultExecutor().execute(new Runnable(this, taskSetManager, tid, serializedData){
            private final /* synthetic */ TaskResultGetter $outer;
            public final TaskSetManager taskSetManager$1;
            public final long tid$1;
            public final ByteBuffer serializedData$1;

            public void run() {
                scala.runtime.NonLocalReturnControl nonLocalReturnControl2;
                block2 : {
                    Object object = new Object();
                    try {
                        org.apache.spark.util.Utils$.MODULE$.logUncaughtExceptions(new scala.Serializable(this, object){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anon$3 $outer;
                            private final Object nonLocalReturnKey1$1;

                            public final void apply() {
                                this.apply$mcV$sp();
                            }

                            /*
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             */
                            public void apply$mcV$sp() {
                                try {
                                    scala.Tuple2 tuple2;
                                    scala.Tuple2 tuple22;
                                    org.apache.spark.scheduler.TaskResult taskResult = (org.apache.spark.scheduler.TaskResult)this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().serializer().get().deserialize(this.$outer.serializedData$1, scala.reflect.ClassTag$.MODULE$.apply(org.apache.spark.scheduler.TaskResult.class));
                                    if (taskResult instanceof org.apache.spark.scheduler.DirectTaskResult) {
                                        org.apache.spark.scheduler.DirectTaskResult directTaskResult = (org.apache.spark.scheduler.DirectTaskResult)taskResult;
                                        if (!this.$outer.taskSetManager$1.canFetchMoreResults(this.$outer.serializedData$1.limit())) throw new scala.runtime.NonLocalReturnControl$mcV$sp(this.nonLocalReturnKey1$1, BoxedUnit.UNIT);
                                        directTaskResult.value(this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().taskResultSerializer().get());
                                        tuple2 = new scala.Tuple2((Object)directTaskResult, (Object)scala.runtime.BoxesRunTime.boxToInteger((int)this.$outer.serializedData$1.limit()));
                                    } else {
                                        if (!(taskResult instanceof org.apache.spark.scheduler.IndirectTaskResult)) throw new scala.MatchError((Object)taskResult);
                                        org.apache.spark.scheduler.IndirectTaskResult indirectTaskResult = (org.apache.spark.scheduler.IndirectTaskResult)taskResult;
                                        org.apache.spark.storage.BlockId blockId = indirectTaskResult.blockId();
                                        int size = indirectTaskResult.size();
                                        if (!this.$outer.taskSetManager$1.canFetchMoreResults(size)) {
                                            this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().org$apache$spark$scheduler$TaskResultGetter$$sparkEnv.blockManager().master().removeBlock(blockId);
                                            throw new scala.runtime.NonLocalReturnControl$mcV$sp(this.nonLocalReturnKey1$1, BoxedUnit.UNIT);
                                        }
                                        this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().logDebug((Function0<String>)new scala.Serializable(this){
                                            public static final long serialVersionUID = 0L;
                                            private final /* synthetic */ org.apache.spark.scheduler.TaskResultGetter$$anon$3$$anonfun$run$1 $outer;

                                            public final String apply() {
                                                return new scala.collection.immutable.StringOps(scala.Predef$.MODULE$.augmentString("Fetching indirect task result for TID %s")).format((scala.collection.Seq)scala.Predef$.MODULE$.genericWrapArray((Object)new Object[]{scala.runtime.BoxesRunTime.boxToLong((long)this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$anonfun$$$outer().tid$1)}));
                                            }
                                            {
                                                if ($outer == null) {
                                                    throw null;
                                                }
                                                this.$outer = $outer;
                                            }
                                        });
                                        this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().org$apache$spark$scheduler$TaskResultGetter$$scheduler.handleTaskGettingResult(this.$outer.taskSetManager$1, this.$outer.tid$1);
                                        scala.Option<org.apache.spark.util.io.ChunkedByteBuffer> serializedTaskResult = this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().org$apache$spark$scheduler$TaskResultGetter$$sparkEnv.blockManager().getRemoteBytes(blockId);
                                        if (!serializedTaskResult.isDefined()) {
                                            this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().org$apache$spark$scheduler$TaskResultGetter$$scheduler.handleFailedTask(this.$outer.taskSetManager$1, this.$outer.tid$1, org.apache.spark.TaskState$.MODULE$.FINISHED(), org.apache.spark.TaskResultLost$.MODULE$);
                                            throw new scala.runtime.NonLocalReturnControl$mcV$sp(this.nonLocalReturnKey1$1, BoxedUnit.UNIT);
                                        }
                                        org.apache.spark.scheduler.DirectTaskResult deserializedResult = (org.apache.spark.scheduler.DirectTaskResult)this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().serializer().get().deserialize(((org.apache.spark.util.io.ChunkedByteBuffer)serializedTaskResult.get()).toByteBuffer(), scala.reflect.ClassTag$.MODULE$.apply(org.apache.spark.scheduler.DirectTaskResult.class));
                                        deserializedResult.value(this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().taskResultSerializer().get());
                                        this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().org$apache$spark$scheduler$TaskResultGetter$$sparkEnv.blockManager().master().removeBlock(blockId);
                                        tuple2 = new scala.Tuple2((Object)deserializedResult, (Object)scala.runtime.BoxesRunTime.boxToInteger((int)size));
                                    }
                                    scala.Tuple2 tuple23 = tuple2;
                                    if (tuple23 == null) throw new scala.MatchError((Object)tuple23);
                                    org.apache.spark.scheduler.DirectTaskResult result2 = (org.apache.spark.scheduler.DirectTaskResult)tuple23._1();
                                    int size = tuple23._2$mcI$sp();
                                    scala.Tuple2 tuple24 = tuple22 = new scala.Tuple2((Object)result2, (Object)scala.runtime.BoxesRunTime.boxToInteger((int)size));
                                    org.apache.spark.scheduler.DirectTaskResult result3 = (org.apache.spark.scheduler.DirectTaskResult)tuple24._1();
                                    int size2 = tuple24._2$mcI$sp();
                                    result3.accumUpdates_$eq((scala.collection.Seq)result3.accumUpdates().map((scala.Function1)new scala.Serializable(this, size2){
                                        public static final long serialVersionUID = 0L;
                                        private final int size$1;

                                        /*
                                         * Enabled aggressive block sorting
                                         */
                                        public final org.apache.spark.util.AccumulatorV2<? super java.lang.Long, ? super java.lang.Long> apply(org.apache.spark.util.AccumulatorV2<?, ?> a) {
                                            org.apache.spark.util.LongAccumulator longAccumulator;
                                            block4 : {
                                                org.apache.spark.util.LongAccumulator acc;
                                                block3 : {
                                                    scala.Some some;
                                                    scala.Option<String> option;
                                                    block2 : {
                                                        some = new scala.Some((Object)org.apache.spark.InternalAccumulator$.MODULE$.RESULT_SIZE());
                                                        if (a.name() != null) break block2;
                                                        if (some == null) break block3;
                                                        break block4;
                                                    }
                                                    if (!option.equals((Object)some)) break block4;
                                                }
                                                scala.Predef$.MODULE$.assert((acc = a).sum() == 0L, (Function0)new scala.Serializable(this){
                                                    public static final long serialVersionUID = 0L;

                                                    public final String apply() {
                                                        return "task result size should not have been set on the executors";
                                                    }
                                                });
                                                acc.setValue(this.size$1);
                                                longAccumulator = acc;
                                                return longAccumulator;
                                            }
                                            longAccumulator = a;
                                            return longAccumulator;
                                        }
                                        {
                                            this.size$1 = size$1;
                                        }
                                    }, scala.collection.Seq$.MODULE$.canBuildFrom()));
                                    this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().org$apache$spark$scheduler$TaskResultGetter$$scheduler.handleSuccessfulTask(this.$outer.taskSetManager$1, this.$outer.tid$1, result3);
                                    return;
                                }
                                catch (Throwable throwable) {
                                    Throwable throwable2 = throwable;
                                    if (throwable2 instanceof java.lang.ClassNotFoundException) {
                                        java.lang.ClassLoader loader = java.lang.Thread.currentThread().getContextClassLoader();
                                        this.$outer.taskSetManager$1.abort(new scala.collection.mutable.StringBuilder().append((Object)"ClassNotFound with classloader: ").append((Object)loader).toString(), this.$outer.taskSetManager$1.abort$default$2());
                                        BoxedUnit boxedUnit = BoxedUnit.UNIT;
                                        return;
                                    }
                                    scala.Option option = scala.util.control.NonFatal$.MODULE$.unapply(throwable2);
                                    if (option.isEmpty()) {
                                        throw throwable;
                                    }
                                    Throwable ex = (Throwable)option.get();
                                    this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().logError((Function0<String>)new scala.Serializable(this){
                                        public static final long serialVersionUID = 0L;

                                        public final String apply() {
                                            return "Exception while getting task result";
                                        }
                                    }, ex);
                                    this.$outer.taskSetManager$1.abort(new scala.collection.immutable.StringOps(scala.Predef$.MODULE$.augmentString("Exception while getting task result: %s")).format((scala.collection.Seq)scala.Predef$.MODULE$.genericWrapArray((Object)new Object[]{ex})), this.$outer.taskSetManager$1.abort$default$2());
                                    BoxedUnit boxedUnit = BoxedUnit.UNIT;
                                }
                            }

                            public /* synthetic */ $anon$3 org$apache$spark$scheduler$TaskResultGetter$$anon$$anonfun$$$outer() {
                                return this.$outer;
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                            }
                        });
                    }
                    catch (scala.runtime.NonLocalReturnControl nonLocalReturnControl2) {
                        if (nonLocalReturnControl2.key() != object) break block2;
                        nonLocalReturnControl2.value$mcV$sp();
                    }
                    return;
                }
                throw nonLocalReturnControl2;
            }

            public /* synthetic */ TaskResultGetter org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.taskSetManager$1 = taskSetManager$1;
                this.tid$1 = tid$1;
                this.serializedData$1 = serializedData$1;
            }
        });
    }

    public void enqueueFailedTask(TaskSetManager taskSetManager, long tid, Enumeration.Value taskState, ByteBuffer serializedData) {
        Throwable throwable2;
        block2 : {
            ObjectRef reason = ObjectRef.create((Object)UnknownReason$.MODULE$);
            try {
                this.getTaskResultExecutor().execute(new Runnable(this, taskSetManager, tid, taskState, serializedData, reason){
                    private final /* synthetic */ TaskResultGetter $outer;
                    public final TaskSetManager taskSetManager$2;
                    public final long tid$2;
                    public final Enumeration.Value taskState$1;
                    public final ByteBuffer serializedData$2;
                    public final ObjectRef reason$1;

                    public void run() {
                        org.apache.spark.util.Utils$.MODULE$.logUncaughtExceptions(new scala.Serializable(this){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anon$4 $outer;

                            public final void apply() {
                                this.apply$mcV$sp();
                            }

                            public void apply$mcV$sp() {
                                java.lang.ClassLoader loader = org.apache.spark.util.Utils$.MODULE$.getContextOrSparkClassLoader();
                                try {
                                    try {
                                        if (this.$outer.serializedData$2 != null && this.$outer.serializedData$2.limit() > 0) {
                                            this.$outer.reason$1.elem = (org.apache.spark.TaskFailedReason)this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().serializer().get().deserialize(this.$outer.serializedData$2, loader, scala.reflect.ClassTag$.MODULE$.apply(org.apache.spark.TaskFailedReason.class));
                                        }
                                    }
                                    catch (java.lang.Exception exception2) {
                                    }
                                    catch (java.lang.ClassNotFoundException classNotFoundException) {
                                        this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().logError((Function0<String>)new scala.Serializable(this, loader){
                                            public static final long serialVersionUID = 0L;
                                            private final java.lang.ClassLoader loader$1;

                                            public final String apply() {
                                                return new scala.collection.mutable.StringBuilder().append((Object)"Could not deserialize TaskEndReason: ClassNotFound with classloader ").append((Object)this.loader$1).toString();
                                            }
                                            {
                                                this.loader$1 = loader$1;
                                            }
                                        });
                                    }
                                }
                                finally {
                                    this.$outer.org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer().org$apache$spark$scheduler$TaskResultGetter$$scheduler.handleFailedTask(this.$outer.taskSetManager$2, this.$outer.tid$2, this.$outer.taskState$1, (org.apache.spark.TaskFailedReason)this.$outer.reason$1.elem);
                                }
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                            }
                        });
                    }

                    public /* synthetic */ TaskResultGetter org$apache$spark$scheduler$TaskResultGetter$$anon$$$outer() {
                        return this.$outer;
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.taskSetManager$2 = taskSetManager$2;
                        this.tid$2 = tid$2;
                        this.taskState$1 = taskState$1;
                        this.serializedData$2 = serializedData$2;
                        this.reason$1 = reason$1;
                    }
                });
            }
            catch (Throwable throwable2) {
                Throwable throwable3 = throwable2;
                if (!(throwable3 instanceof RejectedExecutionException) || !this.org$apache$spark$scheduler$TaskResultGetter$$sparkEnv.isStopped()) break block2;
                BoxedUnit boxedUnit = BoxedUnit.UNIT;
            }
            return;
        }
        throw throwable2;
    }

    public void stop() {
        this.getTaskResultExecutor().shutdownNow();
    }

    public TaskResultGetter(SparkEnv sparkEnv, TaskSchedulerImpl scheduler) {
        this.org$apache$spark$scheduler$TaskResultGetter$$sparkEnv = sparkEnv;
        this.org$apache$spark$scheduler$TaskResultGetter$$scheduler = scheduler;
        Logging$class.$init$(this);
        this.THREADS = sparkEnv.conf().getInt("spark.resultGetter.threads", 4);
        this.getTaskResultExecutor = ThreadUtils$.MODULE$.newDaemonFixedThreadPool(this.THREADS(), "task-result-getter");
        this.serializer = new ThreadLocal<SerializerInstance>(this){
            private final /* synthetic */ TaskResultGetter $outer;

            public SerializerInstance initialValue() {
                return this.$outer.org$apache$spark$scheduler$TaskResultGetter$$sparkEnv.closureSerializer().newInstance();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        };
        this.taskResultSerializer = new ThreadLocal<SerializerInstance>(this){
            private final /* synthetic */ TaskResultGetter $outer;

            public SerializerInstance initialValue() {
                return this.$outer.org$apache$spark$scheduler$TaskResultGetter$$sparkEnv.serializer().newInstance();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        };
    }
}

