/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.deploy.history;

import org.apache.spark.deploy.history.LoadedAppUI;
import org.apache.spark.ui.SparkUI;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class LoadedAppUI$
extends AbstractFunction1<SparkUI, LoadedAppUI>
implements Serializable {
    public static final LoadedAppUI$ MODULE$;

    public static {
        new org.apache.spark.deploy.history.LoadedAppUI$();
    }

    public final String toString() {
        return "LoadedAppUI";
    }

    public LoadedAppUI apply(SparkUI ui) {
        return new LoadedAppUI(ui);
    }

    public Option<SparkUI> unapply(LoadedAppUI x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.ui());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private LoadedAppUI$() {
        MODULE$ = this;
    }
}

