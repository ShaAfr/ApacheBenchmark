/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.runtime.AbstractFunction1
 */
package org.apache.spark.internal.config;

import org.apache.spark.internal.config.ConfigBuilder;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.runtime.AbstractFunction1;

public final class ConfigBuilder$
extends AbstractFunction1<String, ConfigBuilder>
implements Serializable {
    public static final ConfigBuilder$ MODULE$;

    public static {
        new org.apache.spark.internal.config.ConfigBuilder$();
    }

    public final String toString() {
        return "ConfigBuilder";
    }

    public ConfigBuilder apply(String key) {
        return new ConfigBuilder(key);
    }

    public Option<String> unapply(ConfigBuilder x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)x$0.key());
    }

    private Object readResolve() {
        return MODULE$;
    }

    private ConfigBuilder$() {
        MODULE$ = this;
    }
}

