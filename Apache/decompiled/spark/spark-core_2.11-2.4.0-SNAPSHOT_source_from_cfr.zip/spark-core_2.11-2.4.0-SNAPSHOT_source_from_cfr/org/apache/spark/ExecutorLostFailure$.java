/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark;

import org.apache.spark.ExecutorLostFailure;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;
import scala.runtime.BoxesRunTime;

public final class ExecutorLostFailure$
extends AbstractFunction3<String, Object, Option<String>, ExecutorLostFailure>
implements Serializable {
    public static final ExecutorLostFailure$ MODULE$;

    public static {
        new org.apache.spark.ExecutorLostFailure$();
    }

    public final String toString() {
        return "ExecutorLostFailure";
    }

    public ExecutorLostFailure apply(String execId, boolean exitCausedByApp, Option<String> reason) {
        return new ExecutorLostFailure(execId, exitCausedByApp, reason);
    }

    public Option<Tuple3<String, Object, Option<String>>> unapply(ExecutorLostFailure x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)x$0.execId(), (Object)BoxesRunTime.boxToBoolean((boolean)x$0.exitCausedByApp()), x$0.reason()));
    }

    public boolean $lessinit$greater$default$2() {
        return true;
    }

    public boolean apply$default$2() {
        return true;
    }

    private Object readResolve() {
        return MODULE$;
    }

    private ExecutorLostFailure$() {
        MODULE$ = this;
    }
}

