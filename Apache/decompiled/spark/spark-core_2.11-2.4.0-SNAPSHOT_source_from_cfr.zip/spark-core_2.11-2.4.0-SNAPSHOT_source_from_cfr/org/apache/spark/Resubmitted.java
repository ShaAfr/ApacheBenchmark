/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.annotation.DeveloperApi
 *  scala.collection.Iterator
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark;

import org.apache.spark.Resubmitted$;
import org.apache.spark.annotation.DeveloperApi;
import scala.collection.Iterator;
import scala.reflect.ScalaSignature;

@DeveloperApi
@ScalaSignature(bytes="\u0006\u0001\u0019<Q!\u0001\u0002\t\u0002&\t1BU3tk\nl\u0017\u000e\u001e;fI*\u00111\u0001B\u0001\u0006gB\f'o\u001b\u0006\u0003\u000b\u0019\ta!\u00199bG\",'\"A\u0004\u0002\u0007=\u0014xm\u0001\u0001\u0011\u0005)YQ\"\u0001\u0002\u0007\u000b1\u0011\u0001\u0012Q\u0007\u0003\u0017I+7/\u001e2nSR$X\rZ\n\u0006\u00179!rC\u0007\t\u0003\u001fIi\u0011\u0001\u0005\u0006\u0002#\u0005)1oY1mC&\u00111\u0003\u0005\u0002\u0007\u0003:L(+\u001a4\u0011\u0005))\u0012B\u0001\f\u0003\u0005A!\u0016m]6GC&dW\r\u001a*fCN|g\u000e\u0005\u0002\u00101%\u0011\u0011\u0004\u0005\u0002\b!J|G-^2u!\ty1$\u0003\u0002\u001d!\ta1+\u001a:jC2L'0\u00192mK\")ad\u0003C\u0001?\u00051A(\u001b8jiz\"\u0012!\u0003\u0005\u0006C-!\tEI\u0001\u000ei>,%O]8s'R\u0014\u0018N\\4\u0016\u0003\r\u0002\"\u0001J\u0014\u000f\u0005=)\u0013B\u0001\u0014\u0011\u0003\u0019\u0001&/\u001a3fM&\u0011\u0001&\u000b\u0002\u0007'R\u0014\u0018N\\4\u000b\u0005\u0019\u0002\u0002bB\u0016\f\u0003\u0003%\t\u0005L\u0001\u000eaJ|G-^2u!J,g-\u001b=\u0016\u00035\u0002\"AL\u001a\u000e\u0003=R!\u0001M\u0019\u0002\t1\fgn\u001a\u0006\u0002e\u0005!!.\u0019<b\u0013\tAs\u0006C\u00046\u0017\u0005\u0005I\u0011\u0001\u001c\u0002\u0019A\u0014x\u000eZ;di\u0006\u0013\u0018\u000e^=\u0016\u0003]\u0002\"a\u0004\u001d\n\u0005e\u0002\"aA%oi\"91hCA\u0001\n\u0003a\u0014A\u00049s_\u0012,8\r^#mK6,g\u000e\u001e\u000b\u0003{\u0001\u0003\"a\u0004 \n\u0005}\u0002\"aA!os\"9\u0011IOA\u0001\u0002\u00049\u0014a\u0001=%c!91iCA\u0001\n\u0003\"\u0015a\u00049s_\u0012,8\r^%uKJ\fGo\u001c:\u0016\u0003\u0015\u00032AR%>\u001b\u00059%B\u0001%\u0011\u0003)\u0019w\u000e\u001c7fGRLwN\\\u0005\u0003\u0015\u001e\u0013\u0001\"\u0013;fe\u0006$xN\u001d\u0005\b\u0019.\t\t\u0011\"\u0001N\u0003!\u0019\u0017M\\#rk\u0006dGC\u0001(R!\tyq*\u0003\u0002Q!\t9!i\\8mK\u0006t\u0007bB!L\u0003\u0003\u0005\r!\u0010\u0005\b'.\t\t\u0011\"\u0011U\u0003!A\u0017m\u001d5D_\u0012,G#A\u001c\t\u000fY[\u0011\u0011!C!/\u0006AAo\\*ue&tw\rF\u0001.\u0011\u001dI6\"!A\u0005\ni\u000b1B]3bIJ+7o\u001c7wKR\t1\f\u0005\u0002/9&\u0011Ql\f\u0002\u0007\u001f\nTWm\u0019;)\u0005-y\u0006C\u00011d\u001b\u0005\t'B\u00012\u0003\u0003)\tgN\\8uCRLwN\\\u0005\u0003I\u0006\u0014A\u0002R3wK2|\u0007/\u001a:Ba&D#\u0001A0")
public final class Resubmitted {
    public static boolean countTowardsTaskFailures() {
        return Resubmitted$.MODULE$.countTowardsTaskFailures();
    }

    public static String toString() {
        return Resubmitted$.MODULE$.toString();
    }

    public static int hashCode() {
        return Resubmitted$.MODULE$.hashCode();
    }

    public static boolean canEqual(Object object) {
        return Resubmitted$.MODULE$.canEqual(object);
    }

    public static Iterator<Object> productIterator() {
        return Resubmitted$.MODULE$.productIterator();
    }

    public static Object productElement(int n) {
        return Resubmitted$.MODULE$.productElement(n);
    }

    public static int productArity() {
        return Resubmitted$.MODULE$.productArity();
    }

    public static String productPrefix() {
        return Resubmitted$.MODULE$.productPrefix();
    }

    public static String toErrorString() {
        return Resubmitted$.MODULE$.toErrorString();
    }
}

