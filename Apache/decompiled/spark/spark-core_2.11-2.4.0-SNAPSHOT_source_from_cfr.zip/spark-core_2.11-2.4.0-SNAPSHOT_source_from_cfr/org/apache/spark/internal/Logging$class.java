/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.log4j.Level
 *  org.apache.log4j.LogManager
 *  org.apache.log4j.Logger
 *  org.apache.log4j.PropertyConfigurator
 *  org.apache.spark.internal.Logging$$anonfun
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  scala.Function0
 *  scala.MatchError
 *  scala.None$
 *  scala.Option
 *  scala.Option$
 *  scala.Predef$
 *  scala.Serializable
 *  scala.Some
 *  scala.StringContext
 *  scala.collection.Seq
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.WrappedArray
 *  scala.runtime.BoxedUnit
 */
package org.apache.spark.internal;

import java.io.PrintStream;
import java.net.URL;
import java.util.Enumeration;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Function0;
import scala.MatchError;
import scala.None$;
import scala.Option;
import scala.Option$;
import scala.Predef$;
import scala.Serializable;
import scala.Some;
import scala.StringContext;
import scala.collection.Seq;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.WrappedArray;
import scala.runtime.BoxedUnit;

public abstract class Logging$class {
    public static String logName(Logging $this) {
        return new StringOps(Predef$.MODULE$.augmentString($this.getClass().getName())).stripSuffix("$");
    }

    public static Logger log(Logging $this) {
        if ($this.org$apache$spark$internal$Logging$$log_() == null) {
            $this.initializeLogIfNecessary(false);
            $this.org$apache$spark$internal$Logging$$log__$eq(LoggerFactory.getLogger((String)$this.logName()));
        }
        return $this.org$apache$spark$internal$Logging$$log_();
    }

    public static void logInfo(Logging $this, Function0 msg) {
        if ($this.log().isInfoEnabled()) {
            $this.log().info((String)msg.apply());
        }
    }

    public static void logDebug(Logging $this, Function0 msg) {
        if ($this.log().isDebugEnabled()) {
            $this.log().debug((String)msg.apply());
        }
    }

    public static void logTrace(Logging $this, Function0 msg) {
        if ($this.log().isTraceEnabled()) {
            $this.log().trace((String)msg.apply());
        }
    }

    public static void logWarning(Logging $this, Function0 msg) {
        if ($this.log().isWarnEnabled()) {
            $this.log().warn((String)msg.apply());
        }
    }

    public static void logError(Logging $this, Function0 msg) {
        if ($this.log().isErrorEnabled()) {
            $this.log().error((String)msg.apply());
        }
    }

    public static void logInfo(Logging $this, Function0 msg, Throwable throwable) {
        if ($this.log().isInfoEnabled()) {
            $this.log().info((String)msg.apply(), throwable);
        }
    }

    public static void logDebug(Logging $this, Function0 msg, Throwable throwable) {
        if ($this.log().isDebugEnabled()) {
            $this.log().debug((String)msg.apply(), throwable);
        }
    }

    public static void logTrace(Logging $this, Function0 msg, Throwable throwable) {
        if ($this.log().isTraceEnabled()) {
            $this.log().trace((String)msg.apply(), throwable);
        }
    }

    public static void logWarning(Logging $this, Function0 msg, Throwable throwable) {
        if ($this.log().isWarnEnabled()) {
            $this.log().warn((String)msg.apply(), throwable);
        }
    }

    public static void logError(Logging $this, Function0 msg, Throwable throwable) {
        if ($this.log().isErrorEnabled()) {
            $this.log().error((String)msg.apply(), throwable);
        }
    }

    public static boolean isTraceEnabled(Logging $this) {
        return $this.log().isTraceEnabled();
    }

    public static void initializeLogIfNecessary(Logging $this, boolean isInterpreter) {
        $this.initializeLogIfNecessary(isInterpreter, false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean initializeLogIfNecessary(Logging $this, boolean isInterpreter, boolean silent) {
        BoxedUnit boxedUnit;
        if (Logging$.MODULE$.org$apache$spark$internal$Logging$$initialized()) {
            boxedUnit = BoxedUnit.UNIT;
            return false;
        }
        Object object = Logging$.MODULE$.initLock();
        synchronized (object) {
            if (Logging$.MODULE$.org$apache$spark$internal$Logging$$initialized()) {
                BoxedUnit boxedUnit2 = BoxedUnit.UNIT;
                // MONITOREXIT [0, 2, 4] lbl9 : MonitorExitStatement: MONITOREXIT : var3_3
                boxedUnit = boxedUnit2;
                return false;
            }
            Logging$class.initializeLogging($this, isInterpreter, silent);
            return true;
        }
    }

    public static boolean initializeLogIfNecessary$default$2(Logging $this) {
        return false;
    }

    private static void initializeLogging(Logging $this, boolean isInterpreter, boolean silent) {
        block6 : {
            Option option;
            block9 : {
                Level replLevel;
                org.apache.log4j.Logger rootLogger;
                block11 : {
                    Level level;
                    Level level2;
                    block10 : {
                        block7 : {
                            String defaultLogProps;
                            block8 : {
                                BoxedUnit boxedUnit;
                                if (!Logging$.MODULE$.org$apache$spark$internal$Logging$$isLog4j12()) break block6;
                                boolean log4j12Initialized = LogManager.getRootLogger().getAllAppenders().hasMoreElements();
                                if (log4j12Initialized) break block7;
                                Logging$.MODULE$.org$apache$spark$internal$Logging$$defaultSparkLog4jConfig_$eq(true);
                                defaultLogProps = "org/apache/spark/log4j-defaults.properties";
                                option = Option$.MODULE$.apply((Object)Utils$.MODULE$.getSparkClassLoader().getResource(defaultLogProps));
                                if (!(option instanceof Some)) break block8;
                                Some some = (Some)option;
                                URL url = (URL)some.x();
                                PropertyConfigurator.configure((URL)url);
                                if (silent) {
                                    boxedUnit = BoxedUnit.UNIT;
                                } else {
                                    System.err.println(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Using Spark's default log4j profile: ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{defaultLogProps})));
                                    boxedUnit = BoxedUnit.UNIT;
                                }
                                BoxedUnit boxedUnit2 = boxedUnit;
                                break block7;
                            }
                            if (!None$.MODULE$.equals((Object)option)) break block9;
                            System.err.println(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Spark was unable to load ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{defaultLogProps})));
                            BoxedUnit boxedUnit = BoxedUnit.UNIT;
                        }
                        rootLogger = LogManager.getRootLogger();
                        if (Logging$.MODULE$.org$apache$spark$internal$Logging$$defaultRootLevel() == null) {
                            Logging$.MODULE$.org$apache$spark$internal$Logging$$defaultRootLevel_$eq(rootLogger.getLevel());
                        }
                        if (!isInterpreter) break block6;
                        org.apache.log4j.Logger replLogger = LogManager.getLogger((String)$this.logName());
                        level = rootLogger.getEffectiveLevel();
                        replLevel = (Level)Option$.MODULE$.apply((Object)replLogger.getLevel()).getOrElse((Function0)new Serializable($this){
                            public static final long serialVersionUID = 0L;

                            public final Level apply() {
                                return Level.WARN;
                            }
                        });
                        if (replLevel != null) break block10;
                        if (level == null) break block6;
                        break block11;
                    }
                    if (level2.equals((Object)level)) break block6;
                }
                if (!silent) {
                    System.err.printf("Setting default log level to \"%s\".\n", new Object[]{replLevel});
                    System.err.println("To adjust logging level use sc.setLogLevel(newLevel). For SparkR, use setLogLevel(newLevel).");
                }
                rootLogger.setLevel(replLevel);
                break block6;
            }
            throw new MatchError((Object)option);
        }
        Logging$.MODULE$.org$apache$spark$internal$Logging$$initialized_$eq(true);
        $this.log();
    }

    public static void $init$(Logging $this) {
        $this.org$apache$spark$internal$Logging$$log__$eq(null);
    }
}

