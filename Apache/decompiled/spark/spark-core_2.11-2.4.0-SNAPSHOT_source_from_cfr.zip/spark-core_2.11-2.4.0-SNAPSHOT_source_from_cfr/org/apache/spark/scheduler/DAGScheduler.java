/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.SerializationUtils
 *  org.apache.spark.network.util.JavaUtils
 *  org.apache.spark.scheduler.DAGScheduler$$anon
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$activeJobForStage
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$cancelJob
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$cancelJobGroup
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$cleanUpAfterSchedulerStop
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$cleanupStateForJobAndIndependentStages
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$createShuffleMapStage
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$doCancelAllJobs
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$getMissingAncestorShuffleDependencies
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$getOrCreateParentStages
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$getShuffleDependencies
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleExecutorAdded
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleJobCancellation
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleJobGroupCancelled
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleJobSubmitted
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleMapStageSubmitted
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleStageCancellation
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskCompletion
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$handleWorkerRemoved
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$org$apache$spark$scheduler$DAGScheduler$
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$org$apache$spark$scheduler$DAGScheduler$$getOrCreateShuffleMapStage
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$org$apache$spark$scheduler$DAGScheduler$$getPreferredLocsInternal
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$org$apache$spark$scheduler$DAGScheduler$$submitStage
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$removeExecutorAndUnregisterOutputs
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$resubmitFailedStages
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$runJob
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$submitJob
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$submitMissingTasks
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$submitWaitingChildStages
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$updateAccumulators
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$updateJobIdStageIdMapsList
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$updateJobIdStageIdMapsList$1
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$visit
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$visit$1
 *  org.apache.spark.scheduler.DAGScheduler$$anonfun$visit$2
 *  org.slf4j.Logger
 *  scala.Array$
 *  scala.Function0
 *  scala.Function1
 *  scala.Function2
 *  scala.MatchError
 *  scala.None$
 *  scala.Option
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$$less$colon$less
 *  scala.Product2
 *  scala.Serializable
 *  scala.Some
 *  scala.StringContext
 *  scala.Tuple2
 *  scala.Tuple4
 *  scala.collection.GenTraversable
 *  scala.collection.GenTraversableOnce
 *  scala.collection.IndexedSeq
 *  scala.collection.IndexedSeq$
 *  scala.collection.Iterable
 *  scala.collection.Iterator
 *  scala.collection.Map
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.SetLike
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.generic.Shrinkable
 *  scala.collection.immutable.IndexedSeq$
 *  scala.collection.immutable.List
 *  scala.collection.immutable.List$
 *  scala.collection.immutable.Map
 *  scala.collection.immutable.Nil$
 *  scala.collection.immutable.Range
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.ArrayStack
 *  scala.collection.mutable.HashMap
 *  scala.collection.mutable.HashSet
 *  scala.collection.mutable.HashSet$
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.concurrent.Awaitable
 *  scala.concurrent.Future
 *  scala.concurrent.duration.Duration
 *  scala.concurrent.duration.Duration$
 *  scala.concurrent.duration.Duration$Infinite
 *  scala.concurrent.duration.FiniteDuration
 *  scala.concurrent.duration.package
 *  scala.concurrent.duration.package$
 *  scala.concurrent.duration.package$DurationInt
 *  scala.math.Ordering
 *  scala.math.Ordering$Int$
 *  scala.package$
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BooleanRef
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.NonLocalReturnControl
 *  scala.runtime.ObjectRef
 *  scala.runtime.RichInt$
 *  scala.runtime.ScalaRunTime$
 *  scala.runtime.TraitSetter
 *  scala.util.Failure
 *  scala.util.Success
 *  scala.util.Try
 *  scala.util.control.NonFatal$
 */
package org.apache.spark.scheduler;

import java.io.NotSerializableException;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.Properties;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.spark.Dependency;
import org.apache.spark.ExceptionFailure;
import org.apache.spark.ExecutorLostFailure;
import org.apache.spark.FetchFailed;
import org.apache.spark.MapOutputStatistics;
import org.apache.spark.MapOutputTracker;
import org.apache.spark.MapOutputTrackerMaster;
import org.apache.spark.Partition;
import org.apache.spark.Resubmitted$;
import org.apache.spark.ShuffleDependency;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.SparkContext$;
import org.apache.spark.SparkDriverExecutionException;
import org.apache.spark.SparkEnv;
import org.apache.spark.SparkEnv$;
import org.apache.spark.SparkException;
import org.apache.spark.Success$;
import org.apache.spark.TaskCommitDenied;
import org.apache.spark.TaskContext;
import org.apache.spark.TaskEndReason;
import org.apache.spark.TaskKilled;
import org.apache.spark.TaskResultLost$;
import org.apache.spark.UnknownReason$;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.executor.TaskMetrics;
import org.apache.spark.executor.TaskMetrics$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.internal.config.ConfigEntry;
import org.apache.spark.network.util.JavaUtils;
import org.apache.spark.partial.ApproximateActionListener;
import org.apache.spark.partial.ApproximateEvaluator;
import org.apache.spark.partial.PartialResult;
import org.apache.spark.rdd.RDD;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.rpc.RpcTimeout;
import org.apache.spark.scheduler.AccumulableInfo;
import org.apache.spark.scheduler.ActiveJob;
import org.apache.spark.scheduler.AllJobsCancelled$;
import org.apache.spark.scheduler.BeginEvent;
import org.apache.spark.scheduler.CompletionEvent;
import org.apache.spark.scheduler.DAGScheduler$;
import org.apache.spark.scheduler.DAGScheduler$$anonfun$org$apache$spark$scheduler$DAGScheduler$;
import org.apache.spark.scheduler.DAGSchedulerEventProcessLoop;
import org.apache.spark.scheduler.DAGSchedulerSource;
import org.apache.spark.scheduler.ExecutorAdded;
import org.apache.spark.scheduler.ExecutorLossReason;
import org.apache.spark.scheduler.ExecutorLost;
import org.apache.spark.scheduler.GettingResultEvent;
import org.apache.spark.scheduler.JobCancelled;
import org.apache.spark.scheduler.JobFailed;
import org.apache.spark.scheduler.JobGroupCancelled;
import org.apache.spark.scheduler.JobListener;
import org.apache.spark.scheduler.JobResult;
import org.apache.spark.scheduler.JobSubmitted;
import org.apache.spark.scheduler.JobSucceeded$;
import org.apache.spark.scheduler.JobWaiter;
import org.apache.spark.scheduler.LiveListenerBus;
import org.apache.spark.scheduler.MapStageSubmitted;
import org.apache.spark.scheduler.MapStatus;
import org.apache.spark.scheduler.OutputCommitCoordinator;
import org.apache.spark.scheduler.ResultStage;
import org.apache.spark.scheduler.ResultTask;
import org.apache.spark.scheduler.ShuffleMapStage;
import org.apache.spark.scheduler.ShuffleMapTask;
import org.apache.spark.scheduler.SparkListenerEvent;
import org.apache.spark.scheduler.SparkListenerExecutorMetricsUpdate;
import org.apache.spark.scheduler.SparkListenerJobEnd;
import org.apache.spark.scheduler.SparkListenerJobStart;
import org.apache.spark.scheduler.SparkListenerSpeculativeTaskSubmitted;
import org.apache.spark.scheduler.SparkListenerStageCompleted;
import org.apache.spark.scheduler.SparkListenerStageSubmitted;
import org.apache.spark.scheduler.SparkListenerTaskEnd;
import org.apache.spark.scheduler.SparkListenerTaskGettingResult;
import org.apache.spark.scheduler.SparkListenerTaskStart;
import org.apache.spark.scheduler.SpeculativeTaskSubmitted;
import org.apache.spark.scheduler.Stage;
import org.apache.spark.scheduler.StageCancelled;
import org.apache.spark.scheduler.StageInfo;
import org.apache.spark.scheduler.Task;
import org.apache.spark.scheduler.TaskInfo;
import org.apache.spark.scheduler.TaskLocation;
import org.apache.spark.scheduler.TaskScheduler;
import org.apache.spark.scheduler.TaskSet;
import org.apache.spark.scheduler.TaskSetFailed;
import org.apache.spark.scheduler.WorkerRemoved;
import org.apache.spark.serializer.Serializer;
import org.apache.spark.serializer.SerializerInstance;
import org.apache.spark.storage.BlockId;
import org.apache.spark.storage.BlockManager;
import org.apache.spark.storage.BlockManagerId;
import org.apache.spark.storage.BlockManagerMaster;
import org.apache.spark.storage.BlockManagerMessages;
import org.apache.spark.storage.StorageLevel;
import org.apache.spark.storage.StorageLevel$;
import org.apache.spark.util.AccumulatorV2;
import org.apache.spark.util.CallSite;
import org.apache.spark.util.Clock;
import org.apache.spark.util.ThreadUtils$;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Array$;
import scala.Function0;
import scala.Function1;
import scala.Function2;
import scala.MatchError;
import scala.None$;
import scala.Option;
import scala.Predef;
import scala.Predef$;
import scala.Product2;
import scala.Some;
import scala.StringContext;
import scala.Tuple2;
import scala.Tuple4;
import scala.collection.GenTraversable;
import scala.collection.GenTraversableOnce;
import scala.collection.IndexedSeq;
import scala.collection.IndexedSeq$;
import scala.collection.Iterable;
import scala.collection.Iterator;
import scala.collection.Map;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.SetLike;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.generic.Shrinkable;
import scala.collection.immutable.List;
import scala.collection.immutable.List$;
import scala.collection.immutable.Nil$;
import scala.collection.immutable.Range;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.ArrayStack;
import scala.collection.mutable.HashMap;
import scala.collection.mutable.HashSet;
import scala.collection.mutable.HashSet$;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.concurrent.Awaitable;
import scala.concurrent.Future;
import scala.concurrent.duration.Duration;
import scala.concurrent.duration.Duration$;
import scala.concurrent.duration.FiniteDuration;
import scala.concurrent.duration.package;
import scala.math.Ordering;
import scala.package$;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.reflect.ScalaSignature;
import scala.runtime.BooleanRef;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.runtime.NonLocalReturnControl;
import scala.runtime.ObjectRef;
import scala.runtime.RichInt$;
import scala.runtime.ScalaRunTime$;
import scala.runtime.TraitSetter;
import scala.util.Failure;
import scala.util.Success;
import scala.util.Try;
import scala.util.control.NonFatal$;

@ScalaSignature(bytes="\u0006\u0001\u001d\rf!B\u0001\u0003\u0001\u0011Q!\u0001\u0004#B\u000fN\u001b\u0007.\u001a3vY\u0016\u0014(BA\u0002\u0005\u0003%\u00198\r[3ek2,'O\u0003\u0002\u0006\r\u0005)1\u000f]1sW*\u0011q\u0001C\u0001\u0007CB\f7\r[3\u000b\u0003%\t1a\u001c:h'\r\u00011\"\u0005\t\u0003\u0019=i\u0011!\u0004\u0006\u0002\u001d\u0005)1oY1mC&\u0011\u0001#\u0004\u0002\u0007\u0003:L(+\u001a4\u0011\u0005I)R\"A\n\u000b\u0005Q!\u0011\u0001C5oi\u0016\u0014h.\u00197\n\u0005Y\u0019\"a\u0002'pO\u001eLgn\u001a\u0005\n1\u0001\u0011)\u0019!C\u0001\u0005e\t!a]2\u0016\u0003i\u0001\"a\u0007\u000f\u000e\u0003\u0011I!!\b\u0003\u0003\u0019M\u0003\u0018M]6D_:$X\r\u001f;\u0004\u0001!A\u0001\u0005\u0001B\u0001B\u0003%!$A\u0002tG\u0002B\u0011B\t\u0001\u0003\u0006\u0004%\tAA\u0012\u0002\u001bQ\f7o[*dQ\u0016$W\u000f\\3s+\u0005!\u0003CA\u0013'\u001b\u0005\u0011\u0011BA\u0014\u0003\u00055!\u0016m]6TG\",G-\u001e7fe\"A\u0011\u0006\u0001B\u0001B\u0003%A%\u0001\buCN\\7k\u00195fIVdWM\u001d\u0011\t\u0011-\u0002!\u0011!Q\u0001\n1\n1\u0002\\5ti\u0016tWM\u001d\"vgB\u0011Q%L\u0005\u0003]\t\u0011q\u0002T5wK2K7\u000f^3oKJ\u0014Uo\u001d\u0005\ta\u0001\u0011\t\u0011)A\u0005c\u0005\u0001R.\u00199PkR\u0004X\u000f\u001e+sC\u000e\\WM\u001d\t\u00037IJ!a\r\u0003\u0003-5\u000b\u0007oT;uaV$HK]1dW\u0016\u0014X*Y:uKJD\u0001\"\u000e\u0001\u0003\u0002\u0003\u0006IAN\u0001\u0013E2|7m['b]\u0006<WM]'bgR,'\u000f\u0005\u00028u5\t\u0001H\u0003\u0002:\t\u000591\u000f^8sC\u001e,\u0017BA\u001e9\u0005I\u0011En\\2l\u001b\u0006t\u0017mZ3s\u001b\u0006\u001cH/\u001a:\t\u0011u\u0002!\u0011!Q\u0001\ny\n1!\u001a8w!\tYr(\u0003\u0002A\t\tA1\u000b]1sW\u0016sg\u000f\u0003\u0005C\u0001\t\u0005\t\u0015!\u0003D\u0003\u0015\u0019Gn\\2l!\t!u)D\u0001F\u0015\t1E!\u0001\u0003vi&d\u0017B\u0001%F\u0005\u0015\u0019En\\2l\u0011\u0015Q\u0005\u0001\"\u0001L\u0003\u0019a\u0014N\\5u}QAA*\u0014(P!F\u00136\u000b\u0005\u0002&\u0001!)\u0001$\u0013a\u00015!)!%\u0013a\u0001I!)1&\u0013a\u0001Y!)\u0001'\u0013a\u0001c!)Q'\u0013a\u0001m!)Q(\u0013a\u0001}!9!)\u0013I\u0001\u0002\u0004\u0019\u0005\"\u0002&\u0001\t\u0003)Fc\u0001'W/\")\u0001\u0004\u0016a\u00015!)!\u0005\u0016a\u0001I!)!\n\u0001C\u00013R\u0011AJ\u0017\u0005\u00061a\u0003\rA\u0007\u0005\t9\u0002\u0011\r\u0011\"\u0001\u0005;\u0006iQ.\u001a;sS\u000e\u001c8k\\;sG\u0016,\u0012A\u0018\t\u0003K}K!\u0001\u0019\u0002\u0003%\u0011\u000buiU2iK\u0012,H.\u001a:T_V\u00148-\u001a\u0005\u0007E\u0002\u0001\u000b\u0011\u00020\u0002\u001d5,GO]5dgN{WO]2fA!AA\r\u0001b\u0001\n\u0003\u0011Q-A\u0005oKb$(j\u001c2JIV\ta\r\u0005\u0002h_6\t\u0001N\u0003\u0002jU\u00061\u0011\r^8nS\u000eT!a\u001b7\u0002\u0015\r|gnY;se\u0016tGO\u0003\u0002G[*\ta.\u0001\u0003kCZ\f\u0017B\u00019i\u00055\tEo\\7jG&sG/Z4fe\"1!\u000f\u0001Q\u0001\n\u0019\f!B\\3yi*{'-\u00133!\u0011\u0019!\b\u0001\"\u0001\u0003k\u0006aa.^7U_R\fGNS8cgV\ta\u000f\u0005\u0002\ro&\u0011\u00010\u0004\u0002\u0004\u0013:$\bb\u0002>\u0001\u0005\u0004%I!Z\u0001\f]\u0016DHo\u0015;bO\u0016LE\r\u0003\u0004}\u0001\u0001\u0006IAZ\u0001\r]\u0016DHo\u0015;bO\u0016LE\r\t\u0005\t}\u0002\u0011\r\u0011\"\u0001\u0003\u0006y!n\u001c2JIR{7\u000b^1hK&#7/\u0006\u0002\u0002\u0002A9\u00111AA\u0007m\u0006EQBAA\u0003\u0015\u0011\t9!!\u0003\u0002\u000f5,H/\u00192mK*\u0019\u00111B\u0007\u0002\u0015\r|G\u000e\\3di&|g.\u0003\u0003\u0002\u0010\u0005\u0015!a\u0002%bg\"l\u0015\r\u001d\t\u0006\u0003\u0007\t\u0019B^\u0005\u0005\u0003+\t)AA\u0004ICND7+\u001a;\t\u0011\u0005e\u0001\u0001)A\u0005\u0003\u0003\t\u0001C[8c\u0013\u0012$vn\u0015;bO\u0016LEm\u001d\u0011\t\u0015\u0005u\u0001A1A\u0005\u0002\t\ty\"\u0001\bti\u0006<W-\u00133U_N#\u0018mZ3\u0016\u0005\u0005\u0005\u0002cBA\u0002\u0003\u001b1\u00181\u0005\t\u0004K\u0005\u0015\u0012bAA\u0014\u0005\t)1\u000b^1hK\"A\u00111\u0006\u0001!\u0002\u0013\t\t#A\bti\u0006<W-\u00133U_N#\u0018mZ3!\u0011)\ty\u0003\u0001b\u0001\n\u0003\u0011\u0011\u0011G\u0001\u0014g\",hM\u001a7f\u0013\u0012$v.T1q'R\fw-Z\u000b\u0003\u0003g\u0001r!a\u0001\u0002\u000eY\f)\u0004E\u0002&\u0003oI1!!\u000f\u0003\u0005=\u0019\u0006.\u001e4gY\u0016l\u0015\r]*uC\u001e,\u0007\u0002CA\u001f\u0001\u0001\u0006I!a\r\u0002)MDWO\u001a4mK&#Gk\\'baN#\u0018mZ3!\u0011)\t\t\u0005\u0001b\u0001\n\u0003\u0011\u00111I\u0001\u0011U>\u0014\u0017\n\u001a+p\u0003\u000e$\u0018N^3K_\n,\"!!\u0012\u0011\u000f\u0005\r\u0011Q\u0002<\u0002HA\u0019Q%!\u0013\n\u0007\u0005-#AA\u0005BGRLg/\u001a&pE\"A\u0011q\n\u0001!\u0002\u0013\t)%A\tk_\nLE\rV8BGRLg/\u001a&pE\u0002B!\"a\u0015\u0001\u0005\u0004%\tAAA+\u000359\u0018-\u001b;j]\u001e\u001cF/Y4fgV\u0011\u0011q\u000b\t\u0007\u0003\u0007\t\u0019\"a\t\t\u0011\u0005m\u0003\u0001)A\u0005\u0003/\nab^1ji&twm\u0015;bO\u0016\u001c\b\u0005\u0003\u0006\u0002`\u0001\u0011\r\u0011\"\u0001\u0003\u0003+\nQB];o]&twm\u0015;bO\u0016\u001c\b\u0002CA2\u0001\u0001\u0006I!a\u0016\u0002\u001dI,hN\\5oON#\u0018mZ3tA!Q\u0011q\r\u0001C\u0002\u0013\u0005!!!\u0016\u0002\u0019\u0019\f\u0017\u000e\\3e'R\fw-Z:\t\u0011\u0005-\u0004\u0001)A\u0005\u0003/\nQBZ1jY\u0016$7\u000b^1hKN\u0004\u0003BCA8\u0001\t\u0007I\u0011\u0001\u0002\u0002r\u0005Q\u0011m\u0019;jm\u0016TuNY:\u0016\u0005\u0005M\u0004CBA\u0002\u0003'\t9\u0005\u0003\u0005\u0002x\u0001\u0001\u000b\u0011BA:\u0003-\t7\r^5wK*{'m\u001d\u0011\t\u0013\u0005m\u0004A1A\u0005\n\u0005u\u0014!C2bG\",Gj\\2t+\t\ty\bE\u0004\u0002\u0004\u00055a/!!\u0011\r\u0005\r\u00151SAM\u001d\u0011\t))a$\u000f\t\u0005\u001d\u0015QR\u0007\u0003\u0003\u0013S1!a#\u001f\u0003\u0019a$o\\8u}%\ta\"C\u0002\u0002\u00126\tq\u0001]1dW\u0006<W-\u0003\u0003\u0002\u0016\u0006]%AC%oI\u0016DX\rZ*fc*\u0019\u0011\u0011S\u0007\u0011\r\u0005\r\u00151TAP\u0013\u0011\ti*a&\u0003\u0007M+\u0017\u000fE\u0002&\u0003CK1!a)\u0003\u00051!\u0016m]6M_\u000e\fG/[8o\u0011!\t9\u000b\u0001Q\u0001\n\u0005}\u0014AC2bG\",Gj\\2tA!I\u00111\u0016\u0001C\u0002\u0013%\u0011QV\u0001\fM\u0006LG.\u001a3Fa>\u001c\u0007.\u0006\u0002\u00020BA\u00111AA\u0007\u0003c\u000by\f\u0005\u0003\u00024\u0006efb\u0001\u0007\u00026&\u0019\u0011qW\u0007\u0002\rA\u0013X\rZ3g\u0013\u0011\tY,!0\u0003\rM#(/\u001b8h\u0015\r\t9,\u0004\t\u0004\u0019\u0005\u0005\u0017bAAb\u001b\t!Aj\u001c8h\u0011!\t9\r\u0001Q\u0001\n\u0005=\u0016\u0001\u00044bS2,G-\u00129pG\"\u0004\u0003BCAf\u0001\t\u0007I\u0011\u0001\u0002\u0002N\u00069r.\u001e;qkR\u001cu.\\7ji\u000e{wN\u001d3j]\u0006$xN]\u000b\u0003\u0003\u001f\u00042!JAi\u0013\r\t\u0019N\u0001\u0002\u0018\u001fV$\b/\u001e;D_6l\u0017\u000e^\"p_J$\u0017N\\1u_JD\u0001\"a6\u0001A\u0003%\u0011qZ\u0001\u0019_V$\b/\u001e;D_6l\u0017\u000e^\"p_J$\u0017N\\1u_J\u0004\u0003\"CAn\u0001\t\u0007I\u0011BAo\u0003E\u0019Gn\\:ve\u0016\u001cVM]5bY&TXM]\u000b\u0003\u0003?\u0004B!!9\u0002h6\u0011\u00111\u001d\u0006\u0004\u0003K$\u0011AC:fe&\fG.\u001b>fe&!\u0011\u0011^Ar\u0005I\u0019VM]5bY&TXM]%ogR\fgnY3\t\u0011\u00055\b\u0001)A\u0005\u0003?\f!c\u00197pgV\u0014XmU3sS\u0006d\u0017N_3sA!I\u0011\u0011\u001f\u0001C\u0002\u0013%\u00111_\u0001\u001aI&\u001c\u0018\r\u001c7poN#\u0018mZ3SKR\u0014\u0018PR8s)\u0016\u001cH/\u0006\u0002\u0002vB\u0019A\"a>\n\u0007\u0005eXBA\u0004C_>dW-\u00198\t\u0011\u0005u\b\u0001)A\u0005\u0003k\f!\u0004Z5tC2dwn^*uC\u001e,'+\u001a;ss\u001a{'\u000fV3ti\u0002B!B!\u0001\u0001\u0005\u0004%\tAAAz\u0003\u0011*hNU3hSN$XM](viB,Ho\u00148I_N$xJ\u001c$fi\u000eDg)Y5mkJ,\u0007\u0002\u0003B\u0003\u0001\u0001\u0006I!!>\u0002KUt'+Z4jgR,'oT;uaV$xJ\u001c%pgR|eNR3uG\"4\u0015-\u001b7ve\u0016\u0004\u0003\"\u0003B\u0005\u0001\t\u0007I\u0011\u0001\u0002v\u0003mi\u0017\r_\"p]N,7-\u001e;jm\u0016\u001cF/Y4f\u0003R$X-\u001c9ug\"9!Q\u0002\u0001!\u0002\u00131\u0018\u0001H7bq\u000e{gn]3dkRLg/Z*uC\u001e,\u0017\t\u001e;f[B$8\u000f\t\u0005\n\u0005#\u0001!\u0019!C\u0005\u0005'\t\u0001#\\3tg\u0006<WmU2iK\u0012,H.\u001a:\u0016\u0005\tU\u0001\u0003\u0002B\f\u00053i\u0011A[\u0005\u0004\u00057Q'\u0001G*dQ\u0016$W\u000f\\3e\u000bb,7-\u001e;peN+'O^5dK\"A!q\u0004\u0001!\u0002\u0013\u0011)\"A\tnKN\u001c\u0018mZ3TG\",G-\u001e7fe\u0002B!Ba\t\u0001\u0005\u0004%\tA\u0001B\u0013\u0003A)g/\u001a8u!J|7-Z:t\u0019>|\u0007/\u0006\u0002\u0003(A\u0019QE!\u000b\n\u0007\t-\"A\u0001\u000fE\u0003\u001e\u001b6\r[3ek2,'/\u0012<f]R\u0004&o\\2fgNdun\u001c9\t\u0011\t=\u0002\u0001)A\u0005\u0005O\t\u0011#\u001a<f]R\u0004&o\\2fgNdun\u001c9!\u0011\u001d\u0011\u0019\u0004\u0001C\u0001\u0005k\t1\u0002^1tWN#\u0018M\u001d;fIR1!q\u0007B\u001f\u0005?\u00022\u0001\u0004B\u001d\u0013\r\u0011Y$\u0004\u0002\u0005+:LG\u000f\u0003\u0005\u0003@\tE\u0002\u0019\u0001B!\u0003\u0011!\u0018m]61\t\t\r#Q\n\t\u0006K\t\u0015#\u0011J\u0005\u0004\u0005\u000f\u0012!\u0001\u0002+bg.\u0004BAa\u0013\u0003N1\u0001A\u0001\u0004B(\u0005{\t\t\u0011!A\u0003\u0002\tE#aA0%cE!!1\u000bB-!\ra!QK\u0005\u0004\u0005/j!a\u0002(pi\"Lgn\u001a\t\u0004\u0019\tm\u0013b\u0001B/\u001b\t\u0019\u0011I\\=\t\u0011\t\u0005$\u0011\u0007a\u0001\u0005G\n\u0001\u0002^1tW&sgm\u001c\t\u0004K\t\u0015\u0014b\u0001B4\u0005\tAA+Y:l\u0013:4w\u000eC\u0004\u0003l\u0001!\tA!\u001c\u0002#Q\f7o[$fiRLgn\u001a*fgVdG\u000f\u0006\u0003\u00038\t=\u0004\u0002\u0003B1\u0005S\u0002\rAa\u0019\t\u000f\tM\u0004\u0001\"\u0001\u0003v\u0005IA/Y:l\u000b:$W\r\u001a\u000b\r\u0005o\u00119Ha!\u0003\u000e\nE%1\u0016\u0005\t\u0005\u0011\t\b1\u0001\u0003zA\"!1\u0010B@!\u0015)#Q\tB?!\u0011\u0011YEa \u0005\u0019\t\u0005%qOA\u0001\u0002\u0003\u0015\tA!\u0015\u0003\u0007}##\u0007\u0003\u0005\u0003\u0006\nE\u0004\u0019\u0001BD\u0003\u0019\u0011X-Y:p]B\u00191D!#\n\u0007\t-EAA\u0007UCN\\WI\u001c3SK\u0006\u001cxN\u001c\u0005\t\u0005\u001f\u0013\t\b1\u0001\u0003Z\u00051!/Z:vYRD\u0001Ba%\u0003r\u0001\u0007!QS\u0001\rC\u000e\u001cW/\\+qI\u0006$Xm\u001d\t\u0007\u0003\u0007\u000bYJa&1\r\te%\u0011\u0015BT!\u001d!%1\u0014BP\u0005KK1A!(F\u00055\t5mY;nk2\fGo\u001c:WeA!!1\nBQ\t1\u0011\u0019K!%\u0002\u0002\u0003\u0005)\u0011\u0001B)\u0005\ryFe\r\t\u0005\u0005\u0017\u00129\u000b\u0002\u0007\u0003*\nE\u0015\u0011!A\u0001\u0006\u0003\u0011\tFA\u0002`IQB\u0001B!\u0019\u0003r\u0001\u0007!1\r\u0005\b\u0005_\u0003A\u0011\u0001BY\u0003e)\u00070Z2vi>\u0014\b*Z1si\n,\u0017\r\u001e*fG\u0016Lg/\u001a3\u0015\u0011\u0005U(1\u0017B\\\u0005\u001bD\u0001B!.\u0003.\u0002\u0007\u0011\u0011W\u0001\u0007Kb,7-\u00133\t\u0011\tM%Q\u0016a\u0001\u0005s\u0003R\u0001\u0004B^\u0005K1A!0\u000e\u0005\u0015\t%O]1z!%a!\u0011YA`mZ\u0014)-C\u0002\u0003D6\u0011a\u0001V;qY\u0016$\u0004CBAB\u00037\u00139\rE\u0002&\u0005\u0013L1Aa3\u0003\u0005=\t5mY;nk2\f'\r\\3J]\u001a|\u0007\u0002\u0003Bh\u0005[\u0003\rA!5\u0002\u001d\tdwnY6NC:\fw-\u001a:JIB\u0019qGa5\n\u0007\tU\u0007H\u0001\bCY>\u001c7.T1oC\u001e,'/\u00133\t\u000f\te\u0007\u0001\"\u0001\u0003\\\u0006aQ\r_3dkR|'\u000fT8tiR1!q\u0007Bo\u0005?D\u0001B!.\u0003X\u0002\u0007\u0011\u0011\u0017\u0005\t\u0005\u000b\u00139\u000e1\u0001\u0003bB\u0019QEa9\n\u0007\t\u0015(A\u0001\nFq\u0016\u001cW\u000f^8s\u0019>\u001c8OU3bg>t\u0007b\u0002Bu\u0001\u0011\u0005!1^\u0001\u000eo>\u00148.\u001a:SK6|g/\u001a3\u0015\u0011\t]\"Q\u001eBy\u0005kD\u0001Ba<\u0003h\u0002\u0007\u0011\u0011W\u0001\to>\u00148.\u001a:JI\"A!1\u001fBt\u0001\u0004\t\t,\u0001\u0003i_N$\b\u0002\u0003B|\u0005O\u0004\r!!-\u0002\u000f5,7o]1hK\"9!1 \u0001\u0005\u0002\tu\u0018!D3yK\u000e,Ho\u001c:BI\u0012,G\r\u0006\u0004\u00038\t}8\u0011\u0001\u0005\t\u0005k\u0013I\u00101\u0001\u00022\"A!1\u001fB}\u0001\u0004\t\t\fC\u0004\u0004\u0006\u0001!\taa\u0002\u0002\u001bQ\f7o[*fi\u001a\u000b\u0017\u000e\\3e)!\u00119d!\u0003\u0004\u0014\rU\u0001\u0002CB\u0006\u0007\u0007\u0001\ra!\u0004\u0002\u000fQ\f7o[*fiB\u0019Qea\u0004\n\u0007\rE!AA\u0004UCN\\7+\u001a;\t\u0011\t\u001551\u0001a\u0001\u0003cC\u0001ba\u0006\u0004\u0004\u0001\u00071\u0011D\u0001\nKb\u001cW\r\u001d;j_:\u0004R\u0001DB\u000e\u0007?I1a!\b\u000e\u0005\u0019y\u0005\u000f^5p]B!\u00111QB\u0011\u0013\u0011\u0019\u0019#a&\u0003\u0013QC'o\\<bE2,\u0007bBB\u0014\u0001\u0011\u00051\u0011F\u0001\u0019gB,7-\u001e7bi&4X\rV1tWN+(-\\5ui\u0016$G\u0003\u0002B\u001c\u0007WA\u0001Ba\u0010\u0004&\u0001\u00071Q\u0006\u0019\u0005\u0007_\u0019\u0019\u0004E\u0003&\u0005\u000b\u001a\t\u0004\u0005\u0003\u0003L\rMB\u0001DB\u001b\u0007W\t\t\u0011!A\u0003\u0002\tE#aA0%k!A1\u0011\b\u0001\u0005\u0002\t\u0019Y$\u0001\u0007hKR\u001c\u0015m\u00195f\u0019>\u001c7\u000f\u0006\u0003\u0002\u0002\u000eu\u0002\u0002CB \u0007o\u0001\ra!\u0011\u0002\u0007I$G\r\r\u0003\u0004D\r=\u0003CBB#\u0007\u0013\u001ai%\u0004\u0002\u0004H)\u00191q\b\u0003\n\t\r-3q\t\u0002\u0004%\u0012#\u0005\u0003\u0002B&\u0007\u001f\"Ab!\u0015\u0004>\u0005\u0005\t\u0011!B\u0001\u0005#\u00121a\u0018\u00137\u0011\u001d\u0019)\u0006\u0001C\u0005\u0007/\nab\u00197fCJ\u001c\u0015m\u00195f\u0019>\u001c7\u000f\u0006\u0002\u00038!911\f\u0001\u0005\n\ru\u0013AG4fi>\u00138I]3bi\u0016\u001c\u0006.\u001e4gY\u0016l\u0015\r]*uC\u001e,GCBA\u001b\u0007?\u001ai\b\u0003\u0005\u0004b\re\u0003\u0019AB2\u0003)\u0019\b.\u001e4gY\u0016$U\r\u001d\u0019\t\u0007K\u001aiga\u001d\u0004zAI1da\u001a\u0004l\rE4qO\u0005\u0004\u0007S\"!!E*ik\u001a4G.\u001a#fa\u0016tG-\u001a8dsB!!1JB7\t1\u0019yga\u0018\u0002\u0002\u0003\u0005)\u0011\u0001B)\u0005\ryFe\u000e\t\u0005\u0005\u0017\u001a\u0019\b\u0002\u0007\u0004v\r}\u0013\u0011!A\u0001\u0006\u0003\u0011\tFA\u0002`Ia\u0002BAa\u0013\u0004z\u0011a11PB0\u0003\u0003\u0005\tQ!\u0001\u0003R\t\u0019q\fJ\u001d\t\u000f\r}4\u0011\fa\u0001m\u0006Qa-\u001b:ti*{'-\u00133\t\u000f\r\r\u0005\u0001\"\u0001\u0004\u0006\u0006)2M]3bi\u0016\u001c\u0006.\u001e4gY\u0016l\u0015\r]*uC\u001e,GCBA\u001b\u0007\u000f\u001by\n\u0003\u0005\u0004b\r\u0005\u0005\u0019ABEa!\u0019Yia$\u0004\u0016\u000em\u0005#C\u000e\u0004h\r551SBM!\u0011\u0011Yea$\u0005\u0019\rE5qQA\u0001\u0002\u0003\u0015\tA!\u0015\u0003\t}#\u0013\u0007\r\t\u0005\u0005\u0017\u001a)\n\u0002\u0007\u0004\u0018\u000e\u001d\u0015\u0011!A\u0001\u0006\u0003\u0011\tF\u0001\u0003`IE\n\u0004\u0003\u0002B&\u00077#Ab!(\u0004\b\u0006\u0005\t\u0011!B\u0001\u0005#\u0012Aa\u0018\u00132e!91\u0011UBA\u0001\u00041\u0018!\u00026pE&#\u0007bBBS\u0001\u0011%1qU\u0001\u0012GJ,\u0017\r^3SKN,H\u000e^*uC\u001e,G\u0003DBU\u0007_\u001bYl!9\u0004h\u000e%\bcA\u0013\u0004,&\u00191Q\u0016\u0002\u0003\u0017I+7/\u001e7u'R\fw-\u001a\u0005\t\u0007\u0019\u0019\u000b1\u0001\u00042B\"11WB\\!\u0019\u0019)e!\u0013\u00046B!!1JB\\\t1\u0019Ila,\u0002\u0002\u0003\u0005)\u0011\u0001B)\u0005\u0011yF%M\u001a\t\u0011\ru61\u0015a\u0001\u0007\u000bAAZ;oGB\"1\u0011YBo!%a11YBd\u0007\u001b\u001cY.C\u0002\u0004F6\u0011\u0011BR;oGRLwN\u001c\u001a\u0011\u0007m\u0019I-C\u0002\u0004L\u0012\u00111\u0002V1tW\u000e{g\u000e^3yiB\"1qZBl!\u0019\t\u0019i!5\u0004V&!11[AL\u0005!IE/\u001a:bi>\u0014\b\u0003\u0002B&\u0007/$Ab!7\u0004<\u0006\u0005\t\u0011!B\u0001\u0005#\u0012Aa\u0018\u00132iA!!1JBo\t1\u0019yna/\u0002\u0002\u0003\u0005)\u0011\u0001B)\u0005\u0011yF%M\u001b\t\u0011\r\r81\u0015a\u0001\u0007K\f!\u0002]1si&$\u0018n\u001c8t!\u0011a!1\u0018<\t\u000f\r\u000561\u0015a\u0001m\"A11^BR\u0001\u0004\u0019i/\u0001\u0005dC2d7+\u001b;f!\r!5q^\u0005\u0004\u0007c,%\u0001C\"bY2\u001c\u0016\u000e^3\t\u000f\rU\b\u0001\"\u0003\u0004x\u00069r-\u001a;Pe\u000e\u0013X-\u0019;f!\u0006\u0014XM\u001c;Ti\u0006<Wm\u001d\u000b\u0007\u0007s\u001cy\u0010b\u0003\u0011\r\u0005\r51`A\u0012\u0013\u0011\u0019i0a&\u0003\t1K7\u000f\u001e\u0005\t\u0007\u0019\u0019\u00101\u0001\u0005\u0002A\"A1\u0001C\u0004!\u0019\u0019)e!\u0013\u0005\u0006A!!1\nC\u0004\t1!Iaa@\u0002\u0002\u0003\u0005)\u0011\u0001B)\u0005\u0011yF%\r\u001c\t\u000f\r}41\u001fa\u0001m\"9Aq\u0002\u0001\u0005\n\u0011E\u0011!J4fi6K7o]5oO\u0006s7-Z:u_J\u001c\u0006.\u001e4gY\u0016$U\r]3oI\u0016t7-[3t)\u0011!\u0019\u0002b\f\u0011\r\u0005\rAQ\u0003C\r\u0013\u0011!9\"!\u0002\u0003\u0015\u0005\u0013(/Y=Ti\u0006\u001c7\u000e\r\u0005\u0005\u001c\u0011}AQ\u0005C\u0016!%Y2q\rC\u000f\tG!I\u0003\u0005\u0003\u0003L\u0011}A\u0001\u0004C\u0011\t\u001b\t\t\u0011!A\u0003\u0002\tE#\u0001B0%ca\u0002BAa\u0013\u0005&\u0011aAq\u0005C\u0007\u0003\u0003\u0005\tQ!\u0001\u0003R\t!q\fJ\u0019:!\u0011\u0011Y\u0005b\u000b\u0005\u0019\u00115BQBA\u0001\u0002\u0003\u0015\tA!\u0015\u0003\t}##\u0007\r\u0005\t\u0007!i\u00011\u0001\u00052A\"A1\u0007C\u001c!\u0019\u0019)e!\u0013\u00056A!!1\nC\u001c\t1!I\u0004b\f\u0002\u0002\u0003\u0005)\u0011\u0001B)\u0005\u0011yF%M\u001c\t\u0011\u0011u\u0002\u0001\"\u0001\u0003\t\tacZ3u'\",hM\u001a7f\t\u0016\u0004XM\u001c3f]\u000eLWm\u001d\u000b\u0005\t\u0003\"I\u0006\u0005\u0004\u0002\u0004\u0005MA1\t\u0019\t\t\u000b\"I\u0005b\u0014\u0005VAI1da\u001a\u0005H\u00115C1\u000b\t\u0005\u0005\u0017\"I\u0005\u0002\u0007\u0005L\u0011m\u0012\u0011!A\u0001\u0006\u0003\u0011\tF\u0001\u0003`II:\u0004\u0003\u0002B&\t\u001f\"A\u0002\"\u0015\u0005<\u0005\u0005\t\u0011!B\u0001\u0005#\u0012Aa\u0018\u00133qA!!1\nC+\t1!9\u0006b\u000f\u0002\u0002\u0003\u0005)\u0011\u0001B)\u0005\u0011yFEM\u001d\t\u0011\r}B1\ba\u0001\t7\u0002D\u0001\"\u0018\u0005bA11QIB%\t?\u0002BAa\u0013\u0005b\u0011aA1\rC-\u0003\u0003\u0005\tQ!\u0001\u0003R\t!q\f\n\u001a7\u0011\u001d!9\u0007\u0001C\u0005\tS\nacZ3u\u001b&\u001c8/\u001b8h!\u0006\u0014XM\u001c;Ti\u0006<Wm\u001d\u000b\u0005\u0007s$Y\u0007\u0003\u0005\u0005n\u0011\u0015\u0004\u0019AA\u0012\u0003\u0015\u0019H/Y4f\u0011\u001d!\t\b\u0001C\u0005\tg\na#\u001e9eCR,'j\u001c2JIN#\u0018mZ3JI6\u000b\u0007o\u001d\u000b\u0007\u0005o!)\bb\u001e\t\u000f\r\u0005Fq\u000ea\u0001m\"AAQ\u000eC8\u0001\u0004\t\u0019\u0003C\u0004\u0005|\u0001!I\u0001\" \u0002M\rdW-\u00198vaN#\u0018\r^3G_JTuNY!oI&sG-\u001a9f]\u0012,g\u000e^*uC\u001e,7\u000f\u0006\u0003\u00038\u0011}\u0004\u0002\u0003CA\ts\u0002\r!a\u0012\u0002\u0007)|'\rC\u0004\u0005\u0006\u0002!\t\u0001b\"\u0002\u0013M,(-\\5u\u0015>\u0014WC\u0002CE\t;#\u0019\n\u0006\b\u0005\f\u0012]E\u0011\u0015CT\tW#i\u000bb-\u0011\u000b\u0015\"i\t\"%\n\u0007\u0011=%AA\u0005K_\n<\u0016-\u001b;feB!!1\nCJ\t!!)\nb!C\u0002\tE#!A+\t\u0011\r}B1\u0011a\u0001\t3\u0003ba!\u0012\u0004J\u0011m\u0005\u0003\u0002B&\t;#\u0001\u0002b(\u0005\u0004\n\u0007!\u0011\u000b\u0002\u0002)\"A1Q\u0018CB\u0001\u0004!\u0019\u000bE\u0005\r\u0007\u0007\u001c9\r\"*\u0005\u0012B1\u00111QBi\t7C\u0001ba9\u0005\u0004\u0002\u0007A\u0011\u0016\t\u0006\u0003\u0007\u000bYJ\u001e\u0005\t\u0007W$\u0019\t1\u0001\u0004n\"AAq\u0016CB\u0001\u0004!\t,A\u0007sKN,H\u000e\u001e%b]\u0012dWM\u001d\t\t\u0019\r\rg\u000f\"%\u00038!AAQ\u0017CB\u0001\u0004!9,\u0001\u0006qe>\u0004XM\u001d;jKN\u0004B\u0001\"/\u0005<6\tA.C\u0002\u0005>2\u0014!\u0002\u0015:pa\u0016\u0014H/[3t\u0011\u001d!\t\r\u0001C\u0001\t\u0007\faA];o\u0015>\u0014WC\u0002Cc\t\u001b$9\u000e\u0006\b\u00038\u0011\u001dGq\u001aCm\t7$i\u000e\"9\t\u0011\r}Bq\u0018a\u0001\t\u0013\u0004ba!\u0012\u0004J\u0011-\u0007\u0003\u0002B&\t\u001b$\u0001\u0002b(\u0005@\n\u0007!\u0011\u000b\u0005\t\u0007{#y\f1\u0001\u0005RBIAba1\u0004H\u0012MGQ\u001b\t\u0007\u0003\u0007\u001b\t\u000eb3\u0011\t\t-Cq\u001b\u0003\t\t+#yL1\u0001\u0003R!A11\u001dC`\u0001\u0004!I\u000b\u0003\u0005\u0004l\u0012}\u0006\u0019ABw\u0011!!y\u000bb0A\u0002\u0011}\u0007\u0003\u0003\u0007\u0004DZ$)Na\u000e\t\u0011\u0011UFq\u0018a\u0001\toCq\u0001\":\u0001\t\u0003!9/A\tsk:\f\u0005\u000f\u001d:pq&l\u0017\r^3K_\n,\u0002\u0002\";\u0006\u0004\u00155A\u0011 \u000b\u000f\tW$i0\"\u0002\u0006\u0010\u0015eQ1DC\u0010!\u0019!i\u000fb=\u0005x6\u0011Aq\u001e\u0006\u0004\tc$\u0011a\u00029beRL\u0017\r\\\u0005\u0005\tk$yOA\u0007QCJ$\u0018.\u00197SKN,H\u000e\u001e\t\u0005\u0005\u0017\"I\u0010\u0002\u0005\u0005|\u0012\r(\u0019\u0001B)\u0005\u0005\u0011\u0006\u0002CB \tG\u0004\r\u0001b@\u0011\r\r\u00153\u0011JC\u0001!\u0011\u0011Y%b\u0001\u0005\u0011\u0011}E1\u001db\u0001\u0005#B\u0001b!0\u0005d\u0002\u0007Qq\u0001\t\n\u0019\r\r7qYC\u0005\u000b\u0017\u0001b!a!\u0004R\u0016\u0005\u0001\u0003\u0002B&\u000b\u001b!\u0001\u0002\"&\u0005d\n\u0007!\u0011\u000b\u0005\t\u000b#!\u0019\u000f1\u0001\u0006\u0014\u0005IQM^1mk\u0006$xN\u001d\t\t\t[,)\"b\u0003\u0005x&!Qq\u0003Cx\u0005Q\t\u0005\u000f\u001d:pq&l\u0017\r^3Fm\u0006dW/\u0019;pe\"A11\u001eCr\u0001\u0004\u0019i\u000f\u0003\u0005\u0006\u001e\u0011\r\b\u0019AA`\u0003\u001d!\u0018.\\3pkRD\u0001\u0002\".\u0005d\u0002\u0007Aq\u0017\u0005\b\u000bG\u0001A\u0011AC\u0013\u00039\u0019XOY7ji6\u000b\u0007o\u0015;bO\u0016,\u0002\"b\n\u0006:\u0015}RQ\t\u000b\u000b\u000bS)\t$\"\u0013\u0006T\u0015U\u0003#B\u0013\u0005\u000e\u0016-\u0002cA\u000e\u0006.%\u0019Qq\u0006\u0003\u0003'5\u000b\u0007oT;uaV$8\u000b^1uSN$\u0018nY:\t\u0011\u0015MR\u0011\u0005a\u0001\u000bk\t!\u0002Z3qK:$WM\\2z!%Y2qMC\u001c\u000b{)\u0019\u0005\u0005\u0003\u0003L\u0015eB\u0001CC\u001e\u000bC\u0011\rA!\u0015\u0003\u0003-\u0003BAa\u0013\u0006@\u0011AQ\u0011IC\u0011\u0005\u0004\u0011\tFA\u0001W!\u0011\u0011Y%\"\u0012\u0005\u0011\u0015\u001dS\u0011\u0005b\u0001\u0005#\u0012\u0011a\u0011\u0005\t\u000b\u0017*\t\u00031\u0001\u0006N\u0005A1-\u00197mE\u0006\u001c7\u000eE\u0004\r\u000b\u001f*YCa\u000e\n\u0007\u0015ESBA\u0005Gk:\u001cG/[8oc!A11^C\u0011\u0001\u0004\u0019i\u000f\u0003\u0005\u00056\u0016\u0005\u0002\u0019\u0001C\\\u0011\u001d)I\u0006\u0001C\u0001\u000b7\n\u0011bY1oG\u0016d'j\u001c2\u0015\r\t]RQLC0\u0011\u001d\u0019\t+b\u0016A\u0002YD\u0001B!\"\u0006X\u0001\u0007Q\u0011\r\t\u0006\u0019\rm\u0011\u0011\u0017\u0005\b\u000bK\u0002A\u0011AC4\u00039\u0019\u0017M\\2fY*{'m\u0012:pkB$BAa\u000e\u0006j!AQ1NC2\u0001\u0004\t\t,A\u0004he>,\b/\u00133\t\u000f\u0015=\u0004\u0001\"\u0001\u0004X\u0005i1-\u00198dK2\fE\u000e\u001c&pEND\u0001\"b\u001d\u0001\t\u0003\u00111qK\u0001\u0010I>\u001c\u0015M\\2fY\u0006cGNS8cg\"9Qq\u000f\u0001\u0005\u0002\u0015e\u0014aC2b]\u000e,Gn\u0015;bO\u0016$bAa\u000e\u0006|\u0015}\u0004bBC?\u000bk\u0002\rA^\u0001\bgR\fw-Z%e\u0011!\u0011))\"\u001eA\u0002\u0015\u0005\u0004bBCB\u0001\u0011\u0005QQQ\u0001\u0010W&dG\u000eV1tW\u0006#H/Z7qiRA\u0011Q_CD\u000b\u0017+y\t\u0003\u0005\u0006\n\u0016\u0005\u0005\u0019AA`\u0003\u0019!\u0018m]6JI\"AQQRCA\u0001\u0004\t)0A\bj]R,'O];qiRC'/Z1e\u0011!\u0011))\"!A\u0002\u0005E\u0006\u0002CCJ\u0001\u0011\u0005!aa\u0016\u0002)I,7/\u001e2nSR4\u0015-\u001b7fIN#\u0018mZ3t\u0011\u001d)9\n\u0001C\u0005\u000b3\u000b\u0001d];c[&$x+Y5uS:<7\t[5mIN#\u0018mZ3t)\u0011\u00119$b'\t\u0011\u0015uUQ\u0013a\u0001\u0003G\ta\u0001]1sK:$\bbBCQ\u0001\u0011%Q1U\u0001\u0012C\u000e$\u0018N^3K_\n4uN]*uC\u001e,G\u0003BCS\u000bO\u0003B\u0001DB\u000em\"AAQNCP\u0001\u0004\t\u0019\u0003\u0003\u0005\u0006,\u0002!\tAACW\u0003]A\u0017M\u001c3mK*{'m\u0012:pkB\u001c\u0015M\\2fY2,G\r\u0006\u0003\u00038\u0015=\u0006\u0002CC6\u000bS\u0003\r!!-\t\u0011\u0015M\u0006\u0001\"\u0001\u0003\u000bk\u000b\u0001\u0003[1oI2,')Z4j]\u00163XM\u001c;\u0015\r\t]RqWCb\u0011!\u0011y$\"-A\u0002\u0015e\u0006\u0007BC^\u000b\u0003R!\nB#\u000b{\u0003BAa\u0013\u0006@\u0012aQ\u0011YC\\\u0003\u0003\u0005\tQ!\u0001\u0003R\t!q\f\n\u001b3\u0011!\u0011\t'\"-A\u0002\t\r\u0004\u0002CCd\u0001\u0011\u0005!!\"3\u0002=!\fg\u000e\u001a7f'B,7-\u001e7bi&4X\rV1tWN+(-\\5ui\u0016$G\u0003\u0002B\u001c\u000b\u0017D\u0001Ba\u0010\u0006F\u0002\u0007QQ\u001a\u0019\u0005\u000b\u001f,\u0019\u000eE\u0003&\u0005\u000b*\t\u000e\u0005\u0003\u0003L\u0015MG\u0001DCk\u000b\u0017\f\t\u0011!A\u0003\u0002\tE#\u0001B0%iMB\u0001\"\"7\u0001\t\u0003\u0011Q1\\\u0001\u0014Q\u0006tG\r\\3UCN\\7+\u001a;GC&dW\r\u001a\u000b\t\u0005o)i.b8\u0006b\"A11BCl\u0001\u0004\u0019i\u0001\u0003\u0005\u0003\u0006\u0016]\u0007\u0019AAY\u0011!\u00199\"b6A\u0002\re\u0001\u0002CCs\u0001\u0011\u0005!aa\u0016\u00023\rdW-\u00198Va\u00063G/\u001a:TG\",G-\u001e7feN#x\u000e\u001d\u0005\t\u000bS\u0004A\u0011\u0001\u0002\u0006l\u0006\u0019\u0002.\u00198eY\u0016<U\r\u001e+bg.\u0014Vm];miR!!qGCw\u0011!\u0011\t'b:A\u0002\t\r\u0004\u0002CCy\u0001\u0011\u0005!!b=\u0002%!\fg\u000e\u001a7f\u0015>\u00147+\u001e2nSR$X\r\u001a\u000b\u0011\u0005o))0b>\u0007\u0006\u0019maQ\u0004D\u0010\rSAqa!)\u0006p\u0002\u0007a\u000f\u0003\u0005\u0006z\u0016=\b\u0019AC~\u0003!1\u0017N\\1m%\u0012#\u0005\u0007BC\r\u0003\u0001ba!\u0012\u0004J\u0015}\b\u0003\u0002B&\r\u0003!ABb\u0001\u0006x\u0006\u0005\t\u0011!B\u0001\u0005#\u0012Aa\u0018\u00135i!A1QXCx\u0001\u000419\u0001\r\u0003\u0007\n\u0019]\u0001#\u0003\u0007\u0004D\u000e\u001dg1\u0002D\u000ba\u00111iA\"\u0005\u0011\r\u0005\r5\u0011\u001bD\b!\u0011\u0011YE\"\u0005\u0005\u0019\u0019MaQAA\u0001\u0002\u0003\u0015\tA!\u0015\u0003\t}#C'\u000e\t\u0005\u0005\u001729\u0002\u0002\u0007\u0007\u001a\u0019\u0015\u0011\u0011!A\u0001\u0006\u0003\u0011\tF\u0001\u0003`IQ2\u0004\u0002CBr\u000b_\u0004\ra!:\t\u0011\r-Xq\u001ea\u0001\u0007[D\u0001B\"\t\u0006p\u0002\u0007a1E\u0001\tY&\u001cH/\u001a8feB\u0019QE\"\n\n\u0007\u0019\u001d\"AA\u0006K_\nd\u0015n\u001d;f]\u0016\u0014\b\u0002\u0003C[\u000b_\u0004\r\u0001b.\t\u0011\u00195\u0002\u0001\"\u0001\u0003\r_\tq\u0003[1oI2,W*\u00199Ti\u0006<WmU;c[&$H/\u001a3\u0015\u0019\t]b\u0011\u0007D\u001a\r\u00172iEb\u0014\t\u000f\r\u0005f1\u0006a\u0001m\"AQ1\u0007D\u0016\u0001\u00041)\u0004\r\u0005\u00078\u0019mb\u0011\tD$!%Y2q\rD\u001d\r1)\u0005\u0005\u0003\u0003L\u0019mB\u0001\u0004D\u001f\rg\t\t\u0011!A\u0003\u0002\tE#\u0001B0%i]\u0002BAa\u0013\u0007B\u0011aa1\tD\u001a\u0003\u0003\u0005\tQ!\u0001\u0003R\t!q\f\n\u001b9!\u0011\u0011YEb\u0012\u0005\u0019\u0019%c1GA\u0001\u0002\u0003\u0015\tA!\u0015\u0003\t}#C'\u000f\u0005\t\u0007W4Y\u00031\u0001\u0004n\"Aa\u0011\u0005D\u0016\u0001\u00041\u0019\u0003\u0003\u0005\u00056\u001a-\u0002\u0019\u0001C\\\u0011\u001d1\u0019\u0006\u0001C\u0005\r+\n1b];c[&$8\u000b^1hKR!!q\u0007D,\u0011!!iG\"\u0015A\u0002\u0005\r\u0002b\u0002D.\u0001\u0011%aQL\u0001\u0013gV\u0014W.\u001b;NSN\u001c\u0018N\\4UCN\\7\u000f\u0006\u0004\u00038\u0019}c\u0011\r\u0005\t\t[2I\u00061\u0001\u0002$!91\u0011\u0015D-\u0001\u00041\bb\u0002D3\u0001\u0011%aqM\u0001\u0013kB$\u0017\r^3BG\u000e,X.\u001e7bi>\u00148\u000f\u0006\u0003\u00038\u0019%\u0004\u0002\u0003D6\rG\u0002\rA\"\u001c\u0002\u000b\u00154XM\u001c;\u0011\u0007\u00152y'C\u0002\u0007r\t\u0011qbQ8na2,G/[8o\u000bZ,g\u000e\u001e\u0005\b\rk\u0002A\u0011\u0002D<\u0003-\u0001xn\u001d;UCN\\WI\u001c3\u0015\t\t]b\u0011\u0010\u0005\t\rW2\u0019\b1\u0001\u0007n!AaQ\u0010\u0001\u0005\u0002\t1y(\u0001\u000biC:$G.\u001a+bg.\u001cu.\u001c9mKRLwN\u001c\u000b\u0005\u0005o1\t\t\u0003\u0005\u0007l\u0019m\u0004\u0019\u0001D7\u0011!1)\t\u0001C\u0001\u0005\u0019\u001d\u0015A\u00055b]\u0012dW-\u0012=fGV$xN\u001d'pgR$bAa\u000e\u0007\n\u001a-\u0005\u0002\u0003B[\r\u0007\u0003\r!!-\t\u0011\u00195e1\u0011a\u0001\u0003k\f!b^8sW\u0016\u0014Hj\\:u\u0011\u001d1\t\n\u0001C\u0005\r'\u000b!E]3n_Z,W\t_3dkR|'/\u00118e+:\u0014XmZ5ti\u0016\u0014x*\u001e;qkR\u001cHC\u0003B\u001c\r+39Jb'\u0007 \"A!Q\u0017DH\u0001\u0004\t\t\f\u0003\u0005\u0007\u001a\u001a=\u0005\u0019AA{\u0003!1\u0017\u000e\\3M_N$\b\u0002\u0003DO\r\u001f\u0003\r!\"\u0019\u0002/!|7\u000f\u001e+p+:\u0014XmZ5ti\u0016\u0014x*\u001e;qkR\u001c\bB\u0003DQ\r\u001f\u0003\n\u00111\u0001\u0007$\u0006QQ.Y=cK\u0016\u0003xn\u00195\u0011\u000b1\u0019Y\"a0\t\u0011\u0019\u001d\u0006\u0001\"\u0001\u0003\rS\u000b1\u0003[1oI2,wk\u001c:lKJ\u0014V-\\8wK\u0012$\u0002Ba\u000e\u0007,\u001a5fq\u0016\u0005\t\u0005_4)\u000b1\u0001\u00022\"A!1\u001fDS\u0001\u0004\t\t\f\u0003\u0005\u0003x\u001a\u0015\u0006\u0019AAY\u0011!1\u0019\f\u0001C\u0001\u0005\u0019U\u0016a\u00055b]\u0012dW-\u0012=fGV$xN]!eI\u0016$GC\u0002B\u001c\ro3I\f\u0003\u0005\u00036\u001aE\u0006\u0019AAY\u0011!\u0011\u0019P\"-A\u0002\u0005E\u0006\u0002\u0003D_\u0001\u0011\u0005!Ab0\u0002/!\fg\u000e\u001a7f'R\fw-Z\"b]\u000e,G\u000e\\1uS>tGC\u0002B\u001c\r\u00034\u0019\rC\u0004\u0006~\u0019m\u0006\u0019\u0001<\t\u0011\t\u0015e1\u0018a\u0001\u000bCB\u0001Bb2\u0001\t\u0003\u0011a\u0011Z\u0001\u0016Q\u0006tG\r\\3K_\n\u001c\u0015M\\2fY2\fG/[8o)\u0019\u00119Db3\u0007N\"91\u0011\u0015Dc\u0001\u00041\b\u0002\u0003BC\r\u000b\u0004\r!\"\u0019\t\u000f\u0019E\u0007\u0001\"\u0003\u0007T\u0006\u0019R.\u0019:l'R\fw-Z!t\r&t\u0017n\u001d5fIR1!q\u0007Dk\r/D\u0001\u0002\"\u001c\u0007P\u0002\u0007\u00111\u0005\u0005\u000b\r34y\r%AA\u0002\u0015\u0005\u0014\u0001D3se>\u0014X*Z:tC\u001e,\u0007\u0002\u0003Do\u0001\u0011\u0005!Ab8\u0002\u0015\u0005\u0014wN\u001d;Ti\u0006<W\r\u0006\u0005\u00038\u0019\u0005hQ\u001dDt\u0011!1\u0019Ob7A\u0002\u0005\r\u0012a\u00034bS2,Gm\u0015;bO\u0016D\u0001B!\"\u0007\\\u0002\u0007\u0011\u0011\u0017\u0005\t\u0007/1Y\u000e1\u0001\u0004\u001a!9a1\u001e\u0001\u0005\n\u00195\u0018a\u00074bS2TuNY!oI&sG-\u001a9f]\u0012,g\u000e^*uC\u001e,7\u000f\u0006\u0005\u00038\u0019=h\u0011\u001fD{\u0011!!\tI\";A\u0002\u0005\u001d\u0003\u0002\u0003Dz\rS\u0004\r!!-\u0002\u001b\u0019\f\u0017\u000e\\;sKJ+\u0017m]8o\u0011)\u00199B\";\u0011\u0002\u0003\u00071\u0011\u0004\u0005\b\rs\u0004A\u0011\u0002D~\u00039\u0019H/Y4f\t\u0016\u0004XM\u001c3t\u001f:$b!!>\u0007~\u001a}\b\u0002\u0003C7\ro\u0004\r!a\t\t\u0011\u001d\u0005aq\u001fa\u0001\u0003G\ta\u0001^1sO\u0016$\b\u0002CD\u0003\u0001\u0011\u0005Aab\u0002\u0002!\u001d,G\u000f\u0015:fM\u0016\u0014(/\u001a3M_\u000e\u001cHCBAM\u000f\u00139)\u0002\u0003\u0005\u0004@\u001d\r\u0001\u0019AD\u0006a\u00119ia\"\u0005\u0011\r\r\u00153\u0011JD\b!\u0011\u0011Ye\"\u0005\u0005\u0019\u001dMq\u0011BA\u0001\u0002\u0003\u0015\tA!\u0015\u0003\t}#S\u0007\u000e\u0005\b\u000f/9\u0019\u00011\u0001w\u0003%\u0001\u0018M\u001d;ji&|g\u000eC\u0004\b\u001c\u0001!Ia\"\b\u00021\u001d,G\u000f\u0015:fM\u0016\u0014(/\u001a3M_\u000e\u001c\u0018J\u001c;fe:\fG\u000e\u0006\u0005\u0002\u001a\u001e}q1FD\u0017\u0011!\u0019yd\"\u0007A\u0002\u001d\u0005\u0002\u0007BD\u0012\u000fO\u0001ba!\u0012\u0004J\u001d\u0015\u0002\u0003\u0002B&\u000fO!Ab\"\u000b\b \u0005\u0005\t\u0011!B\u0001\u0005#\u0012Aa\u0018\u00136k!9qqCD\r\u0001\u00041\b\u0002CD\u0018\u000f3\u0001\ra\"\r\u0002\u000fYL7/\u001b;fIB1\u00111AA\n\u000fg\u0001b\u0001DD\u001b\u000fs1\u0018bAD\u001c\u001b\t1A+\u001e9mKJ\u0002Dab\u000f\b@A11QIB%\u000f{\u0001BAa\u0013\b@\u0011aq\u0011ID\u0017\u0003\u0003\u0005\tQ!\u0001\u0003R\t!q\fJ\u001b7\u0011\u001d9)\u0005\u0001C\u0001\u000f\u000f\n\u0011$\\1sW6\u000b\u0007o\u0015;bO\u0016TuNY!t\r&t\u0017n\u001d5fIR1!qGD%\u000f\u0017B\u0001\u0002\"!\bD\u0001\u0007\u0011q\t\u0005\t\u000f\u001b:\u0019\u00051\u0001\u0006,\u0005)1\u000f^1ug\"9q\u0011\u000b\u0001\u0005\u0002\r]\u0013\u0001B:u_BD\u0011b\"\u0016\u0001#\u0003%Iab\u0016\u0002;5\f'o[*uC\u001e,\u0017i\u001d$j]&\u001c\b.\u001a3%I\u00164\u0017-\u001e7uII*\"a\"\u0017+\t\u0015\u0005t1L\u0016\u0003\u000f;\u0002Bab\u0018\bj5\u0011q\u0011\r\u0006\u0005\u000fG:)'A\u0005v]\u000eDWmY6fI*\u0019qqM\u0007\u0002\u0015\u0005tgn\u001c;bi&|g.\u0003\u0003\bl\u001d\u0005$!E;oG\",7m[3e-\u0006\u0014\u0018.\u00198dK\"Iqq\u000e\u0001\u0012\u0002\u0013%q\u0011O\u0001-e\u0016lwN^3Fq\u0016\u001cW\u000f^8s\u0003:$WK\u001c:fO&\u001cH/\u001a:PkR\u0004X\u000f^:%I\u00164\u0017-\u001e7uIQ*\"ab\u001d+\t\u0019\rv1\f\u0005\n\u000fo\u0002\u0011\u0013!C\u0005\u000fs\nQEZ1jY*{'-\u00118e\u0013:$W\r]3oI\u0016tGo\u0015;bO\u0016\u001cH\u0005Z3gCVdG\u000fJ\u001a\u0016\u0005\u001dm$\u0006BB\r\u000f7:\u0001bb \u0003\u0011\u0003!q\u0011Q\u0001\r\t\u0006;5k\u00195fIVdWM\u001d\t\u0004K\u001d\reaB\u0001\u0003\u0011\u0003!qQQ\n\u0004\u000f\u0007[\u0001b\u0002&\b\u0004\u0012\u0005q\u0011\u0012\u000b\u0003\u000f\u0003C\u0011b\"$\b\u0004\n\u0007I\u0011A;\u0002!I+5+\u0016\"N\u0013R{F+S'F\u001fV#\u0006\u0002CDI\u000f\u0007\u0003\u000b\u0011\u0002<\u0002#I+5+\u0016\"N\u0013R{F+S'F\u001fV#\u0006\u0005C\u0005\b\u0016\u001e\r%\u0019!C\u0001k\u00061C)\u0012$B+2#v,T!Y?\u000e{ejU#D+RKe+R0T)\u0006;UiX!U)\u0016k\u0005\u000bV*\t\u0011\u001deu1\u0011Q\u0001\nY\fq\u0005R#G\u0003VcEkX'B1~\u001buJT*F\u0007V#\u0016JV#`'R\u000bu)R0B)R+U\n\u0015+TA!QqQTDB#\u0003%\tab(\u00027\u0011bWm]:j]&$He\u001a:fCR,'\u000f\n3fM\u0006,H\u000e\u001e\u00138+\t9\tKK\u0002D\u000f7\u0002")
public class DAGScheduler
implements Logging {
    private final SparkContext sc;
    private final TaskScheduler taskScheduler;
    public final LiveListenerBus org$apache$spark$scheduler$DAGScheduler$$listenerBus;
    public final MapOutputTrackerMaster org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker;
    private final BlockManagerMaster blockManagerMaster;
    private final SparkEnv env;
    public final Clock org$apache$spark$scheduler$DAGScheduler$$clock;
    private final DAGSchedulerSource metricsSource;
    private final AtomicInteger nextJobId;
    private final AtomicInteger nextStageId;
    private final HashMap<Object, HashSet<Object>> jobIdToStageIds;
    private final HashMap<Object, Stage> stageIdToStage;
    private final HashMap<Object, ShuffleMapStage> shuffleIdToMapStage;
    private final HashMap<Object, ActiveJob> jobIdToActiveJob;
    private final HashSet<Stage> waitingStages;
    private final HashSet<Stage> runningStages;
    private final HashSet<Stage> failedStages;
    private final HashSet<ActiveJob> activeJobs;
    private final HashMap<Object, IndexedSeq<Seq<TaskLocation>>> cacheLocs;
    private final HashMap<String, Object> failedEpoch;
    private final OutputCommitCoordinator outputCommitCoordinator;
    private final SerializerInstance closureSerializer;
    private final boolean disallowStageRetryForTest;
    private final boolean unRegisterOutputOnHostOnFetchFailure;
    private final int maxConsecutiveStageAttempts;
    private final ScheduledExecutorService messageScheduler;
    private final DAGSchedulerEventProcessLoop eventProcessLoop;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static Clock $lessinit$greater$default$7() {
        return DAGScheduler$.MODULE$.$lessinit$greater$default$7();
    }

    public static int DEFAULT_MAX_CONSECUTIVE_STAGE_ATTEMPTS() {
        return DAGScheduler$.MODULE$.DEFAULT_MAX_CONSECUTIVE_STAGE_ATTEMPTS();
    }

    public static int RESUBMIT_TIMEOUT() {
        return DAGScheduler$.MODULE$.RESUBMIT_TIMEOUT();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @TraitSetter
    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    public SparkContext sc() {
        return this.sc;
    }

    public TaskScheduler taskScheduler() {
        return this.taskScheduler;
    }

    public DAGSchedulerSource metricsSource() {
        return this.metricsSource;
    }

    public AtomicInteger nextJobId() {
        return this.nextJobId;
    }

    public int numTotalJobs() {
        return this.nextJobId().get();
    }

    private AtomicInteger nextStageId() {
        return this.nextStageId;
    }

    public HashMap<Object, HashSet<Object>> jobIdToStageIds() {
        return this.jobIdToStageIds;
    }

    public HashMap<Object, Stage> stageIdToStage() {
        return this.stageIdToStage;
    }

    public HashMap<Object, ShuffleMapStage> shuffleIdToMapStage() {
        return this.shuffleIdToMapStage;
    }

    public HashMap<Object, ActiveJob> jobIdToActiveJob() {
        return this.jobIdToActiveJob;
    }

    public HashSet<Stage> waitingStages() {
        return this.waitingStages;
    }

    public HashSet<Stage> runningStages() {
        return this.runningStages;
    }

    public HashSet<Stage> failedStages() {
        return this.failedStages;
    }

    public HashSet<ActiveJob> activeJobs() {
        return this.activeJobs;
    }

    private HashMap<Object, IndexedSeq<Seq<TaskLocation>>> cacheLocs() {
        return this.cacheLocs;
    }

    private HashMap<String, Object> failedEpoch() {
        return this.failedEpoch;
    }

    public OutputCommitCoordinator outputCommitCoordinator() {
        return this.outputCommitCoordinator;
    }

    private SerializerInstance closureSerializer() {
        return this.closureSerializer;
    }

    private boolean disallowStageRetryForTest() {
        return this.disallowStageRetryForTest;
    }

    public boolean unRegisterOutputOnHostOnFetchFailure() {
        return this.unRegisterOutputOnHostOnFetchFailure;
    }

    public int maxConsecutiveStageAttempts() {
        return this.maxConsecutiveStageAttempts;
    }

    private ScheduledExecutorService messageScheduler() {
        return this.messageScheduler;
    }

    public DAGSchedulerEventProcessLoop eventProcessLoop() {
        return this.eventProcessLoop;
    }

    public void taskStarted(Task<?> task, TaskInfo taskInfo) {
        this.eventProcessLoop().post(new BeginEvent(task, taskInfo));
    }

    public void taskGettingResult(TaskInfo taskInfo) {
        this.eventProcessLoop().post(new GettingResultEvent(taskInfo));
    }

    public void taskEnded(Task<?> task, TaskEndReason reason, Object result2, Seq<AccumulatorV2<?, ?>> accumUpdates, TaskInfo taskInfo) {
        this.eventProcessLoop().post(new CompletionEvent(task, reason, result2, accumUpdates, taskInfo));
    }

    public boolean executorHeartbeatReceived(String execId, Tuple4<Object, Object, Object, Seq<AccumulableInfo>>[] accumUpdates, BlockManagerId blockManagerId) {
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerExecutorMetricsUpdate(execId, (Seq<Tuple4<Object, Object, Object, Seq<AccumulableInfo>>>)Predef$.MODULE$.wrapRefArray((Object[])accumUpdates)));
        return BoxesRunTime.unboxToBoolean(this.blockManagerMaster.driverEndpoint().askSync(new BlockManagerMessages.BlockManagerHeartbeat(blockManagerId), new RpcTimeout(new package.DurationInt(scala.concurrent.duration.package$.MODULE$.DurationInt(600)).seconds(), "BlockManagerHeartbeat"), ClassTag$.MODULE$.Boolean()));
    }

    public void executorLost(String execId, ExecutorLossReason reason) {
        this.eventProcessLoop().post(new ExecutorLost(execId, reason));
    }

    public void workerRemoved(String workerId, String host, String message) {
        this.eventProcessLoop().post(new WorkerRemoved(workerId, host, message));
    }

    public void executorAdded(String execId, String host) {
        this.eventProcessLoop().post(new ExecutorAdded(execId, host));
    }

    public void taskSetFailed(TaskSet taskSet, String reason, Option<Throwable> exception2) {
        this.eventProcessLoop().post(new TaskSetFailed(taskSet, reason, exception2));
    }

    public void speculativeTaskSubmitted(Task<?> task) {
        this.eventProcessLoop().post(new SpeculativeTaskSubmitted(task));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public IndexedSeq<Seq<TaskLocation>> getCacheLocs(RDD<?> rdd) {
        block5 : {
            block6 : {
                var2_2 = this.cacheLocs();
                // MONITORENTER : var2_2
                if (this.cacheLocs().contains((Object)BoxesRunTime.boxToInteger((int)rdd.id()))) break block5;
                var5_3 = StorageLevel$.MODULE$.NONE();
                if (rdd.getStorageLevel() != null) break block6;
                if (var5_3 == null) ** GOTO lbl-1000
                ** GOTO lbl-1000
            }
            if (v0.equals(var5_3)) lbl-1000: // 2 sources:
            {
                v1 = (IndexedSeq)package$.MODULE$.IndexedSeq().fill(rdd.partitions().length, (Function0)new scala.Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final Nil$ apply() {
                        return Nil$.MODULE$;
                    }
                });
            } else lbl-1000: // 2 sources:
            {
                blockIds = (BlockId[])((TraversableOnce)Predef$.MODULE$.refArrayOps((Object[])rdd.partitions()).indices().map((Function1)new scala.Serializable(this, rdd){
                    public static final long serialVersionUID = 0L;
                    private final RDD rdd$1;

                    public final org.apache.spark.storage.RDDBlockId apply(int index) {
                        return new org.apache.spark.storage.RDDBlockId(this.rdd$1.id(), index);
                    }
                    {
                        this.rdd$1 = rdd$1;
                    }
                }, scala.collection.immutable.IndexedSeq$.MODULE$.canBuildFrom())).toArray(ClassTag$.MODULE$.apply(BlockId.class));
                v1 = (IndexedSeq)this.blockManagerMaster.getLocations(blockIds).map((Function1)new scala.Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final Seq<TaskLocation> apply(Seq<BlockManagerId> bms) {
                        return (Seq)bms.map((Function1)new scala.Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final TaskLocation apply(BlockManagerId bm) {
                                return org.apache.spark.scheduler.TaskLocation$.MODULE$.apply(bm.host(), bm.executorId());
                            }
                        }, Seq$.MODULE$.canBuildFrom());
                    }
                }, IndexedSeq$.MODULE$.canBuildFrom());
            }
            locs = v1;
            this.cacheLocs().update((Object)BoxesRunTime.boxToInteger((int)rdd.id()), (Object)locs);
        }
        var3_6 = this.cacheLocs().apply((Object)BoxesRunTime.boxToInteger((int)rdd.id()));
        // MONITOREXIT : var2_2
        return (IndexedSeq)var3_6;
    }

    private void clearCacheLocs() {
        HashMap<Object, IndexedSeq<Seq<TaskLocation>>> hashMap = this.cacheLocs();
        synchronized (hashMap) {
            this.cacheLocs().clear();
            return;
        }
    }

    public ShuffleMapStage org$apache$spark$scheduler$DAGScheduler$$getOrCreateShuffleMapStage(ShuffleDependency<?, ?, ?> shuffleDep, int firstJobId) {
        Option option;
        block4 : {
            ShuffleMapStage shuffleMapStage;
            block3 : {
                block2 : {
                    ShuffleMapStage stage;
                    option = this.shuffleIdToMapStage().get((Object)BoxesRunTime.boxToInteger((int)shuffleDep.shuffleId()));
                    if (!(option instanceof Some)) break block2;
                    Some some = (Some)option;
                    shuffleMapStage = stage = (ShuffleMapStage)some.x();
                    break block3;
                }
                if (!None$.MODULE$.equals((Object)option)) break block4;
                this.getMissingAncestorShuffleDependencies(shuffleDep.rdd()).foreach((Function1)new scala.Serializable(this, firstJobId){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ DAGScheduler $outer;
                    private final int firstJobId$1;

                    public final Object apply(ShuffleDependency<?, ?, ?> dep) {
                        return this.$outer.shuffleIdToMapStage().contains((Object)BoxesRunTime.boxToInteger((int)dep.shuffleId())) ? BoxedUnit.UNIT : this.$outer.createShuffleMapStage(dep, this.firstJobId$1);
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.firstJobId$1 = firstJobId$1;
                    }
                });
                shuffleMapStage = this.createShuffleMapStage(shuffleDep, firstJobId);
            }
            return shuffleMapStage;
        }
        throw new MatchError((Object)option);
    }

    public ShuffleMapStage createShuffleMapStage(ShuffleDependency<?, ?, ?> shuffleDep, int jobId) {
        RDD<Product2<?, ?>> rdd = shuffleDep.rdd();
        int numTasks = rdd.partitions().length;
        List<Stage> parents = this.getOrCreateParentStages(rdd, jobId);
        int id = this.nextStageId().getAndIncrement();
        ShuffleMapStage stage = new ShuffleMapStage(id, rdd, numTasks, parents, jobId, rdd.creationSite(), shuffleDep, this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker);
        this.stageIdToStage().update((Object)BoxesRunTime.boxToInteger((int)id), (Object)stage);
        this.shuffleIdToMapStage().update((Object)BoxesRunTime.boxToInteger((int)shuffleDep.shuffleId()), (Object)stage);
        this.updateJobIdStageIdMaps(jobId, stage);
        if (!this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.containsShuffle(shuffleDep.shuffleId())) {
            this.logInfo((Function0<String>)new scala.Serializable(this, rdd){
                public static final long serialVersionUID = 0L;
                private final RDD rdd$2;

                public final String apply() {
                    return new StringBuilder().append((Object)"Registering RDD ").append((Object)BoxesRunTime.boxToInteger((int)this.rdd$2.id())).append((Object)" (").append((Object)this.rdd$2.getCreationSite()).append((Object)")").toString();
                }
                {
                    this.rdd$2 = rdd$2;
                }
            });
            this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.registerShuffle(shuffleDep.shuffleId(), rdd.partitions().length);
        }
        return stage;
    }

    private ResultStage createResultStage(RDD<?> rdd, Function2<TaskContext, Iterator<?>, ?> func, int[] partitions2, int jobId, CallSite callSite) {
        List<Stage> parents = this.getOrCreateParentStages(rdd, jobId);
        int id = this.nextStageId().getAndIncrement();
        ResultStage stage = new ResultStage(id, rdd, func, partitions2, parents, jobId, callSite);
        this.stageIdToStage().update((Object)BoxesRunTime.boxToInteger((int)id), (Object)stage);
        this.updateJobIdStageIdMaps(jobId, stage);
        return stage;
    }

    private List<Stage> getOrCreateParentStages(RDD<?> rdd, int firstJobId) {
        return ((TraversableOnce)this.getShuffleDependencies(rdd).map((Function1)new scala.Serializable(this, firstJobId){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;
            private final int firstJobId$2;

            public final ShuffleMapStage apply(ShuffleDependency<?, ?, ?> shuffleDep) {
                return this.$outer.org$apache$spark$scheduler$DAGScheduler$$getOrCreateShuffleMapStage(shuffleDep, this.firstJobId$2);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.firstJobId$2 = firstJobId$2;
            }
        }, HashSet$.MODULE$.canBuildFrom())).toList();
    }

    private ArrayStack<ShuffleDependency<?, ?, ?>> getMissingAncestorShuffleDependencies(RDD<?> rdd) {
        ArrayStack ancestors = new ArrayStack();
        HashSet visited = new HashSet();
        ArrayStack waitingForVisit = new ArrayStack();
        waitingForVisit.push(rdd);
        while (waitingForVisit.nonEmpty()) {
            RDD toVisit = (RDD)waitingForVisit.pop();
            if (visited.apply((Object)toVisit)) continue;
            visited.$plus$eq((Object)toVisit);
            this.getShuffleDependencies(toVisit).foreach((Function1)new scala.Serializable(this, ancestors, waitingForVisit){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ DAGScheduler $outer;
                private final ArrayStack ancestors$1;
                private final ArrayStack waitingForVisit$1;

                public final void apply(ShuffleDependency<?, ?, ?> shuffleDep) {
                    if (!this.$outer.shuffleIdToMapStage().contains((Object)BoxesRunTime.boxToInteger((int)shuffleDep.shuffleId()))) {
                        this.ancestors$1.push(shuffleDep);
                        this.waitingForVisit$1.push(shuffleDep.rdd());
                    }
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.ancestors$1 = ancestors$1;
                    this.waitingForVisit$1 = waitingForVisit$1;
                }
            });
        }
        return ancestors;
    }

    public HashSet<ShuffleDependency<?, ?, ?>> getShuffleDependencies(RDD<?> rdd) {
        HashSet parents = new HashSet();
        HashSet visited = new HashSet();
        ArrayStack waitingForVisit = new ArrayStack();
        waitingForVisit.push(rdd);
        while (waitingForVisit.nonEmpty()) {
            RDD toVisit = (RDD)waitingForVisit.pop();
            if (visited.apply((Object)toVisit)) continue;
            visited.$plus$eq((Object)toVisit);
            toVisit.dependencies().foreach((Function1)new scala.Serializable(this, parents, waitingForVisit){
                public static final long serialVersionUID = 0L;
                private final HashSet parents$1;
                private final ArrayStack waitingForVisit$2;

                public final Object apply(Dependency<?> x0$1) {
                    BoxedUnit boxedUnit;
                    Dependency<?> dependency = x0$1;
                    if (dependency instanceof ShuffleDependency) {
                        ShuffleDependency shuffleDependency = (ShuffleDependency)dependency;
                        boxedUnit = this.parents$1.$plus$eq((Object)shuffleDependency);
                    } else {
                        this.waitingForVisit$2.push(dependency.rdd());
                        boxedUnit = BoxedUnit.UNIT;
                    }
                    return boxedUnit;
                }
                {
                    this.parents$1 = parents$1;
                    this.waitingForVisit$2 = waitingForVisit$2;
                }
            });
        }
        return parents;
    }

    public List<Stage> org$apache$spark$scheduler$DAGScheduler$$getMissingParentStages(Stage stage) {
        HashSet missing = new HashSet();
        HashSet visited = new HashSet();
        ArrayStack waitingForVisit = new ArrayStack();
        waitingForVisit.push(stage.rdd());
        while (waitingForVisit.nonEmpty()) {
            this.visit$1((RDD)waitingForVisit.pop(), stage, missing, visited, waitingForVisit);
        }
        return missing.toList();
    }

    private void updateJobIdStageIdMaps(int jobId, Stage stage) {
        this.updateJobIdStageIdMapsList$1(List$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new Stage[]{stage})), jobId);
    }

    private void cleanupStateForJobAndIndependentStages(ActiveJob job) {
        Stage stage;
        block7 : {
            block6 : {
                block5 : {
                    Option registeredStages = this.jobIdToStageIds().get((Object)BoxesRunTime.boxToInteger((int)job.jobId()));
                    if (registeredStages.isEmpty() || ((SetLike)registeredStages.get()).isEmpty()) {
                        this.logError((Function0<String>)new scala.Serializable(this, job){
                            public static final long serialVersionUID = 0L;
                            private final ActiveJob job$1;

                            public final String apply() {
                                return new StringBuilder().append((Object)"No stages registered for job ").append((Object)BoxesRunTime.boxToInteger((int)this.job$1.jobId())).toString();
                            }
                            {
                                this.job$1 = job$1;
                            }
                        });
                    } else {
                        this.stageIdToStage().filterKeys((Function1)new scala.Serializable(this, registeredStages){
                            public static final long serialVersionUID = 0L;
                            private final Option registeredStages$1;

                            public final boolean apply(int stageId) {
                                return this.apply$mcZI$sp(stageId);
                            }

                            public boolean apply$mcZI$sp(int stageId) {
                                return ((HashSet)this.registeredStages$1.get()).contains((Object)BoxesRunTime.boxToInteger((int)stageId));
                            }
                            {
                                this.registeredStages$1 = registeredStages$1;
                            }
                        }).foreach((Function1)new scala.Serializable(this, job){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ DAGScheduler $outer;
                            public final ActiveJob job$1;

                            public final void apply(Tuple2<Object, Stage> x0$2) {
                                Tuple2<Object, Stage> tuple2 = x0$2;
                                if (tuple2 != null) {
                                    BoxedUnit boxedUnit;
                                    int stageId = tuple2._1$mcI$sp();
                                    Stage stage = (Stage)tuple2._2();
                                    HashSet<Object> jobSet = stage.jobIds();
                                    if (jobSet.contains((Object)BoxesRunTime.boxToInteger((int)this.job$1.jobId()))) {
                                        jobSet.$minus$eq((Object)BoxesRunTime.boxToInteger((int)this.job$1.jobId()));
                                        if (jobSet.isEmpty()) {
                                            this.removeStage$1(stageId);
                                            boxedUnit = BoxedUnit.UNIT;
                                        } else {
                                            boxedUnit = BoxedUnit.UNIT;
                                        }
                                    } else {
                                        this.$outer.logError((Function0<String>)new scala.Serializable(this, stageId){
                                            public static final long serialVersionUID = 0L;
                                            private final /* synthetic */ $anonfun$cleanupStateForJobAndIndependentStages$3 $outer;
                                            private final int stageId$1;

                                            public final String apply() {
                                                return new StringOps(Predef$.MODULE$.augmentString("Job %d not registered for stage %d even though that stage was registered for the job")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.job$1.jobId()), BoxesRunTime.boxToInteger((int)this.stageId$1)}));
                                            }
                                            {
                                                if ($outer == null) {
                                                    throw null;
                                                }
                                                this.$outer = $outer;
                                                this.stageId$1 = stageId$1;
                                            }
                                        });
                                        boxedUnit = BoxedUnit.UNIT;
                                    }
                                    BoxedUnit boxedUnit2 = boxedUnit;
                                    return;
                                }
                                throw new MatchError(tuple2);
                            }

                            public /* synthetic */ DAGScheduler org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer() {
                                return this.$outer;
                            }

                            private final void removeStage$1(int stageId) {
                                this.$outer.stageIdToStage().get((Object)BoxesRunTime.boxToInteger((int)stageId)).foreach((Function1)new scala.Serializable(this, stageId){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ $anonfun$cleanupStateForJobAndIndependentStages$3 $outer;
                                    public final int stageId$2;

                                    public final Object apply(Stage stage) {
                                        BoxedUnit boxedUnit;
                                        BoxedUnit boxedUnit2;
                                        BoxedUnit boxedUnit3;
                                        if (this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().runningStages().contains((Object)stage)) {
                                            this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().logDebug((Function0<String>)new scala.Serializable(this){
                                                public static final long serialVersionUID = 0L;
                                                private final /* synthetic */ org.apache.spark.scheduler.DAGScheduler$$anonfun$cleanupStateForJobAndIndependentStages$3$$anonfun$removeStage$1$1 $outer;

                                                public final String apply() {
                                                    return new StringOps(Predef$.MODULE$.augmentString("Removing running stage %d")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.stageId$2)}));
                                                }
                                                {
                                                    if ($outer == null) {
                                                        throw null;
                                                    }
                                                    this.$outer = $outer;
                                                }
                                            });
                                            boxedUnit3 = this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().runningStages().$minus$eq((Object)stage);
                                        } else {
                                            boxedUnit3 = BoxedUnit.UNIT;
                                        }
                                        this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().shuffleIdToMapStage().find((Function1)new scala.Serializable(this, stage){
                                            public static final long serialVersionUID = 0L;
                                            private final Stage stage$7;

                                            /*
                                             * Enabled force condition propagation
                                             * Lifted jumps to return sites
                                             */
                                            public final boolean apply(Tuple2<Object, ShuffleMapStage> x$2) {
                                                Stage stage = this.stage$7;
                                                if (x$2._2() != null) {
                                                    Object object;
                                                    if (!object.equals(stage)) return false;
                                                    return true;
                                                }
                                                if (stage == null) return true;
                                                return false;
                                            }
                                            {
                                                this.stage$7 = stage$7;
                                            }
                                        }).withFilter((Function1)new scala.Serializable(this){
                                            public static final long serialVersionUID = 0L;

                                            public final boolean apply(Tuple2<Object, ShuffleMapStage> check$ifrefutable$1) {
                                                Tuple2<Object, ShuffleMapStage> tuple2 = check$ifrefutable$1;
                                                boolean bl = tuple2 != null;
                                                return bl;
                                            }
                                        }).foreach((Function1)new scala.Serializable(this){
                                            public static final long serialVersionUID = 0L;
                                            private final /* synthetic */ org.apache.spark.scheduler.DAGScheduler$$anonfun$cleanupStateForJobAndIndependentStages$3$$anonfun$removeStage$1$1 $outer;

                                            public final Option<ShuffleMapStage> apply(Tuple2<Object, ShuffleMapStage> x$3) {
                                                Tuple2<Object, ShuffleMapStage> tuple2 = x$3;
                                                if (tuple2 != null) {
                                                    int k = tuple2._1$mcI$sp();
                                                    Option option = this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$anonfun$$$outer().org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().shuffleIdToMapStage().remove((Object)BoxesRunTime.boxToInteger((int)k));
                                                    return option;
                                                }
                                                throw new MatchError(tuple2);
                                            }
                                            {
                                                if ($outer == null) {
                                                    throw null;
                                                }
                                                this.$outer = $outer;
                                            }
                                        });
                                        if (this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().waitingStages().contains((Object)stage)) {
                                            this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().logDebug((Function0<String>)new scala.Serializable(this){
                                                public static final long serialVersionUID = 0L;
                                                private final /* synthetic */ org.apache.spark.scheduler.DAGScheduler$$anonfun$cleanupStateForJobAndIndependentStages$3$$anonfun$removeStage$1$1 $outer;

                                                public final String apply() {
                                                    return new StringOps(Predef$.MODULE$.augmentString("Removing stage %d from waiting set.")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.stageId$2)}));
                                                }
                                                {
                                                    if ($outer == null) {
                                                        throw null;
                                                    }
                                                    this.$outer = $outer;
                                                }
                                            });
                                            boxedUnit2 = this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().waitingStages().$minus$eq((Object)stage);
                                        } else {
                                            boxedUnit2 = BoxedUnit.UNIT;
                                        }
                                        if (this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().failedStages().contains((Object)stage)) {
                                            this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().logDebug((Function0<String>)new scala.Serializable(this){
                                                public static final long serialVersionUID = 0L;
                                                private final /* synthetic */ org.apache.spark.scheduler.DAGScheduler$$anonfun$cleanupStateForJobAndIndependentStages$3$$anonfun$removeStage$1$1 $outer;

                                                public final String apply() {
                                                    return new StringOps(Predef$.MODULE$.augmentString("Removing stage %d from failed set.")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.stageId$2)}));
                                                }
                                                {
                                                    if ($outer == null) {
                                                        throw null;
                                                    }
                                                    this.$outer = $outer;
                                                }
                                            });
                                            boxedUnit = this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().failedStages().$minus$eq((Object)stage);
                                        } else {
                                            boxedUnit = BoxedUnit.UNIT;
                                        }
                                        return boxedUnit;
                                    }

                                    public /* synthetic */ $anonfun$cleanupStateForJobAndIndependentStages$3 org$apache$spark$scheduler$DAGScheduler$$anonfun$$anonfun$$$outer() {
                                        return this.$outer;
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                        this.stageId$2 = stageId$2;
                                    }
                                });
                                this.$outer.stageIdToStage().$minus$eq((Object)BoxesRunTime.boxToInteger((int)stageId));
                                this.$outer.logDebug((Function0<String>)new scala.Serializable(this, stageId){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ $anonfun$cleanupStateForJobAndIndependentStages$3 $outer;
                                    private final int stageId$2;

                                    public final String apply() {
                                        return new StringOps(Predef$.MODULE$.augmentString("After removal of stage %d, remaining stages = %d")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.stageId$2), BoxesRunTime.boxToInteger((int)this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().stageIdToStage().size())}));
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                        this.stageId$2 = stageId$2;
                                    }
                                });
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.job$1 = job$1;
                            }
                        });
                    }
                    this.jobIdToStageIds().$minus$eq((Object)BoxesRunTime.boxToInteger((int)job.jobId()));
                    this.jobIdToActiveJob().$minus$eq((Object)BoxesRunTime.boxToInteger((int)job.jobId()));
                    this.activeJobs().$minus$eq((Object)job);
                    stage = job.finalStage();
                    if (!(stage instanceof ResultStage)) break block5;
                    ResultStage resultStage = (ResultStage)stage;
                    resultStage.removeActiveJob();
                    BoxedUnit boxedUnit = BoxedUnit.UNIT;
                    break block6;
                }
                if (!(stage instanceof ShuffleMapStage)) break block7;
                ShuffleMapStage shuffleMapStage = (ShuffleMapStage)stage;
                shuffleMapStage.removeActiveJob(job);
                BoxedUnit boxedUnit = BoxedUnit.UNIT;
            }
            return;
        }
        throw new MatchError((Object)stage);
    }

    public <T, U> JobWaiter<U> submitJob(RDD<T> rdd, Function2<TaskContext, Iterator<T>, U> func, Seq<Object> partitions2, CallSite callSite, Function2<Object, U, BoxedUnit> resultHandler, Properties properties) {
        int maxPartitions = rdd.partitions().length;
        partitions2.find((Function1)new scala.Serializable(this, maxPartitions){
            public static final long serialVersionUID = 0L;
            private final int maxPartitions$1;

            public final boolean apply(int p) {
                return this.apply$mcZI$sp(p);
            }

            public boolean apply$mcZI$sp(int p) {
                return p >= this.maxPartitions$1 || p < 0;
            }
            {
                this.maxPartitions$1 = maxPartitions$1;
            }
        }).foreach((Function1)new scala.Serializable(this, maxPartitions){
            public static final long serialVersionUID = 0L;
            private final int maxPartitions$1;

            public final scala.runtime.Nothing$ apply(int p) {
                throw new java.lang.IllegalArgumentException(new StringBuilder().append((Object)"Attempting to access a non-existent partition: ").append((Object)BoxesRunTime.boxToInteger((int)p)).append((Object)". ").append((Object)"Total number of partitions: ").append((Object)BoxesRunTime.boxToInteger((int)this.maxPartitions$1)).toString());
            }
            {
                this.maxPartitions$1 = maxPartitions$1;
            }
        });
        int jobId = this.nextJobId().getAndIncrement();
        if (partitions2.size() == 0) {
            return new JobWaiter<U>(this, jobId, 0, resultHandler);
        }
        Predef$.MODULE$.assert(partitions2.size() > 0);
        Function2<TaskContext, Iterator<T>, U> func2 = func;
        JobWaiter<U> waiter = new JobWaiter<U>(this, jobId, partitions2.size(), resultHandler);
        this.eventProcessLoop().post(new JobSubmitted(jobId, rdd, func2, (int[])partitions2.toArray(ClassTag$.MODULE$.Int()), callSite, waiter, (Properties)SerializationUtils.clone((Serializable)properties)));
        return waiter;
    }

    public <T, U> void runJob(RDD<T> rdd, Function2<TaskContext, Iterator<T>, U> func, Seq<Object> partitions2, CallSite callSite, Function2<Object, U, BoxedUnit> resultHandler, Properties properties) {
        long start2 = System.nanoTime();
        JobWaiter<U> waiter = this.submitJob(rdd, func, partitions2, callSite, resultHandler, properties);
        ThreadUtils$.MODULE$.awaitReady(waiter.completionFuture(), (Duration)Duration$.MODULE$.Inf());
        Try try_ = (Try)waiter.completionFuture().value().get();
        if (try_ instanceof Success) {
            this.logInfo((Function0<String>)new scala.Serializable(this, callSite, start2, waiter){
                public static final long serialVersionUID = 0L;
                private final CallSite callSite$1;
                private final long start$1;
                private final JobWaiter waiter$1;

                public final String apply() {
                    return new StringOps(Predef$.MODULE$.augmentString("Job %d finished: %s, took %f s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.waiter$1.jobId()), this.callSite$1.shortForm(), BoxesRunTime.boxToDouble((double)((double)(System.nanoTime() - this.start$1) / 1.0E9))}));
                }
                {
                    this.callSite$1 = callSite$1;
                    this.start$1 = start$1;
                    this.waiter$1 = waiter$1;
                }
            });
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
            return;
        }
        if (try_ instanceof Failure) {
            Failure failure = (Failure)try_;
            Throwable exception2 = failure.exception();
            this.logInfo((Function0<String>)new scala.Serializable(this, callSite, start2, waiter){
                public static final long serialVersionUID = 0L;
                private final CallSite callSite$1;
                private final long start$1;
                private final JobWaiter waiter$1;

                public final String apply() {
                    return new StringOps(Predef$.MODULE$.augmentString("Job %d failed: %s, took %f s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.waiter$1.jobId()), this.callSite$1.shortForm(), BoxesRunTime.boxToDouble((double)((double)(System.nanoTime() - this.start$1) / 1.0E9))}));
                }
                {
                    this.callSite$1 = callSite$1;
                    this.start$1 = start$1;
                    this.waiter$1 = waiter$1;
                }
            });
            StackTraceElement[] callerStackTrace = (StackTraceElement[])Predef$.MODULE$.refArrayOps((Object[])Thread.currentThread().getStackTrace()).tail();
            exception2.setStackTrace((StackTraceElement[])Predef$.MODULE$.refArrayOps((Object[])exception2.getStackTrace()).$plus$plus((GenTraversableOnce)Predef$.MODULE$.refArrayOps((Object[])callerStackTrace), Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.apply(StackTraceElement.class))));
            throw exception2;
        }
        throw new MatchError((Object)try_);
    }

    public <T, U, R> PartialResult<R> runApproximateJob(RDD<T> rdd, Function2<TaskContext, Iterator<T>, U> func, ApproximateEvaluator<U, R> evaluator, CallSite callSite, long timeout, Properties properties) {
        ApproximateActionListener<T, U, R> listener = new ApproximateActionListener<T, U, R>(rdd, func, evaluator, timeout);
        Function2<TaskContext, Iterator<T>, U> func2 = func;
        int[] partitions2 = (int[])RichInt$.MODULE$.until$extension0(Predef$.MODULE$.intWrapper(0), rdd.partitions().length).toArray(ClassTag$.MODULE$.Int());
        int jobId = this.nextJobId().getAndIncrement();
        this.eventProcessLoop().post(new JobSubmitted(jobId, rdd, func2, partitions2, callSite, listener, (Properties)SerializationUtils.clone((Serializable)properties)));
        return listener.awaitResult();
    }

    public <K, V, C> JobWaiter<MapOutputStatistics> submitMapStage(ShuffleDependency<K, V, C> dependency, Function1<MapOutputStatistics, BoxedUnit> callback, CallSite callSite, Properties properties) {
        RDD<Product2<K, V>> rdd = dependency.rdd();
        int jobId = this.nextJobId().getAndIncrement();
        if (rdd.partitions().length == 0) {
            throw new SparkException("Can't run submitMapStage on RDD with 0 partitions");
        }
        JobWaiter<MapOutputStatistics> waiter = new JobWaiter<MapOutputStatistics>(this, jobId, 1, (Function2<Object, MapOutputStatistics, BoxedUnit>)new scala.Serializable(this, callback){
            public static final long serialVersionUID = 0L;
            private final Function1 callback$1;

            public final void apply(int i, MapOutputStatistics r) {
                this.callback$1.apply((Object)r);
            }
            {
                this.callback$1 = callback$1;
            }
        });
        this.eventProcessLoop().post(new MapStageSubmitted(jobId, dependency, callSite, waiter, (Properties)SerializationUtils.clone((Serializable)properties)));
        return waiter;
    }

    public void cancelJob(int jobId, Option<String> reason) {
        this.logInfo((Function0<String>)new scala.Serializable(this, jobId){
            public static final long serialVersionUID = 0L;
            private final int jobId$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Asked to cancel job ").append((Object)BoxesRunTime.boxToInteger((int)this.jobId$1)).toString();
            }
            {
                this.jobId$1 = jobId$1;
            }
        });
        this.eventProcessLoop().post(new JobCancelled(jobId, reason));
    }

    public void cancelJobGroup(String groupId) {
        this.logInfo((Function0<String>)new scala.Serializable(this, groupId){
            public static final long serialVersionUID = 0L;
            private final String groupId$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Asked to cancel job group ").append((Object)this.groupId$1).toString();
            }
            {
                this.groupId$1 = groupId$1;
            }
        });
        this.eventProcessLoop().post(new JobGroupCancelled(groupId));
    }

    public void cancelAllJobs() {
        this.eventProcessLoop().post(AllJobsCancelled$.MODULE$);
    }

    public void doCancelAllJobs() {
        ((HashSet)this.runningStages().map((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(Stage x$4) {
                return x$4.firstJobId();
            }
        }, HashSet$.MODULE$.canBuildFrom())).foreach((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final void apply(int x$5) {
                this.apply$mcVI$sp(x$5);
            }

            public void apply$mcVI$sp(int x$5) {
                this.$outer.handleJobCancellation(x$5, (Option<String>)scala.Option$.MODULE$.apply((Object)"as part of cancellation of all jobs"));
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        this.activeJobs().clear();
        this.jobIdToActiveJob().clear();
    }

    public void cancelStage(int stageId, Option<String> reason) {
        this.eventProcessLoop().post(new StageCancelled(stageId, reason));
    }

    public boolean killTaskAttempt(long taskId, boolean interruptThread, String reason) {
        return this.taskScheduler().killTaskAttempt(taskId, interruptThread, reason);
    }

    public void resubmitFailedStages() {
        if (this.failedStages().size() > 0) {
            this.logInfo((Function0<String>)new scala.Serializable(this){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "Resubmitting failed stages";
                }
            });
            this.clearCacheLocs();
            Stage[] failedStagesCopy = (Stage[])this.failedStages().toArray(ClassTag$.MODULE$.apply(Stage.class));
            this.failedStages().clear();
            Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])failedStagesCopy).sortBy((Function1)new scala.Serializable(this){
                public static final long serialVersionUID = 0L;

                public final int apply(Stage x$6) {
                    return x$6.firstJobId();
                }
            }, (Ordering)Ordering.Int$.MODULE$)).foreach((Function1)new scala.Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ DAGScheduler $outer;

                public final void apply(Stage stage) {
                    this.$outer.org$apache$spark$scheduler$DAGScheduler$$submitStage(stage);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            });
        }
    }

    private void submitWaitingChildStages(Stage parent) {
        this.logTrace((Function0<String>)new scala.Serializable(this, parent){
            public static final long serialVersionUID = 0L;
            private final Stage parent$1;

            public final String apply() {
                return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Checking if any dependencies of ", " are now runnable"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.parent$1}));
            }
            {
                this.parent$1 = parent$1;
            }
        });
        this.logTrace((Function0<String>)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final String apply() {
                return new StringBuilder().append((Object)"running: ").append(this.$outer.runningStages()).toString();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        this.logTrace((Function0<String>)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final String apply() {
                return new StringBuilder().append((Object)"waiting: ").append(this.$outer.waitingStages()).toString();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        this.logTrace((Function0<String>)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final String apply() {
                return new StringBuilder().append((Object)"failed: ").append(this.$outer.failedStages()).toString();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        Stage[] childStages = (Stage[])((TraversableOnce)this.waitingStages().filter((Function1)new scala.Serializable(this, parent){
            public static final long serialVersionUID = 0L;
            private final Stage parent$1;

            public final boolean apply(Stage x$7) {
                return x$7.parents().contains((Object)this.parent$1);
            }
            {
                this.parent$1 = parent$1;
            }
        })).toArray(ClassTag$.MODULE$.apply(Stage.class));
        this.waitingStages().$minus$minus$eq((TraversableOnce)Predef$.MODULE$.refArrayOps((Object[])childStages));
        Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])childStages).sortBy((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(Stage x$8) {
                return x$8.firstJobId();
            }
        }, (Ordering)Ordering.Int$.MODULE$)).foreach((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final void apply(Stage stage) {
                this.$outer.org$apache$spark$scheduler$DAGScheduler$$submitStage(stage);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
    }

    private Option<Object> activeJobForStage(Stage stage) {
        int[] jobsThatUseStage = (int[])Predef$.MODULE$.intArrayOps((int[])stage.jobIds().toArray(ClassTag$.MODULE$.Int())).sorted((Ordering)Ordering.Int$.MODULE$);
        return Predef$.MODULE$.intArrayOps(jobsThatUseStage).find((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final boolean apply(int key) {
                return this.apply$mcZI$sp(key);
            }

            public boolean apply$mcZI$sp(int key) {
                return this.$outer.jobIdToActiveJob().contains((Object)BoxesRunTime.boxToInteger((int)key));
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
    }

    public void handleJobGroupCancelled(String groupId) {
        HashSet activeInGroup = (HashSet)this.activeJobs().filter((Function1)new scala.Serializable(this, groupId){
            public static final long serialVersionUID = 0L;
            public final String groupId$2;

            public final boolean apply(ActiveJob activeJob) {
                return scala.Option$.MODULE$.apply((Object)activeJob.properties()).exists((Function1)new scala.Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ $anonfun$9 $outer;

                    /*
                     * Enabled force condition propagation
                     * Lifted jumps to return sites
                     */
                    public final boolean apply(Properties x$9) {
                        String string = this.$outer.groupId$2;
                        if (x$9.getProperty(SparkContext$.MODULE$.SPARK_JOB_GROUP_ID()) != null) {
                            String string2;
                            if (!string2.equals(string)) return false;
                            return true;
                        }
                        if (string == null) return true;
                        return false;
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
            }
            {
                this.groupId$2 = groupId$2;
            }
        });
        HashSet jobIds2 = (HashSet)activeInGroup.map((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(ActiveJob x$10) {
                return x$10.jobId();
            }
        }, HashSet$.MODULE$.canBuildFrom());
        jobIds2.foreach((Function1)new scala.Serializable(this, groupId){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;
            private final String groupId$2;

            public final void apply(int x$11) {
                this.apply$mcVI$sp(x$11);
            }

            public void apply$mcVI$sp(int x$11) {
                this.$outer.handleJobCancellation(x$11, (Option<String>)scala.Option$.MODULE$.apply((Object)new StringOps(Predef$.MODULE$.augmentString("part of cancelled job group %s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.groupId$2}))));
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.groupId$2 = groupId$2;
            }
        });
    }

    public void handleBeginEvent(Task<?> task, TaskInfo taskInfo) {
        int stageAttemptId = BoxesRunTime.unboxToInt((Object)this.stageIdToStage().get((Object)BoxesRunTime.boxToInteger((int)task.stageId())).map((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(Stage x$12) {
                return x$12.latestInfo().attemptNumber();
            }
        }).getOrElse((Function0)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply() {
                return this.apply$mcI$sp();
            }

            public int apply$mcI$sp() {
                return -1;
            }
        }));
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerTaskStart(task.stageId(), stageAttemptId, taskInfo));
    }

    public void handleSpeculativeTaskSubmitted(Task<?> task) {
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerSpeculativeTaskSubmitted(task.stageId()));
    }

    public void handleTaskSetFailed(TaskSet taskSet, String reason, Option<Throwable> exception2) {
        this.stageIdToStage().get((Object)BoxesRunTime.boxToInteger((int)taskSet.stageId())).foreach((Function1)new scala.Serializable(this, reason, exception2){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;
            private final String reason$1;
            private final Option exception$1;

            public final void apply(Stage x$13) {
                this.$outer.abortStage(x$13, this.reason$1, (Option<Throwable>)this.exception$1);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.reason$1 = reason$1;
                this.exception$1 = exception$1;
            }
        });
    }

    public void cleanUpAfterSchedulerStop() {
        this.activeJobs().foreach((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final void apply(ActiveJob job) {
                SparkException error2 = new SparkException(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Job ", " cancelled because SparkContext was shut down"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)job.jobId())})));
                job.listener().jobFailed(error2);
                String stageFailedMessage = "Stage cancelled because SparkContext was shut down";
                Predef$.MODULE$.refArrayOps((Object[])this.$outer.runningStages().toArray(ClassTag$.MODULE$.apply(Stage.class))).foreach((Function1)new scala.Serializable(this, stageFailedMessage){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ $anonfun$cleanUpAfterSchedulerStop$1 $outer;
                    private final String stageFailedMessage$1;

                    public final void apply(Stage stage) {
                        this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished(stage, (Option<String>)new Some((Object)this.stageFailedMessage$1));
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.stageFailedMessage$1 = stageFailedMessage$1;
                    }
                });
                this.$outer.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerJobEnd(job.jobId(), this.$outer.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis(), new JobFailed(error2)));
            }

            public /* synthetic */ DAGScheduler org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
    }

    public void handleGetTaskResult(TaskInfo taskInfo) {
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerTaskGettingResult(taskInfo));
    }

    public void handleJobSubmitted(int jobId, RDD<?> finalRDD, Function2<TaskContext, Iterator<?>, ?> func, int[] partitions2, CallSite callSite, JobListener listener, Properties properties) {
        long jobSubmissionTime;
        ActiveJob job;
        ObjectRef finalStage = ObjectRef.create(null);
        try {
            finalStage.elem = this.createResultStage(finalRDD, func, partitions2, jobId, callSite);
            job = new ActiveJob(jobId, (ResultStage)finalStage.elem, callSite, listener, properties);
            this.clearCacheLocs();
            this.logInfo((Function0<String>)new scala.Serializable(this, partitions2, callSite, job){
                public static final long serialVersionUID = 0L;
                private final int[] partitions$1;
                private final CallSite callSite$2;
                private final ActiveJob job$2;

                public final String apply() {
                    return new StringOps(Predef$.MODULE$.augmentString("Got job %s (%s) with %d output partitions")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.job$2.jobId()), this.callSite$2.shortForm(), BoxesRunTime.boxToInteger((int)this.partitions$1.length)}));
                }
                {
                    this.partitions$1 = partitions$1;
                    this.callSite$2 = callSite$2;
                    this.job$2 = job$2;
                }
            });
            this.logInfo((Function0<String>)new scala.Serializable(this, finalStage){
                public static final long serialVersionUID = 0L;
                private final ObjectRef finalStage$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"Final stage: ").append((Object)((ResultStage)this.finalStage$1.elem)).append((Object)" (").append((Object)((ResultStage)this.finalStage$1.elem).name()).append((Object)")").toString();
                }
                {
                    this.finalStage$1 = finalStage$1;
                }
            });
            this.logInfo((Function0<String>)new scala.Serializable(this, finalStage){
                public static final long serialVersionUID = 0L;
                private final ObjectRef finalStage$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"Parents of final stage: ").append(((ResultStage)this.finalStage$1.elem).parents()).toString();
                }
                {
                    this.finalStage$1 = finalStage$1;
                }
            });
            this.logInfo((Function0<String>)new scala.Serializable(this, finalStage){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ DAGScheduler $outer;
                private final ObjectRef finalStage$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"Missing parents: ").append(this.$outer.org$apache$spark$scheduler$DAGScheduler$$getMissingParentStages((ResultStage)this.finalStage$1.elem)).toString();
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.finalStage$1 = finalStage$1;
                }
            });
            jobSubmissionTime = this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis();
        }
        catch (Exception exception2) {
            this.logWarning((Function0<String>)new scala.Serializable(this, jobId){
                public static final long serialVersionUID = 0L;
                private final int jobId$4;

                public final String apply() {
                    return new StringBuilder().append((Object)"Creating new stage failed due to exception - job: ").append((Object)BoxesRunTime.boxToInteger((int)this.jobId$4)).toString();
                }
                {
                    this.jobId$4 = jobId$4;
                }
            }, exception2);
            listener.jobFailed(exception2);
            return;
        }
        this.jobIdToActiveJob().update((Object)BoxesRunTime.boxToInteger((int)jobId), (Object)job);
        this.activeJobs().$plus$eq((Object)job);
        ((ResultStage)finalStage.elem).setActiveJob(job);
        int[] stageIds = (int[])((TraversableOnce)this.jobIdToStageIds().apply((Object)BoxesRunTime.boxToInteger((int)jobId))).toArray(ClassTag$.MODULE$.Int());
        StageInfo[] stageInfos = (StageInfo[])Predef$.MODULE$.intArrayOps(stageIds).flatMap((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final Iterable<StageInfo> apply(int id) {
                return scala.Option$.MODULE$.option2Iterable(this.$outer.stageIdToStage().get((Object)BoxesRunTime.boxToInteger((int)id)).map((Function1)new scala.Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final StageInfo apply(Stage x$14) {
                        return x$14.latestInfo();
                    }
                }));
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.apply(StageInfo.class)));
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerJobStart(job.jobId(), jobSubmissionTime, (Seq<StageInfo>)Predef$.MODULE$.wrapRefArray((Object[])stageInfos), properties));
        this.org$apache$spark$scheduler$DAGScheduler$$submitStage((ResultStage)finalStage.elem);
    }

    public void handleMapStageSubmitted(int jobId, ShuffleDependency<?, ?, ?> dependency, CallSite callSite, JobListener listener, Properties properties) {
        long jobSubmissionTime;
        ActiveJob job;
        ObjectRef finalStage = ObjectRef.create(null);
        try {
            finalStage.elem = this.org$apache$spark$scheduler$DAGScheduler$$getOrCreateShuffleMapStage(dependency, jobId);
            job = new ActiveJob(jobId, (ShuffleMapStage)finalStage.elem, callSite, listener, properties);
            this.clearCacheLocs();
            this.logInfo((Function0<String>)new scala.Serializable(this, jobId, dependency, callSite){
                public static final long serialVersionUID = 0L;
                private final int jobId$5;
                private final ShuffleDependency dependency$1;
                private final CallSite callSite$3;

                public final String apply() {
                    return new StringOps(Predef$.MODULE$.augmentString("Got map stage job %s (%s) with %d output partitions")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.jobId$5), this.callSite$3.shortForm(), BoxesRunTime.boxToInteger((int)this.dependency$1.rdd().partitions().length)}));
                }
                {
                    this.jobId$5 = jobId$5;
                    this.dependency$1 = dependency$1;
                    this.callSite$3 = callSite$3;
                }
            });
            this.logInfo((Function0<String>)new scala.Serializable(this, finalStage){
                public static final long serialVersionUID = 0L;
                private final ObjectRef finalStage$2;

                public final String apply() {
                    return new StringBuilder().append((Object)"Final stage: ").append((Object)((ShuffleMapStage)this.finalStage$2.elem)).append((Object)" (").append((Object)((ShuffleMapStage)this.finalStage$2.elem).name()).append((Object)")").toString();
                }
                {
                    this.finalStage$2 = finalStage$2;
                }
            });
            this.logInfo((Function0<String>)new scala.Serializable(this, finalStage){
                public static final long serialVersionUID = 0L;
                private final ObjectRef finalStage$2;

                public final String apply() {
                    return new StringBuilder().append((Object)"Parents of final stage: ").append(((ShuffleMapStage)this.finalStage$2.elem).parents()).toString();
                }
                {
                    this.finalStage$2 = finalStage$2;
                }
            });
            this.logInfo((Function0<String>)new scala.Serializable(this, finalStage){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ DAGScheduler $outer;
                private final ObjectRef finalStage$2;

                public final String apply() {
                    return new StringBuilder().append((Object)"Missing parents: ").append(this.$outer.org$apache$spark$scheduler$DAGScheduler$$getMissingParentStages((ShuffleMapStage)this.finalStage$2.elem)).toString();
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.finalStage$2 = finalStage$2;
                }
            });
            jobSubmissionTime = this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis();
        }
        catch (Exception exception2) {
            this.logWarning((Function0<String>)new scala.Serializable(this, jobId){
                public static final long serialVersionUID = 0L;
                private final int jobId$5;

                public final String apply() {
                    return new StringBuilder().append((Object)"Creating new stage failed due to exception - job: ").append((Object)BoxesRunTime.boxToInteger((int)this.jobId$5)).toString();
                }
                {
                    this.jobId$5 = jobId$5;
                }
            }, exception2);
            listener.jobFailed(exception2);
            return;
        }
        this.jobIdToActiveJob().update((Object)BoxesRunTime.boxToInteger((int)jobId), (Object)job);
        this.activeJobs().$plus$eq((Object)job);
        ((ShuffleMapStage)finalStage.elem).addActiveJob(job);
        int[] stageIds = (int[])((TraversableOnce)this.jobIdToStageIds().apply((Object)BoxesRunTime.boxToInteger((int)jobId))).toArray(ClassTag$.MODULE$.Int());
        StageInfo[] stageInfos = (StageInfo[])Predef$.MODULE$.intArrayOps(stageIds).flatMap((Function1)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final Iterable<StageInfo> apply(int id) {
                return scala.Option$.MODULE$.option2Iterable(this.$outer.stageIdToStage().get((Object)BoxesRunTime.boxToInteger((int)id)).map((Function1)new scala.Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final StageInfo apply(Stage x$15) {
                        return x$15.latestInfo();
                    }
                }));
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.apply(StageInfo.class)));
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerJobStart(job.jobId(), jobSubmissionTime, (Seq<StageInfo>)Predef$.MODULE$.wrapRefArray((Object[])stageInfos), properties));
        this.org$apache$spark$scheduler$DAGScheduler$$submitStage((ShuffleMapStage)finalStage.elem);
        if (((ShuffleMapStage)finalStage.elem).isAvailable()) {
            this.markMapStageJobAsFinished(job, this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.getStatistics(dependency));
        }
    }

    public void org$apache$spark$scheduler$DAGScheduler$$submitStage(Stage stage) {
        Option<Object> jobId = this.activeJobForStage(stage);
        if (jobId.isDefined()) {
            this.logDebug((Function0<String>)new scala.Serializable(this, stage){
                public static final long serialVersionUID = 0L;
                private final Stage stage$2;

                public final String apply() {
                    return new StringBuilder().append((Object)"submitStage(").append((Object)this.stage$2).append((Object)")").toString();
                }
                {
                    this.stage$2 = stage$2;
                }
            });
            if (!(this.waitingStages().apply((Object)stage) || this.runningStages().apply((Object)stage) || this.failedStages().apply((Object)stage))) {
                List missing = (List)this.org$apache$spark$scheduler$DAGScheduler$$getMissingParentStages(stage).sortBy((Function1)new scala.Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final int apply(Stage x$16) {
                        return x$16.id();
                    }
                }, (Ordering)Ordering.Int$.MODULE$);
                this.logDebug((Function0<String>)new scala.Serializable(this, missing){
                    public static final long serialVersionUID = 0L;
                    private final List missing$2;

                    public final String apply() {
                        return new StringBuilder().append((Object)"missing: ").append((Object)this.missing$2).toString();
                    }
                    {
                        this.missing$2 = missing$2;
                    }
                });
                if (missing.isEmpty()) {
                    this.logInfo((Function0<String>)new scala.Serializable(this, stage){
                        public static final long serialVersionUID = 0L;
                        private final Stage stage$2;

                        public final String apply() {
                            return new StringBuilder().append((Object)"Submitting ").append((Object)this.stage$2).append((Object)" (").append(this.stage$2.rdd()).append((Object)"), which has no missing parents").toString();
                        }
                        {
                            this.stage$2 = stage$2;
                        }
                    });
                    this.submitMissingTasks(stage, BoxesRunTime.unboxToInt((Object)jobId.get()));
                } else {
                    missing.foreach((Function1)new scala.Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ DAGScheduler $outer;

                        public final void apply(Stage parent) {
                            this.$outer.org$apache$spark$scheduler$DAGScheduler$$submitStage(parent);
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    });
                    this.waitingStages().$plus$eq((Object)stage);
                }
            }
        } else {
            this.abortStage(stage, new StringBuilder().append((Object)"No active job for stage ").append((Object)BoxesRunTime.boxToInteger((int)stage.id())).toString(), (Option<Throwable>)None$.MODULE$);
        }
    }

    private void submitMissingTasks(Stage stage, int jobId) {
        Stage stage2;
        block29 : {
            Properties properties;
            Seq<Object> partitionsToCompute;
            Stage stage3;
            block24 : {
                Stage stage4;
                block25 : {
                    Stage stage5;
                    block26 : {
                        Stage stage6;
                        block34 : {
                            block31 : {
                                String string;
                                block33 : {
                                    block32 : {
                                        block30 : {
                                            scala.collection.immutable.Map map2;
                                            byte[] arrby;
                                            Seq tasks;
                                            block28 : {
                                                block27 : {
                                                    this.logDebug((Function0<String>)new scala.Serializable(this, stage){
                                                        public static final long serialVersionUID = 0L;
                                                        private final Stage stage$4;

                                                        public final String apply() {
                                                            return new StringBuilder().append((Object)"submitMissingTasks(").append((Object)this.stage$4).append((Object)")").toString();
                                                        }
                                                        {
                                                            this.stage$4 = stage$4;
                                                        }
                                                    });
                                                    partitionsToCompute = stage.findMissingPartitions();
                                                    properties = ((ActiveJob)this.jobIdToActiveJob().apply((Object)BoxesRunTime.boxToInteger((int)jobId))).properties();
                                                    this.runningStages().$plus$eq((Object)stage);
                                                    stage2 = stage;
                                                    if (!(stage2 instanceof ShuffleMapStage)) break block27;
                                                    ShuffleMapStage shuffleMapStage = (ShuffleMapStage)stage2;
                                                    this.outputCommitCoordinator().stageStart(shuffleMapStage.id(), shuffleMapStage.numPartitions() - 1);
                                                    BoxedUnit boxedUnit = BoxedUnit.UNIT;
                                                    break block28;
                                                }
                                                if (!(stage2 instanceof ResultStage)) break block29;
                                                ResultStage resultStage = (ResultStage)stage2;
                                                this.outputCommitCoordinator().stageStart(resultStage.id(), resultStage.rdd().partitions().length - 1);
                                                BoxedUnit boxedUnit = BoxedUnit.UNIT;
                                            }
                                            stage3 = stage;
                                            if (stage3 instanceof ShuffleMapStage) {
                                                map2 = ((TraversableOnce)partitionsToCompute.map((Function1)new scala.Serializable(this, stage){
                                                    public static final long serialVersionUID = 0L;
                                                    private final /* synthetic */ DAGScheduler $outer;
                                                    private final Stage stage$4;

                                                    public final Tuple2<Object, Seq<TaskLocation>> apply(int id) {
                                                        return new Tuple2((Object)BoxesRunTime.boxToInteger((int)id), this.$outer.getPreferredLocs(this.stage$4.rdd(), id));
                                                    }
                                                    {
                                                        if ($outer == null) {
                                                            throw null;
                                                        }
                                                        this.$outer = $outer;
                                                        this.stage$4 = stage$4;
                                                    }
                                                }, Seq$.MODULE$.canBuildFrom())).toMap(Predef$.MODULE$.$conforms());
                                            } else {
                                                if (!(stage3 instanceof ResultStage)) break block24;
                                                ResultStage resultStage = (ResultStage)stage3;
                                                map2 = ((TraversableOnce)partitionsToCompute.map((Function1)new scala.Serializable(this, stage, resultStage){
                                                    public static final long serialVersionUID = 0L;
                                                    private final /* synthetic */ DAGScheduler $outer;
                                                    private final Stage stage$4;
                                                    private final ResultStage x3$1;

                                                    public final Tuple2<Object, Seq<TaskLocation>> apply(int id) {
                                                        int p = this.x3$1.partitions()[id];
                                                        return new Tuple2((Object)BoxesRunTime.boxToInteger((int)id), this.$outer.getPreferredLocs(this.stage$4.rdd(), p));
                                                    }
                                                    {
                                                        if ($outer == null) {
                                                            throw null;
                                                        }
                                                        this.$outer = $outer;
                                                        this.stage$4 = stage$4;
                                                        this.x3$1 = x3$1;
                                                    }
                                                }, Seq$.MODULE$.canBuildFrom())).toMap(Predef$.MODULE$.$conforms());
                                            }
                                            scala.collection.immutable.Map taskIdToLocations = map2;
                                            stage.makeNewStageAttempt(partitionsToCompute.size(), (Seq<Seq<TaskLocation>>)taskIdToLocations.values().toSeq());
                                            if (partitionsToCompute.nonEmpty()) {
                                                stage.latestInfo().submissionTime_$eq((Option<Object>)new Some((Object)BoxesRunTime.boxToLong((long)this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis())));
                                            }
                                            this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerStageSubmitted(stage.latestInfo(), properties));
                                            ObjectRef taskBinary = ObjectRef.create(null);
                                            stage4 = stage;
                                            if (stage4 instanceof ShuffleMapStage) {
                                                ShuffleMapStage shuffleMapStage = (ShuffleMapStage)stage4;
                                                arrby = JavaUtils.bufferToArray((ByteBuffer)this.closureSerializer().serialize(new Tuple2(shuffleMapStage.rdd(), shuffleMapStage.shuffleDep()), ClassTag$.MODULE$.AnyRef()));
                                            } else {
                                                if (!(stage4 instanceof ResultStage)) break block25;
                                                ResultStage resultStage = (ResultStage)stage4;
                                                arrby = JavaUtils.bufferToArray((ByteBuffer)this.closureSerializer().serialize(new Tuple2(resultStage.rdd(), resultStage.func()), ClassTag$.MODULE$.AnyRef()));
                                            }
                                            byte[] taskBinaryBytes = arrby;
                                            taskBinary.elem = this.sc().broadcast(taskBinaryBytes, ClassTag$.MODULE$.apply(ScalaRunTime$.MODULE$.arrayClass(Byte.TYPE)));
                                            try {
                                                Seq seq;
                                                byte[] serializedTaskMetrics = this.closureSerializer().serialize(stage.latestInfo().taskMetrics(), ClassTag$.MODULE$.apply(TaskMetrics.class)).array();
                                                stage5 = stage;
                                                if (stage5 instanceof ShuffleMapStage) {
                                                    ShuffleMapStage shuffleMapStage = (ShuffleMapStage)stage5;
                                                    shuffleMapStage.pendingPartitions().clear();
                                                    seq = (Seq)partitionsToCompute.map((Function1)new scala.Serializable(this, jobId, properties, (Map)taskIdToLocations, taskBinary, serializedTaskMetrics, shuffleMapStage){
                                                        public static final long serialVersionUID = 0L;
                                                        private final /* synthetic */ DAGScheduler $outer;
                                                        private final int jobId$6;
                                                        private final Properties properties$1;
                                                        private final Map taskIdToLocations$1;
                                                        private final ObjectRef taskBinary$1;
                                                        private final byte[] serializedTaskMetrics$1;
                                                        private final ShuffleMapStage x2$1;

                                                        public final ShuffleMapTask apply(int id) {
                                                            Seq locs = (Seq)this.taskIdToLocations$1.apply((Object)BoxesRunTime.boxToInteger((int)id));
                                                            Partition part = this.x2$1.rdd().partitions()[id];
                                                            this.x2$1.pendingPartitions().$plus$eq((Object)BoxesRunTime.boxToInteger((int)id));
                                                            return new ShuffleMapTask(this.x2$1.id(), this.x2$1.latestInfo().attemptNumber(), (Broadcast)this.taskBinary$1.elem, part, (Seq<TaskLocation>)locs, this.properties$1, this.serializedTaskMetrics$1, (Option<Object>)scala.Option$.MODULE$.apply((Object)BoxesRunTime.boxToInteger((int)this.jobId$6)), (Option<String>)scala.Option$.MODULE$.apply((Object)this.$outer.sc().applicationId()), this.$outer.sc().applicationAttemptId());
                                                        }
                                                        {
                                                            if ($outer == null) {
                                                                throw null;
                                                            }
                                                            this.$outer = $outer;
                                                            this.jobId$6 = jobId$6;
                                                            this.properties$1 = properties$1;
                                                            this.taskIdToLocations$1 = taskIdToLocations$1;
                                                            this.taskBinary$1 = taskBinary$1;
                                                            this.serializedTaskMetrics$1 = serializedTaskMetrics$1;
                                                            this.x2$1 = x2$1;
                                                        }
                                                    }, Seq$.MODULE$.canBuildFrom());
                                                } else {
                                                    if (!(stage5 instanceof ResultStage)) break block26;
                                                    ResultStage resultStage = (ResultStage)stage5;
                                                    seq = (Seq)partitionsToCompute.map((Function1)new scala.Serializable(this, jobId, properties, (Map)taskIdToLocations, taskBinary, serializedTaskMetrics, resultStage){
                                                        public static final long serialVersionUID = 0L;
                                                        private final /* synthetic */ DAGScheduler $outer;
                                                        private final int jobId$6;
                                                        private final Properties properties$1;
                                                        private final Map taskIdToLocations$1;
                                                        private final ObjectRef taskBinary$1;
                                                        private final byte[] serializedTaskMetrics$1;
                                                        private final ResultStage x3$2;

                                                        public final ResultTask<scala.runtime.Nothing$, scala.runtime.Nothing$> apply(int id) {
                                                            int p = this.x3$2.partitions()[id];
                                                            Partition part = this.x3$2.rdd().partitions()[p];
                                                            Seq locs = (Seq)this.taskIdToLocations$1.apply((Object)BoxesRunTime.boxToInteger((int)id));
                                                            return new ResultTask<scala.runtime.Nothing$, scala.runtime.Nothing$>(this.x3$2.id(), this.x3$2.latestInfo().attemptNumber(), (Broadcast)this.taskBinary$1.elem, part, (Seq<TaskLocation>)locs, id, this.properties$1, this.serializedTaskMetrics$1, (Option<Object>)scala.Option$.MODULE$.apply((Object)BoxesRunTime.boxToInteger((int)this.jobId$6)), (Option<String>)scala.Option$.MODULE$.apply((Object)this.$outer.sc().applicationId()), this.$outer.sc().applicationAttemptId());
                                                        }
                                                        {
                                                            if ($outer == null) {
                                                                throw null;
                                                            }
                                                            this.$outer = $outer;
                                                            this.jobId$6 = jobId$6;
                                                            this.properties$1 = properties$1;
                                                            this.taskIdToLocations$1 = taskIdToLocations$1;
                                                            this.taskBinary$1 = taskBinary$1;
                                                            this.serializedTaskMetrics$1 = serializedTaskMetrics$1;
                                                            this.x3$2 = x3$2;
                                                        }
                                                    }, Seq$.MODULE$.canBuildFrom());
                                                }
                                                tasks = seq;
                                            }
                                            catch (Throwable throwable) {
                                                Throwable throwable2 = throwable;
                                                Option option = NonFatal$.MODULE$.unapply(throwable2);
                                                if (option.isEmpty()) {
                                                    throw throwable;
                                                }
                                                Throwable e = (Throwable)option.get();
                                                this.abortStage(stage, new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Task creation failed: ", "\\n", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{e, Utils$.MODULE$.exceptionString(e)})), (Option<Throwable>)new Some((Object)e));
                                                this.runningStages().$minus$eq((Object)stage);
                                                return;
                                            }
                                            if (tasks.size() <= 0) break block30;
                                            this.logInfo((Function0<String>)new scala.Serializable(this, stage, tasks){
                                                public static final long serialVersionUID = 0L;
                                                private final Stage stage$4;
                                                private final Seq tasks$1;

                                                public final String apply() {
                                                    return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Submitting ", " missing tasks from ", " (", ") (first 15 "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.tasks$1.size()), this.stage$4, this.stage$4.rdd()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"tasks are for partitions ", ")"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{((scala.collection.TraversableLike)this.tasks$1.take(15)).map((Function1)new scala.Serializable(this){
                                                        public static final long serialVersionUID = 0L;

                                                        public final int apply(Task<?> x$17) {
                                                            return x$17.partitionId();
                                                        }
                                                    }, Seq$.MODULE$.canBuildFrom())}))).toString();
                                                }
                                                {
                                                    this.stage$4 = stage$4;
                                                    this.tasks$1 = tasks$1;
                                                }
                                            });
                                            this.taskScheduler().submitTasks(new TaskSet((Task[])tasks.toArray(ClassTag$.MODULE$.apply(Task.class)), stage.id(), stage.latestInfo().attemptNumber(), jobId, properties));
                                            break block31;
                                        }
                                        this.org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished(stage, (Option<String>)None$.MODULE$);
                                        stage6 = stage;
                                        if (!(stage6 instanceof ShuffleMapStage)) break block32;
                                        ShuffleMapStage shuffleMapStage = (ShuffleMapStage)stage6;
                                        string = new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Stage ", " is actually done; "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{shuffleMapStage}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"(available: ", ","})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToBoolean((boolean)shuffleMapStage.isAvailable())}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"available outputs: ", ","})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)shuffleMapStage.numAvailableOutputs())}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"partitions: ", ")"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)shuffleMapStage.numPartitions())}))).toString();
                                        break block33;
                                    }
                                    if (!(stage6 instanceof ResultStage)) break block34;
                                    ResultStage resultStage = (ResultStage)stage6;
                                    string = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Stage ", " is actually done; (partitions: ", ")"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{resultStage, BoxesRunTime.boxToInteger((int)resultStage.numPartitions())}));
                                }
                                String debugString2 = string;
                                this.logDebug((Function0<String>)new scala.Serializable(this, debugString2){
                                    public static final long serialVersionUID = 0L;
                                    private final String debugString$1;

                                    public final String apply() {
                                        return this.debugString$1;
                                    }
                                    {
                                        this.debugString$1 = debugString$1;
                                    }
                                });
                                this.submitWaitingChildStages(stage);
                            }
                            return;
                        }
                        throw new MatchError((Object)stage6);
                    }
                    throw new MatchError((Object)stage5);
                }
                try {
                    throw new MatchError((Object)stage4);
                }
                catch (Throwable throwable) {
                    Throwable throwable3 = throwable;
                    if (throwable3 instanceof NotSerializableException) {
                        NotSerializableException notSerializableException = (NotSerializableException)throwable3;
                        this.abortStage(stage, new StringBuilder().append((Object)"Task not serializable: ").append((Object)notSerializableException.toString()).toString(), (Option<Throwable>)new Some((Object)notSerializableException));
                        this.runningStages().$minus$eq((Object)stage);
                        return;
                    }
                    Option option = NonFatal$.MODULE$.unapply(throwable3);
                    if (option.isEmpty()) {
                        throw throwable;
                    }
                    Throwable e = (Throwable)option.get();
                    this.abortStage(stage, new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Task serialization failed: ", "\\n", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{e, Utils$.MODULE$.exceptionString(e)})), (Option<Throwable>)new Some((Object)e));
                    this.runningStages().$minus$eq((Object)stage);
                    return;
                }
            }
            try {
                throw new MatchError((Object)stage3);
            }
            catch (Throwable throwable) {
                Throwable throwable4 = throwable;
                Option option = NonFatal$.MODULE$.unapply(throwable4);
                if (option.isEmpty()) {
                    throw throwable;
                }
                Throwable e = (Throwable)option.get();
                stage.makeNewStageAttempt(partitionsToCompute.size(), stage.makeNewStageAttempt$default$2());
                this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerStageSubmitted(stage.latestInfo(), properties));
                this.abortStage(stage, new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Task creation failed: ", "\\n", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{e, Utils$.MODULE$.exceptionString(e)})), (Option<Throwable>)new Some((Object)e));
                this.runningStages().$minus$eq((Object)stage);
                return;
            }
        }
        throw new MatchError((Object)stage2);
    }

    private void updateAccumulators(CompletionEvent event) {
        Task<?> task = event.task();
        Stage stage = (Stage)this.stageIdToStage().apply((Object)BoxesRunTime.boxToInteger((int)task.stageId()));
        try {
            event.accumUpdates().foreach((Function1)new scala.Serializable(this, event, stage){
                public static final long serialVersionUID = 0L;
                private final CompletionEvent event$1;
                private final Stage stage$5;

                public final void apply(AccumulatorV2<?, ?> updates) {
                    long id = updates.id();
                    Option<AccumulatorV2<?, ?>> option = org.apache.spark.util.AccumulatorContext$.MODULE$.get(id);
                    if (option instanceof Some) {
                        AccumulatorV2 accumulatorV2;
                        AccumulatorV2 accum;
                        Some some = (Some)option;
                        AccumulatorV2 acc = accumulatorV2 = (accum = (AccumulatorV2)some.x());
                        acc.merge(updates);
                        if (acc.name().isDefined() && !updates.isZero()) {
                            this.stage$5.latestInfo().accumulables().update((Object)BoxesRunTime.boxToLong((long)id), (Object)acc.toInfo((Option<Object>)None$.MODULE$, (Option<Object>)new Some(acc.value())));
                            AccumulableInfo accumulableInfo = acc.toInfo((Option<Object>)new Some(updates.value()), (Option<Object>)new Some(acc.value()));
                            this.event$1.taskInfo().setAccumulables((Seq<AccumulableInfo>)((Seq)this.event$1.taskInfo().accumulables().$plus$colon((Object)accumulableInfo, Seq$.MODULE$.canBuildFrom())));
                        }
                        return;
                    }
                    if (None$.MODULE$.equals(option)) {
                        throw new SparkException(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"attempted to access non-existent accumulator ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)id)})));
                    }
                    throw new MatchError(option);
                }
                {
                    this.event$1 = event$1;
                    this.stage$5 = stage$5;
                }
            });
        }
        catch (Throwable throwable) {
            Throwable throwable2 = throwable;
            Option option = NonFatal$.MODULE$.unapply(throwable2);
            if (option.isEmpty()) {
                throw throwable;
            }
            Throwable e = (Throwable)option.get();
            this.logError((Function0<String>)new scala.Serializable(this, task){
                public static final long serialVersionUID = 0L;
                private final Task task$1;

                public final String apply() {
                    return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Failed to update accumulators for task ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.task$1.partitionId())}));
                }
                {
                    this.task$1 = task$1;
                }
            }, e);
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void postTaskEnd(CompletionEvent event) {
        block5 : {
            if (event.accumUpdates().nonEmpty()) {
                v0 = TaskMetrics$.MODULE$.fromAccumulators(event.accumUpdates());
                ** GOTO lbl17
            } else {
                v0 = null;
            }
            break block5;
            catch (Throwable var3_2) {
                var4_3 = var3_2;
                var5_4 = NonFatal$.MODULE$.unapply(var4_3);
                if (var5_4.isEmpty()) {
                    throw var3_2;
                }
                e = (Throwable)var5_4.get();
                taskId = event.taskInfo().taskId();
                this.logError((Function0<String>)new scala.Serializable(this, taskId){
                    public static final long serialVersionUID = 0L;
                    private final long taskId$1;

                    public final String apply() {
                        return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Error when attempting to reconstruct metrics for task ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)this.taskId$1)}));
                    }
                    {
                        this.taskId$1 = taskId$1;
                    }
                }, e);
                var7_7 = null;
                v0 = var7_7;
            }
        }
        taskMetrics = v0;
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerTaskEnd(event.task().stageId(), event.task().stageAttemptId(), Utils$.MODULE$.getFormattedClassName(event.task()), event.reason(), event.taskInfo(), taskMetrics));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void handleTaskCompletion(CompletionEvent event) {
        block50 : {
            block49 : {
                BoxedUnit boxedUnit;
                block48 : {
                    block43 : {
                        Stage stage;
                        TaskEndReason taskEndReason;
                        Task<?> task;
                        block44 : {
                            BoxedUnit boxedUnit2;
                            Task<?> task2;
                            HashSet hashSet;
                            block45 : {
                                Option<ActiveJob> option;
                                ResultTask resultTask;
                                block46 : {
                                    ResultStage resultStage;
                                    ActiveJob job;
                                    block47 : {
                                        task = event.task();
                                        String taskId = event.taskInfo().id();
                                        int stageId = task.stageId();
                                        String taskType = Utils$.MODULE$.getFormattedClassName(task);
                                        this.outputCommitCoordinator().taskCompleted(stageId, task.partitionId(), event.taskInfo().attemptNumber(), event.reason());
                                        if (!this.stageIdToStage().contains((Object)BoxesRunTime.boxToInteger((int)task.stageId()))) break block43;
                                        stage = (Stage)this.stageIdToStage().apply((Object)BoxesRunTime.boxToInteger((int)task.stageId()));
                                        TaskEndReason taskEndReason2 = event.reason();
                                        if (Success$.MODULE$.equals(taskEndReason2)) {
                                            Task<?> task3 = task;
                                            if (task3 instanceof ResultTask) {
                                                ResultTask resultTask2 = (ResultTask)task3;
                                                ResultStage resultStage2 = (ResultStage)stage;
                                                Option<ActiveJob> option2 = resultStage2.activeJob();
                                                if (option2 instanceof Some) {
                                                    BoxedUnit boxedUnit3;
                                                    Some some = (Some)option2;
                                                    ActiveJob job2 = (ActiveJob)some.x();
                                                    if (job2.finished()[resultTask2.outputId()]) {
                                                        boxedUnit3 = BoxedUnit.UNIT;
                                                    } else {
                                                        this.updateAccumulators(event);
                                                        boxedUnit3 = BoxedUnit.UNIT;
                                                    }
                                                    BoxedUnit boxedUnit4 = boxedUnit3;
                                                } else {
                                                    if (!None$.MODULE$.equals(option2)) throw new MatchError(option2);
                                                    BoxedUnit boxedUnit5 = BoxedUnit.UNIT;
                                                }
                                                BoxedUnit boxedUnit6 = BoxedUnit.UNIT;
                                            } else {
                                                this.updateAccumulators(event);
                                                BoxedUnit boxedUnit7 = BoxedUnit.UNIT;
                                            }
                                            BoxedUnit boxedUnit8 = BoxedUnit.UNIT;
                                        } else if (taskEndReason2 instanceof ExceptionFailure) {
                                            this.updateAccumulators(event);
                                            BoxedUnit boxedUnit9 = BoxedUnit.UNIT;
                                        } else {
                                            BoxedUnit boxedUnit10 = BoxedUnit.UNIT;
                                        }
                                        this.postTaskEnd(event);
                                        taskEndReason = event.reason();
                                        if (!Success$.MODULE$.equals(taskEndReason)) break block44;
                                        task2 = task;
                                        if (!(task2 instanceof ResultTask)) break block45;
                                        resultTask = (ResultTask)task2;
                                        resultStage = (ResultStage)stage;
                                        option = resultStage.activeJob();
                                        if (!(option instanceof Some)) break block46;
                                        Some some = (Some)option;
                                        job = (ActiveJob)some.x();
                                        if (!job.finished()[resultTask.outputId()]) break block47;
                                        boxedUnit = BoxedUnit.UNIT;
                                        break block48;
                                    }
                                    job.finished()[resultTask.outputId()] = true;
                                    job.numFinished_$eq(job.numFinished() + 1);
                                    if (job.numFinished() == job.numPartitions()) {
                                        this.org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished(resultStage, this.markStageAsFinished$default$2());
                                        this.cleanupStateForJobAndIndependentStages(job);
                                        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerJobEnd(job.jobId(), this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis(), JobSucceeded$.MODULE$));
                                    }
                                    try {
                                        job.listener().taskSucceeded(resultTask.outputId(), event.result());
                                        boxedUnit = BoxedUnit.UNIT;
                                    }
                                    catch (Exception exception2) {
                                        job.listener().jobFailed(new SparkDriverExecutionException(exception2));
                                        boxedUnit = BoxedUnit.UNIT;
                                    }
                                }
                                if (!None$.MODULE$.equals(option)) throw new MatchError(option);
                                this.logInfo((Function0<String>)new scala.Serializable(this, resultTask){
                                    public static final long serialVersionUID = 0L;
                                    private final ResultTask x2$2;

                                    public final String apply() {
                                        return new StringBuilder().append((Object)"Ignoring result from ").append((Object)this.x2$2).append((Object)" because its job has finished").toString();
                                    }
                                    {
                                        this.x2$2 = x2$2;
                                    }
                                });
                                BoxedUnit boxedUnit11 = BoxedUnit.UNIT;
                                break block49;
                            }
                            if (!(task2 instanceof ShuffleMapTask)) throw new MatchError(task2);
                            ShuffleMapTask shuffleMapTask = (ShuffleMapTask)task2;
                            ShuffleMapStage shuffleStage = (ShuffleMapStage)stage;
                            MapStatus status = (MapStatus)event.result();
                            String execId = status.location().executorId();
                            this.logDebug((Function0<String>)new scala.Serializable(this, execId){
                                public static final long serialVersionUID = 0L;
                                private final String execId$1;

                                public final String apply() {
                                    return new StringBuilder().append((Object)"ShuffleMapTask finished on ").append((Object)this.execId$1).toString();
                                }
                                {
                                    this.execId$1 = execId$1;
                                }
                            });
                            Object object = ((Stage)this.stageIdToStage().apply((Object)BoxesRunTime.boxToInteger((int)task.stageId()))).latestInfo().attemptNumber() == task.stageAttemptId() ? shuffleStage.pendingPartitions().$minus$eq((Object)BoxesRunTime.boxToInteger((int)task.partitionId())) : BoxedUnit.UNIT;
                            if (this.failedEpoch().contains((Object)execId) && shuffleMapTask.epoch() <= BoxesRunTime.unboxToLong((Object)this.failedEpoch().apply((Object)execId))) {
                                this.logInfo((Function0<String>)new scala.Serializable(this, execId, shuffleMapTask){
                                    public static final long serialVersionUID = 0L;
                                    private final String execId$1;
                                    private final ShuffleMapTask x3$3;

                                    public final String apply() {
                                        return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Ignoring possibly bogus ", " completion from executor ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.x3$3, this.execId$1}));
                                    }
                                    {
                                        this.execId$1 = execId$1;
                                        this.x3$3 = x3$3;
                                    }
                                });
                                hashSet = BoxedUnit.UNIT;
                            } else {
                                this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.registerMapOutput(shuffleStage.shuffleDep().shuffleId(), shuffleMapTask.partitionId(), status);
                                hashSet = shuffleStage.pendingPartitions().$minus$eq((Object)BoxesRunTime.boxToInteger((int)task.partitionId()));
                            }
                            if (this.runningStages().contains((Object)shuffleStage) && shuffleStage.pendingPartitions().isEmpty()) {
                                this.org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished(shuffleStage, this.markStageAsFinished$default$2());
                                this.logInfo((Function0<String>)new scala.Serializable(this){
                                    public static final long serialVersionUID = 0L;

                                    public final String apply() {
                                        return "looking for newly runnable stages";
                                    }
                                });
                                this.logInfo((Function0<String>)new scala.Serializable(this){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ DAGScheduler $outer;

                                    public final String apply() {
                                        return new StringBuilder().append((Object)"running: ").append(this.$outer.runningStages()).toString();
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                    }
                                });
                                this.logInfo((Function0<String>)new scala.Serializable(this){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ DAGScheduler $outer;

                                    public final String apply() {
                                        return new StringBuilder().append((Object)"waiting: ").append(this.$outer.waitingStages()).toString();
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                    }
                                });
                                this.logInfo((Function0<String>)new scala.Serializable(this){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ DAGScheduler $outer;

                                    public final String apply() {
                                        return new StringBuilder().append((Object)"failed: ").append(this.$outer.failedStages()).toString();
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                    }
                                });
                                this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.incrementEpoch();
                                this.clearCacheLocs();
                                if (shuffleStage.isAvailable()) {
                                    if (shuffleStage.mapStageJobs().nonEmpty()) {
                                        MapOutputStatistics stats2 = this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.getStatistics(shuffleStage.shuffleDep());
                                        shuffleStage.mapStageJobs().foreach((Function1)new scala.Serializable(this, stats2){
                                            public static final long serialVersionUID = 0L;
                                            private final /* synthetic */ DAGScheduler $outer;
                                            private final MapOutputStatistics stats$1;

                                            public final void apply(ActiveJob job) {
                                                this.$outer.markMapStageJobAsFinished(job, this.stats$1);
                                            }
                                            {
                                                if ($outer == null) {
                                                    throw null;
                                                }
                                                this.$outer = $outer;
                                                this.stats$1 = stats$1;
                                            }
                                        });
                                    }
                                    this.submitWaitingChildStages(shuffleStage);
                                    boxedUnit2 = BoxedUnit.UNIT;
                                } else {
                                    this.logInfo((Function0<String>)new scala.Serializable(this, shuffleStage){
                                        public static final long serialVersionUID = 0L;
                                        private final ShuffleMapStage shuffleStage$1;

                                        public final String apply() {
                                            return new StringBuilder().append((Object)"Resubmitting ").append((Object)this.shuffleStage$1).append((Object)" (").append((Object)this.shuffleStage$1.name()).append((Object)") because some of its tasks had failed: ").append((Object)this.shuffleStage$1.findMissingPartitions().mkString(", ")).toString();
                                        }
                                        {
                                            this.shuffleStage$1 = shuffleStage$1;
                                        }
                                    });
                                    this.org$apache$spark$scheduler$DAGScheduler$$submitStage(shuffleStage);
                                    boxedUnit2 = BoxedUnit.UNIT;
                                }
                            } else {
                                boxedUnit2 = BoxedUnit.UNIT;
                            }
                            BoxedUnit boxedUnit12 = boxedUnit2;
                            break block50;
                        }
                        if (Resubmitted$.MODULE$.equals(taskEndReason)) {
                            this.logInfo((Function0<String>)new scala.Serializable(this, task){
                                public static final long serialVersionUID = 0L;
                                private final Task task$2;

                                public final String apply() {
                                    return new StringBuilder().append((Object)"Resubmitted ").append((Object)this.task$2).append((Object)", so marking it as still running").toString();
                                }
                                {
                                    this.task$2 = task$2;
                                }
                            });
                            Stage stage2 = stage;
                            if (stage2 instanceof ShuffleMapStage) {
                                ShuffleMapStage shuffleMapStage = (ShuffleMapStage)stage2;
                                shuffleMapStage.pendingPartitions().$plus$eq((Object)BoxesRunTime.boxToInteger((int)task.partitionId()));
                                BoxedUnit boxedUnit13 = BoxedUnit.UNIT;
                            } else {
                                Predef$.MODULE$.assert(false, (Function0)new scala.Serializable(this){
                                    public static final long serialVersionUID = 0L;

                                    public final String apply() {
                                        return "TaskSetManagers should only send Resubmitted task statuses for tasks in ShuffleMapStages.";
                                    }
                                });
                                BoxedUnit boxedUnit14 = BoxedUnit.UNIT;
                            }
                            BoxedUnit boxedUnit15 = BoxedUnit.UNIT;
                            return;
                        } else if (taskEndReason instanceof FetchFailed) {
                            BoxedUnit boxedUnit16;
                            FetchFailed fetchFailed = (FetchFailed)taskEndReason;
                            BlockManagerId bmAddress = fetchFailed.bmAddress();
                            int shuffleId = fetchFailed.shuffleId();
                            int mapId = fetchFailed.mapId();
                            String failureMessage = fetchFailed.message();
                            Stage failedStage = (Stage)this.stageIdToStage().apply((Object)BoxesRunTime.boxToInteger((int)task.stageId()));
                            ShuffleMapStage mapStage = (ShuffleMapStage)this.shuffleIdToMapStage().apply((Object)BoxesRunTime.boxToInteger((int)shuffleId));
                            if (failedStage.latestInfo().attemptNumber() != task.stageAttemptId()) {
                                this.logInfo((Function0<String>)new scala.Serializable(this, task, failedStage){
                                    public static final long serialVersionUID = 0L;
                                    private final Task task$2;
                                    private final Stage failedStage$2;

                                    public final String apply() {
                                        return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Ignoring fetch failure from ", " as it's from ", " attempt"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.task$2, this.failedStage$2}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{" ", " and there is a more recent attempt for that stage "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.task$2.stageAttemptId())}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"(attempt ", ") running"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.failedStage$2.latestInfo().attemptNumber())}))).toString();
                                    }
                                    {
                                        this.task$2 = task$2;
                                        this.failedStage$2 = failedStage$2;
                                    }
                                });
                                boxedUnit16 = BoxedUnit.UNIT;
                            } else {
                                boolean shouldAbortStage;
                                Object object;
                                if (this.runningStages().contains((Object)failedStage)) {
                                    this.logInfo((Function0<String>)new scala.Serializable(this, failedStage, mapStage){
                                        public static final long serialVersionUID = 0L;
                                        private final Stage failedStage$2;
                                        private final ShuffleMapStage mapStage$1;

                                        public final String apply() {
                                            return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Marking ", " (", ") as failed "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.failedStage$2, this.failedStage$2.name()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"due to a fetch failure from ", " (", ")"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.mapStage$1, this.mapStage$1.name()}))).toString();
                                        }
                                        {
                                            this.failedStage$2 = failedStage$2;
                                            this.mapStage$1 = mapStage$1;
                                        }
                                    });
                                    this.org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished(failedStage, (Option<String>)new Some((Object)failureMessage));
                                } else {
                                    this.logDebug((Function0<String>)new scala.Serializable(this, task, failedStage){
                                        public static final long serialVersionUID = 0L;
                                        private final Task task$2;
                                        private final Stage failedStage$2;

                                        public final String apply() {
                                            return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Received fetch failure from ", ", but its from ", " which is no "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.task$2, this.failedStage$2}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"longer running"})).s((Seq)Nil$.MODULE$)).toString();
                                        }
                                        {
                                            this.task$2 = task$2;
                                            this.failedStage$2 = failedStage$2;
                                        }
                                    });
                                }
                                failedStage.fetchFailedAttemptIds().add((Object)BoxesRunTime.boxToInteger((int)task.stageAttemptId()));
                                boolean bl = shouldAbortStage = failedStage.fetchFailedAttemptIds().size() >= this.maxConsecutiveStageAttempts() || this.disallowStageRetryForTest();
                                if (shouldAbortStage) {
                                    String abortMessage = this.disallowStageRetryForTest() ? "Fetch failure will not retry stage due to testing config" : new StringOps(Predef$.MODULE$.augmentString(new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " (", ")\n                 |has failed the maximum allowable number of\n                 |times: ", ".\n                 |Most recent failure reason: ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{failedStage, failedStage.name(), BoxesRunTime.boxToInteger((int)this.maxConsecutiveStageAttempts()), failureMessage})))).stripMargin().replaceAll("\n", " ");
                                    this.abortStage(failedStage, abortMessage, (Option<Throwable>)None$.MODULE$);
                                    object = BoxedUnit.UNIT;
                                } else {
                                    boolean noResubmitEnqueued = !this.failedStages().contains((Object)failedStage);
                                    this.failedStages().$plus$eq((Object)failedStage);
                                    this.failedStages().$plus$eq((Object)mapStage);
                                    if (noResubmitEnqueued) {
                                        this.logInfo((Function0<String>)new scala.Serializable(this, failedStage, mapStage){
                                            public static final long serialVersionUID = 0L;
                                            private final Stage failedStage$2;
                                            private final ShuffleMapStage mapStage$1;

                                            public final String apply() {
                                                return new StringBuilder().append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Resubmitting ", " (", ") and "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.mapStage$1, this.mapStage$1.name()}))).append((Object)new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " (", ") due to fetch failure"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.failedStage$2, this.failedStage$2.name()}))).toString();
                                            }
                                            {
                                                this.failedStage$2 = failedStage$2;
                                                this.mapStage$1 = mapStage$1;
                                            }
                                        });
                                        object = this.messageScheduler().schedule(new Runnable(this){
                                            private final /* synthetic */ DAGScheduler $outer;

                                            public void run() {
                                                this.$outer.eventProcessLoop().post(org.apache.spark.scheduler.ResubmitFailedStages$.MODULE$);
                                            }
                                            {
                                                if ($outer == null) {
                                                    throw null;
                                                }
                                                this.$outer = $outer;
                                            }
                                        }, (long)DAGScheduler$.MODULE$.RESUBMIT_TIMEOUT(), TimeUnit.MILLISECONDS);
                                    } else {
                                        object = BoxedUnit.UNIT;
                                    }
                                }
                                if (mapId != -1) {
                                    this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.unregisterMapOutput(shuffleId, mapId, bmAddress);
                                }
                                if (bmAddress == null) {
                                    boxedUnit16 = BoxedUnit.UNIT;
                                } else {
                                    None$ hostToUnregisterOutputs = this.env.blockManager().externalShuffleServiceEnabled() && this.unRegisterOutputOnHostOnFetchFailure() ? new Some((Object)bmAddress.host()) : None$.MODULE$;
                                    this.removeExecutorAndUnregisterOutputs(bmAddress.executorId(), true, (Option<String>)hostToUnregisterOutputs, (Option<Object>)new Some((Object)BoxesRunTime.boxToLong((long)task.epoch())));
                                    boxedUnit16 = BoxedUnit.UNIT;
                                }
                            }
                            BoxedUnit boxedUnit17 = boxedUnit16;
                            return;
                        } else if (taskEndReason instanceof TaskCommitDenied) {
                            BoxedUnit boxedUnit18 = BoxedUnit.UNIT;
                            return;
                        } else if (taskEndReason instanceof ExceptionFailure) {
                            BoxedUnit boxedUnit19 = BoxedUnit.UNIT;
                            return;
                        } else if (TaskResultLost$.MODULE$.equals(taskEndReason)) {
                            BoxedUnit boxedUnit20 = BoxedUnit.UNIT;
                            return;
                        } else {
                            boolean bl = taskEndReason instanceof ExecutorLostFailure ? true : (taskEndReason instanceof TaskKilled ? true : UnknownReason$.MODULE$.equals(taskEndReason));
                            if (!bl) throw new MatchError((Object)taskEndReason);
                            BoxedUnit boxedUnit21 = BoxedUnit.UNIT;
                        }
                        return;
                    }
                    this.postTaskEnd(event);
                    return;
                }
                BoxedUnit boxedUnit22 = boxedUnit;
            }
            BoxedUnit boxedUnit = BoxedUnit.UNIT;
        }
        BoxedUnit boxedUnit = BoxedUnit.UNIT;
    }

    public void handleExecutorLost(String execId, boolean workerLost) {
        boolean fileLost = workerLost || !this.env.blockManager().externalShuffleServiceEnabled();
        this.removeExecutorAndUnregisterOutputs(execId, fileLost, (Option<String>)None$.MODULE$, (Option<Object>)None$.MODULE$);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void removeExecutorAndUnregisterOutputs(String execId, boolean fileLost, Option<String> hostToUnregisterOutputs, Option<Object> maybeEpoch) {
        long currentEpoch = BoxesRunTime.unboxToLong((Object)maybeEpoch.getOrElse((Function0)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;

            public final long apply() {
                return this.apply$mcJ$sp();
            }

            public long apply$mcJ$sp() {
                return this.$outer.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.getEpoch();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }));
        if (this.failedEpoch().contains((Object)execId) && BoxesRunTime.unboxToLong((Object)this.failedEpoch().apply((Object)execId)) >= currentEpoch) return;
        this.failedEpoch().update((Object)execId, (Object)BoxesRunTime.boxToLong((long)currentEpoch));
        this.logInfo((Function0<String>)new scala.Serializable(this, execId, currentEpoch){
            public static final long serialVersionUID = 0L;
            private final String execId$2;
            private final long currentEpoch$1;

            public final String apply() {
                return new StringOps(Predef$.MODULE$.augmentString("Executor lost: %s (epoch %d)")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.execId$2, BoxesRunTime.boxToLong((long)this.currentEpoch$1)}));
            }
            {
                this.execId$2 = execId$2;
                this.currentEpoch$1 = currentEpoch$1;
            }
        });
        this.blockManagerMaster.removeExecutor(execId);
        if (fileLost) {
            Option<String> option = hostToUnregisterOutputs;
            if (option instanceof Some) {
                Some some = (Some)option;
                String host = (String)some.x();
                this.logInfo((Function0<String>)new scala.Serializable(this, currentEpoch, host){
                    public static final long serialVersionUID = 0L;
                    private final long currentEpoch$1;
                    private final String host$1;

                    public final String apply() {
                        return new StringOps(Predef$.MODULE$.augmentString("Shuffle files lost for host: %s (epoch %d)")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.host$1, BoxesRunTime.boxToLong((long)this.currentEpoch$1)}));
                    }
                    {
                        this.currentEpoch$1 = currentEpoch$1;
                        this.host$1 = host$1;
                    }
                });
                this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.removeOutputsOnHost(host);
                BoxedUnit boxedUnit = BoxedUnit.UNIT;
            } else {
                if (!None$.MODULE$.equals(option)) throw new MatchError(option);
                this.logInfo((Function0<String>)new scala.Serializable(this, execId, currentEpoch){
                    public static final long serialVersionUID = 0L;
                    private final String execId$2;
                    private final long currentEpoch$1;

                    public final String apply() {
                        return new StringOps(Predef$.MODULE$.augmentString("Shuffle files lost for executor: %s (epoch %d)")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.execId$2, BoxesRunTime.boxToLong((long)this.currentEpoch$1)}));
                    }
                    {
                        this.execId$2 = execId$2;
                        this.currentEpoch$1 = currentEpoch$1;
                    }
                });
                this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.removeOutputsOnExecutor(execId);
                BoxedUnit boxedUnit = BoxedUnit.UNIT;
            }
            this.clearCacheLocs();
            return;
        } else {
            this.logDebug((Function0<String>)new scala.Serializable(this, execId, currentEpoch){
                public static final long serialVersionUID = 0L;
                private final String execId$2;
                private final long currentEpoch$1;

                public final String apply() {
                    return new StringOps(Predef$.MODULE$.augmentString("Additional executor lost message for %s (epoch %d)")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.execId$2, BoxesRunTime.boxToLong((long)this.currentEpoch$1)}));
                }
                {
                    this.execId$2 = execId$2;
                    this.currentEpoch$1 = currentEpoch$1;
                }
            });
        }
    }

    private Option<Object> removeExecutorAndUnregisterOutputs$default$4() {
        return None$.MODULE$;
    }

    public void handleWorkerRemoved(String workerId, String host, String message) {
        this.logInfo((Function0<String>)new scala.Serializable(this, workerId, host){
            public static final long serialVersionUID = 0L;
            private final String workerId$1;
            private final String host$2;

            public final String apply() {
                return new StringOps(Predef$.MODULE$.augmentString("Shuffle files lost for worker %s on host %s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workerId$1, this.host$2}));
            }
            {
                this.workerId$1 = workerId$1;
                this.host$2 = host$2;
            }
        });
        this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker.removeOutputsOnHost(host);
        this.clearCacheLocs();
    }

    public void handleExecutorAdded(String execId, String host) {
        if (this.failedEpoch().contains((Object)execId)) {
            this.logInfo((Function0<String>)new scala.Serializable(this, host){
                public static final long serialVersionUID = 0L;
                private final String host$3;

                public final String apply() {
                    return new StringBuilder().append((Object)"Host added was in lost list earlier: ").append((Object)this.host$3).toString();
                }
                {
                    this.host$3 = host$3;
                }
            });
            this.failedEpoch().$minus$eq((Object)execId);
        }
    }

    public void handleStageCancellation(int stageId, Option<String> reason) {
        Option option;
        block4 : {
            block3 : {
                block2 : {
                    option = this.stageIdToStage().get((Object)BoxesRunTime.boxToInteger((int)stageId));
                    if (!(option instanceof Some)) break block2;
                    Some some = (Some)option;
                    Stage stage = (Stage)some.x();
                    int[] jobsThatUseStage = (int[])stage.jobIds().toArray(ClassTag$.MODULE$.Int());
                    Predef$.MODULE$.intArrayOps(jobsThatUseStage).foreach((Function1)new scala.Serializable(this, stageId, reason){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ DAGScheduler $outer;
                        private final int stageId$3;
                        private final Option reason$3;

                        public final void apply(int jobId) {
                            this.apply$mcVI$sp(jobId);
                        }

                        public void apply$mcVI$sp(int jobId) {
                            Option option;
                            block4 : {
                                String string;
                                block3 : {
                                    block2 : {
                                        option = this.reason$3;
                                        if (!(option instanceof Some)) break block2;
                                        Some some = (Some)option;
                                        String originalReason = (String)some.x();
                                        string = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"because ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{originalReason}));
                                        break block3;
                                    }
                                    if (!None$.MODULE$.equals((Object)option)) break block4;
                                    string = new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"because Stage ", " was cancelled"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.stageId$3)}));
                                }
                                String reasonStr = string;
                                this.$outer.handleJobCancellation(jobId, (Option<String>)scala.Option$.MODULE$.apply((Object)reasonStr));
                                return;
                            }
                            throw new MatchError((Object)option);
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.stageId$3 = stageId$3;
                            this.reason$3 = reason$3;
                        }
                    });
                    BoxedUnit boxedUnit = BoxedUnit.UNIT;
                    break block3;
                }
                if (!None$.MODULE$.equals((Object)option)) break block4;
                this.logInfo((Function0<String>)new scala.Serializable(this, stageId){
                    public static final long serialVersionUID = 0L;
                    private final int stageId$3;

                    public final String apply() {
                        return new StringBuilder().append((Object)"No active jobs to kill for Stage ").append((Object)BoxesRunTime.boxToInteger((int)this.stageId$3)).toString();
                    }
                    {
                        this.stageId$3 = stageId$3;
                    }
                });
                BoxedUnit boxedUnit = BoxedUnit.UNIT;
            }
            return;
        }
        throw new MatchError((Object)option);
    }

    public void handleJobCancellation(int jobId, Option<String> reason) {
        if (this.jobIdToStageIds().contains((Object)BoxesRunTime.boxToInteger((int)jobId))) {
            this.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages((ActiveJob)this.jobIdToActiveJob().apply((Object)BoxesRunTime.boxToInteger((int)jobId)), new StringOps(Predef$.MODULE$.augmentString("Job %d cancelled %s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)jobId), reason.getOrElse((Function0)new scala.Serializable(this){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "";
                }
            })})), this.failJobAndIndependentStages$default$3());
        } else {
            this.logDebug((Function0<String>)new scala.Serializable(this, jobId){
                public static final long serialVersionUID = 0L;
                private final int jobId$3;

                public final String apply() {
                    return new StringBuilder().append((Object)"Trying to cancel unregistered job ").append((Object)BoxesRunTime.boxToInteger((int)this.jobId$3)).toString();
                }
                {
                    this.jobId$3 = jobId$3;
                }
            });
        }
    }

    public void org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished(Stage stage, Option<String> errorMessage) {
        String string;
        Option<Object> option = stage.latestInfo().submissionTime();
        if (option instanceof Some) {
            Some some = (Some)option;
            long t = BoxesRunTime.unboxToLong((Object)some.x());
            string = new StringOps(Predef$.MODULE$.augmentString("%.03f")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToDouble((double)((double)(this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis() - t) / 1000.0))}));
        } else {
            string = "Unknown";
        }
        String serviceTime = string;
        if (errorMessage.isEmpty()) {
            this.logInfo((Function0<String>)new scala.Serializable(this, stage, serviceTime){
                public static final long serialVersionUID = 0L;
                private final Stage stage$3;
                private final String serviceTime$1;

                public final String apply() {
                    return new StringOps(Predef$.MODULE$.augmentString("%s (%s) finished in %s s")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.stage$3, this.stage$3.name(), this.serviceTime$1}));
                }
                {
                    this.stage$3 = stage$3;
                    this.serviceTime$1 = serviceTime$1;
                }
            });
            stage.latestInfo().completionTime_$eq((Option<Object>)new Some((Object)BoxesRunTime.boxToLong((long)this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis())));
            stage.clearFailures();
        } else {
            stage.latestInfo().stageFailed((String)errorMessage.get());
            this.logInfo((Function0<String>)new scala.Serializable(this, stage, errorMessage, serviceTime){
                public static final long serialVersionUID = 0L;
                private final Stage stage$3;
                private final Option errorMessage$1;
                private final String serviceTime$1;

                public final String apply() {
                    return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " (", ") failed in ", " s due to ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.stage$3, this.stage$3.name(), this.serviceTime$1, this.errorMessage$1.get()}));
                }
                {
                    this.stage$3 = stage$3;
                    this.errorMessage$1 = errorMessage$1;
                    this.serviceTime$1 = serviceTime$1;
                }
            });
        }
        this.outputCommitCoordinator().stageEnd(stage.id());
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerStageCompleted(stage.latestInfo()));
        this.runningStages().$minus$eq((Object)stage);
    }

    private Option<String> markStageAsFinished$default$2() {
        return None$.MODULE$;
    }

    public void abortStage(Stage failedStage, String reason, Option<Throwable> exception2) {
        if (this.stageIdToStage().contains((Object)BoxesRunTime.boxToInteger((int)failedStage.id()))) {
            Seq dependentJobs = ((SetLike)this.activeJobs().filter((Function1)new scala.Serializable(this, failedStage){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ DAGScheduler $outer;
                private final Stage failedStage$1;

                public final boolean apply(ActiveJob job) {
                    return this.$outer.org$apache$spark$scheduler$DAGScheduler$$stageDependsOn(job.finalStage(), this.failedStage$1);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.failedStage$1 = failedStage$1;
                }
            })).toSeq();
            failedStage.latestInfo().completionTime_$eq((Option<Object>)new Some((Object)BoxesRunTime.boxToLong((long)this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis())));
            dependentJobs.foreach((Function1)new scala.Serializable(this, reason, exception2){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ DAGScheduler $outer;
                private final String reason$2;
                private final Option exception$2;

                public final void apply(ActiveJob job) {
                    this.$outer.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(job, new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Job aborted due to stage failure: ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.reason$2})), (Option<Throwable>)this.exception$2);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.reason$2 = reason$2;
                    this.exception$2 = exception$2;
                }
            });
            if (dependentJobs.isEmpty()) {
                this.logInfo((Function0<String>)new scala.Serializable(this, failedStage){
                    public static final long serialVersionUID = 0L;
                    private final Stage failedStage$1;

                    public final String apply() {
                        return new StringBuilder().append((Object)"Ignoring failure of ").append((Object)this.failedStage$1).append((Object)" because all jobs depending on it are done").toString();
                    }
                    {
                        this.failedStage$1 = failedStage$1;
                    }
                });
            }
            return;
        }
    }

    public void org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(ActiveJob job, String failureReason, Option<Throwable> exception2) {
        SparkException error2 = new SparkException(failureReason, (Throwable)exception2.getOrElse((Function0)new scala.Serializable(this){
            public static final long serialVersionUID = 0L;

            public final scala.runtime.Null$ apply() {
                return null;
            }
        }));
        BooleanRef ableToCancelStages = BooleanRef.create((boolean)true);
        boolean shouldInterruptThread = job.properties() == null ? false : new StringOps(Predef$.MODULE$.augmentString(job.properties().getProperty(SparkContext$.MODULE$.SPARK_JOB_INTERRUPT_ON_CANCEL(), "false"))).toBoolean();
        HashSet stages = (HashSet)this.jobIdToStageIds().apply((Object)BoxesRunTime.boxToInteger((int)job.jobId()));
        if (stages.isEmpty()) {
            this.logError((Function0<String>)new scala.Serializable(this, job){
                public static final long serialVersionUID = 0L;
                private final ActiveJob job$3;

                public final String apply() {
                    return new StringBuilder().append((Object)"No stages registered for job ").append((Object)BoxesRunTime.boxToInteger((int)this.job$3.jobId())).toString();
                }
                {
                    this.job$3 = job$3;
                }
            });
        }
        stages.foreach((Function1)new scala.Serializable(this, job, failureReason, ableToCancelStages, shouldInterruptThread){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ DAGScheduler $outer;
            public final ActiveJob job$3;
            private final String failureReason$1;
            private final BooleanRef ableToCancelStages$1;
            private final boolean shouldInterruptThread$1;

            public final void apply(int stageId) {
                this.apply$mcVI$sp(stageId);
            }

            public void apply$mcVI$sp(int stageId) {
                block3 : {
                    block2 : {
                        block4 : {
                            Option jobsForStage = this.$outer.stageIdToStage().get((Object)BoxesRunTime.boxToInteger((int)stageId)).map((Function1)new scala.Serializable(this){
                                public static final long serialVersionUID = 0L;

                                public final HashSet<Object> apply(Stage x$19) {
                                    return x$19.jobIds();
                                }
                            });
                            if (jobsForStage.isEmpty() || !((HashSet)jobsForStage.get()).contains((Object)BoxesRunTime.boxToInteger((int)this.job$3.jobId()))) break block2;
                            if (((HashSet)jobsForStage.get()).size() != 1) break block3;
                            if (!this.$outer.stageIdToStage().contains((Object)BoxesRunTime.boxToInteger((int)stageId))) break block4;
                            Stage stage = (Stage)this.$outer.stageIdToStage().apply((Object)BoxesRunTime.boxToInteger((int)stageId));
                            if (!this.$outer.runningStages().contains((Object)stage)) break block3;
                            try {
                                this.$outer.taskScheduler().cancelTasks(stageId, this.shouldInterruptThread$1);
                                this.$outer.org$apache$spark$scheduler$DAGScheduler$$markStageAsFinished(stage, (Option<String>)new Some((Object)this.failureReason$1));
                            }
                            catch (java.lang.UnsupportedOperationException unsupportedOperationException) {
                                this.$outer.logInfo((Function0<String>)new scala.Serializable(this, stageId){
                                    public static final long serialVersionUID = 0L;
                                    private final int stageId$4;

                                    public final String apply() {
                                        return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Could not cancel tasks for stage ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.stageId$4)}));
                                    }
                                    {
                                        this.stageId$4 = stageId$4;
                                    }
                                }, unsupportedOperationException);
                                this.ableToCancelStages$1.elem = false;
                            }
                        }
                        this.$outer.logError((Function0<String>)new scala.Serializable(this, stageId){
                            public static final long serialVersionUID = 0L;
                            private final int stageId$4;

                            public final String apply() {
                                return new StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Missing Stage for stage with id ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.stageId$4)}));
                            }
                            {
                                this.stageId$4 = stageId$4;
                            }
                        });
                        break block3;
                    }
                    this.$outer.logError((Function0<String>)new scala.Serializable(this, stageId){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ $anonfun$org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages$1 $outer;
                        private final int stageId$4;

                        public final String apply() {
                            return new StringOps(Predef$.MODULE$.augmentString("Job %d not registered for stage %d even though that stage was registered for the job")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.$outer.job$3.jobId()), BoxesRunTime.boxToInteger((int)this.stageId$4)}));
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.stageId$4 = stageId$4;
                        }
                    });
                }
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.job$3 = job$3;
                this.failureReason$1 = failureReason$1;
                this.ableToCancelStages$1 = ableToCancelStages$1;
                this.shouldInterruptThread$1 = shouldInterruptThread$1;
            }
        });
        if (ableToCancelStages.elem) {
            this.cleanupStateForJobAndIndependentStages(job);
            job.listener().jobFailed(error2);
            this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerJobEnd(job.jobId(), this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis(), new JobFailed(error2)));
        }
    }

    private Option<Throwable> failJobAndIndependentStages$default$3() {
        return None$.MODULE$;
    }

    public boolean org$apache$spark$scheduler$DAGScheduler$$stageDependsOn(Stage stage, Stage target) {
        block5 : {
            block4 : {
                Stage stage2;
                Stage stage3;
                block3 : {
                    stage2 = target;
                    if (stage != null) break block3;
                    if (stage2 == null) break block4;
                    break block5;
                }
                if (!((Object)stage3).equals(stage2)) break block5;
            }
            return true;
        }
        HashSet visitedRdds = new HashSet();
        ArrayStack waitingForVisit = new ArrayStack();
        waitingForVisit.push(stage.rdd());
        while (waitingForVisit.nonEmpty()) {
            this.visit$2((RDD)waitingForVisit.pop(), stage, visitedRdds, waitingForVisit);
        }
        return visitedRdds.contains(target.rdd());
    }

    public Seq<TaskLocation> getPreferredLocs(RDD<?> rdd, int partition2) {
        return this.org$apache$spark$scheduler$DAGScheduler$$getPreferredLocsInternal(rdd, partition2, new HashSet());
    }

    public Seq<TaskLocation> org$apache$spark$scheduler$DAGScheduler$$getPreferredLocsInternal(RDD<?> rdd, int partition2, HashSet<Tuple2<RDD<?>, Object>> visited) {
        NonLocalReturnControl nonLocalReturnControl2;
        block6 : {
            Seq seq;
            Object object = new Object();
            try {
                if (visited.add((Object)new Tuple2(rdd, (Object)BoxesRunTime.boxToInteger((int)partition2)))) {
                    Seq cached = (Seq)this.getCacheLocs(rdd).apply(partition2);
                    if (cached.nonEmpty()) {
                        return cached;
                    }
                    List rddPrefs = rdd.preferredLocations(rdd.partitions()[partition2]).toList();
                    if (rddPrefs.nonEmpty()) {
                        return (Seq)rddPrefs.map((Function1)new scala.Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final TaskLocation apply(String x$20) {
                                return org.apache.spark.scheduler.TaskLocation$.MODULE$.apply(x$20);
                            }
                        }, List$.MODULE$.canBuildFrom());
                    }
                } else {
                    return Nil$.MODULE$;
                }
                rdd.dependencies().foreach((Function1)new scala.Serializable(this, partition2, visited, object){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ DAGScheduler $outer;
                    private final int partition$1;
                    public final HashSet visited$2;
                    public final Object nonLocalReturnKey1$1;

                    public final void apply(Dependency<?> x0$3) {
                        Dependency<?> dependency = x0$3;
                        if (dependency instanceof org.apache.spark.NarrowDependency) {
                            org.apache.spark.NarrowDependency narrowDependency = (org.apache.spark.NarrowDependency)dependency;
                            narrowDependency.getParents(this.partition$1).foreach((Function1)new scala.Serializable(this, narrowDependency){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ $anonfun$org$apache$spark$scheduler$DAGScheduler$$getPreferredLocsInternal$2 $outer;
                                private final org.apache.spark.NarrowDependency x2$3;

                                public final void apply(int inPart) {
                                    this.apply$mcVI$sp(inPart);
                                }

                                public void apply$mcVI$sp(int inPart) {
                                    Seq<TaskLocation> locs;
                                    block4 : {
                                        block3 : {
                                            Nil$ nil$;
                                            Seq<TaskLocation> seq;
                                            block2 : {
                                                nil$ = Nil$.MODULE$;
                                                locs = this.$outer.org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer().org$apache$spark$scheduler$DAGScheduler$$getPreferredLocsInternal(this.x2$3.rdd(), inPart, this.$outer.visited$2);
                                                if (locs != null) break block2;
                                                if (nil$ == null) break block3;
                                                break block4;
                                            }
                                            if (!seq.equals((Object)nil$)) break block4;
                                        }
                                        return;
                                    }
                                    throw new NonLocalReturnControl(this.$outer.nonLocalReturnKey1$1, locs);
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                    this.x2$3 = x2$3;
                                }
                            });
                            BoxedUnit boxedUnit = BoxedUnit.UNIT;
                        } else {
                            BoxedUnit boxedUnit = BoxedUnit.UNIT;
                        }
                    }

                    public /* synthetic */ DAGScheduler org$apache$spark$scheduler$DAGScheduler$$anonfun$$$outer() {
                        return this.$outer;
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.partition$1 = partition$1;
                        this.visited$2 = visited$2;
                        this.nonLocalReturnKey1$1 = nonLocalReturnKey1$1;
                    }
                });
                seq = Nil$.MODULE$;
            }
            catch (NonLocalReturnControl nonLocalReturnControl2) {
                if (nonLocalReturnControl2.key() != object) break block6;
                seq = (Seq)nonLocalReturnControl2.value();
            }
            return seq;
        }
        throw nonLocalReturnControl2;
    }

    public void markMapStageJobAsFinished(ActiveJob job, MapOutputStatistics stats2) {
        job.finished()[0] = true;
        job.numFinished_$eq(job.numFinished() + 1);
        job.listener().taskSucceeded(0, stats2);
        this.cleanupStateForJobAndIndependentStages(job);
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus.post(new SparkListenerJobEnd(job.jobId(), this.org$apache$spark$scheduler$DAGScheduler$$clock.getTimeMillis(), JobSucceeded$.MODULE$));
    }

    public void stop() {
        this.messageScheduler().shutdownNow();
        this.eventProcessLoop().stop();
        this.taskScheduler().stop();
    }

    private final void visit$1(RDD rdd, Stage stage$1, HashSet missing$1, HashSet visited$1, ArrayStack waitingForVisit$3) {
        if (!visited$1.apply((Object)rdd)) {
            visited$1.$plus$eq((Object)rdd);
            boolean rddHasUncachedPartitions = this.getCacheLocs(rdd).contains((Object)Nil$.MODULE$);
            if (rddHasUncachedPartitions) {
                rdd.dependencies().foreach((Function1)new scala.Serializable(this, stage$1, missing$1, waitingForVisit$3){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ DAGScheduler $outer;
                    private final Stage stage$1;
                    private final HashSet missing$1;
                    private final ArrayStack waitingForVisit$3;

                    public final Object apply(Dependency<?> dep) {
                        Dependency<?> dependency;
                        block4 : {
                            BoxedUnit boxedUnit;
                            block3 : {
                                block2 : {
                                    dependency = dep;
                                    if (!(dependency instanceof ShuffleDependency)) break block2;
                                    ShuffleDependency shuffleDependency = (ShuffleDependency)dependency;
                                    ShuffleMapStage mapStage = this.$outer.org$apache$spark$scheduler$DAGScheduler$$getOrCreateShuffleMapStage(shuffleDependency, this.stage$1.firstJobId());
                                    boxedUnit = mapStage.isAvailable() ? BoxedUnit.UNIT : this.missing$1.$plus$eq((Object)mapStage);
                                    break block3;
                                }
                                if (!(dependency instanceof org.apache.spark.NarrowDependency)) break block4;
                                org.apache.spark.NarrowDependency narrowDependency = (org.apache.spark.NarrowDependency)dependency;
                                this.waitingForVisit$3.push(narrowDependency.rdd());
                                boxedUnit = BoxedUnit.UNIT;
                            }
                            return boxedUnit;
                        }
                        throw new MatchError(dependency);
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.stage$1 = stage$1;
                        this.missing$1 = missing$1;
                        this.waitingForVisit$3 = waitingForVisit$3;
                    }
                });
            }
        }
    }

    private final void updateJobIdStageIdMapsList$1(List stages, int jobId$2) {
        while (stages.nonEmpty()) {
            Stage s = (Stage)stages.head();
            s.jobIds().$plus$eq((Object)BoxesRunTime.boxToInteger((int)jobId$2));
            ((HashSet)this.jobIdToStageIds().getOrElseUpdate((Object)BoxesRunTime.boxToInteger((int)jobId$2), (Function0)new scala.Serializable(this){
                public static final long serialVersionUID = 0L;

                public final HashSet<Object> apply() {
                    return new HashSet();
                }
            })).$plus$eq((Object)BoxesRunTime.boxToInteger((int)s.id()));
            List parentsWithoutThisJobId = (List)s.parents().filter((Function1)new scala.Serializable(this, jobId$2){
                public static final long serialVersionUID = 0L;
                private final int jobId$2;

                public final boolean apply(Stage x$1) {
                    return !x$1.jobIds().contains((Object)BoxesRunTime.boxToInteger((int)this.jobId$2));
                }
                {
                    this.jobId$2 = jobId$2;
                }
            });
            stages = (List)parentsWithoutThisJobId.$plus$plus((GenTraversableOnce)stages.tail(), List$.MODULE$.canBuildFrom());
        }
    }

    private final void visit$2(RDD rdd, Stage stage$6, HashSet visitedRdds$1, ArrayStack waitingForVisit$4) {
        if (!visitedRdds$1.apply((Object)rdd)) {
            visitedRdds$1.$plus$eq((Object)rdd);
            rdd.dependencies().foreach((Function1)new scala.Serializable(this, stage$6, waitingForVisit$4){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ DAGScheduler $outer;
                private final Stage stage$6;
                private final ArrayStack waitingForVisit$4;

                public final void apply(Dependency<?> dep) {
                    Dependency<?> dependency;
                    block7 : {
                        block6 : {
                            block5 : {
                                BoxedUnit boxedUnit;
                                dependency = dep;
                                if (!(dependency instanceof ShuffleDependency)) break block5;
                                ShuffleDependency shuffleDependency = (ShuffleDependency)dependency;
                                ShuffleMapStage mapStage = this.$outer.org$apache$spark$scheduler$DAGScheduler$$getOrCreateShuffleMapStage(shuffleDependency, this.stage$6.firstJobId());
                                if (mapStage.isAvailable()) {
                                    boxedUnit = BoxedUnit.UNIT;
                                } else {
                                    this.waitingForVisit$4.push(mapStage.rdd());
                                    boxedUnit = BoxedUnit.UNIT;
                                }
                                BoxedUnit boxedUnit2 = boxedUnit;
                                break block6;
                            }
                            if (!(dependency instanceof org.apache.spark.NarrowDependency)) break block7;
                            org.apache.spark.NarrowDependency narrowDependency = (org.apache.spark.NarrowDependency)dependency;
                            this.waitingForVisit$4.push(narrowDependency.rdd());
                            BoxedUnit boxedUnit = BoxedUnit.UNIT;
                        }
                        return;
                    }
                    throw new MatchError(dependency);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.stage$6 = stage$6;
                    this.waitingForVisit$4 = waitingForVisit$4;
                }
            });
        }
    }

    public DAGScheduler(SparkContext sc, TaskScheduler taskScheduler, LiveListenerBus listenerBus, MapOutputTrackerMaster mapOutputTracker, BlockManagerMaster blockManagerMaster, SparkEnv env, Clock clock) {
        this.sc = sc;
        this.taskScheduler = taskScheduler;
        this.org$apache$spark$scheduler$DAGScheduler$$listenerBus = listenerBus;
        this.org$apache$spark$scheduler$DAGScheduler$$mapOutputTracker = mapOutputTracker;
        this.blockManagerMaster = blockManagerMaster;
        this.env = env;
        this.org$apache$spark$scheduler$DAGScheduler$$clock = clock;
        Logging$class.$init$(this);
        this.metricsSource = new DAGSchedulerSource(this);
        this.nextJobId = new AtomicInteger(0);
        this.nextStageId = new AtomicInteger(0);
        this.jobIdToStageIds = new HashMap();
        this.stageIdToStage = new HashMap();
        this.shuffleIdToMapStage = new HashMap();
        this.jobIdToActiveJob = new HashMap();
        this.waitingStages = new HashSet();
        this.runningStages = new HashSet();
        this.failedStages = new HashSet();
        this.activeJobs = new HashSet();
        this.cacheLocs = new HashMap();
        this.failedEpoch = new HashMap();
        this.outputCommitCoordinator = env.outputCommitCoordinator();
        this.closureSerializer = SparkEnv$.MODULE$.get().closureSerializer().newInstance();
        this.disallowStageRetryForTest = sc.getConf().getBoolean("spark.test.noStageRetry", false);
        this.unRegisterOutputOnHostOnFetchFailure = BoxesRunTime.unboxToBoolean((Object)sc.getConf().get(org.apache.spark.internal.config.package$.MODULE$.UNREGISTER_OUTPUT_ON_HOST_ON_FETCH_FAILURE()));
        this.maxConsecutiveStageAttempts = sc.getConf().getInt("spark.stage.maxConsecutiveAttempts", DAGScheduler$.MODULE$.DEFAULT_MAX_CONSECUTIVE_STAGE_ATTEMPTS());
        this.messageScheduler = ThreadUtils$.MODULE$.newDaemonSingleThreadScheduledExecutor("dag-scheduler-message");
        this.eventProcessLoop = new DAGSchedulerEventProcessLoop(this);
        taskScheduler.setDAGScheduler(this);
        this.eventProcessLoop().start();
    }

    public DAGScheduler(SparkContext sc, TaskScheduler taskScheduler) {
        this(sc, taskScheduler, sc.listenerBus(), (MapOutputTrackerMaster)sc.env().mapOutputTracker(), sc.env().blockManager().master(), sc.env(), DAGScheduler$.MODULE$.$lessinit$greater$default$7());
    }

    public DAGScheduler(SparkContext sc) {
        this(sc, sc.taskScheduler());
    }
}

