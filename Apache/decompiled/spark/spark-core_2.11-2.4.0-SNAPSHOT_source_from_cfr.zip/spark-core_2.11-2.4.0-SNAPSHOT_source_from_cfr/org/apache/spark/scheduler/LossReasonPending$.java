/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.ExecutorLossReason;

public final class LossReasonPending$
extends ExecutorLossReason {
    public static final LossReasonPending$ MODULE$;

    public static {
        new org.apache.spark.scheduler.LossReasonPending$();
    }

    private Object readResolve() {
        return MODULE$;
    }

    private LossReasonPending$() {
        super("Pending loss reason.");
        MODULE$ = this;
    }
}

