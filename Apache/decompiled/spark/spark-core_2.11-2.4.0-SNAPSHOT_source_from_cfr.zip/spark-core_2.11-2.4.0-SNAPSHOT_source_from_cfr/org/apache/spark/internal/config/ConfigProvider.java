/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Option
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.internal.config;

import scala.Option;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001\r2\u0001\"\u0001\u0002\u0011\u0002G\u0005a\u0001\u0004\u0002\u000f\u0007>tg-[4Qe>4\u0018\u000eZ3s\u0015\t\u0019A!\u0001\u0004d_:4\u0017n\u001a\u0006\u0003\u000b\u0019\t\u0001\"\u001b8uKJt\u0017\r\u001c\u0006\u0003\u000f!\tQa\u001d9be.T!!\u0003\u0006\u0002\r\u0005\u0004\u0018m\u00195f\u0015\u0005Y\u0011aA8sON\u0011\u0001!\u0004\t\u0003\u001dEi\u0011a\u0004\u0006\u0002!\u0005)1oY1mC&\u0011!c\u0004\u0002\u0007\u0003:L(+\u001a4\t\u000bQ\u0001a\u0011\u0001\f\u0002\u0007\u001d,Go\u0001\u0001\u0015\u0005]\t\u0003c\u0001\b\u00195%\u0011\u0011d\u0004\u0002\u0007\u001fB$\u0018n\u001c8\u0011\u0005mqbB\u0001\b\u001d\u0013\tir\"\u0001\u0004Qe\u0016$WMZ\u0005\u0003?\u0001\u0012aa\u0015;sS:<'BA\u000f\u0010\u0011\u0015\u00113\u00031\u0001\u001b\u0003\rYW-\u001f")
public interface ConfigProvider {
    public Option<String> get(String var1);
}

