/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Product
 *  scala.Product$class
 *  scala.collection.Iterator
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.ScalaRunTime$
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.OutputCommitCoordinationMessage;
import scala.Product;
import scala.collection.Iterator;
import scala.runtime.BoxesRunTime;
import scala.runtime.ScalaRunTime$;

public final class StopCoordinator$
implements OutputCommitCoordinationMessage,
Product {
    public static final StopCoordinator$ MODULE$;

    public static {
        new org.apache.spark.scheduler.StopCoordinator$();
    }

    public String productPrefix() {
        return "StopCoordinator";
    }

    public int productArity() {
        return 0;
    }

    public Object productElement(int x$1) {
        int n = x$1;
        throw new IndexOutOfBoundsException(((Object)BoxesRunTime.boxToInteger((int)x$1)).toString());
    }

    public Iterator<Object> productIterator() {
        return ScalaRunTime$.MODULE$.typedProductIterator((Product)this);
    }

    public boolean canEqual(Object x$1) {
        return x$1 instanceof StopCoordinator$;
    }

    public int hashCode() {
        return 371711406;
    }

    public String toString() {
        return "StopCoordinator";
    }

    private Object readResolve() {
        return MODULE$;
    }

    private StopCoordinator$() {
        MODULE$ = this;
        Product.class.$init$((Product)this);
    }
}

