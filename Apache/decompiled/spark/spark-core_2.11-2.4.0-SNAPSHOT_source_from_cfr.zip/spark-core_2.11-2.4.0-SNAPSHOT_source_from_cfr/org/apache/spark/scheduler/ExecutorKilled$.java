/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.ExecutorLossReason;

public final class ExecutorKilled$
extends ExecutorLossReason {
    public static final ExecutorKilled$ MODULE$;

    public static {
        new org.apache.spark.scheduler.ExecutorKilled$();
    }

    private Object readResolve() {
        return MODULE$;
    }

    private ExecutorKilled$() {
        super("Executor killed by driver.");
        MODULE$ = this;
    }
}

