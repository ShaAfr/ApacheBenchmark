/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.unsafe.array.ByteArrayMethods
 */
package org.apache.spark.unsafe.map;

import org.apache.spark.unsafe.array.ByteArrayMethods;

public interface HashMapGrowthStrategy {
    public static final HashMapGrowthStrategy DOUBLING = new Doubling();

    public int nextCapacity(int var1);

    public static class Doubling
    implements HashMapGrowthStrategy {
        private static final int ARRAY_MAX = ByteArrayMethods.MAX_ROUNDED_ARRAY_LENGTH;

        @Override
        public int nextCapacity(int currentCapacity) {
            assert (currentCapacity > 0);
            int doubleCapacity = currentCapacity * 2;
            return doubleCapacity > 0 && doubleCapacity <= ARRAY_MAX ? doubleCapacity : ARRAY_MAX;
        }
    }

}

