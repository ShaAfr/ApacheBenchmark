/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.ExecutorKilled$;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001\u0005:a!\u0001\u0002\t\u0002\u0011Q\u0011AD#yK\u000e,Ho\u001c:LS2dW\r\u001a\u0006\u0003\u0007\u0011\t\u0011b]2iK\u0012,H.\u001a:\u000b\u0005\u00151\u0011!B:qCJ\\'BA\u0004\t\u0003\u0019\t\u0007/Y2iK*\t\u0011\"A\u0002pe\u001e\u0004\"a\u0003\u0007\u000e\u0003\t1a!\u0004\u0002\t\u0002\u0011q!AD#yK\u000e,Ho\u001c:LS2dW\rZ\n\u0003\u0019=\u0001\"a\u0003\t\n\u0005E\u0011!AE#yK\u000e,Ho\u001c:M_N\u001c(+Z1t_:DQa\u0005\u0007\u0005\u0002U\ta\u0001P5oSRt4\u0001\u0001\u000b\u0002\u0015!9q\u0003DA\u0001\n\u0013A\u0012a\u0003:fC\u0012\u0014Vm]8mm\u0016$\u0012!\u0007\t\u00035}i\u0011a\u0007\u0006\u00039u\tA\u0001\\1oO*\ta$\u0001\u0003kCZ\f\u0017B\u0001\u0011\u001c\u0005\u0019y%M[3di\u0002")
public final class ExecutorKilled {
    public static String toString() {
        return ExecutorKilled$.MODULE$.toString();
    }

    public static String message() {
        return ExecutorKilled$.MODULE$.message();
    }
}

