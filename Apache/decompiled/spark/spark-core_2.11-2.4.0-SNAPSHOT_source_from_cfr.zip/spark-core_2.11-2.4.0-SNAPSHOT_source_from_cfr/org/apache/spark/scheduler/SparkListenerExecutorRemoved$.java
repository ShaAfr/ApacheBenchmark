/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerExecutorRemoved;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;
import scala.runtime.BoxesRunTime;

public final class SparkListenerExecutorRemoved$
extends AbstractFunction3<Object, String, String, SparkListenerExecutorRemoved>
implements Serializable {
    public static final SparkListenerExecutorRemoved$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerExecutorRemoved$();
    }

    public final String toString() {
        return "SparkListenerExecutorRemoved";
    }

    public SparkListenerExecutorRemoved apply(long time, String executorId, String reason) {
        return new SparkListenerExecutorRemoved(time, executorId, reason);
    }

    public Option<Tuple3<Object, String, String>> unapply(SparkListenerExecutorRemoved x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)BoxesRunTime.boxToLong((long)x$0.time()), (Object)x$0.executorId(), (Object)x$0.reason()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerExecutorRemoved$() {
        MODULE$ = this;
    }
}

