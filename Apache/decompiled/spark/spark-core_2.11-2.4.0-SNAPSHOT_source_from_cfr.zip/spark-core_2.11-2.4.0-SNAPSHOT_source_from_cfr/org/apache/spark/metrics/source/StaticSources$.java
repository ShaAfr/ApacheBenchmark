/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Predef$
 *  scala.collection.GenTraversable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.mutable.WrappedArray
 */
package org.apache.spark.metrics.source;

import org.apache.spark.metrics.source.CodegenMetrics$;
import org.apache.spark.metrics.source.HiveCatalogMetrics$;
import org.apache.spark.metrics.source.Source;
import scala.Predef$;
import scala.collection.GenTraversable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.mutable.WrappedArray;

public final class StaticSources$ {
    public static final StaticSources$ MODULE$;
    private final Seq<Source> allSources;

    public static {
        new org.apache.spark.metrics.source.StaticSources$();
    }

    public Seq<Source> allSources() {
        return this.allSources;
    }

    private StaticSources$() {
        MODULE$ = this;
        this.allSources = (Seq)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new Source[]{CodegenMetrics$.MODULE$, HiveCatalogMetrics$.MODULE$}));
    }
}

