/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.scheduler;

public final class package$ {
    public static final package$ MODULE$;

    public static {
        new org.apache.spark.scheduler.package$();
    }

    private package$() {
        MODULE$ = this;
    }
}

