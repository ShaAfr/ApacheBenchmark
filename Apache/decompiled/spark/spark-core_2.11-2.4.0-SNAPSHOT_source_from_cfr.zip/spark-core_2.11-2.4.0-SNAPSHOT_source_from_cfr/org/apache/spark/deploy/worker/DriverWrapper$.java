/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.hadoop.conf.Configuration
 *  org.apache.spark.deploy.worker.DriverWrapper$$anonfun
 *  org.apache.spark.deploy.worker.DriverWrapper$$anonfun$main
 *  org.slf4j.Logger
 *  scala.Function0
 *  scala.Function1
 *  scala.MatchError
 *  scala.Option
 *  scala.Predef
 *  scala.Predef$
 *  scala.Predef$$less$colon$less
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple4
 *  scala.collection.GenTraversable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.SeqLike
 *  scala.collection.TraversableLike
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.
 *  scala.collection.immutable.$colon
 *  scala.collection.immutable.$colon$colon
 *  scala.collection.immutable.List
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.WrappedArray
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.runtime.BoxedUnit
 *  scala.sys.SystemProperties
 *  scala.sys.package$
 */
package org.apache.spark.deploy.worker;

import java.io.File;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.spark.SecurityManager;
import org.apache.spark.SecurityManager$;
import org.apache.spark.SparkConf;
import org.apache.spark.deploy.DependencyUtils$;
import org.apache.spark.deploy.SparkHadoopUtil$;
import org.apache.spark.deploy.SparkSubmit$;
import org.apache.spark.deploy.worker.DriverWrapper$;
import org.apache.spark.deploy.worker.WorkerWatcher;
import org.apache.spark.deploy.worker.WorkerWatcher$;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.rpc.RpcEndpoint;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.rpc.RpcEnv;
import org.apache.spark.rpc.RpcEnv$;
import org.apache.spark.util.ChildFirstURLClassLoader;
import org.apache.spark.util.MutableURLClassLoader;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import scala.Function0;
import scala.Function1;
import scala.MatchError;
import scala.Option;
import scala.Predef;
import scala.Predef$;
import scala.Serializable;
import scala.Some;
import scala.Tuple4;
import scala.collection.GenTraversable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.SeqLike;
import scala.collection.TraversableLike;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.;
import scala.collection.immutable.List;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.WrappedArray;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.runtime.BoxedUnit;
import scala.sys.SystemProperties;
import scala.sys.package$;

public final class DriverWrapper$
implements Logging {
    public static final DriverWrapper$ MODULE$;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static {
        new org.apache.spark.deploy.worker.DriverWrapper$();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void main(String[] args) {
        List list = Predef$.MODULE$.refArrayOps((Object[])args).toList();
        if (list instanceof .colon.colon) {
            .colon.colon colon2 = (.colon.colon)list;
            String workerUrl = (String)colon2.head();
            List list2 = colon2.tl$1();
            if (list2 instanceof .colon.colon) {
                .colon.colon colon3 = (.colon.colon)list2;
                String userJar = (String)colon3.head();
                List list3 = colon3.tl$1();
                if (list3 instanceof .colon.colon) {
                    .colon.colon colon4 = (.colon.colon)list3;
                    String mainClass = (String)colon4.head();
                    List extraArgs = colon4.tl$1();
                    SparkConf conf = new SparkConf();
                    String host = Utils$.MODULE$.localHostName();
                    int port = new StringOps(Predef$.MODULE$.augmentString((String)package$.MODULE$.props().getOrElse((Object)"spark.driver.port", (Function0)new Serializable(){
                        public static final long serialVersionUID = 0L;

                        public final String apply() {
                            return "0";
                        }
                    }))).toInt();
                    RpcEnv rpcEnv = RpcEnv$.MODULE$.create("Driver", host, port, conf, new SecurityManager(conf, SecurityManager$.MODULE$.$lessinit$greater$default$2()), RpcEnv$.MODULE$.create$default$6());
                    this.logInfo((Function0<String>)new Serializable(rpcEnv){
                        public static final long serialVersionUID = 0L;
                        private final RpcEnv rpcEnv$1;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Driver address: ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.rpcEnv$1.address()}));
                        }
                        {
                            this.rpcEnv$1 = rpcEnv$1;
                        }
                    });
                    rpcEnv.setupEndpoint("workerWatcher", new WorkerWatcher(rpcEnv, workerUrl, WorkerWatcher$.MODULE$.$lessinit$greater$default$3()));
                    ClassLoader currentLoader = Thread.currentThread().getContextClassLoader();
                    URL userJarUrl = new File(userJar).toURI().toURL();
                    MutableURLClassLoader loader = new StringOps(Predef$.MODULE$.augmentString((String)package$.MODULE$.props().getOrElse((Object)"spark.driver.userClassPathFirst", (Function0)new Serializable(){
                        public static final long serialVersionUID = 0L;

                        public final String apply() {
                            return "false";
                        }
                    }))).toBoolean() ? new ChildFirstURLClassLoader(new URL[]{userJarUrl}, currentLoader) : new MutableURLClassLoader(new URL[]{userJarUrl}, currentLoader);
                    Thread.currentThread().setContextClassLoader(loader);
                    this.setupDependencies(loader, userJar);
                    Class<?> clazz = Utils$.MODULE$.classForName(mainClass);
                    Method mainMethod = clazz.getMethod("main", String[].class);
                    mainMethod.invoke(null, extraArgs.toArray(ClassTag$.MODULE$.apply(String.class)));
                    rpcEnv.shutdown();
                    BoxedUnit boxedUnit = BoxedUnit.UNIT;
                    return;
                }
            }
        }
        System.err.println("Usage: DriverWrapper <workerUrl> <userJar> <driverMainClass> [options]");
        System.exit(-1);
        BoxedUnit boxedUnit = BoxedUnit.UNIT;
    }

    private void setupDependencies(MutableURLClassLoader loader, String userJar) {
        SparkConf sparkConf = new SparkConf();
        SecurityManager secMgr = new SecurityManager(sparkConf, SecurityManager$.MODULE$.$lessinit$greater$default$2());
        Configuration hadoopConf = SparkHadoopUtil$.MODULE$.newConfiguration(sparkConf);
        Seq seq = (Seq)((TraversableLike)Seq$.MODULE$.apply((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"spark.jars.excludes", "spark.jars.packages", "spark.jars.repositories", "spark.jars.ivy"}))).map((Function1)new Serializable(){
            public static final long serialVersionUID = 0L;

            public final String apply(String x$1) {
                return (String)package$.MODULE$.props().get(x$1).orNull(Predef$.MODULE$.$conforms());
            }
        }, Seq$.MODULE$.canBuildFrom());
        Some some = Seq$.MODULE$.unapplySeq(seq);
        if (!some.isEmpty() && some.get() != null && ((SeqLike)some.get()).lengthCompare(4) == 0) {
            Tuple4 tuple4;
            String packagesExclusions = (String)((SeqLike)some.get()).apply(0);
            String packages = (String)((SeqLike)some.get()).apply(1);
            String repositories = (String)((SeqLike)some.get()).apply(2);
            String ivyRepoPath = (String)((SeqLike)some.get()).apply(3);
            Tuple4 tuple42 = tuple4 = new Tuple4((Object)packagesExclusions, (Object)packages, (Object)repositories, (Object)ivyRepoPath);
            String packagesExclusions2 = (String)tuple42._1();
            String packages2 = (String)tuple42._2();
            String repositories2 = (String)tuple42._3();
            String ivyRepoPath2 = (String)tuple42._4();
            String resolvedMavenCoordinates = DependencyUtils$.MODULE$.resolveMavenDependencies(packagesExclusions2, packages2, repositories2, ivyRepoPath2);
            String jarsProp = (String)package$.MODULE$.props().get("spark.jars").orNull(Predef$.MODULE$.$conforms());
            String jars = StringUtils.isBlank((CharSequence)resolvedMavenCoordinates) ? jarsProp : SparkSubmit$.MODULE$.mergeFileLists((Seq<String>)Predef$.MODULE$.wrapRefArray((Object[])new String[]{jarsProp, resolvedMavenCoordinates}));
            String localJars = DependencyUtils$.MODULE$.resolveAndDownloadJars(jars, userJar, sparkConf, hadoopConf, secMgr);
            DependencyUtils$.MODULE$.addJarsToClassPath(localJars, loader);
            return;
        }
        throw new MatchError((Object)seq);
    }

    private DriverWrapper$() {
        MODULE$ = this;
        Logging$class.$init$(this);
    }
}

