/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 *  scala.runtime.AbstractFunction3
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.SparkListenerExecutorAdded;
import org.apache.spark.scheduler.cluster.ExecutorInfo;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;
import scala.runtime.AbstractFunction3;
import scala.runtime.BoxesRunTime;

public final class SparkListenerExecutorAdded$
extends AbstractFunction3<Object, String, ExecutorInfo, SparkListenerExecutorAdded>
implements Serializable {
    public static final SparkListenerExecutorAdded$ MODULE$;

    public static {
        new org.apache.spark.scheduler.SparkListenerExecutorAdded$();
    }

    public final String toString() {
        return "SparkListenerExecutorAdded";
    }

    public SparkListenerExecutorAdded apply(long time, String executorId, ExecutorInfo executorInfo) {
        return new SparkListenerExecutorAdded(time, executorId, executorInfo);
    }

    public Option<Tuple3<Object, String, ExecutorInfo>> unapply(SparkListenerExecutorAdded x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3((Object)BoxesRunTime.boxToLong((long)x$0.time()), (Object)x$0.executorId(), (Object)x$0.executorInfo()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private SparkListenerExecutorAdded$() {
        MODULE$ = this;
    }
}

