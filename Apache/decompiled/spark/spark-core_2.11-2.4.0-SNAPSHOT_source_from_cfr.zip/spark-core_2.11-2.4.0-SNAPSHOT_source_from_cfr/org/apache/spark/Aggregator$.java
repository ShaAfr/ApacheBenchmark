/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.Function1
 *  scala.Function2
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple3
 */
package org.apache.spark;

import org.apache.spark.Aggregator;
import scala.Function1;
import scala.Function2;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple3;

public final class Aggregator$
implements Serializable {
    public static final Aggregator$ MODULE$;

    public static {
        new org.apache.spark.Aggregator$();
    }

    public final String toString() {
        return "Aggregator";
    }

    public <K, V, C> Aggregator<K, V, C> apply(Function1<V, C> createCombiner, Function2<C, V, C> mergeValue, Function2<C, C, C> mergeCombiners) {
        return new Aggregator(createCombiner, mergeValue, mergeCombiners);
    }

    public <K, V, C> Option<Tuple3<Function1<V, C>, Function2<C, V, C>, Function2<C, C, C>>> unapply(Aggregator<K, V, C> x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple3(x$0.createCombiner(), x$0.mergeValue(), x$0.mergeCombiners()));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private Aggregator$() {
        MODULE$ = this;
    }
}

