/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.hadoop.conf.Configuration
 *  org.apache.spark.deploy.master.Master$$anon
 *  org.apache.spark.deploy.master.Master$$anonfun
 *  org.apache.spark.deploy.master.Master$$anonfun$onDisconnected
 *  org.apache.spark.deploy.master.Master$$anonfun$onStart
 *  org.apache.spark.deploy.master.Master$$anonfun$onStop
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$allocateWorkerResourceToExecutors
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$beginRecovery
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$canCompleteRecovery
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$completeRecovery
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$formatExecutorIds
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$handleKillExecutors
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$handleRequestExecutors
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$launchDriver
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$launchExecutor
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$registerApplication
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$registerWorker
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$removeDriver
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$removeWorker
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$schedule
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$scheduleExecutorsOnWorkers
 *  org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$$timeOutDeadWorkers
 *  org.apache.spark.deploy.master.Master$$anonfun$receive
 *  org.apache.spark.deploy.master.Master$$anonfun$receiveAndReply
 *  org.apache.spark.deploy.master.Master$$anonfun$removeApplication
 *  org.apache.spark.deploy.master.Master$$anonfun$startExecutorsOnWorkers
 *  org.slf4j.Logger
 *  scala.Array$
 *  scala.Enumeration
 *  scala.Enumeration$Value
 *  scala.Function0
 *  scala.Function1
 *  scala.MatchError
 *  scala.None$
 *  scala.Option
 *  scala.PartialFunction
 *  scala.Predef$
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.Tuple3
 *  scala.collection.Iterable
 *  scala.collection.Seq
 *  scala.collection.Seq$
 *  scala.collection.TraversableOnce
 *  scala.collection.generic.CanBuildFrom
 *  scala.collection.immutable.IndexedSeq
 *  scala.collection.immutable.List
 *  scala.collection.immutable.Range
 *  scala.collection.immutable.Range$Inclusive
 *  scala.collection.immutable.StringOps
 *  scala.collection.mutable.ArrayBuffer
 *  scala.collection.mutable.ArrayOps
 *  scala.collection.mutable.Buffer
 *  scala.collection.mutable.HashMap
 *  scala.collection.mutable.HashSet
 *  scala.collection.mutable.ResizableArray
 *  scala.collection.mutable.StringBuilder
 *  scala.collection.mutable.WrappedArray
 *  scala.math.Numeric
 *  scala.math.Numeric$IntIsIntegral$
 *  scala.math.package$
 *  scala.reflect.ClassTag
 *  scala.reflect.ClassTag$
 *  scala.reflect.ScalaSignature
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 *  scala.runtime.IntRef
 *  scala.runtime.RichInt$
 *  scala.util.Random$
 */
package org.apache.spark.deploy.master;

import java.lang.reflect.Constructor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.apache.hadoop.conf.Configuration;
import org.apache.spark.SecurityManager;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkException;
import org.apache.spark.deploy.ApplicationDescription;
import org.apache.spark.deploy.DeployMessages;
import org.apache.spark.deploy.DriverDescription;
import org.apache.spark.deploy.ExecutorState$;
import org.apache.spark.deploy.SparkHadoopUtil;
import org.apache.spark.deploy.SparkHadoopUtil$;
import org.apache.spark.deploy.master.ApplicationInfo;
import org.apache.spark.deploy.master.ApplicationSource;
import org.apache.spark.deploy.master.ApplicationState$;
import org.apache.spark.deploy.master.BlackHolePersistenceEngine;
import org.apache.spark.deploy.master.DriverInfo;
import org.apache.spark.deploy.master.DriverState$;
import org.apache.spark.deploy.master.ExecutorDesc;
import org.apache.spark.deploy.master.FileSystemRecoveryModeFactory;
import org.apache.spark.deploy.master.LeaderElectable;
import org.apache.spark.deploy.master.LeaderElectionAgent;
import org.apache.spark.deploy.master.Master$;
import org.apache.spark.deploy.master.Master$$anonfun$org$apache$spark$deploy$master$Master$;
import org.apache.spark.deploy.master.MasterMessages$ElectedLeader$;
import org.apache.spark.deploy.master.MasterMessages$RevokedLeadership$;
import org.apache.spark.deploy.master.MasterSource;
import org.apache.spark.deploy.master.MonarchyLeaderAgent;
import org.apache.spark.deploy.master.PersistenceEngine;
import org.apache.spark.deploy.master.RecoveryState$;
import org.apache.spark.deploy.master.StandaloneRecoveryModeFactory;
import org.apache.spark.deploy.master.WorkerInfo;
import org.apache.spark.deploy.master.WorkerState$;
import org.apache.spark.deploy.master.ZooKeeperRecoveryModeFactory;
import org.apache.spark.deploy.master.ui.MasterWebUI;
import org.apache.spark.deploy.rest.StandaloneRestServer;
import org.apache.spark.internal.Logging;
import org.apache.spark.internal.Logging$class;
import org.apache.spark.metrics.MetricsSystem;
import org.apache.spark.metrics.MetricsSystem$;
import org.apache.spark.metrics.source.Source;
import org.apache.spark.rpc.RpcAddress;
import org.apache.spark.rpc.RpcCallContext;
import org.apache.spark.rpc.RpcEndpoint$class;
import org.apache.spark.rpc.RpcEndpointRef;
import org.apache.spark.rpc.RpcEnv;
import org.apache.spark.rpc.ThreadSafeRpcEndpoint;
import org.apache.spark.serializer.JavaSerializer;
import org.apache.spark.serializer.Serializer;
import org.apache.spark.util.ThreadUtils$;
import org.apache.spark.util.Utils$;
import org.slf4j.Logger;
import org.spark_project.jetty.servlet.ServletContextHandler;
import scala.Array$;
import scala.Enumeration;
import scala.Function0;
import scala.Function1;
import scala.MatchError;
import scala.None$;
import scala.Option;
import scala.PartialFunction;
import scala.Predef$;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.Tuple3;
import scala.collection.Iterable;
import scala.collection.Seq;
import scala.collection.Seq$;
import scala.collection.TraversableOnce;
import scala.collection.generic.CanBuildFrom;
import scala.collection.immutable.IndexedSeq;
import scala.collection.immutable.List;
import scala.collection.immutable.Range;
import scala.collection.immutable.StringOps;
import scala.collection.mutable.ArrayBuffer;
import scala.collection.mutable.ArrayOps;
import scala.collection.mutable.Buffer;
import scala.collection.mutable.HashMap;
import scala.collection.mutable.HashSet;
import scala.collection.mutable.ResizableArray;
import scala.collection.mutable.StringBuilder;
import scala.collection.mutable.WrappedArray;
import scala.math.Numeric;
import scala.math.package$;
import scala.reflect.ClassTag;
import scala.reflect.ClassTag$;
import scala.reflect.ScalaSignature;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;
import scala.runtime.IntRef;
import scala.runtime.RichInt$;
import scala.util.Random$;

@ScalaSignature(bytes="\u0006\u0001\u0015=e!B\u0001\u0003\u0001\u0011a!AB'bgR,'O\u0003\u0002\u0004\t\u00051Q.Y:uKJT!!\u0002\u0004\u0002\r\u0011,\u0007\u000f\\8z\u0015\t9\u0001\"A\u0003ta\u0006\u00148N\u0003\u0002\n\u0015\u00051\u0011\r]1dQ\u0016T\u0011aC\u0001\u0004_J<7#\u0002\u0001\u000e'ey\u0002C\u0001\b\u0012\u001b\u0005y!\"\u0001\t\u0002\u000bM\u001c\u0017\r\\1\n\u0005Iy!AB!osJ+g\r\u0005\u0002\u0015/5\tQC\u0003\u0002\u0017\r\u0005\u0019!\u000f]2\n\u0005a)\"!\u0006+ie\u0016\fGmU1gKJ\u00038-\u00128ea>Lg\u000e\u001e\t\u00035ui\u0011a\u0007\u0006\u00039\u0019\t\u0001\"\u001b8uKJt\u0017\r\\\u0005\u0003=m\u0011q\u0001T8hO&tw\r\u0005\u0002!C5\t!!\u0003\u0002#\u0005\tyA*Z1eKJ,E.Z2uC\ndW\r\u0003\u0005%\u0001\t\u0015\r\u0011\"\u0011'\u0003\u0019\u0011\boY#om\u000e\u0001Q#A\u0014\u0011\u0005QA\u0013BA\u0015\u0016\u0005\u0019\u0011\u0006oY#om\"A1\u0006\u0001B\u0001B\u0003%q%A\u0004sa\u000e,eN\u001e\u0011\t\u00115\u0002!\u0011!Q\u0001\n9\nq!\u00193ee\u0016\u001c8\u000f\u0005\u0002\u0015_%\u0011\u0001'\u0006\u0002\u000b%B\u001c\u0017\t\u001a3sKN\u001c\b\u0002\u0003\u001a\u0001\u0005\u0003\u0005\u000b\u0011B\u001a\u0002\u0013],'-V5Q_J$\bC\u0001\b5\u0013\t)tBA\u0002J]RD\u0001b\u000e\u0001\u0003\u0006\u0004%\t\u0001O\u0001\fg\u0016\u001cWO]5us6;'/F\u0001:!\tQ4(D\u0001\u0007\u0013\tadAA\bTK\u000e,(/\u001b;z\u001b\u0006t\u0017mZ3s\u0011!q\u0004A!A!\u0002\u0013I\u0014\u0001D:fGV\u0014\u0018\u000e^=NOJ\u0004\u0003\u0002\u0003!\u0001\u0005\u000b\u0007I\u0011A!\u0002\t\r|gNZ\u000b\u0002\u0005B\u0011!hQ\u0005\u0003\t\u001a\u0011\u0011b\u00159be.\u001cuN\u001c4\t\u0011\u0019\u0003!\u0011!Q\u0001\n\t\u000bQaY8oM\u0002BQ\u0001\u0013\u0001\u0005\u0002%\u000ba\u0001P5oSRtDC\u0002&L\u00196su\n\u0005\u0002!\u0001!)Ae\u0012a\u0001O!)Qf\u0012a\u0001]!)!g\u0012a\u0001g!)qg\u0012a\u0001s!)\u0001i\u0012a\u0001\u0005\"9\u0011\u000b\u0001b\u0001\n\u0013\u0011\u0016\u0001\u00064pe^\f'\u000fZ'fgN\fw-\u001a+ie\u0016\fG-F\u0001T!\t!6,D\u0001V\u0015\t1v+\u0001\u0006d_:\u001cWO\u001d:f]RT!\u0001W-\u0002\tU$\u0018\u000e\u001c\u0006\u00025\u0006!!.\u0019<b\u0013\taVK\u0001\rTG\",G-\u001e7fI\u0016CXmY;u_J\u001cVM\u001d<jG\u0016DaA\u0018\u0001!\u0002\u0013\u0019\u0016!\u00064pe^\f'\u000fZ'fgN\fw-\u001a+ie\u0016\fG\r\t\u0005\bA\u0002\u0011\r\u0011\"\u0003b\u0003)A\u0017\rZ8pa\u000e{gNZ\u000b\u0002EB\u00111mZ\u0007\u0002I*\u0011\u0001)\u001a\u0006\u0003M\"\ta\u0001[1e_>\u0004\u0018B\u00015e\u00055\u0019uN\u001c4jOV\u0014\u0018\r^5p]\"1!\u000e\u0001Q\u0001\n\t\f1\u0002[1e_>\u00048i\u001c8gA!)A\u000e\u0001C\u0005[\u0006\u00012M]3bi\u0016$\u0015\r^3G_Jl\u0017\r^\u000b\u0002]B\u0011qN]\u0007\u0002a*\u0011\u0011/W\u0001\u0005i\u0016DH/\u0003\u0002ta\n\u00012+[7qY\u0016$\u0015\r^3G_Jl\u0017\r\u001e\u0005\bk\u0002\u0011\r\u0011\"\u0003w\u0003E9vJU&F%~#\u0016*T#P+R{VjU\u000b\u0002oB\u0011a\u0002_\u0005\u0003s>\u0011A\u0001T8oO\"11\u0010\u0001Q\u0001\n]\f!cV(S\u0017\u0016\u0013v\fV%N\u000b>+FkX'TA!9Q\u0010\u0001b\u0001\n\u0013q\u0018!\u0006*F)\u0006Ke*\u0012#`\u0003B\u0003F*S\"B)&{ejU\u000b\u0002g!9\u0011\u0011\u0001\u0001!\u0002\u0013\u0019\u0014A\u0006*F)\u0006Ke*\u0012#`\u0003B\u0003F*S\"B)&{ej\u0015\u0011\t\u0011\u0005\u0015\u0001A1A\u0005\ny\f\u0001CU#U\u0003&sU\tR0E%&3VIU*\t\u000f\u0005%\u0001\u0001)A\u0005g\u0005\t\"+\u0012+B\u0013:+Ei\u0018#S\u0013Z+%k\u0015\u0011\t\u0011\u00055\u0001A1A\u0005\ny\f\u0011CU#B!\u0016\u0013v,\u0013+F%\u0006#\u0016j\u0014(T\u0011\u001d\t\t\u0002\u0001Q\u0001\nM\n!CU#B!\u0016\u0013v,\u0013+F%\u0006#\u0016j\u0014(TA!I\u0011Q\u0003\u0001C\u0002\u0013%\u0011qC\u0001\u000e%\u0016\u001buJV#S3~ku\nR#\u0016\u0005\u0005e\u0001\u0003BA\u000e\u0003Cq1ADA\u000f\u0013\r\tybD\u0001\u0007!J,G-\u001a4\n\t\u0005\r\u0012Q\u0005\u0002\u0007'R\u0014\u0018N\\4\u000b\u0007\u0005}q\u0002\u0003\u0005\u0002*\u0001\u0001\u000b\u0011BA\r\u00039\u0011ViQ(W\u000bJKv,T(E\u000b\u0002B\u0001\"!\f\u0001\u0005\u0004%IA`\u0001\u0015\u001b\u0006Cv,\u0012-F\u0007V#vJU0S\u000bR\u0013\u0016*R*\t\u000f\u0005E\u0002\u0001)A\u0005g\u0005)R*\u0011-`\u000bb+5)\u0016+P%~\u0013V\t\u0016*J\u000bN\u0003\u0003\"CA\u001b\u0001\t\u0007I\u0011AA\u001c\u0003\u001d9xN]6feN,\"!!\u000f\u0011\r\u0005m\u0012QIA%\u001b\t\tiD\u0003\u0003\u0002@\u0005\u0005\u0013aB7vi\u0006\u0014G.\u001a\u0006\u0004\u0003\u0007z\u0011AC2pY2,7\r^5p]&!\u0011qIA\u001f\u0005\u001dA\u0015m\u001d5TKR\u00042\u0001IA&\u0013\r\tiE\u0001\u0002\u000b/>\u00148.\u001a:J]\u001a|\u0007\u0002CA)\u0001\u0001\u0006I!!\u000f\u0002\u0011]|'o[3sg\u0002B\u0011\"!\u0016\u0001\u0005\u0004%\t!a\u0016\u0002\u000f%$Gk\\!qaV\u0011\u0011\u0011\f\t\t\u0003w\tY&!\u0007\u0002`%!\u0011QLA\u001f\u0005\u001dA\u0015m\u001d5NCB\u00042\u0001IA1\u0013\r\t\u0019G\u0001\u0002\u0010\u0003B\u0004H.[2bi&|g.\u00138g_\"A\u0011q\r\u0001!\u0002\u0013\tI&\u0001\u0005jIR{\u0017\t\u001d9!\u0011%\tY\u0007\u0001b\u0001\n\u0013\ti'A\u0006xC&$\u0018N\\4BaB\u001cXCAA8!\u0019\tY$!\u001d\u0002`%!\u00111OA\u001f\u0005-\t%O]1z\u0005V4g-\u001a:\t\u0011\u0005]\u0004\u0001)A\u0005\u0003_\nAb^1ji&tw-\u00119qg\u0002B\u0011\"a\u001f\u0001\u0005\u0004%\t!! \u0002\t\u0005\u0004\bo]\u000b\u0003\u0003\u0002b!a\u000f\u0002F\u0005}\u0003\u0002CAB\u0001\u0001\u0006I!a \u0002\u000b\u0005\u0004\bo\u001d\u0011\t\u0013\u0005\u001d\u0005A1A\u0005\n\u0005%\u0015AC5e)><vN]6feV\u0011\u00111\u0012\t\t\u0003w\tY&!\u0007\u0002J!A\u0011q\u0012\u0001!\u0002\u0013\tY)A\u0006jIR{wk\u001c:lKJ\u0004\u0003\"CAJ\u0001\t\u0007I\u0011BAK\u0003=\tG\r\u001a:fgN$vnV8sW\u0016\u0014XCAAL!\u001d\tY$a\u0017/\u0003\u0013B\u0001\"a'\u0001A\u0003%\u0011qS\u0001\u0011C\u0012$'/Z:t)><vN]6fe\u0002B\u0011\"a(\u0001\u0005\u0004%I!!)\u0002\u001b\u0015tG\r]8j]R$v.\u00119q+\t\t\u0019\u000b\u0005\u0005\u0002<\u0005m\u0013QUA0!\r!\u0012qU\u0005\u0004\u0003S+\"A\u0004*qG\u0016sG\r]8j]R\u0014VM\u001a\u0005\t\u0003[\u0003\u0001\u0015!\u0003\u0002$\u0006qQM\u001c3q_&tG\u000fV8BaB\u0004\u0003\"CAY\u0001\t\u0007I\u0011BAZ\u00031\tG\r\u001a:fgN$v.\u00119q+\t\t)\fE\u0004\u0002<\u0005mc&a\u0018\t\u0011\u0005e\u0006\u0001)A\u0005\u0003k\u000bQ\"\u00193ee\u0016\u001c8\u000fV8BaB\u0004\u0003\"CA_\u0001\t\u0007I\u0011BA7\u00035\u0019w.\u001c9mKR,G-\u00119qg\"A\u0011\u0011\u0019\u0001!\u0002\u0013\ty'\u0001\bd_6\u0004H.\u001a;fI\u0006\u0003\bo\u001d\u0011\t\u0011\u0005\u0015\u0007\u00011A\u0005\ny\fQB\\3yi\u0006\u0003\bOT;nE\u0016\u0014\b\"CAe\u0001\u0001\u0007I\u0011BAf\u0003EqW\r\u001f;BaBtU/\u001c2fe~#S-\u001d\u000b\u0005\u0003\u001b\f\u0019\u000eE\u0002\u000f\u0003\u001fL1!!5\u0010\u0005\u0011)f.\u001b;\t\u0013\u0005U\u0017qYA\u0001\u0002\u0004\u0019\u0014a\u0001=%c!9\u0011\u0011\u001c\u0001!B\u0013\u0019\u0014A\u00048fqR\f\u0005\u000f\u001d(v[\n,'\u000f\t\u0005\n\u0003;\u0004!\u0019!C\u0005\u0003?\fq\u0001\u001a:jm\u0016\u00148/\u0006\u0002\u0002bB1\u00111HA#\u0003G\u00042\u0001IAs\u0013\r\t9O\u0001\u0002\u000b\tJLg/\u001a:J]\u001a|\u0007\u0002CAv\u0001\u0001\u0006I!!9\u0002\u0011\u0011\u0014\u0018N^3sg\u0002B\u0011\"a<\u0001\u0005\u0004%I!!=\u0002!\r|W\u000e\u001d7fi\u0016$GI]5wKJ\u001cXCAAz!\u0019\tY$!\u001d\u0002d\"A\u0011q\u001f\u0001!\u0002\u0013\t\u00190A\td_6\u0004H.\u001a;fI\u0012\u0013\u0018N^3sg\u0002B\u0011\"a?\u0001\u0005\u0004%I!!=\u0002\u001d]\f\u0017\u000e^5oO\u0012\u0013\u0018N^3sg\"A\u0011q \u0001!\u0002\u0013\t\u00190A\bxC&$\u0018N\\4Ee&4XM]:!\u0011!\u0011\u0019\u0001\u0001a\u0001\n\u0013q\u0018\u0001\u00058fqR$%/\u001b<fe:+XNY3s\u0011%\u00119\u0001\u0001a\u0001\n\u0013\u0011I!\u0001\u000boKb$HI]5wKJtU/\u001c2fe~#S-\u001d\u000b\u0005\u0003\u001b\u0014Y\u0001C\u0005\u0002V\n\u0015\u0011\u0011!a\u0001g!9!q\u0002\u0001!B\u0013\u0019\u0014!\u00058fqR$%/\u001b<fe:+XNY3sA!I!1\u0003\u0001C\u0002\u0013%!QC\u0001\u0014[\u0006\u001cH/\u001a:NKR\u0014\u0018nY:TsN$X-\\\u000b\u0003\u0005/\u0001BA!\u0007\u0003 5\u0011!1\u0004\u0006\u0004\u0005;1\u0011aB7fiJL7m]\u0005\u0005\u0005C\u0011YBA\u0007NKR\u0014\u0018nY:TsN$X-\u001c\u0005\t\u0005K\u0001\u0001\u0015!\u0003\u0003\u0018\u0005!R.Y:uKJlU\r\u001e:jGN\u001c\u0016p\u001d;f[\u0002B\u0011B!\u000b\u0001\u0005\u0004%IA!\u0006\u00021\u0005\u0004\b\u000f\\5dCRLwN\\'fiJL7m]*zgR,W\u000e\u0003\u0005\u0003.\u0001\u0001\u000b\u0011\u0002B\f\u0003e\t\u0007\u000f\u001d7jG\u0006$\u0018n\u001c8NKR\u0014\u0018nY:TsN$X-\u001c\u0011\t\u0013\tE\u0002A1A\u0005\n\tM\u0012\u0001D7bgR,'oU8ve\u000e,WC\u0001B\u001b!\r\u0001#qG\u0005\u0004\u0005s\u0011!\u0001D'bgR,'oU8ve\u000e,\u0007\u0002\u0003B\u001f\u0001\u0001\u0006IA!\u000e\u0002\u001b5\f7\u000f^3s'>,(oY3!\u0011%\u0011\t\u0005\u0001a\u0001\n\u0013\u0011\u0019%A\u0003xK\n,\u0016.\u0006\u0002\u0003FA!!q\tB'\u001b\t\u0011IEC\u0002\u0003L\t\t!!^5\n\t\t=#\u0011\n\u0002\f\u001b\u0006\u001cH/\u001a:XK\n,\u0016\nC\u0005\u0003T\u0001\u0001\r\u0011\"\u0003\u0003V\u0005Iq/\u001a2VS~#S-\u001d\u000b\u0005\u0003\u001b\u00149\u0006\u0003\u0006\u0002V\nE\u0013\u0011!a\u0001\u0005\u000bB\u0001Ba\u0017\u0001A\u0003&!QI\u0001\u0007o\u0016\u0014W+\u001b\u0011\t\u0013\t}\u0003A1A\u0005\n\u0005]\u0011aE7bgR,'\u000fU;cY&\u001c\u0017\t\u001a3sKN\u001c\b\u0002\u0003B2\u0001\u0001\u0006I!!\u0007\u0002)5\f7\u000f^3s!V\u0014G.[2BI\u0012\u0014Xm]:!\u0011%\u00119\u0007\u0001b\u0001\n\u0013\t9\"A\u0005nCN$XM]+sY\"A!1\u000e\u0001!\u0002\u0013\tI\"\u0001\u0006nCN$XM]+sY\u0002B1Ba\u001c\u0001\u0001\u0004\u0005\r\u0011\"\u0003\u0002\u0018\u0005qQ.Y:uKJ<VMY+j+Jd\u0007b\u0003B:\u0001\u0001\u0007\t\u0019!C\u0005\u0005k\n!#\\1ti\u0016\u0014x+\u001a2VSV\u0013Hn\u0018\u0013fcR!\u0011Q\u001aB<\u0011)\t)N!\u001d\u0002\u0002\u0003\u0007\u0011\u0011\u0004\u0005\t\u0005w\u0002\u0001\u0015)\u0003\u0002\u001a\u0005yQ.Y:uKJ<VMY+j+Jd\u0007\u0005C\u0005\u0003\u0000\u0001\u0001\r\u0011\"\u0003\u0003\u0002\u0006)1\u000f^1uKV\u0011!1\u0011\t\u0005\u0005\u000b\u0013YID\u0002!\u0005\u000fK1A!#\u0003\u00035\u0011VmY8wKJL8\u000b^1uK&!!Q\u0012BH\u0005\u00151\u0016\r\\;f\u0013\r\u0011\tj\u0004\u0002\f\u000b:,X.\u001a:bi&|g\u000eC\u0005\u0003\u0016\u0002\u0001\r\u0011\"\u0003\u0003\u0018\u0006I1\u000f^1uK~#S-\u001d\u000b\u0005\u0003\u001b\u0014I\n\u0003\u0006\u0002V\nM\u0015\u0011!a\u0001\u0005\u0007C\u0001B!(\u0001A\u0003&!1Q\u0001\u0007gR\fG/\u001a\u0011\t\u0017\t\u0005\u0006\u00011AA\u0002\u0013%!1U\u0001\u0012a\u0016\u00148/[:uK:\u001cW-\u00128hS:,WC\u0001BS!\r\u0001#qU\u0005\u0004\u0005S\u0013!!\u0005)feNL7\u000f^3oG\u0016,enZ5oK\"Y!Q\u0016\u0001A\u0002\u0003\u0007I\u0011\u0002BX\u0003U\u0001XM]:jgR,gnY3F]\u001eLg.Z0%KF$B!!4\u00032\"Q\u0011Q\u001bBV\u0003\u0003\u0005\rA!*\t\u0011\tU\u0006\u0001)Q\u0005\u0005K\u000b!\u0003]3sg&\u001cH/\u001a8dK\u0016sw-\u001b8fA!Y!\u0011\u0018\u0001A\u0002\u0003\u0007I\u0011\u0002B^\u0003MaW-\u00193fe\u0016cWm\u0019;j_:\fu-\u001a8u+\t\u0011i\fE\u0002!\u0005K1A!1\u0003\u0005MaU-\u00193fe\u0016cWm\u0019;j_:\fu-\u001a8u\u0011-\u0011)\r\u0001a\u0001\u0002\u0004%IAa2\u0002/1,\u0017\rZ3s\u000b2,7\r^5p]\u0006;WM\u001c;`I\u0015\fH\u0003BAg\u0005\u0013D!\"!6\u0003D\u0006\u0005\t\u0019\u0001B_\u0011!\u0011i\r\u0001Q!\n\tu\u0016\u0001\u00067fC\u0012,'/\u00127fGRLwN\\!hK:$\b\u0005C\u0006\u0003R\u0002\u0001\r\u00111A\u0005\n\tM\u0017A\u0006:fG>4XM]=D_6\u0004H.\u001a;j_:$\u0016m]6\u0016\u0005\tU\u0007\u0007\u0002Bl\u0005C\u0004R\u0001\u0016Bm\u0005;L1Aa7V\u0005=\u00196\r[3ek2,GMR;ukJ,\u0007\u0003\u0002Bp\u0005Cd\u0001\u0001\u0002\u0007\u0003d\n\u0015\u0018\u0011!A\u0001\u0006\u0003\u0011\tPA\u0002`IEB\u0001Ba:\u0001A\u0003&!\u0011^\u0001\u0018e\u0016\u001cwN^3ss\u000e{W\u000e\u001d7fi&|g\u000eV1tW\u0002\u0002DAa;\u0003pB)AK!7\u0003nB!!q\u001cBx\t1\u0011\u0019O!:\u0002\u0002\u0003\u0005)\u0011\u0001By#\u0011\u0011\u0019P!?\u0011\u00079\u0011)0C\u0002\u0003x>\u0011qAT8uQ&tw\rE\u0002\u000f\u0005wL1A!@\u0010\u0005\r\te.\u001f\u0005\f\u0007\u0003\u0001\u0001\u0019!a\u0001\n\u0013\u0019\u0019!\u0001\u000esK\u000e|g/\u001a:z\u0007>l\u0007\u000f\\3uS>tG+Y:l?\u0012*\u0017\u000f\u0006\u0003\u0002N\u000e\u0015\u0001BCAk\u0005\f\t\u00111\u0001\u0004\bA\"1\u0011BB\u0007!\u0015!&\u0011\\B\u0006!\u0011\u0011yn!\u0004\u0005\u0019\t\r(Q]A\u0001\u0002\u0003\u0015\tA!=\t\u0017\rE\u0001\u00011AA\u0002\u0013%11C\u0001\u001aG\",7m\u001b$pe^{'o[3s)&lWmT;u)\u0006\u001c8.\u0006\u0002\u0004\u0016A\"1qCB\u000e!\u0015!&\u0011\\B\r!\u0011\u0011yna\u0007\u0005\u0019\ru1qDA\u0001\u0002\u0003\u0015\tA!=\u0003\u0007}##\u0007\u0003\u0005\u0004\"\u0001\u0001\u000b\u0015BB\u0012\u0003i\u0019\u0007.Z2l\r>\u0014xk\u001c:lKJ$\u0016.\\3PkR$\u0016m]6!a\u0011\u0019)c!\u000b\u0011\u000bQ\u0013Ina\n\u0011\t\t}7\u0011\u0006\u0003\r\u0007;\u0019y\"!A\u0001\u0002\u000b\u0005!\u0011\u001f\u0005\f\u0007[\u0001\u0001\u0019!a\u0001\n\u0013\u0019y#A\u000fdQ\u0016\u001c7NR8s/>\u00148.\u001a:US6,w*\u001e;UCN\\w\fJ3r)\u0011\tim!\r\t\u0015\u0005U71FA\u0001\u0002\u0004\u0019\u0019\u0004\r\u0003\u00046\re\u0002#\u0002+\u0003Z\u000e]\u0002\u0003\u0002Bp\u0007s!Ab!\b\u0004 \u0005\u0005\t\u0011!B\u0001\u0005cD\u0011b!\u0010\u0001\u0005\u0004%Iaa\u0010\u0002\u001bM\u0004(/Z1e\u001fV$\u0018\t\u001d9t+\t\u0019\t\u0005E\u0002\u000f\u0007\u0007J1a!\u0012\u0010\u0005\u001d\u0011un\u001c7fC:D\u0001b!\u0013\u0001A\u0003%1\u0011I\u0001\u000fgB\u0014X-\u00193PkR\f\u0005\u000f]:!\u0011!\u0019i\u0005\u0001b\u0001\n\u0013q\u0018\u0001\u00043fM\u0006,H\u000e^\"pe\u0016\u001c\bbBB)\u0001\u0001\u0006IaM\u0001\u000eI\u00164\u0017-\u001e7u\u0007>\u0014Xm\u001d\u0011\t\u0013\rU\u0003A1A\u0005\u0002\r}\u0012\u0001\u0004:fm\u0016\u00148/\u001a)s_bL\b\u0002CB-\u0001\u0001\u0006Ia!\u0011\u0002\u001bI,g/\u001a:tKB\u0013x\u000e_=!\u0011%\u0019i\u0006\u0001b\u0001\n\u0013\u0019y$A\tsKN$8+\u001a:wKJ,e.\u00192mK\u0012D\u0001b!\u0019\u0001A\u0003%1\u0011I\u0001\u0013e\u0016\u001cHoU3sm\u0016\u0014XI\\1cY\u0016$\u0007\u0005C\u0005\u0004f\u0001\u0001\r\u0011\"\u0003\u0004h\u0005Q!/Z:u'\u0016\u0014h/\u001a:\u0016\u0005\r%\u0004#\u0002\b\u0004l\r=\u0014bAB7\u001f\t1q\n\u001d;j_:\u0004Ba!\u001d\u0004x5\u001111\u000f\u0006\u0004\u0007k\"\u0011\u0001\u0002:fgRLAa!\u001f\u0004t\t!2\u000b^1oI\u0006dwN\\3SKN$8+\u001a:wKJD\u0011b! \u0001\u0001\u0004%Iaa \u0002\u001dI,7\u000f^*feZ,'o\u0018\u0013fcR!\u0011QZBA\u0011)\t)na\u001f\u0002\u0002\u0003\u00071\u0011\u000e\u0005\t\u0007\u000b\u0003\u0001\u0015)\u0003\u0004j\u0005Y!/Z:u'\u0016\u0014h/\u001a:!\u0011%\u0019I\t\u0001a\u0001\n\u0013\u0019Y)A\nsKN$8+\u001a:wKJ\u0014u.\u001e8e!>\u0014H/\u0006\u0002\u0004\u000eB!aba\u001b4\u0011%\u0019\t\n\u0001a\u0001\n\u0013\u0019\u0019*A\fsKN$8+\u001a:wKJ\u0014u.\u001e8e!>\u0014Ho\u0018\u0013fcR!\u0011QZBK\u0011)\t)na$\u0002\u0002\u0003\u00071Q\u0012\u0005\t\u00073\u0003\u0001\u0015)\u0003\u0004\u000e\u0006!\"/Z:u'\u0016\u0014h/\u001a:C_VtG\rU8si\u0002Bqa!(\u0001\t\u0003\u001ay*A\u0004p]N#\u0018M\u001d;\u0015\u0005\u00055\u0007bBBR\u0001\u0011\u00053qT\u0001\u0007_:\u001cFo\u001c9\t\u000f\r\u001d\u0006\u0001\"\u0011\u0004 \u0006iQ\r\\3di\u0016$G*Z1eKJDqaa+\u0001\t\u0003\u001ay*A\tsKZ|7.\u001a3MK\u0006$WM]:iSBDqaa,\u0001\t\u0003\u001a\t,A\u0004sK\u000e,\u0017N^3\u0016\u0005\rM\u0006c\u0002\b\u00046\ne\u0018QZ\u0005\u0004\u0007o{!a\u0004)beRL\u0017\r\u001c$v]\u000e$\u0018n\u001c8\t\u000f\rm\u0006\u0001\"\u0011\u0004>\u0006y!/Z2fSZ,\u0017I\u001c3SKBd\u0017\u0010\u0006\u0003\u00044\u000e}\u0006\u0002CBa\u0007s\u0003\raa1\u0002\u000f\r|g\u000e^3yiB\u0019Ac!2\n\u0007\r\u001dWC\u0001\bSa\u000e\u001c\u0015\r\u001c7D_:$X\r\u001f;\t\u000f\r-\u0007\u0001\"\u0011\u0004N\u0006qqN\u001c#jg\u000e|gN\\3di\u0016$G\u0003BAg\u0007\u001fDa!LBe\u0001\u0004q\u0003bBBj\u0001\u0011%1qH\u0001\u0014G\u0006t7i\\7qY\u0016$XMU3d_Z,'/\u001f\u0005\b\u0007/\u0004A\u0011BBm\u00035\u0011WmZ5o%\u0016\u001cwN^3ssRA\u0011QZBn\u0007o\u001ci\u0010\u0003\u0005\u0004^\u000eU\u0007\u0019ABp\u0003)\u0019Ho\u001c:fI\u0006\u0003\bo\u001d\t\u0007\u0007C\u001c\t0a\u0018\u000f\t\r\r8Q\u001e\b\u0005\u0007K\u001cY/\u0004\u0002\u0004h*\u00191\u0011^\u0013\u0002\rq\u0012xn\u001c;?\u0013\u0005\u0001\u0012bABx\u001f\u00059\u0001/Y2lC\u001e,\u0017\u0002BBz\u0007k\u00141aU3r\u0015\r\u0019yo\u0004\u0005\t\u0007s\u001c)\u000e1\u0001\u0004|\u0006i1\u000f^8sK\u0012$%/\u001b<feN\u0004ba!9\u0004r\u0006\r\b\u0002CB\u0000\u0007+\u0004\r\u0001\"\u0001\u0002\u001bM$xN]3e/>\u00148.\u001a:t!\u0019\u0019\to!=\u0002J!9AQ\u0001\u0001\u0005\n\r}\u0015\u0001E2p[BdW\r^3SK\u000e|g/\u001a:z\u0011\u001d!I\u0001\u0001C\u0005\t\u0017\t!d]2iK\u0012,H.Z#yK\u000e,Ho\u001c:t\u001f:<vN]6feN$\u0002\u0002\"\u0004\u0005\u0014\u0011]AQ\u0004\t\u0005\u001d\u0011=1'C\u0002\u0005\u0012=\u0011Q!\u0011:sCfD\u0001\u0002\"\u0006\u0005\b\u0001\u0007\u0011qL\u0001\u0004CB\u0004\b\u0002\u0003C\r\t\u000f\u0001\r\u0001b\u0007\u0002\u001bU\u001c\u0018M\u00197f/>\u00148.\u001a:t!\u0015qAqBA%\u0011!\u0019i\u0004b\u0002A\u0002\r\u0005\u0003b\u0002C\u0011\u0001\u0011%1qT\u0001\u0018gR\f'\u000f^#yK\u000e,Ho\u001c:t\u001f:<vN]6feNDq\u0001\"\n\u0001\t\u0013!9#A\u0011bY2|7-\u0019;f/>\u00148.\u001a:SKN|WO]2f)>,\u00050Z2vi>\u00148\u000f\u0006\u0006\u0002N\u0012%B1\u0006C\u0018\tgA\u0001\u0002\"\u0006\u0005$\u0001\u0007\u0011q\f\u0005\b\t[!\u0019\u00031\u00014\u00035\t7o]5h]\u0016$7i\u001c:fg\"AA\u0011\u0007C\u0012\u0001\u0004\u0019i)\u0001\td_J,7\u000fU3s\u000bb,7-\u001e;pe\"AAQ\u0007C\u0012\u0001\u0004\tI%\u0001\u0004x_J\\WM\u001d\u0005\b\ts\u0001A\u0011BBP\u0003!\u00198\r[3ek2,\u0007b\u0002C\u001f\u0001\u0011%AqH\u0001\u000fY\u0006,hn\u00195Fq\u0016\u001cW\u000f^8s)\u0019\ti\r\"\u0011\u0005D!AAQ\u0007C\u001e\u0001\u0004\tI\u0005\u0003\u0005\u0005F\u0011m\u0002\u0019\u0001C$\u0003\u0011)\u00070Z2\u0011\u0007\u0001\"I%C\u0002\u0005L\t\u0011A\"\u0012=fGV$xN\u001d#fg\u000eDq\u0001b\u0014\u0001\t\u0013!\t&\u0001\bsK\u001eL7\u000f^3s/>\u00148.\u001a:\u0015\t\r\u0005C1\u000b\u0005\t\tk!i\u00051\u0001\u0002J!9Aq\u000b\u0001\u0005\n\u0011e\u0013\u0001\u0004:f[>4XmV8sW\u0016\u0014HCBAg\t7\"i\u0006\u0003\u0005\u00056\u0011U\u0003\u0019AA%\u0011!!y\u0006\"\u0016A\u0002\u0005e\u0011aA7tO\"9A1\r\u0001\u0005\n\u0011\u0015\u0014A\u0004:fY\u0006,hn\u00195Ee&4XM\u001d\u000b\u0005\u0003\u001b$9\u0007\u0003\u0005\u0005j\u0011\u0005\u0004\u0019AAr\u0003\u0019!'/\u001b<fe\"9AQ\u000e\u0001\u0005\n\u0011=\u0014!E2sK\u0006$X-\u00119qY&\u001c\u0017\r^5p]R1\u0011q\fC9\t{B\u0001\u0002b\u001d\u0005l\u0001\u0007AQO\u0001\u0005I\u0016\u001c8\r\u0005\u0003\u0005x\u0011eT\"\u0001\u0003\n\u0007\u0011mDA\u0001\fBaBd\u0017nY1uS>tG)Z:de&\u0004H/[8o\u0011!!I\u0007b\u001bA\u0002\u0005\u0015\u0006b\u0002CA\u0001\u0011%A1Q\u0001\u0014e\u0016<\u0017n\u001d;fe\u0006\u0003\b\u000f\\5dCRLwN\u001c\u000b\u0005\u0003\u001b$)\t\u0003\u0005\u0005\u0016\u0011}\u0004\u0019AA0\u0011\u001d!I\t\u0001C\u0005\t\u0017\u000b\u0011CZ5oSND\u0017\t\u001d9mS\u000e\fG/[8o)\u0011\ti\r\"$\t\u0011\u0011UAq\u0011a\u0001\u0003?Bq\u0001\"%\u0001\t\u0003!\u0019*A\tsK6|g/Z!qa2L7-\u0019;j_:$b!!4\u0005\u0016\u0012]\u0005\u0002\u0003C\u000b\t\u001f\u0003\r!a\u0018\t\u0011\t}Dq\u0012a\u0001\t3\u0003B\u0001b'\u0003\f:\u0019\u0001\u0005\"(\n\u0007\u0011}%!\u0001\tBaBd\u0017nY1uS>t7\u000b^1uK\"9A1\u0015\u0001\u0005\n\u0011\u0015\u0016A\u00065b]\u0012dWMU3rk\u0016\u001cH/\u0012=fGV$xN]:\u0015\r\r\u0005Cq\u0015CV\u0011!!I\u000b\")A\u0002\u0005e\u0011!B1qa&#\u0007b\u0002CW\tC\u0003\raM\u0001\u000fe\u0016\fX/Z:uK\u0012$v\u000e^1m\u0011\u001d!\t\f\u0001C\u0005\tg\u000b1\u0003[1oI2,7*\u001b7m\u000bb,7-\u001e;peN$ba!\u0011\u00056\u0012]\u0006\u0002\u0003CU\t_\u0003\r!!\u0007\t\u0011\u0011eFq\u0016a\u0001\tw\u000b1\"\u001a=fGV$xN]%egB)1\u0011]Byg!9Aq\u0018\u0001\u0005\n\u0011\u0005\u0017!\u00054pe6\fG/\u0012=fGV$xN]%egR!A1\u0018Cb\u0011!!I\f\"0A\u0002\u0011\u0015\u0007CBBq\u0007c\fI\u0002C\u0004\u0005J\u0002!I\u0001b3\u0002\u0019-LG\u000e\\#yK\u000e,Ho\u001c:\u0015\t\u00055GQ\u001a\u0005\t\t\u000b\"9\r1\u0001\u0005H!9A\u0011\u001b\u0001\u0005\n\u0011M\u0017\u0001\u00058fo\u0006\u0003\b\u000f\\5dCRLwN\\%e)\u0011\tI\u0002\"6\t\u0011\u0011]Gq\u001aa\u0001\t3\f!b];c[&$H)\u0019;f!\u0011!Y\u000e\"8\u000e\u0003]K1\u0001b8X\u0005\u0011!\u0015\r^3\t\u000f\u0011\r\b\u0001\"\u0003\u0004 \u0006\u0011B/[7f\u001fV$H)Z1e/>\u00148.\u001a:t\u0011\u001d!9\u000f\u0001C\u0005\tS\f1B\\3x\tJLg/\u001a:JIR!\u0011\u0011\u0004Cv\u0011!!9\u000e\":A\u0002\u0011e\u0007b\u0002Cx\u0001\u0011%A\u0011_\u0001\rGJ,\u0017\r^3Ee&4XM\u001d\u000b\u0005\u0003G$\u0019\u0010\u0003\u0005\u0005t\u00115\b\u0019\u0001C{!\u0011!9\bb>\n\u0007\u0011eHAA\tEe&4XM\u001d#fg\u000e\u0014\u0018\u000e\u001d;j_:Dq\u0001\"@\u0001\t\u0013!y0\u0001\u0007mCVt7\r\u001b#sSZ,'\u000f\u0006\u0004\u0002N\u0016\u0005Q1\u0001\u0005\t\tk!Y\u00101\u0001\u0002J!AA\u0011\u000eC~\u0001\u0004\t\u0019\u000fC\u0004\u0006\b\u0001!I!\"\u0003\u0002\u0019I,Wn\u001c<f\tJLg/\u001a:\u0015\u0011\u00055W1BC\b\u000bkA\u0001\"\"\u0004\u0006\u0006\u0001\u0007\u0011\u0011D\u0001\tIJLg/\u001a:JI\"AQ\u0011CC\u0003\u0001\u0004)\u0019\"\u0001\u0006gS:\fGn\u0015;bi\u0016\u0004B!\"\u0006\u000609!QqCC\u0016\u001d\u0011)I\"\"\u000b\u000f\t\u0015mQq\u0005\b\u0005\u000b;))C\u0004\u0003\u0006 \u0015\rb\u0002BBs\u000bCI\u0011aC\u0005\u0003\u0013)I!a\u0002\u0005\n\u0005\u00151\u0011BA\u0002\u0005\u0013\r)iCA\u0001\f\tJLg/\u001a:Ti\u0006$X-\u0003\u0003\u00062\u0015M\"a\u0003#sSZ,'o\u0015;bi\u0016T1!\"\f\u0003\u0011!)9$\"\u0002A\u0002\u0015e\u0012!C3yG\u0016\u0004H/[8o!\u0015q11NC\u001e!\u0011\u0019\t/\"\u0010\n\t\u0015}2Q\u001f\u0002\n\u000bb\u001cW\r\u001d;j_:<\u0001\"b\u0011\u0003\u0011\u0003!QQI\u0001\u0007\u001b\u0006\u001cH/\u001a:\u0011\u0007\u0001*9EB\u0004\u0002\u0005!\u0005A!\"\u0013\u0014\t\u0015\u001dS\"\u0007\u0005\b\u0011\u0016\u001dC\u0011AC')\t))\u0005\u0003\u0006\u0006R\u0015\u001d#\u0019!C\u0001\u000b'\n1bU-T)\u0016kuLT!N\u000bV\u0011QQ\u000b\t\u0005\u000b/*i&\u0004\u0002\u0006Z)\u0019Q1L-\u0002\t1\fgnZ\u0005\u0005\u0003G)I\u0006C\u0005\u0006b\u0015\u001d\u0003\u0015!\u0003\u0006V\u0005a1+W*U\u000b6{f*Q'FA!QQQMC$\u0005\u0004%\t!b\u0015\u0002\u001b\u0015sE\tU(J\u001dR{f*Q'F\u0011%)I'b\u0012!\u0002\u0013))&\u0001\bF\u001d\u0012\u0003v*\u0013(U?:\u000bU*\u0012\u0011\t\u0011\u00155Tq\tC\u0001\u000b_\nA!\\1j]R!\u0011QZC9\u0011!)\u0019(b\u001bA\u0002\u0015U\u0014AC1sON#(/\u001b8hgB)a\u0002b\u0004\u0002\u001a!AQ\u0011PC$\t\u0003)Y(\u0001\fti\u0006\u0014HO\u00159d\u000b:4\u0018I\u001c3F]\u0012\u0004x.\u001b8u)))i(b!\u0006\b\u0016-UQ\u0012\t\b\u001d\u0015}teMBG\u0013\r)\ti\u0004\u0002\u0007)V\u0004H.Z\u001a\t\u0011\u0015\u0015Uq\u000fa\u0001\u00033\tA\u0001[8ti\"9Q\u0011RC<\u0001\u0004\u0019\u0014\u0001\u00029peRDaAMC<\u0001\u0004\u0019\u0004B\u0002!\u0006x\u0001\u0007!\t")
public class Master
implements ThreadSafeRpcEndpoint,
Logging,
LeaderElectable {
    private final RpcEnv rpcEnv;
    public final RpcAddress org$apache$spark$deploy$master$Master$$address;
    private final int webUiPort;
    private final SecurityManager securityMgr;
    private final SparkConf conf;
    private final ScheduledExecutorService org$apache$spark$deploy$master$Master$$forwardMessageThread;
    private final Configuration hadoopConf;
    private final long org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS;
    private final int RETAINED_APPLICATIONS;
    private final int RETAINED_DRIVERS;
    private final int org$apache$spark$deploy$master$Master$$REAPER_ITERATIONS;
    private final String RECOVERY_MODE;
    private final int org$apache$spark$deploy$master$Master$$MAX_EXECUTOR_RETRIES;
    private final HashSet<WorkerInfo> workers;
    private final HashMap<String, ApplicationInfo> idToApp;
    private final ArrayBuffer<ApplicationInfo> waitingApps;
    private final HashSet<ApplicationInfo> apps;
    private final HashMap<String, WorkerInfo> org$apache$spark$deploy$master$Master$$idToWorker;
    private final HashMap<RpcAddress, WorkerInfo> addressToWorker;
    private final HashMap<RpcEndpointRef, ApplicationInfo> endpointToApp;
    private final HashMap<RpcAddress, ApplicationInfo> addressToApp;
    private final ArrayBuffer<ApplicationInfo> org$apache$spark$deploy$master$Master$$completedApps;
    private int nextAppNumber;
    private final HashSet<DriverInfo> org$apache$spark$deploy$master$Master$$drivers;
    private final ArrayBuffer<DriverInfo> org$apache$spark$deploy$master$Master$$completedDrivers;
    private final ArrayBuffer<DriverInfo> org$apache$spark$deploy$master$Master$$waitingDrivers;
    private int nextDriverNumber;
    private final MetricsSystem masterMetricsSystem;
    private final MetricsSystem org$apache$spark$deploy$master$Master$$applicationMetricsSystem;
    private final MasterSource masterSource;
    private MasterWebUI org$apache$spark$deploy$master$Master$$webUi;
    private final String masterPublicAddress;
    private final String org$apache$spark$deploy$master$Master$$masterUrl;
    private String org$apache$spark$deploy$master$Master$$masterWebUiUrl;
    private Enumeration.Value org$apache$spark$deploy$master$Master$$state;
    private PersistenceEngine org$apache$spark$deploy$master$Master$$persistenceEngine;
    private LeaderElectionAgent leaderElectionAgent;
    private ScheduledFuture<?> org$apache$spark$deploy$master$Master$$recoveryCompletionTask;
    private ScheduledFuture<?> checkForWorkerTimeOutTask;
    private final boolean org$apache$spark$deploy$master$Master$$spreadOutApps;
    private final int defaultCores;
    private final boolean reverseProxy;
    private final boolean restServerEnabled;
    private Option<StandaloneRestServer> restServer;
    private Option<Object> org$apache$spark$deploy$master$Master$$restServerBoundPort;
    private transient Logger org$apache$spark$internal$Logging$$log_;

    public static Tuple3<RpcEnv, Object, Option<Object>> startRpcEnvAndEndpoint(String string, int n, int n2, SparkConf sparkConf) {
        return Master$.MODULE$.startRpcEnvAndEndpoint(string, n, n2, sparkConf);
    }

    public static void main(String[] arrstring) {
        Master$.MODULE$.main(arrstring);
    }

    public static String ENDPOINT_NAME() {
        return Master$.MODULE$.ENDPOINT_NAME();
    }

    public static String SYSTEM_NAME() {
        return Master$.MODULE$.SYSTEM_NAME();
    }

    @Override
    public Logger org$apache$spark$internal$Logging$$log_() {
        return this.org$apache$spark$internal$Logging$$log_;
    }

    @Override
    public void org$apache$spark$internal$Logging$$log__$eq(Logger x$1) {
        this.org$apache$spark$internal$Logging$$log_ = x$1;
    }

    @Override
    public String logName() {
        return Logging$class.logName(this);
    }

    @Override
    public Logger log() {
        return Logging$class.log(this);
    }

    @Override
    public void logInfo(Function0<String> msg) {
        Logging$class.logInfo(this, msg);
    }

    @Override
    public void logDebug(Function0<String> msg) {
        Logging$class.logDebug(this, msg);
    }

    @Override
    public void logTrace(Function0<String> msg) {
        Logging$class.logTrace(this, msg);
    }

    @Override
    public void logWarning(Function0<String> msg) {
        Logging$class.logWarning(this, msg);
    }

    @Override
    public void logError(Function0<String> msg) {
        Logging$class.logError(this, msg);
    }

    @Override
    public void logInfo(Function0<String> msg, Throwable throwable) {
        Logging$class.logInfo(this, msg, throwable);
    }

    @Override
    public void logDebug(Function0<String> msg, Throwable throwable) {
        Logging$class.logDebug(this, msg, throwable);
    }

    @Override
    public void logTrace(Function0<String> msg, Throwable throwable) {
        Logging$class.logTrace(this, msg, throwable);
    }

    @Override
    public void logWarning(Function0<String> msg, Throwable throwable) {
        Logging$class.logWarning(this, msg, throwable);
    }

    @Override
    public void logError(Function0<String> msg, Throwable throwable) {
        Logging$class.logError(this, msg, throwable);
    }

    @Override
    public boolean isTraceEnabled() {
        return Logging$class.isTraceEnabled(this);
    }

    @Override
    public void initializeLogIfNecessary(boolean isInterpreter) {
        Logging$class.initializeLogIfNecessary(this, isInterpreter);
    }

    @Override
    public boolean initializeLogIfNecessary(boolean isInterpreter, boolean silent) {
        return Logging$class.initializeLogIfNecessary(this, isInterpreter, silent);
    }

    @Override
    public boolean initializeLogIfNecessary$default$2() {
        return Logging$class.initializeLogIfNecessary$default$2(this);
    }

    @Override
    public final RpcEndpointRef self() {
        return RpcEndpoint$class.self(this);
    }

    @Override
    public void onError(Throwable cause) {
        RpcEndpoint$class.onError(this, cause);
    }

    @Override
    public void onConnected(RpcAddress remoteAddress) {
        RpcEndpoint$class.onConnected(this, remoteAddress);
    }

    @Override
    public void onNetworkError(Throwable cause, RpcAddress remoteAddress) {
        RpcEndpoint$class.onNetworkError(this, cause, remoteAddress);
    }

    @Override
    public final void stop() {
        RpcEndpoint$class.stop(this);
    }

    @Override
    public RpcEnv rpcEnv() {
        return this.rpcEnv;
    }

    public SecurityManager securityMgr() {
        return this.securityMgr;
    }

    public SparkConf conf() {
        return this.conf;
    }

    public ScheduledExecutorService org$apache$spark$deploy$master$Master$$forwardMessageThread() {
        return this.org$apache$spark$deploy$master$Master$$forwardMessageThread;
    }

    private Configuration hadoopConf() {
        return this.hadoopConf;
    }

    private SimpleDateFormat createDateFormat() {
        return new SimpleDateFormat("yyyyMMddHHmmss", Locale.US);
    }

    public long org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS() {
        return this.org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS;
    }

    private int RETAINED_APPLICATIONS() {
        return this.RETAINED_APPLICATIONS;
    }

    private int RETAINED_DRIVERS() {
        return this.RETAINED_DRIVERS;
    }

    public int org$apache$spark$deploy$master$Master$$REAPER_ITERATIONS() {
        return this.org$apache$spark$deploy$master$Master$$REAPER_ITERATIONS;
    }

    private String RECOVERY_MODE() {
        return this.RECOVERY_MODE;
    }

    public int org$apache$spark$deploy$master$Master$$MAX_EXECUTOR_RETRIES() {
        return this.org$apache$spark$deploy$master$Master$$MAX_EXECUTOR_RETRIES;
    }

    public HashSet<WorkerInfo> workers() {
        return this.workers;
    }

    public HashMap<String, ApplicationInfo> idToApp() {
        return this.idToApp;
    }

    private ArrayBuffer<ApplicationInfo> waitingApps() {
        return this.waitingApps;
    }

    public HashSet<ApplicationInfo> apps() {
        return this.apps;
    }

    public HashMap<String, WorkerInfo> org$apache$spark$deploy$master$Master$$idToWorker() {
        return this.org$apache$spark$deploy$master$Master$$idToWorker;
    }

    private HashMap<RpcAddress, WorkerInfo> addressToWorker() {
        return this.addressToWorker;
    }

    private HashMap<RpcEndpointRef, ApplicationInfo> endpointToApp() {
        return this.endpointToApp;
    }

    private HashMap<RpcAddress, ApplicationInfo> addressToApp() {
        return this.addressToApp;
    }

    public ArrayBuffer<ApplicationInfo> org$apache$spark$deploy$master$Master$$completedApps() {
        return this.org$apache$spark$deploy$master$Master$$completedApps;
    }

    private int nextAppNumber() {
        return this.nextAppNumber;
    }

    private void nextAppNumber_$eq(int x$1) {
        this.nextAppNumber = x$1;
    }

    public HashSet<DriverInfo> org$apache$spark$deploy$master$Master$$drivers() {
        return this.org$apache$spark$deploy$master$Master$$drivers;
    }

    public ArrayBuffer<DriverInfo> org$apache$spark$deploy$master$Master$$completedDrivers() {
        return this.org$apache$spark$deploy$master$Master$$completedDrivers;
    }

    public ArrayBuffer<DriverInfo> org$apache$spark$deploy$master$Master$$waitingDrivers() {
        return this.org$apache$spark$deploy$master$Master$$waitingDrivers;
    }

    private int nextDriverNumber() {
        return this.nextDriverNumber;
    }

    private void nextDriverNumber_$eq(int x$1) {
        this.nextDriverNumber = x$1;
    }

    private MetricsSystem masterMetricsSystem() {
        return this.masterMetricsSystem;
    }

    public MetricsSystem org$apache$spark$deploy$master$Master$$applicationMetricsSystem() {
        return this.org$apache$spark$deploy$master$Master$$applicationMetricsSystem;
    }

    private MasterSource masterSource() {
        return this.masterSource;
    }

    public MasterWebUI org$apache$spark$deploy$master$Master$$webUi() {
        return this.org$apache$spark$deploy$master$Master$$webUi;
    }

    private void org$apache$spark$deploy$master$Master$$webUi_$eq(MasterWebUI x$1) {
        this.org$apache$spark$deploy$master$Master$$webUi = x$1;
    }

    private String masterPublicAddress() {
        return this.masterPublicAddress;
    }

    public String org$apache$spark$deploy$master$Master$$masterUrl() {
        return this.org$apache$spark$deploy$master$Master$$masterUrl;
    }

    public String org$apache$spark$deploy$master$Master$$masterWebUiUrl() {
        return this.org$apache$spark$deploy$master$Master$$masterWebUiUrl;
    }

    private void org$apache$spark$deploy$master$Master$$masterWebUiUrl_$eq(String x$1) {
        this.org$apache$spark$deploy$master$Master$$masterWebUiUrl = x$1;
    }

    public Enumeration.Value org$apache$spark$deploy$master$Master$$state() {
        return this.org$apache$spark$deploy$master$Master$$state;
    }

    public void org$apache$spark$deploy$master$Master$$state_$eq(Enumeration.Value x$1) {
        this.org$apache$spark$deploy$master$Master$$state = x$1;
    }

    public PersistenceEngine org$apache$spark$deploy$master$Master$$persistenceEngine() {
        return this.org$apache$spark$deploy$master$Master$$persistenceEngine;
    }

    private void org$apache$spark$deploy$master$Master$$persistenceEngine_$eq(PersistenceEngine x$1) {
        this.org$apache$spark$deploy$master$Master$$persistenceEngine = x$1;
    }

    private LeaderElectionAgent leaderElectionAgent() {
        return this.leaderElectionAgent;
    }

    private void leaderElectionAgent_$eq(LeaderElectionAgent x$1) {
        this.leaderElectionAgent = x$1;
    }

    private ScheduledFuture<?> org$apache$spark$deploy$master$Master$$recoveryCompletionTask() {
        return this.org$apache$spark$deploy$master$Master$$recoveryCompletionTask;
    }

    public void org$apache$spark$deploy$master$Master$$recoveryCompletionTask_$eq(ScheduledFuture<?> x$1) {
        this.org$apache$spark$deploy$master$Master$$recoveryCompletionTask = x$1;
    }

    private ScheduledFuture<?> checkForWorkerTimeOutTask() {
        return this.checkForWorkerTimeOutTask;
    }

    private void checkForWorkerTimeOutTask_$eq(ScheduledFuture<?> x$1) {
        this.checkForWorkerTimeOutTask = x$1;
    }

    public boolean org$apache$spark$deploy$master$Master$$spreadOutApps() {
        return this.org$apache$spark$deploy$master$Master$$spreadOutApps;
    }

    private int defaultCores() {
        return this.defaultCores;
    }

    public boolean reverseProxy() {
        return this.reverseProxy;
    }

    private boolean restServerEnabled() {
        return this.restServerEnabled;
    }

    private Option<StandaloneRestServer> restServer() {
        return this.restServer;
    }

    private void restServer_$eq(Option<StandaloneRestServer> x$1) {
        this.restServer = x$1;
    }

    public Option<Object> org$apache$spark$deploy$master$Master$$restServerBoundPort() {
        return this.org$apache$spark$deploy$master$Master$$restServerBoundPort;
    }

    private void org$apache$spark$deploy$master$Master$$restServerBoundPort_$eq(Option<Object> x$1) {
        this.org$apache$spark$deploy$master$Master$$restServerBoundPort = x$1;
    }

    @Override
    public void onStart() {
        Tuple2 tuple2;
        this.logInfo((Function0<String>)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final String apply() {
                return new StringBuilder().append((Object)"Starting Spark master at ").append((Object)this.$outer.org$apache$spark$deploy$master$Master$$masterUrl()).toString();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        this.logInfo((Function0<String>)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final String apply() {
                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Running Spark version ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{org.apache.spark.package$.MODULE$.SPARK_VERSION()}));
            }
        });
        this.org$apache$spark$deploy$master$Master$$webUi_$eq(new MasterWebUI(this, this.webUiPort));
        this.org$apache$spark$deploy$master$Master$$webUi().bind();
        this.org$apache$spark$deploy$master$Master$$masterWebUiUrl_$eq(new StringBuilder().append((Object)"http://").append((Object)this.masterPublicAddress()).append((Object)":").append((Object)BoxesRunTime.boxToInteger((int)this.org$apache$spark$deploy$master$Master$$webUi().boundPort())).toString());
        if (this.reverseProxy()) {
            this.org$apache$spark$deploy$master$Master$$masterWebUiUrl_$eq(this.conf().get("spark.ui.reverseProxyUrl", this.org$apache$spark$deploy$master$Master$$masterWebUiUrl()));
            this.org$apache$spark$deploy$master$Master$$webUi().addProxy();
            this.logInfo((Function0<String>)new Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ Master $outer;

                public final String apply() {
                    return new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Spark Master is acting as a reverse proxy. Master, Workers and "})).s((Seq)scala.collection.immutable.Nil$.MODULE$)).append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Applications UIs are available at ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.$outer.org$apache$spark$deploy$master$Master$$masterWebUiUrl()}))).toString();
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            });
        }
        this.checkForWorkerTimeOutTask_$eq(this.org$apache$spark$deploy$master$Master$$forwardMessageThread().scheduleAtFixedRate(new Runnable(this){
            private final /* synthetic */ Master $outer;

            public void run() {
                Utils$.MODULE$.tryLogNonFatalError((Function0<BoxedUnit>)new Serializable(this){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ $anon$1 $outer;

                    public final void apply() {
                        this.apply$mcV$sp();
                    }

                    public void apply$mcV$sp() {
                        this.$outer.org$apache$spark$deploy$master$Master$$anon$$$outer().self().send(org.apache.spark.deploy.master.MasterMessages$CheckForWorkerTimeOut$.MODULE$);
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                    }
                });
            }

            public /* synthetic */ Master org$apache$spark$deploy$master$Master$$anon$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, 0L, this.org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS(), TimeUnit.MILLISECONDS));
        if (this.restServerEnabled()) {
            int port = this.conf().getInt("spark.master.rest.port", 6066);
            this.restServer_$eq((Option<StandaloneRestServer>)new Some((Object)new StandaloneRestServer(this.org$apache$spark$deploy$master$Master$$address.host(), port, this.conf(), this.self(), this.org$apache$spark$deploy$master$Master$$masterUrl())));
        }
        this.org$apache$spark$deploy$master$Master$$restServerBoundPort_$eq((Option<Object>)this.restServer().map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(StandaloneRestServer x$1) {
                return x$1.start();
            }
        }));
        this.masterMetricsSystem().registerSource(this.masterSource());
        this.masterMetricsSystem().start();
        this.org$apache$spark$deploy$master$Master$$applicationMetricsSystem().start();
        MasterWebUI masterWebUI = this.org$apache$spark$deploy$master$Master$$webUi();
        Predef$.MODULE$.refArrayOps((Object[])this.masterMetricsSystem().getServletHandlers()).foreach((Function1)new Serializable(this, masterWebUI){
            public static final long serialVersionUID = 0L;
            private final MasterWebUI eta$0$1$1;

            public final void apply(ServletContextHandler handler) {
                this.eta$0$1$1.attachHandler(handler);
            }
            {
                this.eta$0$1$1 = eta$0$1$1;
            }
        });
        MasterWebUI masterWebUI2 = this.org$apache$spark$deploy$master$Master$$webUi();
        Predef$.MODULE$.refArrayOps((Object[])this.org$apache$spark$deploy$master$Master$$applicationMetricsSystem().getServletHandlers()).foreach((Function1)new Serializable(this, masterWebUI2){
            public static final long serialVersionUID = 0L;
            private final MasterWebUI eta$0$2$1;

            public final void apply(ServletContextHandler handler) {
                this.eta$0$2$1.attachHandler(handler);
            }
            {
                this.eta$0$2$1 = eta$0$2$1;
            }
        });
        JavaSerializer serializer = new JavaSerializer(this.conf());
        String string = this.RECOVERY_MODE();
        if ("ZOOKEEPER".equals(string)) {
            this.logInfo((Function0<String>)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "Persisting recovery state to ZooKeeper";
                }
            });
            ZooKeeperRecoveryModeFactory zkFactory = new ZooKeeperRecoveryModeFactory(this.conf(), serializer);
            tuple2 = new Tuple2((Object)zkFactory.createPersistenceEngine(), (Object)zkFactory.createLeaderElectionAgent(this));
        } else if ("FILESYSTEM".equals(string)) {
            FileSystemRecoveryModeFactory fsFactory = new FileSystemRecoveryModeFactory(this.conf(), serializer);
            tuple2 = new Tuple2((Object)fsFactory.createPersistenceEngine(), (Object)fsFactory.createLeaderElectionAgent(this));
        } else if ("CUSTOM".equals(string)) {
            Class<?> clazz = Utils$.MODULE$.classForName(this.conf().get("spark.deploy.recoveryMode.factory"));
            StandaloneRecoveryModeFactory factory = (StandaloneRecoveryModeFactory)clazz.getConstructor(SparkConf.class, Serializer.class).newInstance(this.conf(), serializer);
            tuple2 = new Tuple2((Object)factory.createPersistenceEngine(), (Object)factory.createLeaderElectionAgent(this));
        } else {
            tuple2 = new Tuple2((Object)new BlackHolePersistenceEngine(), (Object)new MonarchyLeaderAgent(this));
        }
        Tuple2 tuple22 = tuple2;
        if (tuple22 != null) {
            Tuple2 tuple23;
            PersistenceEngine persistenceEngine_ = (PersistenceEngine)tuple22._1();
            LeaderElectionAgent leaderElectionAgent_ = (LeaderElectionAgent)tuple22._2();
            Tuple2 tuple24 = tuple23 = new Tuple2((Object)persistenceEngine_, (Object)leaderElectionAgent_);
            PersistenceEngine persistenceEngine_2 = (PersistenceEngine)tuple24._1();
            LeaderElectionAgent leaderElectionAgent_2 = (LeaderElectionAgent)tuple24._2();
            this.org$apache$spark$deploy$master$Master$$persistenceEngine_$eq(persistenceEngine_2);
            this.leaderElectionAgent_$eq(leaderElectionAgent_2);
            return;
        }
        throw new MatchError((Object)tuple22);
    }

    @Override
    public void onStop() {
        this.masterMetricsSystem().report();
        this.org$apache$spark$deploy$master$Master$$applicationMetricsSystem().report();
        Object object = this.org$apache$spark$deploy$master$Master$$recoveryCompletionTask() == null ? BoxedUnit.UNIT : BoxesRunTime.boxToBoolean((boolean)this.org$apache$spark$deploy$master$Master$$recoveryCompletionTask().cancel(true));
        Object object2 = this.checkForWorkerTimeOutTask() == null ? BoxedUnit.UNIT : BoxesRunTime.boxToBoolean((boolean)this.checkForWorkerTimeOutTask().cancel(true));
        this.org$apache$spark$deploy$master$Master$$forwardMessageThread().shutdownNow();
        this.org$apache$spark$deploy$master$Master$$webUi().stop();
        this.restServer().foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final void apply(StandaloneRestServer x$3) {
                x$3.stop();
            }
        });
        this.masterMetricsSystem().stop();
        this.org$apache$spark$deploy$master$Master$$applicationMetricsSystem().stop();
        this.org$apache$spark$deploy$master$Master$$persistenceEngine().close();
        this.leaderElectionAgent().stop();
    }

    @Override
    public void electedLeader() {
        this.self().send(MasterMessages$ElectedLeader$.MODULE$);
    }

    @Override
    public void revokedLeadership() {
        this.self().send(MasterMessages$RevokedLeadership$.MODULE$);
    }

    @Override
    public PartialFunction<Object, BoxedUnit> receive() {
        return new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public final <A1, B1> B1 applyOrElse(A1 x1, Function1<A1, B1> default) {
                block55 : {
                    block59 : {
                        block66 : {
                            block65 : {
                                block64 : {
                                    block63 : {
                                        block62 : {
                                            block61 : {
                                                block60 : {
                                                    block58 : {
                                                        block57 : {
                                                            block56 : {
                                                                block46 : {
                                                                    block54 : {
                                                                        block47 : {
                                                                            block52 : {
                                                                                block53 : {
                                                                                    block50 : {
                                                                                        block51 : {
                                                                                            block49 : {
                                                                                                block48 : {
                                                                                                    block44 : {
                                                                                                        block45 : {
                                                                                                            block42 : {
                                                                                                                block43 : {
                                                                                                                    block40 : {
                                                                                                                        block41 : {
                                                                                                                            var3_3 = x1;
                                                                                                                            if (!MasterMessages$ElectedLeader$.MODULE$.equals(var3_3)) break block40;
                                                                                                                            var6_4 = this.$outer.org$apache$spark$deploy$master$Master$$persistenceEngine().readPersistedData(this.$outer.rpcEnv());
                                                                                                                            if (var6_4 == null) throw new MatchError(var6_4);
                                                                                                                            storedApps = (Seq)var6_4._1();
                                                                                                                            storedDrivers = (Seq)var6_4._2();
                                                                                                                            storedWorkers = (Seq)var6_4._3();
                                                                                                                            var5_9 = var10_8 = new Tuple3((Object)storedApps, (Object)storedDrivers, (Object)storedWorkers);
                                                                                                                            storedApps = (Seq)var5_9._1();
                                                                                                                            storedDrivers = (Seq)var5_9._2();
                                                                                                                            storedWorkers = (Seq)var5_9._3();
                                                                                                                            this.$outer.org$apache$spark$deploy$master$Master$$state_$eq(storedApps.isEmpty() != false && storedDrivers.isEmpty() != false && storedWorkers.isEmpty() != false ? RecoveryState$.MODULE$.ALIVE() : RecoveryState$.MODULE$.RECOVERING());
                                                                                                                            this.$outer.logInfo((Function0<String>)new Serializable(this){
                                                                                                                                public static final long serialVersionUID = 0L;
                                                                                                                                private final /* synthetic */ $anonfun$receive$1 $outer;

                                                                                                                                public final String apply() {
                                                                                                                                    return new StringBuilder().append((Object)"I have been elected leader! New state: ").append((Object)this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().org$apache$spark$deploy$master$Master$$state()).toString();
                                                                                                                                }
                                                                                                                                {
                                                                                                                                    if ($outer == null) {
                                                                                                                                        throw null;
                                                                                                                                    }
                                                                                                                                    this.$outer = $outer;
                                                                                                                                }
                                                                                                                            });
                                                                                                                            var14_13 = RecoveryState$.MODULE$.RECOVERING();
                                                                                                                            if (this.$outer.org$apache$spark$deploy$master$Master$$state() != null) break block41;
                                                                                                                            if (var14_13 == null) ** GOTO lbl-1000
                                                                                                                            ** GOTO lbl-1000
                                                                                                                        }
                                                                                                                        if (v0.equals((Object)var14_13)) lbl-1000: // 2 sources:
                                                                                                                        {
                                                                                                                            this.$outer.org$apache$spark$deploy$master$Master$$beginRecovery((Seq<ApplicationInfo>)storedApps, (Seq<DriverInfo>)storedDrivers, (Seq<WorkerInfo>)storedWorkers);
                                                                                                                            this.$outer.org$apache$spark$deploy$master$Master$$recoveryCompletionTask_$eq(this.$outer.org$apache$spark$deploy$master$Master$$forwardMessageThread().schedule(new Runnable(this){
                                                                                                                                private final /* synthetic */ $anonfun$receive$1 $outer;

                                                                                                                                public void run() {
                                                                                                                                    Utils$.MODULE$.tryLogNonFatalError((Function0<BoxedUnit>)new Serializable(this){
                                                                                                                                        public static final long serialVersionUID = 0L;
                                                                                                                                        private final /* synthetic */ org.apache.spark.deploy.master.Master$$anonfun$receive$1$$anon$2 $outer;

                                                                                                                                        public final void apply() {
                                                                                                                                            this.apply$mcV$sp();
                                                                                                                                        }

                                                                                                                                        public void apply$mcV$sp() {
                                                                                                                                            this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$anon$$$outer().org$apache$spark$deploy$master$Master$$anonfun$$$outer().self().send(org.apache.spark.deploy.master.MasterMessages$CompleteRecovery$.MODULE$);
                                                                                                                                        }
                                                                                                                                        {
                                                                                                                                            if ($outer == null) {
                                                                                                                                                throw null;
                                                                                                                                            }
                                                                                                                                            this.$outer = $outer;
                                                                                                                                        }
                                                                                                                                    });
                                                                                                                                }

                                                                                                                                public /* synthetic */ $anonfun$receive$1 org$apache$spark$deploy$master$Master$$anonfun$$anon$$$outer() {
                                                                                                                                    return this.$outer;
                                                                                                                                }
                                                                                                                                {
                                                                                                                                    if ($outer == null) {
                                                                                                                                        throw null;
                                                                                                                                    }
                                                                                                                                    this.$outer = $outer;
                                                                                                                                }
                                                                                                                            }, this.$outer.org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS(), TimeUnit.MILLISECONDS));
                                                                                                                            v1 = BoxedUnit.UNIT;
                                                                                                                        } else lbl-1000: // 2 sources:
                                                                                                                        {
                                                                                                                            v1 = BoxedUnit.UNIT;
                                                                                                                        }
                                                                                                                        var4_14 = v1;
                                                                                                                        return var4_28;
                                                                                                                    }
                                                                                                                    if (org.apache.spark.deploy.master.MasterMessages$CompleteRecovery$.MODULE$.equals(var3_3)) {
                                                                                                                        this.$outer.org$apache$spark$deploy$master$Master$$completeRecovery();
                                                                                                                        var4_15 = BoxedUnit.UNIT;
                                                                                                                        return var4_28;
                                                                                                                    }
                                                                                                                    if (MasterMessages$RevokedLeadership$.MODULE$.equals(var3_3)) {
                                                                                                                        this.$outer.logError((Function0<String>)new Serializable(this){
                                                                                                                            public static final long serialVersionUID = 0L;

                                                                                                                            public final String apply() {
                                                                                                                                return "Leadership has been revoked -- master shutting down.";
                                                                                                                            }
                                                                                                                        });
                                                                                                                        System.exit(0);
                                                                                                                        var4_16 = BoxedUnit.UNIT;
                                                                                                                        return var4_28;
                                                                                                                    }
                                                                                                                    if (!(var3_3 instanceof org.apache.spark.deploy.DeployMessages$RegisterWorker)) break block42;
                                                                                                                    var15_29 = (org.apache.spark.deploy.DeployMessages$RegisterWorker)var3_3;
                                                                                                                    id = var15_29.id();
                                                                                                                    workerHost = var15_29.host();
                                                                                                                    workerPort = var15_29.port();
                                                                                                                    workerRef = var15_29.worker();
                                                                                                                    cores = var15_29.cores();
                                                                                                                    memory = var15_29.memory();
                                                                                                                    workerWebUiUrl = var15_29.workerWebUiUrl();
                                                                                                                    masterAddress = var15_29.masterAddress();
                                                                                                                    this.$outer.logInfo((Function0<String>)new Serializable(this, workerHost, workerPort, cores, memory){
                                                                                                                        public static final long serialVersionUID = 0L;
                                                                                                                        private final String workerHost$1;
                                                                                                                        private final int workerPort$1;
                                                                                                                        private final int cores$1;
                                                                                                                        private final int memory$1;

                                                                                                                        public final String apply() {
                                                                                                                            return new StringOps(Predef$.MODULE$.augmentString("Registering worker %s:%d with %d cores, %s RAM")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workerHost$1, BoxesRunTime.boxToInteger((int)this.workerPort$1), BoxesRunTime.boxToInteger((int)this.cores$1), Utils$.MODULE$.megabytesToString(this.memory$1)}));
                                                                                                                        }
                                                                                                                        {
                                                                                                                            this.workerHost$1 = workerHost$1;
                                                                                                                            this.workerPort$1 = workerPort$1;
                                                                                                                            this.cores$1 = cores$1;
                                                                                                                            this.memory$1 = memory$1;
                                                                                                                        }
                                                                                                                    });
                                                                                                                    var24_38 = RecoveryState$.MODULE$.STANDBY();
                                                                                                                    if (this.$outer.org$apache$spark$deploy$master$Master$$state() != null) break block43;
                                                                                                                    if (var24_38 == null) ** GOTO lbl-1000
                                                                                                                    ** GOTO lbl-1000
                                                                                                                }
                                                                                                                if (v2.equals((Object)var24_38)) lbl-1000: // 2 sources:
                                                                                                                {
                                                                                                                    workerRef.send(org.apache.spark.deploy.DeployMessages$MasterInStandby$.MODULE$);
                                                                                                                    v3 = BoxedUnit.UNIT;
                                                                                                                } else if (this.$outer.org$apache$spark$deploy$master$Master$$idToWorker().contains((Object)id)) {
                                                                                                                    workerRef.send(new org.apache.spark.deploy.DeployMessages$RegisterWorkerFailed("Duplicate worker ID"));
                                                                                                                    v3 = BoxedUnit.UNIT;
                                                                                                                } else {
                                                                                                                    worker = new WorkerInfo(id, workerHost, workerPort, cores, memory, workerRef, workerWebUiUrl);
                                                                                                                    if (this.$outer.org$apache$spark$deploy$master$Master$$registerWorker(worker)) {
                                                                                                                        this.$outer.org$apache$spark$deploy$master$Master$$persistenceEngine().addWorker(worker);
                                                                                                                        workerRef.send(new org.apache.spark.deploy.DeployMessages$RegisteredWorker(this.$outer.self(), this.$outer.org$apache$spark$deploy$master$Master$$masterWebUiUrl(), masterAddress));
                                                                                                                        this.$outer.org$apache$spark$deploy$master$Master$$schedule();
                                                                                                                        v3 = BoxedUnit.UNIT;
                                                                                                                    } else {
                                                                                                                        workerAddress = worker.endpoint().address();
                                                                                                                        this.$outer.logWarning((Function0<String>)new Serializable(this, workerAddress){
                                                                                                                            public static final long serialVersionUID = 0L;
                                                                                                                            private final RpcAddress workerAddress$1;

                                                                                                                            public final String apply() {
                                                                                                                                return new StringBuilder().append((Object)"Worker registration failed. Attempted to re-register worker at same address: ").append((Object)this.workerAddress$1).toString();
                                                                                                                            }
                                                                                                                            {
                                                                                                                                this.workerAddress$1 = workerAddress$1;
                                                                                                                            }
                                                                                                                        });
                                                                                                                        workerRef.send(new org.apache.spark.deploy.DeployMessages$RegisterWorkerFailed(new StringBuilder().append((Object)"Attempted to re-register worker at same address: ").append((Object)workerAddress).toString()));
                                                                                                                        v3 = BoxedUnit.UNIT;
                                                                                                                    }
                                                                                                                }
                                                                                                                var4_17 = v3;
                                                                                                                return var4_28;
                                                                                                            }
                                                                                                            if (!(var3_3 instanceof org.apache.spark.deploy.DeployMessages$RegisterApplication)) break block44;
                                                                                                            var27_41 = (org.apache.spark.deploy.DeployMessages$RegisterApplication)var3_3;
                                                                                                            description = var27_41.appDescription();
                                                                                                            driver = var27_41.driver();
                                                                                                            var30_44 = RecoveryState$.MODULE$.STANDBY();
                                                                                                            if (this.$outer.org$apache$spark$deploy$master$Master$$state() != null) break block45;
                                                                                                            if (var30_44 == null) ** GOTO lbl-1000
                                                                                                            ** GOTO lbl-1000
                                                                                                        }
                                                                                                        if (v4.equals((Object)var30_44)) lbl-1000: // 2 sources:
                                                                                                        {
                                                                                                            v5 = BoxedUnit.UNIT;
                                                                                                        } else lbl-1000: // 2 sources:
                                                                                                        {
                                                                                                            this.$outer.logInfo((Function0<String>)new Serializable(this, description){
                                                                                                                public static final long serialVersionUID = 0L;
                                                                                                                private final ApplicationDescription description$1;

                                                                                                                public final String apply() {
                                                                                                                    return new StringBuilder().append((Object)"Registering app ").append((Object)this.description$1.name()).toString();
                                                                                                                }
                                                                                                                {
                                                                                                                    this.description$1 = description$1;
                                                                                                                }
                                                                                                            });
                                                                                                            app = this.$outer.org$apache$spark$deploy$master$Master$$createApplication(description, driver);
                                                                                                            this.$outer.org$apache$spark$deploy$master$Master$$registerApplication(app);
                                                                                                            this.$outer.logInfo((Function0<String>)new Serializable(this, description, app){
                                                                                                                public static final long serialVersionUID = 0L;
                                                                                                                private final ApplicationDescription description$1;
                                                                                                                private final ApplicationInfo app$1;

                                                                                                                public final String apply() {
                                                                                                                    return new StringBuilder().append((Object)"Registered app ").append((Object)this.description$1.name()).append((Object)" with ID ").append((Object)this.app$1.id()).toString();
                                                                                                                }
                                                                                                                {
                                                                                                                    this.description$1 = description$1;
                                                                                                                    this.app$1 = app$1;
                                                                                                                }
                                                                                                            });
                                                                                                            this.$outer.org$apache$spark$deploy$master$Master$$persistenceEngine().addApplication(app);
                                                                                                            driver.send(new org.apache.spark.deploy.DeployMessages$RegisteredApplication(app.id(), this.$outer.self()));
                                                                                                            this.$outer.org$apache$spark$deploy$master$Master$$schedule();
                                                                                                            v5 = BoxedUnit.UNIT;
                                                                                                        }
                                                                                                        var4_18 = v5;
                                                                                                        return var4_28;
                                                                                                    }
                                                                                                    if (!(var3_3 instanceof org.apache.spark.deploy.DeployMessages$ExecutorStateChanged)) break block46;
                                                                                                    var32_46 = (org.apache.spark.deploy.DeployMessages$ExecutorStateChanged)var3_3;
                                                                                                    appId = var32_46.appId();
                                                                                                    execId = var32_46.execId();
                                                                                                    state = var32_46.state();
                                                                                                    message = var32_46.message();
                                                                                                    exitStatus = var32_46.exitStatus();
                                                                                                    execOption = this.$outer.idToApp().get((Object)appId).flatMap((Function1)new Serializable(this, execId){
                                                                                                        public static final long serialVersionUID = 0L;
                                                                                                        private final int execId$1;

                                                                                                        public final Option<ExecutorDesc> apply(ApplicationInfo app) {
                                                                                                            return app.executors().get((Object)BoxesRunTime.boxToInteger((int)this.execId$1));
                                                                                                        }
                                                                                                        {
                                                                                                            this.execId$1 = execId$1;
                                                                                                        }
                                                                                                    });
                                                                                                    var39_53 = execOption;
                                                                                                    if (!(var39_53 instanceof Some)) break block47;
                                                                                                    var40_54 = (Some)var39_53;
                                                                                                    exec = (ExecutorDesc)var40_54.x();
                                                                                                    appInfo = (ApplicationInfo)this.$outer.idToApp().apply((Object)appId);
                                                                                                    oldState = exec.state();
                                                                                                    exec.state_$eq(state);
                                                                                                    var45_58 = ExecutorState$.MODULE$.RUNNING();
                                                                                                    if (state != null) break block48;
                                                                                                    if (var45_58 == null) break block49;
                                                                                                    break block50;
                                                                                                }
                                                                                                if (!v6.equals((Object)var45_58)) break block50;
                                                                                            }
                                                                                            var46_59 = ExecutorState$.MODULE$.LAUNCHING();
                                                                                            if (oldState != null) break block51;
                                                                                            if (var46_59 == null) ** GOTO lbl-1000
                                                                                            ** GOTO lbl-1000
                                                                                        }
                                                                                        if (v7.equals((Object)var46_59)) lbl-1000: // 2 sources:
                                                                                        {
                                                                                            v8 = true;
                                                                                        } else lbl-1000: // 2 sources:
                                                                                        {
                                                                                            v8 = false;
                                                                                        }
                                                                                        Predef$.MODULE$.assert(v8, (Function0)new Serializable(this, execId, oldState){
                                                                                            public static final long serialVersionUID = 0L;
                                                                                            private final int execId$1;
                                                                                            private final Enumeration.Value oldState$1;

                                                                                            public final String apply() {
                                                                                                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"executor ", " state transfer from ", " to RUNNING is illegal"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.execId$1), this.oldState$1}));
                                                                                            }
                                                                                            {
                                                                                                this.execId$1 = execId$1;
                                                                                                this.oldState$1 = oldState$1;
                                                                                            }
                                                                                        });
                                                                                        appInfo.resetRetryCount();
                                                                                    }
                                                                                    exec.application().driver().send(new org.apache.spark.deploy.DeployMessages$ExecutorUpdated(execId, state, message, exitStatus, false));
                                                                                    if (!ExecutorState$.MODULE$.isFinished(state)) break block52;
                                                                                    this.$outer.logInfo((Function0<String>)new Serializable(this, state, exec){
                                                                                        public static final long serialVersionUID = 0L;
                                                                                        private final Enumeration.Value state$1;
                                                                                        private final ExecutorDesc exec$1;

                                                                                        public final String apply() {
                                                                                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Removing executor ", " because it is ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.exec$1.fullId(), this.state$1}));
                                                                                        }
                                                                                        {
                                                                                            this.state$1 = state$1;
                                                                                            this.exec$1 = exec$1;
                                                                                        }
                                                                                    });
                                                                                    if (!appInfo.isFinished()) {
                                                                                        appInfo.removeExecutor(exec);
                                                                                    }
                                                                                    exec.worker().removeExecutor(exec);
                                                                                    var48_60 = new Some((Object)BoxesRunTime.boxToInteger((int)0));
                                                                                    if (exitStatus != null) break block53;
                                                                                    if (var48_60 == null) ** GOTO lbl-1000
                                                                                    ** GOTO lbl-1000
                                                                                }
                                                                                if (v9.equals((Object)var48_60)) lbl-1000: // 2 sources:
                                                                                {
                                                                                    v10 = true;
                                                                                } else lbl-1000: // 2 sources:
                                                                                {
                                                                                    v10 = normalExit = false;
                                                                                }
                                                                                if (!normalExit && appInfo.incrementRetryCount() >= this.$outer.org$apache$spark$deploy$master$Master$$MAX_EXECUTOR_RETRIES() && this.$outer.org$apache$spark$deploy$master$Master$$MAX_EXECUTOR_RETRIES() >= 0 && !(execs = appInfo.executors().values()).exists((Function1)new Serializable(this){
                                                                                    public static final long serialVersionUID = 0L;

                                                                                    /*
                                                                                     * Enabled force condition propagation
                                                                                     * Lifted jumps to return sites
                                                                                     */
                                                                                    public final boolean apply(ExecutorDesc x$5) {
                                                                                        Enumeration.Value value2 = ExecutorState$.MODULE$.RUNNING();
                                                                                        if (x$5.state() != null) {
                                                                                            Enumeration.Value value3;
                                                                                            if (!value3.equals((Object)value2)) return false;
                                                                                            return true;
                                                                                        }
                                                                                        if (value2 == null) return true;
                                                                                        return false;
                                                                                    }
                                                                                })) {
                                                                                    this.$outer.logError((Function0<String>)new Serializable(this, appInfo){
                                                                                        public static final long serialVersionUID = 0L;
                                                                                        private final ApplicationInfo appInfo$1;

                                                                                        public final String apply() {
                                                                                            return new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Application ", " with ID ", " failed "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.appInfo$1.desc().name(), this.appInfo$1.id()}))).append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " times; removing it"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToInteger((int)this.appInfo$1.retryCount())}))).toString();
                                                                                        }
                                                                                        {
                                                                                            this.appInfo$1 = appInfo$1;
                                                                                        }
                                                                                    });
                                                                                    this.$outer.removeApplication(appInfo, ApplicationState$.MODULE$.FAILED());
                                                                                }
                                                                            }
                                                                            this.$outer.org$apache$spark$deploy$master$Master$$schedule();
                                                                            var42_63 = BoxedUnit.UNIT;
                                                                            break block54;
                                                                        }
                                                                        if (None$.MODULE$.equals((Object)var39_53) == false) throw new MatchError((Object)var39_53);
                                                                        this.$outer.logWarning((Function0<String>)new Serializable(this, appId, execId){
                                                                            public static final long serialVersionUID = 0L;
                                                                            private final String appId$1;
                                                                            private final int execId$1;

                                                                            public final String apply() {
                                                                                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Got status update for unknown executor ", "/", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.appId$1, BoxesRunTime.boxToInteger((int)this.execId$1)}));
                                                                            }
                                                                            {
                                                                                this.appId$1 = appId$1;
                                                                                this.execId$1 = execId$1;
                                                                            }
                                                                        });
                                                                        var42_64 = BoxedUnit.UNIT;
                                                                    }
                                                                    var4_19 = BoxedUnit.UNIT;
                                                                    return var4_28;
                                                                }
                                                                if (!(var3_3 instanceof org.apache.spark.deploy.DeployMessages$DriverStateChanged)) break block55;
                                                                var50_65 = (org.apache.spark.deploy.DeployMessages$DriverStateChanged)var3_3;
                                                                driverId = var50_65.driverId();
                                                                state = var50_65.state();
                                                                exception = var50_65.exception();
                                                                var54_69 = state;
                                                                var55_70 = var54_69;
                                                                if (DriverState$.MODULE$.ERROR() != null) break block56;
                                                                if (var55_70 == null) break block57;
                                                                break block58;
                                                            }
                                                            if (!v11.equals((Object)var55_70)) break block58;
                                                        }
                                                        var56_71 = true;
                                                        break block59;
                                                    }
                                                    var57_72 = var54_69;
                                                    if (DriverState$.MODULE$.FINISHED() != null) break block60;
                                                    if (var57_72 == null) break block61;
                                                    break block62;
                                                }
                                                if (!v12.equals((Object)var57_72)) break block62;
                                            }
                                            var56_71 = true;
                                            break block59;
                                        }
                                        var58_73 = var54_69;
                                        if (DriverState$.MODULE$.KILLED() != null) break block63;
                                        if (var58_73 == null) break block64;
                                        break block65;
                                    }
                                    if (!v13.equals((Object)var58_73)) break block65;
                                }
                                var56_71 = true;
                                break block59;
                            }
                            var59_74 = var54_69;
                            if (DriverState$.MODULE$.FAILED() != null) break block66;
                            if (var59_74 == null) ** GOTO lbl-1000
                            ** GOTO lbl-1000
                        }
                        if (v14.equals((Object)var59_74)) lbl-1000: // 2 sources:
                        {
                            var56_71 = true;
                        } else lbl-1000: // 2 sources:
                        {
                            var56_71 = false;
                        }
                    }
                    if (!var56_71) throw new Exception(new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Received unexpected state update for driver ", ": ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{driverId, state})));
                    this.$outer.org$apache$spark$deploy$master$Master$$removeDriver(driverId, state, exception);
                    var60_75 = BoxedUnit.UNIT;
                    var4_20 = BoxedUnit.UNIT;
                    return var4_28;
                }
                if (var3_3 instanceof org.apache.spark.deploy.DeployMessages$Heartbeat) {
                    var61_76 = (org.apache.spark.deploy.DeployMessages$Heartbeat)var3_3;
                    workerId = var61_76.workerId();
                    worker = var61_76.worker();
                    var64_79 = this.$outer.org$apache$spark$deploy$master$Master$$idToWorker().get((Object)workerId);
                    if (var64_79 instanceof Some) {
                        var65_80 = (Some)var64_79;
                        workerInfo = (WorkerInfo)var65_80.x();
                        workerInfo.lastHeartbeat_$eq(System.currentTimeMillis());
                        var67_82 = BoxedUnit.UNIT;
                    } else {
                        if (None$.MODULE$.equals((Object)var64_79) == false) throw new MatchError((Object)var64_79);
                        if (((HashSet)this.$outer.workers().map((Function1)new Serializable(this){
                            public static final long serialVersionUID = 0L;

                            public final String apply(WorkerInfo x$6) {
                                return x$6.id();
                            }
                        }, scala.collection.mutable.HashSet$.MODULE$.canBuildFrom())).contains((Object)workerId)) {
                            this.$outer.logWarning((Function0<String>)new Serializable(this, workerId){
                                public static final long serialVersionUID = 0L;
                                private final String workerId$1;

                                public final String apply() {
                                    return new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Got heartbeat from unregistered worker ", "."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workerId$1}))).append((Object)" Asking it to re-register.").toString();
                                }
                                {
                                    this.workerId$1 = workerId$1;
                                }
                            });
                            worker.send(new org.apache.spark.deploy.DeployMessages$ReconnectWorker(this.$outer.org$apache$spark$deploy$master$Master$$masterUrl()));
                            v15 = BoxedUnit.UNIT;
                        } else {
                            this.$outer.logWarning((Function0<String>)new Serializable(this, workerId){
                                public static final long serialVersionUID = 0L;
                                private final String workerId$1;

                                public final String apply() {
                                    return new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Got heartbeat from unregistered worker ", "."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.workerId$1}))).append((Object)" This worker was never registered, so ignoring the heartbeat.").toString();
                                }
                                {
                                    this.workerId$1 = workerId$1;
                                }
                            });
                            v15 = BoxedUnit.UNIT;
                        }
                        var67_83 = v15;
                    }
                    var4_21 = BoxedUnit.UNIT;
                    return var4_28;
                }
                if (var3_3 instanceof org.apache.spark.deploy.DeployMessages$MasterChangeAcknowledged) {
                    var68_84 = (org.apache.spark.deploy.DeployMessages$MasterChangeAcknowledged)var3_3;
                    appId = var68_84.appId();
                    var70_86 = this.$outer.idToApp().get((Object)appId);
                    if (var70_86 instanceof Some) {
                        var71_87 = (Some)var70_86;
                        app = (ApplicationInfo)var71_87.x();
                        this.$outer.logInfo((Function0<String>)new Serializable(this, appId){
                            public static final long serialVersionUID = 0L;
                            private final String appId$2;

                            public final String apply() {
                                return new StringBuilder().append((Object)"Application has been re-registered: ").append((Object)this.appId$2).toString();
                            }
                            {
                                this.appId$2 = appId$2;
                            }
                        });
                        app.state_$eq(ApplicationState$.MODULE$.WAITING());
                        var73_89 = BoxedUnit.UNIT;
                    } else {
                        if (None$.MODULE$.equals((Object)var70_86) == false) throw new MatchError((Object)var70_86);
                        this.$outer.logWarning((Function0<String>)new Serializable(this, appId){
                            public static final long serialVersionUID = 0L;
                            private final String appId$2;

                            public final String apply() {
                                return new StringBuilder().append((Object)"Master change ack from unknown app: ").append((Object)this.appId$2).toString();
                            }
                            {
                                this.appId$2 = appId$2;
                            }
                        });
                        var73_90 = BoxedUnit.UNIT;
                    }
                    if (this.$outer.org$apache$spark$deploy$master$Master$$canCompleteRecovery()) {
                        this.$outer.org$apache$spark$deploy$master$Master$$completeRecovery();
                        v16 = BoxedUnit.UNIT;
                    } else {
                        v16 = BoxedUnit.UNIT;
                    }
                    var4_22 = v16;
                    return var4_28;
                }
                if (var3_3 instanceof org.apache.spark.deploy.DeployMessages$WorkerSchedulerStateResponse) {
                    var74_91 = (org.apache.spark.deploy.DeployMessages$WorkerSchedulerStateResponse)var3_3;
                    workerId = var74_91.id();
                    executors = var74_91.executors();
                    driverIds = var74_91.driverIds();
                    var78_95 = this.$outer.org$apache$spark$deploy$master$Master$$idToWorker().get((Object)workerId);
                    if (var78_95 instanceof Some) {
                        var79_96 = (Some)var78_95;
                        worker = (WorkerInfo)var79_96.x();
                        this.$outer.logInfo((Function0<String>)new Serializable(this, workerId){
                            public static final long serialVersionUID = 0L;
                            private final String workerId$2;

                            public final String apply() {
                                return new StringBuilder().append((Object)"Worker has been re-registered: ").append((Object)this.workerId$2).toString();
                            }
                            {
                                this.workerId$2 = workerId$2;
                            }
                        });
                        worker.state_$eq(WorkerState$.MODULE$.ALIVE());
                        validExecutors = (List)executors.filter((Function1)new Serializable(this){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anonfun$receive$1 $outer;

                            public final boolean apply(org.apache.spark.deploy.ExecutorDescription exec) {
                                return this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().idToApp().get((Object)exec.appId()).isDefined();
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                            }
                        });
                        validExecutors.foreach((Function1)new Serializable(this, worker){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anonfun$receive$1 $outer;
                            private final WorkerInfo worker$2;

                            public final void apply(org.apache.spark.deploy.ExecutorDescription exec) {
                                ApplicationInfo app = (ApplicationInfo)this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().idToApp().get((Object)exec.appId()).get();
                                ExecutorDesc execInfo = app.addExecutor(this.worker$2, exec.cores(), (Option<Object>)new Some((Object)BoxesRunTime.boxToInteger((int)exec.execId())));
                                this.worker$2.addExecutor(execInfo);
                                execInfo.copyState(exec);
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.worker$2 = worker$2;
                            }
                        });
                        driverIds.foreach((Function1)new Serializable(this, worker){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anonfun$receive$1 $outer;
                            public final WorkerInfo worker$2;

                            public final void apply(String driverId) {
                                this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().org$apache$spark$deploy$master$Master$$drivers().find((Function1)new Serializable(this, driverId){
                                    public static final long serialVersionUID = 0L;
                                    private final String driverId$4;

                                    /*
                                     * Enabled force condition propagation
                                     * Lifted jumps to return sites
                                     */
                                    public final boolean apply(DriverInfo x$7) {
                                        String string = this.driverId$4;
                                        if (x$7.id() != null) {
                                            String string2;
                                            if (!string2.equals(string)) return false;
                                            return true;
                                        }
                                        if (string == null) return true;
                                        return false;
                                    }
                                    {
                                        this.driverId$4 = driverId$4;
                                    }
                                }).foreach((Function1)new Serializable(this){
                                    public static final long serialVersionUID = 0L;
                                    private final /* synthetic */ org.apache.spark.deploy.master.Master$$anonfun$receive$1$$anonfun$applyOrElse$19 $outer;

                                    public final void apply(DriverInfo driver) {
                                        driver.worker_$eq((Option<WorkerInfo>)new Some((Object)this.$outer.worker$2));
                                        driver.state_$eq(DriverState$.MODULE$.RUNNING());
                                        this.$outer.worker$2.addDriver(driver);
                                    }
                                    {
                                        if ($outer == null) {
                                            throw null;
                                        }
                                        this.$outer = $outer;
                                    }
                                });
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.worker$2 = worker$2;
                            }
                        });
                        var81_99 = BoxedUnit.UNIT;
                    } else {
                        if (None$.MODULE$.equals((Object)var78_95) == false) throw new MatchError((Object)var78_95);
                        this.$outer.logWarning((Function0<String>)new Serializable(this, workerId){
                            public static final long serialVersionUID = 0L;
                            private final String workerId$2;

                            public final String apply() {
                                return new StringBuilder().append((Object)"Scheduler state from unknown worker: ").append((Object)this.workerId$2).toString();
                            }
                            {
                                this.workerId$2 = workerId$2;
                            }
                        });
                        var81_100 = BoxedUnit.UNIT;
                    }
                    if (this.$outer.org$apache$spark$deploy$master$Master$$canCompleteRecovery()) {
                        this.$outer.org$apache$spark$deploy$master$Master$$completeRecovery();
                        v17 = BoxedUnit.UNIT;
                    } else {
                        v17 = BoxedUnit.UNIT;
                    }
                    var4_23 = v17;
                    return var4_28;
                }
                if (var3_3 instanceof org.apache.spark.deploy.DeployMessages$WorkerLatestState) {
                    var83_101 = (org.apache.spark.deploy.DeployMessages$WorkerLatestState)var3_3;
                    workerId = var83_101.id();
                    executors = var83_101.executors();
                    driverIds = var83_101.driverIds();
                    var87_105 = this.$outer.org$apache$spark$deploy$master$Master$$idToWorker().get((Object)workerId);
                    if (var87_105 instanceof Some) {
                        var88_106 = (Some)var87_105;
                        worker = (WorkerInfo)var88_106.x();
                        executors.foreach((Function1)new Serializable(this, worker){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ $anonfun$receive$1 $outer;
                            private final WorkerInfo worker$3;

                            public final void apply(org.apache.spark.deploy.ExecutorDescription exec) {
                                boolean executorMatches = this.worker$3.executors().exists((Function1)new Serializable(this, exec){
                                    public static final long serialVersionUID = 0L;
                                    private final org.apache.spark.deploy.ExecutorDescription exec$3;

                                    /*
                                     * Enabled force condition propagation
                                     * Lifted jumps to return sites
                                     */
                                    public final boolean apply(Tuple2<String, ExecutorDesc> x0$1) {
                                        String string;
                                        Tuple2<String, ExecutorDesc> tuple2 = x0$1;
                                        if (tuple2 == null) throw new MatchError(tuple2);
                                        ExecutorDesc e = (ExecutorDesc)tuple2._2();
                                        String string2 = this.exec$3.appId();
                                        if (e.application().id() == null) {
                                            if (string2 != null) {
                                                return false;
                                            }
                                        } else if (!string.equals(string2)) return false;
                                        if (e.id() != this.exec$3.execId()) return false;
                                        return true;
                                    }
                                    {
                                        this.exec$3 = exec$3;
                                    }
                                });
                                if (!executorMatches) {
                                    this.worker$3.endpoint().send(new DeployMessages.KillExecutor(this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().org$apache$spark$deploy$master$Master$$masterUrl(), exec.appId(), exec.execId()));
                                }
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.worker$3 = worker$3;
                            }
                        });
                        driverIds.foreach((Function1)new Serializable(this, worker){
                            public static final long serialVersionUID = 0L;
                            private final WorkerInfo worker$3;

                            public final void apply(String driverId) {
                                boolean driverMatches = this.worker$3.drivers().exists((Function1)new Serializable(this, driverId){
                                    public static final long serialVersionUID = 0L;
                                    private final String driverId$5;

                                    /*
                                     * Enabled force condition propagation
                                     * Lifted jumps to return sites
                                     */
                                    public final boolean apply(Tuple2<String, DriverInfo> x0$2) {
                                        Tuple2<String, DriverInfo> tuple2 = x0$2;
                                        if (tuple2 == null) throw new MatchError(tuple2);
                                        String string = this.driverId$5;
                                        String id = (String)tuple2._1();
                                        if (id != null) {
                                            String string2;
                                            if (!string2.equals(string)) return false;
                                            return true;
                                        }
                                        if (string == null) return true;
                                        return false;
                                    }
                                    {
                                        this.driverId$5 = driverId$5;
                                    }
                                });
                                if (!driverMatches) {
                                    this.worker$3.endpoint().send(new org.apache.spark.deploy.DeployMessages$KillDriver(driverId));
                                }
                            }
                            {
                                this.worker$3 = worker$3;
                            }
                        });
                        var90_108 = BoxedUnit.UNIT;
                    } else {
                        if (None$.MODULE$.equals((Object)var87_105) == false) throw new MatchError((Object)var87_105);
                        this.$outer.logWarning((Function0<String>)new Serializable(this, workerId){
                            public static final long serialVersionUID = 0L;
                            private final String workerId$3;

                            public final String apply() {
                                return new StringBuilder().append((Object)"Worker state from unknown worker: ").append((Object)this.workerId$3).toString();
                            }
                            {
                                this.workerId$3 = workerId$3;
                            }
                        });
                        var90_109 = BoxedUnit.UNIT;
                    }
                    var4_24 = BoxedUnit.UNIT;
                    return var4_28;
                }
                if (var3_3 instanceof org.apache.spark.deploy.DeployMessages$UnregisterApplication) {
                    var91_110 = (org.apache.spark.deploy.DeployMessages$UnregisterApplication)var3_3;
                    applicationId = var91_110.appId();
                    this.$outer.logInfo((Function0<String>)new Serializable(this, applicationId){
                        public static final long serialVersionUID = 0L;
                        private final String applicationId$1;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Received unregister request from application ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.applicationId$1}));
                        }
                        {
                            this.applicationId$1 = applicationId$1;
                        }
                    });
                    this.$outer.idToApp().get((Object)applicationId).foreach((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ $anonfun$receive$1 $outer;

                        public final void apply(ApplicationInfo app) {
                            this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().org$apache$spark$deploy$master$Master$$finishApplication(app);
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    });
                    var4_25 = BoxedUnit.UNIT;
                    return var4_28;
                }
                if (org.apache.spark.deploy.master.MasterMessages$CheckForWorkerTimeOut$.MODULE$.equals(var3_3)) {
                    this.$outer.org$apache$spark$deploy$master$Master$$timeOutDeadWorkers();
                    var4_26 = BoxedUnit.UNIT;
                    return var4_28;
                }
                var4_27 = default.apply(x1);
                return var4_28;
            }

            public final boolean isDefinedAt(Object x1) {
                Object object = x1;
                boolean bl = MasterMessages$ElectedLeader$.MODULE$.equals(object) ? true : (org.apache.spark.deploy.master.MasterMessages$CompleteRecovery$.MODULE$.equals(object) ? true : (MasterMessages$RevokedLeadership$.MODULE$.equals(object) ? true : (object instanceof org.apache.spark.deploy.DeployMessages$RegisterWorker ? true : (object instanceof org.apache.spark.deploy.DeployMessages$RegisterApplication ? true : (object instanceof org.apache.spark.deploy.DeployMessages$ExecutorStateChanged ? true : (object instanceof org.apache.spark.deploy.DeployMessages$DriverStateChanged ? true : (object instanceof org.apache.spark.deploy.DeployMessages$Heartbeat ? true : (object instanceof org.apache.spark.deploy.DeployMessages$MasterChangeAcknowledged ? true : (object instanceof org.apache.spark.deploy.DeployMessages$WorkerSchedulerStateResponse ? true : (object instanceof org.apache.spark.deploy.DeployMessages$WorkerLatestState ? true : (object instanceof org.apache.spark.deploy.DeployMessages$UnregisterApplication ? true : org.apache.spark.deploy.master.MasterMessages$CheckForWorkerTimeOut$.MODULE$.equals(object))))))))))));
                return bl;
            }

            public /* synthetic */ Master org$apache$spark$deploy$master$Master$$anonfun$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        };
    }

    @Override
    public PartialFunction<Object, BoxedUnit> receiveAndReply(RpcCallContext context) {
        return new Serializable(this, context){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;
            private final RpcCallContext context$1;

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public final <A1, B1> B1 applyOrElse(A1 x2, Function1<A1, B1> default) {
                block20 : {
                    block21 : {
                        block18 : {
                            block19 : {
                                block16 : {
                                    block17 : {
                                        var3_3 = x2;
                                        if (!(var3_3 instanceof org.apache.spark.deploy.DeployMessages$RequestSubmitDriver)) break block16;
                                        var4_4 = (org.apache.spark.deploy.DeployMessages$RequestSubmitDriver)var3_3;
                                        description = var4_4.driverDescription();
                                        var7_6 = RecoveryState$.MODULE$.ALIVE();
                                        if (this.$outer.org$apache$spark$deploy$master$Master$$state() != null) break block17;
                                        if (var7_6 == null) ** GOTO lbl-1000
                                        ** GOTO lbl-1000
                                    }
                                    if (v0.equals((Object)var7_6)) lbl-1000: // 2 sources:
                                    {
                                        this.$outer.logInfo((Function0<String>)new Serializable(this, description){
                                            public static final long serialVersionUID = 0L;
                                            private final DriverDescription description$2;

                                            public final String apply() {
                                                return new StringBuilder().append((Object)"Driver submitted ").append((Object)this.description$2.command().mainClass()).toString();
                                            }
                                            {
                                                this.description$2 = description$2;
                                            }
                                        });
                                        driver = this.$outer.org$apache$spark$deploy$master$Master$$createDriver(description);
                                        this.$outer.org$apache$spark$deploy$master$Master$$persistenceEngine().addDriver(driver);
                                        this.$outer.org$apache$spark$deploy$master$Master$$waitingDrivers().$plus$eq((Object)driver);
                                        this.$outer.org$apache$spark$deploy$master$Master$$drivers().add((Object)driver);
                                        this.$outer.org$apache$spark$deploy$master$Master$$schedule();
                                        this.context$1.reply(new org.apache.spark.deploy.DeployMessages$SubmitDriverResponse(this.$outer.self(), true, (Option<String>)new Some((Object)driver.id()), new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Driver successfully submitted as ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{driver.id()}))));
                                        v1 = BoxedUnit.UNIT;
                                    } else lbl-1000: // 2 sources:
                                    {
                                        msg = new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", ": ", ". "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{Utils$.MODULE$.BACKUP_STANDALONE_MASTER_PREFIX(), this.$outer.org$apache$spark$deploy$master$Master$$state()}))).append((Object)"Can only accept driver submissions in ALIVE state.").toString();
                                        this.context$1.reply(new org.apache.spark.deploy.DeployMessages$SubmitDriverResponse(this.$outer.self(), false, (Option<String>)None$.MODULE$, msg));
                                        v1 = BoxedUnit.UNIT;
                                    }
                                    var6_9 = v1;
                                    return (B1)var6_9;
                                }
                                if (!(var3_3 instanceof org.apache.spark.deploy.DeployMessages$RequestKillDriver)) break block18;
                                var10_10 = (org.apache.spark.deploy.DeployMessages$RequestKillDriver)var3_3;
                                driverId = var10_10.driverId();
                                var12_12 = RecoveryState$.MODULE$.ALIVE();
                                if (this.$outer.org$apache$spark$deploy$master$Master$$state() != null) break block19;
                                if (var12_12 == null) ** GOTO lbl-1000
                                ** GOTO lbl-1000
                            }
                            if (v2.equals((Object)var12_12)) lbl-1000: // 2 sources:
                            {
                                this.$outer.logInfo((Function0<String>)new Serializable(this, driverId){
                                    public static final long serialVersionUID = 0L;
                                    private final String driverId$2;

                                    public final String apply() {
                                        return new StringBuilder().append((Object)"Asked to kill driver ").append((Object)this.driverId$2).toString();
                                    }
                                    {
                                        this.driverId$2 = driverId$2;
                                    }
                                });
                                var15_14 = driver = this.$outer.org$apache$spark$deploy$master$Master$$drivers().find((Function1)new Serializable(this, driverId){
                                    public static final long serialVersionUID = 0L;
                                    private final String driverId$2;

                                    /*
                                     * Enabled force condition propagation
                                     * Lifted jumps to return sites
                                     */
                                    public final boolean apply(DriverInfo x$8) {
                                        String string = this.driverId$2;
                                        if (x$8.id() != null) {
                                            String string2;
                                            if (!string2.equals(string)) return false;
                                            return true;
                                        }
                                        if (string == null) return true;
                                        return false;
                                    }
                                    {
                                        this.driverId$2 = driverId$2;
                                    }
                                });
                                if (var15_14 instanceof Some) {
                                    var16_15 = (Some)var15_14;
                                    d = (DriverInfo)var16_15.x();
                                    if (this.$outer.org$apache$spark$deploy$master$Master$$waitingDrivers().contains((Object)d)) {
                                        this.$outer.org$apache$spark$deploy$master$Master$$waitingDrivers().$minus$eq((Object)d);
                                        this.$outer.self().send(new org.apache.spark.deploy.DeployMessages$DriverStateChanged(driverId, DriverState$.MODULE$.KILLED(), (Option<Exception>)None$.MODULE$));
                                    } else {
                                        d.worker().foreach((Function1)new Serializable(this, driverId){
                                            public static final long serialVersionUID = 0L;
                                            private final String driverId$2;

                                            public final void apply(WorkerInfo w) {
                                                w.endpoint().send(new org.apache.spark.deploy.DeployMessages$KillDriver(this.driverId$2));
                                            }
                                            {
                                                this.driverId$2 = driverId$2;
                                            }
                                        });
                                    }
                                    msg = new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Kill request for ", " submitted"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{driverId}));
                                    this.$outer.logInfo((Function0<String>)new Serializable(this, msg){
                                        public static final long serialVersionUID = 0L;
                                        private final String msg$1;

                                        public final String apply() {
                                            return this.msg$1;
                                        }
                                        {
                                            this.msg$1 = msg$1;
                                        }
                                    });
                                    this.context$1.reply(new org.apache.spark.deploy.DeployMessages$KillDriverResponse(this.$outer.self(), driverId, true, msg));
                                    var18_18 = BoxedUnit.UNIT;
                                } else {
                                    if (None$.MODULE$.equals((Object)var15_14) == false) throw new MatchError((Object)var15_14);
                                    msg = new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Driver ", " has already finished or does not exist"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{driverId}));
                                    this.$outer.logWarning((Function0<String>)new Serializable(this, msg){
                                        public static final long serialVersionUID = 0L;
                                        private final String msg$2;

                                        public final String apply() {
                                            return this.msg$2;
                                        }
                                        {
                                            this.msg$2 = msg$2;
                                        }
                                    });
                                    this.context$1.reply(new org.apache.spark.deploy.DeployMessages$KillDriverResponse(this.$outer.self(), driverId, false, msg));
                                    var18_19 = BoxedUnit.UNIT;
                                }
                                v3 = BoxedUnit.UNIT;
                            } else lbl-1000: // 2 sources:
                            {
                                msg = new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", ": ", ". "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{Utils$.MODULE$.BACKUP_STANDALONE_MASTER_PREFIX(), this.$outer.org$apache$spark$deploy$master$Master$$state()}))).append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Can only kill drivers in ALIVE state."})).s((Seq)scala.collection.immutable.Nil$.MODULE$)).toString();
                                this.context$1.reply(new org.apache.spark.deploy.DeployMessages$KillDriverResponse(this.$outer.self(), driverId, false, msg));
                                v3 = BoxedUnit.UNIT;
                            }
                            var6_9 = v3;
                            return (B1)var6_9;
                        }
                        if (!(var3_3 instanceof org.apache.spark.deploy.DeployMessages$RequestDriverStatus)) break block20;
                        var21_22 = (org.apache.spark.deploy.DeployMessages$RequestDriverStatus)var3_3;
                        driverId = var21_22.driverId();
                        var23_24 = RecoveryState$.MODULE$.ALIVE();
                        if (this.$outer.org$apache$spark$deploy$master$Master$$state() != null) break block21;
                        if (var23_24 == null) ** GOTO lbl-1000
                        ** GOTO lbl-1000
                    }
                    if (v4.equals((Object)var23_24)) lbl-1000: // 2 sources:
                    {
                        if ((var25_25 = this.$outer.org$apache$spark$deploy$master$Master$$drivers().$plus$plus(this.$outer.org$apache$spark$deploy$master$Master$$completedDrivers()).find((Function1)new Serializable(this, driverId){
                            public static final long serialVersionUID = 0L;
                            private final String driverId$3;

                            /*
                             * Enabled force condition propagation
                             * Lifted jumps to return sites
                             */
                            public final boolean apply(DriverInfo x$9) {
                                String string = this.driverId$3;
                                if (x$9.id() != null) {
                                    String string2;
                                    if (!string2.equals(string)) return false;
                                    return true;
                                }
                                if (string == null) return true;
                                return false;
                            }
                            {
                                this.driverId$3 = driverId$3;
                            }
                        })) instanceof Some) {
                            var26_26 = (Some)var25_25;
                            driver = (DriverInfo)var26_26.x();
                            this.context$1.reply(new org.apache.spark.deploy.DeployMessages$DriverStatusResponse(true, (Option<Enumeration.Value>)new Some((Object)driver.state()), (Option<String>)driver.worker().map((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;

                                public final String apply(WorkerInfo x$10) {
                                    return x$10.id();
                                }
                            }), (Option<String>)driver.worker().map((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;

                                public final String apply(WorkerInfo x$11) {
                                    return x$11.hostPort();
                                }
                            }), driver.exception()));
                            var28_28 = BoxedUnit.UNIT;
                        } else {
                            if (None$.MODULE$.equals((Object)var25_25) == false) throw new MatchError((Object)var25_25);
                            this.context$1.reply(new org.apache.spark.deploy.DeployMessages$DriverStatusResponse(false, (Option<Enumeration.Value>)None$.MODULE$, (Option<String>)None$.MODULE$, (Option<String>)None$.MODULE$, (Option<Exception>)None$.MODULE$));
                            var28_29 = BoxedUnit.UNIT;
                        }
                        v5 = BoxedUnit.UNIT;
                    } else lbl-1000: // 2 sources:
                    {
                        msg = new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", ": ", ". "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{Utils$.MODULE$.BACKUP_STANDALONE_MASTER_PREFIX(), this.$outer.org$apache$spark$deploy$master$Master$$state()}))).append((Object)"Can only request driver status in ALIVE state.").toString();
                        this.context$1.reply(new org.apache.spark.deploy.DeployMessages$DriverStatusResponse(false, (Option<Enumeration.Value>)None$.MODULE$, (Option<String>)None$.MODULE$, (Option<String>)None$.MODULE$, (Option<Exception>)new Some((Object)new Exception(msg))));
                        v5 = BoxedUnit.UNIT;
                    }
                    var6_9 = v5;
                    return (B1)var6_9;
                }
                if (org.apache.spark.deploy.DeployMessages$RequestMasterState$.MODULE$.equals(var3_3)) {
                    this.context$1.reply(new org.apache.spark.deploy.DeployMessages$MasterStateResponse(this.$outer.org$apache$spark$deploy$master$Master$$address.host(), this.$outer.org$apache$spark$deploy$master$Master$$address.port(), this.$outer.org$apache$spark$deploy$master$Master$$restServerBoundPort(), (WorkerInfo[])this.$outer.workers().toArray(ClassTag$.MODULE$.apply(WorkerInfo.class)), (ApplicationInfo[])this.$outer.apps().toArray(ClassTag$.MODULE$.apply(ApplicationInfo.class)), (ApplicationInfo[])this.$outer.org$apache$spark$deploy$master$Master$$completedApps().toArray(ClassTag$.MODULE$.apply(ApplicationInfo.class)), (DriverInfo[])this.$outer.org$apache$spark$deploy$master$Master$$drivers().toArray(ClassTag$.MODULE$.apply(DriverInfo.class)), (DriverInfo[])this.$outer.org$apache$spark$deploy$master$Master$$completedDrivers().toArray(ClassTag$.MODULE$.apply(DriverInfo.class)), this.$outer.org$apache$spark$deploy$master$Master$$state()));
                    var6_9 = BoxedUnit.UNIT;
                    return (B1)var6_9;
                }
                if (org.apache.spark.deploy.master.MasterMessages$BoundPortsRequest$.MODULE$.equals(var3_3)) {
                    this.context$1.reply(new org.apache.spark.deploy.master.MasterMessages$BoundPortsResponse(this.$outer.org$apache$spark$deploy$master$Master$$address.port(), this.$outer.org$apache$spark$deploy$master$Master$$webUi().boundPort(), this.$outer.org$apache$spark$deploy$master$Master$$restServerBoundPort()));
                    var6_9 = BoxedUnit.UNIT;
                    return (B1)var6_9;
                }
                if (var3_3 instanceof org.apache.spark.deploy.DeployMessages$RequestExecutors) {
                    var29_31 = (org.apache.spark.deploy.DeployMessages$RequestExecutors)var3_3;
                    appId = var29_31.appId();
                    requestedTotal = var29_31.requestedTotal();
                    this.context$1.reply(BoxesRunTime.boxToBoolean((boolean)this.$outer.org$apache$spark$deploy$master$Master$$handleRequestExecutors(appId, requestedTotal)));
                    var6_9 = BoxedUnit.UNIT;
                    return (B1)var6_9;
                }
                if (var3_3 instanceof org.apache.spark.deploy.DeployMessages$KillExecutors) {
                    var32_34 = (org.apache.spark.deploy.DeployMessages$KillExecutors)var3_3;
                    appId = var32_34.appId();
                    executorIds = var32_34.executorIds();
                    formattedExecutorIds = this.$outer.org$apache$spark$deploy$master$Master$$formatExecutorIds(executorIds);
                    this.context$1.reply(BoxesRunTime.boxToBoolean((boolean)this.$outer.org$apache$spark$deploy$master$Master$$handleKillExecutors(appId, formattedExecutorIds)));
                    var6_9 = BoxedUnit.UNIT;
                    return (B1)var6_9;
                }
                var6_9 = default.apply(x2);
                return (B1)var6_9;
            }

            public final boolean isDefinedAt(Object x2) {
                Object object = x2;
                boolean bl = object instanceof org.apache.spark.deploy.DeployMessages$RequestSubmitDriver ? true : (object instanceof org.apache.spark.deploy.DeployMessages$RequestKillDriver ? true : (object instanceof org.apache.spark.deploy.DeployMessages$RequestDriverStatus ? true : (org.apache.spark.deploy.DeployMessages$RequestMasterState$.MODULE$.equals(object) ? true : (org.apache.spark.deploy.master.MasterMessages$BoundPortsRequest$.MODULE$.equals(object) ? true : (object instanceof org.apache.spark.deploy.DeployMessages$RequestExecutors ? true : object instanceof org.apache.spark.deploy.DeployMessages$KillExecutors)))));
                return bl;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.context$1 = context$1;
            }
        };
    }

    @Override
    public void onDisconnected(RpcAddress address) {
        block6 : {
            block5 : {
                Enumeration.Value value2;
                Enumeration.Value value3;
                block4 : {
                    this.logInfo((Function0<String>)new Serializable(this, address){
                        public static final long serialVersionUID = 0L;
                        private final RpcAddress address$1;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " got disassociated, removing it."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.address$1}));
                        }
                        {
                            this.address$1 = address$1;
                        }
                    });
                    this.addressToWorker().get((Object)address).foreach((Function1)new Serializable(this, address){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ Master $outer;
                        private final RpcAddress address$1;

                        public final void apply(WorkerInfo x$12) {
                            this.$outer.org$apache$spark$deploy$master$Master$$removeWorker(x$12, new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"", " got disassociated"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.address$1})));
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.address$1 = address$1;
                        }
                    });
                    this.addressToApp().get((Object)address).foreach((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ Master $outer;

                        public final void apply(ApplicationInfo app) {
                            this.$outer.org$apache$spark$deploy$master$Master$$finishApplication(app);
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    });
                    value3 = RecoveryState$.MODULE$.RECOVERING();
                    if (this.org$apache$spark$deploy$master$Master$$state() != null) break block4;
                    if (value3 == null) break block5;
                    break block6;
                }
                if (!value2.equals((Object)value3)) break block6;
            }
            if (this.org$apache$spark$deploy$master$Master$$canCompleteRecovery()) {
                this.org$apache$spark$deploy$master$Master$$completeRecovery();
            }
        }
    }

    public boolean org$apache$spark$deploy$master$Master$$canCompleteRecovery() {
        return this.workers().count((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(WorkerInfo x$13) {
                Enumeration.Value value2 = WorkerState$.MODULE$.UNKNOWN();
                if (x$13.state() != null) {
                    Enumeration.Value value3;
                    if (!value3.equals((Object)value2)) return false;
                    return true;
                }
                if (value2 == null) return true;
                return false;
            }
        }) == 0 && this.apps().count((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final boolean apply(ApplicationInfo x$14) {
                Enumeration.Value value2 = ApplicationState$.MODULE$.UNKNOWN();
                if (x$14.state() != null) {
                    Enumeration.Value value3;
                    if (!value3.equals((Object)value2)) return false;
                    return true;
                }
                if (value2 == null) return true;
                return false;
            }
        }) == 0;
    }

    public void org$apache$spark$deploy$master$Master$$beginRecovery(Seq<ApplicationInfo> storedApps, Seq<DriverInfo> storedDrivers, Seq<WorkerInfo> storedWorkers) {
        storedApps.foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final void apply(ApplicationInfo app) {
                this.$outer.logInfo((Function0<String>)new Serializable(this, app){
                    public static final long serialVersionUID = 0L;
                    private final ApplicationInfo app$5;

                    public final String apply() {
                        return new StringBuilder().append((Object)"Trying to recover app: ").append((Object)this.app$5.id()).toString();
                    }
                    {
                        this.app$5 = app$5;
                    }
                });
                try {
                    this.$outer.org$apache$spark$deploy$master$Master$$registerApplication(app);
                    app.state_$eq(ApplicationState$.MODULE$.UNKNOWN());
                    app.driver().send(new org.apache.spark.deploy.DeployMessages$MasterChanged(this.$outer.self(), this.$outer.org$apache$spark$deploy$master$Master$$masterWebUiUrl()));
                }
                catch (Exception exception2) {
                    this.$outer.logInfo((Function0<String>)new Serializable(this, app){
                        public static final long serialVersionUID = 0L;
                        private final ApplicationInfo app$5;

                        public final String apply() {
                            return new StringBuilder().append((Object)"App ").append((Object)this.app$5.id()).append((Object)" had exception on reconnect").toString();
                        }
                        {
                            this.app$5 = app$5;
                        }
                    });
                }
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        storedDrivers.foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final HashSet<DriverInfo> apply(DriverInfo driver) {
                return this.$outer.org$apache$spark$deploy$master$Master$$drivers().$plus$eq((Object)driver);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        storedWorkers.foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final void apply(WorkerInfo worker) {
                this.$outer.logInfo((Function0<String>)new Serializable(this, worker){
                    public static final long serialVersionUID = 0L;
                    private final WorkerInfo worker$8;

                    public final String apply() {
                        return new StringBuilder().append((Object)"Trying to recover worker: ").append((Object)this.worker$8.id()).toString();
                    }
                    {
                        this.worker$8 = worker$8;
                    }
                });
                try {
                    this.$outer.org$apache$spark$deploy$master$Master$$registerWorker(worker);
                    worker.state_$eq(WorkerState$.MODULE$.UNKNOWN());
                    worker.endpoint().send(new org.apache.spark.deploy.DeployMessages$MasterChanged(this.$outer.self(), this.$outer.org$apache$spark$deploy$master$Master$$masterWebUiUrl()));
                }
                catch (Exception exception2) {
                    this.$outer.logInfo((Function0<String>)new Serializable(this, worker){
                        public static final long serialVersionUID = 0L;
                        private final WorkerInfo worker$8;

                        public final String apply() {
                            return new StringBuilder().append((Object)"Worker ").append((Object)this.worker$8.id()).append((Object)" had exception on reconnect").toString();
                        }
                        {
                            this.worker$8 = worker$8;
                        }
                    });
                }
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
    }

    public void org$apache$spark$deploy$master$Master$$completeRecovery() {
        block4 : {
            block3 : {
                Enumeration.Value value2;
                Enumeration.Value value3;
                block2 : {
                    value3 = RecoveryState$.MODULE$.RECOVERING();
                    if (this.org$apache$spark$deploy$master$Master$$state() != null) break block2;
                    if (value3 == null) break block3;
                    break block4;
                }
                if (!value2.equals((Object)value3)) break block4;
            }
            this.org$apache$spark$deploy$master$Master$$state_$eq(RecoveryState$.MODULE$.COMPLETING_RECOVERY());
            ((HashSet)this.workers().filter((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final boolean apply(WorkerInfo x$15) {
                    Enumeration.Value value2 = WorkerState$.MODULE$.UNKNOWN();
                    if (x$15.state() != null) {
                        Enumeration.Value value3;
                        if (!value3.equals((Object)value2)) return false;
                        return true;
                    }
                    if (value2 == null) return true;
                    return false;
                }
            })).foreach((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ Master $outer;

                public final void apply(WorkerInfo x$16) {
                    this.$outer.org$apache$spark$deploy$master$Master$$removeWorker(x$16, "Not responding for recovery");
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            });
            ((HashSet)this.apps().filter((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final boolean apply(ApplicationInfo x$17) {
                    Enumeration.Value value2 = ApplicationState$.MODULE$.UNKNOWN();
                    if (x$17.state() != null) {
                        Enumeration.Value value3;
                        if (!value3.equals((Object)value2)) return false;
                        return true;
                    }
                    if (value2 == null) return true;
                    return false;
                }
            })).foreach((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ Master $outer;

                public final void apply(ApplicationInfo app) {
                    this.$outer.org$apache$spark$deploy$master$Master$$finishApplication(app);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            });
            ((HashSet)this.apps().filter((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final boolean apply(ApplicationInfo x$18) {
                    Enumeration.Value value2 = ApplicationState$.MODULE$.WAITING();
                    if (x$18.state() != null) {
                        Enumeration.Value value3;
                        if (!value3.equals((Object)value2)) return false;
                        return true;
                    }
                    if (value2 == null) return true;
                    return false;
                }
            })).foreach((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final void apply(ApplicationInfo x$19) {
                    x$19.state_$eq(ApplicationState$.MODULE$.RUNNING());
                }
            });
            ((HashSet)this.org$apache$spark$deploy$master$Master$$drivers().filter((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final boolean apply(DriverInfo x$20) {
                    return x$20.worker().isEmpty();
                }
            })).foreach((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ Master $outer;

                public final void apply(DriverInfo d) {
                    this.$outer.logWarning((Function0<String>)new Serializable(this, d){
                        public static final long serialVersionUID = 0L;
                        private final DriverInfo d$1;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Driver ", " was not found after master recovery"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.d$1.id()}));
                        }
                        {
                            this.d$1 = d$1;
                        }
                    });
                    if (d.desc().supervise()) {
                        this.$outer.logWarning((Function0<String>)new Serializable(this, d){
                            public static final long serialVersionUID = 0L;
                            private final DriverInfo d$1;

                            public final String apply() {
                                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Re-launching ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.d$1.id()}));
                            }
                            {
                                this.d$1 = d$1;
                            }
                        });
                        this.$outer.org$apache$spark$deploy$master$Master$$relaunchDriver(d);
                    } else {
                        this.$outer.org$apache$spark$deploy$master$Master$$removeDriver(d.id(), DriverState$.MODULE$.ERROR(), (Option<Exception>)None$.MODULE$);
                        this.$outer.logWarning((Function0<String>)new Serializable(this, d){
                            public static final long serialVersionUID = 0L;
                            private final DriverInfo d$1;

                            public final String apply() {
                                return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Did not re-launch ", " because it was not supervised"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.d$1.id()}));
                            }
                            {
                                this.d$1 = d$1;
                            }
                        });
                    }
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                }
            });
            this.org$apache$spark$deploy$master$Master$$state_$eq(RecoveryState$.MODULE$.ALIVE());
            this.org$apache$spark$deploy$master$Master$$schedule();
            this.logInfo((Function0<String>)new Serializable(this){
                public static final long serialVersionUID = 0L;

                public final String apply() {
                    return "Recovery complete - resuming operations!";
                }
            });
            return;
        }
    }

    public int[] org$apache$spark$deploy$master$Master$$scheduleExecutorsOnWorkers(ApplicationInfo app, WorkerInfo[] usableWorkers, boolean spreadOutApps) {
        Option<Object> coresPerExecutor = app.desc().coresPerExecutor();
        int minCoresPerExecutor = BoxesRunTime.unboxToInt((Object)coresPerExecutor.getOrElse((Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply() {
                return this.apply$mcI$sp();
            }

            public int apply$mcI$sp() {
                return 1;
            }
        }));
        boolean oneExecutorPerWorker = coresPerExecutor.isEmpty();
        int memoryPerExecutor = app.desc().memoryPerExecutorMB();
        int numUsable = usableWorkers.length;
        int[] assignedCores = new int[numUsable];
        int[] assignedExecutors = new int[numUsable];
        IntRef coresToAssign = IntRef.create((int)package$.MODULE$.min(app.coresLeft(), BoxesRunTime.unboxToInt((Object)Predef$.MODULE$.intArrayOps((int[])Predef$.MODULE$.refArrayOps((Object[])usableWorkers).map((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply(WorkerInfo x$21) {
                return x$21.coresFree();
            }
        }, Array$.MODULE$.canBuildFrom(ClassTag$.MODULE$.Int()))).sum((Numeric)Numeric.IntIsIntegral$.MODULE$))));
        IndexedSeq freeWorkers = (IndexedSeq)RichInt$.MODULE$.until$extension0(Predef$.MODULE$.intWrapper(0), numUsable).filter((Function1)new Serializable(this, app, usableWorkers, minCoresPerExecutor, oneExecutorPerWorker, memoryPerExecutor, assignedCores, assignedExecutors, coresToAssign){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;
            private final ApplicationInfo app$3;
            private final WorkerInfo[] usableWorkers$1;
            private final int minCoresPerExecutor$1;
            private final boolean oneExecutorPerWorker$1;
            private final int memoryPerExecutor$1;
            private final int[] assignedCores$1;
            private final int[] assignedExecutors$1;
            private final IntRef coresToAssign$1;

            public final boolean apply(int pos) {
                return this.apply$mcZI$sp(pos);
            }

            public boolean apply$mcZI$sp(int pos) {
                return this.$outer.org$apache$spark$deploy$master$Master$$canLaunchExecutor$1(pos, this.app$3, this.usableWorkers$1, this.minCoresPerExecutor$1, this.oneExecutorPerWorker$1, this.memoryPerExecutor$1, this.assignedCores$1, this.assignedExecutors$1, this.coresToAssign$1);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.app$3 = app$3;
                this.usableWorkers$1 = usableWorkers$1;
                this.minCoresPerExecutor$1 = minCoresPerExecutor$1;
                this.oneExecutorPerWorker$1 = oneExecutorPerWorker$1;
                this.memoryPerExecutor$1 = memoryPerExecutor$1;
                this.assignedCores$1 = assignedCores$1;
                this.assignedExecutors$1 = assignedExecutors$1;
                this.coresToAssign$1 = coresToAssign$1;
            }
        });
        while (freeWorkers.nonEmpty()) {
            freeWorkers.foreach((Function1)new Serializable(this, app, usableWorkers, spreadOutApps, minCoresPerExecutor, oneExecutorPerWorker, memoryPerExecutor, assignedCores, assignedExecutors, coresToAssign){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ Master $outer;
                private final ApplicationInfo app$3;
                private final WorkerInfo[] usableWorkers$1;
                private final boolean spreadOutApps$1;
                private final int minCoresPerExecutor$1;
                private final boolean oneExecutorPerWorker$1;
                private final int memoryPerExecutor$1;
                private final int[] assignedCores$1;
                private final int[] assignedExecutors$1;
                private final IntRef coresToAssign$1;

                public final void apply(int pos) {
                    this.apply$mcVI$sp(pos);
                }

                public void apply$mcVI$sp(int pos) {
                    boolean keepScheduling = true;
                    while (keepScheduling && this.$outer.org$apache$spark$deploy$master$Master$$canLaunchExecutor$1(pos, this.app$3, this.usableWorkers$1, this.minCoresPerExecutor$1, this.oneExecutorPerWorker$1, this.memoryPerExecutor$1, this.assignedCores$1, this.assignedExecutors$1, this.coresToAssign$1)) {
                        this.coresToAssign$1.elem -= this.minCoresPerExecutor$1;
                        this.assignedCores$1[pos] = this.assignedCores$1[pos] + this.minCoresPerExecutor$1;
                        this.assignedExecutors$1[pos] = this.oneExecutorPerWorker$1 ? 1 : this.assignedExecutors$1[pos] + 1;
                        if (!this.spreadOutApps$1) continue;
                        keepScheduling = false;
                    }
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.app$3 = app$3;
                    this.usableWorkers$1 = usableWorkers$1;
                    this.spreadOutApps$1 = spreadOutApps$1;
                    this.minCoresPerExecutor$1 = minCoresPerExecutor$1;
                    this.oneExecutorPerWorker$1 = oneExecutorPerWorker$1;
                    this.memoryPerExecutor$1 = memoryPerExecutor$1;
                    this.assignedCores$1 = assignedCores$1;
                    this.assignedExecutors$1 = assignedExecutors$1;
                    this.coresToAssign$1 = coresToAssign$1;
                }
            });
            freeWorkers = (IndexedSeq)freeWorkers.filter((Function1)new Serializable(this, app, usableWorkers, minCoresPerExecutor, oneExecutorPerWorker, memoryPerExecutor, assignedCores, assignedExecutors, coresToAssign){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ Master $outer;
                private final ApplicationInfo app$3;
                private final WorkerInfo[] usableWorkers$1;
                private final int minCoresPerExecutor$1;
                private final boolean oneExecutorPerWorker$1;
                private final int memoryPerExecutor$1;
                private final int[] assignedCores$1;
                private final int[] assignedExecutors$1;
                private final IntRef coresToAssign$1;

                public final boolean apply(int pos) {
                    return this.apply$mcZI$sp(pos);
                }

                public boolean apply$mcZI$sp(int pos) {
                    return this.$outer.org$apache$spark$deploy$master$Master$$canLaunchExecutor$1(pos, this.app$3, this.usableWorkers$1, this.minCoresPerExecutor$1, this.oneExecutorPerWorker$1, this.memoryPerExecutor$1, this.assignedCores$1, this.assignedExecutors$1, this.coresToAssign$1);
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.app$3 = app$3;
                    this.usableWorkers$1 = usableWorkers$1;
                    this.minCoresPerExecutor$1 = minCoresPerExecutor$1;
                    this.oneExecutorPerWorker$1 = oneExecutorPerWorker$1;
                    this.memoryPerExecutor$1 = memoryPerExecutor$1;
                    this.assignedCores$1 = assignedCores$1;
                    this.assignedExecutors$1 = assignedExecutors$1;
                    this.coresToAssign$1 = coresToAssign$1;
                }
            });
        }
        return assignedCores;
    }

    private void startExecutorsOnWorkers() {
        this.waitingApps().foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final void apply(ApplicationInfo app) {
                int coresPerExecutor = BoxesRunTime.unboxToInt((Object)app.desc().coresPerExecutor().getOrElse((Function0)new Serializable(this){
                    public static final long serialVersionUID = 0L;

                    public final int apply() {
                        return this.apply$mcI$sp();
                    }

                    public int apply$mcI$sp() {
                        return 1;
                    }
                }));
                if (app.coresLeft() >= coresPerExecutor) {
                    WorkerInfo[] usableWorkers = (WorkerInfo[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])Predef$.MODULE$.refArrayOps((Object[])this.$outer.workers().toArray(ClassTag$.MODULE$.apply(WorkerInfo.class))).filter((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        /*
                         * Enabled force condition propagation
                         * Lifted jumps to return sites
                         */
                        public final boolean apply(WorkerInfo x$22) {
                            Enumeration.Value value2 = WorkerState$.MODULE$.ALIVE();
                            if (x$22.state() != null) {
                                Enumeration.Value value3;
                                if (!value3.equals((Object)value2)) return false;
                                return true;
                            }
                            if (value2 == null) return true;
                            return false;
                        }
                    })).filter((Function1)new Serializable(this, coresPerExecutor, app){
                        public static final long serialVersionUID = 0L;
                        private final int coresPerExecutor$1;
                        private final ApplicationInfo app$6;

                        public final boolean apply(WorkerInfo worker) {
                            return worker.memoryFree() >= this.app$6.desc().memoryPerExecutorMB() && worker.coresFree() >= this.coresPerExecutor$1;
                        }
                        {
                            this.coresPerExecutor$1 = coresPerExecutor$1;
                            this.app$6 = app$6;
                        }
                    })).sortBy((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;

                        public final int apply(WorkerInfo x$23) {
                            return x$23.coresFree();
                        }
                    }, (scala.math.Ordering)scala.math.Ordering$Int$.MODULE$)).reverse();
                    int[] assignedCores = this.$outer.org$apache$spark$deploy$master$Master$$scheduleExecutorsOnWorkers(app, usableWorkers, this.$outer.org$apache$spark$deploy$master$Master$$spreadOutApps());
                    RichInt$.MODULE$.until$extension0(Predef$.MODULE$.intWrapper(0), usableWorkers.length).withFilter((Function1)new Serializable(this, assignedCores){
                        public static final long serialVersionUID = 0L;
                        private final int[] assignedCores$2;

                        public final boolean apply(int pos) {
                            return this.apply$mcZI$sp(pos);
                        }

                        public boolean apply$mcZI$sp(int pos) {
                            return this.assignedCores$2[pos] > 0;
                        }
                        {
                            this.assignedCores$2 = assignedCores$2;
                        }
                    }).foreach((Function1)new Serializable(this, usableWorkers, assignedCores, app){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ $anonfun$startExecutorsOnWorkers$1 $outer;
                        private final WorkerInfo[] usableWorkers$2;
                        private final int[] assignedCores$2;
                        private final ApplicationInfo app$6;

                        public final void apply(int pos) {
                            this.apply$mcVI$sp(pos);
                        }

                        public void apply$mcVI$sp(int pos) {
                            this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().org$apache$spark$deploy$master$Master$$allocateWorkerResourceToExecutors(this.app$6, this.assignedCores$2[pos], this.app$6.desc().coresPerExecutor(), this.usableWorkers$2[pos]);
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                            this.usableWorkers$2 = usableWorkers$2;
                            this.assignedCores$2 = assignedCores$2;
                            this.app$6 = app$6;
                        }
                    });
                }
            }

            public /* synthetic */ Master org$apache$spark$deploy$master$Master$$anonfun$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
    }

    public void org$apache$spark$deploy$master$Master$$allocateWorkerResourceToExecutors(ApplicationInfo app, int assignedCores, Option<Object> coresPerExecutor, WorkerInfo worker) {
        int numExecutors = BoxesRunTime.unboxToInt((Object)coresPerExecutor.map((Function1)new Serializable(this, assignedCores){
            public static final long serialVersionUID = 0L;
            private final int assignedCores$3;

            public final int apply(int x$24) {
                return this.apply$mcII$sp(x$24);
            }

            public int apply$mcII$sp(int x$24) {
                return this.assignedCores$3 / x$24;
            }
            {
                this.assignedCores$3 = assignedCores$3;
            }
        }).getOrElse((Function0)new Serializable(this){
            public static final long serialVersionUID = 0L;

            public final int apply() {
                return this.apply$mcI$sp();
            }

            public int apply$mcI$sp() {
                return 1;
            }
        }));
        int coresToAssign = BoxesRunTime.unboxToInt((Object)coresPerExecutor.getOrElse((Function0)new Serializable(this, assignedCores){
            public static final long serialVersionUID = 0L;
            private final int assignedCores$3;

            public final int apply() {
                return this.apply$mcI$sp();
            }

            public int apply$mcI$sp() {
                return this.assignedCores$3;
            }
            {
                this.assignedCores$3 = assignedCores$3;
            }
        }));
        RichInt$.MODULE$.to$extension0(Predef$.MODULE$.intWrapper(1), numExecutors).foreach$mVc$sp((Function1)new Serializable(this, app, worker, coresToAssign){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;
            private final ApplicationInfo app$4;
            private final WorkerInfo worker$5;
            private final int coresToAssign$2;

            public final void apply(int i) {
                this.apply$mcVI$sp(i);
            }

            public void apply$mcVI$sp(int i) {
                ExecutorDesc exec = this.app$4.addExecutor(this.worker$5, this.coresToAssign$2, this.app$4.addExecutor$default$3());
                this.$outer.org$apache$spark$deploy$master$Master$$launchExecutor(this.worker$5, exec);
                this.app$4.state_$eq(ApplicationState$.MODULE$.RUNNING());
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.app$4 = app$4;
                this.worker$5 = worker$5;
                this.coresToAssign$2 = coresToAssign$2;
            }
        });
    }

    public void org$apache$spark$deploy$master$Master$$schedule() {
        block4 : {
            block3 : {
                Enumeration.Value value2;
                Enumeration.Value value3;
                block2 : {
                    value3 = RecoveryState$.MODULE$.ALIVE();
                    if (this.org$apache$spark$deploy$master$Master$$state() != null) break block2;
                    if (value3 == null) break block3;
                    break block4;
                }
                if (!value2.equals((Object)value3)) break block4;
            }
            Seq shuffledAliveWorkers = (Seq)Random$.MODULE$.shuffle((TraversableOnce)this.workers().toSeq().filter((Function1)new Serializable(this){
                public static final long serialVersionUID = 0L;

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final boolean apply(WorkerInfo x$25) {
                    Enumeration.Value value2 = WorkerState$.MODULE$.ALIVE();
                    if (x$25.state() != null) {
                        Enumeration.Value value3;
                        if (!value3.equals((Object)value2)) return false;
                        return true;
                    }
                    if (value2 == null) return true;
                    return false;
                }
            }), Seq$.MODULE$.canBuildFrom());
            int numWorkersAlive = shuffledAliveWorkers.size();
            IntRef curPos = IntRef.create((int)0);
            this.org$apache$spark$deploy$master$Master$$waitingDrivers().toList().foreach((Function1)new Serializable(this, shuffledAliveWorkers, numWorkersAlive, curPos){
                public static final long serialVersionUID = 0L;
                private final /* synthetic */ Master $outer;
                private final Seq shuffledAliveWorkers$1;
                private final int numWorkersAlive$1;
                private final IntRef curPos$1;

                public final void apply(DriverInfo driver) {
                    boolean launched = false;
                    int numWorkersVisited = 0;
                    while (numWorkersVisited < this.numWorkersAlive$1 && !launched) {
                        WorkerInfo worker = (WorkerInfo)this.shuffledAliveWorkers$1.apply(this.curPos$1.elem);
                        ++numWorkersVisited;
                        if (worker.memoryFree() >= driver.desc().mem() && worker.coresFree() >= driver.desc().cores()) {
                            this.$outer.org$apache$spark$deploy$master$Master$$launchDriver(worker, driver);
                            this.$outer.org$apache$spark$deploy$master$Master$$waitingDrivers().$minus$eq((Object)driver);
                            launched = true;
                        }
                        this.curPos$1.elem = (this.curPos$1.elem + 1) % this.numWorkersAlive$1;
                    }
                }
                {
                    if ($outer == null) {
                        throw null;
                    }
                    this.$outer = $outer;
                    this.shuffledAliveWorkers$1 = shuffledAliveWorkers$1;
                    this.numWorkersAlive$1 = numWorkersAlive$1;
                    this.curPos$1 = curPos$1;
                }
            });
            this.startExecutorsOnWorkers();
            return;
        }
    }

    public void org$apache$spark$deploy$master$Master$$launchExecutor(WorkerInfo worker, ExecutorDesc exec) {
        this.logInfo((Function0<String>)new Serializable(this, worker, exec){
            public static final long serialVersionUID = 0L;
            private final WorkerInfo worker$6;
            private final ExecutorDesc exec$2;

            public final String apply() {
                return new StringBuilder().append((Object)"Launching executor ").append((Object)this.exec$2.fullId()).append((Object)" on worker ").append((Object)this.worker$6.id()).toString();
            }
            {
                this.worker$6 = worker$6;
                this.exec$2 = exec$2;
            }
        });
        worker.addExecutor(exec);
        worker.endpoint().send(new DeployMessages.LaunchExecutor(this.org$apache$spark$deploy$master$Master$$masterUrl(), exec.application().id(), exec.id(), exec.application().desc(), exec.cores(), exec.memory()));
        exec.application().driver().send(new DeployMessages.ExecutorAdded(exec.id(), worker.id(), worker.hostPort(), exec.cores(), exec.memory()));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean org$apache$spark$deploy$master$Master$$registerWorker(WorkerInfo worker) {
        block2 : {
            block4 : {
                block3 : {
                    ((HashSet)this.workers().filter((Function1)new Serializable(this, worker){
                        public static final long serialVersionUID = 0L;
                        private final WorkerInfo worker$1;

                        /*
                         * Enabled force condition propagation
                         * Lifted jumps to return sites
                         */
                        public final boolean apply(WorkerInfo w) {
                            String string;
                            String string2 = this.worker$1.host();
                            if (w.host() == null) {
                                if (string2 != null) {
                                    return false;
                                }
                            } else if (!string.equals(string2)) return false;
                            if (w.port() != this.worker$1.port()) return false;
                            Enumeration.Value value2 = WorkerState$.MODULE$.DEAD();
                            if (w.state() == null) {
                                if (value2 == null) return true;
                                return false;
                            } else {
                                Enumeration.Value value3;
                                if (!value3.equals((Object)value2)) return false;
                                return true;
                            }
                        }
                        {
                            this.worker$1 = worker$1;
                        }
                    })).foreach((Function1)new Serializable(this){
                        public static final long serialVersionUID = 0L;
                        private final /* synthetic */ Master $outer;

                        public final HashSet<WorkerInfo> apply(WorkerInfo w) {
                            return this.$outer.workers().$minus$eq((Object)w);
                        }
                        {
                            if ($outer == null) {
                                throw null;
                            }
                            this.$outer = $outer;
                        }
                    });
                    workerAddress = worker.endpoint().address();
                    if (!this.addressToWorker().contains((Object)workerAddress)) break block2;
                    oldWorker = (WorkerInfo)this.addressToWorker().apply((Object)workerAddress);
                    var4_4 = WorkerState$.MODULE$.UNKNOWN();
                    if (oldWorker.state() != null) break block3;
                    if (var4_4 == null) break block4;
                    ** GOTO lbl-1000
                }
                if (!v0.equals((Object)var4_4)) lbl-1000: // 2 sources:
                {
                    this.logInfo((Function0<String>)new Serializable(this, workerAddress){
                        public static final long serialVersionUID = 0L;
                        private final RpcAddress workerAddress$2;

                        public final String apply() {
                            return new StringBuilder().append((Object)"Attempted to re-register worker at same address: ").append((Object)this.workerAddress$2).toString();
                        }
                        {
                            this.workerAddress$2 = workerAddress$2;
                        }
                    });
                    return false;
                }
            }
            this.org$apache$spark$deploy$master$Master$$removeWorker(oldWorker, "Worker replaced by a new worker with same address");
        }
        this.workers().$plus$eq((Object)worker);
        this.org$apache$spark$deploy$master$Master$$idToWorker().update((Object)worker.id(), (Object)worker);
        this.addressToWorker().update((Object)workerAddress, (Object)worker);
        return true;
    }

    public void org$apache$spark$deploy$master$Master$$removeWorker(WorkerInfo worker, String msg) {
        this.logInfo((Function0<String>)new Serializable(this, worker){
            public static final long serialVersionUID = 0L;
            private final WorkerInfo worker$4;

            public final String apply() {
                return new StringBuilder().append((Object)"Removing worker ").append((Object)this.worker$4.id()).append((Object)" on ").append((Object)this.worker$4.host()).append((Object)":").append((Object)BoxesRunTime.boxToInteger((int)this.worker$4.port())).toString();
            }
            {
                this.worker$4 = worker$4;
            }
        });
        worker.setState(WorkerState$.MODULE$.DEAD());
        this.org$apache$spark$deploy$master$Master$$idToWorker().$minus$eq((Object)worker.id());
        this.addressToWorker().$minus$eq((Object)worker.endpoint().address());
        worker.executors().values().foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final void apply(ExecutorDesc exec) {
                this.$outer.logInfo((Function0<String>)new Serializable(this, exec){
                    public static final long serialVersionUID = 0L;
                    private final ExecutorDesc exec$4;

                    public final String apply() {
                        return new StringBuilder().append((Object)"Telling app of lost executor: ").append((Object)BoxesRunTime.boxToInteger((int)this.exec$4.id())).toString();
                    }
                    {
                        this.exec$4 = exec$4;
                    }
                });
                exec.application().driver().send(new org.apache.spark.deploy.DeployMessages$ExecutorUpdated(exec.id(), ExecutorState$.MODULE$.LOST(), (Option<String>)new Some((Object)"worker lost"), (Option<Object>)None$.MODULE$, true));
                exec.state_$eq(ExecutorState$.MODULE$.LOST());
                exec.application().removeExecutor(exec);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        worker.drivers().values().foreach((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final void apply(DriverInfo driver) {
                if (driver.desc().supervise()) {
                    this.$outer.logInfo((Function0<String>)new Serializable(this, driver){
                        public static final long serialVersionUID = 0L;
                        private final DriverInfo driver$3;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Re-launching ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.driver$3.id()}));
                        }
                        {
                            this.driver$3 = driver$3;
                        }
                    });
                    this.$outer.org$apache$spark$deploy$master$Master$$relaunchDriver(driver);
                } else {
                    this.$outer.logInfo((Function0<String>)new Serializable(this, driver){
                        public static final long serialVersionUID = 0L;
                        private final DriverInfo driver$3;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Not re-launching ", " because it was not supervised"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.driver$3.id()}));
                        }
                        {
                            this.driver$3 = driver$3;
                        }
                    });
                    this.$outer.org$apache$spark$deploy$master$Master$$removeDriver(driver.id(), DriverState$.MODULE$.ERROR(), (Option<Exception>)None$.MODULE$);
                }
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        });
        this.logInfo((Function0<String>)new Serializable(this, worker){
            public static final long serialVersionUID = 0L;
            private final WorkerInfo worker$4;

            public final String apply() {
                return new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Telling app of lost worker: "})).s((Seq)scala.collection.immutable.Nil$.MODULE$)).append((Object)this.worker$4.id()).toString();
            }
            {
                this.worker$4 = worker$4;
            }
        });
        ((HashSet)this.apps().filterNot((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final boolean apply(ApplicationInfo x$26) {
                return this.$outer.org$apache$spark$deploy$master$Master$$completedApps().contains((Object)x$26);
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        })).foreach((Function1)new Serializable(this, worker, msg){
            public static final long serialVersionUID = 0L;
            private final WorkerInfo worker$4;
            private final String msg$3;

            public final void apply(ApplicationInfo app) {
                app.driver().send(new org.apache.spark.deploy.DeployMessages$WorkerRemoved(this.worker$4.id(), this.worker$4.host(), this.msg$3));
            }
            {
                this.worker$4 = worker$4;
                this.msg$3 = msg$3;
            }
        });
        this.org$apache$spark$deploy$master$Master$$persistenceEngine().removeWorker(worker);
    }

    public void org$apache$spark$deploy$master$Master$$relaunchDriver(DriverInfo driver) {
        this.org$apache$spark$deploy$master$Master$$removeDriver(driver.id(), DriverState$.MODULE$.RELAUNCHING(), (Option<Exception>)None$.MODULE$);
        DriverInfo newDriver = this.org$apache$spark$deploy$master$Master$$createDriver(driver.desc());
        this.org$apache$spark$deploy$master$Master$$persistenceEngine().addDriver(newDriver);
        this.org$apache$spark$deploy$master$Master$$drivers().add((Object)newDriver);
        this.org$apache$spark$deploy$master$Master$$waitingDrivers().$plus$eq((Object)newDriver);
        this.org$apache$spark$deploy$master$Master$$schedule();
    }

    public ApplicationInfo org$apache$spark$deploy$master$Master$$createApplication(ApplicationDescription desc, RpcEndpointRef driver) {
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        String appId = this.newApplicationId(date);
        return new ApplicationInfo(now, appId, desc, date, driver, this.defaultCores());
    }

    public void org$apache$spark$deploy$master$Master$$registerApplication(ApplicationInfo app) {
        RpcAddress appAddress = app.driver().address();
        if (this.addressToApp().contains((Object)appAddress)) {
            this.logInfo((Function0<String>)new Serializable(this, appAddress){
                public static final long serialVersionUID = 0L;
                private final RpcAddress appAddress$1;

                public final String apply() {
                    return new StringBuilder().append((Object)"Attempted to re-register application at same address: ").append((Object)this.appAddress$1).toString();
                }
                {
                    this.appAddress$1 = appAddress$1;
                }
            });
            return;
        }
        this.org$apache$spark$deploy$master$Master$$applicationMetricsSystem().registerSource(app.appSource());
        this.apps().$plus$eq((Object)app);
        this.idToApp().update((Object)app.id(), (Object)app);
        this.endpointToApp().update((Object)app.driver(), (Object)app);
        this.addressToApp().update((Object)appAddress, (Object)app);
        this.waitingApps().$plus$eq((Object)app);
    }

    public void org$apache$spark$deploy$master$Master$$finishApplication(ApplicationInfo app) {
        this.removeApplication(app, ApplicationState$.MODULE$.FINISHED());
    }

    public void removeApplication(ApplicationInfo app, Enumeration.Value state) {
        block4 : {
            block6 : {
                block7 : {
                    Enumeration.Value value2;
                    Enumeration.Value value3;
                    block5 : {
                        if (!this.apps().contains((Object)app)) break block4;
                        this.logInfo((Function0<String>)new Serializable(this, app){
                            public static final long serialVersionUID = 0L;
                            private final ApplicationInfo app$2;

                            public final String apply() {
                                return new StringBuilder().append((Object)"Removing app ").append((Object)this.app$2.id()).toString();
                            }
                            {
                                this.app$2 = app$2;
                            }
                        });
                        this.apps().$minus$eq((Object)app);
                        this.idToApp().$minus$eq((Object)app.id());
                        this.endpointToApp().$minus$eq((Object)app.driver());
                        this.addressToApp().$minus$eq((Object)app.driver().address());
                        if (this.org$apache$spark$deploy$master$Master$$completedApps().size() >= this.RETAINED_APPLICATIONS()) {
                            int toRemove = package$.MODULE$.max(this.RETAINED_APPLICATIONS() / 10, 1);
                            ((ResizableArray)this.org$apache$spark$deploy$master$Master$$completedApps().take(toRemove)).foreach((Function1)new Serializable(this){
                                public static final long serialVersionUID = 0L;
                                private final /* synthetic */ Master $outer;

                                public final void apply(ApplicationInfo a) {
                                    this.$outer.org$apache$spark$deploy$master$Master$$applicationMetricsSystem().removeSource(a.appSource());
                                }
                                {
                                    if ($outer == null) {
                                        throw null;
                                    }
                                    this.$outer = $outer;
                                }
                            });
                            this.org$apache$spark$deploy$master$Master$$completedApps().trimStart(toRemove);
                        }
                        this.org$apache$spark$deploy$master$Master$$completedApps().$plus$eq((Object)app);
                        this.waitingApps().$minus$eq((Object)app);
                        app.executors().values().foreach((Function1)new Serializable(this){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ Master $outer;

                            public final void apply(ExecutorDesc exec) {
                                this.$outer.org$apache$spark$deploy$master$Master$$killExecutor(exec);
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                            }
                        });
                        app.markFinished(state);
                        value3 = ApplicationState$.MODULE$.FINISHED();
                        if (state != null) break block5;
                        if (value3 == null) break block6;
                        break block7;
                    }
                    if (value2.equals((Object)value3)) break block6;
                }
                app.driver().send(new DeployMessages.ApplicationRemoved(state.toString()));
            }
            this.org$apache$spark$deploy$master$Master$$persistenceEngine().removeApplication(app);
            this.org$apache$spark$deploy$master$Master$$schedule();
            this.workers().foreach((Function1)new Serializable(this, app){
                public static final long serialVersionUID = 0L;
                private final ApplicationInfo app$2;

                public final void apply(WorkerInfo w) {
                    w.endpoint().send(new org.apache.spark.deploy.DeployMessages$ApplicationFinished(this.app$2.id()));
                }
                {
                    this.app$2 = app$2;
                }
            });
        }
    }

    public boolean org$apache$spark$deploy$master$Master$$handleRequestExecutors(String appId, int requestedTotal) {
        Option option;
        block4 : {
            boolean bl;
            block3 : {
                block2 : {
                    option = this.idToApp().get((Object)appId);
                    if (!(option instanceof Some)) break block2;
                    Some some = (Some)option;
                    ApplicationInfo appInfo = (ApplicationInfo)some.x();
                    this.logInfo((Function0<String>)new Serializable(this, appId, requestedTotal){
                        public static final long serialVersionUID = 0L;
                        private final String appId$3;
                        private final int requestedTotal$1;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Application ", " requested to set total executors to ", "."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.appId$3, BoxesRunTime.boxToInteger((int)this.requestedTotal$1)}));
                        }
                        {
                            this.appId$3 = appId$3;
                            this.requestedTotal$1 = requestedTotal$1;
                        }
                    });
                    appInfo.executorLimit_$eq(requestedTotal);
                    this.org$apache$spark$deploy$master$Master$$schedule();
                    bl = true;
                    break block3;
                }
                if (!None$.MODULE$.equals((Object)option)) break block4;
                this.logWarning((Function0<String>)new Serializable(this, appId, requestedTotal){
                    public static final long serialVersionUID = 0L;
                    private final String appId$3;
                    private final int requestedTotal$1;

                    public final String apply() {
                        return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Unknown application ", " requested ", " total executors."})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.appId$3, BoxesRunTime.boxToInteger((int)this.requestedTotal$1)}));
                    }
                    {
                        this.appId$3 = appId$3;
                        this.requestedTotal$1 = requestedTotal$1;
                    }
                });
                bl = false;
            }
            return bl;
        }
        throw new MatchError((Object)option);
    }

    public boolean org$apache$spark$deploy$master$Master$$handleKillExecutors(String appId, Seq<Object> executorIds) {
        Option option;
        block7 : {
            boolean bl;
            block6 : {
                block4 : {
                    Tuple2 tuple2;
                    block5 : {
                        Tuple2 tuple22;
                        option = this.idToApp().get((Object)appId);
                        if (!(option instanceof Some)) break block4;
                        Some some = (Some)option;
                        ApplicationInfo appInfo = (ApplicationInfo)some.x();
                        this.logInfo((Function0<String>)new Serializable(this, appId, executorIds){
                            public static final long serialVersionUID = 0L;
                            private final String appId$4;
                            private final Seq executorIds$1;

                            public final String apply() {
                                return new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Application ", " requests to kill executors: "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.appId$4}))).append((Object)this.executorIds$1.mkString(", ")).toString();
                            }
                            {
                                this.appId$4 = appId$4;
                                this.executorIds$1 = executorIds$1;
                            }
                        });
                        HashMap<Object, ExecutorDesc> hashMap = appInfo.executors();
                        tuple2 = executorIds.partition((Function1)new Serializable(this, hashMap){
                            public static final long serialVersionUID = 0L;
                            private final HashMap eta$0$3$1;

                            public final boolean apply(int key) {
                                return this.apply$mcZI$sp(key);
                            }

                            public boolean apply$mcZI$sp(int key) {
                                return this.eta$0$3$1.contains((Object)BoxesRunTime.boxToInteger((int)key));
                            }
                            {
                                this.eta$0$3$1 = eta$0$3$1;
                            }
                        });
                        if (tuple2 == null) break block5;
                        Seq known = (Seq)tuple2._1();
                        Seq unknown = (Seq)tuple2._2();
                        Tuple2 tuple23 = tuple22 = new Tuple2((Object)known, (Object)unknown);
                        Seq known2 = (Seq)tuple23._1();
                        Seq unknown2 = (Seq)tuple23._2();
                        known2.foreach((Function1)new Serializable(this, appInfo){
                            public static final long serialVersionUID = 0L;
                            private final /* synthetic */ Master $outer;
                            private final ApplicationInfo appInfo$2;

                            public final void apply(int executorId) {
                                this.apply$mcVI$sp(executorId);
                            }

                            public void apply$mcVI$sp(int executorId) {
                                ExecutorDesc desc = (ExecutorDesc)this.appInfo$2.executors().apply((Object)BoxesRunTime.boxToInteger((int)executorId));
                                this.appInfo$2.removeExecutor(desc);
                                this.$outer.org$apache$spark$deploy$master$Master$$killExecutor(desc);
                            }
                            {
                                if ($outer == null) {
                                    throw null;
                                }
                                this.$outer = $outer;
                                this.appInfo$2 = appInfo$2;
                            }
                        });
                        if (unknown2.nonEmpty()) {
                            this.logWarning((Function0<String>)new Serializable(this, appId, unknown2){
                                public static final long serialVersionUID = 0L;
                                private final String appId$4;
                                private final Seq unknown$1;

                                public final String apply() {
                                    return new StringBuilder().append((Object)new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Application ", " attempted to kill non-existent executors: "})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.appId$4}))).append((Object)this.unknown$1.mkString(", ")).toString();
                                }
                                {
                                    this.appId$4 = appId$4;
                                    this.unknown$1 = unknown$1;
                                }
                            });
                        }
                        this.org$apache$spark$deploy$master$Master$$schedule();
                        bl = true;
                        break block6;
                    }
                    throw new MatchError((Object)tuple2);
                }
                if (!None$.MODULE$.equals((Object)option)) break block7;
                this.logWarning((Function0<String>)new Serializable(this, appId){
                    public static final long serialVersionUID = 0L;
                    private final String appId$4;

                    public final String apply() {
                        return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Unregistered application ", " requested us to kill executors!"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.appId$4}));
                    }
                    {
                        this.appId$4 = appId$4;
                    }
                });
                bl = false;
            }
            return bl;
        }
        throw new MatchError((Object)option);
    }

    public Seq<Object> org$apache$spark$deploy$master$Master$$formatExecutorIds(Seq<String> executorIds) {
        return (Seq)executorIds.flatMap((Function1)new Serializable(this){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;

            public final Iterable<Object> apply(String executorId) {
                Iterable iterable;
                try {
                    iterable = scala.Option$.MODULE$.option2Iterable((Option)new Some((Object)BoxesRunTime.boxToInteger((int)new StringOps(Predef$.MODULE$.augmentString(executorId)).toInt())));
                }
                catch (java.lang.NumberFormatException numberFormatException) {
                    this.$outer.logError((Function0<String>)new Serializable(this, executorId){
                        public static final long serialVersionUID = 0L;
                        private final String executorId$1;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Encountered executor with a non-integer ID: ", ". Ignoring"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.executorId$1}));
                        }
                        {
                            this.executorId$1 = executorId$1;
                        }
                    });
                    iterable = scala.Option$.MODULE$.option2Iterable((Option)None$.MODULE$);
                }
                return iterable;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
            }
        }, Seq$.MODULE$.canBuildFrom());
    }

    public void org$apache$spark$deploy$master$Master$$killExecutor(ExecutorDesc exec) {
        exec.worker().removeExecutor(exec);
        exec.worker().endpoint().send(new DeployMessages.KillExecutor(this.org$apache$spark$deploy$master$Master$$masterUrl(), exec.application().id(), exec.id()));
        exec.state_$eq(ExecutorState$.MODULE$.KILLED());
    }

    private String newApplicationId(Date submitDate) {
        String appId = new StringOps(Predef$.MODULE$.augmentString("app-%s-%04d")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.createDateFormat().format(submitDate), BoxesRunTime.boxToInteger((int)this.nextAppNumber())}));
        this.nextAppNumber_$eq(this.nextAppNumber() + 1);
        return appId;
    }

    public void org$apache$spark$deploy$master$Master$$timeOutDeadWorkers() {
        long currentTime = System.currentTimeMillis();
        WorkerInfo[] toRemove = (WorkerInfo[])((TraversableOnce)this.workers().filter((Function1)new Serializable(this, currentTime){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;
            private final long currentTime$1;

            public final boolean apply(WorkerInfo x$28) {
                return x$28.lastHeartbeat() < this.currentTime$1 - this.$outer.org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS();
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.currentTime$1 = currentTime$1;
            }
        })).toArray(ClassTag$.MODULE$.apply(WorkerInfo.class));
        Predef$.MODULE$.refArrayOps((Object[])toRemove).foreach((Function1)new Serializable(this, currentTime){
            public static final long serialVersionUID = 0L;
            private final /* synthetic */ Master $outer;
            private final long currentTime$1;

            /*
             * Enabled aggressive block sorting
             */
            public final Object apply(WorkerInfo worker) {
                BoxedUnit boxedUnit;
                block6 : {
                    block5 : {
                        Enumeration.Value value2;
                        Enumeration.Value value3;
                        block4 : {
                            value3 = WorkerState$.MODULE$.DEAD();
                            if (worker.state() != null) break block4;
                            if (value3 == null) break block5;
                            break block6;
                        }
                        if (!value2.equals((Object)value3)) break block6;
                    }
                    if (worker.lastHeartbeat() < this.currentTime$1 - (long)(this.$outer.org$apache$spark$deploy$master$Master$$REAPER_ITERATIONS() + 1) * this.$outer.org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS()) {
                        boxedUnit = this.$outer.workers().$minus$eq((Object)worker);
                        return boxedUnit;
                    }
                    boxedUnit = BoxedUnit.UNIT;
                    return boxedUnit;
                }
                this.$outer.logWarning((Function0<String>)new Serializable(this, worker){
                    public static final long serialVersionUID = 0L;
                    private final /* synthetic */ $anonfun$org$apache$spark$deploy$master$Master$$timeOutDeadWorkers$1 $outer;
                    private final WorkerInfo worker$9;

                    public final String apply() {
                        return new StringOps(Predef$.MODULE$.augmentString("Removing %s because we got no heartbeat in %d seconds")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.worker$9.id(), BoxesRunTime.boxToLong((long)(this.$outer.org$apache$spark$deploy$master$Master$$anonfun$$$outer().org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS() / 1000L))}));
                    }
                    {
                        if ($outer == null) {
                            throw null;
                        }
                        this.$outer = $outer;
                        this.worker$9 = worker$9;
                    }
                });
                this.$outer.org$apache$spark$deploy$master$Master$$removeWorker(worker, new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Not receiving heartbeat for ", " seconds"})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{BoxesRunTime.boxToLong((long)(this.$outer.org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS() / 1000L))})));
                boxedUnit = BoxedUnit.UNIT;
                return boxedUnit;
            }

            public /* synthetic */ Master org$apache$spark$deploy$master$Master$$anonfun$$$outer() {
                return this.$outer;
            }
            {
                if ($outer == null) {
                    throw null;
                }
                this.$outer = $outer;
                this.currentTime$1 = currentTime$1;
            }
        });
    }

    private String newDriverId(Date submitDate) {
        String appId = new StringOps(Predef$.MODULE$.augmentString("driver-%s-%04d")).format((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.createDateFormat().format(submitDate), BoxesRunTime.boxToInteger((int)this.nextDriverNumber())}));
        this.nextDriverNumber_$eq(this.nextDriverNumber() + 1);
        return appId;
    }

    public DriverInfo org$apache$spark$deploy$master$Master$$createDriver(DriverDescription desc) {
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        return new DriverInfo(now, this.newDriverId(date), desc, date);
    }

    public void org$apache$spark$deploy$master$Master$$launchDriver(WorkerInfo worker, DriverInfo driver) {
        this.logInfo((Function0<String>)new Serializable(this, worker, driver){
            public static final long serialVersionUID = 0L;
            private final WorkerInfo worker$7;
            private final DriverInfo driver$1;

            public final String apply() {
                return new StringBuilder().append((Object)"Launching driver ").append((Object)this.driver$1.id()).append((Object)" on worker ").append((Object)this.worker$7.id()).toString();
            }
            {
                this.worker$7 = worker$7;
                this.driver$1 = driver$1;
            }
        });
        worker.addDriver(driver);
        driver.worker_$eq((Option<WorkerInfo>)new Some((Object)worker));
        worker.endpoint().send(new DeployMessages.LaunchDriver(driver.id(), driver.desc()));
        driver.state_$eq(DriverState$.MODULE$.RUNNING());
    }

    public void org$apache$spark$deploy$master$Master$$removeDriver(String driverId, Enumeration.Value finalState, Option<Exception> exception2) {
        Option option;
        block6 : {
            block5 : {
                block4 : {
                    option = this.org$apache$spark$deploy$master$Master$$drivers().find((Function1)new Serializable(this, driverId){
                        public static final long serialVersionUID = 0L;
                        private final String driverId$1;

                        /*
                         * Enabled force condition propagation
                         * Lifted jumps to return sites
                         */
                        public final boolean apply(DriverInfo d) {
                            String string = this.driverId$1;
                            if (d.id() != null) {
                                String string2;
                                if (!string2.equals(string)) return false;
                                return true;
                            }
                            if (string == null) return true;
                            return false;
                        }
                        {
                            this.driverId$1 = driverId$1;
                        }
                    });
                    if (!(option instanceof Some)) break block4;
                    Some some = (Some)option;
                    DriverInfo driver = (DriverInfo)some.x();
                    this.logInfo((Function0<String>)new Serializable(this, driverId){
                        public static final long serialVersionUID = 0L;
                        private final String driverId$1;

                        public final String apply() {
                            return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Removing driver: ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.driverId$1}));
                        }
                        {
                            this.driverId$1 = driverId$1;
                        }
                    });
                    this.org$apache$spark$deploy$master$Master$$drivers().$minus$eq((Object)driver);
                    if (this.org$apache$spark$deploy$master$Master$$completedDrivers().size() >= this.RETAINED_DRIVERS()) {
                        int toRemove = package$.MODULE$.max(this.RETAINED_DRIVERS() / 10, 1);
                        this.org$apache$spark$deploy$master$Master$$completedDrivers().trimStart(toRemove);
                    }
                    this.org$apache$spark$deploy$master$Master$$completedDrivers().$plus$eq((Object)driver);
                    this.org$apache$spark$deploy$master$Master$$persistenceEngine().removeDriver(driver);
                    driver.state_$eq(finalState);
                    driver.exception_$eq(exception2);
                    driver.worker().foreach((Function1)new Serializable(this, driver){
                        public static final long serialVersionUID = 0L;
                        private final DriverInfo driver$2;

                        public final void apply(WorkerInfo w) {
                            w.removeDriver(this.driver$2);
                        }
                        {
                            this.driver$2 = driver$2;
                        }
                    });
                    this.org$apache$spark$deploy$master$Master$$schedule();
                    BoxedUnit boxedUnit = BoxedUnit.UNIT;
                    break block5;
                }
                if (!None$.MODULE$.equals((Object)option)) break block6;
                this.logWarning((Function0<String>)new Serializable(this, driverId){
                    public static final long serialVersionUID = 0L;
                    private final String driverId$1;

                    public final String apply() {
                        return new scala.StringContext((Seq)Predef$.MODULE$.wrapRefArray((Object[])new String[]{"Asked to remove unknown driver: ", ""})).s((Seq)Predef$.MODULE$.genericWrapArray((Object)new Object[]{this.driverId$1}));
                    }
                    {
                        this.driverId$1 = driverId$1;
                    }
                });
                BoxedUnit boxedUnit = BoxedUnit.UNIT;
            }
            return;
        }
        throw new MatchError((Object)option);
    }

    public final boolean org$apache$spark$deploy$master$Master$$canLaunchExecutor$1(int pos, ApplicationInfo app$3, WorkerInfo[] usableWorkers$1, int minCoresPerExecutor$1, boolean oneExecutorPerWorker$1, int memoryPerExecutor$1, int[] assignedCores$1, int[] assignedExecutors$1, IntRef coresToAssign$1) {
        boolean launchingNewExecutor;
        boolean bl;
        boolean keepScheduling = coresToAssign$1.elem >= minCoresPerExecutor$1;
        boolean enoughCores = usableWorkers$1[pos].coresFree() - assignedCores$1[pos] >= minCoresPerExecutor$1;
        boolean bl2 = launchingNewExecutor = !oneExecutorPerWorker$1 || assignedExecutors$1[pos] == 0;
        if (launchingNewExecutor) {
            boolean underLimit;
            int assignedMemory = assignedExecutors$1[pos] * memoryPerExecutor$1;
            boolean enoughMemory = usableWorkers$1[pos].memoryFree() - assignedMemory >= memoryPerExecutor$1;
            boolean bl3 = underLimit = BoxesRunTime.unboxToInt((Object)Predef$.MODULE$.intArrayOps(assignedExecutors$1).sum((Numeric)Numeric.IntIsIntegral$.MODULE$)) + app$3.executors().size() < app$3.executorLimit();
            bl = keepScheduling && enoughCores && enoughMemory && underLimit;
        } else {
            bl = keepScheduling && enoughCores;
        }
        return bl;
    }

    public Master(RpcEnv rpcEnv, RpcAddress address, int webUiPort, SecurityManager securityMgr, SparkConf conf) {
        this.rpcEnv = rpcEnv;
        this.org$apache$spark$deploy$master$Master$$address = address;
        this.webUiPort = webUiPort;
        this.securityMgr = securityMgr;
        this.conf = conf;
        RpcEndpoint$class.$init$(this);
        Logging$class.$init$(this);
        this.org$apache$spark$deploy$master$Master$$forwardMessageThread = ThreadUtils$.MODULE$.newDaemonSingleThreadScheduledExecutor("master-forward-message-thread");
        this.hadoopConf = SparkHadoopUtil$.MODULE$.get().newConfiguration(conf);
        this.org$apache$spark$deploy$master$Master$$WORKER_TIMEOUT_MS = conf.getLong("spark.worker.timeout", 60L) * 1000L;
        this.RETAINED_APPLICATIONS = conf.getInt("spark.deploy.retainedApplications", 200);
        this.RETAINED_DRIVERS = conf.getInt("spark.deploy.retainedDrivers", 200);
        this.org$apache$spark$deploy$master$Master$$REAPER_ITERATIONS = conf.getInt("spark.dead.worker.persistence", 15);
        this.RECOVERY_MODE = conf.get("spark.deploy.recoveryMode", "NONE");
        this.org$apache$spark$deploy$master$Master$$MAX_EXECUTOR_RETRIES = conf.getInt("spark.deploy.maxExecutorRetries", 10);
        this.workers = new HashSet();
        this.idToApp = new HashMap();
        this.waitingApps = new ArrayBuffer();
        this.apps = new HashSet();
        this.org$apache$spark$deploy$master$Master$$idToWorker = new HashMap();
        this.addressToWorker = new HashMap();
        this.endpointToApp = new HashMap();
        this.addressToApp = new HashMap();
        this.org$apache$spark$deploy$master$Master$$completedApps = new ArrayBuffer();
        this.nextAppNumber = 0;
        this.org$apache$spark$deploy$master$Master$$drivers = new HashSet();
        this.org$apache$spark$deploy$master$Master$$completedDrivers = new ArrayBuffer();
        this.org$apache$spark$deploy$master$Master$$waitingDrivers = new ArrayBuffer();
        this.nextDriverNumber = 0;
        Utils$.MODULE$.checkHost(address.host());
        this.masterMetricsSystem = MetricsSystem$.MODULE$.createMetricsSystem("master", conf, securityMgr);
        this.org$apache$spark$deploy$master$Master$$applicationMetricsSystem = MetricsSystem$.MODULE$.createMetricsSystem("applications", conf, securityMgr);
        this.masterSource = new MasterSource(this);
        this.org$apache$spark$deploy$master$Master$$webUi = null;
        String envVar = conf.getenv("SPARK_PUBLIC_DNS");
        this.masterPublicAddress = envVar == null ? address.host() : envVar;
        this.org$apache$spark$deploy$master$Master$$masterUrl = address.toSparkURL();
        this.org$apache$spark$deploy$master$Master$$state = RecoveryState$.MODULE$.STANDBY();
        this.org$apache$spark$deploy$master$Master$$spreadOutApps = conf.getBoolean("spark.deploy.spreadOut", true);
        this.defaultCores = conf.getInt("spark.deploy.defaultCores", Integer.MAX_VALUE);
        this.reverseProxy = conf.getBoolean("spark.ui.reverseProxy", false);
        if (this.defaultCores() < 1) {
            throw new SparkException("spark.deploy.defaultCores must be positive");
        }
        this.restServerEnabled = conf.getBoolean("spark.master.rest.enabled", true);
        this.restServer = None$.MODULE$;
        this.org$apache$spark$deploy$master$Master$$restServerBoundPort = None$.MODULE$;
    }
}

