/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.spark.deploy.SparkDocker$$anonfun
 *  org.apache.spark.deploy.SparkDocker$$anonfun$startNode
 *  scala.Function1
 *  scala.MatchError
 *  scala.Serializable
 *  scala.Tuple3
 *  scala.collection.mutable.StringBuilder
 *  scala.concurrent.Awaitable
 *  scala.concurrent.Future
 *  scala.concurrent.Promise
 *  scala.concurrent.Promise$
 *  scala.concurrent.duration.Duration
 *  scala.concurrent.duration.FiniteDuration
 *  scala.concurrent.duration.package
 *  scala.concurrent.duration.package$
 *  scala.concurrent.duration.package$DurationInt
 *  scala.runtime.BoxedUnit
 *  scala.sys.process.Process
 *  scala.sys.process.ProcessBuilder
 *  scala.sys.process.ProcessLogger
 *  scala.sys.process.ProcessLogger$
 */
package org.apache.spark.deploy;

import java.io.File;
import java.io.FileWriter;
import org.apache.spark.deploy.Docker$;
import org.apache.spark.deploy.DockerId;
import org.apache.spark.deploy.SparkDocker$;
import org.apache.spark.deploy.TestMasterInfo;
import org.apache.spark.deploy.TestWorkerInfo;
import org.apache.spark.util.ThreadUtils$;
import org.apache.spark.util.Utils$;
import scala.Function1;
import scala.MatchError;
import scala.Serializable;
import scala.Tuple3;
import scala.collection.mutable.StringBuilder;
import scala.concurrent.Awaitable;
import scala.concurrent.Future;
import scala.concurrent.Promise;
import scala.concurrent.Promise$;
import scala.concurrent.duration.Duration;
import scala.concurrent.duration.FiniteDuration;
import scala.concurrent.duration.package;
import scala.concurrent.duration.package$;
import scala.runtime.BoxedUnit;
import scala.sys.process.Process;
import scala.sys.process.ProcessBuilder;
import scala.sys.process.ProcessLogger;
import scala.sys.process.ProcessLogger$;

public final class SparkDocker$ {
    public static final SparkDocker$ MODULE$;

    public static {
        new org.apache.spark.deploy.SparkDocker$();
    }

    public TestMasterInfo startMaster(String mountDir) {
        String x$17 = "spark-test-master";
        String x$18 = mountDir;
        String x$19 = Docker$.MODULE$.makeRunCmd$default$2();
        ProcessBuilder cmd = Docker$.MODULE$.makeRunCmd(x$17, x$19, x$18);
        Tuple3<String, DockerId, File> tuple3 = this.startNode(cmd);
        if (tuple3 != null) {
            Tuple3 tuple32;
            String ip = (String)tuple3._1();
            DockerId id = (DockerId)tuple3._2();
            File outFile = (File)tuple3._3();
            Tuple3 tuple33 = tuple32 = new Tuple3((Object)ip, (Object)id, (Object)outFile);
            String ip2 = (String)tuple33._1();
            DockerId id2 = (DockerId)tuple33._2();
            File outFile2 = (File)tuple33._3();
            return new TestMasterInfo(ip2, id2, outFile2);
        }
        throw new MatchError(tuple3);
    }

    public TestWorkerInfo startWorker(String mountDir, String masters) {
        ProcessBuilder cmd = Docker$.MODULE$.makeRunCmd("spark-test-worker", masters, mountDir);
        Tuple3<String, DockerId, File> tuple3 = this.startNode(cmd);
        if (tuple3 != null) {
            Tuple3 tuple32;
            String ip = (String)tuple3._1();
            DockerId id = (DockerId)tuple3._2();
            File outFile = (File)tuple3._3();
            Tuple3 tuple33 = tuple32 = new Tuple3((Object)ip, (Object)id, (Object)outFile);
            String ip2 = (String)tuple33._1();
            DockerId id2 = (DockerId)tuple33._2();
            File outFile2 = (File)tuple33._3();
            return new TestWorkerInfo(ip2, id2, outFile2);
        }
        throw new MatchError(tuple3);
    }

    private Tuple3<String, DockerId, File> startNode(ProcessBuilder dockerCmd) {
        Promise ipPromise = Promise$.MODULE$.apply();
        File outFile = File.createTempFile("fault-tolerance-test", "", Utils$.MODULE$.createTempDir(Utils$.MODULE$.createTempDir$default$1(), Utils$.MODULE$.createTempDir$default$2()));
        FileWriter outStream = new FileWriter(outFile);
        dockerCmd.run(ProcessLogger$.MODULE$.apply((Function1)new Serializable(ipPromise, outStream){
            public static final long serialVersionUID = 0L;
            private final Promise ipPromise$1;
            private final FileWriter outStream$1;

            public final void apply(String line) {
                SparkDocker$.MODULE$.org$apache$spark$deploy$SparkDocker$$findIpAndLog$1(line, this.ipPromise$1, this.outStream$1);
            }
            {
                this.ipPromise$1 = ipPromise$1;
                this.outStream$1 = outStream$1;
            }
        }));
        String ip = (String)ThreadUtils$.MODULE$.awaitResult(ipPromise.future(), (Duration)new package.DurationInt(package$.MODULE$.DurationInt(30)).seconds());
        DockerId dockerId = Docker$.MODULE$.getLastProcessId();
        return new Tuple3((Object)ip, (Object)dockerId, (Object)outFile);
    }

    public final void org$apache$spark$deploy$SparkDocker$$findIpAndLog$1(String line, Promise ipPromise$1, FileWriter outStream$1) {
        BoxedUnit boxedUnit;
        if (line.startsWith("CONTAINER_IP=")) {
            String ip = line.split("=")[1];
            boxedUnit = ipPromise$1.success((Object)ip);
        } else {
            boxedUnit = BoxedUnit.UNIT;
        }
        outStream$1.write(new StringBuilder().append((Object)line).append((Object)"\n").toString());
        outStream$1.flush();
    }

    private SparkDocker$() {
        MODULE$ = this;
    }
}

