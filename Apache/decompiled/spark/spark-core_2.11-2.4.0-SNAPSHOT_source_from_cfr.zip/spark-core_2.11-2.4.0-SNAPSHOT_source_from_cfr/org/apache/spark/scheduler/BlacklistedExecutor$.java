/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.None$
 *  scala.Option
 *  scala.Serializable
 *  scala.Some
 *  scala.Tuple2
 *  scala.runtime.AbstractFunction2
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.scheduler;

import org.apache.spark.scheduler.BlacklistedExecutor;
import scala.None$;
import scala.Option;
import scala.Serializable;
import scala.Some;
import scala.Tuple2;
import scala.runtime.AbstractFunction2;
import scala.runtime.BoxesRunTime;

public final class BlacklistedExecutor$
extends AbstractFunction2<String, Object, BlacklistedExecutor>
implements Serializable {
    public static final BlacklistedExecutor$ MODULE$;

    public static {
        new org.apache.spark.scheduler.BlacklistedExecutor$();
    }

    public final String toString() {
        return "BlacklistedExecutor";
    }

    public BlacklistedExecutor apply(String node, long expiryTime) {
        return new BlacklistedExecutor(node, expiryTime);
    }

    public Option<Tuple2<String, Object>> unapply(BlacklistedExecutor x$0) {
        return x$0 == null ? None$.MODULE$ : new Some((Object)new Tuple2((Object)x$0.node(), (Object)BoxesRunTime.boxToLong((long)x$0.expiryTime())));
    }

    private Object readResolve() {
        return MODULE$;
    }

    private BlacklistedExecutor$() {
        MODULE$ = this;
    }
}

