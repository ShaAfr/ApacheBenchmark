/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  scala.reflect.ScalaSignature
 */
package org.apache.spark.deploy;

import org.apache.spark.deploy.Client$;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\u0006\u0001-:Q!\u0001\u0002\t\u0002-\taa\u00117jK:$(BA\u0002\u0005\u0003\u0019!W\r\u001d7ps*\u0011QAB\u0001\u0006gB\f'o\u001b\u0006\u0003\u000f!\ta!\u00199bG\",'\"A\u0005\u0002\u0007=\u0014xm\u0001\u0001\u0011\u00051iQ\"\u0001\u0002\u0007\u000b9\u0011\u0001\u0012A\b\u0003\r\rc\u0017.\u001a8u'\ti\u0001\u0003\u0005\u0002\u0012)5\t!CC\u0001\u0014\u0003\u0015\u00198-\u00197b\u0013\t)\"C\u0001\u0004B]f\u0014VM\u001a\u0005\u0006/5!\t\u0001G\u0001\u0007y%t\u0017\u000e\u001e \u0015\u0003-AQAG\u0007\u0005\u0002m\tA!\\1j]R\u0011Ad\b\t\u0003#uI!A\b\n\u0003\tUs\u0017\u000e\u001e\u0005\u0006Ae\u0001\r!I\u0001\u0005CJ<7\u000fE\u0002\u0012E\u0011J!a\t\n\u0003\u000b\u0005\u0013(/Y=\u0011\u0005\u0015BcBA\t'\u0013\t9##\u0001\u0004Qe\u0016$WMZ\u0005\u0003S)\u0012aa\u0015;sS:<'BA\u0014\u0013\u0001")
public final class Client {
    public static void main(String[] arrstring) {
        Client$.MODULE$.main(arrstring);
    }
}

