/*
 * Decompiled with CFR 0.145.
 */
package org.apache.spark.unused;

public class UnusedStubClass {
}

