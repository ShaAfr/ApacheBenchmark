/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.apache.log4j.Level
 *  org.apache.log4j.LogManager
 *  org.slf4j.impl.StaticLoggerBinder
 *  scala.runtime.BoxedUnit
 *  scala.runtime.BoxesRunTime
 */
package org.apache.spark.internal;

import java.lang.reflect.Method;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.spark.util.Utils$;
import org.slf4j.impl.StaticLoggerBinder;
import scala.runtime.BoxedUnit;
import scala.runtime.BoxesRunTime;

public final class Logging$ {
    public static final Logging$ MODULE$;
    private volatile boolean org$apache$spark$internal$Logging$$initialized;
    private volatile Level org$apache$spark$internal$Logging$$defaultRootLevel;
    private volatile boolean org$apache$spark$internal$Logging$$defaultSparkLog4jConfig;
    private final Object initLock;

    public static {
        new org.apache.spark.internal.Logging$();
    }

    public boolean org$apache$spark$internal$Logging$$initialized() {
        return this.org$apache$spark$internal$Logging$$initialized;
    }

    public void org$apache$spark$internal$Logging$$initialized_$eq(boolean x$1) {
        this.org$apache$spark$internal$Logging$$initialized = x$1;
    }

    public Level org$apache$spark$internal$Logging$$defaultRootLevel() {
        return this.org$apache$spark$internal$Logging$$defaultRootLevel;
    }

    public void org$apache$spark$internal$Logging$$defaultRootLevel_$eq(Level x$1) {
        this.org$apache$spark$internal$Logging$$defaultRootLevel = x$1;
    }

    private boolean org$apache$spark$internal$Logging$$defaultSparkLog4jConfig() {
        return this.org$apache$spark$internal$Logging$$defaultSparkLog4jConfig;
    }

    public void org$apache$spark$internal$Logging$$defaultSparkLog4jConfig_$eq(boolean x$1) {
        this.org$apache$spark$internal$Logging$$defaultSparkLog4jConfig = x$1;
    }

    public Object initLock() {
        return this.initLock;
    }

    public void uninitialize() {
        Object object = this.initLock();
        synchronized (object) {
            if (this.org$apache$spark$internal$Logging$$isLog4j12()) {
                if (this.org$apache$spark$internal$Logging$$defaultSparkLog4jConfig()) {
                    this.org$apache$spark$internal$Logging$$defaultSparkLog4jConfig_$eq(false);
                    LogManager.resetConfiguration();
                } else {
                    LogManager.getRootLogger().setLevel(this.org$apache$spark$internal$Logging$$defaultRootLevel());
                }
            }
            this.org$apache$spark$internal$Logging$$initialized_$eq(false);
            return;
        }
    }

    public boolean org$apache$spark$internal$Logging$$isLog4j12() {
        String binderClass = StaticLoggerBinder.getSingleton().getLoggerFactoryClassStr();
        return "org.slf4j.impl.Log4jLoggerFactory".equals(binderClass);
    }

    private Logging$() {
        Object object;
        MODULE$ = this;
        this.org$apache$spark$internal$Logging$$initialized = false;
        this.org$apache$spark$internal$Logging$$defaultRootLevel = null;
        this.org$apache$spark$internal$Logging$$defaultSparkLog4jConfig = false;
        this.initLock = new Object();
        try {
            Class<?> bridgeClass = Utils$.MODULE$.classForName("org.slf4j.bridge.SLF4JBridgeHandler");
            bridgeClass.getMethod("removeHandlersForRootLogger", new Class[0]).invoke(null, new Object[0]);
            boolean installed = BoxesRunTime.unboxToBoolean((Object)bridgeClass.getMethod("isInstalled", new Class[0]).invoke(null, new Object[0]));
            object = installed ? BoxedUnit.UNIT : bridgeClass.getMethod("install", new Class[0]).invoke(null, new Object[0]);
        }
        catch (ClassNotFoundException classNotFoundException) {
            object = BoxedUnit.UNIT;
        }
    }
}

