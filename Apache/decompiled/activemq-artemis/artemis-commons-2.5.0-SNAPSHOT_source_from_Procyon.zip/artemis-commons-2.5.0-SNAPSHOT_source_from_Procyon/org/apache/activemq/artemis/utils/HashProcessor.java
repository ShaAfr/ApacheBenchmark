// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

public interface HashProcessor
{
    String hash(final String p0) throws Exception;
    
    boolean compare(final char[] p0, final String p1);
}
