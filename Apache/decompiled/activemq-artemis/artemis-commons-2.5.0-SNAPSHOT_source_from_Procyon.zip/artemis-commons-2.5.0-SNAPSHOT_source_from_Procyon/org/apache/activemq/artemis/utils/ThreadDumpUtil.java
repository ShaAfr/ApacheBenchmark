// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.lang.management.LockInfo;
import java.lang.management.MonitorInfo;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.io.IOException;
import org.apache.activemq.artemis.logs.ActiveMQUtilLogger;
import java.lang.management.ManagementFactory;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;

public final class ThreadDumpUtil
{
    public static String threadDump(final String msg) {
        try (final StringWriter str = new StringWriter();
             final PrintWriter out = new PrintWriter(str)) {
            final ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
            out.println("*******************************************************************************");
            out.println("Complete Thread dump " + msg);
            for (final ThreadInfo threadInfo : threadMXBean.dumpAllThreads(true, true)) {
                out.println(threadInfoToString(threadInfo));
            }
            final long[] deadlockedThreads = threadMXBean.findDeadlockedThreads();
            if (deadlockedThreads != null && deadlockedThreads.length > 0) {
                out.println("Deadlock detected!");
                out.println();
                for (final ThreadInfo threadInfo2 : threadMXBean.getThreadInfo(deadlockedThreads, true, true)) {
                    out.println(threadInfoToString(threadInfo2));
                }
            }
            out.println("===============================================================================");
            out.println("End Thread dump " + msg);
            out.println("*******************************************************************************");
            return str.toString();
        }
        catch (IOException e) {
            ActiveMQUtilLogger.LOGGER.error((Object)"Exception thrown during generating of thread dump.", (Throwable)e);
            return "Generating of thread dump failed " + msg;
        }
    }
    
    private static String threadInfoToString(final ThreadInfo threadInfo) {
        final StringBuilder sb = new StringBuilder("\"" + threadInfo.getThreadName() + "\"" + " Id=" + threadInfo.getThreadId() + " " + threadInfo.getThreadState());
        if (threadInfo.getLockName() != null) {
            sb.append(" on " + threadInfo.getLockName());
        }
        if (threadInfo.getLockOwnerName() != null) {
            sb.append(" owned by \"" + threadInfo.getLockOwnerName() + "\" Id=" + threadInfo.getLockOwnerId());
        }
        if (threadInfo.isSuspended()) {
            sb.append(" (suspended)");
        }
        if (threadInfo.isInNative()) {
            sb.append(" (in native)");
        }
        sb.append('\n');
        for (int i = 0; i < threadInfo.getStackTrace().length; ++i) {
            final StackTraceElement ste = threadInfo.getStackTrace()[i];
            sb.append("\tat " + ste.toString());
            sb.append('\n');
            if (i == 0 && threadInfo.getLockInfo() != null) {
                final Thread.State ts = threadInfo.getThreadState();
                switch (ts) {
                    case BLOCKED: {
                        sb.append("\t-  blocked on " + threadInfo.getLockInfo());
                        sb.append('\n');
                        break;
                    }
                    case WAITING: {
                        sb.append("\t-  waiting on " + threadInfo.getLockInfo());
                        sb.append('\n');
                        break;
                    }
                    case TIMED_WAITING: {
                        sb.append("\t-  waiting on " + threadInfo.getLockInfo());
                        sb.append('\n');
                        break;
                    }
                }
            }
            for (final MonitorInfo mi : threadInfo.getLockedMonitors()) {
                if (mi.getLockedStackDepth() == i) {
                    sb.append("\t-  locked " + mi);
                    sb.append('\n');
                }
            }
        }
        final LockInfo[] locks = threadInfo.getLockedSynchronizers();
        if (locks.length > 0) {
            sb.append("\n\tNumber of locked synchronizers = " + locks.length);
            sb.append('\n');
            for (final LockInfo li : locks) {
                sb.append("\t- " + li);
                sb.append('\n');
            }
        }
        sb.append('\n');
        return sb.toString();
    }
}
