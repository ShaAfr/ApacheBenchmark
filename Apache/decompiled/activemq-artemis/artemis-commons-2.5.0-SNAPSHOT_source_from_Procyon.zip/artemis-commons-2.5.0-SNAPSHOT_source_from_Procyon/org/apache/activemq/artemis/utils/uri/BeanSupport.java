// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.uri;

import org.apache.commons.beanutils.BeanIntrospector;
import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.beans.PropertyDescriptor;
import java.util.List;
import java.util.Iterator;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.net.URI;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.BeanUtilsBean;

public class BeanSupport
{
    private static final BeanUtilsBean beanUtils;
    
    public static void registerConverter(final Converter converter, final Class type) {
        synchronized (BeanSupport.beanUtils) {
            BeanSupport.beanUtils.getConvertUtils().register(converter, type);
        }
    }
    
    public static <P> P copyData(final P source, final P target) throws Exception {
        synchronized (BeanSupport.beanUtils) {
            BeanSupport.beanUtils.copyProperties((Object)source, (Object)target);
        }
        return target;
    }
    
    public static <P> P setData(final URI uri, final P obj, final Map<String, String> query) throws Exception {
        synchronized (BeanSupport.beanUtils) {
            BeanSupport.beanUtils.setProperty((Object)obj, "host", (Object)uri.getHost());
            BeanSupport.beanUtils.setProperty((Object)obj, "port", (Object)uri.getPort());
            BeanSupport.beanUtils.setProperty((Object)obj, "userInfo", (Object)uri.getUserInfo());
            BeanSupport.beanUtils.populate((Object)obj, (Map)query);
        }
        return obj;
    }
    
    public static <P> P setData(final P obj, final Map<String, Object> data) throws Exception {
        synchronized (BeanSupport.beanUtils) {
            BeanSupport.beanUtils.populate((Object)obj, (Map)data);
        }
        return obj;
    }
    
    public static void setData(final URI uri, final HashMap<String, Object> properties, final Set<String> allowableProperties, final Map<String, String> query, final Map<String, Object> extraProps) {
        if (allowableProperties.contains("host")) {
            properties.put("host", "" + uri.getHost());
        }
        if (allowableProperties.contains("port")) {
            properties.put("port", "" + uri.getPort());
        }
        if (allowableProperties.contains("userInfo")) {
            properties.put("userInfo", "" + uri.getUserInfo());
        }
        for (final Map.Entry<String, String> entry : query.entrySet()) {
            if (allowableProperties.contains(entry.getKey())) {
                properties.put(entry.getKey(), entry.getValue());
            }
            else {
                extraProps.put(entry.getKey(), entry.getValue());
            }
        }
    }
    
    public static String getData(final List<String> ignored, final Object... beans) throws Exception {
        final StringBuilder sb = new StringBuilder();
        boolean empty = true;
        synchronized (BeanSupport.beanUtils) {
            for (final Object bean : beans) {
                if (bean != null) {
                    final PropertyDescriptor[] propertyDescriptors;
                    final PropertyDescriptor[] descriptors = propertyDescriptors = BeanSupport.beanUtils.getPropertyUtils().getPropertyDescriptors(bean);
                    for (final PropertyDescriptor descriptor : propertyDescriptors) {
                        if (descriptor.getReadMethod() != null && isWriteable(descriptor, ignored)) {
                            final String value = BeanSupport.beanUtils.getProperty(bean, descriptor.getName());
                            if (value != null) {
                                if (!empty) {
                                    sb.append("&");
                                }
                                empty = false;
                                sb.append(descriptor.getName()).append("=").append(encodeURI(value));
                            }
                        }
                    }
                }
            }
        }
        return sb.toString();
    }
    
    private static boolean isWriteable(final PropertyDescriptor descriptor, final List<String> ignored) {
        if (ignored != null && ignored.contains(descriptor.getName())) {
            return false;
        }
        final Class<?> type = descriptor.getPropertyType();
        return type == Double.class || type == Double.TYPE || type == Long.class || type == Long.TYPE || type == Integer.class || type == Integer.TYPE || type == Float.class || type == Float.TYPE || type == Boolean.class || type == Boolean.TYPE || type == String.class;
    }
    
    public static String decodeURI(final String value) throws UnsupportedEncodingException {
        return URLDecoder.decode(value, "UTF-8");
    }
    
    public static String encodeURI(final String value) throws UnsupportedEncodingException {
        return URLEncoder.encode(value, "UTF-8");
    }
    
    static {
        beanUtils = new BeanUtilsBean();
        BeanSupport.beanUtils.getPropertyUtils().addBeanIntrospector((BeanIntrospector)new FluentPropertyBeanIntrospectorWithIgnores());
    }
}
