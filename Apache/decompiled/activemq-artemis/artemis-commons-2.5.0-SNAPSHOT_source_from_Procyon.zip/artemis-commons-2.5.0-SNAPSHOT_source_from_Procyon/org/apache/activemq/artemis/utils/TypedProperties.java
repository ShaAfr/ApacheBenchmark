// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

@Deprecated
public class TypedProperties extends org.apache.activemq.artemis.utils.collections.TypedProperties
{
}
