// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.actors;

import org.apache.activemq.artemis.api.core.ActiveMQInterruptedException;
import java.util.concurrent.Executor;
import org.jboss.logging.Logger;

public class OrderedExecutor extends ProcessorBase<Runnable> implements ArtemisExecutor
{
    private static final Logger logger;
    
    public OrderedExecutor(final Executor delegate) {
        super(delegate);
    }
    
    @Override
    protected final void doTask(final Runnable task) {
        try {
            task.run();
        }
        catch (ActiveMQInterruptedException e) {
            OrderedExecutor.logger.debug((Object)"Interrupted Thread", (Throwable)e);
        }
        catch (Throwable t) {
            OrderedExecutor.logger.warn((Object)t.getMessage(), t);
        }
    }
    
    @Override
    public final void execute(final Runnable run) {
        this.task(run);
    }
    
    @Override
    public String toString() {
        return "OrderedExecutor(tasks=" + this.tasks + ")";
    }
    
    static {
        logger = Logger.getLogger((Class)OrderedExecutor.class);
    }
}
