// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

import java.util.List;
import java.util.ArrayList;
import io.netty.buffer.ByteBuf;
import java.io.Serializable;

public final class SimpleString implements CharSequence, Serializable, Comparable<SimpleString>
{
    private static final long serialVersionUID = 4204223851422244307L;
    private final byte[] data;
    private transient int hash;
    private transient String str;
    
    public static SimpleString toSimpleString(final String string) {
        if (string == null) {
            return null;
        }
        return new SimpleString(string);
    }
    
    public SimpleString(final String string) {
        final int len = string.length();
        this.data = new byte[len << 1];
        int j = 0;
        for (int i = 0; i < len; ++i) {
            final char c = string.charAt(i);
            final byte low = (byte)(c & '\u00ff');
            this.data[j++] = low;
            final byte high = (byte)(c >> 8 & 0xFF);
            this.data[j++] = high;
        }
        this.str = string;
    }
    
    public SimpleString(final byte[] data) {
        this.data = data;
    }
    
    public SimpleString(final char c) {
        this.data = new byte[2];
        final byte low = (byte)(c & '\u00ff');
        this.data[0] = low;
        final byte high = (byte)(c >> 8 & 0xFF);
        this.data[1] = high;
    }
    
    @Override
    public int length() {
        return this.data.length >> 1;
    }
    
    @Override
    public char charAt(int pos) {
        if (pos < 0 || pos >= this.data.length >> 1) {
            throw new IndexOutOfBoundsException();
        }
        pos <<= 1;
        return (char)((this.data[pos] & 0xFF) | (this.data[pos + 1] << 8 & 0xFF00));
    }
    
    @Override
    public CharSequence subSequence(final int start, final int end) {
        return this.subSeq(start, end);
    }
    
    public static SimpleString readNullableSimpleString(final ByteBuf buffer) {
        final int b = buffer.readByte();
        if (b == 0) {
            return null;
        }
        return readSimpleString(buffer);
    }
    
    public static SimpleString readSimpleString(final ByteBuf buffer) {
        final int len = buffer.readInt();
        if (len > buffer.readableBytes()) {
            throw new IndexOutOfBoundsException();
        }
        final byte[] data = new byte[len];
        buffer.readBytes(data);
        return new SimpleString(data);
    }
    
    public static void writeNullableSimpleString(final ByteBuf buffer, final SimpleString val) {
        if (val == null) {
            buffer.writeByte(0);
        }
        else {
            buffer.writeByte(1);
            writeSimpleString(buffer, val);
        }
    }
    
    public static void writeSimpleString(final ByteBuf buffer, final SimpleString val) {
        final byte[] data = val.getData();
        buffer.writeInt(data.length);
        buffer.writeBytes(data);
    }
    
    public SimpleString subSeq(final int start, final int end) {
        final int len = this.data.length >> 1;
        if (end < start || start < 0 || end > len) {
            throw new IndexOutOfBoundsException();
        }
        final int newlen = end - start << 1;
        final byte[] bytes = new byte[newlen];
        System.arraycopy(this.data, start << 1, bytes, 0, newlen);
        return new SimpleString(bytes);
    }
    
    @Override
    public int compareTo(final SimpleString o) {
        return this.toString().compareTo(o.toString());
    }
    
    public byte[] getData() {
        return this.data;
    }
    
    public boolean startsWith(final SimpleString other) {
        final byte[] otherdata = other.data;
        if (otherdata.length > this.data.length) {
            return false;
        }
        for (int i = 0; i < otherdata.length; ++i) {
            if (this.data[i] != otherdata[i]) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        if (this.str == null) {
            final int len = this.data.length >> 1;
            final char[] chars = new char[len];
            int j = 0;
            for (int i = 0; i < len; ++i) {
                final int low = this.data[j++] & 0xFF;
                final int high = this.data[j++] << 8 & 0xFF00;
                chars[i] = (char)(low | high);
            }
            this.str = new String(chars);
        }
        return this.str;
    }
    
    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SimpleString)) {
            return false;
        }
        final SimpleString s = (SimpleString)other;
        if (this.data.length != s.data.length) {
            return false;
        }
        for (int i = 0; i < this.data.length; ++i) {
            if (this.data[i] != s.data[i]) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            int tmphash = 0;
            for (final byte element : this.data) {
                tmphash = (tmphash << 5) - tmphash + element;
            }
            this.hash = tmphash;
        }
        return this.hash;
    }
    
    public SimpleString[] split(final char delim) {
        List<SimpleString> all = null;
        final byte low = (byte)(delim & '\u00ff');
        final byte high = (byte)(delim >> 8 & 0xFF);
        int lasPos = 0;
        for (int i = 0; i < this.data.length; i += 2) {
            if (this.data[i] == low && this.data[i + 1] == high) {
                final byte[] bytes = new byte[i - lasPos];
                System.arraycopy(this.data, lasPos, bytes, 0, bytes.length);
                lasPos = i + 2;
                if (all == null) {
                    all = new ArrayList<SimpleString>(2);
                }
                all.add(new SimpleString(bytes));
            }
        }
        if (all == null) {
            return new SimpleString[] { this };
        }
        final byte[] bytes2 = new byte[this.data.length - lasPos];
        System.arraycopy(this.data, lasPos, bytes2, 0, bytes2.length);
        all.add(new SimpleString(bytes2));
        final SimpleString[] parts = new SimpleString[all.size()];
        return all.toArray(parts);
    }
    
    public boolean contains(final char c) {
        final byte low = (byte)(c & '\u00ff');
        final byte high = (byte)(c >> 8 & 0xFF);
        for (int i = 0; i < this.data.length; i += 2) {
            if (this.data[i] == low && this.data[i + 1] == high) {
                return true;
            }
        }
        return false;
    }
    
    public SimpleString concat(final String toAdd) {
        return this.concat(new SimpleString(toAdd));
    }
    
    public SimpleString concat(final SimpleString toAdd) {
        final byte[] bytes = new byte[this.data.length + toAdd.getData().length];
        System.arraycopy(this.data, 0, bytes, 0, this.data.length);
        System.arraycopy(toAdd.getData(), 0, bytes, this.data.length, toAdd.getData().length);
        return new SimpleString(bytes);
    }
    
    public SimpleString concat(final char c) {
        final byte[] bytes = new byte[this.data.length + 2];
        System.arraycopy(this.data, 0, bytes, 0, this.data.length);
        bytes[this.data.length] = (byte)(c & '\u00ff');
        bytes[this.data.length + 1] = (byte)(c >> 8 & 0xFF);
        return new SimpleString(bytes);
    }
    
    public int sizeof() {
        return 4 + this.data.length;
    }
    
    public static int sizeofString(final SimpleString str) {
        return str.sizeof();
    }
    
    public static int sizeofNullableString(final SimpleString str) {
        if (str == null) {
            return 1;
        }
        return 1 + str.sizeof();
    }
    
    public void getChars(final int srcBegin, final int srcEnd, final char[] dst, final int dstPos) {
        if (srcBegin < 0) {
            throw new StringIndexOutOfBoundsException(srcBegin);
        }
        if (srcEnd > this.length()) {
            throw new StringIndexOutOfBoundsException(srcEnd);
        }
        if (srcBegin > srcEnd) {
            throw new StringIndexOutOfBoundsException(srcEnd - srcBegin);
        }
        int j = srcBegin * 2;
        int d = dstPos;
        for (int i = srcBegin; i < srcEnd; ++i) {
            final int low = this.data[j++] & 0xFF;
            final int high = this.data[j++] << 8 & 0xFF00;
            dst[d++] = (char)(low | high);
        }
    }
}
