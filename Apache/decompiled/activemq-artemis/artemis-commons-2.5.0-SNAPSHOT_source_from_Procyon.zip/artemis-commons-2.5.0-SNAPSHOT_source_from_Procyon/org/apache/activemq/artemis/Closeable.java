// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis;

public interface Closeable
{
    void close(final boolean p0);
}
