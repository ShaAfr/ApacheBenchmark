// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.security.PrivilegedAction;
import java.security.AccessController;
import java.security.AccessControlContext;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ThreadFactory;

public final class ActiveMQThreadFactory implements ThreadFactory
{
    private String groupName;
    private final AtomicInteger threadCount;
    private final int threadPriority;
    private final boolean daemon;
    private final ClassLoader tccl;
    private final AccessControlContext acc;
    private final String prefix;
    
    public ActiveMQThreadFactory(final String groupName, final boolean daemon, final ClassLoader tccl) {
        this(groupName, "Thread-", daemon, tccl);
    }
    
    public ActiveMQThreadFactory(final String groupName, final String prefix, final boolean daemon, final ClassLoader tccl) {
        this.threadCount = new AtomicInteger(0);
        this.groupName = groupName;
        this.prefix = prefix;
        this.threadPriority = 5;
        this.tccl = tccl;
        this.daemon = daemon;
        this.acc = AccessController.getContext();
    }
    
    @Override
    public Thread newThread(final Runnable command) {
        if (this.acc != null) {
            return AccessController.doPrivileged((PrivilegedAction<Thread>)new ThreadCreateAction(command), this.acc);
        }
        return this.createThread(command);
    }
    
    private Thread createThread(final Runnable command) {
        final Thread t = new Thread(command, this.prefix + this.threadCount.getAndIncrement() + " (" + this.groupName + ")");
        t.setDaemon(this.daemon);
        t.setPriority(this.threadPriority);
        t.setContextClassLoader(this.tccl);
        return t;
    }
    
    public static ActiveMQThreadFactory defaultThreadFactory() {
        final String callerClassName = Thread.currentThread().getStackTrace()[2].getClassName();
        return new ActiveMQThreadFactory(callerClassName, false, null);
    }
    
    private final class ThreadCreateAction implements PrivilegedAction<Thread>
    {
        private final Runnable target;
        
        private ThreadCreateAction(final Runnable target) {
            this.target = target;
        }
        
        @Override
        public Thread run() {
            return ActiveMQThreadFactory.this.createThread(this.target);
        }
    }
}
