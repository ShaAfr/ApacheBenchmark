// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.uri;

public class SchemaConstants
{
    public static final String TCP = "tcp";
    public static final String UDP = "udp";
    public static final String JGROUPS = "jgroups";
    public static final String VM = "vm";
}
