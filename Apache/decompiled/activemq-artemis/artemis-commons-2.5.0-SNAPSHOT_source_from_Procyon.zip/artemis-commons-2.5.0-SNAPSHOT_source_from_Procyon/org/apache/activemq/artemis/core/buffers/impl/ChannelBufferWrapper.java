// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.core.buffers.impl;

import org.apache.activemq.artemis.utils.ByteUtil;
import java.io.IOException;
import java.nio.ByteBuffer;
import org.apache.activemq.artemis.utils.UTF8Util;
import org.apache.activemq.artemis.api.core.SimpleString;
import io.netty.buffer.Unpooled;
import io.netty.buffer.ByteBuf;
import org.apache.activemq.artemis.api.core.ActiveMQBuffer;

public class ChannelBufferWrapper implements ActiveMQBuffer
{
    protected final ByteBuf buffer;
    private final boolean releasable;
    private final boolean isPooled;
    
    public static ByteBuf unwrap(ByteBuf buffer) {
        ByteBuf parent;
        while ((parent = buffer.unwrap()) != null && parent != buffer) {
            buffer = parent;
        }
        return buffer;
    }
    
    public ChannelBufferWrapper(final ByteBuf buffer) {
        this(buffer, false);
    }
    
    public ChannelBufferWrapper(final ByteBuf buffer, final boolean releasable) {
        this(buffer, releasable, false);
    }
    
    public ChannelBufferWrapper(final ByteBuf buffer, final boolean releasable, final boolean pooled) {
        if (!releasable) {
            this.buffer = Unpooled.unreleasableBuffer(buffer);
        }
        else {
            this.buffer = buffer;
        }
        this.releasable = releasable;
        this.isPooled = pooled;
    }
    
    @Override
    public boolean readBoolean() {
        return this.readByte() != 0;
    }
    
    @Override
    public SimpleString readNullableSimpleString() {
        return SimpleString.readNullableSimpleString(this.buffer);
    }
    
    @Override
    public String readNullableString() {
        final int b = this.buffer.readByte();
        if (b == 0) {
            return null;
        }
        return this.readStringInternal();
    }
    
    @Override
    public SimpleString readSimpleString() {
        return SimpleString.readSimpleString(this.buffer);
    }
    
    @Override
    public String readString() {
        return this.readStringInternal();
    }
    
    private String readStringInternal() {
        final int len = this.buffer.readInt();
        if (len < 9) {
            final char[] chars = new char[len];
            for (int i = 0; i < len; ++i) {
                chars[i] = (char)this.buffer.readShort();
            }
            return new String(chars);
        }
        if (len < 4095) {
            return this.readUTF();
        }
        return SimpleString.readSimpleString(this.buffer).toString();
    }
    
    @Override
    public void writeNullableString(final String val) {
        UTF8Util.writeNullableString(this.buffer, val);
    }
    
    @Override
    public void writeUTF(final String utf) {
        UTF8Util.saveUTF(this.buffer, utf);
    }
    
    @Override
    public String readUTF() {
        return UTF8Util.readUTF(this);
    }
    
    @Override
    public void writeBoolean(final boolean val) {
        this.buffer.writeByte((int)(byte)(val ? -1 : 0));
    }
    
    @Override
    public void writeNullableSimpleString(final SimpleString val) {
        SimpleString.writeNullableSimpleString(this.buffer, val);
    }
    
    @Override
    public void writeSimpleString(final SimpleString val) {
        SimpleString.writeSimpleString(this.buffer, val);
    }
    
    @Override
    public void writeString(final String val) {
        UTF8Util.writeString(this.buffer, val);
    }
    
    @Override
    public int capacity() {
        return this.buffer.capacity();
    }
    
    @Override
    public ByteBuf byteBuf() {
        return this.buffer;
    }
    
    @Override
    public void clear() {
        this.buffer.clear();
    }
    
    @Override
    public ActiveMQBuffer copy() {
        return new ChannelBufferWrapper(this.buffer.copy(), this.releasable);
    }
    
    @Override
    public ActiveMQBuffer copy(final int index, final int length) {
        return new ChannelBufferWrapper(this.buffer.copy(index, length), this.releasable);
    }
    
    @Override
    public void discardReadBytes() {
        this.buffer.discardReadBytes();
    }
    
    @Override
    public ActiveMQBuffer duplicate() {
        return new ChannelBufferWrapper(this.buffer.duplicate(), this.releasable);
    }
    
    @Override
    public byte getByte(final int index) {
        return this.buffer.getByte(index);
    }
    
    @Override
    public void getBytes(final int index, final byte[] dst, final int dstIndex, final int length) {
        this.buffer.getBytes(index, dst, dstIndex, length);
    }
    
    @Override
    public void getBytes(final int index, final byte[] dst) {
        this.buffer.getBytes(index, dst);
    }
    
    @Override
    public void getBytes(final int index, final ByteBuffer dst) {
        this.buffer.getBytes(index, dst);
    }
    
    @Override
    public void getBytes(final int index, final ActiveMQBuffer dst, final int dstIndex, final int length) {
        this.buffer.getBytes(index, dst.byteBuf(), dstIndex, length);
    }
    
    @Override
    public void getBytes(final int index, final ActiveMQBuffer dst, final int length) {
        this.buffer.getBytes(index, dst.byteBuf(), length);
    }
    
    @Override
    public void getBytes(final int index, final ActiveMQBuffer dst) {
        this.buffer.getBytes(index, dst.byteBuf());
    }
    
    @Override
    public char getChar(final int index) {
        return (char)this.buffer.getShort(index);
    }
    
    @Override
    public double getDouble(final int index) {
        return Double.longBitsToDouble(this.buffer.getLong(index));
    }
    
    @Override
    public float getFloat(final int index) {
        return Float.intBitsToFloat(this.buffer.getInt(index));
    }
    
    @Override
    public int getInt(final int index) {
        return this.buffer.getInt(index);
    }
    
    @Override
    public long getLong(final int index) {
        return this.buffer.getLong(index);
    }
    
    @Override
    public short getShort(final int index) {
        return this.buffer.getShort(index);
    }
    
    @Override
    public short getUnsignedByte(final int index) {
        return this.buffer.getUnsignedByte(index);
    }
    
    @Override
    public long getUnsignedInt(final int index) {
        return this.buffer.getUnsignedInt(index);
    }
    
    @Override
    public int getUnsignedShort(final int index) {
        return this.buffer.getUnsignedShort(index);
    }
    
    @Override
    public void markReaderIndex() {
        this.buffer.markReaderIndex();
    }
    
    @Override
    public void markWriterIndex() {
        this.buffer.markWriterIndex();
    }
    
    @Override
    public boolean readable() {
        return this.buffer.isReadable();
    }
    
    @Override
    public int readableBytes() {
        return this.buffer.readableBytes();
    }
    
    @Override
    public byte readByte() {
        return this.buffer.readByte();
    }
    
    @Override
    public void readBytes(final byte[] dst, final int dstIndex, final int length) {
        this.buffer.readBytes(dst, dstIndex, length);
    }
    
    @Override
    public void readBytes(final byte[] dst) {
        this.buffer.readBytes(dst);
    }
    
    @Override
    public void readBytes(final ByteBuffer dst) {
        this.buffer.readBytes(dst);
    }
    
    @Override
    public void readBytes(final ActiveMQBuffer dst, final int dstIndex, final int length) {
        this.buffer.readBytes(dst.byteBuf(), dstIndex, length);
    }
    
    @Override
    public void readBytes(final ActiveMQBuffer dst, final int length) {
        this.buffer.readBytes(dst.byteBuf(), length);
    }
    
    @Override
    public void readBytes(final ActiveMQBuffer dst) {
        this.buffer.readBytes(dst.byteBuf());
    }
    
    @Override
    public ActiveMQBuffer readBytes(final int length) {
        return new ChannelBufferWrapper(this.buffer.readBytes(length), this.releasable);
    }
    
    @Override
    public char readChar() {
        return (char)this.buffer.readShort();
    }
    
    @Override
    public double readDouble() {
        return Double.longBitsToDouble(this.buffer.readLong());
    }
    
    @Override
    public int readerIndex() {
        return this.buffer.readerIndex();
    }
    
    @Override
    public void readerIndex(final int readerIndex) {
        this.buffer.readerIndex(readerIndex);
    }
    
    @Override
    public float readFloat() {
        return Float.intBitsToFloat(this.buffer.readInt());
    }
    
    @Override
    public int readInt() {
        return this.buffer.readInt();
    }
    
    @Override
    public long readLong() {
        return this.buffer.readLong();
    }
    
    @Override
    public short readShort() {
        return this.buffer.readShort();
    }
    
    @Override
    public ActiveMQBuffer readSlice(final int length) {
        if (this.isPooled) {
            final ByteBuf fromBuffer = this.buffer.readSlice(length);
            final ByteBuf newNettyBuffer = Unpooled.buffer(fromBuffer.capacity());
            final int read = fromBuffer.readerIndex();
            final int writ = fromBuffer.writerIndex();
            fromBuffer.readerIndex(0);
            fromBuffer.readBytes(newNettyBuffer, 0, writ);
            newNettyBuffer.setIndex(read, writ);
            final ActiveMQBuffer returnBuffer = new ChannelBufferWrapper(newNettyBuffer, this.releasable, false);
            returnBuffer.setIndex(read, writ);
            return returnBuffer;
        }
        return new ChannelBufferWrapper(this.buffer.readSlice(length), this.releasable, this.isPooled);
    }
    
    @Override
    public int readUnsignedByte() {
        return this.buffer.readUnsignedByte();
    }
    
    @Override
    public long readUnsignedInt() {
        return this.buffer.readUnsignedInt();
    }
    
    @Override
    public int readUnsignedShort() {
        return this.buffer.readUnsignedShort();
    }
    
    @Override
    public void resetReaderIndex() {
        this.buffer.resetReaderIndex();
    }
    
    @Override
    public void resetWriterIndex() {
        this.buffer.resetWriterIndex();
    }
    
    @Override
    public void setByte(final int index, final byte value) {
        this.buffer.setByte(index, (int)value);
    }
    
    @Override
    public void setBytes(final int index, final byte[] src, final int srcIndex, final int length) {
        this.buffer.setBytes(index, src, srcIndex, length);
    }
    
    @Override
    public void setBytes(final int index, final byte[] src) {
        this.buffer.setBytes(index, src);
    }
    
    @Override
    public void setBytes(final int index, final ByteBuffer src) {
        this.buffer.setBytes(index, src);
    }
    
    @Override
    public void setBytes(final int index, final ActiveMQBuffer src, final int srcIndex, final int length) {
        this.buffer.setBytes(index, src.byteBuf(), srcIndex, length);
    }
    
    @Override
    public void setBytes(final int index, final ActiveMQBuffer src, final int length) {
        this.buffer.setBytes(index, src.byteBuf(), length);
    }
    
    @Override
    public void setBytes(final int index, final ActiveMQBuffer src) {
        this.buffer.setBytes(index, src.byteBuf());
    }
    
    @Override
    public void setChar(final int index, final char value) {
        this.buffer.setShort(index, (int)(short)value);
    }
    
    @Override
    public void setDouble(final int index, final double value) {
        this.buffer.setLong(index, Double.doubleToLongBits(value));
    }
    
    @Override
    public void setFloat(final int index, final float value) {
        this.buffer.setInt(index, Float.floatToIntBits(value));
    }
    
    @Override
    public void setIndex(final int readerIndex, final int writerIndex) {
        this.buffer.setIndex(readerIndex, writerIndex);
    }
    
    @Override
    public void setInt(final int index, final int value) {
        this.buffer.setInt(index, value);
    }
    
    @Override
    public void setLong(final int index, final long value) {
        this.buffer.setLong(index, value);
    }
    
    @Override
    public void setShort(final int index, final short value) {
        this.buffer.setShort(index, (int)value);
    }
    
    @Override
    public int skipBytes(final int length) {
        this.buffer.skipBytes(length);
        return length;
    }
    
    @Override
    public ActiveMQBuffer slice() {
        return new ChannelBufferWrapper(this.buffer.slice(), this.releasable);
    }
    
    @Override
    public ActiveMQBuffer slice(final int index, final int length) {
        return new ChannelBufferWrapper(this.buffer.slice(index, length), this.releasable);
    }
    
    @Override
    public ByteBuffer toByteBuffer() {
        return this.buffer.nioBuffer();
    }
    
    @Override
    public ByteBuffer toByteBuffer(final int index, final int length) {
        return this.buffer.nioBuffer(index, length);
    }
    
    @Override
    public void release() {
        if (this.isPooled) {
            this.buffer.release();
        }
    }
    
    @Override
    public boolean writable() {
        return this.buffer.isWritable();
    }
    
    @Override
    public int writableBytes() {
        return this.buffer.writableBytes();
    }
    
    @Override
    public void writeByte(final byte value) {
        this.buffer.writeByte((int)value);
    }
    
    @Override
    public void writeBytes(final byte[] src, final int srcIndex, final int length) {
        this.buffer.writeBytes(src, srcIndex, length);
    }
    
    @Override
    public void writeBytes(final byte[] src) {
        this.buffer.writeBytes(src);
    }
    
    @Override
    public void writeBytes(final ByteBuffer src) {
        this.buffer.writeBytes(src);
    }
    
    @Override
    public void writeBytes(final ByteBuf src, final int srcIndex, final int length) {
        this.buffer.writeBytes(src, srcIndex, length);
    }
    
    @Override
    public void writeBytes(final ActiveMQBuffer src, final int srcIndex, final int length) {
        this.buffer.writeBytes(src.byteBuf(), srcIndex, length);
    }
    
    @Override
    public void writeBytes(final ActiveMQBuffer src, final int length) {
        this.buffer.writeBytes(src.byteBuf(), length);
    }
    
    @Override
    public void writeChar(final char chr) {
        this.buffer.writeShort((int)(short)chr);
    }
    
    @Override
    public void writeDouble(final double value) {
        this.buffer.writeLong(Double.doubleToLongBits(value));
    }
    
    @Override
    public void writeFloat(final float value) {
        this.buffer.writeInt(Float.floatToIntBits(value));
    }
    
    @Override
    public void writeInt(final int value) {
        this.buffer.writeInt(value);
    }
    
    @Override
    public void writeLong(final long value) {
        this.buffer.writeLong(value);
    }
    
    @Override
    public int writerIndex() {
        return this.buffer.writerIndex();
    }
    
    @Override
    public void writerIndex(final int writerIndex) {
        this.buffer.writerIndex(writerIndex);
    }
    
    @Override
    public void writeShort(final short value) {
        this.buffer.writeShort((int)value);
    }
    
    @Override
    public void readFully(final byte[] b) throws IOException {
        this.readBytes(b);
    }
    
    @Override
    public void readFully(final byte[] b, final int off, final int len) throws IOException {
        this.readBytes(b, off, len);
    }
    
    @Override
    public String readLine() throws IOException {
        return ByteUtil.readLine(this);
    }
}
