// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.actors;

public abstract class HandlerBase
{
    private static final Object DUMMY;
    private final ThreadLocal<Object> inHandler;
    
    public HandlerBase() {
        this.inHandler = new ThreadLocal<Object>();
    }
    
    protected void enter() {
        assert this.inHandler.get() == null : "should be null";
        this.inHandler.set(HandlerBase.DUMMY);
    }
    
    public boolean inHandler() {
        final Object dummy = this.inHandler.get();
        return dummy != null;
    }
    
    protected void leave() {
        assert this.inHandler.get() != null : "marker not set";
        this.inHandler.set(null);
    }
    
    static {
        DUMMY = Boolean.TRUE;
    }
}
