// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.actors;

public interface ActorListener<T>
{
    void onMessage(final T p0);
}
