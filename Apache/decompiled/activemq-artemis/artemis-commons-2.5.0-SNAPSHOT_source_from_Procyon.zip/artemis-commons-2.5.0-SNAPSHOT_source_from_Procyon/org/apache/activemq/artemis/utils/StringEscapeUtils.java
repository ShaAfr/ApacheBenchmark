// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

public abstract class StringEscapeUtils
{
    public static String escapeString(final String str) {
        if (str == null) {
            return str;
        }
        final int sz = str.length();
        final StringBuilder stringBuilder = new StringBuilder(str.length());
        for (int i = 0; i < sz; ++i) {
            final char ch = str.charAt(i);
            if (ch > '\u0fff') {
                stringBuilder.append("\\u").append(hex(ch));
            }
            else if (ch > '\u00ff') {
                stringBuilder.append("\\u0").append(hex(ch));
            }
            else if (ch > '\u007f') {
                stringBuilder.append("\\u00").append(hex(ch));
            }
            else if (ch < ' ') {
                switch (ch) {
                    case '\b': {
                        stringBuilder.append('\\').append('b');
                        break;
                    }
                    case '\n': {
                        stringBuilder.append('\\').append('n');
                        break;
                    }
                    case '\t': {
                        stringBuilder.append('\\').append('t');
                        break;
                    }
                    case '\f': {
                        stringBuilder.append('\\').append('f');
                        break;
                    }
                    case '\r': {
                        stringBuilder.append('\\').append('r');
                        break;
                    }
                    default: {
                        if (ch > '\u000f') {
                            stringBuilder.append("\\u00").append(hex(ch));
                            break;
                        }
                        stringBuilder.append("\\u000").append(hex(ch));
                        break;
                    }
                }
            }
            else {
                switch (ch) {
                    case '\'': {
                        stringBuilder.append('\\').append('\'');
                        break;
                    }
                    case '\"': {
                        stringBuilder.append('\\').append('\"');
                        break;
                    }
                    case '\\': {
                        stringBuilder.append('\\').append('\\');
                        break;
                    }
                    case '/': {
                        stringBuilder.append('\\').append('/');
                        break;
                    }
                    default: {
                        stringBuilder.append(ch);
                        break;
                    }
                }
            }
        }
        return stringBuilder.toString();
    }
    
    private static String hex(final char ch) {
        return Integer.toHexString(ch).toUpperCase();
    }
}
