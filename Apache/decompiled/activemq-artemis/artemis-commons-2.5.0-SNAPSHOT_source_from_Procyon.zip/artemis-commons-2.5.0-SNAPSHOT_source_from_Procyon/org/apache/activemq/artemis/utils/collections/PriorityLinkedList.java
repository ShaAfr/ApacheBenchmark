// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

public interface PriorityLinkedList<T>
{
    void addHead(final T p0, final int p1);
    
    void addTail(final T p0, final int p1);
    
    T poll();
    
    void clear();
    
    int size();
    
    LinkedListIterator<T> iterator();
    
    boolean isEmpty();
}
