// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQConnectionTimedOutException extends ActiveMQException
{
    private static final long serialVersionUID = 3244233758084830372L;
    
    public ActiveMQConnectionTimedOutException() {
        super(ActiveMQExceptionType.CONNECTION_TIMEDOUT);
    }
    
    public ActiveMQConnectionTimedOutException(final String msg) {
        super(ActiveMQExceptionType.CONNECTION_TIMEDOUT, msg);
    }
}
