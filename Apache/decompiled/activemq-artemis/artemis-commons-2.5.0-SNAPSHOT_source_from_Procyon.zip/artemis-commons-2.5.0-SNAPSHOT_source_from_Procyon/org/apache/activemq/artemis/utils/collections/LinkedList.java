// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

public interface LinkedList<E>
{
    void addHead(final E p0);
    
    void addTail(final E p0);
    
    E poll();
    
    LinkedListIterator<E> iterator();
    
    void clear();
    
    int size();
}
