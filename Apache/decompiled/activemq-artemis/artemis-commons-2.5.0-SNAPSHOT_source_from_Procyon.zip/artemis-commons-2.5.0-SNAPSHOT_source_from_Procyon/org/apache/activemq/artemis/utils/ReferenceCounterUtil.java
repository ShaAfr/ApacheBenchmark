// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.Executor;

public class ReferenceCounterUtil implements ReferenceCounter
{
    private final Runnable runnable;
    private final Executor executor;
    private final AtomicInteger uses;
    
    public ReferenceCounterUtil(final Runnable runnable) {
        this(runnable, null);
    }
    
    public ReferenceCounterUtil(final Runnable runnable, final Executor executor) {
        this.uses = new AtomicInteger(0);
        this.runnable = runnable;
        this.executor = executor;
    }
    
    @Override
    public int increment() {
        return this.uses.incrementAndGet();
    }
    
    @Override
    public int decrement() {
        final int value = this.uses.decrementAndGet();
        if (value == 0) {
            if (this.executor != null) {
                this.executor.execute(this.runnable);
            }
            else {
                this.runnable.run();
            }
        }
        return value;
    }
}
