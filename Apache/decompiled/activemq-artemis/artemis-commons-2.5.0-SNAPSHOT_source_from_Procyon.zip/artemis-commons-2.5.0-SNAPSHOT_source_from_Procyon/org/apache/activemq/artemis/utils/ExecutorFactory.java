// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import org.apache.activemq.artemis.utils.actors.ArtemisExecutor;

public interface ExecutorFactory
{
    ArtemisExecutor getExecutor();
}
