// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

public interface RunnableEx
{
    void run() throws Exception;
}
