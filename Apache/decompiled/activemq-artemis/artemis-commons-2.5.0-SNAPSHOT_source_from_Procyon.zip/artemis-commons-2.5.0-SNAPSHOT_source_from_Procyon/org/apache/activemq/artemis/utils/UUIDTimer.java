// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.Random;

public class UUIDTimer
{
    private static final long kClockOffset = 122192928000000000L;
    private static final long kClockMultiplier = 10000L;
    private static final long kClockMultiplierL = 10000L;
    private static final long kMaxClockAdvance = 100L;
    private final Random mRnd;
    private final byte[] mClockSequence;
    private long mLastSystemTimestamp;
    private long mLastUsedTimestamp;
    private int mClockCounter;
    private static final int MAX_WAIT_COUNT = 50;
    
    UUIDTimer(final Random rnd) {
        this.mClockSequence = new byte[3];
        this.mLastSystemTimestamp = 0L;
        this.mLastUsedTimestamp = 0L;
        this.mClockCounter = 0;
        this.initCounters(this.mRnd = rnd);
        this.mLastSystemTimestamp = 0L;
        this.mLastUsedTimestamp = 0L;
    }
    
    private void initCounters(final Random rnd) {
        rnd.nextBytes(this.mClockSequence);
        this.mClockCounter = (this.mClockSequence[2] & 0xFF);
    }
    
    public void getTimestamp(final byte[] uuidData) {
        uuidData[8] = this.mClockSequence[0];
        uuidData[9] = this.mClockSequence[1];
        long systime = System.currentTimeMillis();
        if (systime < this.mLastSystemTimestamp) {
            this.mLastSystemTimestamp = systime;
        }
        if (systime <= this.mLastUsedTimestamp) {
            if (this.mClockCounter < 10000L) {
                systime = this.mLastUsedTimestamp;
            }
            else {
                final long actDiff = this.mLastUsedTimestamp - systime;
                final long origTime = systime;
                systime = this.mLastUsedTimestamp + 1L;
                this.initCounters(this.mRnd);
                if (actDiff >= 100L) {
                    slowDown(origTime, actDiff);
                }
            }
        }
        else {
            this.mClockCounter &= 0xFF;
        }
        this.mLastUsedTimestamp = systime;
        systime *= 10000L;
        systime += 122192928000000000L;
        systime += this.mClockCounter;
        ++this.mClockCounter;
        final int clockHi = (int)(systime >>> 32);
        final int clockLo = (int)systime;
        uuidData[6] = (byte)(clockHi >>> 24);
        uuidData[7] = (byte)(clockHi >>> 16);
        uuidData[4] = (byte)(clockHi >>> 8);
        uuidData[5] = (byte)clockHi;
        uuidData[0] = (byte)(clockLo >>> 24);
        uuidData[1] = (byte)(clockLo >>> 16);
        uuidData[2] = (byte)(clockLo >>> 8);
        uuidData[3] = (byte)clockLo;
    }
    
    private static void slowDown(final long startTime, final long actDiff) {
        final long ratio = actDiff / 100L;
        long delay;
        if (ratio < 2L) {
            delay = 1L;
        }
        else if (ratio < 10L) {
            delay = 2L;
        }
        else if (ratio < 600L) {
            delay = 3L;
        }
        else {
            delay = 5L;
        }
        final long waitUntil = startTime + delay;
        int counter = 0;
        do {
            try {
                Thread.sleep(delay);
            }
            catch (InterruptedException ex) {}
            delay = 1L;
            if (++counter > 50) {
                break;
            }
        } while (System.currentTimeMillis() < waitUntil);
    }
}
