// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQInvalidTransientQueueUseException extends ActiveMQException
{
    private static final long serialVersionUID = -405552292451883063L;
    
    public ActiveMQInvalidTransientQueueUseException() {
        super(ActiveMQExceptionType.INVALID_TRANSIENT_QUEUE_USE);
    }
    
    public ActiveMQInvalidTransientQueueUseException(final String msg) {
        super(ActiveMQExceptionType.INVALID_TRANSIENT_QUEUE_USE, msg);
    }
}
