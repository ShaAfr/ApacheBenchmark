// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

import java.nio.ByteBuffer;
import org.apache.activemq.artemis.utils.ByteUtil;
import org.apache.activemq.artemis.logs.ActiveMQUtilBundle;
import io.netty.buffer.ByteBuf;
import java.util.Collections;
import org.apache.activemq.artemis.api.core.ActiveMQPropertyConversionException;
import java.util.Iterator;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import org.apache.activemq.artemis.api.core.SimpleString;

public class TypedProperties
{
    private static final SimpleString AMQ_PROPNAME;
    private Map<SimpleString, PropertyValue> properties;
    private volatile int size;
    private boolean internalProperties;
    
    public TypedProperties() {
    }
    
    public int size() {
        return this.properties.size();
    }
    
    public int getMemoryOffset() {
        return (this.properties == null) ? 0 : (this.size + 8 * this.properties.size());
    }
    
    public TypedProperties(final TypedProperties other) {
        this.properties = ((other.properties == null) ? null : new HashMap<SimpleString, PropertyValue>(other.properties));
        this.size = other.size;
    }
    
    public boolean hasInternalProperties() {
        return this.internalProperties;
    }
    
    public void putBooleanProperty(final SimpleString key, final boolean value) {
        this.checkCreateProperties();
        this.doPutValue(key, of(value));
    }
    
    public void putByteProperty(final SimpleString key, final byte value) {
        this.checkCreateProperties();
        this.doPutValue(key, valueOf(value));
    }
    
    public void putBytesProperty(final SimpleString key, final byte[] value) {
        this.checkCreateProperties();
        this.doPutValue(key, (value == null) ? NullValue.INSTANCE : new BytesValue(value));
    }
    
    public void putShortProperty(final SimpleString key, final short value) {
        this.checkCreateProperties();
        this.doPutValue(key, new ShortValue(value));
    }
    
    public void putIntProperty(final SimpleString key, final int value) {
        this.checkCreateProperties();
        this.doPutValue(key, new IntValue(value));
    }
    
    public void putLongProperty(final SimpleString key, final long value) {
        this.checkCreateProperties();
        this.doPutValue(key, new LongValue(value));
    }
    
    public void putFloatProperty(final SimpleString key, final float value) {
        this.checkCreateProperties();
        this.doPutValue(key, new FloatValue(value));
    }
    
    public void putDoubleProperty(final SimpleString key, final double value) {
        this.checkCreateProperties();
        this.doPutValue(key, new DoubleValue(value));
    }
    
    public void putSimpleStringProperty(final SimpleString key, final SimpleString value) {
        this.checkCreateProperties();
        this.doPutValue(key, (value == null) ? NullValue.INSTANCE : new StringValue(value));
    }
    
    public void putNullValue(final SimpleString key) {
        this.checkCreateProperties();
        this.doPutValue(key, NullValue.INSTANCE);
    }
    
    public void putCharProperty(final SimpleString key, final char value) {
        this.checkCreateProperties();
        this.doPutValue(key, new CharValue(value));
    }
    
    public void putTypedProperties(final TypedProperties otherProps) {
        if (otherProps == null || otherProps.properties == null) {
            return;
        }
        this.checkCreateProperties();
        final Set<Map.Entry<SimpleString, PropertyValue>> otherEntries = otherProps.properties.entrySet();
        for (final Map.Entry<SimpleString, PropertyValue> otherEntry : otherEntries) {
            this.doPutValue(otherEntry.getKey(), otherEntry.getValue());
        }
    }
    
    public Object getProperty(final SimpleString key) {
        return this.doGetProperty(key);
    }
    
    public Boolean getBooleanProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return Boolean.valueOf(null);
        }
        if (value instanceof Boolean) {
            return (Boolean)value;
        }
        if (value instanceof SimpleString) {
            return Boolean.valueOf(((SimpleString)value).toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Byte getByteProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return Byte.valueOf(null);
        }
        if (value instanceof Byte) {
            return (Byte)value;
        }
        if (value instanceof SimpleString) {
            return Byte.parseByte(((SimpleString)value).toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Character getCharProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            throw new NullPointerException("Invalid conversion: " + (Object)key);
        }
        if (value instanceof Character) {
            return (Character)value;
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public byte[] getBytesProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return null;
        }
        if (value instanceof byte[]) {
            return (byte[])value;
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Double getDoubleProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return Double.valueOf(null);
        }
        if (value instanceof Float) {
            return (double)value;
        }
        if (value instanceof Double) {
            return (Double)value;
        }
        if (value instanceof SimpleString) {
            return Double.parseDouble(((SimpleString)value).toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Integer getIntProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return Integer.valueOf(null);
        }
        if (value instanceof Integer) {
            return (Integer)value;
        }
        if (value instanceof Byte) {
            return (int)value;
        }
        if (value instanceof Short) {
            return (int)value;
        }
        if (value instanceof SimpleString) {
            return Integer.parseInt(((SimpleString)value).toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Long getLongProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return Long.valueOf(null);
        }
        if (value instanceof Long) {
            return (Long)value;
        }
        if (value instanceof Byte) {
            return (long)value;
        }
        if (value instanceof Short) {
            return (long)value;
        }
        if (value instanceof Integer) {
            return (long)value;
        }
        if (value instanceof SimpleString) {
            return Long.parseLong(((SimpleString)value).toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Short getShortProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return Short.valueOf(null);
        }
        if (value instanceof Byte) {
            return (short)value;
        }
        if (value instanceof Short) {
            return (Short)value;
        }
        if (value instanceof SimpleString) {
            return Short.parseShort(((SimpleString)value).toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Float getFloatProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return Float.valueOf(null);
        }
        if (value instanceof Float) {
            return (Float)value;
        }
        if (value instanceof SimpleString) {
            return Float.parseFloat(((SimpleString)value).toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public SimpleString getSimpleStringProperty(final SimpleString key) throws ActiveMQPropertyConversionException {
        final Object value = this.doGetProperty(key);
        if (value == null) {
            return null;
        }
        if (value instanceof SimpleString) {
            return (SimpleString)value;
        }
        if (value instanceof Boolean) {
            return new SimpleString(value.toString());
        }
        if (value instanceof Character) {
            return new SimpleString(value.toString());
        }
        if (value instanceof Byte) {
            return new SimpleString(value.toString());
        }
        if (value instanceof Short) {
            return new SimpleString(value.toString());
        }
        if (value instanceof Integer) {
            return new SimpleString(value.toString());
        }
        if (value instanceof Long) {
            return new SimpleString(value.toString());
        }
        if (value instanceof Float) {
            return new SimpleString(value.toString());
        }
        if (value instanceof Double) {
            return new SimpleString(value.toString());
        }
        throw new ActiveMQPropertyConversionException("Invalid conversion: " + (Object)key);
    }
    
    public Object removeProperty(final SimpleString key) {
        return this.doRemoveProperty(key);
    }
    
    public boolean containsProperty(final SimpleString key) {
        return this.size != 0 && this.properties.containsKey(key);
    }
    
    public Set<SimpleString> getPropertyNames() {
        if (this.size == 0) {
            return Collections.emptySet();
        }
        return this.properties.keySet();
    }
    
    public synchronized void decode(final ByteBuf buffer) {
        final byte b = buffer.readByte();
        if (b == 0) {
            this.properties = null;
        }
        else {
            final int numHeaders = buffer.readInt();
            this.properties = new HashMap<SimpleString, PropertyValue>(numHeaders, 1.0f);
            this.size = 0;
            for (int i = 0; i < numHeaders; ++i) {
                final int len = buffer.readInt();
                final byte[] data = new byte[len];
                buffer.readBytes(data);
                final SimpleString key = new SimpleString(data);
                final byte type = buffer.readByte();
                switch (type) {
                    case 0: {
                        final PropertyValue val = NullValue.INSTANCE;
                        this.doPutValue(key, val);
                        break;
                    }
                    case 11: {
                        final PropertyValue val = new CharValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    case 2: {
                        final PropertyValue val = of(buffer.readBoolean());
                        this.doPutValue(key, val);
                        break;
                    }
                    case 3: {
                        final PropertyValue val = valueOf(buffer.readByte());
                        this.doPutValue(key, val);
                        break;
                    }
                    case 4: {
                        final PropertyValue val = new BytesValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    case 5: {
                        final PropertyValue val = new ShortValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    case 6: {
                        final PropertyValue val = new IntValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    case 7: {
                        final PropertyValue val = new LongValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    case 8: {
                        final PropertyValue val = new FloatValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    case 9: {
                        final PropertyValue val = new DoubleValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    case 10: {
                        final PropertyValue val = new StringValue(buffer);
                        this.doPutValue(key, val);
                        break;
                    }
                    default: {
                        throw ActiveMQUtilBundle.BUNDLE.invalidType(type);
                    }
                }
            }
        }
    }
    
    public synchronized void encode(final ByteBuf buffer) {
        if (this.properties == null) {
            buffer.writeByte(0);
        }
        else {
            buffer.writeByte(1);
            buffer.writeInt(this.properties.size());
            final byte[] data;
            this.properties.forEach((key, value) -> {
                data = key.getData();
                buffer.writeInt(data.length);
                buffer.writeBytes(data);
                value.write(buffer);
            });
        }
    }
    
    public int getEncodeSize() {
        if (this.properties == null) {
            return 1;
        }
        return 5 + this.size;
    }
    
    public void clear() {
        if (this.properties != null) {
            this.properties.clear();
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TypedProperties[");
        if (this.properties != null) {
            final Iterator<Map.Entry<SimpleString, PropertyValue>> iter = this.properties.entrySet().iterator();
            while (iter.hasNext()) {
                final Map.Entry<SimpleString, PropertyValue> iterItem = iter.next();
                sb.append((Object)iterItem.getKey() + "=");
                final Object theValue = iterItem.getValue().getValue();
                if (theValue == null) {
                    sb.append("NULL-value");
                }
                else if (theValue instanceof byte[]) {
                    sb.append("[" + ByteUtil.maxString(ByteUtil.bytesToHex((byte[])theValue, 2), 150) + ")");
                    if (iterItem.getKey().toString().startsWith("_AMQ_ROUTE_TO")) {
                        sb.append(",bytesAsLongs(");
                        try {
                            final ByteBuffer buff = ByteBuffer.wrap((byte[])theValue);
                            while (buff.hasRemaining()) {
                                final long bindingID = buff.getLong();
                                sb.append(bindingID);
                                if (buff.hasRemaining()) {
                                    sb.append(",");
                                }
                            }
                        }
                        catch (Throwable e) {
                            sb.append("error-converting-longs=" + e.getMessage());
                        }
                        sb.append("]");
                    }
                }
                else {
                    sb.append(theValue.toString());
                }
                if (iter.hasNext()) {
                    sb.append(",");
                }
            }
        }
        return sb.append("]").toString();
    }
    
    private void checkCreateProperties() {
        if (this.properties == null) {
            this.properties = new HashMap<SimpleString, PropertyValue>();
        }
    }
    
    private synchronized void doPutValue(final SimpleString key, final PropertyValue value) {
        if (key.startsWith(TypedProperties.AMQ_PROPNAME)) {
            this.internalProperties = true;
        }
        final PropertyValue oldValue = this.properties.put(key, value);
        if (oldValue != null) {
            this.size += value.encodeSize() - oldValue.encodeSize();
        }
        else {
            this.size += SimpleString.sizeofString(key) + value.encodeSize();
        }
    }
    
    private synchronized Object doRemoveProperty(final SimpleString key) {
        if (this.properties == null) {
            return null;
        }
        final PropertyValue val = this.properties.remove(key);
        if (val == null) {
            return null;
        }
        this.size -= SimpleString.sizeofString(key) + val.encodeSize();
        return val.getValue();
    }
    
    private synchronized Object doGetProperty(final Object key) {
        if (this.size == 0) {
            return null;
        }
        final PropertyValue val = this.properties.get(key);
        if (val == null) {
            return null;
        }
        return val.getValue();
    }
    
    public boolean isEmpty() {
        return this.properties.isEmpty();
    }
    
    public Map<String, Object> getMap() {
        final Map<String, Object> m = new HashMap<String, Object>();
        for (final Map.Entry<SimpleString, PropertyValue> entry : this.properties.entrySet()) {
            final Object val = entry.getValue().getValue();
            if (val instanceof SimpleString) {
                m.put(entry.getKey().toString(), ((SimpleString)val).toString());
            }
            else {
                m.put(entry.getKey().toString(), val);
            }
        }
        return m;
    }
    
    public static void setObjectProperty(final SimpleString key, final Object value, final TypedProperties properties) {
        if (value == null) {
            properties.putNullValue(key);
        }
        else if (value instanceof Boolean) {
            properties.putBooleanProperty(key, (boolean)value);
        }
        else if (value instanceof Byte) {
            properties.putByteProperty(key, (byte)value);
        }
        else if (value instanceof Character) {
            properties.putCharProperty(key, (char)value);
        }
        else if (value instanceof Short) {
            properties.putShortProperty(key, (short)value);
        }
        else if (value instanceof Integer) {
            properties.putIntProperty(key, (int)value);
        }
        else if (value instanceof Long) {
            properties.putLongProperty(key, (long)value);
        }
        else if (value instanceof Float) {
            properties.putFloatProperty(key, (float)value);
        }
        else if (value instanceof Double) {
            properties.putDoubleProperty(key, (double)value);
        }
        else if (value instanceof String) {
            properties.putSimpleStringProperty(key, new SimpleString((String)value));
        }
        else if (value instanceof SimpleString) {
            properties.putSimpleStringProperty(key, (SimpleString)value);
        }
        else {
            if (!(value instanceof byte[])) {
                throw new ActiveMQPropertyConversionException(value.getClass() + " is not a valid property type");
            }
            properties.putBytesProperty(key, (byte[])value);
        }
    }
    
    static {
        AMQ_PROPNAME = new SimpleString("_AMQ_");
    }
    
    private abstract static class PropertyValue
    {
        abstract Object getValue();
        
        abstract void write(final ByteBuf p0);
        
        abstract int encodeSize();
        
        @Override
        public String toString() {
            return "" + this.getValue();
        }
    }
    
    private static final class NullValue extends PropertyValue
    {
        private static final NullValue INSTANCE;
        
        public Object getValue() {
            return null;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(0);
        }
        
        public int encodeSize() {
            return 1;
        }
        
        static {
            INSTANCE = new NullValue();
        }
    }
    
    private static final class BooleanValue extends PropertyValue
    {
        private static final int ENCODE_SIZE = 2;
        private static final BooleanValue TRUE;
        private static final BooleanValue FALSE;
        private final boolean val;
        private final Boolean objVal;
        
        private BooleanValue(final boolean val) {
            this.val = val;
            this.objVal = val;
        }
        
        private static BooleanValue of(final boolean val) {
            if (val) {
                return BooleanValue.TRUE;
            }
            return BooleanValue.FALSE;
        }
        
        public Object getValue() {
            return this.objVal;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(2);
            buffer.writeBoolean(this.val);
        }
        
        public int encodeSize() {
            return 2;
        }
        
        static {
            TRUE = new BooleanValue(true);
            FALSE = new BooleanValue(false);
        }
    }
    
    private static final class ByteValue extends PropertyValue
    {
        private static final int ENCODE_SIZE = 2;
        private static final ByteValue[] VALUES;
        private final byte val;
        private final Byte objectVal;
        
        private static ByteValue valueOf(final byte b) {
            final int offset = 128;
            final int index = b + 128;
            final ByteValue value = ByteValue.VALUES[index];
            if (value == null) {
                return ByteValue.VALUES[index] = new ByteValue(b);
            }
            return value;
        }
        
        private ByteValue(final byte val) {
            this.val = val;
            this.objectVal = val;
        }
        
        public Object getValue() {
            return this.objectVal;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(3);
            buffer.writeByte((int)this.val);
        }
        
        public int encodeSize() {
            return 2;
        }
        
        static {
            VALUES = new ByteValue[256];
        }
    }
    
    private static final class BytesValue extends PropertyValue
    {
        final byte[] val;
        
        private BytesValue(final byte[] val) {
            this.val = val;
        }
        
        private BytesValue(final ByteBuf buffer) {
            final int len = buffer.readInt();
            buffer.readBytes(this.val = new byte[len]);
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(4);
            buffer.writeInt(this.val.length);
            buffer.writeBytes(this.val);
        }
        
        public int encodeSize() {
            return 5 + this.val.length;
        }
    }
    
    private static final class ShortValue extends PropertyValue
    {
        final short val;
        
        private ShortValue(final short val) {
            this.val = val;
        }
        
        private ShortValue(final ByteBuf buffer) {
            this.val = buffer.readShort();
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(5);
            buffer.writeShort((int)this.val);
        }
        
        public int encodeSize() {
            return 3;
        }
    }
    
    private static final class IntValue extends PropertyValue
    {
        final int val;
        
        private IntValue(final int val) {
            this.val = val;
        }
        
        private IntValue(final ByteBuf buffer) {
            this.val = buffer.readInt();
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(6);
            buffer.writeInt(this.val);
        }
        
        public int encodeSize() {
            return 5;
        }
    }
    
    private static final class LongValue extends PropertyValue
    {
        final long val;
        
        private LongValue(final long val) {
            this.val = val;
        }
        
        private LongValue(final ByteBuf buffer) {
            this.val = buffer.readLong();
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(7);
            buffer.writeLong(this.val);
        }
        
        public int encodeSize() {
            return 9;
        }
    }
    
    private static final class FloatValue extends PropertyValue
    {
        final float val;
        
        private FloatValue(final float val) {
            this.val = val;
        }
        
        private FloatValue(final ByteBuf buffer) {
            this.val = Float.intBitsToFloat(buffer.readInt());
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(8);
            buffer.writeInt(Float.floatToIntBits(this.val));
        }
        
        public int encodeSize() {
            return 5;
        }
    }
    
    private static final class DoubleValue extends PropertyValue
    {
        final double val;
        
        private DoubleValue(final double val) {
            this.val = val;
        }
        
        private DoubleValue(final ByteBuf buffer) {
            this.val = Double.longBitsToDouble(buffer.readLong());
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(9);
            buffer.writeLong(Double.doubleToLongBits(this.val));
        }
        
        public int encodeSize() {
            return 9;
        }
    }
    
    private static final class CharValue extends PropertyValue
    {
        final char val;
        
        private CharValue(final char val) {
            this.val = val;
        }
        
        private CharValue(final ByteBuf buffer) {
            this.val = (char)buffer.readShort();
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(11);
            buffer.writeShort((int)(short)this.val);
        }
        
        public int encodeSize() {
            return 3;
        }
    }
    
    private static final class StringValue extends PropertyValue
    {
        final SimpleString val;
        
        private StringValue(final SimpleString val) {
            this.val = val;
        }
        
        private StringValue(final ByteBuf buffer) {
            this.val = SimpleString.readSimpleString(buffer);
        }
        
        public Object getValue() {
            return this.val;
        }
        
        public void write(final ByteBuf buffer) {
            buffer.writeByte(10);
            SimpleString.writeSimpleString(buffer, this.val);
        }
        
        public int encodeSize() {
            return 1 + SimpleString.sizeofString(this.val);
        }
    }
}
