// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.uri;

import java.util.Iterator;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.net.URI;

public abstract class URISchema<T, P>
{
    private URIFactory<T, P> parentFactory;
    
    public abstract String getSchemaName();
    
    public T newObject(final URI uri, final P param) throws Exception {
        return this.newObject(uri, null, param);
    }
    
    public void populateObject(final URI uri, final T bean) throws Exception {
        BeanSupport.setData(uri, bean, parseQuery(uri.getQuery(), null));
    }
    
    public URI newURI(final T bean) throws Exception {
        return this.internalNewURI(bean);
    }
    
    void setFactory(final URIFactory<T, P> factory) {
        this.parentFactory = factory;
    }
    
    protected URIFactory<T, P> getFactory() {
        return this.parentFactory;
    }
    
    protected String getHost(URI uri) {
        final URI defaultFactory = this.getDefaultURI();
        if (defaultFactory != null && uri.getHost() == null && defaultFactory.getScheme().equals(uri.getScheme())) {
            uri = defaultFactory;
        }
        return uri.getHost();
    }
    
    protected URI getDefaultURI() {
        final URIFactory<T, P> factory = this.getFactory();
        if (factory == null) {
            return null;
        }
        return factory.getDefaultURI();
    }
    
    protected int getPort(URI uri) {
        final URI defaultFactory = this.getDefaultURI();
        if (defaultFactory != null && uri.getPort() < 0 && defaultFactory.getScheme().equals(uri.getScheme())) {
            uri = defaultFactory;
        }
        return uri.getPort();
    }
    
    public T newObject(final URI uri, final Map<String, String> propertyOverrides, final P param) throws Exception {
        return this.internalNewObject(uri, parseQuery(uri.getQuery(), propertyOverrides), param);
    }
    
    protected abstract T internalNewObject(final URI p0, final Map<String, String> p1, final P p2) throws Exception;
    
    protected URI internalNewURI(final T bean) throws Exception {
        final String query = BeanSupport.getData(null, bean);
        return new URI(this.getSchemaName(), null, "//", query, null);
    }
    
    public static Map<String, String> parseQuery(final String uri, final Map<String, String> propertyOverrides) throws URISyntaxException {
        try {
            final Map<String, String> rc = new HashMap<String, String>();
            if (uri != null && !uri.isEmpty()) {
                final String[] split;
                final String[] parameters = split = uri.split("&");
                for (final String parameter : split) {
                    final int p = parameter.indexOf("=");
                    if (p >= 0) {
                        final String name = BeanSupport.decodeURI(parameter.substring(0, p));
                        final String value = BeanSupport.decodeURI(parameter.substring(p + 1));
                        rc.put(name, value);
                    }
                    else if (!parameter.trim().isEmpty()) {
                        rc.put(parameter, null);
                    }
                }
            }
            if (propertyOverrides != null) {
                for (final Map.Entry<String, String> entry : propertyOverrides.entrySet()) {
                    rc.put(entry.getKey(), entry.getValue());
                }
            }
            return rc;
        }
        catch (UnsupportedEncodingException e) {
            throw (URISyntaxException)new URISyntaxException(e.toString(), "Invalid encoding").initCause(e);
        }
    }
    
    protected String printQuery(final Map<String, String> query) {
        final StringBuffer buffer = new StringBuffer();
        for (final Map.Entry<String, String> entry : query.entrySet()) {
            buffer.append(entry.getKey() + "=" + entry.getValue());
            buffer.append("\n");
        }
        return buffer.toString();
    }
}
