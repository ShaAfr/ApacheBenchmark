// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import org.apache.activemq.artemis.api.core.ActiveMQBuffers;
import org.apache.activemq.artemis.api.core.ActiveMQBuffer;
import org.apache.activemq.artemis.api.core.SimpleString;
import java.util.UUID;
import java.util.Random;

public class RandomUtil
{
    protected static final Random random;
    
    public static Random getRandom() {
        return RandomUtil.random;
    }
    
    public static String randomString() {
        return UUID.randomUUID().toString();
    }
    
    public static SimpleString randomSimpleString() {
        return new SimpleString(randomString());
    }
    
    public static char randomChar() {
        return randomString().charAt(0);
    }
    
    public static long randomLong() {
        return RandomUtil.random.nextLong();
    }
    
    public static long randomPositiveLong() {
        return Math.abs(randomLong());
    }
    
    public static int randomInt() {
        return RandomUtil.random.nextInt();
    }
    
    public static int randomPositiveInt() {
        return Math.abs(randomInt());
    }
    
    public static ActiveMQBuffer randomBuffer(final int size, final long... data) {
        final ActiveMQBuffer buffer = ActiveMQBuffers.fixedBuffer(size + 8 * data.length);
        for (final long d : data) {
            buffer.writeLong(d);
        }
        for (int i = 0; i < size; ++i) {
            buffer.writeByte(randomByte());
        }
        return buffer;
    }
    
    public static int randomInterval(final int min, final int max) {
        return min + RandomUtil.random.nextInt(max - min);
    }
    
    public static int randomMax(final int max) {
        int value = randomPositiveInt() % max;
        if (value == 0) {
            value = max;
        }
        return value;
    }
    
    public static int randomPort() {
        return RandomUtil.random.nextInt(65536);
    }
    
    public static short randomShort() {
        return (short)RandomUtil.random.nextInt(32767);
    }
    
    public static byte randomByte() {
        return RandomUtil.random.nextInt().byteValue();
    }
    
    public static boolean randomBoolean() {
        return RandomUtil.random.nextBoolean();
    }
    
    public static byte[] randomBytes() {
        return randomString().getBytes();
    }
    
    public static byte[] randomBytes(final int length) {
        final byte[] bytes = new byte[length];
        for (int i = 0; i < bytes.length; ++i) {
            bytes[i] = randomByte();
        }
        return bytes;
    }
    
    public static double randomDouble() {
        return RandomUtil.random.nextDouble();
    }
    
    public static float randomFloat() {
        return RandomUtil.random.nextFloat();
    }
    
    static {
        random = new Random();
    }
}
