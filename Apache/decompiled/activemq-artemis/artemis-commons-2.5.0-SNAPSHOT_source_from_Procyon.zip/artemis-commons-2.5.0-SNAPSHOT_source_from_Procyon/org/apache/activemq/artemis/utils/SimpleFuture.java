// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.concurrent.TimeoutException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public interface SimpleFuture<V> extends Future<V>
{
    public static final SimpleFuture dumb = new SimpleFuture() {
        @Override
        public void fail(final Throwable e) {
        }
        
        @Override
        public void set(final Object o) {
        }
        
        @Override
        public boolean cancel(final boolean mayInterruptIfRunning) {
            return false;
        }
        
        @Override
        public boolean isCancelled() {
            return false;
        }
        
        @Override
        public boolean isDone() {
            return false;
        }
        
        @Override
        public Object get() throws InterruptedException, ExecutionException {
            return null;
        }
        
        @Override
        public Object get(final long timeout, final TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            return null;
        }
    };
    
    default SimpleFuture dumb() {
        return SimpleFuture.dumb;
    }
    
    void fail(final Throwable p0);
    
    void set(final V p0);
}
