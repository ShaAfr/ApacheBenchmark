// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.core.server;

import java.net.URLConnection;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.IOException;
import java.net.Inet6Address;
import java.util.Iterator;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.apache.activemq.artemis.utils.ActiveMQThreadFactory;
import org.apache.activemq.artemis.logs.ActiveMQUtilLogger;
import org.apache.activemq.artemis.utils.collections.ConcurrentHashSet;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.net.NetworkInterface;
import java.net.URL;
import java.net.InetAddress;
import java.util.Set;
import org.jboss.logging.Logger;

public class NetworkHealthCheck extends ActiveMQScheduledComponent
{
    private static final Logger logger;
    private final Set<ActiveMQComponent> componentList;
    private final Set<InetAddress> addresses;
    private final Set<URL> urls;
    private NetworkInterface networkInterface;
    public static final String IPV6_DEFAULT_COMMAND = "ping6 -c 1 %2$s";
    public static final String IPV4_DEFAULT_COMMAND = "ping -c 1 -t %d %s";
    private String ipv4Command;
    private String ipv6Command;
    private boolean ignoreLoopback;
    private int networkTimeout;
    
    public NetworkHealthCheck() {
        this(null, 1000L, 1000);
    }
    
    public NetworkHealthCheck(final String nicName, final long checkPeriod, final int networkTimeout) {
        super(null, null, checkPeriod, TimeUnit.MILLISECONDS, false);
        this.componentList = new ConcurrentHashSet<ActiveMQComponent>();
        this.addresses = new ConcurrentHashSet<InetAddress>();
        this.urls = new ConcurrentHashSet<URL>();
        this.ipv4Command = "ping -c 1 -t %d %s";
        this.ipv6Command = "ping6 -c 1 %2$s";
        this.ignoreLoopback = false;
        this.networkTimeout = networkTimeout;
        this.setNICName(nicName);
    }
    
    public NetworkHealthCheck setNICName(final String nicName) {
        NetworkInterface netToUse;
        try {
            if (nicName != null) {
                netToUse = NetworkInterface.getByName(nicName);
            }
            else {
                netToUse = null;
            }
        }
        catch (Exception e) {
            ActiveMQUtilLogger.LOGGER.failedToSetNIC(e, (nicName == null) ? " " : nicName);
            netToUse = null;
        }
        this.networkInterface = netToUse;
        return this;
    }
    
    public boolean isIgnoreLoopback() {
        return this.ignoreLoopback;
    }
    
    public NetworkHealthCheck setIgnoreLoopback(final boolean ignoreLoopback) {
        this.ignoreLoopback = ignoreLoopback;
        return this;
    }
    
    public Set<InetAddress> getAddresses() {
        return this.addresses;
    }
    
    public Set<URL> getUrls() {
        return this.urls;
    }
    
    public String getNICName() {
        if (this.networkInterface != null) {
            return this.networkInterface.getName();
        }
        return null;
    }
    
    public NetworkHealthCheck parseAddressList(final String addressList) {
        if (addressList != null) {
            final String[] split;
            final String[] addresses = split = addressList.split(",");
            for (final String address : split) {
                if (!address.trim().isEmpty()) {
                    try {
                        this.addAddress(InetAddress.getByName(address.trim()));
                    }
                    catch (Exception e) {
                        ActiveMQUtilLogger.LOGGER.failedToParseAddressList(e, addressList);
                    }
                }
            }
        }
        return this;
    }
    
    public NetworkHealthCheck parseURIList(final String addressList) {
        if (addressList != null) {
            final String[] split;
            final String[] addresses = split = addressList.split(",");
            for (final String address : split) {
                if (!address.trim().isEmpty()) {
                    try {
                        this.addURL(new URL(address.trim()));
                    }
                    catch (Exception e) {
                        ActiveMQUtilLogger.LOGGER.failedToParseUrlList(e, addressList);
                    }
                }
            }
        }
        return this;
    }
    
    @Override
    protected ActiveMQThreadFactory getThreadFactory() {
        return new ActiveMQThreadFactory("NetworkChecker", "Network-Checker-", false, this.getThisClassLoader());
    }
    
    private ClassLoader getThisClassLoader() {
        return AccessController.doPrivileged((PrivilegedAction<ClassLoader>)new PrivilegedAction<ClassLoader>() {
            @Override
            public ClassLoader run() {
                return NetworkHealthCheck.this.getClass().getClassLoader();
            }
        });
    }
    
    public int getNetworkTimeout() {
        return this.networkTimeout;
    }
    
    @Override
    public NetworkHealthCheck setPeriod(final long period) {
        super.setPeriod(period);
        return this;
    }
    
    @Override
    public NetworkHealthCheck setTimeUnit(final TimeUnit timeUnit) {
        super.setTimeUnit(timeUnit);
        return this;
    }
    
    public NetworkHealthCheck setNetworkTimeout(final int networkTimeout) {
        this.networkTimeout = networkTimeout;
        return this;
    }
    
    public NetworkHealthCheck addComponent(final ActiveMQComponent component) {
        this.componentList.add(component);
        this.checkStart();
        return this;
    }
    
    public NetworkHealthCheck clearComponents() {
        this.componentList.clear();
        return this;
    }
    
    public NetworkHealthCheck addAddress(final InetAddress address) {
        if (!this.check(address)) {
            ActiveMQUtilLogger.LOGGER.addressWasntReacheable(address.toString());
        }
        if (!this.ignoreLoopback && address.isLoopbackAddress()) {
            ActiveMQUtilLogger.LOGGER.addressloopback(address.toString());
        }
        else {
            this.addresses.add(address);
            this.checkStart();
        }
        return this;
    }
    
    public NetworkHealthCheck removeAddress(final InetAddress address) {
        this.addresses.remove(address);
        return this;
    }
    
    public NetworkHealthCheck clearAddresses() {
        this.addresses.clear();
        return this;
    }
    
    public NetworkHealthCheck addURL(final URL url) {
        if (!this.check(url)) {
            ActiveMQUtilLogger.LOGGER.urlWasntReacheable(url.toString());
        }
        this.urls.add(url);
        this.checkStart();
        return this;
    }
    
    public NetworkHealthCheck removeURL(final URL url) {
        this.urls.remove(url);
        return this;
    }
    
    public NetworkHealthCheck clearURL() {
        this.urls.clear();
        return this;
    }
    
    public String getIpv4Command() {
        return this.ipv4Command;
    }
    
    public NetworkHealthCheck setIpv4Command(final String ipv4Command) {
        this.ipv4Command = ipv4Command;
        return this;
    }
    
    public String getIpv6Command() {
        return this.ipv6Command;
    }
    
    public NetworkHealthCheck setIpv6Command(final String ipv6Command) {
        this.ipv6Command = ipv6Command;
        return this;
    }
    
    private void checkStart() {
        if (!this.isStarted() && (!this.addresses.isEmpty() || !this.urls.isEmpty()) && !this.componentList.isEmpty()) {
            this.start();
        }
    }
    
    @Override
    public void run() {
        final boolean healthy = this.check();
        if (healthy) {
            for (final ActiveMQComponent component : this.componentList) {
                if (!component.isStarted()) {
                    try {
                        ActiveMQUtilLogger.LOGGER.startingService(component.toString());
                        component.start();
                    }
                    catch (Exception e) {
                        ActiveMQUtilLogger.LOGGER.errorStartingComponent(e, component.toString());
                    }
                }
            }
        }
        else {
            for (final ActiveMQComponent component : this.componentList) {
                if (component.isStarted()) {
                    try {
                        ActiveMQUtilLogger.LOGGER.stoppingService(component.toString());
                        component.stop();
                    }
                    catch (Exception e) {
                        ActiveMQUtilLogger.LOGGER.errorStoppingComponent(e, component.toString());
                    }
                }
            }
        }
    }
    
    public boolean check() {
        if (this.isEmpty()) {
            return true;
        }
        for (final InetAddress address : this.addresses) {
            if (this.check(address)) {
                return true;
            }
        }
        for (final URL url : this.urls) {
            if (this.check(url)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean check(final InetAddress address) {
        try {
            if (address.isReachable(this.networkInterface, 0, this.networkTimeout)) {
                if (NetworkHealthCheck.logger.isTraceEnabled()) {
                    NetworkHealthCheck.logger.tracef(address + " OK", new Object[0]);
                }
                return true;
            }
            return this.purePing(address);
        }
        catch (Exception e) {
            ActiveMQUtilLogger.LOGGER.failedToCheckAddress(e, (address == null) ? " " : address.toString());
            return false;
        }
    }
    
    public boolean purePing(final InetAddress address) throws IOException, InterruptedException {
        final long timeout = Math.max(1L, TimeUnit.MILLISECONDS.toSeconds(this.networkTimeout));
        if (NetworkHealthCheck.logger.isTraceEnabled()) {
            NetworkHealthCheck.logger.trace((Object)("purePing on canonical address " + address.getCanonicalHostName()));
        }
        ProcessBuilder processBuilder;
        if (address instanceof Inet6Address) {
            processBuilder = this.buildProcess(this.ipv6Command, timeout, address.getCanonicalHostName());
        }
        else {
            processBuilder = this.buildProcess(this.ipv4Command, timeout, address.getCanonicalHostName());
        }
        final Process pingProcess = processBuilder.start();
        this.readStream(pingProcess.getInputStream(), false);
        this.readStream(pingProcess.getErrorStream(), true);
        return pingProcess.waitFor() == 0;
    }
    
    private ProcessBuilder buildProcess(final String expressionCommand, final long timeout, final String host) {
        final String command = String.format(expressionCommand, timeout, host);
        if (NetworkHealthCheck.logger.isDebugEnabled()) {
            NetworkHealthCheck.logger.debug((Object)("executing ping:: " + command));
        }
        final ProcessBuilder builder = new ProcessBuilder(command.split(" "));
        return builder;
    }
    
    private void readStream(final InputStream stream, final boolean error) throws IOException {
        final BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        String inputLine;
        while ((inputLine = reader.readLine()) != null) {
            if (error) {
                ActiveMQUtilLogger.LOGGER.failedToReadFromStream(inputLine);
            }
            else {
                NetworkHealthCheck.logger.trace((Object)inputLine);
            }
        }
        reader.close();
    }
    
    public boolean check(final URL url) {
        try {
            final URLConnection connection = url.openConnection();
            connection.setReadTimeout(this.networkTimeout);
            final InputStream is = connection.getInputStream();
            is.close();
            return true;
        }
        catch (Exception e) {
            ActiveMQUtilLogger.LOGGER.failedToCheckURL(e, (url == null) ? " " : url.toString());
            return false;
        }
    }
    
    public boolean isEmpty() {
        return this.addresses.isEmpty() && this.urls.isEmpty();
    }
    
    static {
        logger = Logger.getLogger((Class)NetworkHealthCheck.class);
    }
}
