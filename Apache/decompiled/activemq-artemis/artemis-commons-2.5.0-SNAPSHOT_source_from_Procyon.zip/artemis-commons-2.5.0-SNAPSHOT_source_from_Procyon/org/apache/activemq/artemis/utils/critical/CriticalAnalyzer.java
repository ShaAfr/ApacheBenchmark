// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.critical;

import java.util.concurrent.TimeUnit;
import org.apache.activemq.artemis.core.server.ActiveMQComponent;

public interface CriticalAnalyzer extends ActiveMQComponent
{
    default void clear() {
    }
    
    boolean isMeasuring();
    
    void add(final CriticalComponent p0);
    
    void remove(final CriticalComponent p0);
    
    CriticalAnalyzer setCheckTime(final long p0, final TimeUnit p1);
    
    long getCheckTimeNanoSeconds();
    
    CriticalAnalyzer setTimeout(final long p0, final TimeUnit p1);
    
    long getTimeout(final TimeUnit p0);
    
    CriticalAnalyzer addAction(final CriticalAction p0);
    
    void check();
}
