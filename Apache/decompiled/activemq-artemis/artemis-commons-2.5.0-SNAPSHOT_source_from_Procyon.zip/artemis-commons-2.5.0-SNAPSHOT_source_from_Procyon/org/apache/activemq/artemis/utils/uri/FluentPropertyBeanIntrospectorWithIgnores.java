// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.uri;

import java.util.Locale;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.beans.IntrospectionException;
import org.apache.commons.beanutils.IntrospectionContext;
import org.apache.activemq.artemis.api.core.Pair;
import org.apache.activemq.artemis.utils.collections.ConcurrentHashSet;
import org.jboss.logging.Logger;
import org.apache.commons.beanutils.FluentPropertyBeanIntrospector;

public class FluentPropertyBeanIntrospectorWithIgnores extends FluentPropertyBeanIntrospector
{
    static Logger logger;
    private static ConcurrentHashSet<Pair<String, String>> ignores;
    
    public static void addIgnore(final String className, final String propertyName) {
        FluentPropertyBeanIntrospectorWithIgnores.logger.trace((Object)("Adding ignore on " + className + "/" + propertyName));
        FluentPropertyBeanIntrospectorWithIgnores.ignores.add(new Pair<String, String>(className, propertyName));
    }
    
    public static boolean isIgnored(final String className, final String propertyName) {
        return FluentPropertyBeanIntrospectorWithIgnores.ignores.contains(new Pair(className, propertyName));
    }
    
    public void introspect(final IntrospectionContext icontext) throws IntrospectionException {
        for (final Method m : icontext.getTargetClass().getMethods()) {
            if (m.getName().startsWith(this.getWriteMethodPrefix())) {
                final String propertyName = this.propertyName(m);
                final PropertyDescriptor pd = icontext.getPropertyDescriptor(propertyName);
                if (isIgnored(icontext.getTargetClass().getName(), m.getName())) {
                    FluentPropertyBeanIntrospectorWithIgnores.logger.trace((Object)(m.getName() + " Ignored for " + icontext.getTargetClass().getName()));
                }
                else {
                    try {
                        if (pd == null) {
                            icontext.addPropertyDescriptor(this.createFluentPropertyDescritor(m, propertyName));
                        }
                        else if (pd.getWriteMethod() == null) {
                            pd.setWriteMethod(m);
                        }
                    }
                    catch (IntrospectionException e) {
                        FluentPropertyBeanIntrospectorWithIgnores.logger.debug((Object)e.getMessage(), (Throwable)e);
                    }
                }
            }
        }
    }
    
    private PropertyDescriptor createFluentPropertyDescritor(final Method m, final String propertyName) throws IntrospectionException {
        return new PropertyDescriptor(this.propertyName(m), null, m);
    }
    
    private String propertyName(final Method m) {
        final String methodName = m.getName().substring(this.getWriteMethodPrefix().length());
        return (methodName.length() > 1) ? (Character.toLowerCase(methodName.charAt(0)) + methodName.substring(1)) : methodName.toLowerCase(Locale.ENGLISH);
    }
    
    static {
        FluentPropertyBeanIntrospectorWithIgnores.logger = Logger.getLogger((Class)FluentPropertyBeanIntrospectorWithIgnores.class);
        FluentPropertyBeanIntrospectorWithIgnores.ignores = new ConcurrentHashSet<Pair<String, String>>();
    }
}
