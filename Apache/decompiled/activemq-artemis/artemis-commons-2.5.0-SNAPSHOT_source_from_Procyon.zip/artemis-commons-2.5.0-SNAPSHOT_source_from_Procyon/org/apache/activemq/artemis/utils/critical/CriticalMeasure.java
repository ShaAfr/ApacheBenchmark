// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.critical;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;

public class CriticalMeasure
{
    private static final AtomicLongFieldUpdater<CriticalMeasure> TIME_ENTER_UPDATER;
    private static final AtomicLongFieldUpdater<CriticalMeasure> TIME_LEFT_UPDATER;
    private volatile long timeEnter;
    private volatile long timeLeft;
    
    public CriticalMeasure() {
        this.enterCritical();
        this.leaveCritical();
    }
    
    public void enterCritical() {
        CriticalMeasure.TIME_ENTER_UPDATER.lazySet(this, System.nanoTime());
    }
    
    public void leaveCritical() {
        CriticalMeasure.TIME_LEFT_UPDATER.lazySet(this, System.nanoTime());
    }
    
    public boolean isExpired(final long timeout) {
        final long timeLeft = CriticalMeasure.TIME_LEFT_UPDATER.get(this);
        final long timeEnter = CriticalMeasure.TIME_ENTER_UPDATER.get(this);
        return timeLeft - timeEnter < 0L && System.nanoTime() - timeEnter > timeout;
    }
    
    public long enterTime() {
        return CriticalMeasure.TIME_ENTER_UPDATER.get(this);
    }
    
    public long leaveTime() {
        return CriticalMeasure.TIME_LEFT_UPDATER.get(this);
    }
    
    static {
        TIME_ENTER_UPDATER = AtomicLongFieldUpdater.newUpdater(CriticalMeasure.class, "timeEnter");
        TIME_LEFT_UPDATER = AtomicLongFieldUpdater.newUpdater(CriticalMeasure.class, "timeLeft");
    }
}
