// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.actors;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import java.util.function.Consumer;
import java.util.concurrent.Executor;

public interface ArtemisExecutor extends Executor
{
    default ArtemisExecutor delegate(final Executor executor) {
        return new ArtemisExecutor() {
            @Override
            public void execute(final Runnable command) {
                executor.execute(command);
            }
        };
    }
    
    default int shutdownNow(final Consumer<? super Runnable> onPendingTask) {
        return 0;
    }
    
    default int shutdownNow() {
        return this.shutdownNow(t -> {});
    }
    
    default void shutdown() {
    }
    
    default boolean isFlushed() {
        final CountDownLatch latch = new CountDownLatch(1);
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                latch.countDown();
            }
        };
        this.execute(runnable);
        try {
            return latch.await(100L, TimeUnit.MILLISECONDS);
        }
        catch (InterruptedException e) {
            return false;
        }
    }
}
