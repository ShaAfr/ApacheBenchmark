// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

public interface ReferenceCounter
{
    int increment();
    
    int decrement();
}
