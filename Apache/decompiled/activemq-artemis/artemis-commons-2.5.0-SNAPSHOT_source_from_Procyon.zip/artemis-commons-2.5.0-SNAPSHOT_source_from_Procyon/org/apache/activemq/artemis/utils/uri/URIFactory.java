// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.uri;

import java.net.URISyntaxException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.net.URI;

public class URIFactory<T, P>
{
    private URI defaultURI;
    private final Map<String, URISchema<T, P>> schemas;
    
    public URIFactory() {
        this.schemas = new ConcurrentHashMap<String, URISchema<T, P>>();
    }
    
    public URI getDefaultURI() {
        return this.defaultURI;
    }
    
    public void setDefaultURI(final URI uri) {
        this.defaultURI = uri;
    }
    
    public void registerSchema(final URISchema<T, P> schemaFactory) {
        this.schemas.put(schemaFactory.getSchemaName(), schemaFactory);
        schemaFactory.setFactory(this);
    }
    
    public void removeSchema(final String schemaName) {
        this.schemas.remove(schemaName);
    }
    
    public URI expandURI(final String uriString) throws Exception {
        return this.normalise(uriString);
    }
    
    public T newObject(final URI uri, final P param) throws Exception {
        final URISchema<T, P> schemaFactory = this.schemas.get(uri.getScheme());
        if (schemaFactory == null) {
            throw new NullPointerException("Schema " + uri.getScheme() + " not found");
        }
        return schemaFactory.newObject(uri, param);
    }
    
    public T newObject(final URI uri, final Map<String, String> overrides, final P param) throws Exception {
        final URISchema<T, P> schemaFactory = this.schemas.get(uri.getScheme());
        if (schemaFactory == null) {
            throw new NullPointerException("Schema " + uri.getScheme() + " not found");
        }
        return schemaFactory.newObject(uri, overrides, param);
    }
    
    public T newObject(final String uri, final P param) throws Exception {
        return this.newObject(new URI(uri), param);
    }
    
    public void populateObject(final URI uri, final T bean) throws Exception {
        final URISchema<T, P> schemaFactory = this.schemas.get(uri.getScheme());
        if (schemaFactory == null) {
            throw new NullPointerException("Schema " + uri.getScheme() + " not found");
        }
        schemaFactory.populateObject(uri, bean);
    }
    
    public void populateObject(final String uri, final T bean) throws Exception {
        this.populateObject(new URI(uri), bean);
    }
    
    public URI createSchema(final String scheme, final T bean) throws Exception {
        final URISchema<T, P> schemaFactory = this.schemas.get(scheme);
        if (schemaFactory == null) {
            throw new NullPointerException("Schema " + scheme + " not found");
        }
        return schemaFactory.newURI(bean);
    }
    
    private URI normalise(final String uri) throws URISyntaxException {
        if (uri.startsWith("(")) {
            final String[] split = uri.split("\\)");
            final String[] connectorURIS = split[0].substring(split[0].indexOf(40) + 1).split(",");
            final String factoryQuery = (split.length > 1) ? split[1] : "";
            final StringBuilder builder = new StringBuilder(connectorURIS[0]);
            if (factoryQuery != null && factoryQuery.length() > 0) {
                if (connectorURIS[0].contains("?")) {
                    builder.append("&").append(factoryQuery.substring(1));
                }
                else {
                    builder.append(factoryQuery);
                }
            }
            if (connectorURIS.length > 1) {
                builder.append("#");
                for (int i = 1; i < connectorURIS.length; ++i) {
                    if (i > 1) {
                        builder.append(",");
                    }
                    builder.append(connectorURIS[i]);
                }
            }
            return new URI(builder.toString().replace(";", "&"));
        }
        return new URI(uri.replace(";", "&"));
    }
}
