// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.regex.Matcher;
import org.apache.activemq.artemis.logs.ActiveMQUtilBundle;
import java.nio.ByteBuffer;
import org.apache.activemq.artemis.api.core.ActiveMQBuffer;
import io.netty.buffer.UnpooledByteBufAllocator;
import org.apache.activemq.artemis.api.core.SimpleString;
import io.netty.buffer.ByteBuf;
import org.jboss.logging.Logger;
import java.util.regex.Pattern;

public class ByteUtil
{
    public static final String NON_ASCII_STRING = "@@@@@";
    private static final char[] hexArray;
    private static final String prefix = "^\\s*(\\d+)\\s*";
    private static final String suffix = "(b)?\\s*$";
    private static final Pattern ONE;
    private static final Pattern KILO;
    private static final Pattern MEGA;
    private static final Pattern GIGA;
    
    public static void debugFrame(final Logger logger, final String message, final ByteBuf byteIn) {
        if (logger.isTraceEnabled()) {
            final int location = byteIn.readerIndex();
            final byte[] frame = new byte[byteIn.writerIndex()];
            byteIn.readBytes(frame);
            try {
                logger.trace((Object)(message + "\n" + formatGroup(bytesToHex(frame), 8, 16)));
            }
            catch (Exception e) {
                logger.warn((Object)e.getMessage(), (Throwable)e);
            }
            byteIn.readerIndex(location);
        }
    }
    
    public static String formatGroup(final String str, final int groupSize, final int lineBreak) {
        final StringBuffer buffer = new StringBuffer();
        int line = 1;
        buffer.append("/*  1 */ \"");
        for (int i = 0; i < str.length(); i += groupSize) {
            buffer.append(str.substring(i, i + Math.min(str.length() - i, groupSize)));
            if ((i + groupSize) % lineBreak == 0) {
                buffer.append("\" +\n/* ");
                if (++line < 10) {
                    buffer.append(" ");
                }
                buffer.append(Integer.toString(line) + " */ \"");
            }
            else if ((i + groupSize) % groupSize == 0 && str.length() - i > groupSize) {
                buffer.append("\" + \"");
            }
        }
        buffer.append("\";");
        return buffer.toString();
    }
    
    public static String maxString(final String value, final int size) {
        if (value.length() < size) {
            return value;
        }
        return value.substring(0, size / 2) + " ... " + value.substring(value.length() - size / 2);
    }
    
    public static String bytesToHex(final byte[] bytes) {
        final char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; ++j) {
            final int v = bytes[j] & 0xFF;
            hexChars[j * 2] = ByteUtil.hexArray[v >>> 4];
            hexChars[j * 2 + 1] = ByteUtil.hexArray[v & 0xF];
        }
        return new String(hexChars);
    }
    
    public static String bytesToHex(final byte[] bytes, final int groupSize) {
        if (bytes == null) {
            return "NULL";
        }
        if (bytes.length == 0) {
            return "[]";
        }
        final char[] hexChars = new char[bytes.length * 2 + numberOfGroups(bytes, groupSize)];
        int outPos = 0;
        for (int j = 0; j < bytes.length; ++j) {
            if (j > 0 && j % groupSize == 0) {
                hexChars[outPos++] = ' ';
            }
            final int v = bytes[j] & 0xFF;
            hexChars[outPos++] = ByteUtil.hexArray[v >>> 4];
            hexChars[outPos++] = ByteUtil.hexArray[v & 0xF];
        }
        return new String(hexChars);
    }
    
    public static String toSimpleString(final byte[] bytes) {
        final SimpleString simpleString = new SimpleString(bytes);
        final String value = simpleString.toString();
        for (final char c : value.toCharArray()) {
            if (c < ' ' || c > '\u007f') {
                return "@@@@@";
            }
        }
        return value;
    }
    
    private static int numberOfGroups(final byte[] bytes, final int groupSize) {
        int groups = bytes.length / groupSize;
        if (bytes.length % groupSize == 0) {
            --groups;
        }
        return groups;
    }
    
    public static byte[] longToBytes(final long x) {
        final ByteBuf buffer = UnpooledByteBufAllocator.DEFAULT.heapBuffer(8, 8);
        buffer.writeLong(x);
        return buffer.array();
    }
    
    public static byte[] hexToBytes(final String hexStr) {
        final byte[] bytes = new byte[hexStr.length() / 2];
        for (int i = 0; i < bytes.length; ++i) {
            bytes[i] = (byte)Integer.parseInt(hexStr.substring(2 * i, 2 * i + 2), 16);
        }
        return bytes;
    }
    
    public static String readLine(final ActiveMQBuffer buffer) {
        final StringBuilder sb = new StringBuilder("");
        for (char c = buffer.readChar(); c != '\n'; c = buffer.readChar()) {
            sb.append(c);
        }
        return sb.toString();
    }
    
    public static byte[] getActiveArray(final ByteBuffer buffer) {
        final byte[] ret = new byte[buffer.remaining()];
        if (buffer.hasArray()) {
            final byte[] array = buffer.array();
            System.arraycopy(array, buffer.arrayOffset() + buffer.position(), ret, 0, ret.length);
        }
        else {
            buffer.slice().get(ret);
        }
        return ret;
    }
    
    public static long convertTextBytes(final String text) {
        try {
            Matcher m = ByteUtil.ONE.matcher(text);
            if (m.matches()) {
                return Long.parseLong(m.group(1));
            }
            m = ByteUtil.KILO.matcher(text);
            if (m.matches()) {
                return Long.parseLong(m.group(1)) * 1024L;
            }
            m = ByteUtil.MEGA.matcher(text);
            if (m.matches()) {
                return Long.parseLong(m.group(1)) * 1024L * 1024L;
            }
            m = ByteUtil.GIGA.matcher(text);
            if (m.matches()) {
                return Long.parseLong(m.group(1)) * 1024L * 1024L * 1024L;
            }
            return Long.parseLong(text);
        }
        catch (NumberFormatException e) {
            throw ActiveMQUtilBundle.BUNDLE.failedToParseLong(text);
        }
    }
    
    static {
        hexArray = "0123456789ABCDEF".toCharArray();
        ONE = Pattern.compile("^\\s*(\\d+)\\s*(b)?\\s*$", 2);
        KILO = Pattern.compile("^\\s*(\\d+)\\s*k(b)?\\s*$", 2);
        MEGA = Pattern.compile("^\\s*(\\d+)\\s*m(b)?\\s*$", 2);
        GIGA = Pattern.compile("^\\s*(\\d+)\\s*g(b)?\\s*$", 2);
    }
}
