// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

public final class UUID
{
    private static final String kHexChars = "0123456789abcdefABCDEF";
    public static final byte INDEX_CLOCK_HI = 6;
    public static final byte INDEX_CLOCK_MID = 4;
    public static final byte INDEX_CLOCK_LO = 0;
    public static final byte INDEX_TYPE = 6;
    public static final byte INDEX_CLOCK_SEQUENCE = 8;
    public static final byte INDEX_VARIATION = 8;
    public static final byte TYPE_NULL = 0;
    public static final byte TYPE_TIME_BASED = 1;
    public static final byte TYPE_DCE = 2;
    public static final byte TYPE_NAME_BASED = 3;
    public static final byte TYPE_RANDOM_BASED = 4;
    public static final String NAMESPACE_DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    public static final String NAMESPACE_URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
    public static final String NAMESPACE_OID = "6ba7b812-9dad-11d1-80b4-00c04fd430c8";
    public static final String NAMESPACE_X500 = "6ba7b814-9dad-11d1-80b4-00c04fd430c8";
    private static boolean sDescCaching;
    private final byte[] mId;
    private transient String mDesc;
    private transient int mHashCode;
    private static final int[] kShifts;
    
    public UUID(final int type, final byte[] data) {
        this.mDesc = null;
        this.mHashCode = 0;
        this.mId = data;
        final byte[] mId = this.mId;
        final int n = 6;
        mId[n] &= 0xF;
        final byte[] mId2 = this.mId;
        final int n2 = 6;
        mId2[n2] |= (byte)(type << 4);
        final byte[] mId3 = this.mId;
        final int n3 = 8;
        mId3[n3] &= 0x3F;
        final byte[] mId4 = this.mId;
        final int n4 = 8;
        mId4[n4] |= 0xFFFFFF80;
    }
    
    public byte[] asBytes() {
        return this.mId;
    }
    
    @Override
    public int hashCode() {
        if (this.mHashCode == 0) {
            int result = this.mId[0] & 0xFF;
            result |= result << 16;
            result |= result << 8;
            for (int i = 1; i < 15; i += 2) {
                final int curr = (this.mId[i] & 0xFF) << 8 | (this.mId[i + 1] & 0xFF);
                final int shift = UUID.kShifts[i >> 1];
                if (shift > 16) {
                    result ^= (curr << shift | curr >>> 32 - shift);
                }
                else {
                    result ^= curr << shift;
                }
            }
            final int last = this.mId[15] & 0xFF;
            result ^= last << 3;
            result ^= last << 13;
            result ^= last << 27;
            if (result == 0) {
                this.mHashCode = -1;
            }
            else {
                this.mHashCode = result;
            }
        }
        return this.mHashCode;
    }
    
    @Override
    public String toString() {
        if (this.mDesc == null) {
            final StringBuffer b = new StringBuffer(36);
            for (int i = 0; i < 16; ++i) {
                switch (i) {
                    case 4:
                    case 6:
                    case 8:
                    case 10: {
                        b.append('-');
                        break;
                    }
                }
                final int hex = this.mId[i] & 0xFF;
                b.append("0123456789abcdefABCDEF".charAt(hex >> 4));
                b.append("0123456789abcdefABCDEF".charAt(hex & 0xF));
            }
            if (!UUID.sDescCaching) {
                return b.toString();
            }
            this.mDesc = b.toString();
        }
        return this.mDesc;
    }
    
    public static byte[] stringToBytes(final String uuid) {
        final byte[] data = new byte[16];
        int dataIdx = 0;
        try {
            char c1;
            char c2;
            int c1Bytes;
            int c2Bytes;
            for (int i = 0; i < uuid.length(); i += 2, c1Bytes = Character.digit(c1, 16), c2Bytes = Character.digit(c2, 16), data[dataIdx++] = (byte)((c1Bytes << 4) + c2Bytes)) {
                while (uuid.charAt(i) == '-') {
                    ++i;
                }
                c1 = uuid.charAt(i);
                c2 = uuid.charAt(i + 1);
            }
        }
        catch (RuntimeException e) {
            throw new IllegalArgumentException(e);
        }
        return data;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof UUID)) {
            return false;
        }
        final byte[] otherId = ((UUID)o).mId;
        final byte[] thisId = this.mId;
        for (int i = 0; i < 16; ++i) {
            if (otherId[i] != thisId[i]) {
                return false;
            }
        }
        return true;
    }
    
    static {
        UUID.sDescCaching = true;
        kShifts = new int[] { 3, 7, 17, 21, 29, 4, 9 };
    }
}
