// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

import java.util.Arrays;
import java.util.concurrent.locks.StampedLock;
import java.util.Objects;
import java.util.HashSet;
import java.util.Set;
import com.google.common.base.Preconditions;

public class ConcurrentLongHashSet
{
    private static final long EmptyItem = -1L;
    private static final long DeletedItem = -2L;
    private static final float SetFillFactor = 0.66f;
    private static final int DefaultExpectedItems = 256;
    private static final int DefaultConcurrencyLevel = 16;
    private final Section[] sections;
    private static final long HashMixer = -4132994306676758123L;
    private static final int R = 47;
    
    public ConcurrentLongHashSet() {
        this(256);
    }
    
    public ConcurrentLongHashSet(final int expectedItems) {
        this(expectedItems, 16);
    }
    
    public ConcurrentLongHashSet(int expectedItems, final int numSections) {
        Preconditions.checkArgument(numSections > 0);
        if (expectedItems < numSections) {
            expectedItems = numSections;
        }
        final int perSectionExpectedItems = expectedItems / numSections;
        final int perSectionCapacity = (int)(perSectionExpectedItems / 0.66f);
        this.sections = new Section[numSections];
        for (int i = 0; i < numSections; ++i) {
            this.sections[i] = new Section(perSectionCapacity);
        }
    }
    
    public int size() {
        int size = 0;
        for (final Section s : this.sections) {
            size += s.size;
        }
        return size;
    }
    
    public long capacity() {
        long capacity = 0L;
        for (final Section s : this.sections) {
            capacity += s.capacity;
        }
        return capacity;
    }
    
    public boolean isEmpty() {
        for (final Section s : this.sections) {
            if (s.size != 0) {
                return false;
            }
        }
        return true;
    }
    
    long getUsedBucketCount() {
        long usedBucketCount = 0L;
        for (final Section s : this.sections) {
            usedBucketCount += s.usedBuckets;
        }
        return usedBucketCount;
    }
    
    public boolean contains(final long item) {
        checkBiggerEqualZero(item);
        final long h = hash(item);
        return this.getSection(h).contains(item, (int)h);
    }
    
    public boolean add(final long item) {
        checkBiggerEqualZero(item);
        final long h = hash(item);
        return this.getSection(h).add(item, (int)h);
    }
    
    public boolean remove(final long item) {
        checkBiggerEqualZero(item);
        final long h = hash(item);
        return this.getSection(h).remove(item, (int)h);
    }
    
    private Section getSection(final long hash) {
        final int sectionIdx = (int)(hash >>> 32) & this.sections.length - 1;
        return this.sections[sectionIdx];
    }
    
    public void clear() {
        for (final Section s : this.sections) {
            s.clear();
        }
    }
    
    public void forEach(final ConsumerLong processor) {
        for (final Section s : this.sections) {
            s.forEach(processor);
        }
    }
    
    public Set<Long> items() {
        final HashSet obj;
        final Set<Long> items = (Set<Long>)(obj = new HashSet());
        Objects.requireNonNull(obj);
        this.forEach(obj::add);
        return items;
    }
    
    static long hash(final long key) {
        long hash = key * -4132994306676758123L;
        hash ^= hash >>> 47;
        hash *= -4132994306676758123L;
        return hash;
    }
    
    static int signSafeMod(final long n, final int Max) {
        return (int)(n & (long)(Max - 1));
    }
    
    static int alignToPowerOfTwo(final int n) {
        return (int)Math.pow(2.0, 32 - Integer.numberOfLeadingZeros(n - 1));
    }
    
    static void checkBiggerEqualZero(final long n) {
        if (n < 0L) {
            throw new IllegalArgumentException("Keys and values must be >= 0");
        }
    }
    
    private static final class Section extends StampedLock
    {
        private long[] table;
        private int capacity;
        private volatile int size;
        private int usedBuckets;
        private int resizeThreshold;
        
        Section(final int capacity) {
            this.capacity = ConcurrentLongHashSet.alignToPowerOfTwo(capacity);
            this.table = new long[this.capacity];
            this.size = 0;
            this.usedBuckets = 0;
            this.resizeThreshold = (int)(this.capacity * 0.66f);
            Arrays.fill(this.table, -1L);
        }
        
        boolean contains(final long item, final int hash) {
            long stamp = this.tryOptimisticRead();
            boolean acquiredLock = false;
            int bucket = ConcurrentLongHashSet.signSafeMod(hash, this.capacity);
            try {
                while (true) {
                    long storedItem = this.table[bucket];
                    if (!acquiredLock && this.validate(stamp)) {
                        if (item == storedItem) {
                            return true;
                        }
                        if (storedItem == -1L) {
                            return false;
                        }
                    }
                    else {
                        if (!acquiredLock) {
                            stamp = this.readLock();
                            acquiredLock = true;
                            bucket = ConcurrentLongHashSet.signSafeMod(hash, this.capacity);
                            storedItem = this.table[bucket];
                        }
                        if (item == storedItem) {
                            return true;
                        }
                        if (storedItem == -1L) {
                            return false;
                        }
                    }
                    bucket = (bucket + 1 & this.table.length - 1);
                }
            }
            finally {
                if (acquiredLock) {
                    this.unlockRead(stamp);
                }
            }
        }
        
        boolean add(final long item, final long hash) {
            final long stamp = this.writeLock();
            int bucket = ConcurrentLongHashSet.signSafeMod(hash, this.capacity);
            int firstDeletedItem = -1;
            try {
                while (true) {
                    final long storedItem = this.table[bucket];
                    if (item == storedItem) {
                        return false;
                    }
                    if (storedItem == -1L) {
                        if (firstDeletedItem != -1) {
                            bucket = firstDeletedItem;
                        }
                        else {
                            ++this.usedBuckets;
                        }
                        this.table[bucket] = item;
                        ++this.size;
                        return true;
                    }
                    if (storedItem == -2L && firstDeletedItem == -1) {
                        firstDeletedItem = bucket;
                    }
                    bucket = (bucket + 1 & this.table.length - 1);
                }
            }
            finally {
                if (this.usedBuckets > this.resizeThreshold) {
                    try {
                        this.rehash();
                    }
                    finally {
                        this.unlockWrite(stamp);
                    }
                }
                else {
                    this.unlockWrite(stamp);
                }
            }
        }
        
        private boolean remove(final long item, final int hash) {
            final long stamp = this.writeLock();
            int bucket = ConcurrentLongHashSet.signSafeMod(hash, this.capacity);
            try {
                while (true) {
                    final long storedItem = this.table[bucket];
                    if (item == storedItem) {
                        --this.size;
                        this.cleanBucket(bucket);
                        return true;
                    }
                    if (storedItem == -1L) {
                        return false;
                    }
                    bucket = (bucket + 1 & this.table.length - 1);
                }
            }
            finally {
                this.unlockWrite(stamp);
            }
        }
        
        private void cleanBucket(final int bucket) {
            final int nextInArray = bucket + 1 & this.table.length - 1;
            if (this.table[nextInArray] == -1L) {
                this.table[bucket] = -1L;
                --this.usedBuckets;
            }
            else {
                this.table[bucket] = -2L;
            }
        }
        
        void clear() {
            final long stamp = this.writeLock();
            try {
                Arrays.fill(this.table, -1L);
                this.size = 0;
                this.usedBuckets = 0;
            }
            finally {
                this.unlockWrite(stamp);
            }
        }
        
        public void forEach(final ConsumerLong processor) {
            long stamp = this.tryOptimisticRead();
            long[] table = this.table;
            boolean acquiredReadLock = false;
            try {
                if (!this.validate(stamp)) {
                    stamp = this.readLock();
                    acquiredReadLock = true;
                    table = this.table;
                }
                for (int bucket = 0; bucket < table.length; ++bucket) {
                    long storedItem = table[bucket];
                    if (!acquiredReadLock && !this.validate(stamp)) {
                        stamp = this.readLock();
                        acquiredReadLock = true;
                        storedItem = table[bucket];
                    }
                    if (storedItem != -2L && storedItem != -1L) {
                        processor.accept(storedItem);
                    }
                }
            }
            finally {
                if (acquiredReadLock) {
                    this.unlockRead(stamp);
                }
            }
        }
        
        private void rehash() {
            final int newCapacity = this.capacity * 2;
            final long[] newTable = new long[newCapacity];
            Arrays.fill(newTable, -1L);
            for (int i = 0; i < this.table.length; ++i) {
                final long storedItem = this.table[i];
                if (storedItem != -1L && storedItem != -2L) {
                    insertKeyValueNoLock(newTable, newCapacity, storedItem);
                }
            }
            this.capacity = newCapacity;
            this.table = newTable;
            this.usedBuckets = this.size;
            this.resizeThreshold = (int)(this.capacity * 0.66f);
        }
        
        private static void insertKeyValueNoLock(final long[] table, final int capacity, final long item) {
            int bucket = ConcurrentLongHashSet.signSafeMod(ConcurrentLongHashSet.hash(item), capacity);
            while (true) {
                final long storedKey = table[bucket];
                if (storedKey == -1L) {
                    break;
                }
                bucket = (bucket + 1 & table.length - 1);
            }
            table[bucket] = item;
        }
    }
    
    public interface ConsumerLong
    {
        void accept(final long p0);
    }
}
