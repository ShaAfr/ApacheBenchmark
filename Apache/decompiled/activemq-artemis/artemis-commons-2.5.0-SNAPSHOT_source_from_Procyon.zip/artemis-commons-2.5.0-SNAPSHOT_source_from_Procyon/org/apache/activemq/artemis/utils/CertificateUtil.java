// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import io.netty.channel.ChannelHandler;
import javax.net.ssl.SSLPeerUnverifiedException;
import io.netty.handler.ssl.SslHandler;
import javax.security.cert.X509Certificate;
import io.netty.channel.Channel;

public class CertificateUtil
{
    public static X509Certificate[] getCertsFromChannel(final Channel channel) {
        X509Certificate[] certificates = null;
        final ChannelHandler channelHandler = channel.pipeline().get("ssl");
        if (channelHandler != null && channelHandler instanceof SslHandler) {
            final SslHandler sslHandler = (SslHandler)channelHandler;
            try {
                certificates = sslHandler.engine().getSession().getPeerCertificateChain();
            }
            catch (SSLPeerUnverifiedException ex) {}
        }
        return certificates;
    }
}
