// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

import java.util.NoSuchElementException;
import java.lang.reflect.Array;

public class LinkedListImpl<E> implements LinkedList<E>
{
    private static final int INITIAL_ITERATOR_ARRAY_SIZE = 10;
    private final Node<E> head;
    private Node<E> tail;
    private int size;
    private volatile Iterator[] iters;
    private int numIters;
    private int nextIndex;
    
    public LinkedListImpl() {
        this.head = new Node<E>(null);
        this.tail = null;
        this.iters = this.createIteratorArray(10);
    }
    
    @Override
    public void addHead(final E e) {
        final Node<E> node = new Node<E>(e);
        node.next = this.head.next;
        node.prev = this.head;
        this.head.next = node;
        if (this.size == 0) {
            this.tail = node;
        }
        else {
            node.next.prev = node;
        }
        ++this.size;
    }
    
    @Override
    public void addTail(final E e) {
        if (this.size == 0) {
            this.addHead(e);
        }
        else {
            final Node<E> node = new Node<E>(e);
            node.prev = this.tail;
            this.tail.next = node;
            this.tail = node;
            ++this.size;
        }
    }
    
    @Override
    public E poll() {
        final Node<E> ret = this.head.next;
        if (ret != null) {
            this.removeAfter(this.head);
            return ret.val;
        }
        return null;
    }
    
    @Override
    public void clear() {
        final Node<E> head = this.head;
        final Node<E> node = null;
        head.next = node;
        this.tail = node;
        this.size = 0;
    }
    
    @Override
    public int size() {
        return this.size;
    }
    
    @Override
    public LinkedListIterator<E> iterator() {
        return new Iterator();
    }
    
    @Override
    public String toString() {
        final StringBuilder str = new StringBuilder("LinkedListImpl [ ");
        for (Node<E> node = this.head; node != null; node = node.next) {
            str.append(node.toString());
            if (node.next != null) {
                str.append(", ");
            }
        }
        return str.toString();
    }
    
    public int numIters() {
        return this.numIters;
    }
    
    private Iterator[] createIteratorArray(final int size) {
        return (Iterator[])Array.newInstance(Iterator.class, size);
    }
    
    private void removeAfter(final Node<E> node) {
        final Node<E> toRemove = node.next;
        node.next = toRemove.next;
        if (toRemove.next != null) {
            toRemove.next.prev = node;
        }
        if (toRemove == this.tail) {
            this.tail = node;
        }
        --this.size;
        if (toRemove.iterCount != 0) {
            this.nudgeIterators(toRemove);
        }
        final Node<E> node2 = toRemove;
        final Node<E> node3 = toRemove;
        final Node<E> node4 = null;
        node3.prev = (Node<E>)node4;
        node2.next = (Node<E>)node4;
    }
    
    private synchronized void nudgeIterators(final Node<E> node) {
        for (int i = 0; i < this.numIters; ++i) {
            final Iterator iter = this.iters[i];
            if (iter != null) {
                iter.nudged(node);
            }
        }
    }
    
    private synchronized void addIter(final Iterator iter) {
        if (this.numIters == this.iters.length) {
            this.resize(2 * this.numIters);
        }
        this.iters[this.nextIndex++] = iter;
        ++this.numIters;
    }
    
    private synchronized void resize(final int newSize) {
        final Iterator[] newIters = this.createIteratorArray(newSize);
        System.arraycopy(this.iters, 0, newIters, 0, this.numIters);
        this.iters = newIters;
    }
    
    private synchronized void removeIter(final Iterator iter) {
        for (int i = 0; i < this.numIters; ++i) {
            if (iter == this.iters[i]) {
                this.iters[i] = null;
                if (i != this.numIters - 1) {
                    System.arraycopy(this.iters, i + 1, this.iters, i, this.numIters - i - 1);
                }
                --this.numIters;
                if (this.numIters >= 10 && this.numIters == this.iters.length / 2) {
                    this.resize(this.numIters);
                }
                --this.nextIndex;
                return;
            }
        }
        throw new IllegalStateException("Cannot find iter to remove");
    }
    
    private static final class Node<E>
    {
        Node<E> next;
        Node<E> prev;
        final E val;
        int iterCount;
        
        Node(final E e) {
            this.val = e;
        }
        
        @Override
        public String toString() {
            return "Node, value = " + this.val;
        }
    }
    
    private class Iterator implements LinkedListIterator<E>
    {
        Node<E> last;
        Node<E> current;
        boolean repeat;
        
        Iterator() {
            this.current = LinkedListImpl.this.head.next;
            if (this.current != null) {
                final Node<E> current = this.current;
                ++current.iterCount;
            }
            LinkedListImpl.this.addIter(this);
        }
        
        @Override
        public void repeat() {
            this.repeat = true;
        }
        
        @Override
        public boolean hasNext() {
            final Node<E> e = this.getNode();
            return (e != null && (e != this.last || this.repeat)) || this.canAdvance();
        }
        
        @Override
        public E next() {
            Node<E> e = this.getNode();
            if (!this.repeat) {
                if (e == null || e == this.last) {
                    if (!this.canAdvance()) {
                        throw new NoSuchElementException();
                    }
                    this.advance();
                    e = this.getNode();
                }
                this.last = e;
                this.repeat = false;
                return e.val;
            }
            this.repeat = false;
            if (e != null) {
                return e.val;
            }
            if (this.canAdvance()) {
                this.advance();
                e = this.getNode();
                return e.val;
            }
            throw new NoSuchElementException();
        }
        
        @Override
        public void remove() {
            if (this.last == null) {
                throw new NoSuchElementException();
            }
            if (this.current == null) {
                throw new NoSuchElementException();
            }
            LinkedListImpl.this.removeAfter(this.current.prev);
            this.last = null;
        }
        
        @Override
        public void close() {
            LinkedListImpl.this.removeIter(this);
        }
        
        public void nudged(final Node<E> node) {
            if (this.current == node) {
                if (this.canAdvance()) {
                    this.advance();
                }
                else if (this.current.prev != LinkedListImpl.this.head) {
                    final Node<E> current = this.current;
                    --current.iterCount;
                    this.current = this.current.prev;
                    final Node<E> current2 = this.current;
                    ++current2.iterCount;
                }
                else {
                    this.current = null;
                }
            }
        }
        
        private Node<E> getNode() {
            if (this.current == null) {
                this.current = LinkedListImpl.this.head.next;
                if (this.current != null) {
                    final Node<E> current = this.current;
                    ++current.iterCount;
                }
            }
            if (this.current != null) {
                return this.current;
            }
            return null;
        }
        
        private boolean canAdvance() {
            if (this.current == null) {
                this.current = LinkedListImpl.this.head.next;
                if (this.current != null) {
                    final Node<E> current = this.current;
                    ++current.iterCount;
                }
            }
            return this.current != null && this.current.next != null;
        }
        
        private void advance() {
            if (this.current == null || this.current.next == null) {
                throw new NoSuchElementException();
            }
            final Node<E> current = this.current;
            --current.iterCount;
            this.current = this.current.next;
            final Node<E> current2 = this.current;
            ++current2.iterCount;
        }
    }
}
