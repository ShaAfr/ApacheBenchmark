// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.ArrayList;
import java.util.List;

public class ListUtil
{
    public static List<String> toList(final String commaSeparatedString) {
        final List<String> list = new ArrayList<String>();
        if (commaSeparatedString == null || commaSeparatedString.trim().length() == 0) {
            return list;
        }
        final String[] split;
        final String[] values = split = commaSeparatedString.split(",");
        for (final String value : split) {
            list.add(value.trim());
        }
        return list;
    }
}
