// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.critical;

import org.apache.commons.beanutils.Converter;
import org.apache.activemq.artemis.utils.uri.BeanSupport;

public enum CriticalAnalyzerPolicy
{
    HALT, 
    SHUTDOWN, 
    LOG;
    
    static {
        BeanSupport.registerConverter((Converter)new CriticalAnalyzerPolicyConverter(), CriticalAnalyzerPolicy.class);
    }
    
    static class CriticalAnalyzerPolicyConverter implements Converter
    {
        public <T> T convert(final Class<T> type, final Object value) {
            return type.cast(CriticalAnalyzerPolicy.valueOf(value.toString()));
        }
    }
}
