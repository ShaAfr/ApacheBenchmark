// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public class ActiveMQException extends Exception
{
    private static final long serialVersionUID = -4802014152804997417L;
    private final ActiveMQExceptionType type;
    
    public ActiveMQException() {
        this.type = ActiveMQExceptionType.GENERIC_EXCEPTION;
    }
    
    public ActiveMQException(final String msg) {
        super(msg);
        this.type = ActiveMQExceptionType.GENERIC_EXCEPTION;
    }
    
    public ActiveMQException(final String msg, final ActiveMQExceptionType t) {
        super(msg);
        this.type = t;
    }
    
    public ActiveMQException(final String message, final Throwable t, final ActiveMQExceptionType type) {
        super(message, t);
        this.type = type;
    }
    
    public ActiveMQException(final int code, final String msg) {
        super(msg);
        this.type = ActiveMQExceptionType.getType(code);
    }
    
    public ActiveMQException(final ActiveMQExceptionType type, final String msg) {
        super(msg);
        this.type = type;
    }
    
    public ActiveMQException(final ActiveMQExceptionType type) {
        this.type = type;
    }
    
    public ActiveMQException(final ActiveMQExceptionType type, final String message, final Throwable t) {
        super(message, t);
        this.type = type;
    }
    
    public ActiveMQExceptionType getType() {
        return this.type;
    }
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "[errorType=" + this.type + " message=" + this.getMessage() + "]";
    }
}
