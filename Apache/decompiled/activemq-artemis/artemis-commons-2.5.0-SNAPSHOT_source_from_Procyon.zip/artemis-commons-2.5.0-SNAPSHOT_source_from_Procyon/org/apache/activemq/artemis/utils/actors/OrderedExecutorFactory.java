// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.actors;

import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executor;
import org.apache.activemq.artemis.utils.ExecutorFactory;

public final class OrderedExecutorFactory implements ExecutorFactory
{
    final Executor parent;
    
    public static boolean flushExecutor(final Executor executor) {
        return flushExecutor(executor, 30L, TimeUnit.SECONDS);
    }
    
    public static boolean flushExecutor(final Executor executor, final long timeout, final TimeUnit unit) {
        final CountDownLatch obj;
        final CountDownLatch latch = obj = new CountDownLatch(1);
        Objects.requireNonNull(obj);
        executor.execute(obj::countDown);
        try {
            return latch.await(timeout, unit);
        }
        catch (Exception e) {
            return false;
        }
    }
    
    public OrderedExecutorFactory(final Executor parent) {
        this.parent = parent;
    }
    
    @Override
    public ArtemisExecutor getExecutor() {
        return new OrderedExecutor(this.parent);
    }
    
    public Executor getParent() {
        return this.parent;
    }
}
