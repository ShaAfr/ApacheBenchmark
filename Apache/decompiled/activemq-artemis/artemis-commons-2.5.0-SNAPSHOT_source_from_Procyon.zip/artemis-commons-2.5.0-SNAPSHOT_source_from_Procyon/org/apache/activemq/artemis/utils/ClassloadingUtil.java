// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.net.URL;

public final class ClassloadingUtil
{
    private static final String INSTANTIATION_EXCEPTION_MESSAGE = "Your class must have a constructor without arguments. If it is an inner class, it must be static!";
    
    public static Object newInstanceFromClassLoader(final String className) {
        ClassLoader loader = ClassloadingUtil.class.getClassLoader();
        try {
            final Class<?> clazz = loader.loadClass(className);
            return clazz.newInstance();
        }
        catch (Throwable t) {
            if (t instanceof InstantiationException) {
                System.out.println("Your class must have a constructor without arguments. If it is an inner class, it must be static!");
            }
            loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) {
                throw new RuntimeException("No local context classloader", t);
            }
            try {
                return loader.loadClass(className).newInstance();
            }
            catch (InstantiationException e) {
                throw new RuntimeException("Your class must have a constructor without arguments. If it is an inner class, it must be static! " + className, e);
            }
            catch (ClassNotFoundException e2) {
                throw new IllegalStateException(e2);
            }
            catch (IllegalAccessException e3) {
                throw new RuntimeException(e3);
            }
        }
    }
    
    public static Object newInstanceFromClassLoader(final String className, final Object... objs) {
        ClassLoader loader = ClassloadingUtil.class.getClassLoader();
        try {
            final Class<?>[] parametersType = (Class<?>[])new Class[objs.length];
            for (int i = 0; i < objs.length; ++i) {
                parametersType[i] = objs[i].getClass();
            }
            final Class<?> clazz = loader.loadClass(className);
            return clazz.getConstructor(parametersType).newInstance(objs);
        }
        catch (Throwable t) {
            if (t instanceof InstantiationException) {
                System.out.println("Your class must have a constructor without arguments. If it is an inner class, it must be static!");
            }
            loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) {
                throw new RuntimeException("No local context classloader", t);
            }
            try {
                return loader.loadClass(className).newInstance();
            }
            catch (InstantiationException e) {
                throw new RuntimeException("Your class must have a constructor without arguments. If it is an inner class, it must be static! " + className, e);
            }
            catch (ClassNotFoundException e2) {
                throw new IllegalStateException(e2);
            }
            catch (IllegalAccessException e3) {
                throw new RuntimeException(e3);
            }
        }
    }
    
    public static URL findResource(final String resourceName) {
        ClassLoader loader = ClassloadingUtil.class.getClassLoader();
        try {
            final URL resource = loader.getResource(resourceName);
            if (resource != null) {
                return resource;
            }
        }
        catch (Throwable t) {}
        loader = Thread.currentThread().getContextClassLoader();
        if (loader == null) {
            return null;
        }
        return loader.getResource(resourceName);
    }
}
