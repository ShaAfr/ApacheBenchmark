// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQUnexpectedRoutingTypeForAddress extends ActiveMQException
{
    public ActiveMQUnexpectedRoutingTypeForAddress() {
        super(ActiveMQExceptionType.MAX_CONSUMER_LIMIT_EXCEEDED);
    }
    
    public ActiveMQUnexpectedRoutingTypeForAddress(final String msg) {
        super(ActiveMQExceptionType.MAX_CONSUMER_LIMIT_EXCEEDED, msg);
    }
}
