// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

import java.util.Iterator;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum ActiveMQExceptionType
{
    INTERNAL_ERROR(0, 0) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQInternalErrorException(msg);
        }
    }, 
    UNSUPPORTED_PACKET(1, 1) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQUnsupportedPacketException(msg);
        }
    }, 
    NOT_CONNECTED(2, 2) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQNotConnectedException(msg);
        }
    }, 
    CONNECTION_TIMEDOUT(3, 3) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQConnectionTimedOutException(msg);
        }
    }, 
    DISCONNECTED(4, 4) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQDisconnectedException(msg);
        }
    }, 
    UNBLOCKED(5, 5) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQUnBlockedException(msg);
        }
    }, 
    IO_ERROR(6, 6) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQIOErrorException(msg);
        }
    }, 
    QUEUE_DOES_NOT_EXIST(7, 100) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQNonExistentQueueException(msg);
        }
    }, 
    QUEUE_EXISTS(8, 101) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQQueueExistsException(msg);
        }
    }, 
    OBJECT_CLOSED(9, 102) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQObjectClosedException(msg);
        }
    }, 
    INVALID_FILTER_EXPRESSION(10, 103) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQInvalidFilterExpressionException(msg);
        }
    }, 
    ILLEGAL_STATE(11, 104) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQIllegalStateException(msg);
        }
    }, 
    SECURITY_EXCEPTION(12, 105) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQSecurityException(msg);
        }
    }, 
    ADDRESS_DOES_NOT_EXIST(13, 106) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQAddressDoesNotExistException(msg);
        }
    }, 
    ADDRESS_EXISTS(14, 107) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQAddressExistsException(msg);
        }
    }, 
    INCOMPATIBLE_CLIENT_SERVER_VERSIONS(15, 108) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQIncompatibleClientServerException(msg);
        }
    }, 
    LARGE_MESSAGE_ERROR_BODY(16, 110) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQLargeMessageException(msg);
        }
    }, 
    TRANSACTION_ROLLED_BACK(17, 111) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQTransactionRolledBackException(msg);
        }
    }, 
    SESSION_CREATION_REJECTED(18, 112) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQSessionCreationException(msg);
        }
    }, 
    DUPLICATE_ID_REJECTED(19, 113) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQDuplicateIdException(msg);
        }
    }, 
    DUPLICATE_METADATA(20, 114) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQDuplicateMetaDataException(msg);
        }
    }, 
    TRANSACTION_OUTCOME_UNKNOWN(21, 115) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQTransactionOutcomeUnknownException(msg);
        }
    }, 
    ALREADY_REPLICATING(22, 116) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQAlreadyReplicatingException(msg);
        }
    }, 
    INTERCEPTOR_REJECTED_PACKET(23, 117) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQInterceptorRejectedPacketException(msg);
        }
    }, 
    INVALID_TRANSIENT_QUEUE_USE(24, 118) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQInvalidTransientQueueUseException(msg);
        }
    }, 
    REMOTE_DISCONNECT(25, 119) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQRemoteDisconnectException(msg);
        }
    }, 
    TRANSACTION_TIMEOUT(26, 120) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQTransactionTimeoutException(msg);
        }
    }, 
    GENERIC_EXCEPTION(999), 
    NATIVE_ERROR_INTERNAL(200), 
    NATIVE_ERROR_INVALID_BUFFER(201), 
    NATIVE_ERROR_NOT_ALIGNED(202), 
    NATIVE_ERROR_CANT_INITIALIZE_AIO(203), 
    NATIVE_ERROR_CANT_RELEASE_AIO(204), 
    NATIVE_ERROR_CANT_OPEN_CLOSE_FILE(205), 
    NATIVE_ERROR_CANT_ALLOCATE_QUEUE(206), 
    NATIVE_ERROR_PREALLOCATE_FILE(208), 
    NATIVE_ERROR_ALLOCATE_MEMORY(209), 
    ADDRESS_FULL(37, 210) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQAddressFullException(msg);
        }
    }, 
    LARGE_MESSAGE_INTERRUPTED(38, 211) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQLargeMessageInterruptedException(msg);
        }
    }, 
    CLUSTER_SECURITY_EXCEPTION(39, 212) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQClusterSecurityException(msg);
        }
    }, 
    NOT_IMPLEMTNED_EXCEPTION(213), 
    MAX_CONSUMER_LIMIT_EXCEEDED(41, 214) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQQueueMaxConsumerLimitReached(msg);
        }
    }, 
    UNEXPECTED_ROUTING_TYPE_FOR_ADDRESS(42, 215) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQUnexpectedRoutingTypeForAddress(msg);
        }
    }, 
    INVALID_QUEUE_CONFIGURATION(43, 216) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQInvalidQueueConfiguration(msg);
        }
    }, 
    DELETE_ADDRESS_ERROR(44, 217) {
        @Override
        public ActiveMQException createException(final String msg) {
            return new ActiveMQDeleteAddressException(msg);
        }
    };
    
    private static final Map<Integer, ActiveMQExceptionType> TYPE_MAP;
    private final int code;
    
    private ActiveMQExceptionType(final int code) {
        this.code = code;
    }
    
    public int getCode() {
        return this.code;
    }
    
    public ActiveMQException createException(final String msg) {
        return new ActiveMQException(msg + ", code:" + this);
    }
    
    public static ActiveMQException createException(final int code, final String msg) {
        return getType(code).createException(msg);
    }
    
    public static ActiveMQExceptionType getType(final int code) {
        final ActiveMQExceptionType type = ActiveMQExceptionType.TYPE_MAP.get(code);
        if (type != null) {
            return type;
        }
        return ActiveMQExceptionType.GENERIC_EXCEPTION;
    }
    
    static {
        final HashMap<Integer, ActiveMQExceptionType> map = new HashMap<Integer, ActiveMQExceptionType>();
        for (final ActiveMQExceptionType type : EnumSet.allOf(ActiveMQExceptionType.class)) {
            map.put(type.getCode(), type);
        }
        TYPE_MAP = Collections.unmodifiableMap((Map<? extends Integer, ? extends ActiveMQExceptionType>)map);
    }
}
