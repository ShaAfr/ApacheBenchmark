// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

public class ActiveMQThreadPoolExecutor extends ThreadPoolExecutor
{
    private static final RejectedExecutionHandler QUEUE_EXECUTION_HANDLER;
    
    public ActiveMQThreadPoolExecutor(final int coreSize, final int maxSize, final long keep, final TimeUnit keepUnits, final ThreadFactory factory) {
        super(coreSize, maxSize, keep, keepUnits, new ThreadPoolQueue(), factory, ActiveMQThreadPoolExecutor.QUEUE_EXECUTION_HANDLER);
    }
    
    static {
        QUEUE_EXECUTION_HANDLER = ((r, e) -> {
            if (!e.isShutdown()) {
                e.getQueue().add(r);
            }
        });
    }
    
    private static class ThreadPoolQueue extends LinkedBlockingQueue<Runnable>
    {
        @Override
        public boolean offer(final Runnable runnable) {
            return false;
        }
        
        @Override
        public boolean add(final Runnable runnable) {
            return super.offer(runnable);
        }
    }
}
