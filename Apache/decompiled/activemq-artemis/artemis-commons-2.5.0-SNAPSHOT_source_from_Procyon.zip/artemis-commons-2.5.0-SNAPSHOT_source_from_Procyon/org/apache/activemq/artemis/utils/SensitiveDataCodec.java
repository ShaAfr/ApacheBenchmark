// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.Map;

public interface SensitiveDataCodec<T>
{
    T decode(final Object p0) throws Exception;
    
    T encode(final Object p0) throws Exception;
    
    void init(final Map<String, String> p0) throws Exception;
}
