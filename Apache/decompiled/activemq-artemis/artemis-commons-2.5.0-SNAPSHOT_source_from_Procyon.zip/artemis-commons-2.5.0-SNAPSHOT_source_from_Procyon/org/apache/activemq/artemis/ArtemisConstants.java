// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis;

public class ArtemisConstants
{
    public static final int DEFAULT_JOURNAL_BUFFER_SIZE_AIO = 501760;
    public static final int DEFAULT_JOURNAL_BUFFER_TIMEOUT_AIO = 500000;
    public static final int DEFAULT_JOURNAL_BUFFER_TIMEOUT_NIO = 3333333;
    public static final int DEFAULT_JOURNAL_BUFFER_SIZE_NIO = 501760;
}
