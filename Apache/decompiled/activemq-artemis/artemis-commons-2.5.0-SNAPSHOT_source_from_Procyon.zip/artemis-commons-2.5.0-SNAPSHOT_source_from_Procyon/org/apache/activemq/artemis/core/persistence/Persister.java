// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.core.persistence;

import org.apache.activemq.artemis.api.core.ActiveMQBuffer;

public interface Persister<T>
{
    default byte getID() {
        return 0;
    }
    
    int getEncodeSize(final T p0);
    
    void encode(final ActiveMQBuffer p0, final T p1);
    
    T decode(final ActiveMQBuffer p0, final T p1);
}
