// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQDeleteAddressException extends ActiveMQException
{
    public ActiveMQDeleteAddressException() {
        super(ActiveMQExceptionType.DELETE_ADDRESS_ERROR);
    }
    
    public ActiveMQDeleteAddressException(final String msg) {
        super(ActiveMQExceptionType.DELETE_ADDRESS_ERROR, msg);
    }
}
