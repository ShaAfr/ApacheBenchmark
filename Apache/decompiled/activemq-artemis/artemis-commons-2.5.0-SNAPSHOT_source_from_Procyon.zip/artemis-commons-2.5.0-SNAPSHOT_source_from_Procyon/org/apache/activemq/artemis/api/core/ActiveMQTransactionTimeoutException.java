// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public class ActiveMQTransactionTimeoutException extends ActiveMQException
{
    public ActiveMQTransactionTimeoutException() {
        super(ActiveMQExceptionType.TRANSACTION_TIMEOUT);
    }
    
    public ActiveMQTransactionTimeoutException(final String message) {
        super(ActiveMQExceptionType.TRANSACTION_TIMEOUT, message);
    }
}
