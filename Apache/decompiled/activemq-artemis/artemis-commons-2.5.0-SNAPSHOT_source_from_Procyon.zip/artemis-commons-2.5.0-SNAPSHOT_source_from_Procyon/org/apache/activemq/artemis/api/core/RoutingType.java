// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public enum RoutingType
{
    MULTICAST, 
    ANYCAST;
    
    public byte getType() {
        switch (this) {
            case MULTICAST: {
                return 0;
            }
            case ANYCAST: {
                return 1;
            }
            default: {
                return -1;
            }
        }
    }
    
    public static RoutingType getType(final byte type) {
        switch (type) {
            case 0: {
                return RoutingType.MULTICAST;
            }
            case 1: {
                return RoutingType.ANYCAST;
            }
            default: {
                return null;
            }
        }
    }
}
