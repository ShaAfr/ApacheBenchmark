// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

import io.netty.buffer.ByteBuf;
import java.nio.ByteBuffer;
import org.apache.activemq.artemis.core.buffers.impl.ChannelBufferWrapper;
import io.netty.buffer.Unpooled;
import io.netty.buffer.PooledByteBufAllocator;

public final class ActiveMQBuffers
{
    private static final PooledByteBufAllocator ALLOCATOR;
    
    public static ActiveMQBuffer dynamicBuffer(final int size) {
        return new ChannelBufferWrapper(Unpooled.buffer(size));
    }
    
    public static ActiveMQBuffer pooledBuffer(final int size) {
        return new ChannelBufferWrapper(ActiveMQBuffers.ALLOCATOR.heapBuffer(size), true, true);
    }
    
    public static ActiveMQBuffer dynamicBuffer(final byte[] bytes) {
        final ActiveMQBuffer buff = dynamicBuffer(bytes.length);
        buff.writeBytes(bytes);
        return buff;
    }
    
    public static ActiveMQBuffer wrappedBuffer(final ByteBuffer underlying) {
        final ActiveMQBuffer buff = new ChannelBufferWrapper(Unpooled.wrappedBuffer(underlying));
        buff.clear();
        return buff;
    }
    
    public static ActiveMQBuffer wrappedBuffer(final ByteBuf underlying) {
        final ActiveMQBuffer buff = new ChannelBufferWrapper(underlying.duplicate());
        return buff;
    }
    
    public static ActiveMQBuffer wrappedBuffer(final byte[] underlying) {
        return new ChannelBufferWrapper(Unpooled.wrappedBuffer(underlying));
    }
    
    public static ActiveMQBuffer fixedBuffer(final int size) {
        return new ChannelBufferWrapper(Unpooled.buffer(size, size));
    }
    
    private ActiveMQBuffers() {
    }
    
    static {
        ALLOCATOR = PooledByteBufAllocator.DEFAULT;
    }
}
