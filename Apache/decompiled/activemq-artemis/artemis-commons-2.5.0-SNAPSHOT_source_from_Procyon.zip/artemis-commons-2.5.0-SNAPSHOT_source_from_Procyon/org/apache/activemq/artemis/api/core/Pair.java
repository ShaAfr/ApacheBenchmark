// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

import java.io.Serializable;

public final class Pair<A, B> implements Serializable
{
    private static final long serialVersionUID = -2496357457812368127L;
    private A a;
    private B b;
    private int hash;
    
    public Pair(final A a, final B b) {
        this.hash = -1;
        this.a = a;
        this.b = b;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == -1) {
            if (this.a == null && this.b == null) {
                return super.hashCode();
            }
            this.hash = ((this.a == null) ? 0 : this.a.hashCode()) + 37 * ((this.b == null) ? 0 : this.b.hashCode());
        }
        return this.hash;
    }
    
    @Override
    public boolean equals(final Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof Pair)) {
            return false;
        }
        final Pair<A, B> pother = (Pair<A, B>)other;
        if (pother.a == null) {
            if (this.a != null) {
                return false;
            }
        }
        else if (!pother.a.equals(this.a)) {
            return false;
        }
        if ((pother.b != null) ? pother.b.equals(this.b) : (this.b == null)) {
            return true;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "Pair[a=" + this.a + ", b=" + this.b + "]";
    }
    
    public void setA(final A a) {
        this.hash = -1;
        this.a = a;
    }
    
    public A getA() {
        return this.a;
    }
    
    public void setB(final B b) {
        this.hash = -1;
        this.b = b;
    }
    
    public B getB() {
        return this.b;
    }
}
