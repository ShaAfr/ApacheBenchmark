// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;
import java.security.AccessController;
import org.apache.activemq.artemis.logs.ActiveMQUtilBundle;
import java.util.ServiceLoader;
import org.apache.activemq.artemis.api.core.ActiveMQException;
import org.apache.activemq.artemis.api.core.ActiveMQExceptionType;

public final class PasswordMaskingUtil
{
    private PasswordMaskingUtil() {
    }
    
    public static HashProcessor getHashProcessor(final String storedPassword) throws Exception {
        if (!isEncoded(storedPassword)) {
            return LazyPlainTextProcessorHolder.INSTANCE;
        }
        final Exception secureProcessorException = LazySecureProcessorHolder.EXCEPTION;
        if (secureProcessorException != null) {
            throw new RuntimeException(secureProcessorException);
        }
        return LazySecureProcessorHolder.INSTANCE;
    }
    
    private static boolean isEncoded(final String storedPassword) {
        return storedPassword == null || (storedPassword.startsWith("ENC(") && storedPassword.endsWith(")"));
    }
    
    public static HashProcessor getHashProcessor() {
        HashProcessor processor = LazySecureProcessorHolder.INSTANCE;
        if (processor == null) {
            processor = LazyPlainTextProcessorHolder.INSTANCE;
        }
        return processor;
    }
    
    public static SensitiveDataCodec<String> getCodec(final String codecDesc) throws ActiveMQException {
        final String[] parts = codecDesc.split(";");
        if (parts.length < 1) {
            throw new ActiveMQException(ActiveMQExceptionType.ILLEGAL_STATE, "Invalid PasswordCodec value: " + codecDesc);
        }
        final String codecClassName = parts[0];
        final ServiceLoader<SensitiveDataCodec> serviceLoader;
        final Iterator<SensitiveDataCodec<String>> iterator;
        SensitiveDataCodec<String> codec;
        final String name;
        final SensitiveDataCodec<String> codecInstance = AccessController.doPrivileged(() -> {
            serviceLoader = (ServiceLoader<SensitiveDataCodec>)ServiceLoader.load(SensitiveDataCodec.class, PasswordMaskingUtil.class.getClassLoader());
            try {
                serviceLoader.iterator();
                while (iterator.hasNext()) {
                    codec = iterator.next();
                    if (codec.getClass().getCanonicalName().equals(name)) {
                        return (SensitiveDataCodec)codec.getClass().newInstance();
                    }
                }
            }
            catch (Exception ex) {}
            try {
                return (SensitiveDataCodec)PasswordMaskingUtil.class.getClassLoader().loadClass(name).newInstance();
            }
            catch (Exception e4) {
                try {
                    return (SensitiveDataCodec)Thread.currentThread().getContextClassLoader().loadClass(name).newInstance();
                }
                catch (Exception e2) {
                    throw ActiveMQUtilBundle.BUNDLE.errorCreatingCodec(e2, name);
                }
            }
        });
        if (parts.length > 1) {
            final Map<String, String> props = new HashMap<String, String>();
            for (int i = 1; i < parts.length; ++i) {
                final String[] keyVal = parts[i].split("=");
                if (keyVal.length != 2) {
                    throw ActiveMQUtilBundle.BUNDLE.invalidProperty(parts[i]);
                }
                props.put(keyVal[0], keyVal[1]);
            }
            try {
                codecInstance.init(props);
            }
            catch (Exception e3) {
                throw new ActiveMQException("Fail to init codec", e3, ActiveMQExceptionType.SECURITY_EXCEPTION);
            }
        }
        return codecInstance;
    }
    
    public static DefaultSensitiveStringCodec getDefaultCodec() {
        return new DefaultSensitiveStringCodec();
    }
    
    private static final class LazyPlainTextProcessorHolder
    {
        private static final HashProcessor INSTANCE;
        
        static {
            INSTANCE = new NoHashProcessor();
        }
    }
    
    private static final class LazySecureProcessorHolder
    {
        private static final HashProcessor INSTANCE;
        private static final Exception EXCEPTION;
        
        static {
            HashProcessor processor = null;
            Exception exception = null;
            final String codecDesc = DefaultSensitiveStringCodec.class.getName() + ";" + "algorithm" + "=" + "one-way";
            try {
                final DefaultSensitiveStringCodec codec = (DefaultSensitiveStringCodec)PasswordMaskingUtil.getCodec(codecDesc);
                processor = new SecureHashProcessor(codec);
            }
            catch (Exception e) {
                exception = e;
            }
            finally {
                EXCEPTION = exception;
                INSTANCE = processor;
            }
        }
    }
}
