// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.critical;

import java.util.Iterator;
import java.util.ConcurrentModificationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.apache.activemq.artemis.utils.collections.ConcurrentHashSet;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.activemq.artemis.core.server.ActiveMQScheduledComponent;
import org.jboss.logging.Logger;

public class CriticalAnalyzerImpl implements CriticalAnalyzer
{
    private final Logger logger;
    private volatile long timeoutNanoSeconds;
    private volatile long checkTimeNanoSeconds;
    private final ActiveMQScheduledComponent scheduledComponent;
    private final AtomicBoolean running;
    private CopyOnWriteArrayList<CriticalAction> actions;
    private final ConcurrentHashSet<CriticalComponent> components;
    
    public CriticalAnalyzerImpl() {
        this.logger = Logger.getLogger((Class)CriticalAnalyzer.class);
        this.checkTimeNanoSeconds = TimeUnit.SECONDS.toNanos(60L);
        this.running = new AtomicBoolean(false);
        this.actions = new CopyOnWriteArrayList<CriticalAction>();
        this.components = new ConcurrentHashSet<CriticalComponent>();
        this.scheduledComponent = new ActiveMQScheduledComponent(null, null, this.checkTimeNanoSeconds, TimeUnit.NANOSECONDS, false) {
            @Override
            public void run() {
                CriticalAnalyzerImpl.this.logger.trace((Object)"Checking critical analyzer");
                CriticalAnalyzerImpl.this.check();
            }
        };
    }
    
    @Override
    public void clear() {
        this.actions.clear();
        this.components.clear();
    }
    
    @Override
    public boolean isMeasuring() {
        return true;
    }
    
    @Override
    public void add(final CriticalComponent component) {
        this.components.add(component);
    }
    
    @Override
    public void remove(final CriticalComponent component) {
        this.components.remove(component);
    }
    
    @Override
    public CriticalAnalyzer setCheckTime(final long timeout, final TimeUnit unit) {
        this.checkTimeNanoSeconds = unit.toNanos(timeout);
        this.scheduledComponent.setPeriod(timeout, unit);
        return this;
    }
    
    @Override
    public long getCheckTimeNanoSeconds() {
        if (this.checkTimeNanoSeconds == 0L) {
            this.checkTimeNanoSeconds = this.getTimeout(TimeUnit.NANOSECONDS) / 2L;
        }
        return this.checkTimeNanoSeconds;
    }
    
    @Override
    public CriticalAnalyzer setTimeout(final long timeout, final TimeUnit unit) {
        if (this.checkTimeNanoSeconds <= 0L) {
            this.setCheckTime(timeout / 2L, unit);
        }
        this.timeoutNanoSeconds = unit.toNanos(timeout);
        return this;
    }
    
    @Override
    public long getTimeout(final TimeUnit unit) {
        if (this.timeoutNanoSeconds == 0L) {
            this.timeoutNanoSeconds = TimeUnit.MINUTES.toNanos(2L);
        }
        return unit.convert(this.timeoutNanoSeconds, TimeUnit.NANOSECONDS);
    }
    
    @Override
    public CriticalAnalyzer addAction(final CriticalAction action) {
        this.actions.add(action);
        return this;
    }
    
    @Override
    public void check() {
        boolean retry = true;
        while (retry) {
            try {
                for (final CriticalComponent component : this.components) {
                    if (component.isExpired(this.timeoutNanoSeconds)) {
                        this.fireAction(component);
                        return;
                    }
                }
                retry = false;
            }
            catch (ConcurrentModificationException ex) {}
        }
    }
    
    private void fireAction(final CriticalComponent component) {
        for (final CriticalAction action : this.actions) {
            try {
                action.run(component);
            }
            catch (Throwable e) {
                this.logger.warn((Object)e.getMessage(), e);
            }
        }
        this.actions.clear();
    }
    
    @Override
    public void start() {
        this.scheduledComponent.start();
    }
    
    @Override
    public void stop() {
        this.scheduledComponent.stop();
    }
    
    @Override
    public boolean isStarted() {
        return this.scheduledComponent.isStarted();
    }
}
