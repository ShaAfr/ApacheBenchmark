// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

import java.nio.ByteBuffer;
import io.netty.buffer.ByteBuf;
import java.io.DataInput;

public interface ActiveMQBuffer extends DataInput
{
    ByteBuf byteBuf();
    
    int capacity();
    
    int readerIndex();
    
    void readerIndex(final int p0);
    
    int writerIndex();
    
    void writerIndex(final int p0);
    
    void setIndex(final int p0, final int p1);
    
    int readableBytes();
    
    int writableBytes();
    
    boolean readable();
    
    boolean writable();
    
    void clear();
    
    void markReaderIndex();
    
    void resetReaderIndex();
    
    void markWriterIndex();
    
    void resetWriterIndex();
    
    void discardReadBytes();
    
    byte getByte(final int p0);
    
    short getUnsignedByte(final int p0);
    
    short getShort(final int p0);
    
    int getUnsignedShort(final int p0);
    
    int getInt(final int p0);
    
    long getUnsignedInt(final int p0);
    
    long getLong(final int p0);
    
    void getBytes(final int p0, final ActiveMQBuffer p1);
    
    void getBytes(final int p0, final ActiveMQBuffer p1, final int p2);
    
    void getBytes(final int p0, final ActiveMQBuffer p1, final int p2, final int p3);
    
    void getBytes(final int p0, final byte[] p1);
    
    void getBytes(final int p0, final byte[] p1, final int p2, final int p3);
    
    void getBytes(final int p0, final ByteBuffer p1);
    
    char getChar(final int p0);
    
    float getFloat(final int p0);
    
    double getDouble(final int p0);
    
    void setByte(final int p0, final byte p1);
    
    void setShort(final int p0, final short p1);
    
    void setInt(final int p0, final int p1);
    
    void setLong(final int p0, final long p1);
    
    void setBytes(final int p0, final ActiveMQBuffer p1);
    
    void setBytes(final int p0, final ActiveMQBuffer p1, final int p2);
    
    void setBytes(final int p0, final ActiveMQBuffer p1, final int p2, final int p3);
    
    void setBytes(final int p0, final byte[] p1);
    
    void setBytes(final int p0, final byte[] p1, final int p2, final int p3);
    
    void setBytes(final int p0, final ByteBuffer p1);
    
    void setChar(final int p0, final char p1);
    
    void setFloat(final int p0, final float p1);
    
    void setDouble(final int p0, final double p1);
    
    byte readByte();
    
    int readUnsignedByte();
    
    short readShort();
    
    int readUnsignedShort();
    
    int readInt();
    
    long readUnsignedInt();
    
    long readLong();
    
    char readChar();
    
    float readFloat();
    
    double readDouble();
    
    boolean readBoolean();
    
    SimpleString readNullableSimpleString();
    
    String readNullableString();
    
    SimpleString readSimpleString();
    
    String readString();
    
    String readUTF();
    
    ActiveMQBuffer readBytes(final int p0);
    
    ActiveMQBuffer readSlice(final int p0);
    
    void readBytes(final ActiveMQBuffer p0);
    
    void readBytes(final ActiveMQBuffer p0, final int p1);
    
    void readBytes(final ActiveMQBuffer p0, final int p1, final int p2);
    
    void readBytes(final byte[] p0);
    
    void readBytes(final byte[] p0, final int p1, final int p2);
    
    void readBytes(final ByteBuffer p0);
    
    int skipBytes(final int p0);
    
    void writeByte(final byte p0);
    
    void writeShort(final short p0);
    
    void writeInt(final int p0);
    
    void writeLong(final long p0);
    
    void writeChar(final char p0);
    
    void writeFloat(final float p0);
    
    void writeDouble(final double p0);
    
    void writeBoolean(final boolean p0);
    
    void writeNullableSimpleString(final SimpleString p0);
    
    void writeNullableString(final String p0);
    
    void writeSimpleString(final SimpleString p0);
    
    void writeString(final String p0);
    
    void writeUTF(final String p0);
    
    void writeBytes(final ActiveMQBuffer p0, final int p1);
    
    void writeBytes(final ActiveMQBuffer p0, final int p1, final int p2);
    
    void writeBytes(final byte[] p0);
    
    void writeBytes(final byte[] p0, final int p1, final int p2);
    
    void writeBytes(final ByteBuffer p0);
    
    void writeBytes(final ByteBuf p0, final int p1, final int p2);
    
    ActiveMQBuffer copy();
    
    ActiveMQBuffer copy(final int p0, final int p1);
    
    ActiveMQBuffer slice();
    
    ActiveMQBuffer slice(final int p0, final int p1);
    
    ActiveMQBuffer duplicate();
    
    ByteBuffer toByteBuffer();
    
    ByteBuffer toByteBuffer(final int p0, final int p1);
    
    void release();
}
