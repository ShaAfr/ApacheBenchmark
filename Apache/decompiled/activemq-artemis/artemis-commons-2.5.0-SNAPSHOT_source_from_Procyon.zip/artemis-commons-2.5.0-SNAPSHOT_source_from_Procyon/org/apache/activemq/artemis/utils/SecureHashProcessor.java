// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

public class SecureHashProcessor implements HashProcessor
{
    public static final String BEGIN_HASH = "ENC(";
    public static final String END_HASH = ")";
    private DefaultSensitiveStringCodec codec;
    
    public SecureHashProcessor(final DefaultSensitiveStringCodec codec) {
        this.codec = codec;
    }
    
    @Override
    public String hash(final String plainText) throws Exception {
        return "ENC(" + this.codec.encode((Object)plainText) + ")";
    }
    
    @Override
    public boolean compare(final char[] inputValue, final String storedValue) {
        final String storedHash = storedValue.substring(4, storedValue.length() - 2);
        return this.codec.verify(inputValue, storedHash);
    }
}
