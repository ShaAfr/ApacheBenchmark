// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.logs;

import java.text.FieldPosition;
import java.text.MessageFormat;
import java.util.Arrays;
import org.apache.activemq.artemis.api.core.ActiveMQIllegalStateException;
import java.util.Locale;
import java.io.Serializable;

public class ActiveMQUtilBundle_$bundle implements ActiveMQUtilBundle, Serializable
{
    private static final long serialVersionUID = 1L;
    public static final ActiveMQUtilBundle_$bundle INSTANCE;
    private static final Locale LOCALE;
    private static final String invalidProperty = "AMQ209000: invalid property: {0}";
    private static final String invalidType = "AMQ209001: Invalid type: {0}";
    private static final String stringTooLong = "AMQ209002: the specified string is too long ({0})";
    private static final String errorCreatingCodec = "AMQ209003: Error instantiating codec {0}";
    private static final String failedToParseLong = "AMQ209004: Failed to parse long value from {0}";
    
    protected ActiveMQUtilBundle_$bundle() {
    }
    
    protected Object readResolve() {
        return ActiveMQUtilBundle_$bundle.INSTANCE;
    }
    
    protected Locale getLoggingLocale() {
        return ActiveMQUtilBundle_$bundle.LOCALE;
    }
    
    protected String invalidProperty$str() {
        return "AMQ209000: invalid property: {0}";
    }
    
    @Override
    public final ActiveMQIllegalStateException invalidProperty(final String part) {
        final ActiveMQIllegalStateException result = new ActiveMQIllegalStateException(this._formatMessage(this.invalidProperty$str(), part));
        final StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));
        return result;
    }
    
    private String _formatMessage(final String format, final Object... args) {
        final MessageFormat formatter = new MessageFormat(format, this.getLoggingLocale());
        return formatter.format(args, new StringBuffer(), new FieldPosition(0)).toString();
    }
    
    protected String invalidType$str() {
        return "AMQ209001: Invalid type: {0}";
    }
    
    @Override
    public final IllegalStateException invalidType(final Byte type) {
        final IllegalStateException result = new IllegalStateException(this._formatMessage(this.invalidType$str(), type));
        final StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));
        return result;
    }
    
    protected String stringTooLong$str() {
        return "AMQ209002: the specified string is too long ({0})";
    }
    
    @Override
    public final IllegalStateException stringTooLong(final Integer length) {
        final IllegalStateException result = new IllegalStateException(this._formatMessage(this.stringTooLong$str(), length));
        final StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));
        return result;
    }
    
    protected String errorCreatingCodec$str() {
        return "AMQ209003: Error instantiating codec {0}";
    }
    
    @Override
    public final IllegalArgumentException errorCreatingCodec(final Exception e, final String codecClassName) {
        final IllegalArgumentException result = new IllegalArgumentException(this._formatMessage(this.errorCreatingCodec$str(), codecClassName), e);
        final StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));
        return result;
    }
    
    protected String failedToParseLong$str() {
        return "AMQ209004: Failed to parse long value from {0}";
    }
    
    @Override
    public final IllegalArgumentException failedToParseLong(final String value) {
        final IllegalArgumentException result = new IllegalArgumentException(this._formatMessage(this.failedToParseLong$str(), value));
        final StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));
        return result;
    }
    
    static {
        INSTANCE = new ActiveMQUtilBundle_$bundle();
        LOCALE = Locale.ROOT;
    }
}
