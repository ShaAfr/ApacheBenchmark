// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import org.apache.activemq.artemis.api.core.SimpleString;

public class CompositeAddress
{
    public static String SEPARATOR;
    private final String address;
    private final String queueName;
    private final boolean fqqn;
    
    public static SimpleString toFullQN(final SimpleString address, final SimpleString qName) {
        return address.concat(CompositeAddress.SEPARATOR).concat(qName);
    }
    
    public static String toFullQN(final String address, final String qName) {
        return address + CompositeAddress.SEPARATOR + qName;
    }
    
    public String getAddress() {
        return this.address;
    }
    
    public String getQueueName() {
        return this.queueName;
    }
    
    public CompositeAddress(final String address, final String queueName) {
        this.address = address;
        this.queueName = queueName;
        this.fqqn = (address != null && !address.isEmpty());
    }
    
    public CompositeAddress(final String singleName) {
        final int index = singleName.indexOf(CompositeAddress.SEPARATOR);
        if (index == -1) {
            this.fqqn = false;
            this.address = null;
            this.queueName = singleName;
        }
        else {
            this.fqqn = true;
            this.address = singleName.substring(0, index);
            this.queueName = singleName.substring(index + 2);
        }
    }
    
    public boolean isFqqn() {
        return this.fqqn;
    }
    
    public static boolean isFullyQualified(final String address) {
        return address.contains(CompositeAddress.SEPARATOR);
    }
    
    public static CompositeAddress getQueueName(final String address) {
        final int index = address.indexOf(CompositeAddress.SEPARATOR);
        if (index == -1) {
            throw new IllegalStateException("Not A Fully Qualified Name");
        }
        return new CompositeAddress(address.substring(0, index), address.substring(index + 2));
    }
    
    public static String extractQueueName(final String name) {
        final int index = name.indexOf(CompositeAddress.SEPARATOR);
        if (index != -1) {
            return name.substring(index + 2);
        }
        return name;
    }
    
    public static SimpleString extractQueueName(final SimpleString name) {
        return new SimpleString(extractQueueName(name.toString()));
    }
    
    public static String extractAddressName(final String address) {
        final String[] split = address.split(CompositeAddress.SEPARATOR);
        return split[0];
    }
    
    static {
        CompositeAddress.SEPARATOR = "::";
    }
}
