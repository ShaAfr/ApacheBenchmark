// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import org.apache.activemq.artemis.logs.ActiveMQUtilLogger;
import java.io.IOException;
import java.util.Set;
import java.nio.file.Files;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.nio.file.attribute.PosixFilePermission;
import java.io.File;

public class FileUtil
{
    public static void makeExec(final File file) throws IOException {
        try {
            Files.setPosixFilePermissions(file.toPath(), new HashSet<PosixFilePermission>(Arrays.asList(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE, PosixFilePermission.OWNER_EXECUTE, PosixFilePermission.GROUP_READ, PosixFilePermission.GROUP_WRITE, PosixFilePermission.GROUP_EXECUTE, PosixFilePermission.OTHERS_READ, PosixFilePermission.OTHERS_EXECUTE)));
        }
        catch (Throwable t) {}
    }
    
    public static final boolean deleteDirectory(final File directory) {
        if (directory.isDirectory()) {
            String[] files = directory.list();
            for (int num = 5, attempts = 0; files == null && attempts < num; files = directory.list(), ++attempts) {
                try {
                    Thread.sleep(100L);
                }
                catch (InterruptedException ex) {}
            }
            if (files == null) {
                ActiveMQUtilLogger.LOGGER.failedListFilesToCleanup(directory.getAbsolutePath());
            }
            else {
                for (final String file : files) {
                    final File f = new File(directory, file);
                    if (!deleteDirectory(f)) {
                        ActiveMQUtilLogger.LOGGER.failedToCleanupFile(f.getAbsolutePath());
                    }
                }
            }
        }
        return directory.delete();
    }
}
