// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQIOErrorException extends ActiveMQException
{
    private static final long serialVersionUID = 797277117077787396L;
    
    public ActiveMQIOErrorException() {
        super(ActiveMQExceptionType.IO_ERROR);
    }
    
    public ActiveMQIOErrorException(final String msg) {
        super(ActiveMQExceptionType.IO_ERROR, msg);
    }
    
    public ActiveMQIOErrorException(final String msg, final Throwable cause) {
        super(ActiveMQExceptionType.IO_ERROR, msg, cause);
    }
}
