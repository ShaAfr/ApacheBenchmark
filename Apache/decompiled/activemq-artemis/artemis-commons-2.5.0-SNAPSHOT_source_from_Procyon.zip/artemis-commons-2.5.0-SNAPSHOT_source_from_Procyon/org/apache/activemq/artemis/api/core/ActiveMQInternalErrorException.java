// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQInternalErrorException extends ActiveMQException
{
    private static final long serialVersionUID = -5987814047521530695L;
    
    public ActiveMQInternalErrorException() {
        super(ActiveMQExceptionType.INTERNAL_ERROR);
    }
    
    public ActiveMQInternalErrorException(final String msg) {
        super(ActiveMQExceptionType.INTERNAL_ERROR, msg);
    }
    
    public ActiveMQInternalErrorException(final String message, final Exception e) {
        super(ActiveMQExceptionType.INTERNAL_ERROR, message, e);
    }
    
    public ActiveMQInternalErrorException(final String message, final Throwable t) {
        super(ActiveMQExceptionType.INTERNAL_ERROR, message, t);
    }
}
