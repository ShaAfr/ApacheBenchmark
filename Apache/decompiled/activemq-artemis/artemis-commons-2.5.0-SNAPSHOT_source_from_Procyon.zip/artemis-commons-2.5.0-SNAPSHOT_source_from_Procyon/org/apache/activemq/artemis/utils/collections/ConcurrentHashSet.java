// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.AbstractSet;

public class ConcurrentHashSet<E> extends AbstractSet<E> implements ConcurrentSet<E>
{
    private final ConcurrentMap<E, Object> theMap;
    private static final Object dummy;
    
    public ConcurrentHashSet() {
        this.theMap = new ConcurrentHashMap<E, Object>();
    }
    
    @Override
    public int size() {
        return this.theMap.size();
    }
    
    @Override
    public Iterator<E> iterator() {
        return this.theMap.keySet().iterator();
    }
    
    @Override
    public boolean isEmpty() {
        return this.theMap.isEmpty();
    }
    
    @Override
    public boolean add(final E o) {
        return this.theMap.put(o, ConcurrentHashSet.dummy) == null;
    }
    
    @Override
    public boolean contains(final Object o) {
        return this.theMap.containsKey(o);
    }
    
    @Override
    public void clear() {
        this.theMap.clear();
    }
    
    @Override
    public boolean remove(final Object o) {
        return this.theMap.remove(o) == ConcurrentHashSet.dummy;
    }
    
    @Override
    public boolean addIfAbsent(final E o) {
        final Object obj = this.theMap.putIfAbsent(o, ConcurrentHashSet.dummy);
        return obj == null;
    }
    
    static {
        dummy = new Object();
    }
}
