// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQRemoteDisconnectException extends ActiveMQException
{
    public ActiveMQRemoteDisconnectException() {
        super(ActiveMQExceptionType.REMOTE_DISCONNECT);
    }
    
    public ActiveMQRemoteDisconnectException(final String msg) {
        super(ActiveMQExceptionType.REMOTE_DISCONNECT, msg);
    }
}
