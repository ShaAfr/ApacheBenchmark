// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.logs;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.logging.Level;
import org.jboss.logmanager.ExtLogRecord;
import java.util.Map;
import org.jboss.logmanager.ExtHandler;

public class AssertionLoggerHandler extends ExtHandler
{
    private static final Map<String, ExtLogRecord> messages;
    private static boolean capture;
    
    public void flush() {
    }
    
    public void close() throws SecurityException {
    }
    
    protected void doPublish(final ExtLogRecord record) {
        if (AssertionLoggerHandler.capture) {
            AssertionLoggerHandler.messages.put(record.getFormattedMessage(), record);
        }
    }
    
    public static boolean hasLevel(final Level level) {
        for (final ExtLogRecord record : AssertionLoggerHandler.messages.values()) {
            if (record.getLevel().equals(level)) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean findText(final long mstimeout, final String... text) {
        final long timeMax = System.currentTimeMillis() + mstimeout;
        while (!findText(text)) {
            if (timeMax <= System.currentTimeMillis()) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean findText(final String... text) {
        for (final Map.Entry<String, ExtLogRecord> entry : AssertionLoggerHandler.messages.entrySet()) {
            final String key = entry.getKey();
            boolean found = true;
            for (final String txtCheck : text) {
                found = key.contains(txtCheck);
                if (!found) {
                    final Throwable throwable = entry.getValue().getThrown();
                    if (throwable == null || throwable.getMessage() == null) {
                        break;
                    }
                    found = throwable.getMessage().contains(txtCheck);
                    if (!found) {
                        break;
                    }
                }
            }
            if (found) {
                return true;
            }
        }
        return false;
    }
    
    public static final void clear() {
        AssertionLoggerHandler.messages.clear();
    }
    
    public static final void startCapture() {
        clear();
        AssertionLoggerHandler.capture = true;
    }
    
    public static final void stopCapture() {
        AssertionLoggerHandler.capture = false;
        clear();
    }
    
    static {
        messages = new ConcurrentHashMap<String, ExtLogRecord>();
        AssertionLoggerHandler.capture = false;
    }
}
