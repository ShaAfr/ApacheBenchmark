// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.critical;

import java.util.concurrent.TimeUnit;

public class EmptyCriticalAnalyzer implements CriticalAnalyzer
{
    private static final EmptyCriticalAnalyzer instance;
    
    public static EmptyCriticalAnalyzer getInstance() {
        return EmptyCriticalAnalyzer.instance;
    }
    
    private EmptyCriticalAnalyzer() {
    }
    
    @Override
    public void add(final CriticalComponent component) {
    }
    
    @Override
    public void remove(final CriticalComponent component) {
    }
    
    @Override
    public boolean isMeasuring() {
        return false;
    }
    
    @Override
    public void start() throws Exception {
    }
    
    @Override
    public void stop() throws Exception {
    }
    
    @Override
    public boolean isStarted() {
        return false;
    }
    
    @Override
    public CriticalAnalyzer setCheckTime(final long timeout, final TimeUnit unit) {
        return this;
    }
    
    @Override
    public long getCheckTimeNanoSeconds() {
        return 0L;
    }
    
    @Override
    public CriticalAnalyzer setTimeout(final long timeout, final TimeUnit unit) {
        return this;
    }
    
    @Override
    public long getTimeout(final TimeUnit unit) {
        return 0L;
    }
    
    @Override
    public CriticalAnalyzer addAction(final CriticalAction action) {
        return this;
    }
    
    @Override
    public void check() {
    }
    
    static {
        instance = new EmptyCriticalAnalyzer();
    }
}
