// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.Arrays;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import javax.crypto.SecretKeyFactory;
import java.security.Key;
import javax.crypto.Cipher;
import java.math.BigInteger;
import javax.crypto.spec.SecretKeySpec;
import java.util.Iterator;
import java.util.Properties;
import java.util.HashMap;
import java.util.Map;
import java.util.Collections;
import org.jboss.logging.Logger;

public class DefaultSensitiveStringCodec implements SensitiveDataCodec<String>
{
    private static final Logger logger;
    public static final String ALGORITHM = "algorithm";
    public static final String BLOWFISH_KEY = "key";
    public static final String ONE_WAY = "one-way";
    public static final String TWO_WAY = "two-way";
    private CodecAlgorithm algorithm;
    
    public DefaultSensitiveStringCodec() {
        this.algorithm = new BlowfishAlgorithm(Collections.EMPTY_MAP);
    }
    
    @Override
    public String decode(final Object secret) throws Exception {
        return this.algorithm.decode((String)secret);
    }
    
    @Override
    public String encode(final Object secret) throws Exception {
        return this.algorithm.encode((String)secret);
    }
    
    @Override
    public void init(final Map<String, String> params) throws Exception {
        final String algorithm = params.get("algorithm");
        if (algorithm == null || algorithm.equals("two-way")) {
            this.algorithm = new BlowfishAlgorithm(params);
        }
        else {
            if (!algorithm.equals("one-way")) {
                throw new IllegalArgumentException("Invalid algorithm: " + algorithm);
            }
            this.algorithm = new PBKDF2Algorithm(params);
        }
    }
    
    public static void main(final String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Use: java -cp <classPath> org.apache.activemq.artemis.utils.DefaultSensitiveStringCodec password-to-encode");
            System.err.println("Error: no password on the args");
            System.exit(-1);
        }
        final DefaultSensitiveStringCodec codec = new DefaultSensitiveStringCodec();
        final Map<String, String> params = new HashMap<String, String>();
        final Properties properties = System.getProperties();
        synchronized (properties) {
            for (final String name : properties.stringPropertyNames()) {
                params.put(name, properties.getProperty(name));
            }
        }
        codec.init(params);
        final Object encode = codec.encode((Object)args[0]);
        System.out.println("Encoded password (without quotes): \"" + encode + "\"");
    }
    
    public boolean verify(final char[] inputValue, final String storedValue) {
        return this.algorithm.verify(inputValue, storedValue);
    }
    
    static {
        logger = Logger.getLogger((Class)DefaultSensitiveStringCodec.class);
    }
    
    private abstract class CodecAlgorithm
    {
        protected Map<String, String> params;
        
        CodecAlgorithm(final Map<String, String> params) {
            this.params = params;
        }
        
        public abstract String decode(final String p0) throws Exception;
        
        public abstract String encode(final String p0) throws Exception;
        
        public boolean verify(final char[] inputValue, final String storedValue) {
            return false;
        }
    }
    
    private class BlowfishAlgorithm extends CodecAlgorithm
    {
        private byte[] internalKey;
        
        BlowfishAlgorithm(final Map<String, String> params) {
            super(params);
            this.internalKey = "clusterpassword".getBytes();
            final String key = params.get("key");
            if (key != null) {
                this.updateKey(key);
            }
        }
        
        private void updateKey(final String key) {
            this.internalKey = key.getBytes();
        }
        
        @Override
        public String decode(final String secret) throws Exception {
            final SecretKeySpec key = new SecretKeySpec(this.internalKey, "Blowfish");
            byte[] encoding;
            try {
                encoding = new BigInteger(secret, 16).toByteArray();
            }
            catch (Exception ex) {
                if (DefaultSensitiveStringCodec.logger.isDebugEnabled()) {
                    DefaultSensitiveStringCodec.logger.debug((Object)ex.getMessage(), (Throwable)ex);
                }
                throw new IllegalArgumentException("Password must be encrypted.");
            }
            if (encoding.length % 8 != 0) {
                final int length = encoding.length;
                final int newLength = (length / 8 + 1) * 8;
                final int pad = newLength - length;
                final byte[] old = encoding;
                encoding = new byte[newLength];
                System.arraycopy(old, 0, encoding, pad, old.length);
            }
            final Cipher cipher = Cipher.getInstance("Blowfish");
            cipher.init(2, key);
            final byte[] decode = cipher.doFinal(encoding);
            return new String(decode);
        }
        
        @Override
        public String encode(final String secret) throws Exception {
            final SecretKeySpec key = new SecretKeySpec(this.internalKey, "Blowfish");
            final Cipher cipher = Cipher.getInstance("Blowfish");
            cipher.init(1, key);
            final byte[] encoding = cipher.doFinal(secret.getBytes());
            final BigInteger n = new BigInteger(encoding);
            return n.toString(16);
        }
    }
    
    private class PBKDF2Algorithm extends CodecAlgorithm
    {
        private static final String SEPARATOR = ":";
        private String sceretKeyAlgorithm;
        private String randomScheme;
        private int keyLength;
        private int saltLength;
        private int iterations;
        private SecretKeyFactory skf;
        
        PBKDF2Algorithm(final Map<String, String> params) throws NoSuchAlgorithmException {
            super(params);
            this.sceretKeyAlgorithm = "PBKDF2WithHmacSHA1";
            this.randomScheme = "SHA1PRNG";
            this.keyLength = 512;
            this.saltLength = 32;
            this.iterations = 1024;
            this.skf = SecretKeyFactory.getInstance(this.sceretKeyAlgorithm);
        }
        
        @Override
        public String decode(final String secret) throws Exception {
            throw new IllegalArgumentException("Algorithm doesn't support decoding");
        }
        
        public byte[] getSalt() throws NoSuchAlgorithmException {
            final byte[] salt = RandomUtil.randomBytes(this.saltLength);
            return salt;
        }
        
        @Override
        public String encode(final String secret) throws Exception {
            final char[] chars = secret.toCharArray();
            final byte[] salt = this.getSalt();
            final StringBuilder builder = new StringBuilder();
            builder.append(this.iterations).append(":").append(ByteUtil.bytesToHex(salt)).append(":");
            final PBEKeySpec spec = new PBEKeySpec(chars, salt, this.iterations, this.keyLength);
            final byte[] hash = this.skf.generateSecret(spec).getEncoded();
            final String hexValue = ByteUtil.bytesToHex(hash);
            builder.append(hexValue);
            return builder.toString();
        }
        
        @Override
        public boolean verify(final char[] plainChars, final String storedValue) {
            final String[] parts = storedValue.split(":");
            final int originalIterations = Integer.parseInt(parts[0]);
            final byte[] salt = ByteUtil.hexToBytes(parts[1]);
            final byte[] originalHash = ByteUtil.hexToBytes(parts[2]);
            final PBEKeySpec spec = new PBEKeySpec(plainChars, salt, originalIterations, originalHash.length * 8);
            byte[] newHash;
            try {
                newHash = this.skf.generateSecret(spec).getEncoded();
            }
            catch (InvalidKeySpecException e) {
                return false;
            }
            return Arrays.equals(newHash, originalHash);
        }
    }
}
