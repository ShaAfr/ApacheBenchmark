// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQInterruptedException extends RuntimeException
{
    private static final long serialVersionUID = -5744690023549671221L;
    
    public ActiveMQInterruptedException(final Throwable cause) {
        super(cause);
    }
    
    public ActiveMQInterruptedException(final String message) {
        super(message);
    }
}
