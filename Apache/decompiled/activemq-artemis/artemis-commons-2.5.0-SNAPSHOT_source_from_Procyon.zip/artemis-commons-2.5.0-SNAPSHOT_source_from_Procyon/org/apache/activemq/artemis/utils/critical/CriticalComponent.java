// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.critical;

public interface CriticalComponent
{
    default void enterCritical(final int path) {
    }
    
    default void leaveCritical(final int path) {
    }
    
    boolean isExpired(final long p0);
}
