// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.critical;

public interface CriticalAction
{
    void run(final CriticalComponent p0);
}
