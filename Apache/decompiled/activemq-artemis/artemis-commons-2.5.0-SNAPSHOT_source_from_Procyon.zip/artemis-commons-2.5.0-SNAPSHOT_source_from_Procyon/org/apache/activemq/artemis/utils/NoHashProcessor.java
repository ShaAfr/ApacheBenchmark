// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.Arrays;

public class NoHashProcessor implements HashProcessor
{
    @Override
    public String hash(final String plainText) throws Exception {
        return plainText;
    }
    
    @Override
    public boolean compare(final char[] inputValue, final String storedHash) {
        return Arrays.equals(inputValue, storedHash.toCharArray());
    }
}
