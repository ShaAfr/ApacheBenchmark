// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.actors;

import java.util.concurrent.Executor;

public class Actor<T> extends ProcessorBase<T>
{
    private final ActorListener<T> listener;
    
    public Actor(final Executor parent, final ActorListener<T> listener) {
        super(parent);
        this.listener = listener;
    }
    
    @Override
    protected final void doTask(final T task) {
        this.listener.onMessage(task);
    }
    
    public final void act(final T message) {
        this.task(message);
    }
}
