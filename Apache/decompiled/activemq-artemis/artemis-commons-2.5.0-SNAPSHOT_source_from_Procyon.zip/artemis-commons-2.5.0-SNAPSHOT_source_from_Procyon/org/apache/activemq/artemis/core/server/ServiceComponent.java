// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.core.server;

public interface ServiceComponent extends ActiveMQComponent
{
    void stop(final boolean p0) throws Exception;
}
