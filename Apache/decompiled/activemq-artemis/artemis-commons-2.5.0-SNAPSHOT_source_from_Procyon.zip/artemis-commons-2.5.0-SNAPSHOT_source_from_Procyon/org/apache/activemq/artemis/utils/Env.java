// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import sun.misc.Unsafe;

public final class Env
{
    private static final int OS_PAGE_SIZE;
    private static boolean testEnv;
    
    private Env() {
    }
    
    public static int osPageSize() {
        return Env.OS_PAGE_SIZE;
    }
    
    public static boolean isTestEnv() {
        return Env.testEnv;
    }
    
    public static void setTestEnv(final boolean testEnv) {
        Env.testEnv = testEnv;
    }
    
    static {
        int osPageSize = 4096;
        Unsafe instance;
        try {
            final Field field = Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            instance = (Unsafe)field.get(null);
        }
        catch (Throwable t) {
            try {
                final Constructor<Unsafe> c = Unsafe.class.getDeclaredConstructor((Class<?>[])new Class[0]);
                c.setAccessible(true);
                instance = c.newInstance(new Object[0]);
            }
            catch (Throwable t2) {
                instance = null;
            }
        }
        if (instance != null) {
            osPageSize = instance.pageSize();
        }
        OS_PAGE_SIZE = osPageSize;
        Env.testEnv = false;
    }
}
