// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.actors;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.LockSupport;
import java.util.function.Consumer;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.Executor;
import java.util.Queue;
import org.jboss.logging.Logger;

public abstract class ProcessorBase<T> extends HandlerBase
{
    private static final Logger logger;
    public static final int STATE_NOT_RUNNING = 0;
    public static final int STATE_RUNNING = 1;
    public static final int STATE_FORCED_SHUTDOWN = 2;
    protected final Queue<T> tasks;
    private final Executor delegate;
    private final Runnable task;
    private volatile int state;
    private volatile boolean requestedForcedShutdown;
    private volatile boolean requestedShutdown;
    private static final AtomicIntegerFieldUpdater<ProcessorBase> stateUpdater;
    
    private void executePendingTasks() {
        while (ProcessorBase.stateUpdater.compareAndSet(this, 0, 1)) {
            this.enter();
            try {
                T task;
                while (!this.requestedForcedShutdown && (task = this.tasks.poll()) != null) {
                    this.doTask(task);
                }
                this.leave();
                if (!ProcessorBase.stateUpdater.compareAndSet(this, 1, 0)) {
                    return;
                }
            }
            finally {
                this.leave();
                if (!ProcessorBase.stateUpdater.compareAndSet(this, 1, 0)) {
                    return;
                }
            }
            if (this.tasks.isEmpty() || this.requestedShutdown) {
                return;
            }
        }
    }
    
    public void shutdown() {
        this.shutdown(30L, TimeUnit.SECONDS);
    }
    
    public void shutdown(final long timeout, final TimeUnit unit) {
        this.requestedShutdown = true;
        if (!this.inHandler()) {
            this.flush(timeout, unit);
        }
    }
    
    public int shutdownNow(final Consumer<? super T> onPendingItem) {
        this.requestedForcedShutdown = true;
        this.requestedShutdown = true;
        if (this.inHandler()) {
            ProcessorBase.stateUpdater.set(this, 2);
        }
        else {
            do {
                final int startState = ProcessorBase.stateUpdater.get(this);
                if (startState == 2) {
                    break;
                }
                if (startState != 1) {
                    continue;
                }
                LockSupport.parkNanos(100000000L);
            } while (!ProcessorBase.stateUpdater.compareAndSet(this, 0, 2));
        }
        int pendingItems = 0;
        synchronized (this.tasks) {
            T item;
            while ((item = this.tasks.poll()) != null) {
                onPendingItem.accept((Object)item);
                ++pendingItems;
            }
        }
        return pendingItems;
    }
    
    protected abstract void doTask(final T p0);
    
    public ProcessorBase(final Executor parent) {
        this.tasks = new ConcurrentLinkedQueue<T>();
        this.task = this::executePendingTasks;
        this.state = 0;
        this.requestedForcedShutdown = false;
        this.requestedShutdown = false;
        this.delegate = parent;
    }
    
    public final boolean isFlushed() {
        return this.state == 0;
    }
    
    public final boolean flush(final long timeout, final TimeUnit unit) {
        if (this.state == 0) {
            return true;
        }
        final long timeLimit = System.currentTimeMillis() + unit.toMillis(timeout);
        try {
            while (this.state == 1 && timeLimit > System.currentTimeMillis()) {
                if (this.tasks.isEmpty()) {
                    return true;
                }
                Thread.sleep(10L);
            }
        }
        catch (InterruptedException ex) {}
        return this.state == 0;
    }
    
    protected void task(final T command) {
        if (this.requestedShutdown) {
            logAddOnShutdown();
        }
        this.tasks.add(command);
        final int state = ProcessorBase.stateUpdater.get(this);
        if (state != 1) {
            this.onAddedTaskIfNotRunning(state);
        }
    }
    
    private void onAddedTaskIfNotRunning(final int state) {
        if (state == 0) {
            this.delegate.execute(this.task);
        }
        else if (state == 2) {
            synchronized (this.tasks) {
                this.tasks.clear();
            }
        }
    }
    
    private static void logAddOnShutdown() {
        if (ProcessorBase.logger.isDebugEnabled()) {
            ProcessorBase.logger.debug((Object)"Ordered executor has been gently shutdown at", (Throwable)new Exception("debug"));
        }
    }
    
    public final int remaining() {
        return this.tasks.size();
    }
    
    public final int status() {
        return this.state;
    }
    
    static {
        logger = Logger.getLogger((Class)ProcessorBase.class);
        stateUpdater = AtomicIntegerFieldUpdater.newUpdater(ProcessorBase.class, "state");
    }
}
