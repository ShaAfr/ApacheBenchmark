// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.api.core;

public final class ActiveMQPropertyConversionException extends RuntimeException
{
    private static final long serialVersionUID = -3010008708334904332L;
    
    public ActiveMQPropertyConversionException(final String message) {
        super(message);
    }
}
