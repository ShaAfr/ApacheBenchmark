// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

import java.util.Set;

public interface ConcurrentSet<E> extends Set<E>
{
    boolean addIfAbsent(final E p0);
}
