// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.concurrent.TimeoutException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.CountDownLatch;

public class SimpleFutureImpl<V> implements SimpleFuture<V>
{
    V value;
    Throwable exception;
    private final CountDownLatch latch;
    boolean canceled;
    
    public SimpleFutureImpl() {
        this.latch = new CountDownLatch(1);
        this.canceled = false;
    }
    
    @Override
    public boolean cancel(final boolean mayInterruptIfRunning) {
        this.canceled = true;
        this.latch.countDown();
        return true;
    }
    
    @Override
    public boolean isCancelled() {
        return this.canceled;
    }
    
    @Override
    public boolean isDone() {
        return this.latch.getCount() <= 0L;
    }
    
    @Override
    public void fail(final Throwable e) {
        this.exception = e;
        this.latch.countDown();
    }
    
    @Override
    public V get() throws InterruptedException, ExecutionException {
        this.latch.await();
        if (this.exception != null) {
            throw new ExecutionException(this.exception);
        }
        return this.value;
    }
    
    @Override
    public void set(final V v) {
        this.value = v;
        this.latch.countDown();
    }
    
    @Override
    public V get(final long timeout, final TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
        this.latch.await(timeout, unit);
        return this.value;
    }
}
