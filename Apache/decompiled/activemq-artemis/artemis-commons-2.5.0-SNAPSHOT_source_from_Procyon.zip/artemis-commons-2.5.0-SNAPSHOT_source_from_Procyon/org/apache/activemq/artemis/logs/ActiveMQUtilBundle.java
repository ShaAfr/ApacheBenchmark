// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.logs;

import org.jboss.logging.Messages;
import org.jboss.logging.annotations.Cause;
import org.jboss.logging.annotations.Message;
import org.apache.activemq.artemis.api.core.ActiveMQIllegalStateException;
import org.jboss.logging.annotations.MessageBundle;

@MessageBundle(projectCode = "AMQ")
public interface ActiveMQUtilBundle
{
    public static final ActiveMQUtilBundle BUNDLE = (ActiveMQUtilBundle)Messages.getBundle((Class)ActiveMQUtilBundle.class);
    
    @Message(id = 209000, value = "invalid property: {0}", format = Message.Format.MESSAGE_FORMAT)
    ActiveMQIllegalStateException invalidProperty(final String p0);
    
    @Message(id = 209001, value = "Invalid type: {0}", format = Message.Format.MESSAGE_FORMAT)
    IllegalStateException invalidType(final Byte p0);
    
    @Message(id = 209002, value = "the specified string is too long ({0})", format = Message.Format.MESSAGE_FORMAT)
    IllegalStateException stringTooLong(final Integer p0);
    
    @Message(id = 209003, value = "Error instantiating codec {0}", format = Message.Format.MESSAGE_FORMAT)
    IllegalArgumentException errorCreatingCodec(@Cause final Exception p0, final String p1);
    
    @Message(id = 209004, value = "Failed to parse long value from {0}", format = Message.Format.MESSAGE_FORMAT)
    IllegalArgumentException failedToParseLong(final String p0);
}
