// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

import java.util.Arrays;
import java.util.concurrent.locks.StampedLock;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.function.LongFunction;
import com.google.common.base.Preconditions;

public class ConcurrentLongHashMap<V>
{
    private static final Object EmptyValue;
    private static final Object DeletedValue;
    private static final float MapFillFactor = 0.66f;
    private static final int DefaultExpectedItems = 256;
    private static final int DefaultConcurrencyLevel = 16;
    private final Section<V>[] sections;
    private static final long HashMixer = -4132994306676758123L;
    private static final int R = 47;
    
    public ConcurrentLongHashMap() {
        this(256);
    }
    
    public ConcurrentLongHashMap(final int expectedItems) {
        this(expectedItems, 16);
    }
    
    public ConcurrentLongHashMap(int expectedItems, final int numSections) {
        Preconditions.checkArgument(numSections > 0);
        if (expectedItems < numSections) {
            expectedItems = numSections;
        }
        final int perSectionExpectedItems = expectedItems / numSections;
        final int perSectionCapacity = (int)(perSectionExpectedItems / 0.66f);
        this.sections = (Section<V>[])new Section[numSections];
        for (int i = 0; i < numSections; ++i) {
            this.sections[i] = new Section<V>(perSectionCapacity);
        }
    }
    
    public int size() {
        int size = 0;
        for (final Section<V> s : this.sections) {
            size += ((Section<Object>)s).size;
        }
        return size;
    }
    
    long getUsedBucketCount() {
        long usedBucketCount = 0L;
        for (final Section<V> s : this.sections) {
            usedBucketCount += ((Section<Object>)s).usedBuckets;
        }
        return usedBucketCount;
    }
    
    public long capacity() {
        long capacity = 0L;
        for (final Section<V> s : this.sections) {
            capacity += ((Section<Object>)s).capacity;
        }
        return capacity;
    }
    
    public boolean isEmpty() {
        for (final Section<V> s : this.sections) {
            if (((Section<Object>)s).size != 0) {
                return false;
            }
        }
        return true;
    }
    
    public V get(final long key) {
        final long h = hash(key);
        return this.getSection(h).get(key, (int)h);
    }
    
    public boolean containsKey(final long key) {
        return this.get(key) != null;
    }
    
    public V put(final long key, final V value) {
        Preconditions.checkNotNull((Object)value);
        final long h = hash(key);
        return this.getSection(h).put(key, value, (int)h, false, null);
    }
    
    public V putIfAbsent(final long key, final V value) {
        Preconditions.checkNotNull((Object)value);
        final long h = hash(key);
        return this.getSection(h).put(key, value, (int)h, true, null);
    }
    
    public V computeIfAbsent(final long key, final LongFunction<V> provider) {
        Preconditions.checkNotNull((Object)provider);
        final long h = hash(key);
        return this.getSection(h).put(key, null, (int)h, true, provider);
    }
    
    public V remove(final long key) {
        final long h = hash(key);
        return (V)this.getSection(h).remove(key, null, (int)h);
    }
    
    public boolean remove(final long key, final Object value) {
        Preconditions.checkNotNull(value);
        final long h = hash(key);
        return this.getSection(h).remove(key, value, (int)h) != null;
    }
    
    private Section<V> getSection(final long hash) {
        final int sectionIdx = (int)(hash >>> 32) & this.sections.length - 1;
        return this.sections[sectionIdx];
    }
    
    public void clear() {
        for (final Section<V> s : this.sections) {
            s.clear();
        }
    }
    
    public void forEach(final EntryProcessor<V> processor) {
        for (final Section<V> s : this.sections) {
            s.forEach(processor);
        }
    }
    
    public List<Long> keys() {
        final List<Long> keys = (List<Long>)Lists.newArrayListWithExpectedSize(this.size());
        this.forEach((key, value) -> keys.add(key));
        return keys;
    }
    
    public ConcurrentLongHashSet keysLongHashSet() {
        final ConcurrentLongHashSet concurrentLongHashSet = new ConcurrentLongHashSet(this.size());
        this.forEach((key, value) -> concurrentLongHashSet.add(key));
        return concurrentLongHashSet;
    }
    
    public List<V> values() {
        final List<V> values = (List<V>)Lists.newArrayListWithExpectedSize(this.size());
        this.forEach((key, value) -> values.add(value));
        return values;
    }
    
    static long hash(final long key) {
        long hash = key * -4132994306676758123L;
        hash ^= hash >>> 47;
        hash *= -4132994306676758123L;
        return hash;
    }
    
    static int signSafeMod(final long n, final int Max) {
        return (int)n & Max - 1;
    }
    
    static int alignToPowerOfTwo(final int n) {
        return (int)Math.pow(2.0, 32 - Integer.numberOfLeadingZeros(n - 1));
    }
    
    static {
        EmptyValue = null;
        DeletedValue = new Object();
    }
    
    private static final class Section<V> extends StampedLock
    {
        private long[] keys;
        private V[] values;
        private int capacity;
        private volatile int size;
        private int usedBuckets;
        private int resizeThreshold;
        
        Section(final int capacity) {
            this.capacity = ConcurrentLongHashMap.alignToPowerOfTwo(capacity);
            this.keys = new long[this.capacity];
            this.values = (V[])new Object[this.capacity];
            this.size = 0;
            this.usedBuckets = 0;
            this.resizeThreshold = (int)(this.capacity * 0.66f);
        }
        
        V get(final long key, final int keyHash) {
            int bucket = keyHash;
            long stamp = this.tryOptimisticRead();
            boolean acquiredLock = false;
            try {
                while (true) {
                    final int capacity = this.capacity;
                    bucket = ConcurrentLongHashMap.signSafeMod(bucket, capacity);
                    long storedKey = this.keys[bucket];
                    V storedValue = this.values[bucket];
                    if (!acquiredLock && this.validate(stamp)) {
                        if (storedKey == key) {
                            return (storedValue != ConcurrentLongHashMap.DeletedValue) ? storedValue : null;
                        }
                        if (storedValue == ConcurrentLongHashMap.EmptyValue) {
                            return null;
                        }
                    }
                    else {
                        if (!acquiredLock) {
                            stamp = this.readLock();
                            acquiredLock = true;
                            storedKey = this.keys[bucket];
                            storedValue = this.values[bucket];
                        }
                        if (capacity != this.capacity) {
                            bucket = keyHash;
                            continue;
                        }
                        if (storedKey == key) {
                            return (storedValue != ConcurrentLongHashMap.DeletedValue) ? storedValue : null;
                        }
                        if (storedValue == ConcurrentLongHashMap.EmptyValue) {
                            return null;
                        }
                    }
                    ++bucket;
                }
            }
            finally {
                if (acquiredLock) {
                    this.unlockRead(stamp);
                }
            }
        }
        
        V put(final long key, final V value, final int keyHash, final boolean onlyIfAbsent, final LongFunction<V> valueProvider) {
            int bucket = keyHash;
            final long stamp = this.writeLock();
            final int capacity = this.capacity;
            int firstDeletedKey = -1;
            try {
                while (true) {
                    bucket = ConcurrentLongHashMap.signSafeMod(bucket, capacity);
                    final long storedKey = this.keys[bucket];
                    final V storedValue = this.values[bucket];
                    if (storedKey == key) {
                        if (storedValue == ConcurrentLongHashMap.EmptyValue) {
                            this.values[bucket] = ((value != null) ? value : valueProvider.apply(key));
                            ++this.size;
                            ++this.usedBuckets;
                            return (valueProvider != null) ? this.values[bucket] : null;
                        }
                        if (storedValue == ConcurrentLongHashMap.DeletedValue) {
                            this.values[bucket] = ((value != null) ? value : valueProvider.apply(key));
                            ++this.size;
                            return (valueProvider != null) ? this.values[bucket] : null;
                        }
                        if (!onlyIfAbsent) {
                            this.values[bucket] = value;
                            return storedValue;
                        }
                        return storedValue;
                    }
                    else {
                        if (storedValue == ConcurrentLongHashMap.EmptyValue) {
                            if (firstDeletedKey != -1) {
                                bucket = firstDeletedKey;
                            }
                            else {
                                ++this.usedBuckets;
                            }
                            this.keys[bucket] = key;
                            this.values[bucket] = ((value != null) ? value : valueProvider.apply(key));
                            ++this.size;
                            return (valueProvider != null) ? this.values[bucket] : null;
                        }
                        if (storedValue == ConcurrentLongHashMap.DeletedValue && firstDeletedKey == -1) {
                            firstDeletedKey = bucket;
                        }
                        ++bucket;
                    }
                }
            }
            finally {
                if (this.usedBuckets > this.resizeThreshold) {
                    try {
                        this.rehash();
                    }
                    finally {
                        this.unlockWrite(stamp);
                    }
                }
                else {
                    this.unlockWrite(stamp);
                }
            }
        }
        
        private V remove(final long key, final Object value, final int keyHash) {
            int bucket = keyHash;
            final long stamp = this.writeLock();
            try {
                while (true) {
                    final int capacity = this.capacity;
                    bucket = ConcurrentLongHashMap.signSafeMod(bucket, capacity);
                    final long storedKey = this.keys[bucket];
                    final V storedValue = this.values[bucket];
                    if (storedKey == key) {
                        if (value != null && !value.equals(storedValue)) {
                            return null;
                        }
                        if (storedValue == ConcurrentLongHashMap.EmptyValue || storedValue == ConcurrentLongHashMap.DeletedValue) {
                            return null;
                        }
                        --this.size;
                        final V nextValueInArray = this.values[ConcurrentLongHashMap.signSafeMod(bucket + 1, capacity)];
                        if (nextValueInArray == ConcurrentLongHashMap.EmptyValue) {
                            this.values[bucket] = (V)ConcurrentLongHashMap.EmptyValue;
                            --this.usedBuckets;
                        }
                        else {
                            this.values[bucket] = (V)ConcurrentLongHashMap.DeletedValue;
                        }
                        return storedValue;
                    }
                    else {
                        if (storedValue == ConcurrentLongHashMap.EmptyValue) {
                            return null;
                        }
                        ++bucket;
                    }
                }
            }
            finally {
                this.unlockWrite(stamp);
            }
        }
        
        void clear() {
            final long stamp = this.writeLock();
            try {
                Arrays.fill(this.keys, 0L);
                Arrays.fill(this.values, ConcurrentLongHashMap.EmptyValue);
                this.size = 0;
                this.usedBuckets = 0;
            }
            finally {
                this.unlockWrite(stamp);
            }
        }
        
        public void forEach(final EntryProcessor<V> processor) {
            long stamp = this.tryOptimisticRead();
            int capacity = this.capacity;
            long[] keys = this.keys;
            V[] values = this.values;
            boolean acquiredReadLock = false;
            try {
                if (!this.validate(stamp)) {
                    stamp = this.readLock();
                    acquiredReadLock = true;
                    capacity = this.capacity;
                    keys = this.keys;
                    values = this.values;
                }
                for (int bucket = 0; bucket < capacity; ++bucket) {
                    long storedKey = keys[bucket];
                    V storedValue = values[bucket];
                    if (!acquiredReadLock && !this.validate(stamp)) {
                        stamp = this.readLock();
                        acquiredReadLock = true;
                        storedKey = keys[bucket];
                        storedValue = values[bucket];
                    }
                    if (storedValue != ConcurrentLongHashMap.DeletedValue && storedValue != ConcurrentLongHashMap.EmptyValue) {
                        processor.accept(storedKey, storedValue);
                    }
                }
            }
            finally {
                if (acquiredReadLock) {
                    this.unlockRead(stamp);
                }
            }
        }
        
        private void rehash() {
            final int newCapacity = this.capacity * 2;
            final long[] newKeys = new long[newCapacity];
            final V[] newValues = (V[])new Object[newCapacity];
            for (int i = 0; i < this.keys.length; ++i) {
                final long storedKey = this.keys[i];
                final V storedValue = this.values[i];
                if (storedValue != ConcurrentLongHashMap.EmptyValue && storedValue != ConcurrentLongHashMap.DeletedValue) {
                    insertKeyValueNoLock(newKeys, newValues, storedKey, storedValue);
                }
            }
            this.capacity = newCapacity;
            this.keys = newKeys;
            this.values = newValues;
            this.usedBuckets = this.size;
            this.resizeThreshold = (int)(this.capacity * 0.66f);
        }
        
        private static <V> void insertKeyValueNoLock(final long[] keys, final V[] values, final long key, final V value) {
            int bucket = (int)ConcurrentLongHashMap.hash(key);
            while (true) {
                bucket = ConcurrentLongHashMap.signSafeMod(bucket, keys.length);
                final V storedValue = values[bucket];
                if (storedValue == ConcurrentLongHashMap.EmptyValue) {
                    break;
                }
                ++bucket;
            }
            keys[bucket] = key;
            values[bucket] = value;
        }
    }
    
    public interface EntryProcessor<V>
    {
        void accept(final long p0, final V p1);
    }
}
