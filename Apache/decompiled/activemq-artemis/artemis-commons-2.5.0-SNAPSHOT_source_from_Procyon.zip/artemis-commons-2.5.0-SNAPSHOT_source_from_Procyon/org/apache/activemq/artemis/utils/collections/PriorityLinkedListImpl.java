// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils.collections;

import java.util.NoSuchElementException;
import java.lang.reflect.Array;

public class PriorityLinkedListImpl<T> implements PriorityLinkedList<T>
{
    protected LinkedListImpl<T>[] levels;
    private int size;
    private int lastReset;
    private int highestPriority;
    private int lastPriority;
    
    public PriorityLinkedListImpl(final int priorities) {
        this.highestPriority = -1;
        this.lastPriority = -1;
        this.levels = (LinkedListImpl<T>[])Array.newInstance(LinkedListImpl.class, priorities);
        for (int i = 0; i < priorities; ++i) {
            this.levels[i] = new LinkedListImpl<T>();
        }
    }
    
    private void checkHighest(final int priority) {
        if (this.lastPriority != priority || priority > this.highestPriority) {
            this.lastPriority = priority;
            if (this.lastReset == Integer.MAX_VALUE) {
                this.lastReset = 0;
            }
            else {
                ++this.lastReset;
            }
        }
        if (priority > this.highestPriority) {
            this.highestPriority = priority;
        }
    }
    
    @Override
    public void addHead(final T t, final int priority) {
        this.checkHighest(priority);
        this.levels[priority].addHead(t);
        ++this.size;
    }
    
    @Override
    public void addTail(final T t, final int priority) {
        this.checkHighest(priority);
        this.levels[priority].addTail(t);
        ++this.size;
    }
    
    @Override
    public T poll() {
        T t = null;
        int i = this.highestPriority;
        while (i >= 0) {
            final LinkedListImpl<T> ll = this.levels[i];
            if (ll.size() != 0) {
                t = ll.poll();
                if (t == null) {
                    break;
                }
                --this.size;
                if (ll.size() == 0 && this.highestPriority == i) {
                    --this.highestPriority;
                    break;
                }
                break;
            }
            else {
                --i;
            }
        }
        return t;
    }
    
    @Override
    public void clear() {
        for (final LinkedListImpl<T> list : this.levels) {
            list.clear();
        }
        this.size = 0;
    }
    
    @Override
    public int size() {
        return this.size;
    }
    
    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }
    
    @Override
    public LinkedListIterator<T> iterator() {
        return new PriorityLinkedListIterator();
    }
    
    private class PriorityLinkedListIterator implements LinkedListIterator<T>
    {
        private int index;
        private final LinkedListIterator<T>[] cachedIters;
        private LinkedListIterator<T> lastIter;
        private int resetCount;
        volatile boolean closed;
        
        PriorityLinkedListIterator() {
            this.cachedIters = (LinkedListIterator<T>[])new LinkedListIterator[PriorityLinkedListImpl.this.levels.length];
            this.resetCount = PriorityLinkedListImpl.this.lastReset;
            this.closed = false;
            this.index = PriorityLinkedListImpl.this.levels.length - 1;
        }
        
        @Override
        protected void finalize() {
            this.close();
        }
        
        @Override
        public void repeat() {
            if (this.lastIter == null) {
                throw new NoSuchElementException();
            }
            this.lastIter.repeat();
        }
        
        @Override
        public void close() {
            if (!this.closed) {
                this.closed = true;
                this.lastIter = null;
                for (final LinkedListIterator<T> iter : this.cachedIters) {
                    if (iter != null) {
                        iter.close();
                    }
                }
            }
        }
        
        private void checkReset() {
            if (PriorityLinkedListImpl.this.lastReset != this.resetCount) {
                this.index = PriorityLinkedListImpl.this.highestPriority;
                this.resetCount = PriorityLinkedListImpl.this.lastReset;
            }
        }
        
        @Override
        public boolean hasNext() {
            this.checkReset();
            while (this.index >= 0) {
                this.lastIter = this.cachedIters[this.index];
                if (this.lastIter == null) {
                    final LinkedListIterator<T>[] cachedIters = this.cachedIters;
                    final int index = this.index;
                    final LinkedListIterator<T> iterator = PriorityLinkedListImpl.this.levels[this.index].iterator();
                    cachedIters[index] = iterator;
                    this.lastIter = iterator;
                }
                final boolean b = this.lastIter.hasNext();
                if (b) {
                    return true;
                }
                --this.index;
                if (this.index < 0) {
                    this.index = PriorityLinkedListImpl.this.levels.length - 1;
                    break;
                }
            }
            return false;
        }
        
        @Override
        public T next() {
            if (this.lastIter == null) {
                throw new NoSuchElementException();
            }
            return this.lastIter.next();
        }
        
        @Override
        public void remove() {
            if (this.lastIter == null) {
                throw new NoSuchElementException();
            }
            this.lastIter.remove();
            for (int i = this.index; i >= 0 && PriorityLinkedListImpl.this.levels[this.index].size() == 0; --i) {
                PriorityLinkedListImpl.this.highestPriority = i;
            }
            PriorityLinkedListImpl.this.size--;
        }
    }
}
