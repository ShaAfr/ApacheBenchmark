// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;

public class ConcurrentUtil
{
    public static boolean await(final Condition condition, final long timeout) throws InterruptedException {
        boolean awaited = false;
        for (long timeoutRemaining = timeout, awaitStarted = System.currentTimeMillis(); !awaited && timeoutRemaining > 0L; awaited = condition.await(timeoutRemaining, TimeUnit.MILLISECONDS), timeoutRemaining -= System.currentTimeMillis() - awaitStarted) {}
        return awaited;
    }
}
