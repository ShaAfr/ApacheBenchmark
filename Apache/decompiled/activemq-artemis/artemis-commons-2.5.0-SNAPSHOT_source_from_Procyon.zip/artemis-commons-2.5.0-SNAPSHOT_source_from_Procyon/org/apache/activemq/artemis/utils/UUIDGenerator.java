// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.Iterator;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Callable;
import java.util.Enumeration;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Arrays;
import org.apache.activemq.artemis.api.core.SimpleString;
import java.net.NetworkInterface;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.Executors;
import org.apache.activemq.artemis.logs.ActiveMQUtilLogger;
import java.security.SecureRandom;
import java.util.Random;

public final class UUIDGenerator
{
    private static final UUIDGenerator sSingleton;
    private static final byte[][] BLACK_LIST;
    private Random mRnd;
    private final Object mTimerLock;
    private UUIDTimer mTimer;
    private byte[] address;
    
    private UUIDGenerator() {
        this.mRnd = null;
        this.mTimerLock = new Object();
        this.mTimer = null;
    }
    
    public static UUIDGenerator getInstance() {
        return UUIDGenerator.sSingleton;
    }
    
    public Random getRandomNumberGenerator() {
        if (this.mRnd == null) {
            this.mRnd = new SecureRandom();
        }
        return this.mRnd;
    }
    
    public UUID generateTimeBasedUUID(final byte[] byteAddr) {
        final byte[] contents = new byte[16];
        final int pos = 10;
        System.arraycopy(byteAddr, 0, contents, pos, 6);
        synchronized (this.mTimerLock) {
            if (this.mTimer == null) {
                this.mTimer = new UUIDTimer(this.getRandomNumberGenerator());
            }
            this.mTimer.getTimestamp(contents);
        }
        return new UUID(1, contents);
    }
    
    public byte[] generateDummyAddress() {
        final Random rnd = this.getRandomNumberGenerator();
        final byte[] dummy = new byte[6];
        rnd.nextBytes(dummy);
        final byte[] array = dummy;
        final int n = 0;
        array[n] |= 0x1;
        if (ActiveMQUtilLogger.LOGGER.isDebugEnabled()) {
            ActiveMQUtilLogger.LOGGER.debug((Object)("using dummy address " + asString(dummy)));
        }
        return dummy;
    }
    
    public static byte[] getHardwareAddress() {
        try {
            final ExecutorService executor = Executors.newFixedThreadPool(1, ActiveMQThreadFactory.defaultThreadFactory());
            executor.shutdownNow();
        }
        catch (Throwable t) {
            return null;
        }
        try {
            final List<NetworkInterface> ifaces = getAllNetworkInterfaces();
            if (ifaces.size() == 0) {
                return null;
            }
            final byte[] address = findFirstMatchingHardwareAddress(ifaces);
            if (address != null) {
                if (ActiveMQUtilLogger.LOGGER.isDebugEnabled()) {
                    ActiveMQUtilLogger.LOGGER.debug((Object)("using hardware address " + asString(address)));
                }
                return address;
            }
            return null;
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public SimpleString generateSimpleStringUUID() {
        return new SimpleString(this.generateStringUUID());
    }
    
    public UUID generateUUID() {
        final byte[] address = this.getAddressBytes();
        final UUID uid = this.generateTimeBasedUUID(address);
        return uid;
    }
    
    public String generateStringUUID() {
        final byte[] address = this.getAddressBytes();
        if (address == null) {
            return java.util.UUID.randomUUID().toString();
        }
        return this.generateTimeBasedUUID(address).toString();
    }
    
    public static byte[] getZeroPaddedSixBytes(final byte[] bytes) {
        if (bytes == null) {
            return null;
        }
        if (bytes.length <= 0 || bytes.length > 6) {
            return null;
        }
        if (bytes.length == 6) {
            return bytes;
        }
        final byte[] paddedAddress = new byte[6];
        System.arraycopy(bytes, 0, paddedAddress, 0, bytes.length);
        for (int i = bytes.length; i < 6; ++i) {
            paddedAddress[i] = 0;
        }
        return paddedAddress;
    }
    
    private static boolean isBlackList(final byte[] address) {
        for (final byte[] blackList : UUIDGenerator.BLACK_LIST) {
            if (Arrays.equals(address, blackList)) {
                return true;
            }
        }
        return false;
    }
    
    private byte[] getAddressBytes() {
        if (this.address == null) {
            this.address = getHardwareAddress();
            if (this.address == null) {
                this.address = this.generateDummyAddress();
            }
        }
        return this.address;
    }
    
    private static String asString(final byte[] bytes) {
        if (bytes == null) {
            return null;
        }
        final StringBuilder s = new StringBuilder();
        for (int i = 0; i < bytes.length - 1; ++i) {
            s.append(Integer.toHexString(bytes[i]));
            s.append(":");
        }
        s.append(bytes[bytes.length - 1]);
        return s.toString();
    }
    
    private static List<NetworkInterface> getAllNetworkInterfaces() {
        try {
            final Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            if (networkInterfaces == null) {
                return Collections.emptyList();
            }
            final List<NetworkInterface> ifaces = new ArrayList<NetworkInterface>();
            while (networkInterfaces.hasMoreElements()) {
                ifaces.add(networkInterfaces.nextElement());
            }
            return ifaces;
        }
        catch (SocketException e) {
            return Collections.emptyList();
        }
    }
    
    private static byte[] findFirstMatchingHardwareAddress(final List<NetworkInterface> ifaces) {
        final ExecutorService executor = Executors.newFixedThreadPool(ifaces.size(), ActiveMQThreadFactory.defaultThreadFactory());
        final Collection<Callable<byte[]>> tasks = new ArrayList<Callable<byte[]>>(ifaces.size());
        for (final NetworkInterface networkInterface : ifaces) {
            tasks.add(new Callable<byte[]>() {
                @Override
                public byte[] call() throws Exception {
                    final boolean up = networkInterface.isUp();
                    final boolean loopback = networkInterface.isLoopback();
                    final boolean virtual = networkInterface.isVirtual();
                    if (loopback || virtual || !up) {
                        throw new Exception("not suitable interface");
                    }
                    final byte[] address = networkInterface.getHardwareAddress();
                    if (address != null) {
                        final byte[] paddedAddress = UUIDGenerator.getZeroPaddedSixBytes(address);
                        if (isBlackList(address)) {
                            throw new Exception("black listed address");
                        }
                        if (paddedAddress != null) {
                            return paddedAddress;
                        }
                    }
                    throw new Exception("invalid network interface");
                }
            });
        }
        try {
            final byte[] address = executor.invokeAny((Collection<? extends Callable<byte[]>>)tasks, 5L, TimeUnit.SECONDS);
            return address;
        }
        catch (Exception e) {
            return null;
        }
        finally {
            executor.shutdownNow();
        }
    }
    
    static {
        sSingleton = new UUIDGenerator();
        BLACK_LIST = new byte[][] { { 2, 0, 84, 85, 78, 1 } };
    }
}
