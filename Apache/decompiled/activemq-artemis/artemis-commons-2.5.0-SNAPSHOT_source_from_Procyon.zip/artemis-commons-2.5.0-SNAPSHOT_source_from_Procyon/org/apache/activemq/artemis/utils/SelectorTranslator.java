// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.activemq.artemis.utils;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

public class SelectorTranslator
{
    public static String convertToActiveMQFilterString(final String selectorString) {
        if (selectorString == null) {
            return null;
        }
        String filterString = parse(selectorString, "JMSDeliveryMode", "AMQDurable");
        filterString = parse(filterString, "'PERSISTENT'", "'DURABLE'");
        filterString = parse(filterString, "'NON_PERSISTENT'", "'NON_DURABLE'");
        filterString = parse(filterString, "JMSPriority", "AMQPriority");
        filterString = parse(filterString, "JMSTimestamp", "AMQTimestamp");
        filterString = parse(filterString, "JMSMessageID", "AMQUserID");
        filterString = parse(filterString, "JMSExpiration", "AMQExpiration");
        return filterString;
    }
    
    private static String parse(final String input, final String match, final String replace) {
        final char quote = '\'';
        boolean inQuote = false;
        int matchPos = 0;
        final List<Integer> positions = new ArrayList<Integer>();
        final boolean replaceInQuotes = match.charAt(0) == '\'';
        for (int i = 0; i < input.length(); ++i) {
            final char c = input.charAt(i);
            if (c == '\'') {
                inQuote = !inQuote;
            }
            if ((!inQuote || replaceInQuotes) && c == match.charAt(matchPos)) {
                if (++matchPos == match.length()) {
                    boolean matched = true;
                    if (i < input.length() - 1 && Character.isJavaIdentifierPart(input.charAt(i + 1))) {
                        matched = false;
                    }
                    final int posBeforeStart = i - match.length();
                    if (posBeforeStart >= 0 && Character.isJavaIdentifierPart(input.charAt(posBeforeStart))) {
                        matched = false;
                    }
                    if (matched) {
                        positions.add(i - match.length() + 1);
                    }
                    matchPos = 0;
                }
            }
            else {
                matchPos = 0;
            }
        }
        if (!positions.isEmpty()) {
            final StringBuffer buff = new StringBuffer();
            int startPos = 0;
            for (final int pos : positions) {
                final String substr = input.substring(startPos, pos);
                buff.append(substr);
                buff.append(replace);
                startPos = pos + match.length();
            }
            if (startPos < input.length()) {
                buff.append(input.substring(startPos, input.length()));
            }
            return buff.toString();
        }
        return input;
    }
}
