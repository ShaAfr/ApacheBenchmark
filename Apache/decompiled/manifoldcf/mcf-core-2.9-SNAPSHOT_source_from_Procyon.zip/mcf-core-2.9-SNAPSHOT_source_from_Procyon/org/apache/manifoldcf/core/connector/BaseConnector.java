// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.connector;

import org.apache.manifoldcf.core.interfaces.IPostParameters;
import java.util.Iterator;
import java.util.ArrayList;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import org.apache.manifoldcf.core.interfaces.IHTTPOutput;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import org.apache.manifoldcf.core.interfaces.ConfigParams;
import org.apache.manifoldcf.core.interfaces.IConnector;

public abstract class BaseConnector implements IConnector
{
    public static final String _rcsid = "@(#)$Id: BaseConnector.java 988245 2010-08-23 18:39:35Z kwright $";
    protected ConfigParams params;
    protected IThreadContext currentContext;
    
    public BaseConnector() {
        this.params = null;
        this.currentContext = null;
    }
    
    @Override
    public void install(final IThreadContext threadContext) throws ManifoldCFException {
    }
    
    @Override
    public void deinstall(final IThreadContext threadContext) throws ManifoldCFException {
    }
    
    @Override
    public void connect(final ConfigParams configParams) {
        this.params = configParams;
    }
    
    @Override
    public String check() throws ManifoldCFException {
        return "Connection working";
    }
    
    @Override
    public void poll() throws ManifoldCFException {
    }
    
    @Override
    public boolean isConnected() {
        return true;
    }
    
    @Override
    public void disconnect() throws ManifoldCFException {
        this.params = null;
    }
    
    @Override
    public void clearThreadContext() {
        this.currentContext = null;
    }
    
    @Override
    public void setThreadContext(final IThreadContext threadContext) throws ManifoldCFException {
        this.currentContext = threadContext;
    }
    
    @Override
    public ConfigParams getConfiguration() {
        return this.params;
    }
    
    @Override
    public void outputConfigurationHeader(final IThreadContext threadContext, final IHTTPOutput out, final Locale locale, final ConfigParams parameters, final List<String> tabsArray) throws ManifoldCFException, IOException {
        this.outputConfigurationHeader(threadContext, out, parameters, tabsArray);
    }
    
    public void outputConfigurationHeader(final IThreadContext threadContext, final IHTTPOutput out, final ConfigParams parameters, final List<String> tabsArray) throws ManifoldCFException, IOException {
        final ArrayList<Object> localTabsArray = new ArrayList<Object>();
        this.outputConfigurationHeader(threadContext, out, parameters, localTabsArray);
        for (final Object o : localTabsArray) {
            tabsArray.add((String)o);
        }
    }
    
    public void outputConfigurationHeader(final IThreadContext threadContext, final IHTTPOutput out, final ConfigParams parameters, final ArrayList<Object> tabsArray) throws ManifoldCFException, IOException {
    }
    
    @Override
    public void outputConfigurationBody(final IThreadContext threadContext, final IHTTPOutput out, final Locale locale, final ConfigParams parameters, final String tabName) throws ManifoldCFException, IOException {
        this.outputConfigurationBody(threadContext, out, parameters, tabName);
    }
    
    public void outputConfigurationBody(final IThreadContext threadContext, final IHTTPOutput out, final ConfigParams parameters, final String tabName) throws ManifoldCFException, IOException {
    }
    
    @Override
    public String processConfigurationPost(final IThreadContext threadContext, final IPostParameters variableContext, final Locale locale, final ConfigParams parameters) throws ManifoldCFException {
        return this.processConfigurationPost(threadContext, variableContext, parameters);
    }
    
    public String processConfigurationPost(final IThreadContext threadContext, final IPostParameters variableContext, final ConfigParams parameters) throws ManifoldCFException {
        return null;
    }
    
    @Override
    public void viewConfiguration(final IThreadContext threadContext, final IHTTPOutput out, final Locale locale, final ConfigParams parameters) throws ManifoldCFException, IOException {
        this.viewConfiguration(threadContext, out, parameters);
    }
    
    public void viewConfiguration(final IThreadContext threadContext, final IHTTPOutput out, final ConfigParams parameters) throws ManifoldCFException, IOException {
    }
    
    protected static void pack(final StringBuilder output, final String value, final char delimiter) {
        int i = 0;
        while (i < value.length()) {
            final char x = value.charAt(i++);
            if (x == '\\' || x == delimiter) {
                output.append('\\');
            }
            output.append(x);
        }
        output.append(delimiter);
    }
    
    protected static int unpack(final StringBuilder sb, final String value, int startPosition, final char delimiter) {
        while (startPosition < value.length()) {
            char x = value.charAt(startPosition++);
            if (x == '\\') {
                if (startPosition < value.length()) {
                    x = value.charAt(startPosition++);
                }
            }
            else if (x == delimiter) {
                break;
            }
            sb.append(x);
        }
        return startPosition;
    }
    
    protected static void packFixedList(final StringBuilder output, final String[] values, final char delimiter) {
        int i = 0;
        while (i < values.length) {
            pack(output, values[i++], delimiter);
        }
    }
    
    protected static int unpackFixedList(final String[] output, final String value, int startPosition, final char delimiter) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < output.length; output[i++] = sb.toString()) {
            sb.setLength(0);
            startPosition = unpack(sb, value, startPosition, delimiter);
        }
        return startPosition;
    }
    
    protected static void packList(final StringBuilder output, final List<String> values, final char delimiter) {
        pack(output, Integer.toString(values.size()), delimiter);
        int i = 0;
        while (i < values.size()) {
            pack(output, values.get(i++).toString(), delimiter);
        }
    }
    
    protected static void packList(final StringBuilder output, final String[] values, final char delimiter) {
        pack(output, Integer.toString(values.length), delimiter);
        int i = 0;
        while (i < values.length) {
            pack(output, values[i++], delimiter);
        }
    }
    
    protected static int unpackList(final List<String> output, final String value, int startPosition, final char delimiter) {
        final StringBuilder sb = new StringBuilder();
        startPosition = unpack(sb, value, startPosition, delimiter);
        try {
            for (int count = Integer.parseInt(sb.toString()), i = 0; i < count; ++i) {
                sb.setLength(0);
                startPosition = unpack(sb, value, startPosition, delimiter);
                output.add(sb.toString());
            }
        }
        catch (NumberFormatException ex) {}
        return startPosition;
    }
}
