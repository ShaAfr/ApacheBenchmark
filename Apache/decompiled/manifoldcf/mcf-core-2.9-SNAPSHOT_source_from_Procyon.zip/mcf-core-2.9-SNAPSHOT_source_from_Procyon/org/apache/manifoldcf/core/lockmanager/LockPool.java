// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.util.HashMap;
import java.util.Map;

public class LockPool
{
    public static final String _rcsid = "@(#)$Id: LockPool.java 988245 2010-08-23 18:39:35Z kwright $";
    protected final Map<Object, LockGate> myLocks;
    protected final LockObjectFactory factory;
    
    public LockPool(final LockObjectFactory factory) {
        this.myLocks = new HashMap<Object, LockGate>();
        this.factory = factory;
    }
    
    public synchronized LockGate getObject(final Object lockKey) {
        LockGate lg = this.myLocks.get(lockKey);
        if (lg == null) {
            final LockObject lo = this.factory.newLockObject(this, lockKey);
            lg = new LockGate(lockKey, lo, this);
            this.myLocks.put(lockKey, lg);
        }
        return lg;
    }
    
    public synchronized void releaseObject(final Object lockKey, final LockGate lockGate) {
        lockGate.makeInvalid();
        this.myLocks.remove(lockKey);
    }
}
