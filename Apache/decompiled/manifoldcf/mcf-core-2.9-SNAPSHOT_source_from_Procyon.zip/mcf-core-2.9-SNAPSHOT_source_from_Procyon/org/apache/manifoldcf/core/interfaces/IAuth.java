// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IAuth
{
    public static final int CAPABILITY_VIEW_CONNECTIONS = 1;
    public static final int CAPABILITY_VIEW_JOBS = 2;
    public static final int CAPABILITY_VIEW_REPORTS = 3;
    public static final int CAPABILITY_EDIT_CONNECTIONS = 4;
    public static final int CAPABILITY_EDIT_JOBS = 5;
    public static final int CAPABILITY_RUN_JOBS = 6;
    
    boolean verifyUILogin(final String p0, final String p1) throws ManifoldCFException;
    
    boolean verifyAPILogin(final String p0, final String p1) throws ManifoldCFException;
    
    boolean checkCapability(final String p0, final int p1) throws ManifoldCFException;
}
