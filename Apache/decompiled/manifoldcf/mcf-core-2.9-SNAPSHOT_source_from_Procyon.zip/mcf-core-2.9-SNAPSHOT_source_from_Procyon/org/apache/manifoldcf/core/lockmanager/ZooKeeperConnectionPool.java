// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.util.ArrayList;
import java.util.List;

public class ZooKeeperConnectionPool
{
    public static final String _rcsid = "@(#)$Id$";
    protected final String connectString;
    protected final int sessionTimeout;
    protected final List<ZooKeeperConnection> openConnectionList;
    
    public ZooKeeperConnectionPool(final String connectString, final int sessionTimeout) {
        this.openConnectionList = new ArrayList<ZooKeeperConnection>();
        this.connectString = connectString;
        this.sessionTimeout = sessionTimeout;
    }
    
    public synchronized ZooKeeperConnection grab() throws ManifoldCFException, InterruptedException {
        if (this.openConnectionList.size() == 0) {
            this.openConnectionList.add(new ZooKeeperConnection(this.connectString, this.sessionTimeout));
        }
        return this.openConnectionList.remove(this.openConnectionList.size() - 1);
    }
    
    public synchronized void release(final ZooKeeperConnection connection) {
        this.openConnectionList.add(connection);
    }
    
    public synchronized void closeAll() throws InterruptedException {
        for (final ZooKeeperConnection c : this.openConnectionList) {
            c.close();
        }
    }
}
