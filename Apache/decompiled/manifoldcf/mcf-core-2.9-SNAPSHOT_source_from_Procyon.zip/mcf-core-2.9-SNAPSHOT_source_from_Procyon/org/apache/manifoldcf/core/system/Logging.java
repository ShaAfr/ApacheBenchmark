// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.system;

import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import java.util.Map;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import org.apache.log4j.Level;
import java.io.File;
import java.util.HashMap;
import org.apache.log4j.Logger;

public class Logging
{
    public static final String _rcsid = "@(#)$Id: Logging.java 988245 2010-08-23 18:39:35Z kwright $";
    public static Logger root;
    public static Logger misc;
    public static Logger db;
    public static Logger lock;
    public static Logger cache;
    public static Logger keystore;
    public static Logger perf;
    public static Logger diagnostics;
    private static HashMap loggerTable;
    private static HashMap logLevelMap;
    
    public static synchronized void initializeLoggingSystem(final File logConfigFile) {
        if (Logging.logLevelMap != null) {
            return;
        }
        (Logging.logLevelMap = new HashMap()).put("OFF", Level.OFF);
        Logging.logLevelMap.put("FATAL", Level.FATAL);
        Logging.logLevelMap.put("WARN", Level.WARN);
        Logging.logLevelMap.put("ERROR", Level.ERROR);
        Logging.logLevelMap.put("INFO", Level.INFO);
        Logging.logLevelMap.put("DEBUG", Level.DEBUG);
        Logging.logLevelMap.put("ALL", Level.ALL);
        Logging.loggerTable = new HashMap();
        System.setProperty("log4j.configurationFile", logConfigFile.toString());
    }
    
    public static synchronized void initializeLoggers() {
        if (Logging.misc != null) {
            return;
        }
        Logging.root = newLogger("org.apache.manifoldcf.root");
        Logging.misc = newLogger("org.apache.manifoldcf.misc");
        Logging.db = newLogger("org.apache.manifoldcf.db");
        Logging.lock = newLogger("org.apache.manifoldcf.lock");
        Logging.cache = newLogger("org.apache.manifoldcf.cache");
        Logging.keystore = newLogger("org.apache.manifoldcf.keystore");
        Logging.perf = newLogger("org.apache.manifoldcf.perf");
        Logging.diagnostics = newLogger("org.apache.manifoldcf.diagnostics");
    }
    
    public static void setLogLevels(final IThreadContext threadContext) throws ManifoldCFException {
        for (final Map.Entry e : Logging.loggerTable.entrySet()) {
            final Logger logger = e.getValue();
            final String loggername = e.getKey();
            final String level = LockManagerFactory.getProperty(threadContext, loggername);
            Level loglevel = null;
            if (level != null && level.length() > 0) {
                loglevel = Logging.logLevelMap.get(level);
            }
            if (loglevel == null) {
                loglevel = Level.WARN;
            }
            try {
                logger.setLevel(loglevel);
            }
            catch (Exception ex) {
                System.err.println("Unable to set log level " + level + " on logger " + loggername);
                ex.printStackTrace();
            }
        }
    }
    
    public static final Logger getLogger(final String loggerName) {
        return Logging.loggerTable.get(loggerName);
    }
    
    public static final Logger newLogger(final String s) {
        final Logger l = Logger.getLogger(s);
        Logging.loggerTable.put(s, l);
        return l;
    }
    
    static {
        Logging.root = null;
        Logging.misc = null;
        Logging.db = null;
        Logging.lock = null;
        Logging.cache = null;
        Logging.keystore = null;
        Logging.perf = null;
        Logging.diagnostics = null;
        Logging.loggerTable = null;
        Logging.logLevelMap = null;
    }
}
