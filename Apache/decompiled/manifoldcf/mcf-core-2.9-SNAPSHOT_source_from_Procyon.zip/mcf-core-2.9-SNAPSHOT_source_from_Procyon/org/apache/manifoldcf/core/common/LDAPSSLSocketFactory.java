// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.common;

import java.net.InetAddress;
import java.io.IOException;
import java.net.Socket;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.ISSLSocketFactoryProducer;
import javax.net.ssl.SSLSocketFactory;

public class LDAPSSLSocketFactory extends SSLSocketFactory
{
    protected static final ThreadLocal<ISSLSocketFactoryProducer> sslSocketFactoryProducer;
    protected final SSLSocketFactory wrappedSocketFactory;
    
    public static void setSocketFactoryProducer(final ISSLSocketFactoryProducer p) {
        LDAPSSLSocketFactory.sslSocketFactoryProducer.set(p);
    }
    
    public LDAPSSLSocketFactory() throws ManifoldCFException {
        this.wrappedSocketFactory = LDAPSSLSocketFactory.sslSocketFactoryProducer.get().getSecureSocketFactory();
    }
    
    @Override
    public Socket createSocket(final Socket s, final String host, final int port, final boolean autoClose) throws IOException {
        return this.wrappedSocketFactory.createSocket(s, host, port, autoClose);
    }
    
    @Override
    public Socket createSocket(final InetAddress source, final int port, final InetAddress target, final int targetPort) throws IOException {
        return this.wrappedSocketFactory.createSocket(source, port, target, targetPort);
    }
    
    @Override
    public Socket createSocket(final String source, final int port, final InetAddress target, final int targetPort) throws IOException {
        return this.wrappedSocketFactory.createSocket(source, port, target, targetPort);
    }
    
    @Override
    public Socket createSocket(final InetAddress source, final int port) throws IOException {
        return this.wrappedSocketFactory.createSocket(source, port);
    }
    
    @Override
    public Socket createSocket(final String source, final int port) throws IOException {
        return this.wrappedSocketFactory.createSocket(source, port);
    }
    
    @Override
    public String[] getDefaultCipherSuites() {
        return this.wrappedSocketFactory.getDefaultCipherSuites();
    }
    
    @Override
    public String[] getSupportedCipherSuites() {
        return this.wrappedSocketFactory.getSupportedCipherSuites();
    }
    
    static {
        sslSocketFactoryProducer = new ThreadLocal<ISSLSocketFactoryProducer>();
    }
}
