// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.jdbcpool;

import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Map;

public class ConnectionPoolManager
{
    public static final String _rcsid = "@(#)$Id$";
    protected final Map<String, ConnectionPool> poolMap;
    protected final ConnectionCloserThread connectionCloserThread;
    protected volatile AtomicBoolean shuttingDown;
    protected final boolean debug;
    
    public ConnectionPoolManager(final int count, final boolean debug) throws ManifoldCFException {
        this.shuttingDown = new AtomicBoolean(false);
        this.debug = debug;
        this.poolMap = new HashMap<String, ConnectionPool>(count);
        (this.connectionCloserThread = new ConnectionCloserThread()).start();
    }
    
    public synchronized ConnectionPool getPool(final String poolKey) {
        return this.poolMap.get(poolKey);
    }
    
    public synchronized ConnectionPool addAlias(final String poolKey, final String driverClassName, final String dbURL, final String userName, final String password, final int maxSize, final long expiration) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName(driverClassName).newInstance();
        final ConnectionPool cp = new ConnectionPool(dbURL, userName, password, maxSize, expiration, this.debug);
        this.poolMap.put(poolKey, cp);
        return cp;
    }
    
    public void flush() {
        synchronized (this) {
            for (final String poolKey : this.poolMap.keySet()) {
                final ConnectionPool cp = this.poolMap.get(poolKey);
                cp.flushPool();
            }
        }
    }
    
    public void shutdown() {
        this.shuttingDown.set(true);
        while (this.connectionCloserThread.isAlive()) {
            try {
                Thread.sleep(1000L);
            }
            catch (InterruptedException e) {
                this.connectionCloserThread.interrupt();
            }
        }
        synchronized (this) {
            for (final String poolKey : this.poolMap.keySet()) {
                final ConnectionPool cp = this.poolMap.get(poolKey);
                cp.closePool();
            }
        }
    }
    
    protected void cleanupExpiredConnections(final long cleanupTime) {
        final ConnectionPool[] connectionPools;
        synchronized (this) {
            connectionPools = new ConnectionPool[this.poolMap.size()];
            int i = 0;
            for (final String poolKey : this.poolMap.keySet()) {
                connectionPools[i++] = this.poolMap.get(poolKey);
            }
        }
        for (int j = 0; j < connectionPools.length; ++j) {
            connectionPools[j].cleanupExpiredConnections(cleanupTime);
        }
    }
    
    protected class ConnectionCloserThread extends Thread
    {
        public ConnectionCloserThread() {
            this.setName("Connection pool reaper");
            this.setDaemon(true);
        }
        
        @Override
        public void run() {
            while (!ConnectionPoolManager.this.shuttingDown.get()) {
                ConnectionPoolManager.this.cleanupExpiredConnections(System.currentTimeMillis());
                if (!ConnectionPoolManager.this.shuttingDown.get()) {
                    try {
                        Thread.sleep(5000L);
                        continue;
                    }
                    catch (InterruptedException e) {}
                }
            }
        }
    }
}
