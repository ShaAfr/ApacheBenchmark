// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import org.apache.manifoldcf.core.system.ManifoldCF;

public class LockManagerFactory
{
    public static final String _rcsid = "@(#)$Id: LockManagerFactory.java 988245 2010-08-23 18:39:35Z kwright $";
    private static final String lockManager = "_LockManager_";
    
    private LockManagerFactory() {
    }
    
    public static ILockManager make(final IThreadContext context) throws ManifoldCFException {
        Object x = context.get("_LockManager_");
        if (x == null || !(x instanceof ILockManager)) {
            final String implementationClass = ManifoldCF.getStringProperty("org.apache.manifoldcf.lockmanagerclass", "org.apache.manifoldcf.core.lockmanager.LockManager");
            try {
                final Class c = Class.forName(implementationClass);
                x = c.newInstance();
                if (!(x instanceof ILockManager)) {
                    throw new ManifoldCFException("Lock manager class " + implementationClass + " does not implement ILockManager", 3);
                }
                context.save("_LockManager_", x);
            }
            catch (ClassNotFoundException e) {
                throw new ManifoldCFException("Lock manager class " + implementationClass + " could not be found: " + e.getMessage(), e, 3);
            }
            catch (ExceptionInInitializerError e2) {
                throw new ManifoldCFException("Lock manager class " + implementationClass + " could not be instantiated: " + e2.getMessage(), e2, 3);
            }
            catch (LinkageError e3) {
                throw new ManifoldCFException("Lock manager class " + implementationClass + " could not be linked: " + e3.getMessage(), e3, 3);
            }
            catch (InstantiationException e4) {
                throw new ManifoldCFException("Lock manager class " + implementationClass + " could not be instantiated: " + e4.getMessage(), e4, 3);
            }
            catch (IllegalAccessException e5) {
                throw new ManifoldCFException("Lock manager class " + implementationClass + " had no public default initializer: " + e5.getMessage(), e5, 3);
            }
        }
        return (ILockManager)x;
    }
    
    public static String getProperty(final IThreadContext tc, final String s) throws ManifoldCFException {
        return make(tc).getSharedConfiguration().getProperty(s);
    }
    
    public static String getStringProperty(final IThreadContext tc, final String s, final String defaultValue) throws ManifoldCFException {
        return make(tc).getSharedConfiguration().getStringProperty(s, defaultValue);
    }
    
    public static String getPossiblyObfuscatedStringProperty(final IThreadContext tc, final String s, final String defaultValue) throws ManifoldCFException {
        return make(tc).getSharedConfiguration().getPossiblyObfuscatedStringProperty(s, defaultValue);
    }
    
    public static int getIntProperty(final IThreadContext tc, final String s, final int defaultValue) throws ManifoldCFException {
        return make(tc).getSharedConfiguration().getIntProperty(s, defaultValue);
    }
    
    public static long getLongProperty(final IThreadContext tc, final String s, final long defaultValue) throws ManifoldCFException {
        return make(tc).getSharedConfiguration().getLongProperty(s, defaultValue);
    }
    
    public static double getDoubleProperty(final IThreadContext tc, final String s, final double defaultValue) throws ManifoldCFException {
        return make(tc).getSharedConfiguration().getDoubleProperty(s, defaultValue);
    }
    
    public static boolean getBooleanProperty(final IThreadContext tc, final String s, final boolean defaultValue) throws ManifoldCFException {
        return make(tc).getSharedConfiguration().getBooleanProperty(s, defaultValue);
    }
}
