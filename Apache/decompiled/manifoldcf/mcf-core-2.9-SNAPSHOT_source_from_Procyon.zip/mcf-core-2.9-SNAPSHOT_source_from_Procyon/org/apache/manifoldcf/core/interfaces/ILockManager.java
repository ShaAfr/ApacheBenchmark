// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface ILockManager
{
    public static final String _rcsid = "@(#)$Id: ILockManager.java 988245 2010-08-23 18:39:35Z kwright $";
    
    String registerServiceBeginServiceActivity(final String p0, final String p1, final IServiceCleanup p2) throws ManifoldCFException;
    
    String registerServiceBeginServiceActivity(final String p0, final String p1, final byte[] p2, final IServiceCleanup p3) throws ManifoldCFException;
    
    void updateServiceData(final String p0, final String p1, final byte[] p2) throws ManifoldCFException;
    
    byte[] retrieveServiceData(final String p0, final String p1) throws ManifoldCFException;
    
    void scanServiceData(final String p0, final IServiceDataAcceptor p1) throws ManifoldCFException;
    
    int countActiveServices(final String p0) throws ManifoldCFException;
    
    boolean cleanupInactiveService(final String p0, final IServiceCleanup p1) throws ManifoldCFException;
    
    void endServiceActivity(final String p0, final String p1) throws ManifoldCFException;
    
    boolean checkServiceActive(final String p0, final String p1) throws ManifoldCFException;
    
    ManifoldCFConfiguration getSharedConfiguration() throws ManifoldCFException;
    
    void setGlobalFlag(final String p0) throws ManifoldCFException;
    
    void clearGlobalFlag(final String p0) throws ManifoldCFException;
    
    boolean checkGlobalFlag(final String p0) throws ManifoldCFException;
    
    byte[] readData(final String p0) throws ManifoldCFException;
    
    void writeData(final String p0, final byte[] p1) throws ManifoldCFException;
    
    void timedWait(final int p0) throws ManifoldCFException;
    
    void enterWriteLock(final String p0) throws ManifoldCFException;
    
    void enterWriteLockNoWait(final String p0) throws ManifoldCFException, LockException;
    
    void leaveWriteLock(final String p0) throws ManifoldCFException;
    
    void enterNonExWriteLock(final String p0) throws ManifoldCFException;
    
    void enterNonExWriteLockNoWait(final String p0) throws ManifoldCFException, LockException;
    
    void leaveNonExWriteLock(final String p0) throws ManifoldCFException;
    
    void enterReadLock(final String p0) throws ManifoldCFException;
    
    void enterReadLockNoWait(final String p0) throws ManifoldCFException, LockException;
    
    void leaveReadLock(final String p0) throws ManifoldCFException;
    
    void enterLocks(final String[] p0, final String[] p1, final String[] p2) throws ManifoldCFException;
    
    void enterLocksNoWait(final String[] p0, final String[] p1, final String[] p2) throws ManifoldCFException, LockException;
    
    void leaveLocks(final String[] p0, final String[] p1, final String[] p2) throws ManifoldCFException;
    
    void clearLocks() throws ManifoldCFException;
    
    void enterReadCriticalSection(final String p0) throws ManifoldCFException;
    
    void leaveReadCriticalSection(final String p0) throws ManifoldCFException;
    
    void enterNonExWriteCriticalSection(final String p0) throws ManifoldCFException;
    
    void leaveNonExWriteCriticalSection(final String p0) throws ManifoldCFException;
    
    void enterWriteCriticalSection(final String p0) throws ManifoldCFException;
    
    void leaveWriteCriticalSection(final String p0) throws ManifoldCFException;
    
    void enterCriticalSections(final String[] p0, final String[] p1, final String[] p2) throws ManifoldCFException;
    
    void leaveCriticalSections(final String[] p0, final String[] p1, final String[] p2) throws ManifoldCFException;
}
