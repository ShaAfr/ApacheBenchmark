// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public class VersionContext
{
    public static final String _rcsid = "@(#)$Id$";
    protected final String versionString;
    protected final ConfigParams params;
    protected final Specification specification;
    
    public VersionContext(final String versionString, final ConfigParams params, final Specification specification) {
        this.versionString = versionString;
        this.params = params;
        this.specification = specification;
    }
    
    public String getVersionString() {
        return this.versionString;
    }
    
    public ConfigParams getParams() {
        return this.params;
    }
    
    public Specification getSpecification() {
        return this.specification;
    }
}
