// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.Reader;
import java.io.StringReader;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import org.apache.manifoldcf.core.common.XMLDoc;
import java.util.ArrayList;
import java.util.List;

public class Configuration implements IHierarchyParent
{
    public static final String _rcsid = "@(#)$Id: Configuration.java 988245 2010-08-23 18:39:35Z kwright $";
    protected static final String JSON_ATTRIBUTE = "_attribute_";
    protected static final String JSON_VALUE = "_value_";
    protected static final String JSON_CHILDREN = "_children_";
    protected static final String JSON_TYPE = "_type_";
    protected String rootNodeLabel;
    protected List<ConfigurationNode> children;
    protected boolean readOnly;
    
    public Configuration() {
        this.children = new ArrayList<ConfigurationNode>();
        this.readOnly = false;
        this.rootNodeLabel = "data";
    }
    
    public Configuration(final String rootNodeLabel) {
        this.children = new ArrayList<ConfigurationNode>();
        this.readOnly = false;
        this.rootNodeLabel = rootNodeLabel;
    }
    
    protected Configuration createNew() {
        return new Configuration();
    }
    
    protected ConfigurationNode createNewNode(final String type) {
        return new ConfigurationNode(type);
    }
    
    protected void clearOuterNodes() {
    }
    
    protected void addOuterNode(final ConfigurationNode node) {
    }
    
    protected void removeOuterNode(final ConfigurationNode node) {
    }
    
    protected Configuration createDuplicate(final boolean readOnly) {
        if (readOnly && this.readOnly) {
            return this;
        }
        final Configuration rval = this.createNew();
        rval.readOnly = readOnly;
        if (this.children != null) {
            int i = 0;
            while (i < this.children.size()) {
                final ConfigurationNode child = this.children.get(i++);
                final ConfigurationNode newChild = child.createDuplicate(readOnly);
                rval.addChild(rval.getChildCount(), newChild);
            }
        }
        return rval;
    }
    
    public void makeReadOnly() {
        if (this.readOnly) {
            return;
        }
        if (this.children != null) {
            int i = 0;
            while (i < this.children.size()) {
                final ConfigurationNode child = this.children.get(i++);
                child.makeReadOnly();
            }
        }
        this.readOnly = true;
    }
    
    public String toXML() throws ManifoldCFException {
        final XMLDoc doc = new XMLDoc();
        final Object top = doc.createElement(null, this.rootNodeLabel);
        int i = 0;
        while (i < this.children.size()) {
            final ConfigurationNode node = this.children.get(i++);
            writeNode(doc, top, node);
        }
        return doc.getXML();
    }
    
    public String toJSON() throws ManifoldCFException {
        final JSONWriter writer = new JSONWriter();
        writer.startObject();
        final Map<String, List<ConfigurationNode>> childMap = new HashMap<String, List<ConfigurationNode>>();
        final List<String> childList = new ArrayList<String>();
        String lastChildType = null;
        boolean needAlternate = false;
        int i = 0;
        while (i < this.getChildCount()) {
            final ConfigurationNode child = this.findChild(i++);
            final String key = child.getType();
            List<ConfigurationNode> list = childMap.get(key);
            if (list == null) {
                list = new ArrayList<ConfigurationNode>();
                childMap.put(key, list);
                childList.add(key);
            }
            else if (!lastChildType.equals(key)) {
                needAlternate = true;
                break;
            }
            list.add(child);
            lastChildType = key;
        }
        if (needAlternate) {
            writer.key("_children_");
            writer.startArray();
            i = 0;
            while (i < this.getChildCount()) {
                final ConfigurationNode child = this.findChild(i++);
                writeNode(writer, child, false, true);
            }
            writer.endArray();
        }
        else {
            int q = 0;
            while (q < childList.size()) {
                final String key = childList.get(q++);
                final List<ConfigurationNode> list = childMap.get(key);
                if (list.size() > 1) {
                    writer.key(key);
                    writer.startArray();
                    i = 0;
                    while (i < list.size()) {
                        final ConfigurationNode child2 = list.get(i++);
                        writeNode(writer, child2, false, false);
                    }
                    writer.endArray();
                }
                else {
                    writeNode(writer, list.get(0), true, false);
                }
            }
        }
        writer.endObject();
        return writer.toString();
    }
    
    protected static void writeNode(final XMLDoc doc, final Object parent, final ConfigurationNode node) throws ManifoldCFException {
        final String type = node.getType();
        final String value = node.getValue();
        final Object o = doc.createElement(parent, type);
        final Iterator iter = node.getAttributes();
        while (iter.hasNext()) {
            final String attribute = iter.next();
            final String attrValue = node.getAttributeValue(attribute);
            doc.setAttribute(o, attribute, attrValue);
        }
        if (value != null) {
            doc.createText(o, value);
        }
        int i = 0;
        while (i < node.getChildCount()) {
            final ConfigurationNode child = node.findChild(i++);
            writeNode(doc, o, child);
        }
    }
    
    protected static void writeNode(final JSONWriter writer, final ConfigurationNode node, final boolean writeKey, final boolean writeSpecialKey) throws ManifoldCFException {
        if (writeKey) {
            final String type = node.getType();
            writer.key(type);
        }
        else if (writeSpecialKey) {
            writer.startObject();
            writer.key("_type_");
            writer.value(node.getType());
        }
        final String value = node.getValue();
        if (value != null && node.getAttributeCount() == 0 && node.getChildCount() == 0) {
            writer.value(value);
        }
        else {
            if (!writeSpecialKey) {
                writer.startObject();
            }
            if (value != null) {
                writer.key("_value_");
                writer.value(value);
            }
            final Iterator<String> iter = node.getAttributes();
            while (iter.hasNext()) {
                final String attribute = iter.next();
                final String attrValue = node.getAttributeValue(attribute);
                writer.key("_attribute_" + attribute);
                writer.value(attrValue);
            }
            final Map<String, List<ConfigurationNode>> childMap = new HashMap<String, List<ConfigurationNode>>();
            final List<String> childList = new ArrayList<String>();
            String lastChildType = null;
            boolean needAlternate = false;
            int i = 0;
            while (i < node.getChildCount()) {
                final ConfigurationNode child = node.findChild(i++);
                final String key = child.getType();
                List<ConfigurationNode> list = childMap.get(key);
                if (list == null) {
                    list = new ArrayList<ConfigurationNode>();
                    childMap.put(key, list);
                    childList.add(key);
                }
                else if (!lastChildType.equals(key)) {
                    needAlternate = true;
                    break;
                }
                list.add(child);
                lastChildType = key;
            }
            if (needAlternate) {
                writer.key("_children_");
                writer.startArray();
                i = 0;
                while (i < node.getChildCount()) {
                    final ConfigurationNode child = node.findChild(i++);
                    writeNode(writer, child, false, true);
                }
                writer.endArray();
            }
            else {
                int q = 0;
                while (q < childList.size()) {
                    final String key = childList.get(q++);
                    final List<ConfigurationNode> list = childMap.get(key);
                    if (list.size() > 1) {
                        writer.key(key);
                        writer.startArray();
                        i = 0;
                        while (i < list.size()) {
                            final ConfigurationNode child2 = list.get(i++);
                            writeNode(writer, child2, false, false);
                        }
                        writer.endArray();
                    }
                    else {
                        writeNode(writer, list.get(0), true, false);
                    }
                }
            }
            if (!writeSpecialKey) {
                writer.endObject();
            }
        }
        if (writeSpecialKey) {
            writer.endObject();
        }
    }
    
    public void fromXML(final String xml) throws ManifoldCFException {
        final XMLDoc doc = new XMLDoc(xml);
        this.initializeFromDoc(doc);
    }
    
    public void fromJSON(final String json) throws ManifoldCFException {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        this.clearChildren();
        final JSONReader object = new JSONReader(json);
        object.startObject();
        final Iterator<String> iter = object.getKeys();
        while (iter.hasNext()) {
            final String key = iter.next();
            object.valueForKey(key);
            if (object.isArray()) {
                object.startArray();
                while (object.nextElement()) {
                    this.processObject(key, object);
                }
                object.endArray();
            }
            else {
                this.processObject(key, object);
            }
        }
        object.endObject();
    }
    
    protected void processObject(final String key, final JSONReader x) throws ManifoldCFException {
        if (x.isObject()) {
            final ConfigurationNode cn = this.readNode(key, x);
            this.addChild(this.getChildCount(), cn);
        }
        else if (!x.isNull()) {
            if (key.equals("_children_")) {
                if (!x.isArray()) {
                    throw new ManifoldCFException("Expected array contents for '_children_' node");
                }
                x.startArray();
                while (x.nextElement()) {
                    final ConfigurationNode nestedCn = this.readNode(null, x);
                    this.addChild(this.getChildCount(), nestedCn);
                }
                x.endArray();
            }
            else {
                final String value = x.readValue();
                final ConfigurationNode cn2 = this.createNewNode(key);
                cn2.setValue(value);
                this.addChild(this.getChildCount(), cn2);
            }
        }
    }
    
    protected ConfigurationNode readNode(String key, final JSONReader object) throws ManifoldCFException {
        object.startObject();
        if (object.valueForKey("_type_")) {
            if (!object.isValue()) {
                throw new ManifoldCFException("JSON_TYPE key does not have a string value");
            }
            key = object.readValue();
        }
        if (key == null) {
            throw new ManifoldCFException("No type found for node");
        }
        final ConfigurationNode rval = this.createNewNode(key);
        final Iterator<String> iter = object.getKeys();
        while (iter.hasNext()) {
            final String nestedKey = iter.next();
            if (!nestedKey.equals("_type_")) {
                object.valueForKey(nestedKey);
                if (object.isArray()) {
                    object.startArray();
                    while (object.nextElement()) {
                        this.processObject(rval, nestedKey, object);
                    }
                    object.endArray();
                }
                else {
                    this.processObject(rval, nestedKey, object);
                }
            }
        }
        object.endObject();
        return rval;
    }
    
    protected void processObject(final ConfigurationNode cn, final String key, final JSONReader x) throws ManifoldCFException {
        if (x.isObject()) {
            final ConfigurationNode nestedCn = this.readNode(key, x);
            cn.addChild(cn.getChildCount(), nestedCn);
        }
        else if (!x.isNull()) {
            final String value = x.readValue();
            if (key.startsWith("_attribute_")) {
                cn.setAttribute(key.substring("_attribute_".length()), value);
            }
            else if (key.equals("_value_")) {
                cn.setValue(value);
            }
            else if (key.equals("_children_")) {
                if (!x.isArray()) {
                    throw new ManifoldCFException("Expected array contents for '_children_' node");
                }
                x.startArray();
                while (x.nextElement()) {
                    final ConfigurationNode nestedCn2 = this.readNode(null, x);
                    cn.addChild(cn.getChildCount(), nestedCn2);
                }
                x.endArray();
            }
            else {
                final ConfigurationNode nestedCn2 = this.createNewNode(key);
                nestedCn2.setValue(value);
                cn.addChild(cn.getChildCount(), nestedCn2);
            }
        }
    }
    
    public void fromXML(final InputStream xmlstream) throws ManifoldCFException {
        final XMLDoc doc = new XMLDoc(xmlstream);
        this.initializeFromDoc(doc);
    }
    
    protected void initializeFromDoc(final XMLDoc doc) throws ManifoldCFException {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        this.clearChildren();
        final ArrayList list = new ArrayList();
        doc.processPath(list, "*", null);
        if (list.size() != 1) {
            throw new ManifoldCFException("Bad xml - missing outer '" + this.rootNodeLabel + "' node - there are " + Integer.toString(list.size()) + " nodes");
        }
        final Object parent = list.get(0);
        if (!doc.getNodeName(parent).equals(this.rootNodeLabel)) {
            throw new ManifoldCFException("Bad xml - outer node is not '" + this.rootNodeLabel + "'");
        }
        list.clear();
        doc.processPath(list, "*", parent);
        int i = 0;
        while (i < list.size()) {
            final Object o = list.get(i++);
            final ConfigurationNode node = this.readNode(doc, o);
            this.addChild(this.getChildCount(), node);
        }
    }
    
    protected ConfigurationNode readNode(final XMLDoc doc, final Object object) throws ManifoldCFException {
        final String type = doc.getNodeName(object);
        final ConfigurationNode rval = this.createNewNode(type);
        final String value = doc.getData(object);
        rval.setValue(value);
        final ArrayList list = doc.getAttributes(object);
        int i = 0;
        while (i < list.size()) {
            final String attribute = list.get(i++);
            final String attrValue = doc.getValue(object, attribute);
            rval.setAttribute(attribute, attrValue);
        }
        list.clear();
        doc.processPath(list, "*", object);
        i = 0;
        while (i < list.size()) {
            final Object o = list.get(i);
            final ConfigurationNode node = this.readNode(doc, o);
            rval.addChild(i++, node);
        }
        return rval;
    }
    
    @Override
    public int getChildCount() {
        return this.children.size();
    }
    
    @Override
    public ConfigurationNode findChild(final int index) {
        return this.children.get(index);
    }
    
    @Override
    public void removeChild(final int index) {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        final ConfigurationNode node = this.children.remove(index);
        this.removeOuterNode(node);
    }
    
    @Override
    public void addChild(final int index, final ConfigurationNode child) {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        this.children.add(index, child);
        this.addOuterNode(child);
    }
    
    @Override
    public void clearChildren() {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        this.children.clear();
        this.clearOuterNodes();
    }
    
    @Override
    public int hashCode() {
        int rval = 0;
        for (int i = 0; i < this.children.size(); rval += this.children.get(i++).hashCode()) {}
        return rval;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof Configuration)) {
            return false;
        }
        final Configuration p = (Configuration)o;
        if (this.children.size() != p.children.size()) {
            return false;
        }
        for (int i = 0; i < this.children.size(); ++i) {
            if (!this.children.get(i).equals(p.children.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("[");
        if (this.children != null) {
            int i = 0;
            while (i < this.children.size()) {
                if (i > 0) {
                    sb.append(", ");
                }
                final ConfigurationNode cn = this.children.get(i++);
                sb.append(cn.toString());
            }
        }
        sb.append("]");
        return sb.toString();
    }
    
    protected static class JSONWriter
    {
        private final List<JSONObject> objectStack;
        private final List<String> keyStack;
        private final List<JSONArray> arrayStack;
        private JSONObject currentObject;
        private JSONArray currentArray;
        private String currentKey;
        private JSONObject finalObject;
        private JSONArray finalArray;
        
        public JSONWriter() {
            this.objectStack = new ArrayList<JSONObject>();
            this.keyStack = new ArrayList<String>();
            this.arrayStack = new ArrayList<JSONArray>();
            this.currentObject = null;
            this.currentArray = null;
            this.currentKey = null;
            this.finalObject = null;
            this.finalArray = null;
        }
        
        public void startObject() {
            this.pushState();
            this.currentObject = new JSONObject();
            this.currentKey = null;
            this.currentArray = null;
        }
        
        public void key(final String key) {
            this.currentKey = key;
        }
        
        public void value(final String value) {
            if (this.currentKey != null) {
                this.currentObject.put((Object)this.currentKey, (Object)value);
            }
            else {
                if (this.currentArray == null) {
                    throw new RuntimeException("Naked value found with no context!");
                }
                this.currentArray.add((Object)value);
            }
        }
        
        public void endObject() {
            final JSONObject object = this.currentObject;
            this.popState();
            if (this.currentObject != null) {
                this.currentObject.put((Object)this.currentKey, (Object)object);
            }
            else if (this.currentArray != null) {
                this.currentArray.add((Object)object);
            }
            else {
                this.finalObject = object;
            }
        }
        
        public void startArray() {
            this.pushState();
            this.currentObject = null;
            this.currentKey = null;
            this.currentArray = new JSONArray();
        }
        
        public void endArray() {
            final JSONArray array = this.currentArray;
            this.popState();
            if (this.currentObject != null) {
                this.currentObject.put((Object)this.currentKey, (Object)array);
            }
            else if (this.currentArray != null) {
                this.currentArray.add((Object)array);
            }
            else {
                this.finalArray = array;
            }
        }
        
        @Override
        public String toString() {
            if (this.finalObject != null) {
                return this.finalObject.toJSONString();
            }
            if (this.finalArray != null) {
                return this.finalArray.toJSONString();
            }
            return "";
        }
        
        protected void pushState() {
            this.objectStack.add(this.currentObject);
            this.keyStack.add(this.currentKey);
            this.arrayStack.add(this.currentArray);
        }
        
        protected void popState() {
            this.currentObject = this.objectStack.remove(this.objectStack.size() - 1);
            this.currentKey = this.keyStack.remove(this.keyStack.size() - 1);
            this.currentArray = this.arrayStack.remove(this.arrayStack.size() - 1);
        }
    }
    
    protected static class JSONReader
    {
        private final List<JSONObject> objectStack;
        private final List<Iterator> arrayStack;
        private JSONObject currentObject;
        private Iterator currentArrayIterator;
        private Object next;
        
        public JSONReader(final String json) throws ManifoldCFException {
            this.objectStack = new ArrayList<JSONObject>();
            this.arrayStack = new ArrayList<Iterator>();
            this.currentObject = null;
            this.currentArrayIterator = null;
            this.next = null;
            final JSONParser parser = new JSONParser();
            try {
                this.next = parser.parse((Reader)new StringReader(json));
            }
            catch (Exception e) {
                throw new ManifoldCFException("Bad json: " + e.getMessage(), e);
            }
        }
        
        public boolean isObject() {
            return this.next != null && this.next instanceof JSONObject;
        }
        
        public void startObject() {
            this.pushState();
            this.currentObject = (JSONObject)this.next;
            this.currentArrayIterator = null;
        }
        
        public Iterator<String> getKeys() {
            return this.currentObject.keySet().iterator();
        }
        
        public boolean valueForKey(final String key) {
            this.next = this.currentObject.get((Object)key);
            return this.next != null;
        }
        
        public void endObject() {
            this.popState();
        }
        
        public boolean isArray() {
            return this.next != null && this.next instanceof JSONArray;
        }
        
        public void startArray() {
            this.pushState();
            this.currentObject = null;
            this.currentArrayIterator = ((JSONArray)this.next).iterator();
        }
        
        public boolean nextElement() {
            if (this.currentArrayIterator.hasNext()) {
                this.next = this.currentArrayIterator.next();
                return true;
            }
            return false;
        }
        
        public void endArray() {
            this.popState();
        }
        
        public boolean isNull() {
            return this.next == null;
        }
        
        public boolean isValue() {
            return this.next != null && !(this.next instanceof JSONObject) && !(this.next instanceof JSONArray);
        }
        
        public String readValue() {
            return this.next.toString();
        }
        
        protected void pushState() {
            this.objectStack.add(this.currentObject);
            this.arrayStack.add(this.currentArrayIterator);
        }
        
        protected void popState() {
            this.currentObject = this.objectStack.remove(this.objectStack.size() - 1);
            this.currentArrayIterator = this.arrayStack.remove(this.arrayStack.size() - 1);
        }
    }
}
