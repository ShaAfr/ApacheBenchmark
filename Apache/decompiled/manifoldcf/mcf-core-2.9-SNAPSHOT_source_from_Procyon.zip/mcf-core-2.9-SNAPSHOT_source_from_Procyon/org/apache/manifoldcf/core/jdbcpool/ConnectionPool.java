// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.jdbcpool;

import java.util.Iterator;
import java.sql.DriverManager;
import org.apache.manifoldcf.core.system.Logging;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import java.sql.Connection;

public class ConnectionPool
{
    public static final String _rcsid = "@(#)$Id$";
    protected final String dbURL;
    protected final String userName;
    protected final String password;
    protected volatile int freePointer;
    protected volatile int activeConnections;
    protected volatile boolean closed;
    protected final Connection[] freeConnections;
    protected final long[] connectionCleanupTimeouts;
    protected final long expiration;
    protected final boolean debug;
    protected final Set<WrappedConnection> outstandingConnections;
    
    public ConnectionPool(final String dbURL, final String userName, final String password, final int maxConnections, final long expiration, final boolean debug) {
        this.outstandingConnections = new HashSet<WrappedConnection>();
        this.dbURL = dbURL;
        this.userName = userName;
        this.password = password;
        this.freeConnections = new Connection[maxConnections];
        this.connectionCleanupTimeouts = new long[maxConnections];
        this.freePointer = 0;
        this.activeConnections = 0;
        this.closed = false;
        this.expiration = expiration;
        this.debug = debug;
    }
    
    public WrappedConnection getConnection() throws SQLException, InterruptedException {
        Exception instantiationException;
        if (this.debug) {
            instantiationException = new Exception("Possibly leaked db connection");
        }
        else {
            instantiationException = null;
        }
        Connection rval = null;
        boolean returnedValue = true;
        try {
            while (true) {
                synchronized (this) {
                    if (this.freePointer > 0) {
                        if (this.closed) {
                            throw new InterruptedException("Pool already closed");
                        }
                        final Connection[] freeConnections = this.freeConnections;
                        final int freePointer = this.freePointer - 1;
                        this.freePointer = freePointer;
                        rval = freeConnections[freePointer];
                        this.freeConnections[this.freePointer] = null;
                        boolean isValid = true;
                        try {
                            isValid = rval.isValid(1);
                        }
                        catch (SQLException ex) {}
                        catch (AbstractMethodError abstractMethodError) {}
                        if (!isValid) {
                            final Connection closeValue = rval;
                            rval = null;
                            --this.activeConnections;
                            try {
                                closeValue.close();
                            }
                            catch (SQLException ex2) {}
                            continue;
                        }
                    }
                    else {
                        if (this.activeConnections == this.freeConnections.length) {
                            if (this.debug) {
                                synchronized (this.outstandingConnections) {
                                    Logging.db.warn((Object)"Out of db connections, list of outstanding ones follows.");
                                    for (final WrappedConnection c : this.outstandingConnections) {
                                        Logging.db.warn((Object)"Found a possibly leaked db connection", (Throwable)c.getInstantiationException());
                                    }
                                }
                            }
                            this.wait();
                            continue;
                        }
                        ++this.activeConnections;
                        if (this.userName != null) {
                            rval = DriverManager.getConnection(this.dbURL, this.userName, this.password);
                        }
                        else {
                            rval = DriverManager.getConnection(this.dbURL);
                        }
                    }
                }
                break;
            }
            final WrappedConnection wc = new WrappedConnection(this, rval, instantiationException);
            if (this.debug) {
                synchronized (this.outstandingConnections) {
                    this.outstandingConnections.add(wc);
                }
            }
            return wc;
        }
        catch (Error e) {
            returnedValue = false;
            throw e;
        }
        catch (RuntimeException e2) {
            returnedValue = false;
            throw e2;
        }
        catch (SQLException e3) {
            returnedValue = false;
            throw e3;
        }
        finally {
            if (!returnedValue) {
                if (rval != null) {
                    this.release(rval);
                }
                else {
                    synchronized (this) {
                        --this.activeConnections;
                    }
                }
            }
        }
    }
    
    public synchronized void flushPool() {
        for (int i = 0; i < this.freePointer; ++i) {
            try {
                this.freeConnections[i].close();
            }
            catch (SQLException e) {
                Logging.db.warn((Object)("Error closing pooled connection: " + e.getMessage()), (Throwable)e);
            }
            this.freeConnections[i] = null;
            --this.activeConnections;
        }
        this.freePointer = 0;
        this.notifyAll();
    }
    
    public synchronized void closePool() {
        for (int i = 0; i < this.freePointer; ++i) {
            try {
                this.freeConnections[i].close();
            }
            catch (SQLException e) {
                Logging.db.warn((Object)("Error closing pooled connection: " + e.getMessage()), (Throwable)e);
            }
            this.freeConnections[i] = null;
        }
        this.freePointer = 0;
        this.closed = true;
        this.notifyAll();
    }
    
    public synchronized void cleanupExpiredConnections(final long currentTime) {
        int i = 0;
        while (i < this.freePointer) {
            if (this.connectionCleanupTimeouts[i] <= currentTime) {
                final Connection c = this.freeConnections[i];
                this.freeConnections[i] = null;
                --this.freePointer;
                --this.activeConnections;
                if (this.freePointer == i) {
                    this.freeConnections[i] = null;
                }
                else {
                    this.freeConnections[i] = this.freeConnections[this.freePointer];
                    this.connectionCleanupTimeouts[i] = this.connectionCleanupTimeouts[this.freePointer];
                    this.freeConnections[this.freePointer] = null;
                }
                try {
                    c.close();
                }
                catch (SQLException e) {
                    Logging.db.warn((Object)("Error closing pooled connection: " + e.getMessage()), (Throwable)e);
                }
            }
            else {
                ++i;
            }
        }
    }
    
    public void releaseConnection(final WrappedConnection connection) {
        if (this.debug) {
            synchronized (this.outstandingConnections) {
                if (!this.outstandingConnections.contains(connection)) {
                    Logging.db.warn((Object)"Released a connection that wasn't tracked!!");
                }
                this.outstandingConnections.remove(connection);
            }
        }
        this.release(connection.getConnection());
    }
    
    protected void release(final Connection c) {
        synchronized (this) {
            this.freeConnections[this.freePointer] = c;
            this.connectionCleanupTimeouts[this.freePointer] = System.currentTimeMillis() + this.expiration;
            ++this.freePointer;
            this.notifyAll();
        }
    }
}
