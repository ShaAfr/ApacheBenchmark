// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.util.HashMap;
import java.util.Map;

public class ZooKeeperEphemeralNodePool
{
    protected final ZooKeeperConnectionPool pool;
    protected final Map<String, ZooKeeperEphemeralNodeObject> nodes;
    
    public ZooKeeperEphemeralNodePool(final ZooKeeperConnectionPool pool) {
        this.nodes = new HashMap<String, ZooKeeperEphemeralNodeObject>();
        this.pool = pool;
    }
    
    public void createNode(final String nodePath, final byte[] nodeData) throws ManifoldCFException, InterruptedException {
        this.getObject(nodePath).createNode(nodeData);
    }
    
    public void setNodeData(final String nodePath, final byte[] nodeData) throws ManifoldCFException, InterruptedException {
        this.getObject(nodePath).setNodeData(nodeData);
    }
    
    public void deleteNode(final String nodePath) throws ManifoldCFException, InterruptedException {
        synchronized (this) {
            final ZooKeeperEphemeralNodeObject rval = this.nodes.get(nodePath);
            if (rval != null) {
                rval.deleteNode();
                this.nodes.remove(nodePath);
            }
        }
    }
    
    public void deleteAll() throws ManifoldCFException, InterruptedException {
        synchronized (this) {
            while (this.nodes.size() > 0) {
                final Iterator<String> nodePathIter = this.nodes.keySet().iterator();
                final String nodePath = nodePathIter.next();
                this.deleteNode(nodePath);
            }
        }
    }
    
    protected synchronized ZooKeeperEphemeralNodeObject getObject(final String nodePath) {
        ZooKeeperEphemeralNodeObject rval = this.nodes.get(nodePath);
        if (rval != null) {
            return rval;
        }
        rval = new ZooKeeperEphemeralNodeObject(nodePath, this.pool);
        this.nodes.put(nodePath, rval);
        return rval;
    }
}
