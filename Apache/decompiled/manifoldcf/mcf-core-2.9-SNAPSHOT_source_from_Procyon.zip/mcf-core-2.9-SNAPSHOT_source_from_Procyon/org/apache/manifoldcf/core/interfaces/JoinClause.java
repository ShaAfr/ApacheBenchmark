// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.List;

public class JoinClause implements ClauseDescription
{
    public static final String _rcsid = "@(#)$Id$";
    protected final String columnName;
    protected final String joinColumnName;
    protected final String operation;
    
    public JoinClause(final String columnName, final String joinColumnName) {
        this(columnName, joinColumnName, "=");
    }
    
    public JoinClause(final String columnName, final String joinColumnName, final String operation) {
        this.columnName = columnName;
        this.joinColumnName = joinColumnName;
        this.operation = operation;
    }
    
    @Override
    public String getColumnName() {
        return this.columnName;
    }
    
    @Override
    public String getOperation() {
        return this.operation;
    }
    
    @Override
    public List getValues() {
        return null;
    }
    
    @Override
    public String getJoinColumnName() {
        return this.joinColumnName;
    }
}
