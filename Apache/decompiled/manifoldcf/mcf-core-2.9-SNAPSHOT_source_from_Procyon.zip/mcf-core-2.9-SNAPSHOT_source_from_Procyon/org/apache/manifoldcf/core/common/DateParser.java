// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.common;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;
import java.util.HashMap;

public class DateParser
{
    public static final String _rcsid = "@(#)$Id$";
    protected static HashMap monthMap;
    protected static final HashMap milTzMap;
    
    public static Date parseISO8601Date(String isoDateValue) {
        if (isoDateValue == null) {
            return null;
        }
        final boolean isMicrosoft = isoDateValue.indexOf("T") == -1;
        String formatString;
        if (isMicrosoft) {
            formatString = "yyyy-MM-dd' 'HH:mm:ss";
        }
        else {
            final StringBuilder isoFormatString = new StringBuilder("yy");
            if (isoDateValue.length() > 2 && isoDateValue.charAt(2) != '-') {
                isoFormatString.append("yy");
            }
            isoFormatString.append("-MM-dd'T'HH:mm:ss");
            if (isoDateValue.indexOf(".") != -1) {
                isoFormatString.append(".SSS");
            }
            if (isoDateValue.endsWith("Z")) {
                isoDateValue = isoDateValue.substring(0, isoDateValue.length() - 1) + "-0000";
                isoFormatString.append("Z");
            }
            else {
                final int colonIndex = isoDateValue.lastIndexOf(":");
                final int dashIndex = isoDateValue.lastIndexOf("-");
                final int plusIndex = isoDateValue.lastIndexOf("+");
                if (colonIndex != -1 && ((dashIndex != -1 && colonIndex == dashIndex + 3 && isNumeral(isoDateValue, dashIndex - 1)) || (plusIndex != -1 && colonIndex == plusIndex + 3 && isNumeral(isoDateValue, plusIndex - 1)))) {
                    isoDateValue = isoDateValue.substring(0, colonIndex) + isoDateValue.substring(colonIndex + 1);
                }
                isoFormatString.append("Z");
            }
            formatString = isoFormatString.toString();
        }
        final DateFormat iso8601Format = new SimpleDateFormat(formatString, Locale.ROOT);
        try {
            return iso8601Format.parse(isoDateValue);
        }
        catch (ParseException e) {
            return null;
        }
    }
    
    protected static boolean isNumeral(final String value, final int index) {
        return index >= 0 && value.charAt(index) >= '0' && value.charAt(index) <= '9';
    }
    
    public static String formatISO8601Date(final Date dateValue) {
        final DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ROOT);
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        return df.format(dateValue);
    }
    
    public static Date parseRFC822Date(String dateValue) {
        if (dateValue == null) {
            return null;
        }
        dateValue = dateValue.trim();
        final int commaIndex = dateValue.indexOf(",");
        String usable;
        if (commaIndex == -1) {
            usable = dateValue;
        }
        else {
            usable = dateValue.substring(commaIndex + 1).trim();
        }
        int index = usable.indexOf(" ");
        if (index == -1) {
            return null;
        }
        final String day = usable.substring(0, index);
        usable = usable.substring(index + 1).trim();
        index = usable.indexOf(" ");
        if (index == -1) {
            return null;
        }
        final String month = usable.substring(0, index).toLowerCase(Locale.ROOT);
        usable = usable.substring(index + 1).trim();
        String hour = null;
        String minute = null;
        String second = null;
        String timezone = null;
        index = usable.indexOf(" ");
        String year;
        if (index != -1) {
            year = usable.substring(0, index);
            usable = usable.substring(index + 1).trim();
            index = usable.indexOf(":");
            if (index == -1) {
                return null;
            }
            hour = usable.substring(0, index);
            usable = usable.substring(index + 1).trim();
            index = usable.indexOf(":");
            if (index != -1) {
                minute = usable.substring(0, index);
                usable = usable.substring(index + 1).trim();
                index = usable.indexOf(" ");
                if (index == -1) {
                    second = usable;
                }
                else {
                    second = usable.substring(0, index);
                    timezone = usable.substring(index + 1).trim();
                }
            }
            else {
                index = usable.indexOf(" ");
                if (index == -1) {
                    minute = usable;
                }
                else {
                    minute = usable.substring(0, index);
                    timezone = usable.substring(index + 1).trim();
                }
            }
        }
        else {
            year = usable;
        }
        if (timezone != null && timezone.length() > 0) {
            if (timezone.startsWith("+") || timezone.startsWith("-")) {
                if (timezone.indexOf(":") == -1 && timezone.length() > 3) {
                    timezone = timezone.substring(0, timezone.length() - 2) + ":" + timezone.substring(timezone.length() - 2);
                }
                timezone = "GMT" + timezone;
            }
            else if (DateParser.milTzMap.get(timezone) != null) {
                timezone = DateParser.milTzMap.get(timezone);
            }
        }
        else {
            timezone = "GMT";
        }
        final TimeZone tz = TimeZone.getTimeZone(timezone);
        final Calendar c = new GregorianCalendar(tz, Locale.ROOT);
        try {
            int value = Integer.parseInt(year);
            if (value < 1900) {
                value += 1900;
            }
            c.set(1, value);
            final Integer x = DateParser.monthMap.get(month);
            if (x == null) {
                return null;
            }
            c.set(2, x - 1);
            value = Integer.parseInt(day);
            c.set(5, value);
            if (hour != null) {
                value = Integer.parseInt(hour);
            }
            else {
                value = 0;
            }
            c.set(11, value);
            if (minute != null) {
                value = Integer.parseInt(minute);
            }
            else {
                value = 0;
            }
            c.set(12, value);
            if (second != null) {
                value = Integer.parseInt(second);
            }
            else {
                value = 0;
            }
            c.set(13, value);
            c.set(14, 0);
            return new Date(c.getTimeInMillis());
        }
        catch (NumberFormatException e) {
            return null;
        }
    }
    
    public static Date parseChinaDate(String dateValue) {
        if (dateValue == null) {
            return null;
        }
        dateValue = dateValue.trim();
        int index = dateValue.indexOf("/");
        if (index == -1) {
            return null;
        }
        final String year = dateValue.substring(0, index);
        dateValue = dateValue.substring(index + 1);
        index = dateValue.indexOf("/");
        if (index == -1) {
            return null;
        }
        final String month = dateValue.substring(0, index);
        dateValue = dateValue.substring(index + 1);
        index = dateValue.indexOf(" ");
        String hour = null;
        String minute = null;
        String second = null;
        String day;
        if (index == -1) {
            day = dateValue;
        }
        else {
            day = dateValue.substring(0, index);
            dateValue = dateValue.substring(index + 1);
            index = dateValue.indexOf(":");
            if (index == -1) {
                return null;
            }
            hour = dateValue.substring(0, index);
            dateValue = dateValue.substring(index + 1);
            index = dateValue.indexOf(":");
            if (index != -1) {
                minute = dateValue.substring(0, index);
                dateValue = (second = dateValue.substring(index + 1));
            }
            else {
                minute = dateValue;
            }
        }
        final TimeZone tz = TimeZone.getTimeZone("GMT");
        final Calendar c = new GregorianCalendar(tz, Locale.ROOT);
        try {
            int value = Integer.parseInt(year);
            if (value < 1900) {
                value += 1900;
            }
            c.set(1, value);
            value = Integer.parseInt(month);
            c.set(2, value - 1);
            value = Integer.parseInt(day);
            c.set(5, value);
            if (hour != null) {
                value = Integer.parseInt(hour);
            }
            else {
                value = 0;
            }
            c.set(11, value);
            if (minute != null) {
                value = Integer.parseInt(minute);
            }
            else {
                value = 0;
            }
            c.set(12, value);
            if (second != null) {
                value = Integer.parseInt(second);
            }
            else {
                value = 0;
            }
            c.set(13, value);
            c.set(14, 0);
            return new Date(c.getTimeInMillis());
        }
        catch (NumberFormatException e) {
            return null;
        }
    }
    
    static {
        (DateParser.monthMap = new HashMap()).put("jan", new Integer(1));
        DateParser.monthMap.put("feb", new Integer(2));
        DateParser.monthMap.put("mar", new Integer(3));
        DateParser.monthMap.put("apr", new Integer(4));
        DateParser.monthMap.put("may", new Integer(5));
        DateParser.monthMap.put("jun", new Integer(6));
        DateParser.monthMap.put("jul", new Integer(7));
        DateParser.monthMap.put("aug", new Integer(8));
        DateParser.monthMap.put("sep", new Integer(9));
        DateParser.monthMap.put("oct", new Integer(10));
        DateParser.monthMap.put("nov", new Integer(11));
        DateParser.monthMap.put("dec", new Integer(12));
        (milTzMap = new HashMap()).put("Z", "GMT");
        DateParser.milTzMap.put("UT", "GMT");
        DateParser.milTzMap.put("A", "GMT-01:00");
        DateParser.milTzMap.put("M", "GMT-12:00");
        DateParser.milTzMap.put("N", "GMT+01:00");
        DateParser.milTzMap.put("Y", "GMT+12:00");
    }
}
