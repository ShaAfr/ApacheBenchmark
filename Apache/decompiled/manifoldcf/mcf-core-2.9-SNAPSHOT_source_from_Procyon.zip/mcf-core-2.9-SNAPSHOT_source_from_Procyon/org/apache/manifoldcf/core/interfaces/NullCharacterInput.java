// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.apache.manifoldcf.core.system.ManifoldCF;
import java.io.StringReader;
import java.io.Reader;

public class NullCharacterInput extends CharacterInput
{
    public static final String _rcsid = "@(#)$Id$";
    
    @Override
    public Reader getStream() throws ManifoldCFException {
        return new StringReader("");
    }
    
    @Override
    public void doneWithStream() throws ManifoldCFException {
    }
    
    @Override
    public long getCharacterLength() throws ManifoldCFException {
        return 0L;
    }
    
    @Override
    public String getHashValue() throws ManifoldCFException {
        return ManifoldCF.getHashValue(ManifoldCF.startHash());
    }
    
    @Override
    public InputStream getUtf8Stream() throws ManifoldCFException {
        return new ByteArrayInputStream(new byte[0]);
    }
    
    @Override
    public long getUtf8StreamLength() throws ManifoldCFException {
        return 0L;
    }
    
    @Override
    public CharacterInput transfer() {
        return new NullCharacterInput();
    }
    
    @Override
    public void discard() throws ManifoldCFException {
    }
    
    @Override
    protected void openStream() throws ManifoldCFException {
    }
    
    @Override
    protected void closeStream() throws ManifoldCFException {
    }
    
    @Override
    protected void calculateLength() throws ManifoldCFException {
    }
    
    @Override
    protected void calculateHashValue() throws ManifoldCFException {
    }
}
