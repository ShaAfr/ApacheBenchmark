// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import javax.net.ssl.SSLSocketFactory;

public interface ISSLSocketFactoryProducer
{
    public static final String _rcsid = "@(#)$Id$";
    
    SSLSocketFactory getSecureSocketFactory() throws ManifoldCFException;
}
