// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public interface IConnector
{
    void install(final IThreadContext p0) throws ManifoldCFException;
    
    void deinstall(final IThreadContext p0) throws ManifoldCFException;
    
    void connect(final ConfigParams p0);
    
    String check() throws ManifoldCFException;
    
    void poll() throws ManifoldCFException;
    
    boolean isConnected();
    
    void disconnect() throws ManifoldCFException;
    
    ConfigParams getConfiguration();
    
    void clearThreadContext();
    
    void setThreadContext(final IThreadContext p0) throws ManifoldCFException;
    
    void outputConfigurationHeader(final IThreadContext p0, final IHTTPOutput p1, final Locale p2, final ConfigParams p3, final List<String> p4) throws ManifoldCFException, IOException;
    
    void outputConfigurationBody(final IThreadContext p0, final IHTTPOutput p1, final Locale p2, final ConfigParams p3, final String p4) throws ManifoldCFException, IOException;
    
    String processConfigurationPost(final IThreadContext p0, final IPostParameters p1, final Locale p2, final ConfigParams p3) throws ManifoldCFException;
    
    void viewConfiguration(final IThreadContext p0, final IHTTPOutput p1, final Locale p2, final ConfigParams p3) throws ManifoldCFException, IOException;
}
