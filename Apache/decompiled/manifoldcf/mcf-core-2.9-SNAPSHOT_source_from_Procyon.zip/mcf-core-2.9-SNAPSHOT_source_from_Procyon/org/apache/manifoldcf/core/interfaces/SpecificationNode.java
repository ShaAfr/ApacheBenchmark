// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public class SpecificationNode extends ConfigurationNode
{
    public static final String _rcsid = "@(#)$Id: SpecificationNode.java 988245 2010-08-23 18:39:35Z kwright $";
    
    public SpecificationNode(final String type) {
        super(type);
    }
    
    public SpecificationNode(final ConfigurationNode source) {
        super(source);
    }
    
    @Override
    protected ConfigurationNode createNewNode() {
        return new SpecificationNode(this.type);
    }
    
    @Override
    protected ConfigurationNode createNewNode(final ConfigurationNode source) {
        return new SpecificationNode(source);
    }
    
    public SpecificationNode duplicate(final boolean readOnly) {
        return (SpecificationNode)this.createDuplicate(readOnly);
    }
    
    public SpecificationNode getChild(final int index) {
        return (SpecificationNode)this.findChild(index);
    }
}
