// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.util.Set;
import java.util.HashMap;
import java.util.Map;

public class LocalLockPool
{
    public static final String _rcsid = "@(#)$Id$";
    protected final Map<String, LocalLock> localLocks;
    
    public LocalLockPool() {
        this.localLocks = new HashMap<String, LocalLock>();
    }
    
    public LocalLock getLocalLock(final String lockKey) {
        LocalLock ll = this.localLocks.get(lockKey);
        if (ll == null) {
            ll = new LocalLock();
            this.localLocks.put(lockKey, ll);
        }
        return ll;
    }
    
    public void releaseLocalLock(final String lockKey) {
        this.localLocks.remove(lockKey);
    }
    
    public Set<String> keySet() {
        return this.localLocks.keySet();
    }
}
