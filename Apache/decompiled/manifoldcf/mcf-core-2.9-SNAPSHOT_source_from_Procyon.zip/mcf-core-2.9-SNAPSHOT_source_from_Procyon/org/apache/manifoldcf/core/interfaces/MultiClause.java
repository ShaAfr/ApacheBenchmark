// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.ArrayList;
import java.util.List;

public class MultiClause implements ClauseDescription
{
    public static final String _rcsid = "@(#)$Id$";
    protected String columnName;
    protected List values;
    
    public MultiClause(final String columnName, final List values) {
        this.columnName = columnName;
        this.values = values;
    }
    
    public MultiClause(final String columnName, final Object[] values) {
        this.columnName = columnName;
        this.values = new ArrayList();
        for (int i = 0; i < values.length; ++i) {
            this.values.add(values[i]);
        }
    }
    
    @Override
    public String getColumnName() {
        return this.columnName;
    }
    
    @Override
    public String getOperation() {
        return "=";
    }
    
    @Override
    public List getValues() {
        return this.values;
    }
    
    @Override
    public String getJoinColumnName() {
        return null;
    }
}
