// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import java.util.HashMap;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.IResultRow;
import org.apache.manifoldcf.core.interfaces.ClauseDescription;
import org.apache.manifoldcf.core.interfaces.CacheKeyFactory;
import org.apache.manifoldcf.core.interfaces.ILimitChecker;
import org.apache.manifoldcf.core.interfaces.IResultSet;
import org.apache.manifoldcf.core.interfaces.IndexDescription;
import org.apache.manifoldcf.core.interfaces.ColumnDescription;
import java.util.List;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.StringSet;
import java.util.Map;
import org.apache.manifoldcf.core.interfaces.IDBInterface;

public class BaseTable
{
    public static final String _rcsid = "@(#)$Id: BaseTable.java 999670 2010-09-21 22:18:19Z kwright $";
    protected IDBInterface dbInterface;
    protected String tableName;
    
    public BaseTable(final IDBInterface dbInterface, final String tableName) {
        this.dbInterface = dbInterface;
        this.tableName = tableName;
    }
    
    protected IDBInterface getDBInterface() {
        return this.dbInterface;
    }
    
    public String getTableName() {
        return this.tableName;
    }
    
    public String getDatabaseCacheKey() {
        return this.dbInterface.getDatabaseCacheKey();
    }
    
    public String getTransactionID() {
        return this.dbInterface.getTransactionID();
    }
    
    protected void performInsert(final Map parameterMap, final StringSet invalidateKeys) throws ManifoldCFException {
        this.dbInterface.performInsert(this.tableName, parameterMap, invalidateKeys);
    }
    
    protected void performUpdate(final Map parameterMap, final String whereClause, final List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        this.dbInterface.performUpdate(this.tableName, parameterMap, whereClause, whereParameters, invalidateKeys);
    }
    
    protected void performDelete(final String whereClause, final List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        this.dbInterface.performDelete(this.tableName, whereClause, whereParameters, invalidateKeys);
    }
    
    protected void performCreate(final Map columnMap, final StringSet invalidateKeys) throws ManifoldCFException {
        this.dbInterface.performCreate(this.tableName, columnMap, invalidateKeys);
    }
    
    public void performAlter(final Map columnMap, final Map columnModifyMap, final List<String> columnDeleteList, final StringSet invalidateKeys) throws ManifoldCFException {
        this.dbInterface.performAlter(this.tableName, columnMap, columnModifyMap, columnDeleteList, invalidateKeys);
    }
    
    protected void addTableIndex(final boolean unique, final List<String> columnList) throws ManifoldCFException {
        this.dbInterface.addTableIndex(this.tableName, unique, columnList);
    }
    
    protected void performAddIndex(final String indexName, final IndexDescription description) throws ManifoldCFException {
        this.dbInterface.performAddIndex(indexName, this.tableName, description);
    }
    
    public void performRemoveIndex(final String indexName) throws ManifoldCFException {
        this.dbInterface.performRemoveIndex(indexName, this.tableName);
    }
    
    protected void analyzeTable() throws ManifoldCFException {
        this.dbInterface.analyzeTable(this.tableName);
    }
    
    protected void reindexTable() throws ManifoldCFException {
        this.dbInterface.reindexTable(this.tableName);
    }
    
    protected void performDrop(final StringSet invalidateKeys) throws ManifoldCFException {
        this.dbInterface.performDrop(this.tableName, invalidateKeys);
    }
    
    protected Map getTableSchema(final StringSet invalidateKeys, final String queryClass) throws ManifoldCFException {
        return this.dbInterface.getTableSchema(this.tableName, invalidateKeys, queryClass);
    }
    
    protected Map getTableIndexes(final StringSet invalidateKeys, final String queryClass) throws ManifoldCFException {
        return this.dbInterface.getTableIndexes(this.tableName, invalidateKeys, queryClass);
    }
    
    protected void performModification(final String query, final List params, final StringSet invalidateKeys) throws ManifoldCFException {
        this.dbInterface.performModification(query, params, invalidateKeys);
    }
    
    protected IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        return this.dbInterface.performQuery(query, params, cacheKeys, queryClass);
    }
    
    protected IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass, final int resultLimit) throws ManifoldCFException {
        return this.dbInterface.performQuery(query, params, cacheKeys, queryClass, resultLimit, null);
    }
    
    protected void beginTransaction() throws ManifoldCFException {
        this.dbInterface.beginTransaction();
    }
    
    public void performCommit() throws ManifoldCFException {
        this.dbInterface.performCommit();
    }
    
    protected void signalRollback() {
        this.dbInterface.signalRollback();
    }
    
    protected void endTransaction() throws ManifoldCFException {
        this.dbInterface.endTransaction();
    }
    
    protected long getSleepAmt() {
        return this.dbInterface.getSleepAmt();
    }
    
    protected void sleepFor(final long amt) throws ManifoldCFException {
        this.dbInterface.sleepFor(amt);
    }
    
    public void noteModifications(final int insertCount, final int modifyCount, final int deleteCount) throws ManifoldCFException {
        this.dbInterface.noteModifications(this.tableName, insertCount, modifyCount, deleteCount);
    }
    
    public String makeTableKey() {
        return CacheKeyFactory.makeTableKey(null, this.tableName, this.dbInterface.getDatabaseName());
    }
    
    public String constructDoubleCastClause(final String value) {
        return this.dbInterface.constructDoubleCastClause(value);
    }
    
    public String constructCountClause(final String column) {
        return this.dbInterface.constructCountClause(column);
    }
    
    public String constructRegexpClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        return this.dbInterface.constructRegexpClause(column, regularExpression, caseInsensitive);
    }
    
    public String constructSubstringClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        return this.dbInterface.constructSubstringClause(column, regularExpression, caseInsensitive);
    }
    
    public String constructOffsetLimitClause(final int offset, final int limit) {
        return this.dbInterface.constructOffsetLimitClause(offset, limit);
    }
    
    public String constructDistinctOnClause(final List outputParameters, final String baseQuery, final List baseParameters, final String[] distinctFields, final String[] orderFields, final boolean[] orderFieldsAscending, final Map<String, String> otherFields) {
        return this.dbInterface.constructDistinctOnClause(outputParameters, baseQuery, baseParameters, distinctFields, orderFields, orderFieldsAscending, otherFields);
    }
    
    public int findConjunctionClauseMax(final ClauseDescription[] otherClauseDescriptions) {
        return this.dbInterface.findConjunctionClauseMax(otherClauseDescriptions);
    }
    
    public String buildConjunctionClause(final List outputParameters, final ClauseDescription[] clauseDescriptions) {
        return this.dbInterface.buildConjunctionClause(outputParameters, clauseDescriptions);
    }
    
    protected int getMaxInClause() {
        return this.dbInterface.getMaxInClause();
    }
    
    protected int getMaxOrClause() {
        return this.dbInterface.getMaxOrClause();
    }
    
    public int getWindowedReportMaxRows() {
        return this.dbInterface.getWindowedReportMaxRows();
    }
    
    public static void readRow(final BaseObject object, final IResultRow resultRow) {
        final Iterator iter = resultRow.getColumns();
        while (iter.hasNext()) {
            final String columnName = iter.next();
            final Object columnValue = resultRow.getValue(columnName);
            object.setValue(columnName, columnValue);
        }
    }
    
    public static Map prepareRowForSave(final BaseObject object, final StringSet fieldSet) {
        final HashMap rval = new HashMap();
        final Iterator keys = fieldSet.getKeys();
        while (keys.hasNext()) {
            final String keyName = keys.next();
            final Object x = object.getValue(keyName);
            if (x != null) {
                rval.put(keyName, x);
            }
        }
        return rval;
    }
}
