// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class DBInterfaceFactory
{
    public static final String _rcsid = "@(#)$Id: DBInterfaceFactory.java 988245 2010-08-23 18:39:35Z kwright $";
    private static final String dbinterfaceInstancePrefix = "_DBInterface:";
    
    private DBInterfaceFactory() {
    }
    
    public static IDBInterface make(final IThreadContext context, final String databaseName, final String userName, final String password) throws ManifoldCFException {
        final String dbName = "_DBInterface:" + databaseName;
        Object x = context.get(dbName);
        if (x == null || !(x instanceof IDBInterface)) {
            final String implementationClass = LockManagerFactory.getStringProperty(context, "org.apache.manifoldcf.databaseimplementationclass", "org.apache.manifoldcf.core.database.DBInterfacePostgreSQL");
            try {
                final Class c = Class.forName(implementationClass);
                final Constructor constructor = c.getConstructor(IThreadContext.class, String.class, String.class, String.class);
                x = constructor.newInstance(context, databaseName, userName, password);
                if (!(x instanceof IDBInterface)) {
                    throw new ManifoldCFException("Database implementation class " + implementationClass + " does not implement IDBInterface", 3);
                }
                context.save(dbName, x);
            }
            catch (ClassNotFoundException e) {
                throw new ManifoldCFException("Database implementation class " + implementationClass + " could not be found: " + e.getMessage(), e, 3);
            }
            catch (ExceptionInInitializerError e2) {
                throw new ManifoldCFException("Database implementation class " + implementationClass + " could not be instantiated: " + e2.getMessage(), e2, 3);
            }
            catch (LinkageError e3) {
                throw new ManifoldCFException("Database implementation class " + implementationClass + " could not be linked: " + e3.getMessage(), e3, 3);
            }
            catch (InstantiationException e4) {
                throw new ManifoldCFException("Database implementation class " + implementationClass + " could not be instantiated: " + e4.getMessage(), e4, 3);
            }
            catch (InvocationTargetException e5) {
                throw new ManifoldCFException("Database implementation class " + implementationClass + " could not be instantiated: " + e5.getMessage(), e5, 3);
            }
            catch (NoSuchMethodException e6) {
                throw new ManifoldCFException("Database implementation class " + implementationClass + " had no constructor taking (IThreadContext, String, String, String): " + e6.getMessage(), e6, 3);
            }
            catch (IllegalAccessException e7) {
                throw new ManifoldCFException("Database implementation class " + implementationClass + " had no public constructor taking (IThreadContext, String, String, String): " + e7.getMessage(), e7, 3);
            }
        }
        return (IDBInterface)x;
    }
}
