// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import org.apache.manifoldcf.core.interfaces.IResultRow;

public class RRow implements IResultRow
{
    public static final String _rcsid = "@(#)$Id: RRow.java 988245 2010-08-23 18:39:35Z kwright $";
    protected Map<String, Object> rowData;
    
    public RRow() {
        this.rowData = new HashMap<String, Object>();
    }
    
    public void put(final String name, final Object value) {
        this.rowData.put(name, value);
    }
    
    @Override
    public int getColumnCount() {
        return this.rowData.size();
    }
    
    @Override
    public Iterator<String> getColumns() {
        return this.rowData.keySet().iterator();
    }
    
    @Override
    public Object getValue(final String columnName) {
        return this.rowData.get(columnName);
    }
}
