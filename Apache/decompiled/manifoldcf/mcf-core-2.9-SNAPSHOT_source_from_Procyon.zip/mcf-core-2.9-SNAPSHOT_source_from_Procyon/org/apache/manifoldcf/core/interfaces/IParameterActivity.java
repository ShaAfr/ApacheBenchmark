// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IParameterActivity
{
    public static final String _rcsid = "@(#)$Id$";
    
    String[] getParameterValues(final String p0);
    
    String getParameter(final String p0);
    
    BinaryInput getBinaryStream(final String p0) throws ManifoldCFException;
    
    byte[] getBinaryBytes(final String p0);
    
    void setParameter(final String p0, final String p1);
    
    void setParameterValues(final String p0, final String[] p1);
}
