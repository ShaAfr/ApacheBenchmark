// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.List;
import java.util.Map;

public interface IDBInterface
{
    public static final String _rcsid = "@(#)$Id: IDBInterface.java 999670 2010-09-21 22:18:19Z kwright $";
    public static final int TRANSACTION_ENCLOSING = 0;
    public static final int TRANSACTION_READCOMMITTED = 1;
    public static final int TRANSACTION_SERIALIZED = 2;
    public static final int TRANSACTION_REPEATABLEREAD = 3;
    
    void openDatabase() throws ManifoldCFException;
    
    void closeDatabase() throws ManifoldCFException;
    
    String getDatabaseName();
    
    String getTransactionID();
    
    String getDatabaseCacheKey();
    
    void performInsert(final String p0, final Map<String, Object> p1, final StringSet p2) throws ManifoldCFException;
    
    void performUpdate(final String p0, final Map<String, Object> p1, final String p2, final List p3, final StringSet p4) throws ManifoldCFException;
    
    void performDelete(final String p0, final String p1, final List p2, final StringSet p3) throws ManifoldCFException;
    
    void performCreate(final String p0, final Map<String, ColumnDescription> p1, final StringSet p2) throws ManifoldCFException;
    
    void performAlter(final String p0, final Map<String, ColumnDescription> p1, final Map<String, ColumnDescription> p2, final List<String> p3, final StringSet p4) throws ManifoldCFException;
    
    void addTableIndex(final String p0, final boolean p1, final List<String> p2) throws ManifoldCFException;
    
    void performAddIndex(final String p0, final String p1, final IndexDescription p2) throws ManifoldCFException;
    
    void performRemoveIndex(final String p0, final String p1) throws ManifoldCFException;
    
    void analyzeTable(final String p0) throws ManifoldCFException;
    
    void reindexTable(final String p0) throws ManifoldCFException;
    
    void performDrop(final String p0, final StringSet p1) throws ManifoldCFException;
    
    void createUserAndDatabase(final String p0, final String p1, final StringSet p2) throws ManifoldCFException;
    
    void dropUserAndDatabase(final String p0, final String p1, final StringSet p2) throws ManifoldCFException;
    
    Map<String, ColumnDescription> getTableSchema(final String p0, final StringSet p1, final String p2) throws ManifoldCFException;
    
    Map<String, IndexDescription> getTableIndexes(final String p0, final StringSet p1, final String p2) throws ManifoldCFException;
    
    StringSet getAllTables(final StringSet p0, final String p1) throws ManifoldCFException;
    
    void performModification(final String p0, final List p1, final StringSet p2) throws ManifoldCFException;
    
    IResultSet performQuery(final String p0, final List p1, final StringSet p2, final String p3) throws ManifoldCFException;
    
    IResultSet performQuery(final String p0, final List p1, final StringSet p2, final String p3, final int p4, final ILimitChecker p5) throws ManifoldCFException;
    
    IResultSet performQuery(final String p0, final List p1, final StringSet p2, final String p3, final int p4, final ResultSpecification p5, final ILimitChecker p6) throws ManifoldCFException;
    
    String constructIndexHintClause(final String p0, final IndexDescription p1) throws ManifoldCFException;
    
    String constructIndexOrderByClause(final String[] p0, final boolean p1);
    
    String constructDoubleCastClause(final String p0);
    
    String constructCountClause(final String p0);
    
    String constructRegexpClause(final String p0, final String p1, final boolean p2);
    
    String constructSubstringClause(final String p0, final String p1, final boolean p2);
    
    String constructOffsetLimitClause(final int p0, final int p1, final boolean p2);
    
    String constructOffsetLimitClause(final int p0, final int p1);
    
    String constructDistinctOnClause(final List p0, final String p1, final List p2, final String[] p3, final String[] p4, final boolean[] p5, final Map<String, String> p6);
    
    int findConjunctionClauseMax(final ClauseDescription[] p0);
    
    String buildConjunctionClause(final List p0, final ClauseDescription[] p1);
    
    int getMaxInClause();
    
    int getMaxOrClause();
    
    int getWindowedReportMaxRows();
    
    void beginTransaction() throws ManifoldCFException;
    
    void beginTransaction(final int p0) throws ManifoldCFException;
    
    void performCommit() throws ManifoldCFException;
    
    void signalRollback();
    
    void endTransaction() throws ManifoldCFException;
    
    void noteModifications(final String p0, final int p1, final int p2, final int p3) throws ManifoldCFException;
    
    long getSleepAmt();
    
    void sleepFor(final long p0) throws ManifoldCFException;
}
