// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.apache.manifoldcf.core.system.ManifoldCF;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

public abstract class ConnectorFactory<T extends IConnector>
{
    public static final String _rcsid = "@(#)$Id: OutputConnectorFactory.java 988245 2010-08-23 18:39:35Z kwright $";
    
    protected ConnectorFactory() {
    }
    
    protected abstract boolean isInstalled(final IThreadContext p0, final String p1) throws ManifoldCFException;
    
    protected void installThis(final IThreadContext threadContext, final String className) throws ManifoldCFException {
        final T connector = this.getThisConnectorNoCheck(className);
        connector.install(threadContext);
    }
    
    protected void deinstallThis(final IThreadContext threadContext, final String className) throws ManifoldCFException {
        final T connector = this.getThisConnectorNoCheck(className);
        connector.deinstall(threadContext);
    }
    
    protected void outputThisConfigurationHeader(final IThreadContext threadContext, final String className, final IHTTPOutput out, final Locale locale, final ConfigParams parameters, final ArrayList tabsArray) throws ManifoldCFException, IOException {
        final T connector = this.getThisConnector(threadContext, className);
        if (connector == null) {
            return;
        }
        connector.outputConfigurationHeader(threadContext, out, locale, parameters, tabsArray);
    }
    
    protected void outputThisConfigurationBody(final IThreadContext threadContext, final String className, final IHTTPOutput out, final Locale locale, final ConfigParams parameters, final String tabName) throws ManifoldCFException, IOException {
        final T connector = this.getThisConnector(threadContext, className);
        if (connector == null) {
            return;
        }
        connector.outputConfigurationBody(threadContext, out, locale, parameters, tabName);
    }
    
    protected String processThisConfigurationPost(final IThreadContext threadContext, final String className, final IPostParameters variableContext, final Locale locale, final ConfigParams configParams) throws ManifoldCFException {
        final T connector = this.getThisConnector(threadContext, className);
        if (connector == null) {
            return null;
        }
        return connector.processConfigurationPost(threadContext, variableContext, locale, configParams);
    }
    
    protected void viewThisConfiguration(final IThreadContext threadContext, final String className, final IHTTPOutput out, final Locale locale, final ConfigParams configParams) throws ManifoldCFException, IOException {
        final T connector = this.getThisConnector(threadContext, className);
        if (connector == null) {
            return;
        }
        connector.viewConfiguration(threadContext, out, locale, configParams);
    }
    
    protected T getThisConnectorNoCheck(final String className) throws ManifoldCFException {
        final T rval = this.getThisConnectorRaw(className);
        if (rval == null) {
            throw new ManifoldCFException("No connector class '" + className + "' was found.");
        }
        return rval;
    }
    
    protected T getThisConnector(final IThreadContext threadContext, final String className) throws ManifoldCFException {
        if (!this.isInstalled(threadContext, className)) {
            return null;
        }
        return this.getThisConnectorRaw(className);
    }
    
    protected T getThisConnectorRaw(final String className) throws ManifoldCFException {
        try {
            final Class theClass = ManifoldCF.findClass(className);
            final Class[] argumentClasses = new Class[0];
            final Constructor c = theClass.getConstructor((Class[])argumentClasses);
            final Object[] arguments = new Object[0];
            final Object o = c.newInstance(arguments);
            try {
                return (T)o;
            }
            catch (ClassCastException e8) {
                throw new ManifoldCFException("Class '" + className + "' does not implement IConnector.");
            }
        }
        catch (InvocationTargetException e) {
            final Throwable z = e.getTargetException();
            if (z instanceof Error) {
                throw (Error)z;
            }
            if (z instanceof RuntimeException) {
                throw (RuntimeException)z;
            }
            if (z instanceof ManifoldCFException) {
                throw (ManifoldCFException)z;
            }
            throw new RuntimeException("Unknown exception type: " + z.getClass().getName() + ": " + z.getMessage(), z);
        }
        catch (ClassNotFoundException e9) {
            return null;
        }
        catch (NoSuchMethodException e2) {
            throw new ManifoldCFException("No appropriate constructor for IConnector implementation '" + className + "'.  Need xxx().", e2);
        }
        catch (SecurityException e3) {
            throw new ManifoldCFException("Protected constructor for IConnector implementation '" + className + "'", e3);
        }
        catch (IllegalAccessException e4) {
            throw new ManifoldCFException("Unavailable constructor for IConnector implementation '" + className + "'", e4);
        }
        catch (IllegalArgumentException e5) {
            throw new ManifoldCFException("Shouldn't happen!!!", e5);
        }
        catch (InstantiationException e6) {
            throw new ManifoldCFException("InstantiationException for IConnector implementation '" + className + "'", e6);
        }
        catch (ExceptionInInitializerError e7) {
            throw new ManifoldCFException("ExceptionInInitializerError for IConnector implementation '" + className + "'", e7);
        }
    }
}
