// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;

public class StringSetBuffer
{
    public static final String _rcsid = "@(#)$Id: StringSetBuffer.java 988245 2010-08-23 18:39:35Z kwright $";
    protected HashMap hashtable;
    
    public StringSetBuffer() {
        this.hashtable = new HashMap();
    }
    
    public void clear() {
        this.hashtable.clear();
    }
    
    public boolean contains(final String x) {
        return this.hashtable.get(x) != null;
    }
    
    public boolean contains(final StringSet x) {
        final Iterator iter = x.getKeys();
        while (iter.hasNext()) {
            final String key = iter.next();
            if (this.contains(key)) {
                return true;
            }
        }
        return false;
    }
    
    public void add(final String s) {
        this.add(s, null);
    }
    
    public void add(String s, final String prefix) {
        if (prefix != null) {
            s = prefix + s;
        }
        this.hashtable.put(s, s);
    }
    
    public void add(final StringSet ss) {
        this.add(ss, null);
    }
    
    public void add(final StringSet ss, final String prefix) {
        final Iterator iterator = ss.getKeys();
        while (iterator.hasNext()) {
            final String key = iterator.next();
            this.add(key, prefix);
        }
    }
    
    public void add(final String[] stringArray) {
        this.add(stringArray, null);
    }
    
    public void add(final String[] stringArray, final String prefix) {
        int i = 0;
        while (i < stringArray.length) {
            this.add(stringArray[i++], prefix);
        }
    }
    
    public void add(final Map table) {
        this.add(table, null);
    }
    
    public void add(final Map table, final String prefix) {
        for (final String key : table.values()) {
            this.add(key, prefix);
        }
    }
    
    public void remove(final String value) {
        this.hashtable.remove(value);
    }
    
    public int size() {
        return this.hashtable.size();
    }
    
    public Iterator getKeys() {
        return this.hashtable.keySet().iterator();
    }
    
    public String[] getArray(final String prefix) {
        final String[] rval = new String[this.hashtable.size()];
        int i = 0;
        for (String x : this.hashtable.keySet()) {
            if (prefix != null) {
                x = prefix + x;
            }
            rval[i++] = x;
        }
        return rval;
    }
}
