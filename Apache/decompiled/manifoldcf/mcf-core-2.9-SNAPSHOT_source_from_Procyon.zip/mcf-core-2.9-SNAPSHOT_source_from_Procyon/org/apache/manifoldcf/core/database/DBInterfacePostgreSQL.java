// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import org.apache.manifoldcf.core.interfaces.ClauseDescription;
import java.util.Collection;
import org.apache.manifoldcf.core.interfaces.StringSetBuffer;
import org.apache.manifoldcf.core.interfaces.IResultRow;
import java.util.HashMap;
import java.sql.SQLException;
import org.apache.manifoldcf.core.system.Logging;
import org.apache.manifoldcf.core.interfaces.IResultSet;
import org.apache.manifoldcf.core.interfaces.ILimitChecker;
import org.apache.manifoldcf.core.interfaces.ResultSpecification;
import org.apache.manifoldcf.core.interfaces.IDFactory;
import org.apache.manifoldcf.core.interfaces.IndexDescription;
import org.apache.manifoldcf.core.interfaces.ColumnDescription;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.StringSet;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import org.apache.manifoldcf.core.interfaces.CacheKeyFactory;
import java.util.ArrayList;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import java.util.Map;
import java.util.List;
import org.apache.manifoldcf.core.interfaces.ILockManager;
import org.apache.manifoldcf.core.interfaces.IDBInterface;

public class DBInterfacePostgreSQL extends Database implements IDBInterface
{
    public static final String _rcsid = "@(#)$Id: DBInterfacePostgreSQL.java 999670 2010-09-21 22:18:19Z kwright $";
    public static final String postgresqlHostnameProperty = "org.apache.manifoldcf.postgresql.hostname";
    public static final String postgresqlPortProperty = "org.apache.manifoldcf.postgresql.port";
    public static final String postgresqlSslProperty = "org.apache.manifoldcf.postgresql.ssl";
    private static final String _defaultUrl = "jdbc:postgresql://localhost/";
    private static final String _driver = "org.postgresql.Driver";
    protected final ILockManager lockManager;
    protected final String cacheKey;
    protected int serializableDepth;
    protected List<String> tablesToAnalyze;
    protected List<String> tablesToReindex;
    protected static Map<String, TableStatistics> currentReindexStatistics;
    protected static Map<String, Integer> reindexThresholds;
    protected static Map<String, TableStatistics> currentAnalyzeStatistics;
    protected static Map<String, Integer> analyzeThresholds;
    protected static final int commitThreshold = 100;
    protected static final String statslockReindexPrefix = "statslock-reindex-";
    protected static final String statsReindexPrefix = "stats-reindex-";
    protected static final String statslockAnalyzePrefix = "statslock-analyze-";
    protected static final String statsAnalyzePrefix = "stats-analyze-";
    
    public DBInterfacePostgreSQL(final IThreadContext tc, final String databaseName, final String userName, final String password) throws ManifoldCFException {
        super(tc, getJdbcUrl(tc, databaseName), "org.postgresql.Driver", databaseName, userName, password);
        this.serializableDepth = 0;
        this.tablesToAnalyze = new ArrayList<String>();
        this.tablesToReindex = new ArrayList<String>();
        this.cacheKey = CacheKeyFactory.makeDatabaseKey(this.databaseName);
        this.lockManager = LockManagerFactory.make(tc);
    }
    
    private static String getJdbcUrl(final IThreadContext tc, final String databaseName) throws ManifoldCFException {
        String jdbcUrl = "jdbc:postgresql://localhost/" + databaseName;
        final String hostname = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.postgresql.hostname");
        final String ssl = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.postgresql.ssl");
        final String port = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.postgresql.port");
        if (hostname != null && hostname.length() > 0) {
            jdbcUrl = "jdbc:postgresql://" + hostname;
            if (port != null && port.length() > 0) {
                jdbcUrl = jdbcUrl + ":" + port;
            }
            jdbcUrl = jdbcUrl + "/" + databaseName;
            if (ssl != null && ssl.equals("true")) {
                jdbcUrl += "?ssl=true";
            }
        }
        return jdbcUrl;
    }
    
    @Override
    public void openDatabase() throws ManifoldCFException {
    }
    
    @Override
    public void closeDatabase() throws ManifoldCFException {
    }
    
    @Override
    public String getDatabaseCacheKey() {
        return this.cacheKey;
    }
    
    @Override
    public void performInsert(final String tableName, final Map<String, Object> parameterMap, final StringSet invalidateKeys) throws ManifoldCFException {
        final List paramArray = new ArrayList();
        final StringBuilder bf = new StringBuilder();
        bf.append("INSERT INTO ");
        bf.append(tableName);
        bf.append(" (");
        final StringBuilder values = new StringBuilder(" VALUES (");
        final Iterator<Map.Entry<String, Object>> it = parameterMap.entrySet().iterator();
        boolean first = true;
        while (it.hasNext()) {
            final Map.Entry<String, Object> e = it.next();
            final String key = e.getKey();
            final Object o = e.getValue();
            if (o != null) {
                paramArray.add(o);
                if (!first) {
                    bf.append(',');
                    values.append(',');
                }
                bf.append(key);
                values.append('?');
                first = false;
            }
        }
        bf.append(')');
        values.append(')');
        bf.append((CharSequence)values);
        this.performModification(bf.toString(), paramArray, invalidateKeys);
    }
    
    @Override
    public void performUpdate(final String tableName, final Map<String, Object> parameterMap, final String whereClause, final List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        final List paramArray = new ArrayList();
        final StringBuilder bf = new StringBuilder();
        bf.append("UPDATE ");
        bf.append(tableName);
        bf.append(" SET ");
        final Iterator<Map.Entry<String, Object>> it = parameterMap.entrySet().iterator();
        boolean first = true;
        while (it.hasNext()) {
            final Map.Entry<String, Object> e = it.next();
            final String key = e.getKey();
            final Object o = e.getValue();
            if (!first) {
                bf.append(',');
            }
            bf.append(key);
            bf.append('=');
            if (o == null) {
                bf.append("NULL");
            }
            else {
                bf.append('?');
                paramArray.add(o);
            }
            first = false;
        }
        if (whereClause != null) {
            bf.append(' ');
            bf.append(whereClause);
            if (whereParameters != null) {
                for (int i = 0; i < whereParameters.size(); ++i) {
                    final Object value = whereParameters.get(i);
                    paramArray.add(value);
                }
            }
        }
        this.performModification(bf.toString(), paramArray, invalidateKeys);
    }
    
    @Override
    public void performDelete(final String tableName, final String whereClause, List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        final StringBuilder bf = new StringBuilder();
        bf.append("DELETE FROM ");
        bf.append(tableName);
        if (whereClause != null) {
            bf.append(' ');
            bf.append(whereClause);
        }
        else {
            whereParameters = null;
        }
        this.performModification(bf.toString(), whereParameters, invalidateKeys);
    }
    
    @Override
    public void performCreate(final String tableName, final Map<String, ColumnDescription> columnMap, final StringSet invalidateKeys) throws ManifoldCFException {
        final StringBuilder queryBuffer = new StringBuilder("CREATE TABLE ");
        queryBuffer.append(tableName);
        queryBuffer.append('(');
        final Iterator<String> iter = columnMap.keySet().iterator();
        boolean first = true;
        while (iter.hasNext()) {
            final String columnName = iter.next();
            final ColumnDescription cd = columnMap.get(columnName);
            if (!first) {
                queryBuffer.append(',');
            }
            else {
                first = false;
            }
            appendDescription(queryBuffer, columnName, cd, false);
        }
        queryBuffer.append(')');
        this.performModification(queryBuffer.toString(), null, invalidateKeys);
    }
    
    protected static void appendDescription(final StringBuilder queryBuffer, final String columnName, final ColumnDescription cd, final boolean forceNull) {
        queryBuffer.append(columnName);
        queryBuffer.append(' ');
        queryBuffer.append(mapType(cd.getTypeString()));
        if (forceNull || cd.getIsNull()) {
            queryBuffer.append(" NULL");
        }
        else {
            queryBuffer.append(" NOT NULL");
        }
        if (cd.getIsPrimaryKey()) {
            queryBuffer.append(" PRIMARY KEY");
        }
        if (cd.getReferenceTable() != null) {
            queryBuffer.append(" REFERENCES ");
            queryBuffer.append(cd.getReferenceTable());
            queryBuffer.append('(');
            queryBuffer.append(cd.getReferenceColumn());
            queryBuffer.append(") ON DELETE");
            if (cd.getReferenceCascade()) {
                queryBuffer.append(" CASCADE");
            }
            else {
                queryBuffer.append(" RESTRICT");
            }
        }
    }
    
    @Override
    public void performAlter(final String tableName, final Map<String, ColumnDescription> columnMap, final Map<String, ColumnDescription> columnModifyMap, final List<String> columnDeleteList, final StringSet invalidateKeys) throws ManifoldCFException {
        this.beginTransaction(0);
        try {
            if (columnDeleteList != null) {
                int i = 0;
                while (i < columnDeleteList.size()) {
                    final String columnName = columnDeleteList.get(i++);
                    this.performModification("ALTER TABLE ONLY " + tableName + " DROP " + columnName, null, invalidateKeys);
                }
            }
            if (columnModifyMap != null) {
                for (final String columnName : columnModifyMap.keySet()) {
                    final ColumnDescription cd = columnModifyMap.get(columnName);
                    final String renameColumn = "__temp__";
                    this.performModification("ALTER TABLE ONLY " + tableName + " RENAME " + columnName + " TO " + renameColumn, null, invalidateKeys);
                    final StringBuilder sb = new StringBuilder();
                    appendDescription(sb, columnName, cd, true);
                    this.performModification("ALTER TABLE ONLY " + tableName + " ADD " + sb.toString(), null, invalidateKeys);
                    this.performModification("UPDATE " + tableName + " SET " + columnName + "=" + renameColumn, null, invalidateKeys);
                    if (!cd.getIsNull()) {
                        this.performModification("ALTER TABLE ONLY " + tableName + " ALTER " + columnName + " SET NOT NULL", null, invalidateKeys);
                    }
                    this.performModification("ALTER TABLE ONLY " + tableName + " DROP " + renameColumn, null, invalidateKeys);
                }
            }
            if (columnMap != null) {
                for (final String columnName : columnMap.keySet()) {
                    final ColumnDescription cd = columnMap.get(columnName);
                    final StringBuilder sb2 = new StringBuilder();
                    appendDescription(sb2, columnName, cd, false);
                    this.performModification("ALTER TABLE ONLY " + tableName + " ADD " + sb2.toString(), null, invalidateKeys);
                }
            }
        }
        catch (ManifoldCFException e) {
            this.signalRollback();
            throw e;
        }
        catch (Error e2) {
            this.signalRollback();
            throw e2;
        }
        finally {
            this.endTransaction();
        }
    }
    
    protected static String mapType(final String inputType) {
        if (inputType.equalsIgnoreCase("longtext")) {
            return "text";
        }
        if (inputType.equalsIgnoreCase("blob")) {
            return "bytea";
        }
        return inputType;
    }
    
    @Override
    public void addTableIndex(final String tableName, final boolean unique, final List<String> columnList) throws ManifoldCFException {
        final String[] columns = new String[columnList.size()];
        for (int i = 0; i < columns.length; ++i) {
            columns[i] = columnList.get(i);
        }
        this.performAddIndex(null, tableName, new IndexDescription(unique, columns));
    }
    
    @Override
    public void performAddIndex(String indexName, final String tableName, final IndexDescription description) throws ManifoldCFException {
        final String[] columnNames = description.getColumnNames();
        if (columnNames.length == 0) {
            return;
        }
        if (indexName == null) {
            indexName = "I" + IDFactory.make(this.context);
        }
        final StringBuilder queryBuffer = new StringBuilder("CREATE ");
        if (description.getIsUnique()) {
            queryBuffer.append("UNIQUE ");
        }
        queryBuffer.append("INDEX ");
        queryBuffer.append(indexName);
        queryBuffer.append(" ON ");
        queryBuffer.append(tableName);
        queryBuffer.append(" (");
        for (int i = 0; i < columnNames.length; ++i) {
            final String colName = columnNames[i];
            if (i > 0) {
                queryBuffer.append(',');
            }
            queryBuffer.append(colName);
        }
        queryBuffer.append(')');
        this.performModification(queryBuffer.toString(), null, null);
    }
    
    @Override
    public void performRemoveIndex(final String indexName, final String tableName) throws ManifoldCFException {
        this.performModification("DROP INDEX " + indexName, null, null);
    }
    
    @Override
    public void performDrop(final String tableName, final StringSet invalidateKeys) throws ManifoldCFException {
        this.performModification("DROP TABLE " + tableName, null, invalidateKeys);
    }
    
    @Override
    public void createUserAndDatabase(final String adminUserName, final String adminPassword, final StringSet invalidateKeys) throws ManifoldCFException {
        final Database masterDatabase = new DBInterfacePostgreSQL(this.context, "template1", adminUserName, adminPassword);
        try {
            final List params = new ArrayList();
            params.add(this.userName);
            IResultSet set = masterDatabase.executeQuery("SELECT * FROM pg_user WHERE usename=?", params, null, null, null, true, -1, null, null);
            if (set.getRowCount() == 0) {
                final StringBuilder sb = new StringBuilder();
                sb.append("'");
                for (int i = 0; i < this.password.length(); ++i) {
                    final char x = this.password.charAt(i);
                    if (x == '\'') {
                        sb.append("'");
                    }
                    sb.append(x);
                }
                sb.append("'");
                final String quotedPassword = sb.toString();
                masterDatabase.executeQuery("CREATE USER " + this.userName + " PASSWORD " + quotedPassword, null, null, invalidateKeys, null, false, 0, null, null);
            }
            params.clear();
            params.add(this.databaseName);
            set = masterDatabase.executeQuery("SELECT * FROM pg_database WHERE datname=?", params, null, null, null, true, -1, null, null);
            if (set.getRowCount() == 0) {
                masterDatabase.prepareForDatabaseCreate();
                masterDatabase.executeQuery("CREATE DATABASE " + this.databaseName + " OWNER " + this.userName + " ENCODING 'utf8'", null, null, invalidateKeys, null, false, 0, null, null);
            }
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public void dropUserAndDatabase(final String adminUserName, final String adminPassword, final StringSet invalidateKeys) throws ManifoldCFException {
        final Database masterDatabase = new DBInterfacePostgreSQL(this.context, "template1", adminUserName, adminPassword);
        try {
            masterDatabase.executeQuery("DROP DATABASE " + this.databaseName, null, null, invalidateKeys, null, false, 0, null, null);
            masterDatabase.executeQuery("DROP USER " + this.userName, null, null, invalidateKeys, null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    protected ManifoldCFException reinterpretException(final ManifoldCFException theException) {
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Reinterpreting exception '" + theException.getMessage() + "'.  The exception type is " + Integer.toString(theException.getErrorCode())));
        }
        if (theException.getErrorCode() != 4) {
            return theException;
        }
        final Throwable e = theException.getCause();
        if (!(e instanceof SQLException)) {
            return theException;
        }
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Exception " + theException.getMessage() + " is possibly a transaction abort signal"));
        }
        final SQLException sqlException = (SQLException)e;
        final String message = sqlException.getMessage();
        final String sqlState = sqlException.getSQLState();
        if (sqlState != null && sqlState.equals("08003")) {
            return new ManifoldCFException(message, e, 2);
        }
        if (sqlState != null && sqlState.equals("40001")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("40P01")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("23505")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("25P02")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Exception " + theException.getMessage() + " is NOT a transaction abort signal"));
        }
        return theException;
    }
    
    @Override
    public void performModification(final String query, final List params, final StringSet invalidateKeys) throws ManifoldCFException {
        try {
            this.executeQuery(query, params, null, invalidateKeys, null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public Map<String, ColumnDescription> getTableSchema(final String tableName, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        final StringBuilder query = new StringBuilder();
        final List list = new ArrayList();
        query.append("SELECT pg_attribute.attname AS \"Field\",");
        query.append("CASE pg_type.typname WHEN 'int2' THEN 'smallint' WHEN 'int4' THEN 'int'");
        query.append(" WHEN 'int8' THEN 'bigint' WHEN 'varchar' THEN 'varchar(' || pg_attribute.atttypmod-4 || ')'");
        query.append(" WHEN 'text' THEN 'longtext'");
        query.append(" WHEN 'bpchar' THEN 'char(' || pg_attribute.atttypmod-4 || ')'");
        query.append(" ELSE pg_type.typname END AS \"Type\",");
        query.append("CASE WHEN pg_attribute.attnotnull THEN '' ELSE 'YES' END AS \"Null\",");
        query.append("CASE pg_type.typname WHEN 'varchar' THEN substring(pg_attrdef.adsrc from '^(.*).*$') ELSE pg_attrdef.adsrc END AS Default ");
        query.append("FROM pg_class INNER JOIN pg_attribute ON (pg_class.oid=pg_attribute.attrelid) INNER JOIN pg_type ON (pg_attribute.atttypid=pg_type.oid) ");
        query.append("LEFT JOIN pg_attrdef ON (pg_class.oid=pg_attrdef.adrelid AND pg_attribute.attnum=pg_attrdef.adnum) ");
        query.append("WHERE pg_class.relname=? AND pg_attribute.attnum>=1 AND NOT pg_attribute.attisdropped ");
        query.append("ORDER BY pg_attribute.attnum");
        list.add(tableName);
        final IResultSet set = this.performQuery(query.toString(), list, cacheKeys, queryClass);
        if (set.getRowCount() == 0) {
            return null;
        }
        final Map<String, ColumnDescription> rval = new HashMap<String, ColumnDescription>();
        int i = 0;
        while (i < set.getRowCount()) {
            final IResultRow row = set.getRow(i++);
            final String fieldName = row.getValue("Field").toString();
            final String type = row.getValue("Type").toString();
            final boolean isNull = row.getValue("Null").toString().equals("YES");
            final boolean isPrimaryKey = false;
            rval.put(fieldName, new ColumnDescription(type, isPrimaryKey, isNull, null, null, false));
        }
        return rval;
    }
    
    @Override
    public Map<String, IndexDescription> getTableIndexes(final String tableName, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        final Map<String, IndexDescription> rval = new HashMap<String, IndexDescription>();
        final String query = "SELECT pg_catalog.pg_get_indexdef(i.indexrelid, 0, true) AS indexdef FROM pg_catalog.pg_class c, pg_catalog.pg_class c2, pg_catalog.pg_index i WHERE c.relname = ? AND c.oid = i.indrelid AND i.indexrelid = c2.oid";
        final List list = new ArrayList();
        list.add(tableName);
        final IResultSet result = this.performQuery(query, list, cacheKeys, queryClass);
        int i = 0;
        while (i < result.getRowCount()) {
            final IResultRow row = result.getRow(i++);
            final String indexdef = (String)row.getValue("indexdef");
            int parsePosition = 0;
            int beforeMatch = indexdef.indexOf("CREATE UNIQUE INDEX ", parsePosition);
            boolean isUnique;
            if (beforeMatch == -1) {
                beforeMatch = indexdef.indexOf("CREATE INDEX ", parsePosition);
                if (beforeMatch == -1) {
                    throw new ManifoldCFException("Cannot parse index description: '" + indexdef + "'");
                }
                isUnique = false;
                parsePosition += "CREATE INDEX ".length();
            }
            else {
                isUnique = true;
                parsePosition += "CREATE UNIQUE INDEX ".length();
            }
            final int afterMatch = indexdef.indexOf(" ON", parsePosition);
            if (afterMatch == -1) {
                throw new ManifoldCFException("Cannot parse index description: '" + indexdef + "'");
            }
            final String indexName = indexdef.substring(parsePosition, afterMatch);
            parsePosition = afterMatch + " ON".length();
            final int parenPosition = indexdef.indexOf("(", parsePosition);
            if (parenPosition == -1) {
                throw new ManifoldCFException("Cannot parse index description: '" + indexdef + "'");
            }
            parsePosition = parenPosition + 1;
            final List<String> columns = new ArrayList<String>();
            while (true) {
                int nextIndex = indexdef.indexOf(",", parsePosition);
                final int nextParenIndex = indexdef.indexOf(")", parsePosition);
                if (nextIndex == -1) {
                    nextIndex = nextParenIndex;
                }
                if (nextIndex == -1) {
                    throw new ManifoldCFException("Cannot parse index description: '" + indexdef + "'");
                }
                if (nextParenIndex != -1 && nextParenIndex < nextIndex) {
                    nextIndex = nextParenIndex;
                }
                final String columnName = indexdef.substring(parsePosition, nextIndex).trim();
                columns.add(columnName);
                if (nextIndex == nextParenIndex) {
                    final String[] columnNames = new String[columns.size()];
                    for (int j = 0; j < columnNames.length; ++j) {
                        columnNames[j] = columns.get(j);
                    }
                    rval.put(indexName, new IndexDescription(isUnique, columnNames));
                    break;
                }
                parsePosition = nextIndex + 1;
            }
        }
        return rval;
    }
    
    @Override
    public StringSet getAllTables(final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        final IResultSet set = this.performQuery("SELECT relname FROM pg_class", null, cacheKeys, queryClass);
        final StringSetBuffer ssb = new StringSetBuffer();
        final String columnName = "relname";
        int i = 0;
        while (i < set.getRowCount()) {
            final IResultRow row = set.getRow(i++);
            final String value = row.getValue(columnName).toString();
            ssb.add(value);
        }
        return new StringSet(ssb);
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, -1, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass, final int maxResults, final ILimitChecker returnLimit) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, maxResults, null, returnLimit);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass, final int maxResults, final ResultSpecification resultSpec, final ILimitChecker returnLimit) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, maxResults, resultSpec, returnLimit);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public String constructDoubleCastClause(final String value) {
        return "CAST(" + value + " AS DOUBLE PRECISION)";
    }
    
    @Override
    public String constructCountClause(final String column) {
        return "COUNT(" + column + ")";
    }
    
    @Override
    public String constructRegexpClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        return column + "~" + (caseInsensitive ? "*" : "") + regularExpression;
    }
    
    @Override
    public String constructSubstringClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        final StringBuilder sb = new StringBuilder();
        sb.append("SUBSTRING(");
        if (caseInsensitive) {
            sb.append("LOWER(").append(column).append(")");
        }
        else {
            sb.append(column);
        }
        sb.append(" FROM ");
        if (caseInsensitive) {
            sb.append("LOWER(").append(regularExpression).append(")");
        }
        else {
            sb.append(regularExpression);
        }
        sb.append(")");
        return sb.toString();
    }
    
    @Override
    public String constructOffsetLimitClause(final int offset, final int limit, final boolean afterOrderBy) {
        final StringBuilder sb = new StringBuilder();
        if (offset != 0) {
            sb.append("OFFSET ").append(Integer.toString(offset));
        }
        if (limit != -1) {
            if (offset != 0) {
                sb.append(" ");
            }
            sb.append("LIMIT ").append(Integer.toString(limit));
        }
        return sb.toString();
    }
    
    @Override
    public String constructDistinctOnClause(final List outputParameters, final String baseQuery, final List baseParameters, final String[] distinctFields, final String[] orderFields, final boolean[] orderFieldsAscending, final Map<String, String> otherFields) {
        if (baseParameters != null) {
            outputParameters.addAll(baseParameters);
        }
        final StringBuilder sb = new StringBuilder("SELECT DISTINCT ON(");
        int i = 0;
        while (i < distinctFields.length) {
            if (i > 0) {
                sb.append(",");
            }
            sb.append(distinctFields[i++]);
        }
        sb.append(") ");
        final Iterator<String> iter = otherFields.keySet().iterator();
        boolean needComma = false;
        while (iter.hasNext()) {
            final String fieldName = iter.next();
            final String columnValue = otherFields.get(fieldName);
            if (needComma) {
                sb.append(",");
            }
            needComma = true;
            sb.append("txxx1.").append(columnValue).append(" AS ").append(fieldName);
        }
        sb.append(" FROM (").append(baseQuery).append(") txxx1");
        if (distinctFields.length > 0 || orderFields.length > 0) {
            sb.append(" ORDER BY ");
            int k = 0;
            for (i = 0; i < distinctFields.length; ++i) {
                if (k > 0) {
                    sb.append(",");
                }
                sb.append(distinctFields[i]).append(" ASC");
                ++k;
            }
            for (i = 0; i < orderFields.length; ++i, ++k) {
                if (k > 0) {
                    sb.append(",");
                }
                sb.append(orderFields[i]).append(" ");
                if (orderFieldsAscending[i]) {
                    sb.append("ASC");
                }
                else {
                    sb.append("DESC");
                }
            }
        }
        return sb.toString();
    }
    
    @Override
    public int getMaxInClause() {
        return 100;
    }
    
    @Override
    public int getMaxOrClause() {
        return 25;
    }
    
    @Override
    public int findConjunctionClauseMax(final ClauseDescription[] otherClauseDescriptions) {
        return this.getMaxOrClause();
    }
    
    @Override
    public String buildConjunctionClause(final List outputParameters, final ClauseDescription[] clauseDescriptions) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < clauseDescriptions.length; ++i) {
            final ClauseDescription cd = clauseDescriptions[i];
            if (i > 0) {
                sb.append(" AND ");
            }
            final String columnName = cd.getColumnName();
            final List values = cd.getValues();
            final String operation = cd.getOperation();
            final String joinColumn = cd.getJoinColumnName();
            if (values != null) {
                if (values.size() > 1) {
                    sb.append(" (");
                    for (int j = 0; j < values.size(); ++j) {
                        if (j > 0) {
                            sb.append(" OR ");
                        }
                        sb.append(columnName).append(operation).append("?");
                        outputParameters.add(values.get(j));
                    }
                    sb.append(")");
                }
                else {
                    sb.append(columnName).append(operation).append("?");
                    outputParameters.add(values.get(0));
                }
            }
            else if (joinColumn != null) {
                sb.append(columnName).append(operation).append(joinColumn);
            }
            else {
                sb.append(columnName).append(operation);
            }
        }
        return sb.toString();
    }
    
    @Override
    public int getWindowedReportMaxRows() {
        return 5000;
    }
    
    @Override
    public void beginTransaction() throws ManifoldCFException {
        this.beginTransaction(0);
    }
    
    @Override
    public void beginTransaction(int transactionType) throws ManifoldCFException {
        if (this.getCurrentTransactionType() == 2) {
            ++this.serializableDepth;
            return;
        }
        if (transactionType == 0) {
            transactionType = this.getCurrentTransactionType();
        }
        switch (transactionType) {
            case 1: {
                super.beginTransaction(1);
                return;
            }
            case 2: {
                super.beginTransaction(2);
                try {
                    this.performModification("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE", null, null);
                    return;
                }
                catch (Error e) {
                    super.signalRollback();
                    super.endTransaction();
                    throw e;
                }
                catch (ManifoldCFException e2) {
                    super.signalRollback();
                    super.endTransaction();
                    throw e2;
                }
                break;
            }
        }
        throw new ManifoldCFException("Bad transaction type: " + Integer.toString(transactionType));
    }
    
    @Override
    public void signalRollback() {
        if (this.serializableDepth == 0) {
            super.signalRollback();
        }
    }
    
    @Override
    public void endTransaction() throws ManifoldCFException {
        if (this.serializableDepth > 0) {
            --this.serializableDepth;
            return;
        }
        super.endTransaction();
        if (this.getTransactionID() == null) {
            int i = 0;
            while (i < this.tablesToAnalyze.size()) {
                this.analyzeTableInternal(this.tablesToAnalyze.get(i++));
            }
            this.tablesToAnalyze.clear();
            i = 0;
            while (i < this.tablesToReindex.size()) {
                this.reindexTableInternal(this.tablesToReindex.get(i++));
            }
            this.tablesToReindex.clear();
        }
    }
    
    @Override
    protected void startATransaction() throws ManifoldCFException {
        try {
            this.executeViaThread((this.connection == null) ? null : this.connection.getConnection(), "START TRANSACTION", null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    protected void commitCurrentTransaction() throws ManifoldCFException {
        try {
            this.executeViaThread((this.connection == null) ? null : this.connection.getConnection(), "COMMIT", null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    protected void rollbackCurrentTransaction() throws ManifoldCFException {
        try {
            this.executeViaThread((this.connection == null) ? null : this.connection.getConnection(), "ROLLBACK", null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    protected void explainQuery(final String query, final List params) throws ManifoldCFException {
        String queryType = "EXPLAIN ";
        if ("SELECT".equalsIgnoreCase(query.substring(0, 6))) {
            queryType += "ANALYZE ";
        }
        IResultSet x = this.executeUncachedQuery(queryType + query, params, true, -1, null, null);
        for (int k = 0; k < x.getRowCount(); ++k) {
            final IResultRow row = x.getRow(k);
            final Iterator<String> iter = row.getColumns();
            final String colName = iter.next();
            Logging.db.warn((Object)(" Plan: " + row.getValue(colName).toString()));
        }
        Logging.db.warn((Object)"");
        if (query.indexOf("jobqueue") != -1) {
            x = this.executeUncachedQuery("select n_distinct, most_common_vals, most_common_freqs from pg_stats where tablename='jobqueue' and attname='status'", null, true, -1, null, null);
            for (int k = 0; k < x.getRowCount(); ++k) {
                final IResultRow row = x.getRow(k);
                Logging.db.warn((Object)(" Stats: n_distinct=" + row.getValue("n_distinct").toString() + " most_common_vals=" + row.getValue("most_common_vals").toString() + " most_common_freqs=" + row.getValue("most_common_freqs").toString()));
            }
            Logging.db.warn((Object)"");
        }
    }
    
    protected int readDatum(final String datumName) throws ManifoldCFException {
        final byte[] bytes = this.lockManager.readData(datumName);
        if (bytes == null) {
            return 0;
        }
        return (bytes[0] & 0xFF) + ((bytes[1] & 0xFF) << 8) + ((bytes[2] & 0xFF) << 16) + ((bytes[3] & 0xFF) << 24);
    }
    
    protected void writeDatum(final String datumName, final int value) throws ManifoldCFException {
        final byte[] bytes = { (byte)(value & 0xFF), (byte)(value >> 8 & 0xFF), (byte)(value >> 16 & 0xFF), (byte)(value >> 24 & 0xFF) };
        this.lockManager.writeData(datumName, bytes);
    }
    
    @Override
    public void analyzeTable(final String tableName) throws ManifoldCFException {
        final String tableStatisticsLock = "statslock-analyze-" + tableName;
        this.lockManager.enterWriteCriticalSection(tableStatisticsLock);
        try {
            final TableStatistics ts = DBInterfacePostgreSQL.currentAnalyzeStatistics.get(tableName);
            this.lockManager.enterWriteLock(tableStatisticsLock);
            try {
                final String eventDatum = "stats-analyze-" + tableName;
                this.analyzeTableInternal(tableName);
                this.writeDatum(eventDatum, 0);
                if (ts != null) {
                    ts.reset();
                }
            }
            finally {
                this.lockManager.leaveWriteLock(tableStatisticsLock);
            }
        }
        finally {
            this.lockManager.leaveWriteCriticalSection(tableStatisticsLock);
        }
    }
    
    @Override
    public void reindexTable(final String tableName) throws ManifoldCFException {
        final String tableStatisticsLock = "statslock-reindex-" + tableName;
        this.lockManager.enterWriteCriticalSection(tableStatisticsLock);
        try {
            final TableStatistics ts = DBInterfacePostgreSQL.currentReindexStatistics.get(tableName);
            this.lockManager.enterWriteLock(tableStatisticsLock);
            try {
                final String eventDatum = "stats-reindex-" + tableName;
                this.reindexTableInternal(tableName);
                this.writeDatum(eventDatum, 0);
                if (ts != null) {
                    ts.reset();
                }
            }
            finally {
                this.lockManager.leaveWriteLock(tableStatisticsLock);
            }
        }
        finally {
            this.lockManager.leaveWriteCriticalSection(tableStatisticsLock);
        }
    }
    
    protected void analyzeTableInternal(final String tableName) throws ManifoldCFException {
        if (this.getTransactionID() == null) {
            this.performModification("ANALYZE " + tableName, null, null);
        }
        else {
            this.tablesToAnalyze.add(tableName);
        }
    }
    
    protected void reindexTableInternal(final String tableName) throws ManifoldCFException {
        if (this.getTransactionID() == null) {
            long sleepAmt = 0L;
            while (true) {
                try {
                    this.performModification("REINDEX TABLE " + tableName, null, null);
                }
                catch (ManifoldCFException e) {
                    if (e.getErrorCode() == 6) {
                        sleepAmt = this.getSleepAmt();
                        this.sleepFor(sleepAmt);
                        continue;
                    }
                    throw e;
                }
                finally {
                    this.sleepFor(sleepAmt);
                }
                break;
            }
        }
        else {
            this.tablesToReindex.add(tableName);
        }
    }
    
    @Override
    protected void noteModificationsNoTransactions(final String tableName, final int insertCount, final int modifyCount, final int deleteCount) throws ManifoldCFException {
        int eventCount = modifyCount + deleteCount;
        String tableStatisticsLock = "statslock-reindex-" + tableName;
        this.lockManager.enterWriteCriticalSection(tableStatisticsLock);
        try {
            final Integer threshold = DBInterfacePostgreSQL.reindexThresholds.get(tableName);
            int reindexThreshold;
            if (threshold == null) {
                reindexThreshold = this.lockManager.getSharedConfiguration().getIntProperty("org.apache.manifoldcf.db.postgres.reindex." + tableName, 250000);
                DBInterfacePostgreSQL.reindexThresholds.put(tableName, new Integer(reindexThreshold));
            }
            else {
                reindexThreshold = threshold;
            }
            TableStatistics ts = DBInterfacePostgreSQL.currentReindexStatistics.get(tableName);
            if (ts == null) {
                ts = new TableStatistics();
                DBInterfacePostgreSQL.currentReindexStatistics.put(tableName, ts);
            }
            ts.add(eventCount);
            if (ts.getEventCount() >= 100) {
                this.lockManager.enterWriteLock(tableStatisticsLock);
                try {
                    final String eventDatum = "stats-reindex-" + tableName;
                    int oldEventCount = this.readDatum(eventDatum);
                    oldEventCount += ts.getEventCount();
                    if (oldEventCount >= reindexThreshold) {
                        this.reindexTableInternal(tableName);
                        this.writeDatum(eventDatum, 0);
                    }
                    else {
                        this.writeDatum(eventDatum, oldEventCount);
                    }
                    ts.reset();
                }
                finally {
                    this.lockManager.leaveWriteLock(tableStatisticsLock);
                }
            }
        }
        finally {
            this.lockManager.leaveWriteCriticalSection(tableStatisticsLock);
        }
        eventCount = modifyCount + insertCount;
        tableStatisticsLock = "statslock-analyze-" + tableName;
        this.lockManager.enterWriteCriticalSection(tableStatisticsLock);
        try {
            final Integer threshold = DBInterfacePostgreSQL.analyzeThresholds.get(tableName);
            int analyzeThreshold;
            if (threshold == null) {
                analyzeThreshold = this.lockManager.getSharedConfiguration().getIntProperty("org.apache.manifoldcf.db.postgres.analyze." + tableName, 2000);
                DBInterfacePostgreSQL.analyzeThresholds.put(tableName, new Integer(analyzeThreshold));
            }
            else {
                analyzeThreshold = threshold;
            }
            TableStatistics ts = DBInterfacePostgreSQL.currentAnalyzeStatistics.get(tableName);
            if (ts == null) {
                ts = new TableStatistics();
                DBInterfacePostgreSQL.currentAnalyzeStatistics.put(tableName, ts);
            }
            ts.add(eventCount);
            if (ts.getEventCount() >= 100) {
                this.lockManager.enterWriteLock(tableStatisticsLock);
                try {
                    final String eventDatum = "stats-analyze-" + tableName;
                    int oldEventCount = this.readDatum(eventDatum);
                    oldEventCount += ts.getEventCount();
                    if (oldEventCount >= analyzeThreshold) {
                        this.analyzeTableInternal(tableName);
                        this.writeDatum(eventDatum, 0);
                    }
                    else {
                        this.writeDatum(eventDatum, oldEventCount);
                    }
                    ts.reset();
                }
                finally {
                    this.lockManager.leaveWriteLock(tableStatisticsLock);
                }
            }
        }
        finally {
            this.lockManager.leaveWriteCriticalSection(tableStatisticsLock);
        }
    }
    
    static {
        DBInterfacePostgreSQL.currentReindexStatistics = new HashMap<String, TableStatistics>();
        DBInterfacePostgreSQL.reindexThresholds = new HashMap<String, Integer>();
        DBInterfacePostgreSQL.currentAnalyzeStatistics = new HashMap<String, TableStatistics>();
        DBInterfacePostgreSQL.analyzeThresholds = new HashMap<String, Integer>();
    }
    
    protected static class TableStatistics
    {
        protected int eventCount;
        
        public TableStatistics() {
            this.eventCount = 0;
        }
        
        public void reset() {
            this.eventCount = 0;
        }
        
        public void add(final int eventCount) {
            this.eventCount += eventCount;
        }
        
        public int getEventCount() {
            return this.eventCount;
        }
    }
}
