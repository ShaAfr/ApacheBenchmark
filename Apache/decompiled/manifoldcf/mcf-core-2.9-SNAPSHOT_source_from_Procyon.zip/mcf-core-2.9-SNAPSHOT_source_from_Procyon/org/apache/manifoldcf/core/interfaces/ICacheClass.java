// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface ICacheClass
{
    public static final String _rcsid = "@(#)$Id: ICacheClass.java 988245 2010-08-23 18:39:35Z kwright $";
    
    String getClassName();
    
    int getMaxLRUCount();
}
