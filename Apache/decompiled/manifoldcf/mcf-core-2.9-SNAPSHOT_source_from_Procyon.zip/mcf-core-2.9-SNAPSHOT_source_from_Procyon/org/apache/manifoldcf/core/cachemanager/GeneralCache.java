// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.cachemanager;

import java.util.HashMap;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.StringSet;

public class GeneralCache
{
    public static final String _rcsid = "@(#)$Id: GeneralCache.java 988245 2010-08-23 18:39:35Z kwright $";
    protected ObjectRecordTable hashtable;
    protected InvalidationTable invalidationTable;
    protected ObjectClassTable objectClassTable;
    public ExpirationTree expirationTree;
    
    public GeneralCache() {
        this.hashtable = new ObjectRecordTable();
        this.invalidationTable = new InvalidationTable();
        this.objectClassTable = new ObjectClassTable();
        this.expirationTree = new ExpirationTree();
    }
    
    public synchronized Object lookup(final Object objectDescription) {
        final ObjectRecord o = this.hashtable.lookup(objectDescription);
        if (o == null) {
            return null;
        }
        return o.getObject();
    }
    
    public synchronized long getObjectCreationTime(final Object objectDescription) {
        final ObjectRecord o = this.hashtable.lookup(objectDescription);
        if (o == null) {
            return -1L;
        }
        return o.getCreationTime();
    }
    
    public synchronized StringSet getObjectInvalidationKeys(final Object objectDescription) {
        final ObjectRecord o = this.hashtable.lookup(objectDescription);
        if (o == null) {
            return null;
        }
        return o.getKeys();
    }
    
    public synchronized long getObjectExpirationTime(final Object objectDescription) {
        final ObjectRecord o = this.hashtable.lookup(objectDescription);
        if (o == null) {
            return -1L;
        }
        return o.getObjectExpiration();
    }
    
    public synchronized void deleteObject(final Object objectDescription) {
        final ObjectRecord o = this.hashtable.lookup(objectDescription);
        if (o != null) {
            this.deleteEntry(o);
        }
    }
    
    public synchronized void setObject(final Object objectDescription, final Object object, final StringSet keys, final long timestamp) {
        final ObjectRecord record = new ObjectRecord(objectDescription, object, keys, timestamp);
        this.hashtable.add(record);
        this.invalidationTable.addKeys(keys, record);
    }
    
    public synchronized void setObjectExpiration(final Object objectDescription, final long expirationTime) {
        final ObjectRecord existing = this.hashtable.lookup(objectDescription);
        if (existing == null) {
            return;
        }
        if (existing.getObjectExpiration() != -1L) {
            this.expirationTree.removeEntry(existing);
        }
        existing.setObjectExpiration(expirationTime);
        if (expirationTime != -1L) {
            this.expirationTree.addEntry(existing);
        }
    }
    
    public synchronized void setObjectClass(final Object objectDescription, final String objectClass, final int maxCount) {
        final ObjectRecord existing = this.hashtable.lookup(objectDescription);
        if (existing == null) {
            return;
        }
        if (existing.getObjectClass() != null) {
            this.objectClassTable.removeEntry(existing);
        }
        existing.setObjectClass(objectClass);
        if (objectClass != null) {
            this.objectClassTable.addEntry(existing);
            if (maxCount >= 0) {
                while (this.objectClassTable.getCurrentMemberCount(objectClass) > maxCount) {
                    final ObjectRecord oldestRecord = this.objectClassTable.getOldestEntry(objectClass);
                    this.deleteEntry(oldestRecord);
                }
            }
        }
    }
    
    public synchronized void invalidateKeys(final StringSet keys) {
        final Iterator enum2 = keys.getKeys();
        while (enum2.hasNext()) {
            final String invalidateKey = enum2.next();
            final Iterator enum3 = this.invalidationTable.getObjectRecordsForKey(invalidateKey);
            while (enum3.hasNext()) {
                final ObjectRecord record = enum3.next();
                this.hashtable.remove(record);
                if (record.getObjectClass() != null) {
                    this.objectClassTable.removeEntry(record);
                }
                if (record.getExpirationTime() >= 0L) {
                    this.expirationTree.removeEntry(record);
                }
            }
            this.invalidationTable.removeKey(invalidateKey);
        }
    }
    
    public void expireRecords(final long expireTime) {
        while (true) {
            synchronized (this) {
                final ObjectRecord x = this.expirationTree.getOldestEntry();
                if (x == null) {
                    break;
                }
                if (x.getExpirationTime() > expireTime) {
                    break;
                }
                this.deleteEntry(x);
            }
        }
    }
    
    protected void deleteEntry(final ObjectRecord record) {
        this.hashtable.remove(record);
        this.invalidationTable.removeObjectRecord(record);
        if (record.getObjectClass() != null) {
            this.objectClassTable.removeEntry(record);
        }
        if (record.getExpirationTime() >= 0L) {
            this.expirationTree.removeEntry(record);
        }
    }
    
    protected class ObjectRecord
    {
        protected Object objectDescription;
        protected Object theObject;
        protected StringSet invalidationKeys;
        protected long creationTime;
        protected long expirationTime;
        protected String objectClass;
        protected ObjectRecord prevLRU;
        protected ObjectRecord nextLRU;
        protected ObjectRecord sameExpirationPrev;
        protected ObjectRecord sameExpirationNext;
        
        public ObjectRecord(final Object objectDescription, final Object theObject, final StringSet invalidationKeys, final long creationTime) {
            this.expirationTime = -1L;
            this.objectClass = null;
            this.prevLRU = null;
            this.nextLRU = null;
            this.sameExpirationPrev = null;
            this.sameExpirationNext = null;
            this.creationTime = creationTime;
            this.objectDescription = objectDescription;
            this.theObject = theObject;
            this.invalidationKeys = invalidationKeys;
        }
        
        public long getCreationTime() {
            return this.creationTime;
        }
        
        public void setSameExpirationPrev(final ObjectRecord x) {
            this.sameExpirationPrev = x;
        }
        
        public ObjectRecord getSameExpirationPrev() {
            return this.sameExpirationPrev;
        }
        
        public void setSameExpirationNext(final ObjectRecord x) {
            this.sameExpirationNext = x;
        }
        
        public ObjectRecord getSameExpirationNext() {
            return this.sameExpirationNext;
        }
        
        public void setObjectExpiration(final long expTime) {
            this.expirationTime = expTime;
        }
        
        public long getObjectExpiration() {
            return this.expirationTime;
        }
        
        public Object getObjectDescription() {
            return this.objectDescription;
        }
        
        public void setObjectClass(final String className) {
            this.objectClass = className;
        }
        
        public String getObjectClass() {
            return this.objectClass;
        }
        
        public ObjectRecord getPrevLRU() {
            return this.prevLRU;
        }
        
        public ObjectRecord getNextLRU() {
            return this.nextLRU;
        }
        
        public void setPrevLRU(final ObjectRecord prev) {
            this.prevLRU = prev;
        }
        
        public void setNextLRU(final ObjectRecord next) {
            this.nextLRU = next;
        }
        
        public Object getObject() {
            return this.theObject;
        }
        
        public StringSet getKeys() {
            return this.invalidationKeys;
        }
        
        public long getExpirationTime() {
            return this.expirationTime;
        }
        
        @Override
        public int hashCode() {
            return this.objectDescription.hashCode();
        }
        
        @Override
        public boolean equals(final Object o) {
            if (!(o instanceof ObjectRecord)) {
                return false;
            }
            final ObjectRecord record = (ObjectRecord)o;
            return this.objectDescription.equals(record.objectDescription);
        }
    }
    
    protected class ObjectRecordTable
    {
        protected HashMap hashtable;
        
        public ObjectRecordTable() {
            this.hashtable = new HashMap();
        }
        
        public void add(final ObjectRecord record) {
            this.hashtable.put(record.getObjectDescription(), record);
        }
        
        public void remove(final Object objectDescription) {
            this.hashtable.remove(objectDescription);
        }
        
        public void remove(final ObjectRecord record) {
            this.hashtable.remove(record.getObjectDescription());
        }
        
        public ObjectRecord lookup(final Object objectDescription) {
            return this.hashtable.get(objectDescription);
        }
    }
    
    protected class InvalidationTable
    {
        protected HashMap hashtable;
        
        public InvalidationTable() {
            this.hashtable = new HashMap();
        }
        
        public void addKeys(final StringSet keyset, final ObjectRecord objectRecord) {
            final Iterator enum1 = keyset.getKeys();
            while (enum1.hasNext()) {
                final String key = enum1.next();
                HashMap ht = this.hashtable.get(key);
                if (ht == null) {
                    ht = new HashMap();
                    this.hashtable.put(key, ht);
                }
                ht.put(objectRecord, objectRecord);
            }
        }
        
        public Iterator getObjectRecordsForKey(final String key) {
            HashMap ht = this.hashtable.get(key);
            if (ht == null) {
                ht = new HashMap();
                this.hashtable.put(key, ht);
            }
            return ht.keySet().iterator();
        }
        
        public void removeKey(final String key) {
            this.hashtable.remove(key);
        }
        
        public void removeObjectRecord(final ObjectRecord record) {
            final StringSet keys = record.getKeys();
            final Iterator enum1 = keys.getKeys();
            while (enum1.hasNext()) {
                final String key = enum1.next();
                this.removeObjectRecordFromKey(key, record);
            }
        }
        
        public void removeObjectRecordFromKey(final String key, final ObjectRecord objectRecord) {
            final HashMap ht = this.hashtable.get(key);
            if (ht == null) {
                return;
            }
            ht.remove(objectRecord);
        }
    }
    
    protected class ObjectClassTable
    {
        protected HashMap hashtable;
        
        public ObjectClassTable() {
            this.hashtable = new HashMap();
        }
        
        public void addEntry(final ObjectRecord record) {
            ObjectClassRecord x = this.hashtable.get(record.getObjectClass());
            if (x == null) {
                x = new ObjectClassRecord();
                this.hashtable.put(record.getObjectClass(), x);
            }
            x.addEntry(record);
        }
        
        public void removeEntry(final ObjectRecord record) {
            final ObjectClassRecord x = this.hashtable.get(record.getObjectClass());
            if (x == null) {
                return;
            }
            x.removeEntry(record);
        }
        
        public int getCurrentMemberCount(final String objectClassName) {
            final ObjectClassRecord x = this.hashtable.get(objectClassName);
            if (x == null) {
                return 0;
            }
            return x.getCurrentMemberCount();
        }
        
        public ObjectRecord getOldestEntry(final String objectClassName) {
            final ObjectClassRecord x = this.hashtable.get(objectClassName);
            if (x == null) {
                return null;
            }
            return x.getOldestEntry();
        }
    }
    
    protected class ObjectClassRecord
    {
        protected int currentMemberCount;
        protected ObjectRecord firstLRU;
        protected ObjectRecord lastLRU;
        
        public ObjectClassRecord() {
            this.currentMemberCount = 0;
            this.firstLRU = null;
            this.lastLRU = null;
        }
        
        public int getCurrentMemberCount() {
            return this.currentMemberCount;
        }
        
        public void removeEntry(final ObjectRecord x) {
            --this.currentMemberCount;
            final ObjectRecord prev = x.getPrevLRU();
            final ObjectRecord next = x.getNextLRU();
            if (prev == null) {
                this.firstLRU = next;
            }
            else {
                prev.setNextLRU(next);
            }
            if (next == null) {
                this.lastLRU = prev;
            }
            else {
                next.setPrevLRU(prev);
            }
            x.setPrevLRU(null);
            x.setNextLRU(null);
        }
        
        public void addEntry(final ObjectRecord x) {
            ++this.currentMemberCount;
            x.setNextLRU(null);
            x.setPrevLRU(this.lastLRU);
            if (this.lastLRU == null) {
                this.firstLRU = x;
            }
            else {
                this.lastLRU.setNextLRU(x);
            }
            this.lastLRU = x;
        }
        
        public ObjectRecord getOldestEntry() {
            return this.firstLRU;
        }
    }
    
    protected class ExpirationTree
    {
        protected ExpirationTreeNode root;
        
        public ExpirationTree() {
            this.root = null;
        }
        
        public void removeEntry(final ObjectRecord x) {
            ExpirationTreeNode parent = null;
            boolean parentLesser = false;
            final long expTime = x.getExpirationTime();
            ExpirationTreeNode current = this.root;
            while (current != null) {
                final long nodeExpTime = current.getExpirationTime();
                if (expTime == nodeExpTime) {
                    if (current.removeObjectRecord(x)) {
                        final ExpirationTreeNode lesserSide = current.getLesser();
                        final ExpirationTreeNode greaterSide = current.getGreater();
                        if (lesserSide == null && greaterSide == null) {
                            this.setPointer(parent, parentLesser, null);
                        }
                        else if (lesserSide == null && greaterSide != null) {
                            this.setPointer(parent, parentLesser, greaterSide);
                        }
                        else if (lesserSide != null && greaterSide == null) {
                            this.setPointer(parent, parentLesser, lesserSide);
                        }
                        else {
                            this.setPointer(parent, parentLesser, greaterSide);
                            this.addTreeToBranch(greaterSide, true, lesserSide);
                        }
                    }
                    return;
                }
                if (expTime < nodeExpTime) {
                    parent = current;
                    parentLesser = true;
                    current = current.getLesser();
                }
                else {
                    parent = current;
                    parentLesser = false;
                    current = current.getGreater();
                }
            }
        }
        
        protected void addTreeToBranch(ExpirationTreeNode parent, boolean parentLesser, final ExpirationTreeNode toAdd) {
            if (toAdd == null) {
                return;
            }
            final long expTime = toAdd.getExpirationTime();
            ExpirationTreeNode current;
            if (parent == null) {
                current = this.root;
            }
            else if (parentLesser) {
                current = parent.getLesser();
            }
            else {
                current = parent.getGreater();
            }
            while (current != null) {
                final long nodeExpTime = current.getExpirationTime();
                if (expTime < nodeExpTime) {
                    parent = current;
                    parentLesser = true;
                    current = current.getLesser();
                }
                else {
                    parent = current;
                    parentLesser = false;
                    current = current.getGreater();
                }
            }
            this.setPointer(parent, parentLesser, toAdd);
        }
        
        public void addEntry(final ObjectRecord x) {
            final long expTime = x.getExpirationTime();
            ExpirationTreeNode previousNode = null;
            boolean lesser = false;
            ExpirationTreeNode current = this.root;
            while (current != null) {
                final long nodeExpTime = current.getExpirationTime();
                if (nodeExpTime == expTime) {
                    current.addObjectRecord(x);
                    return;
                }
                if (nodeExpTime > expTime) {
                    previousNode = current;
                    lesser = true;
                    current = current.getLesser();
                }
                else {
                    previousNode = current;
                    lesser = false;
                    current = current.getGreater();
                }
            }
            final ExpirationTreeNode newNode = new ExpirationTreeNode(x);
            this.setPointer(previousNode, lesser, newNode);
        }
        
        protected void setPointer(final ExpirationTreeNode parent, final boolean isLesser, final ExpirationTreeNode toAdd) {
            if (parent == null) {
                this.root = toAdd;
            }
            else if (isLesser) {
                parent.setLesser(toAdd);
            }
            else {
                parent.setGreater(toAdd);
            }
        }
        
        public ObjectRecord getOldestEntry() {
            ExpirationTreeNode current = this.root;
            ExpirationTreeNode last = null;
            while (current != null) {
                last = current;
                current = current.getLesser();
            }
            if (last == null) {
                return null;
            }
            return last.getOldest();
        }
    }
    
    protected class ExpirationTreeNode
    {
        protected ExpirationTreeNode lesser;
        protected ExpirationTreeNode greater;
        protected ObjectRecord firstSame;
        protected ObjectRecord lastSame;
        
        public ExpirationTreeNode(final ObjectRecord record) {
            this.lesser = null;
            this.greater = null;
            this.firstSame = null;
            this.lastSame = null;
            this.firstSame = record;
            this.lastSame = record;
        }
        
        public long getExpirationTime() {
            return this.firstSame.getExpirationTime();
        }
        
        public ExpirationTreeNode getLesser() {
            return this.lesser;
        }
        
        public void setLesser(final ExpirationTreeNode lesser) {
            this.lesser = lesser;
        }
        
        public ExpirationTreeNode getGreater() {
            return this.greater;
        }
        
        public void setGreater(final ExpirationTreeNode greater) {
            this.greater = greater;
        }
        
        public void addObjectRecord(final ObjectRecord x) {
            x.setSameExpirationNext(this.firstSame);
            this.firstSame.setSameExpirationPrev(x);
            this.firstSame = x;
        }
        
        public boolean removeObjectRecord(final ObjectRecord x) {
            final ObjectRecord prev = x.getSameExpirationPrev();
            final ObjectRecord next = x.getSameExpirationNext();
            if (prev == null) {
                this.firstSame = next;
            }
            else {
                prev.setSameExpirationNext(next);
            }
            if (next == null) {
                this.lastSame = prev;
            }
            else {
                next.setSameExpirationPrev(prev);
            }
            x.setSameExpirationPrev(null);
            x.setSameExpirationNext(null);
            return this.firstSame == null;
        }
        
        public ObjectRecord getOldest() {
            return this.lastSame;
        }
    }
}
