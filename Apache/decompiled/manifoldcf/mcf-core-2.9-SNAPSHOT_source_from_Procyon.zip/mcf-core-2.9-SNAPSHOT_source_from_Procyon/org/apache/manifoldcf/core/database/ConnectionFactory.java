// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import org.apache.manifoldcf.core.system.Logging;
import java.sql.Connection;
import java.util.Iterator;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.jdbcpool.ConnectionPool;
import org.apache.manifoldcf.core.jdbcpool.ConnectionPoolManager;
import java.sql.SQLException;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.jdbcpool.WrappedConnection;
import java.util.HashMap;

public class ConnectionFactory
{
    public static final String _rcsid = "@(#)$Id: ConnectionFactory.java 988245 2010-08-23 18:39:35Z kwright $";
    private static HashMap checkedOutConnections;
    private static PoolManager poolManager;
    
    private ConnectionFactory() {
    }
    
    public static WrappedConnection getConnection(final String jdbcUrl, final String jdbcDriver, final String database, final String userName, final String password, final int maxDBConnections, final boolean debug) throws ManifoldCFException {
        try {
            Class.forName(jdbcDriver);
        }
        catch (Exception e) {
            throw new ManifoldCFException("Unable to load database driver: " + e.getMessage(), e, 3);
        }
        final ConnectionPoolManager cpm = ConnectionFactory.poolManager.createPoolManager(debug);
        try {
            ConnectionPool cp = cpm.getPool(database);
            if (cp == null) {
                cpm.addAlias(database, jdbcDriver, jdbcUrl, userName, password, maxDBConnections, 300000L);
                cp = cpm.getPool(database);
            }
            return getConnectionWithRetries(cp);
        }
        catch (InterruptedException e2) {
            throw new ManifoldCFException("Interrupted: " + e2.getMessage(), e2, 2);
        }
        catch (SQLException e3) {
            throw new ManifoldCFException("Error getting connection: " + e3.getMessage(), e3, 4);
        }
        catch (ClassNotFoundException e4) {
            throw new ManifoldCFException("Fatal error getting connection: " + e4.getMessage(), e4, 3);
        }
        catch (InstantiationException e5) {
            throw new ManifoldCFException("Fatal error getting connection: " + e5.getMessage(), e5, 3);
        }
        catch (IllegalAccessException e6) {
            throw new ManifoldCFException("Fatal error getting connection: " + e6.getMessage(), e6, 3);
        }
    }
    
    public static void releaseConnection(final WrappedConnection c) throws ManifoldCFException {
        c.release();
    }
    
    public static void flush() {
        if (ConnectionFactory.poolManager != null) {
            ConnectionFactory.poolManager.flush();
        }
    }
    
    public static void releaseAll() {
        if (ConnectionFactory.poolManager != null) {
            ConnectionFactory.poolManager.releaseAll();
        }
    }
    
    protected static WrappedConnection getConnectionWithRetries(final ConnectionPool cp) throws SQLException, InterruptedException {
        int retryCount = 3;
        try {
            return cp.getConnection();
        }
        catch (SQLException e) {
            if (retryCount == 0) {
                throw e;
            }
            --retryCount;
            ManifoldCF.sleep(10000L);
            return cp.getConnection();
        }
    }
    
    protected static void checkConnections(final long currentTime) {
        synchronized (ConnectionFactory.checkedOutConnections) {
            for (final Object key : ConnectionFactory.checkedOutConnections.keySet()) {
                final ConnectionTracker ct = ConnectionFactory.checkedOutConnections.get(key);
                if (ct.hasExpired(currentTime)) {
                    ct.printDetails();
                }
            }
        }
    }
    
    static {
        ConnectionFactory.checkedOutConnections = new HashMap();
        ConnectionFactory.poolManager = new PoolManager();
    }
    
    protected static class PoolManager
    {
        private Integer poolExistenceLock;
        private ConnectionPoolManager _pool;
        
        private PoolManager() {
            this.poolExistenceLock = new Integer(0);
            this._pool = null;
        }
        
        public ConnectionPoolManager createPoolManager(final boolean debug) throws ManifoldCFException {
            synchronized (this.poolExistenceLock) {
                if (this._pool != null) {
                    return this._pool;
                }
                return this._pool = new ConnectionPoolManager(100, debug);
            }
        }
        
        public void releaseAll() {
            final ConnectionPoolManager thisPool;
            synchronized (this.poolExistenceLock) {
                if (this._pool == null) {
                    return;
                }
                thisPool = this._pool;
                this._pool = null;
            }
            thisPool.shutdown();
        }
        
        public void flush() {
            synchronized (this.poolExistenceLock) {
                if (this._pool != null) {
                    this._pool.flush();
                }
            }
        }
    }
    
    protected static class ConnectionTracker
    {
        protected Connection theConnection;
        protected long checkoutTime;
        protected Exception theTrace;
        
        public ConnectionTracker(final Connection theConnection) {
            this.theConnection = theConnection;
            this.checkoutTime = System.currentTimeMillis();
            this.theTrace = new Exception("Stack trace");
        }
        
        public boolean hasExpired(final long currentTime) {
            return this.checkoutTime + 300000L < currentTime;
        }
        
        public void printDetails() {
            Logging.db.error((Object)("Connection handle may have been abandoned: " + this.theConnection.toString()), (Throwable)this.theTrace);
        }
    }
}
