// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.LockException;
import org.apache.manifoldcf.core.system.Logging;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.interfaces.ManifoldCFConfiguration;
import java.nio.charset.StandardCharsets;
import org.apache.manifoldcf.core.interfaces.IServiceDataAcceptor;
import org.apache.manifoldcf.core.interfaces.IServiceCleanup;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.util.Map;
import org.apache.manifoldcf.core.interfaces.ILockManager;

public class BaseLockManager implements ILockManager
{
    public static final String _rcsid = "@(#)$Id: LockManager.java 988245 2010-08-23 18:39:35Z kwright $";
    protected static final int TYPE_READ = 1;
    protected static final int TYPE_WRITENONEX = 2;
    protected static final int TYPE_WRITE = 3;
    protected final Long threadID;
    protected final LocalLockPool localLocks;
    protected static final LockPool myLocks;
    protected final LocalLockPool localSections;
    protected static final LockPool mySections;
    protected static final Map<String, Boolean> globalFlags;
    protected static final Map<String, byte[]> globalData;
    protected static final String serviceTypeLockPrefix = "_SERVICELOCK_";
    protected static final String serviceListPrefix = "_SERVICELIST_";
    protected static final String servicePrefix = "_SERVICE_";
    protected static final String activePrefix = "_ACTIVE_";
    protected static final String serviceDataPrefix = "_SERVICEDATA_";
    protected static final String anonymousServiceNamePrefix = "_ANON_";
    protected static final String anonymousServiceTypeCounter = "_SERVICECOUNTER_";
    
    public BaseLockManager() throws ManifoldCFException {
        this.localLocks = new LocalLockPool();
        this.localSections = new LocalLockPool();
        this.threadID = new Long(Thread.currentThread().getId());
    }
    
    @Override
    public String registerServiceBeginServiceActivity(final String serviceType, final String serviceName, final IServiceCleanup cleanup) throws ManifoldCFException {
        return this.registerServiceBeginServiceActivity(serviceType, serviceName, null, cleanup);
    }
    
    @Override
    public String registerServiceBeginServiceActivity(final String serviceType, String serviceName, final byte[] initialData, final IServiceCleanup cleanup) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterWriteLock(serviceTypeLockName);
        try {
            if (serviceName == null) {
                serviceName = this.constructUniqueServiceName(serviceType);
            }
            final String serviceActiveFlag = makeActiveServiceFlagName(serviceType, serviceName);
            if (this.checkGlobalFlag(serviceActiveFlag)) {
                throw new ManifoldCFException("Service '" + serviceName + "' of type '" + serviceType + "' is already active");
            }
            boolean foundService = false;
            boolean foundActiveService = false;
            int i = 0;
            String resourceName;
            while (true) {
                resourceName = buildServiceListEntry(serviceType, i);
                final String x = this.readServiceName(resourceName);
                if (x == null) {
                    break;
                }
                if (x.equals(serviceName)) {
                    foundService = true;
                }
                else if (this.checkGlobalFlag(makeActiveServiceFlagName(serviceType, x))) {
                    foundActiveService = true;
                }
                ++i;
            }
            boolean unregisterAll = false;
            if (cleanup != null) {
                if (i == 0) {
                    cleanup.cleanUpAllServices();
                    cleanup.clusterInit();
                }
                else if (foundService && foundActiveService) {
                    cleanup.cleanUpService(serviceName);
                }
                else if (!foundActiveService) {
                    cleanup.cleanUpAllServices();
                    cleanup.clusterInit();
                    unregisterAll = true;
                }
            }
            if (unregisterAll) {
                int k = i;
                while (k > 0) {
                    --k;
                    resourceName = buildServiceListEntry(serviceType, k);
                    final String x2 = this.readServiceName(resourceName);
                    this.clearGlobalFlag(makeRegisteredServiceFlagName(serviceType, x2));
                    this.writeServiceName(resourceName, null);
                }
                foundService = false;
            }
            if (!foundService) {
                this.writeServiceName(resourceName, serviceName);
                try {
                    this.setGlobalFlag(makeRegisteredServiceFlagName(serviceType, serviceName));
                }
                catch (Throwable e) {
                    this.writeServiceName(resourceName, null);
                    if (e instanceof Error) {
                        throw (Error)e;
                    }
                    if (e instanceof RuntimeException) {
                        throw (RuntimeException)e;
                    }
                    if (e instanceof ManifoldCFException) {
                        throw (ManifoldCFException)e;
                    }
                    throw new RuntimeException("Unknown exception of type: " + e.getClass().getName() + ": " + e.getMessage(), e);
                }
            }
            this.setGlobalFlag(serviceActiveFlag);
            this.writeServiceData(serviceType, serviceName, initialData);
            return serviceName;
        }
        finally {
            this.leaveWriteLock(serviceTypeLockName);
        }
    }
    
    @Override
    public void updateServiceData(final String serviceType, final String serviceName, final byte[] serviceData) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterWriteLock(serviceTypeLockName);
        try {
            final String serviceActiveFlag = makeActiveServiceFlagName(serviceType, serviceName);
            if (!this.checkGlobalFlag(serviceActiveFlag)) {
                throw new ManifoldCFException("Service '" + serviceName + "' of type '" + serviceType + "' is not active");
            }
            this.writeServiceData(serviceType, serviceName, serviceData);
        }
        finally {
            this.leaveWriteLock(serviceTypeLockName);
        }
    }
    
    @Override
    public byte[] retrieveServiceData(final String serviceType, final String serviceName) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterReadLock(serviceTypeLockName);
        try {
            final String serviceActiveFlag = makeActiveServiceFlagName(serviceType, serviceName);
            if (!this.checkGlobalFlag(serviceActiveFlag)) {
                return null;
            }
            byte[] rval = this.readServiceData(serviceType, serviceName);
            if (rval == null) {
                rval = new byte[0];
            }
            return rval;
        }
        finally {
            this.leaveReadLock(serviceTypeLockName);
        }
    }
    
    @Override
    public void scanServiceData(final String serviceType, final IServiceDataAcceptor dataAcceptor) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterReadLock(serviceTypeLockName);
        try {
            int i = 0;
            while (true) {
                final String resourceName = buildServiceListEntry(serviceType, i);
                final String x = this.readServiceName(resourceName);
                if (x == null) {
                    break;
                }
                if (this.checkGlobalFlag(makeActiveServiceFlagName(serviceType, x))) {
                    final byte[] serviceData = this.readServiceData(serviceType, x);
                    if (dataAcceptor.acceptServiceData(x, serviceData)) {
                        break;
                    }
                }
                ++i;
            }
        }
        finally {
            this.leaveReadLock(serviceTypeLockName);
        }
    }
    
    @Override
    public int countActiveServices(final String serviceType) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterReadLock(serviceTypeLockName);
        try {
            int count = 0;
            int i = 0;
            while (true) {
                final String resourceName = buildServiceListEntry(serviceType, i);
                final String x = this.readServiceName(resourceName);
                if (x == null) {
                    break;
                }
                if (this.checkGlobalFlag(makeActiveServiceFlagName(serviceType, x))) {
                    ++count;
                }
                ++i;
            }
            return count;
        }
        finally {
            this.leaveReadLock(serviceTypeLockName);
        }
    }
    
    @Override
    public boolean cleanupInactiveService(final String serviceType, final IServiceCleanup cleanup) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterWriteLock(serviceTypeLockName);
        try {
            int i = 0;
            while (true) {
                final String resourceName = buildServiceListEntry(serviceType, i);
                final String serviceName = this.readServiceName(resourceName);
                if (serviceName == null) {
                    return true;
                }
                if (!this.checkGlobalFlag(makeActiveServiceFlagName(serviceType, serviceName))) {
                    cleanup.cleanUpService(serviceName);
                    final String serviceRegisteredFlag = makeRegisteredServiceFlagName(serviceType, serviceName);
                    int k = i + 1;
                    String lastResourceName = null;
                    String lastServiceName = null;
                    while (true) {
                        final String rName = buildServiceListEntry(serviceType, k);
                        final String x = this.readServiceName(rName);
                        if (x == null) {
                            break;
                        }
                        lastResourceName = rName;
                        lastServiceName = x;
                        ++k;
                    }
                    this.clearGlobalFlag(serviceRegisteredFlag);
                    if (lastServiceName != null) {
                        this.writeServiceName(resourceName, lastServiceName);
                    }
                    this.writeServiceName(lastResourceName, null);
                    return false;
                }
                ++i;
            }
        }
        finally {
            this.leaveWriteLock(serviceTypeLockName);
        }
    }
    
    @Override
    public void endServiceActivity(final String serviceType, final String serviceName) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterWriteLock(serviceTypeLockName);
        try {
            final String serviceActiveFlag = makeActiveServiceFlagName(serviceType, serviceName);
            if (!this.checkGlobalFlag(serviceActiveFlag)) {
                throw new ManifoldCFException("Service '" + serviceName + "' of type '" + serviceType + " is not active");
            }
            this.deleteServiceData(serviceType, serviceName);
            this.clearGlobalFlag(serviceActiveFlag);
        }
        finally {
            this.leaveWriteLock(serviceTypeLockName);
        }
    }
    
    @Override
    public boolean checkServiceActive(final String serviceType, final String serviceName) throws ManifoldCFException {
        final String serviceTypeLockName = buildServiceTypeLockName(serviceType);
        this.enterReadLock(serviceTypeLockName);
        try {
            return this.checkGlobalFlag(makeActiveServiceFlagName(serviceType, serviceName));
        }
        finally {
            this.leaveReadLock(serviceTypeLockName);
        }
    }
    
    protected String constructUniqueServiceName(final String serviceType) throws ManifoldCFException {
        final String serviceCounterName = makeServiceCounterName(serviceType);
        final int serviceUID = this.readServiceCounter(serviceCounterName);
        this.writeServiceCounter(serviceCounterName, serviceUID + 1);
        return "_ANON_" + serviceUID;
    }
    
    protected static String makeServiceCounterName(final String serviceType) {
        return "_SERVICECOUNTER_" + serviceType;
    }
    
    protected int readServiceCounter(final String serviceCounterName) throws ManifoldCFException {
        final byte[] serviceCounterData = this.readData(serviceCounterName);
        if (serviceCounterData == null || serviceCounterData.length != 4) {
            return 0;
        }
        return (serviceCounterData[0] & 0xFF) + (serviceCounterData[1] << 8 & 0xFF00) + (serviceCounterData[2] << 16 & 0xFF0000) + (serviceCounterData[3] << 24 & 0xFF000000);
    }
    
    protected void writeServiceCounter(final String serviceCounterName, final int counter) throws ManifoldCFException {
        final byte[] serviceCounterData = { (byte)(counter & 0xFF), (byte)(counter >> 8 & 0xFF), (byte)(counter >> 16 & 0xFF), (byte)(counter >> 24 & 0xFF) };
        this.writeData(serviceCounterName, serviceCounterData);
    }
    
    protected void writeServiceData(final String serviceType, final String serviceName, final byte[] serviceData) throws ManifoldCFException {
        this.writeData(makeServiceDataName(serviceType, serviceName), serviceData);
    }
    
    protected byte[] readServiceData(final String serviceType, final String serviceName) throws ManifoldCFException {
        return this.readData(makeServiceDataName(serviceType, serviceName));
    }
    
    protected void deleteServiceData(final String serviceType, final String serviceName) throws ManifoldCFException {
        this.writeServiceData(serviceType, serviceName, null);
    }
    
    protected static String makeServiceDataName(final String serviceType, final String serviceName) {
        return "_SERVICEDATA_" + serviceType + "_" + serviceName;
    }
    
    protected static String makeActiveServiceFlagName(final String serviceType, final String serviceName) {
        return "_ACTIVE_" + serviceType + "_" + serviceName;
    }
    
    protected static String makeRegisteredServiceFlagName(final String serviceType, final String serviceName) {
        return "_SERVICE_" + serviceType + "_" + serviceName;
    }
    
    protected String readServiceName(final String resourceName) throws ManifoldCFException {
        final byte[] bytes = this.readData(resourceName);
        if (bytes == null) {
            return null;
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
    
    protected void writeServiceName(final String resourceName, final String serviceName) throws ManifoldCFException {
        this.writeData(resourceName, (byte[])((serviceName == null) ? null : serviceName.getBytes(StandardCharsets.UTF_8)));
    }
    
    protected static String buildServiceListEntry(final String serviceType, final int i) {
        return "_SERVICELIST_" + serviceType + "_" + i;
    }
    
    protected static String buildServiceTypeLockName(final String serviceType) {
        return "_SERVICELOCK_" + serviceType;
    }
    
    @Override
    public ManifoldCFConfiguration getSharedConfiguration() throws ManifoldCFException {
        return ManifoldCF.getConfiguration();
    }
    
    @Override
    public void setGlobalFlag(final String flagName) throws ManifoldCFException {
        synchronized (BaseLockManager.globalFlags) {
            BaseLockManager.globalFlags.put(flagName, new Boolean(true));
        }
    }
    
    @Override
    public void clearGlobalFlag(final String flagName) throws ManifoldCFException {
        synchronized (BaseLockManager.globalFlags) {
            BaseLockManager.globalFlags.remove(flagName);
        }
    }
    
    @Override
    public boolean checkGlobalFlag(final String flagName) throws ManifoldCFException {
        synchronized (BaseLockManager.globalFlags) {
            return BaseLockManager.globalFlags.get(flagName) != null;
        }
    }
    
    @Override
    public byte[] readData(final String resourceName) throws ManifoldCFException {
        synchronized (BaseLockManager.globalData) {
            return BaseLockManager.globalData.get(resourceName);
        }
    }
    
    @Override
    public void writeData(final String resourceName, final byte[] data) throws ManifoldCFException {
        synchronized (BaseLockManager.globalData) {
            if (data == null) {
                BaseLockManager.globalData.remove(resourceName);
            }
            else {
                BaseLockManager.globalData.put(resourceName, data);
            }
        }
    }
    
    @Override
    public final void timedWait(final int time) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Waiting for time " + Integer.toString(time)));
        }
        try {
            ManifoldCF.sleep(time);
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException("Interrupted", e, 2);
        }
    }
    
    protected LockPool getGlobalLockPool() {
        return BaseLockManager.myLocks;
    }
    
    @Override
    public final void enterNonExWriteLock(final String lockKey) throws ManifoldCFException {
        enterNonExWrite(this.threadID, lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterNonExWriteLockNoWait(final String lockKey) throws ManifoldCFException, LockException {
        enterNonExWriteNoWait(this.threadID, lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void leaveNonExWriteLock(final String lockKey) throws ManifoldCFException {
        leaveNonExWrite(lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterWriteLock(final String lockKey) throws ManifoldCFException {
        enterWrite(this.threadID, lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterWriteLockNoWait(final String lockKey) throws ManifoldCFException, LockException {
        enterWriteNoWait(this.threadID, lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void leaveWriteLock(final String lockKey) throws ManifoldCFException {
        leaveWrite(lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterReadLock(final String lockKey) throws ManifoldCFException {
        enterRead(this.threadID, lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterReadLockNoWait(final String lockKey) throws ManifoldCFException, LockException {
        enterReadNoWait(this.threadID, lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void leaveReadLock(final String lockKey) throws ManifoldCFException {
        leaveRead(lockKey, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterLocks(final String[] readLocks, final String[] nonExWriteLocks, final String[] writeLocks) throws ManifoldCFException {
        enter(this.threadID, readLocks, nonExWriteLocks, writeLocks, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterLocksNoWait(final String[] readLocks, final String[] nonExWriteLocks, final String[] writeLocks) throws ManifoldCFException, LockException {
        enterNoWait(this.threadID, readLocks, nonExWriteLocks, writeLocks, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void leaveLocks(final String[] readLocks, final String[] writeNonExLocks, final String[] writeLocks) throws ManifoldCFException {
        leave(readLocks, writeNonExLocks, writeLocks, "lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void clearLocks() throws ManifoldCFException {
        clear("lock", this.localLocks, this.getGlobalLockPool());
    }
    
    @Override
    public final void enterReadCriticalSection(final String sectionKey) throws ManifoldCFException {
        enterRead(this.threadID, sectionKey, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    @Override
    public final void leaveReadCriticalSection(final String sectionKey) throws ManifoldCFException {
        leaveRead(sectionKey, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    @Override
    public final void enterNonExWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        enterNonExWrite(this.threadID, sectionKey, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    @Override
    public final void leaveNonExWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        leaveNonExWrite(sectionKey, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    @Override
    public final void enterWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        enterWrite(this.threadID, sectionKey, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    @Override
    public final void leaveWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        leaveWrite(sectionKey, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    @Override
    public final void enterCriticalSections(final String[] readSectionKeys, final String[] nonExSectionKeys, final String[] writeSectionKeys) throws ManifoldCFException {
        enter(this.threadID, readSectionKeys, nonExSectionKeys, writeSectionKeys, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    @Override
    public final void leaveCriticalSections(final String[] readSectionKeys, final String[] nonExSectionKeys, final String[] writeSectionKeys) throws ManifoldCFException {
        leave(readSectionKeys, nonExSectionKeys, writeSectionKeys, "critical section", this.localSections, BaseLockManager.mySections);
    }
    
    protected static void enterNonExWrite(final Long threadID, final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering non-ex write " + description + " '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        if (ll.hasNonExWriteLock() || ll.hasWriteLock()) {
            ll.incrementNonExWriteLocks();
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
            }
            return;
        }
        if (ll.hasReadLock()) {
            throw new ManifoldCFException("Illegal " + description + " sequence: NonExWrite " + description + " can't be within read " + description, 0);
        }
        while (true) {
            final LockGate lo = crossLocks.getObject(lockKey);
            try {
                lo.enterNonExWriteLock(threadID);
            }
            catch (InterruptedException e) {
                throw new ManifoldCFException("Interrupted", e, 2);
            }
            catch (ExpiredObjectException ex) {
                continue;
            }
            break;
        }
        ll.incrementNonExWriteLocks();
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
        }
    }
    
    protected static void enterNonExWriteNoWait(final Long threadID, final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException, LockException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering non-ex write " + description + " no wait '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        if (ll.hasNonExWriteLock() || ll.hasWriteLock()) {
            ll.incrementNonExWriteLocks();
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
            }
            return;
        }
        if (ll.hasReadLock()) {
            throw new ManifoldCFException("Illegal " + description + " sequence: NonExWrite " + description + " can't be within read " + description, 0);
        }
        while (true) {
            final LockGate lo = crossLocks.getObject(lockKey);
            try {
                synchronized (lo) {
                    lo.enterNonExWriteLockNoWait(threadID);
                }
            }
            catch (LocalLockException e) {
                if (Logging.lock.isDebugEnabled()) {
                    Logging.lock.debug((Object)(" Could not non-ex write " + description + " '" + lockKey + "', lock exception"));
                }
                throw new LockException(e.getMessage());
            }
            catch (InterruptedException e2) {
                throw new ManifoldCFException("Interrupted", e2, 2);
            }
            catch (ExpiredObjectException ex) {
                continue;
            }
            break;
        }
        ll.incrementNonExWriteLocks();
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
        }
    }
    
    protected static void leaveNonExWrite(final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Leaving non-ex write " + description + " '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        ll.decrementNonExWriteLocks();
        if (!ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
            while (true) {
                final LockGate lo = crossLocks.getObject(lockKey);
                try {
                    lo.leaveNonExWriteLock();
                }
                catch (InterruptedException e) {
                    try {
                        lo.leaveNonExWriteLock();
                        throw new ManifoldCFException("Interrupted", e, 2);
                    }
                    catch (InterruptedException e2) {
                        ll.incrementNonExWriteLocks();
                        throw new ManifoldCFException("Interrupted", e2, 2);
                    }
                    catch (ExpiredObjectException e3) {
                        ll.incrementNonExWriteLocks();
                        throw new ManifoldCFException("Interrupted", e, 2);
                    }
                }
                catch (ExpiredObjectException ex) {
                    continue;
                }
                break;
            }
            localLocks.releaseLocalLock(lockKey);
        }
    }
    
    protected static void enterWrite(final Long threadID, final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering write " + description + " '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        if (ll.hasWriteLock()) {
            ll.incrementWriteLocks();
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
            }
            return;
        }
        if (ll.hasReadLock() || ll.hasNonExWriteLock()) {
            throw new ManifoldCFException("Illegal " + description + " sequence: Write " + description + " can't be within read " + description + " or non-ex write " + description, 0);
        }
        while (true) {
            final LockGate lo = crossLocks.getObject(lockKey);
            try {
                lo.enterWriteLock(threadID);
            }
            catch (InterruptedException e) {
                throw new ManifoldCFException("Interrupted", e, 2);
            }
            catch (ExpiredObjectException ex) {
                continue;
            }
            break;
        }
        ll.incrementWriteLocks();
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
        }
    }
    
    protected static void enterWriteNoWait(final Long threadID, final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException, LockException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering write " + description + " no wait '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        if (ll.hasWriteLock()) {
            ll.incrementWriteLocks();
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
            }
            return;
        }
        if (ll.hasReadLock() || ll.hasNonExWriteLock()) {
            throw new ManifoldCFException("Illegal " + description + " sequence: Write " + description + " can't be within read " + description + " or non-ex write " + description, 0);
        }
        while (true) {
            final LockGate lo = crossLocks.getObject(lockKey);
            try {
                synchronized (lo) {
                    lo.enterWriteLockNoWait(threadID);
                }
            }
            catch (LocalLockException e) {
                if (Logging.lock.isDebugEnabled()) {
                    Logging.lock.debug((Object)(" Could not write " + description + " '" + lockKey + "', lock exception"));
                }
                throw new LockException(e.getMessage());
            }
            catch (InterruptedException e2) {
                throw new ManifoldCFException("Interrupted", e2, 2);
            }
            catch (ExpiredObjectException ex) {
                continue;
            }
            break;
        }
        ll.incrementWriteLocks();
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
        }
    }
    
    protected static void leaveWrite(final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Leaving write " + description + " '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        ll.decrementWriteLocks();
        if (!ll.hasWriteLock()) {
            while (true) {
                final LockGate lo = crossLocks.getObject(lockKey);
                try {
                    lo.leaveWriteLock();
                }
                catch (InterruptedException e) {
                    try {
                        lo.leaveWriteLock();
                        throw new ManifoldCFException("Interrupted", e, 2);
                    }
                    catch (InterruptedException e2) {
                        ll.incrementWriteLocks();
                        throw new ManifoldCFException("Interrupted", e2, 2);
                    }
                    catch (ExpiredObjectException e3) {
                        ll.incrementWriteLocks();
                        throw new ManifoldCFException("Interrupted", e, 2);
                    }
                }
                catch (ExpiredObjectException ex) {
                    continue;
                }
                break;
            }
            localLocks.releaseLocalLock(lockKey);
        }
    }
    
    protected static void enterRead(final Long threadID, final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering read " + description + " '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        if (ll.hasReadLock() || ll.hasNonExWriteLock() || ll.hasWriteLock()) {
            ll.incrementReadLocks();
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
            }
            return;
        }
        while (true) {
            final LockGate lo = crossLocks.getObject(lockKey);
            try {
                lo.enterReadLock(threadID);
            }
            catch (InterruptedException e) {
                throw new ManifoldCFException("Interrupted", e, 2);
            }
            catch (ExpiredObjectException ex) {
                continue;
            }
            break;
        }
        ll.incrementReadLocks();
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
        }
    }
    
    protected static void enterReadNoWait(final Long threadID, final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException, LockException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering read " + description + " no wait '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        if (ll.hasReadLock() || ll.hasNonExWriteLock() || ll.hasWriteLock()) {
            ll.incrementReadLocks();
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
            }
            return;
        }
        while (true) {
            final LockGate lo = crossLocks.getObject(lockKey);
            try {
                synchronized (lo) {
                    lo.enterReadLockNoWait(threadID);
                }
            }
            catch (LocalLockException e) {
                if (Logging.lock.isDebugEnabled()) {
                    Logging.lock.debug((Object)(" Could not read " + description + " '" + lockKey + "', lock exception"));
                }
                throw new LockException(e.getMessage());
            }
            catch (InterruptedException e2) {
                throw new ManifoldCFException("Interrupted", e2, 2);
            }
            catch (ExpiredObjectException ex) {
                continue;
            }
            break;
        }
        ll.incrementReadLocks();
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)(" Successfully obtained " + description + "!"));
        }
    }
    
    protected static void leaveRead(final String lockKey, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Leaving read " + description + " '" + lockKey + "'"));
        }
        final LocalLock ll = localLocks.getLocalLock(lockKey);
        ll.decrementReadLocks();
        if (!ll.hasReadLock() && !ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
            while (true) {
                final LockGate lo = crossLocks.getObject(lockKey);
                try {
                    lo.leaveReadLock();
                }
                catch (InterruptedException e) {
                    try {
                        lo.leaveReadLock();
                        throw new ManifoldCFException("Interrupted", e, 2);
                    }
                    catch (InterruptedException e2) {
                        ll.incrementReadLocks();
                        throw new ManifoldCFException("Interrupted", e2, 2);
                    }
                    catch (ExpiredObjectException e3) {
                        ll.incrementReadLocks();
                        throw new ManifoldCFException("Interrupted", e, 2);
                    }
                }
                catch (ExpiredObjectException ex) {
                    continue;
                }
                break;
            }
            localLocks.releaseLocalLock(lockKey);
        }
    }
    
    protected static void clear(final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Clearing all " + description + "s"));
        }
        for (final String keyValue : localLocks.keySet()) {
            final LocalLock ll = localLocks.getLocalLock(keyValue);
            while (ll.hasWriteLock()) {
                leaveWrite(keyValue, description, localLocks, crossLocks);
            }
            while (ll.hasNonExWriteLock()) {
                leaveNonExWrite(keyValue, description, localLocks, crossLocks);
            }
            while (ll.hasReadLock()) {
                leaveRead(keyValue, description, localLocks, crossLocks);
            }
        }
    }
    
    protected static void enter(final Long threadID, final String[] readLocks, final String[] nonExWriteLocks, final String[] writeLocks, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering multiple " + description + "s:"));
            if (readLocks != null) {
                int i = 0;
                while (i < readLocks.length) {
                    Logging.lock.debug((Object)(" Read " + description + " '" + readLocks[i++] + "'"));
                }
            }
            if (nonExWriteLocks != null) {
                int i = 0;
                while (i < nonExWriteLocks.length) {
                    Logging.lock.debug((Object)(" Non-ex write " + description + " '" + nonExWriteLocks[i++] + "'"));
                }
            }
            if (writeLocks != null) {
                int i = 0;
                while (i < writeLocks.length) {
                    Logging.lock.debug((Object)(" Write " + description + " '" + writeLocks[i++] + "'"));
                }
            }
        }
        final LockDescription[] lds = getSortedUniqueLocks(readLocks, nonExWriteLocks, writeLocks);
        int locksProcessed = 0;
        try {
            while (locksProcessed < lds.length) {
                final LockDescription ld = lds[locksProcessed];
                final int lockType = ld.getType();
                final String lockKey = ld.getKey();
                switch (lockType) {
                    case 3: {
                        final LocalLock ll = localLocks.getLocalLock(lockKey);
                        if ((ll.hasReadLock() || ll.hasNonExWriteLock()) && !ll.hasWriteLock()) {
                            throw new ManifoldCFException("Illegal " + description + " sequence: Write " + description + " can't be within read " + description + " or non-ex write " + description, 0);
                        }
                        if (!ll.hasWriteLock()) {
                            while (true) {
                                final LockGate lo = crossLocks.getObject(lockKey);
                                try {
                                    lo.enterWriteLock(threadID);
                                }
                                catch (ExpiredObjectException ex2) {
                                    continue;
                                }
                                break;
                            }
                        }
                        ll.incrementWriteLocks();
                        break;
                    }
                    case 2: {
                        final LocalLock ll = localLocks.getLocalLock(lockKey);
                        if (ll.hasReadLock() && !ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
                            throw new ManifoldCFException("Illegal " + description + " sequence: NonExWrite " + description + " can't be within read " + description, 0);
                        }
                        if (!ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
                            while (true) {
                                final LockGate lo = crossLocks.getObject(lockKey);
                                try {
                                    lo.enterNonExWriteLock(threadID);
                                }
                                catch (ExpiredObjectException ex3) {
                                    continue;
                                }
                                break;
                            }
                        }
                        ll.incrementNonExWriteLocks();
                        break;
                    }
                    case 1: {
                        final LocalLock ll = localLocks.getLocalLock(lockKey);
                        if (!ll.hasReadLock() && !ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
                            while (true) {
                                final LockGate lo = crossLocks.getObject(lockKey);
                                try {
                                    lo.enterReadLock(threadID);
                                }
                                catch (ExpiredObjectException ex4) {
                                    continue;
                                }
                                break;
                            }
                        }
                        ll.incrementReadLocks();
                        break;
                    }
                }
                ++locksProcessed;
            }
            Logging.lock.debug((Object)(" Successfully obtained multiple " + description + "s!"));
        }
        catch (Throwable ex) {
            ManifoldCFException ae = null;
            final int errno = 0;
            while (--locksProcessed >= 0) {
                final LockDescription ld2 = lds[locksProcessed];
                final int lockType2 = ld2.getType();
                final String lockKey2 = ld2.getKey();
                try {
                    switch (lockType2) {
                        case 1: {
                            leaveRead(lockKey2, description, localLocks, crossLocks);
                            continue;
                        }
                        case 2: {
                            leaveNonExWrite(lockKey2, description, localLocks, crossLocks);
                            continue;
                        }
                        case 3: {
                            leaveWrite(lockKey2, description, localLocks, crossLocks);
                            continue;
                        }
                    }
                }
                catch (ManifoldCFException e) {
                    ae = e;
                }
            }
            if (ae != null) {
                throw ae;
            }
            if (ex instanceof ManifoldCFException) {
                throw (ManifoldCFException)ex;
            }
            if (ex instanceof InterruptedException) {
                throw new ManifoldCFException("Interrupted", ex, 2);
            }
            if (!(ex instanceof Error)) {
                throw new Error("Unexpected exception", ex);
            }
            throw (Error)ex;
        }
    }
    
    protected static void enterNoWait(final Long threadID, final String[] readLocks, final String[] nonExWriteLocks, final String[] writeLocks, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException, LockException {
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Entering multiple " + description + "s no wait:"));
            if (readLocks != null) {
                int i = 0;
                while (i < readLocks.length) {
                    Logging.lock.debug((Object)(" Read " + description + " '" + readLocks[i++] + "'"));
                }
            }
            if (nonExWriteLocks != null) {
                int i = 0;
                while (i < nonExWriteLocks.length) {
                    Logging.lock.debug((Object)(" Non-ex write " + description + " '" + nonExWriteLocks[i++] + "'"));
                }
            }
            if (writeLocks != null) {
                int i = 0;
                while (i < writeLocks.length) {
                    Logging.lock.debug((Object)(" Write " + description + " '" + writeLocks[i++] + "'"));
                }
            }
        }
        final LockDescription[] lds = getSortedUniqueLocks(readLocks, nonExWriteLocks, writeLocks);
        int locksProcessed = 0;
        try {
            while (locksProcessed < lds.length) {
                final LockDescription ld = lds[locksProcessed];
                final int lockType = ld.getType();
                final String lockKey = ld.getKey();
                switch (lockType) {
                    case 3: {
                        final LocalLock ll = localLocks.getLocalLock(lockKey);
                        if ((ll.hasReadLock() || ll.hasNonExWriteLock()) && !ll.hasWriteLock()) {
                            throw new ManifoldCFException("Illegal " + description + " sequence: Write " + description + " can't be within read " + description + " or non-ex write " + description, 0);
                        }
                        if (!ll.hasWriteLock()) {
                            while (true) {
                                final LockGate lo = crossLocks.getObject(lockKey);
                                synchronized (lo) {
                                    try {
                                        lo.enterWriteLockNoWait(threadID);
                                        break;
                                    }
                                    catch (ExpiredObjectException ex2) {}
                                }
                            }
                        }
                        ll.incrementWriteLocks();
                        break;
                    }
                    case 2: {
                        final LocalLock ll = localLocks.getLocalLock(lockKey);
                        if (ll.hasReadLock() && !ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
                            throw new ManifoldCFException("Illegal " + description + " sequence: NonExWrite " + description + " can't be within read " + description, 0);
                        }
                        if (!ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
                            while (true) {
                                final LockGate lo = crossLocks.getObject(lockKey);
                                synchronized (lo) {
                                    try {
                                        lo.enterNonExWriteLockNoWait(threadID);
                                        break;
                                    }
                                    catch (ExpiredObjectException ex3) {}
                                }
                            }
                        }
                        ll.incrementNonExWriteLocks();
                        break;
                    }
                    case 1: {
                        final LocalLock ll = localLocks.getLocalLock(lockKey);
                        if (!ll.hasReadLock() && !ll.hasNonExWriteLock() && !ll.hasWriteLock()) {
                            while (true) {
                                final LockGate lo = crossLocks.getObject(lockKey);
                                synchronized (lo) {
                                    try {
                                        lo.enterReadLockNoWait(threadID);
                                        break;
                                    }
                                    catch (ExpiredObjectException ex4) {}
                                }
                            }
                        }
                        ll.incrementReadLocks();
                        break;
                    }
                }
                ++locksProcessed;
            }
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)(" Successfully obtained multiple " + description + "s!"));
            }
        }
        catch (Throwable ex) {
            ManifoldCFException ae = null;
            final int errno = 0;
            while (--locksProcessed >= 0) {
                final LockDescription ld2 = lds[locksProcessed];
                final int lockType2 = ld2.getType();
                final String lockKey2 = ld2.getKey();
                try {
                    switch (lockType2) {
                        case 1: {
                            leaveRead(lockKey2, description, localLocks, crossLocks);
                            continue;
                        }
                        case 2: {
                            leaveNonExWrite(lockKey2, description, localLocks, crossLocks);
                            continue;
                        }
                        case 3: {
                            leaveWrite(lockKey2, description, localLocks, crossLocks);
                            continue;
                        }
                    }
                }
                catch (ManifoldCFException e) {
                    ae = e;
                }
            }
            if (ae != null) {
                throw ae;
            }
            if (ex instanceof ManifoldCFException) {
                throw (ManifoldCFException)ex;
            }
            if (ex instanceof LockException || ex instanceof LocalLockException) {
                Logging.lock.debug((Object)(" Couldn't get " + description + "; throwing LockException"));
                throw new LockException(ex.getMessage());
            }
            if (ex instanceof InterruptedException) {
                throw new ManifoldCFException("Interrupted", ex, 2);
            }
            if (!(ex instanceof Error)) {
                throw new Error("Unexpected exception", ex);
            }
            throw (Error)ex;
        }
    }
    
    protected static void leave(final String[] readLocks, final String[] writeNonExLocks, final String[] writeLocks, final String description, final LocalLockPool localLocks, final LockPool crossLocks) throws ManifoldCFException {
        final LockDescription[] lds = getSortedUniqueLocks(readLocks, writeNonExLocks, writeLocks);
        ManifoldCFException ae = null;
        int i = lds.length;
        while (--i >= 0) {
            final LockDescription ld = lds[i];
            final String lockKey = ld.getKey();
            final int lockType = ld.getType();
            try {
                switch (lockType) {
                    case 1: {
                        leaveRead(lockKey, description, localLocks, crossLocks);
                        continue;
                    }
                    case 2: {
                        leaveNonExWrite(lockKey, description, localLocks, crossLocks);
                        continue;
                    }
                    case 3: {
                        leaveWrite(lockKey, description, localLocks, crossLocks);
                        continue;
                    }
                }
            }
            catch (ManifoldCFException e) {
                ae = e;
            }
        }
        if (ae != null) {
            throw ae;
        }
    }
    
    protected static LockDescription[] getSortedUniqueLocks(final String[] readLocks, final String[] writeNonExLocks, final String[] writeLocks) {
        final Map<String, LockDescription> ht = new HashMap<String, LockDescription>();
        if (readLocks != null) {
            int i = 0;
            while (i < readLocks.length) {
                final String key = readLocks[i++];
                LockDescription ld = ht.get(key);
                if (ld == null) {
                    ld = new LockDescription(1, key);
                    ht.put(key, ld);
                }
                else {
                    ld.set(1);
                }
            }
        }
        if (writeNonExLocks != null) {
            int i = 0;
            while (i < writeNonExLocks.length) {
                final String key = writeNonExLocks[i++];
                LockDescription ld = ht.get(key);
                if (ld == null) {
                    ld = new LockDescription(2, key);
                    ht.put(key, ld);
                }
                else {
                    ld.set(2);
                }
            }
        }
        if (writeLocks != null) {
            int i = 0;
            while (i < writeLocks.length) {
                final String key = writeLocks[i++];
                LockDescription ld = ht.get(key);
                if (ld == null) {
                    ld = new LockDescription(3, key);
                    ht.put(key, ld);
                }
                else {
                    ld.set(3);
                }
            }
        }
        final LockDescription[] rval = new LockDescription[ht.size()];
        final String[] sortarray = new String[ht.size()];
        int i = 0;
        for (final String key2 : ht.keySet()) {
            sortarray[i++] = key2;
        }
        Arrays.sort(sortarray);
        i = 0;
        for (final String key3 : sortarray) {
            rval[i++] = ht.get(key3);
        }
        return rval;
    }
    
    static {
        myLocks = new LockPool(new LockObjectFactory());
        mySections = new LockPool(new LockObjectFactory());
        globalFlags = new HashMap<String, Boolean>();
        globalData = new HashMap<String, byte[]>();
    }
    
    protected static class LockDescription
    {
        protected int lockType;
        protected String lockKey;
        
        public LockDescription(final int lockType, final String lockKey) {
            this.lockType = lockType;
            this.lockKey = lockKey;
        }
        
        public void set(final int lockType) {
            if (lockType > this.lockType) {
                this.lockType = lockType;
            }
        }
        
        public int getType() {
            return this.lockType;
        }
        
        public String getKey() {
            return this.lockKey;
        }
    }
}
