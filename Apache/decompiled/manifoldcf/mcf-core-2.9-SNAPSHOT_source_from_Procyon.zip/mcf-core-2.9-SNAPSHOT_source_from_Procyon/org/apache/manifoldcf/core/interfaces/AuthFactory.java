// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class AuthFactory
{
    public static final String _rcsid = "@(#)$Id$";
    private static final String authName = "_Auth_";
    
    private AuthFactory() {
    }
    
    public static IAuth make(final IThreadContext context) throws ManifoldCFException {
        Object x = context.get("_Auth_");
        if (x == null || !(x instanceof IAuth)) {
            final String implementationClass = LockManagerFactory.getStringProperty(context, "org.apache.manifoldcf.authimplementationclass", "org.apache.manifoldcf.core.auth.DefaultAuthenticator");
            try {
                final Class c = Class.forName(implementationClass);
                final Constructor constructor = c.getConstructor(IThreadContext.class);
                x = constructor.newInstance(context);
                if (!(x instanceof IAuth)) {
                    throw new ManifoldCFException("Auth implementation class " + implementationClass + " does not implement IAuth", 3);
                }
                context.save("_Auth_", x);
            }
            catch (ClassNotFoundException e) {
                throw new ManifoldCFException("Auth implementation class " + implementationClass + " could not be found: " + e.getMessage(), e, 3);
            }
            catch (ExceptionInInitializerError e2) {
                throw new ManifoldCFException("Auth implementation class " + implementationClass + " could not be instantiated: " + e2.getMessage(), e2, 3);
            }
            catch (LinkageError e3) {
                throw new ManifoldCFException("Auth implementation class " + implementationClass + " could not be linked: " + e3.getMessage(), e3, 3);
            }
            catch (InstantiationException e4) {
                throw new ManifoldCFException("Auth implementation class " + implementationClass + " could not be instantiated: " + e4.getMessage(), e4, 3);
            }
            catch (InvocationTargetException e5) {
                throw new ManifoldCFException("Auth implementation class " + implementationClass + " could not be instantiated: " + e5.getMessage(), e5, 3);
            }
            catch (NoSuchMethodException e6) {
                throw new ManifoldCFException("Auth implementation class " + implementationClass + " had no constructor taking (IThreadContext): " + e6.getMessage(), e6, 3);
            }
            catch (IllegalAccessException e7) {
                throw new ManifoldCFException("Auth implementation class " + implementationClass + " had no public constructor taking (IThreadContext): " + e7.getMessage(), e7, 3);
            }
        }
        return (IAuth)x;
    }
}
