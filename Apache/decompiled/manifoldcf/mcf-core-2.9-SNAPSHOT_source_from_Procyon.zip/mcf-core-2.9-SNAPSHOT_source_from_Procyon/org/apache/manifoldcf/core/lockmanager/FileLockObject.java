// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.manifoldcf.core.system.Logging;
import java.io.InterruptedIOException;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.LockException;
import org.apache.manifoldcf.core.system.ManifoldCF;
import java.io.File;

public class FileLockObject extends LockObject
{
    public static final String _rcsid = "@(#)$Id: LockObject.java 988245 2010-08-23 18:39:35Z kwright $";
    private static final int STATUS_WRITELOCKED = -1;
    private File lockDirectoryName;
    private File lockFileName;
    private boolean isSync;
    private static final String DOTLOCK = ".lock";
    private static final String DOTFILE = ".file";
    private static final String SLASH = "/";
    private static final String FILELOCKED = "File locked";
    
    public FileLockObject(final LockPool lockPool, final Object lockKey, final File synchDir) {
        super(lockPool, lockKey);
        this.lockDirectoryName = null;
        this.lockFileName = null;
        this.isSync = (synchDir != null);
        if (this.isSync) {
            final int hashcode = lockKey.hashCode();
            final int outerDirNumber = hashcode & 0x3FF;
            final int innerDirNumber = hashcode >> 10 & 0x3FF;
            String fullDir = synchDir.toString();
            if (fullDir.length() == 0 || !fullDir.endsWith("/")) {
                fullDir += "/";
            }
            fullDir = fullDir + Integer.toString(outerDirNumber) + "/" + Integer.toString(innerDirNumber);
            new File(fullDir).mkdirs();
            final String filename = createFileName(lockKey);
            this.lockDirectoryName = new File(fullDir, filename + ".lock");
            this.lockFileName = new File(fullDir, filename + ".file");
        }
    }
    
    private static String createFileName(final Object lockKey) {
        return "lock-" + ManifoldCF.safeFileName(lockKey.toString());
    }
    
    @Override
    protected void obtainGlobalWriteLockNoWait() throws ManifoldCFException, LockException, InterruptedException {
        if (this.isSync) {
            this.grabFileLock();
            try {
                final int status = this.readFile();
                if (status != 0) {
                    throw new LockException("Locked by another JVM");
                }
                this.writeFile(-1);
            }
            finally {
                this.releaseFileLock();
            }
        }
    }
    
    @Override
    protected void clearGlobalWriteLockNoWait() throws ManifoldCFException, LockException, InterruptedException {
        if (this.isSync) {
            this.grabFileLock();
            try {
                this.writeFile(0);
            }
            finally {
                this.releaseFileLock();
            }
        }
    }
    
    @Override
    protected void obtainGlobalNonExWriteLockNoWait() throws ManifoldCFException, LockException, InterruptedException {
        if (this.isSync) {
            this.grabFileLock();
            try {
                int status = this.readFile();
                if (status == -1 || status > 0) {
                    throw new LockException("Locked by another JVM");
                }
                if (status == 0) {
                    status = -1;
                }
                --status;
                this.writeFile(status);
            }
            finally {
                this.releaseFileLock();
            }
        }
    }
    
    @Override
    protected void clearGlobalNonExWriteLockNoWait() throws ManifoldCFException, LockException, InterruptedException {
        if (this.isSync) {
            this.grabFileLock();
            try {
                int status = this.readFile();
                if (status >= -1) {
                    throw new RuntimeException("JVM error: File lock is not in expected state for object " + this.toString());
                }
                if (++status == -1) {
                    status = 0;
                }
                this.writeFile(status);
            }
            finally {
                this.releaseFileLock();
            }
        }
    }
    
    @Override
    protected void obtainGlobalReadLockNoWait() throws ManifoldCFException, LockException, InterruptedException {
        if (this.isSync) {
            this.grabFileLock();
            try {
                int status = this.readFile();
                if (status <= -1) {
                    throw new LockException("Locked by another JVM");
                }
                ++status;
                this.writeFile(status);
            }
            finally {
                this.releaseFileLock();
            }
        }
    }
    
    @Override
    protected void clearGlobalReadLockNoWait() throws ManifoldCFException, LockException, InterruptedException {
        if (this.isSync) {
            this.grabFileLock();
            try {
                int status = this.readFile();
                if (status == 0) {
                    throw new RuntimeException("JVM error: File lock is not in expected state for object " + this.toString());
                }
                --status;
                this.writeFile(status);
            }
            finally {
                this.releaseFileLock();
            }
        }
    }
    
    private synchronized void grabFileLock() throws LockException, InterruptedException {
        while (true) {
            try {
                if (!this.lockDirectoryName.createNewFile()) {
                    throw new LockException("File locked");
                }
            }
            catch (InterruptedIOException e) {
                throw new InterruptedException("Interrupted IO: " + e.getMessage());
            }
            catch (IOException e2) {
                try {
                    Logging.lock.warn((Object)("Attempt to set file lock '" + this.lockDirectoryName.toString() + "' failed: " + e2.getMessage()), (Throwable)e2);
                }
                catch (Throwable e3) {
                    e2.printStackTrace();
                }
                ManifoldCF.sleep(100L);
                continue;
            }
            break;
        }
    }
    
    private synchronized void releaseFileLock() throws InterruptedException {
        Throwable ie = null;
        while (true) {
            try {
                while (!this.lockDirectoryName.delete()) {
                    try {
                        Logging.lock.fatal((Object)("Failure deleting file lock '" + this.lockDirectoryName.toString() + "'"));
                    }
                    catch (Throwable e3) {
                        System.out.println("Failure deleting file lock '" + this.lockDirectoryName.toString() + "'");
                    }
                    System.exit(-100);
                }
                break;
            }
            catch (Error e) {
                final String message = "Error deleting file lock '" + this.lockDirectoryName.toString() + "': " + e.getMessage();
                try {
                    Logging.lock.error((Object)message, (Throwable)e);
                }
                catch (Throwable e4) {
                    System.out.println(message);
                    e.printStackTrace();
                }
                ie = e;
                ManifoldCF.sleep(100L);
                continue;
            }
            catch (RuntimeException e2) {
                final String message = "Error deleting file lock '" + this.lockDirectoryName.toString() + "': " + e2.getMessage();
                try {
                    Logging.lock.error((Object)message, (Throwable)e2);
                }
                catch (Throwable e4) {
                    System.out.println(message);
                    e2.printStackTrace();
                }
                ie = e2;
                ManifoldCF.sleep(100L);
                continue;
            }
        }
        if (ie != null) {
            if (ie instanceof InterruptedException) {
                throw (InterruptedException)ie;
            }
            if (ie instanceof Error) {
                throw (Error)ie;
            }
            if (ie instanceof RuntimeException) {
                throw (RuntimeException)ie;
            }
        }
    }
    
    private synchronized int readFile() throws InterruptedException {
        try {
            final InputStreamReader isr = new InputStreamReader(new FileInputStream(this.lockFileName), StandardCharsets.UTF_8);
            try {
                final BufferedReader x = new BufferedReader(isr);
                try {
                    final StringBuilder sb = new StringBuilder();
                    while (true) {
                        final int rval = x.read();
                        if (rval == -1) {
                            break;
                        }
                        sb.append((char)rval);
                    }
                    try {
                        return Integer.parseInt(sb.toString());
                    }
                    catch (NumberFormatException e) {
                        throw new IOException("Lock number read was not valid: " + e.getMessage());
                    }
                }
                finally {
                    x.close();
                }
            }
            catch (InterruptedIOException e2) {
                throw new InterruptedException("Interrupted IO: " + e2.getMessage());
            }
            catch (IOException e3) {
                final String message = "Could not read from lock file: '" + this.lockFileName.toString() + "'";
                try {
                    Logging.lock.error((Object)message, (Throwable)e3);
                }
                catch (Throwable e5) {
                    System.out.println(message);
                    e3.printStackTrace();
                }
                throw e3;
            }
            finally {
                isr.close();
            }
        }
        catch (InterruptedIOException e4) {
            throw new InterruptedException("Interrupted IO: " + e4.getMessage());
        }
        catch (IOException e6) {
            return 0;
        }
    }
    
    private synchronized void writeFile(final int value) throws InterruptedException {
        try {
            if (value == 0) {
                if (!this.lockFileName.delete()) {
                    throw new IOException("Could not delete file '" + this.lockFileName.toString() + "'");
                }
            }
            else {
                final OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(this.lockFileName), StandardCharsets.UTF_8);
                try {
                    final BufferedWriter x = new BufferedWriter(osw);
                    try {
                        x.write(Integer.toString(value));
                    }
                    finally {
                        x.close();
                    }
                }
                finally {
                    osw.close();
                }
            }
        }
        catch (Error e) {
            final String message = "Couldn't write to lock file; hard error occurred.  Shutting down process; locks may be left dangling.  You must cleanup before restarting.";
            try {
                Logging.lock.error((Object)message, (Throwable)e);
            }
            catch (Throwable e5) {
                System.out.println(message);
                e.printStackTrace();
            }
            System.exit(-100);
        }
        catch (RuntimeException e2) {
            final String message = "Couldn't write to lock file; JVM error.  Shutting down process; locks may be left dangling.  You must cleanup before restarting.";
            try {
                Logging.lock.error((Object)message, (Throwable)e2);
            }
            catch (Throwable e5) {
                System.out.println(message);
                e2.printStackTrace();
            }
            System.exit(-100);
        }
        catch (InterruptedIOException e3) {
            throw new InterruptedException("Interrupted IO: " + e3.getMessage());
        }
        catch (IOException e4) {
            final String message = "Couldn't write to lock file; disk may be full.  Shutting down process; locks may be left dangling.  You must cleanup before restarting.";
            try {
                Logging.lock.error((Object)message, (Throwable)e4);
            }
            catch (Throwable e5) {
                System.out.println(message);
                e4.printStackTrace();
            }
            System.exit(-100);
        }
    }
}
