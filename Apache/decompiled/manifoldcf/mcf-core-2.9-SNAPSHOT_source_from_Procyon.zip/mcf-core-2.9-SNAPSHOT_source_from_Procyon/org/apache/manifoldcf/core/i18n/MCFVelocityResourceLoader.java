// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.i18n;

import org.apache.commons.collections.ExtendedProperties;
import org.apache.velocity.exception.ResourceNotFoundException;
import java.io.InputStream;
import org.apache.velocity.runtime.resource.Resource;
import org.apache.velocity.runtime.resource.loader.ResourceLoader;

public class MCFVelocityResourceLoader extends ResourceLoader
{
    protected Class classInstance;
    
    public MCFVelocityResourceLoader(final Class classInstance) {
        this.classInstance = classInstance;
    }
    
    public long getLastModified(final Resource resource) {
        return 0L;
    }
    
    public InputStream getResourceStream(final String source) throws ResourceNotFoundException {
        final InputStream rval = this.classInstance.getResourceAsStream(source);
        if (rval == null) {
            throw new ResourceNotFoundException("Resource '" + source + "' not found.");
        }
        return rval;
    }
    
    public void init(final ExtendedProperties configuration) {
    }
    
    public boolean isSourceModified(final Resource resource) {
        return true;
    }
}
