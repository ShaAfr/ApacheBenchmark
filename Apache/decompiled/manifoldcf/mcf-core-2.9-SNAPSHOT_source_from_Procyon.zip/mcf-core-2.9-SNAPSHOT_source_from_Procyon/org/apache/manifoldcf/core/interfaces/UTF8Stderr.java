// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.Writer;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.io.PrintWriter;

public final class UTF8Stderr
{
    public static final String _rcsid = "@(#)$Id: UTF8Stderr.java 988245 2010-08-23 18:39:35Z kwright $";
    private static PrintWriter err;
    
    private UTF8Stderr() {
    }
    
    public static void close() {
        UTF8Stderr.err.close();
    }
    
    public static void println() {
        UTF8Stderr.err.println();
    }
    
    public static void println(final Object x) {
        UTF8Stderr.err.println(x);
    }
    
    public static void println(final boolean x) {
        UTF8Stderr.err.println(x);
    }
    
    public static void println(final char x) {
        UTF8Stderr.err.println(x);
    }
    
    public static void println(final double x) {
        UTF8Stderr.err.println(x);
    }
    
    public static void println(final float x) {
        UTF8Stderr.err.println(x);
    }
    
    public static void println(final int x) {
        UTF8Stderr.err.println(x);
    }
    
    public static void println(final long x) {
        UTF8Stderr.err.println(x);
    }
    
    public static void print() {
        UTF8Stderr.err.flush();
    }
    
    public static void print(final Object x) {
        UTF8Stderr.err.print(x);
        UTF8Stderr.err.flush();
    }
    
    public static void print(final boolean x) {
        UTF8Stderr.err.print(x);
        UTF8Stderr.err.flush();
    }
    
    public static void print(final char x) {
        UTF8Stderr.err.print(x);
        UTF8Stderr.err.flush();
    }
    
    public static void print(final double x) {
        UTF8Stderr.err.print(x);
        UTF8Stderr.err.flush();
    }
    
    public static void print(final float x) {
        UTF8Stderr.err.print(x);
        UTF8Stderr.err.flush();
    }
    
    public static void print(final int x) {
        UTF8Stderr.err.print(x);
        UTF8Stderr.err.flush();
    }
    
    public static void print(final long x) {
        UTF8Stderr.err.print(x);
        UTF8Stderr.err.flush();
    }
    
    public static void printStackTrace(final Throwable e) {
        e.printStackTrace(UTF8Stderr.err);
    }
    
    static {
        UTF8Stderr.err = new PrintWriter(new OutputStreamWriter(System.err, StandardCharsets.UTF_8), true);
    }
}
