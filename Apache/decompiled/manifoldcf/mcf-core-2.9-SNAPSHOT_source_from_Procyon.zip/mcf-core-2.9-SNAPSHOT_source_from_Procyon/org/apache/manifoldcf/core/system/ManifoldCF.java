// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.system;

import org.apache.manifoldcf.core.database.ConnectionFactory;
import org.apache.manifoldcf.core.interfaces.ICacheManager;
import org.apache.manifoldcf.core.interfaces.CacheManagerFactory;
import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;
import java.io.Reader;
import java.io.InterruptedIOException;
import java.io.BufferedReader;
import org.apache.manifoldcf.core.interfaces.StringSet;
import java.io.InputStreamReader;
import javax.crypto.CipherInputStream;
import java.io.ByteArrayInputStream;
import java.io.Writer;
import java.io.IOException;
import org.apache.manifoldcf.core.common.Base64;
import java.io.OutputStreamWriter;
import java.io.OutputStream;
import javax.crypto.CipherOutputStream;
import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;
import javax.crypto.SecretKey;
import java.security.spec.KeySpec;
import java.security.GeneralSecurityException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import org.apache.manifoldcf.core.interfaces.IDBInterface;
import org.apache.manifoldcf.core.interfaces.ConfigurationNode;
import java.io.InputStream;
import java.util.ArrayList;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
import org.apache.manifoldcf.core.interfaces.DBInterfaceFactory;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import org.apache.manifoldcf.core.interfaces.ThreadContextFactory;
import org.apache.manifoldcf.core.interfaces.ManifoldCFConfiguration;
import org.apache.manifoldcf.core.interfaces.IPollingHook;
import org.apache.manifoldcf.core.interfaces.IShutdownHook;
import java.util.List;
import java.io.File;

public class ManifoldCF
{
    public static final String _rcsid = "@(#)$Id: ManifoldCF.java 988245 2010-08-23 18:39:35Z kwright $";
    public static final String NODE_LIBDIR = "libdir";
    public static final String ATTRIBUTE_PATH = "path";
    protected static String processID;
    protected static File workingDirectory;
    protected static ManifoldCFResourceLoader resourceLoader;
    protected static FileTrack tracker;
    protected static DatabaseShutdown dbShutdown;
    protected static final List<IShutdownHook> cleanupHooks;
    protected static final List<IPollingHook> pollingHooks;
    protected static Thread shutdownThread;
    protected static int initializeLevel;
    protected static boolean alreadyClosed;
    protected static boolean alreadyShutdown;
    protected static Integer initializeFlagLock;
    protected static String mcfVersion;
    protected static String masterDatabaseName;
    protected static String masterDatabaseUsername;
    protected static String masterDatabasePassword;
    protected static ManifoldCFConfiguration localConfiguration;
    protected static long propertyFilelastMod;
    protected static String propertyFilePath;
    protected static final String applicationName = "lcf";
    public static final String lcfConfigFileProperty = "org.apache.manifoldcf.configfile";
    public static final String versionProperty = "org.apache.manifoldcf.versionstring";
    public static final String processIDProperty = "org.apache.manifoldcf.processid";
    public static final String masterDatabaseNameProperty = "org.apache.manifoldcf.database.name";
    public static final String masterDatabaseUsernameProperty = "org.apache.manifoldcf.database.username";
    public static final String masterDatabasePasswordProperty = "org.apache.manifoldcf.database.password";
    public static final String databaseHandleMaxcountProperty = "org.apache.manifoldcf.database.maxhandles";
    public static final String databaseHandleTimeoutProperty = "org.apache.manifoldcf.database.handletimeout";
    public static final String databaseConnectionTrackingProperty = "org.apache.manifoldcf.database.connectiontracking";
    public static final String databaseQueryMaxTimeProperty = "org.apache.manifoldcf.database.maxquerytime";
    public static final String logConfigFileProperty = "org.apache.manifoldcf.logconfigfile";
    public static final String fileResourcesProperty = "org.apache.manifoldcf.fileresources";
    public static final String lockManagerImplementation = "org.apache.manifoldcf.lockmanagerclass";
    public static final String databaseImplementation = "org.apache.manifoldcf.databaseimplementationclass";
    public static final String authImplementation = "org.apache.manifoldcf.authimplementationclass";
    public static final String configSignalCommandProperty = "org.apache.manifoldcf.configuration.change.command";
    public static final String maintenanceFileSignalProperty = "org.apache.manifoldcf.database.maintenanceflag";
    public static final String saltProperty = "org.apache.manifoldcf.salt";
    protected static final int IV_LENGTH = 16;
    private static String OBFUSCATION_PASSCODE;
    private static String OBFUSCATION_SALT;
    
    @Deprecated
    public static void resetEnvironment() {
        resetEnvironment(ThreadContextFactory.make());
    }
    
    public static void resetEnvironment(final IThreadContext threadContext) {
        synchronized (ManifoldCF.initializeFlagLock) {
            if (ManifoldCF.initializeLevel > 0) {
                cleanUpEnvironment(threadContext);
                ManifoldCF.processID = null;
                ManifoldCF.mcfVersion = null;
                ManifoldCF.masterDatabaseName = null;
                ManifoldCF.masterDatabaseUsername = null;
                ManifoldCF.masterDatabasePassword = null;
                ManifoldCF.localConfiguration = null;
                ManifoldCF.propertyFilelastMod = -1L;
                ManifoldCF.propertyFilePath = null;
                ManifoldCF.alreadyClosed = false;
                ManifoldCF.alreadyShutdown = false;
                ManifoldCF.initializeLevel = 0;
            }
        }
    }
    
    @Deprecated
    public static void initializeEnvironment() throws ManifoldCFException {
        initializeEnvironment(ThreadContextFactory.make());
    }
    
    public static void initializeEnvironment(final IThreadContext threadContext) throws ManifoldCFException {
        synchronized (ManifoldCF.initializeFlagLock) {
            if (ManifoldCF.initializeLevel == 0) {
                try {
                    final Properties props = System.getProperties();
                    ManifoldCF.propertyFilePath = (String)props.get("org.apache.manifoldcf.configfile");
                    if (ManifoldCF.propertyFilePath == null) {
                        System.err.println("Couldn't find org.apache.manifoldcf.configfile property; using default");
                        String configPath = (String)props.get("user.home") + "/" + "lcf";
                        configPath = configPath.replace('\\', '/');
                        ManifoldCF.propertyFilePath = new File(configPath, "properties.xml").toString();
                    }
                    ManifoldCF.workingDirectory = new File(ManifoldCF.propertyFilePath).getAbsoluteFile().getParentFile();
                    ManifoldCF.resourceLoader = new ManifoldCFResourceLoader(Thread.currentThread().getContextClassLoader());
                    ManifoldCF.localConfiguration = new OverrideableManifoldCFConfiguration();
                    checkProperties();
                    ManifoldCF.processID = getStringProperty("org.apache.manifoldcf.processid", "");
                    if (ManifoldCF.processID.length() > 16) {
                        throw new ManifoldCFException("Process ID cannot exceed 16 characters!");
                    }
                    File logConfigFile = getFileProperty("org.apache.manifoldcf.logconfigfile");
                    if (logConfigFile == null) {
                        System.err.println("Couldn't find org.apache.manifoldcf.logconfigfile property; using default");
                        String configPath2 = (String)props.get("user.home") + "/" + "lcf";
                        configPath2 = configPath2.replace('\\', '/');
                        logConfigFile = new File(configPath2, "logging.xml");
                    }
                    synchronized (ManifoldCF.cleanupHooks) {
                        ManifoldCF.cleanupHooks.clear();
                    }
                    synchronized (ManifoldCF.pollingHooks) {
                        ManifoldCF.pollingHooks.clear();
                    }
                    Logging.initializeLoggingSystem(logConfigFile);
                    Logging.initializeLoggers();
                    Logging.setLogLevels(threadContext);
                    ManifoldCF.mcfVersion = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.versionstring", "unknown version");
                    ManifoldCF.masterDatabaseName = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.database.name", "dbname");
                    ManifoldCF.masterDatabaseUsername = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.database.username", "manifoldcf");
                    ManifoldCF.masterDatabasePassword = LockManagerFactory.getPossiblyObfuscatedStringProperty(threadContext, "org.apache.manifoldcf.database.password", "local_pg_passwd");
                    registerConnectorServices();
                    addPollingHook(new CachePoll());
                    addShutdownHook(ManifoldCF.tracker = new FileTrack());
                    addShutdownHook(new DatabaseShutdown());
                    DBInterfaceFactory.make(threadContext, ManifoldCF.masterDatabaseName, ManifoldCF.masterDatabaseUsername, ManifoldCF.masterDatabasePassword).openDatabase();
                }
                catch (ManifoldCFException e) {
                    throw new ManifoldCFException("Initialization failed: " + e.getMessage(), e, 3);
                }
            }
            ++ManifoldCF.initializeLevel;
        }
    }
    
    protected static void registerConnectorServices() throws ManifoldCFException {
        try {
            final Class connectorServicesManifoldCF = findClass("org.apache.manifoldcf.connectorcommon.system.ManifoldCF");
            final Method m = connectorServicesManifoldCF.getMethod("registerConnectorServices", (Class[])new Class[0]);
            m.invoke(new Object[0], new Object[0]);
        }
        catch (ClassNotFoundException e) {
            Logging.root.warn((Object)("Could not find connectorcommon main class: " + e.getMessage()), (Throwable)e);
        }
        catch (NoSuchMethodException e2) {
            Logging.root.warn((Object)("ManifoldCF.registerConnectorServices not found: " + e2.getMessage()), (Throwable)e2);
        }
        catch (IllegalAccessException e3) {
            Logging.root.warn((Object)("Connectorcommon main class had illegal access: " + e3.getMessage()), (Throwable)e3);
        }
        catch (InvocationTargetException e4) {
            final Throwable z = e4.getTargetException();
            if (z instanceof Error) {
                throw (Error)z;
            }
            if (z instanceof RuntimeException) {
                throw (RuntimeException)z;
            }
            throw new RuntimeException("Unknown exception type: " + z.getClass().getName() + ": " + z.getMessage(), z);
        }
    }
    
    public static final String getProcessID() {
        return ManifoldCF.processID;
    }
    
    public static final ManifoldCFConfiguration getConfiguration() {
        return ManifoldCF.localConfiguration;
    }
    
    public static final void checkProperties() throws ManifoldCFException {
        final File f = new File(ManifoldCF.propertyFilePath);
        try {
            if (ManifoldCF.propertyFilelastMod == f.lastModified()) {
                System.err.println("Configuration file not read because it didn't change");
                return;
            }
            final InputStream is = new FileInputStream(f);
            try {
                ManifoldCF.localConfiguration.fromXML(is);
                System.err.println("Configuration file successfully read");
                ManifoldCF.propertyFilelastMod = f.lastModified();
            }
            finally {
                is.close();
            }
        }
        catch (Exception e) {
            throw new ManifoldCFException("Could not read configuration file '" + f.toString() + "'", e);
        }
        final ArrayList libDirs = new ArrayList();
        int i = 0;
        while (i < ManifoldCF.localConfiguration.getChildCount()) {
            final ConfigurationNode cn = ManifoldCF.localConfiguration.findChild(i++);
            if (cn.getType().equals("libdir")) {
                final String path = cn.getAttributeValue("path");
                if (path == null) {
                    throw new ManifoldCFException("Node type 'libdir' requires a 'path attribute");
                }
                libDirs.add(resolvePath(path));
            }
        }
        ManifoldCF.resourceLoader.setClassPath(libDirs);
    }
    
    public static File resolvePath(final String path) {
        final File r = new File(path);
        return r.isAbsolute() ? r : new File(ManifoldCF.workingDirectory, path);
    }
    
    public static String getProperty(final String s) {
        return ManifoldCF.localConfiguration.getProperty(s);
    }
    
    public static File getFileProperty(final String s) {
        final String value = getProperty(s);
        if (value == null) {
            return null;
        }
        return resolvePath(value);
    }
    
    public static String getStringProperty(final String s, final String defaultValue) {
        return ManifoldCF.localConfiguration.getStringProperty(s, defaultValue);
    }
    
    public static boolean getBooleanProperty(final String s, final boolean defaultValue) throws ManifoldCFException {
        return ManifoldCF.localConfiguration.getBooleanProperty(s, defaultValue);
    }
    
    public static int getIntProperty(final String s, final int defaultValue) throws ManifoldCFException {
        return ManifoldCF.localConfiguration.getIntProperty(s, defaultValue);
    }
    
    public static long getLongProperty(final String s, final long defaultValue) throws ManifoldCFException {
        return ManifoldCF.localConfiguration.getLongProperty(s, defaultValue);
    }
    
    public static double getDoubleProperty(final String s, final double defaultValue) throws ManifoldCFException {
        return ManifoldCF.localConfiguration.getDoubleProperty(s, defaultValue);
    }
    
    public static void ensureFolder(final String path) throws ManifoldCFException {
        try {
            final File f = new File(path);
            if (!f.isDirectory()) {
                f.mkdirs();
            }
        }
        catch (Exception e) {
            throw new ManifoldCFException("Can't make folder", e, 0);
        }
    }
    
    public static void deleteFolder(final String path) {
        final File directoryPath = new File(path);
        recursiveDelete(directoryPath);
    }
    
    public static void recursiveDelete(final File directoryPath) {
        if (!directoryPath.exists()) {
            return;
        }
        if (directoryPath.isDirectory()) {
            final File[] children = directoryPath.listFiles();
            if (children != null) {
                int i = 0;
                while (i < children.length) {
                    final File x = children[i++];
                    recursiveDelete(x);
                }
            }
        }
        directoryPath.delete();
    }
    
    public static boolean isFolder(final String path) {
        final File f = new File(path);
        return f.isDirectory();
    }
    
    public static String safeFileName(final String value) {
        final StringBuilder rval = new StringBuilder();
        int i = 0;
        while (i < value.length()) {
            final char x = value.charAt(i++);
            if (x == '/' || x == '\"' || x == '\\' || x == '|' || (x >= '\0' && x < ' ') || x == '+' || x == ',' || x == ':' || x == ';' || x == '<' || x == '>' || x == '=' || x == '[' || x == ']' || x == '&') {
                rval.append("&").append(Integer.toString(x)).append("!");
            }
            else {
                rval.append(x);
            }
        }
        return rval.toString();
    }
    
    public static String getMcfVersion() {
        return ManifoldCF.mcfVersion;
    }
    
    public static String getMasterDatabaseName() {
        return ManifoldCF.masterDatabaseName;
    }
    
    public static String getMasterDatabaseUsername() {
        return ManifoldCF.masterDatabaseUsername;
    }
    
    public static String getMasterDatabasePassword() {
        return ManifoldCF.masterDatabasePassword;
    }
    
    public static String getChildDatabaseName(final IDBInterface companyDatabase, final String childDBIdentifier) {
        return companyDatabase.getDatabaseName() + "_" + childDBIdentifier;
    }
    
    public static String hash(final String input) throws ManifoldCFException {
        final MessageDigest hash = startHash();
        addToHash(hash, input);
        return getHashValue(hash);
    }
    
    public static MessageDigest startHash() throws ManifoldCFException {
        try {
            return MessageDigest.getInstance("SHA");
        }
        catch (Exception e) {
            throw new ManifoldCFException("Couldn't encrypt: " + e.getMessage(), e, 0);
        }
    }
    
    public static void addToHash(final MessageDigest digest, final String input) throws ManifoldCFException {
        try {
            final byte[] inputBytes = input.getBytes(StandardCharsets.UTF_8);
            digest.update(inputBytes);
        }
        catch (Exception e) {
            throw new ManifoldCFException("Couldn't encrypt: " + e.getMessage(), e, 0);
        }
    }
    
    public static String getHashValue(final MessageDigest digest) throws ManifoldCFException {
        try {
            final byte[] encryptedBytes = digest.digest();
            final StringBuilder rval = new StringBuilder();
            int i = 0;
            while (i < encryptedBytes.length) {
                final byte x = encryptedBytes[i++];
                rval.append(writeNibble(x >> 4 & 0xF));
                rval.append(writeNibble(x & 0xF));
            }
            return rval.toString();
        }
        catch (Exception e) {
            throw new ManifoldCFException("Couldn't encrypt: " + e.getMessage(), e, 0);
        }
    }
    
    protected static String getSaltValue(final IThreadContext threadContext) throws ManifoldCFException {
        final String saltValue = LockManagerFactory.getProperty(threadContext, "org.apache.manifoldcf.salt");
        if (saltValue == null || saltValue.length() == 0) {
            throw new ManifoldCFException("Missing required SALT value");
        }
        return saltValue;
    }
    
    protected static Cipher getCipher(final IThreadContext threadContext, final int mode, final String passCode, final byte[] iv) throws ManifoldCFException {
        return getCipher(getSaltValue(threadContext), mode, passCode, iv);
    }
    
    protected static Cipher getCipher(final String saltValue, final int mode, final String passCode, final byte[] iv) throws ManifoldCFException {
        try {
            final SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            final KeySpec keySpec = new PBEKeySpec(passCode.toCharArray(), saltValue.getBytes(StandardCharsets.UTF_8), 1024, 128);
            final SecretKey secretKey = factory.generateSecret(keySpec);
            final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            final SecretKeySpec key = new SecretKeySpec(secretKey.getEncoded(), "AES");
            final IvParameterSpec parameterSpec = new IvParameterSpec(iv);
            cipher.init(mode, key, parameterSpec);
            return cipher;
        }
        catch (GeneralSecurityException gse) {
            throw new ManifoldCFException("Could not build a cipher: " + gse.getMessage(), gse);
        }
    }
    
    protected static byte[] getSecureRandom() {
        final SecureRandom random = new SecureRandom();
        final byte[] iv = new byte[16];
        random.nextBytes(iv);
        return iv;
    }
    
    public static String obfuscate(final String input) throws ManifoldCFException {
        return encrypt(ManifoldCF.OBFUSCATION_SALT, ManifoldCF.OBFUSCATION_PASSCODE, input);
    }
    
    public static String deobfuscate(final String input) throws ManifoldCFException {
        return decrypt(ManifoldCF.OBFUSCATION_SALT, ManifoldCF.OBFUSCATION_PASSCODE, input);
    }
    
    public static String encrypt(final String saltValue, final String passCode, final String input) throws ManifoldCFException {
        if (input == null) {
            return null;
        }
        if (input.length() == 0) {
            return input;
        }
        try {
            final ByteArrayOutputStream os = new ByteArrayOutputStream();
            final byte[] iv = getSecureRandom();
            os.write(iv);
            os.flush();
            final Cipher cipher = getCipher(saltValue, 1, passCode, iv);
            final CipherOutputStream cos = new CipherOutputStream(os, cipher);
            final Writer w = new OutputStreamWriter(cos, StandardCharsets.UTF_8);
            w.write(input);
            w.flush();
            cos.flush();
            cos.close();
            final byte[] bytes = os.toByteArray();
            return new Base64().encodeByteArray(bytes);
        }
        catch (IOException e) {
            throw new ManifoldCFException(e.getMessage(), e);
        }
    }
    
    public static String decrypt(final String saltValue, final String passCode, final String input) throws ManifoldCFException {
        if (input == null) {
            return null;
        }
        if (input.length() == 0) {
            return input;
        }
        try {
            final ByteArrayInputStream is = new ByteArrayInputStream(new Base64().decodeString(input));
            final byte[] iv = new byte[16];
            int amt;
            for (int pointer = 0; pointer < iv.length; pointer += amt) {
                amt = is.read(iv, pointer, iv.length - pointer);
                if (amt == -1) {
                    throw new ManifoldCFException("String can't be decrypted: too short");
                }
            }
            final Cipher cipher = getCipher(saltValue, 2, passCode, iv);
            final CipherInputStream cis = new CipherInputStream(is, cipher);
            final InputStreamReader reader = new InputStreamReader(cis, StandardCharsets.UTF_8);
            final StringBuilder sb = new StringBuilder();
            final char[] buffer = new char[65536];
            while (true) {
                final int amt2 = reader.read(buffer, 0, buffer.length);
                if (amt2 == -1) {
                    break;
                }
                sb.append(buffer, 0, amt2);
            }
            return sb.toString();
        }
        catch (IOException e) {
            throw new ManifoldCFException(e.getMessage(), e);
        }
    }
    
    protected static char writeNibble(final int value) {
        if (value >= 10) {
            return (char)(value - 10 + 65);
        }
        return (char)(value + 48);
    }
    
    protected static int readNibble(final char value) throws ManifoldCFException {
        if (value >= 'A' && value <= 'F') {
            return value - 'A' + 10;
        }
        if (value >= '0' && value <= '9') {
            return value - '0';
        }
        throw new ManifoldCFException("Bad hexadecimal value", 0);
    }
    
    public static void createSystemDatabase(final IThreadContext threadcontext, final String masterUsername, final String masterPassword) throws ManifoldCFException {
        final String databaseName = getMasterDatabaseName();
        final String databaseUsername = getMasterDatabaseUsername();
        final String databasePassword = getMasterDatabasePassword();
        final IDBInterface master = DBInterfaceFactory.make(threadcontext, databaseName, databaseUsername, databasePassword);
        master.createUserAndDatabase(masterUsername, masterPassword, null);
    }
    
    public static void dropSystemDatabase(final IThreadContext threadcontext, final String masterUsername, final String masterPassword) throws ManifoldCFException {
        final String databaseName = getMasterDatabaseName();
        final String databaseUsername = getMasterDatabaseUsername();
        final String databasePassword = getMasterDatabasePassword();
        final IDBInterface master = DBInterfaceFactory.make(threadcontext, databaseName, databaseUsername, databasePassword);
        master.dropUserAndDatabase(masterUsername, masterPassword, null);
    }
    
    public static File createTempDir(final String prefix, final String suffix) throws ManifoldCFException {
        final String tempDirLocation = System.getProperty("java.io.tmpdir");
        if (tempDirLocation == null) {
            throw new ManifoldCFException("Can't find temporary directory!");
        }
        final File tempDir = new File(tempDirLocation);
        final long currentFileID = System.currentTimeMillis();
        long currentFileHash = currentFileID << 5 ^ currentFileID >> 3;
        int raceConditionRepeat = 0;
        while (raceConditionRepeat < 1000) {
            final File tempCertDir = new File(tempDir, prefix + currentFileHash + suffix);
            if (tempCertDir.mkdir()) {
                return tempCertDir;
            }
            if (tempCertDir.exists()) {
                ++currentFileHash;
            }
            else {
                ++raceConditionRepeat;
                Thread.yield();
            }
        }
        throw new ManifoldCFException("Temporary directory appears to be unwritable");
    }
    
    public static void addFile(final File f) {
        ManifoldCF.tracker.addFile(f);
    }
    
    public static void deleteFile(final File f) {
        ManifoldCF.tracker.deleteFile(f);
    }
    
    public static boolean checkMaintenanceUnderway() {
        final String fileToCheck = getProperty("org.apache.manifoldcf.database.maintenanceflag");
        if (fileToCheck != null && fileToCheck.length() > 0) {
            final File f = new File(fileToCheck);
            return f.exists();
        }
        return false;
    }
    
    public static void noteConfigurationChange() throws ManifoldCFException {
        final String configChangeSignalCommand = getProperty("org.apache.manifoldcf.configuration.change.command");
        if (configChangeSignalCommand == null || configChangeSignalCommand.length() == 0) {
            return;
        }
        final ArrayList list = new ArrayList();
        int currentIndex = 0;
        while (currentIndex < configChangeSignalCommand.length()) {
            while (currentIndex < configChangeSignalCommand.length()) {
                final char x = configChangeSignalCommand.charAt(currentIndex);
                if (x < '\0') {
                    break;
                }
                if (x > ' ') {
                    break;
                }
                ++currentIndex;
            }
            final StringBuilder argBuffer = new StringBuilder();
            boolean isQuoted = false;
            while (currentIndex < configChangeSignalCommand.length()) {
                char x2 = configChangeSignalCommand.charAt(currentIndex);
                if (isQuoted) {
                    if (x2 == '\"') {
                        ++currentIndex;
                        isQuoted = false;
                    }
                    else if (x2 == '\\') {
                        if (++currentIndex >= configChangeSignalCommand.length()) {
                            break;
                        }
                        x2 = configChangeSignalCommand.charAt(currentIndex);
                        argBuffer.append(x2);
                    }
                    else {
                        ++currentIndex;
                        argBuffer.append(x2);
                    }
                }
                else if (x2 == '\"') {
                    ++currentIndex;
                    isQuoted = true;
                }
                else if (x2 == '\\') {
                    if (++currentIndex >= configChangeSignalCommand.length()) {
                        break;
                    }
                    x2 = configChangeSignalCommand.charAt(currentIndex);
                    argBuffer.append(x2);
                }
                else {
                    if (x2 >= '\0' && x2 <= ' ') {
                        break;
                    }
                    ++currentIndex;
                    argBuffer.append(x2);
                }
            }
            list.add(argBuffer.toString());
        }
        final String[] commandArray = new String[list.size()];
        for (int i = 0; i < commandArray.length; ++i) {
            commandArray[i] = list.get(i);
        }
        if (commandArray.length == 0) {
            return;
        }
        final String[] env = new String[0];
        final File dir = new File("/");
        try {
            final Process p = Runtime.getRuntime().exec(commandArray, env, dir);
            try {
                final int rval = p.waitFor();
                if (rval != 0) {
                    final InputStream is = p.getErrorStream();
                    try {
                        final Reader r = new InputStreamReader(is, StandardCharsets.UTF_8);
                        try {
                            final BufferedReader br = new BufferedReader(r);
                            try {
                                final StringBuilder sb = new StringBuilder();
                                while (true) {
                                    final String value = br.readLine();
                                    if (value == null) {
                                        break;
                                    }
                                    sb.append(value).append("; ");
                                }
                                throw new ManifoldCFException("Shelled process '" + configChangeSignalCommand + "' failed with error " + Integer.toString(rval) + ": " + sb.toString());
                            }
                            finally {
                                br.close();
                            }
                        }
                        finally {
                            r.close();
                        }
                    }
                    finally {
                        is.close();
                    }
                }
            }
            finally {
                p.destroy();
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException("Process wait interrupted: " + e.getMessage(), e, 2);
        }
        catch (InterruptedIOException e2) {
            throw new ManifoldCFException("IO with subprocess interrupted: " + e2.getMessage(), e2, 2);
        }
        catch (IOException e3) {
            throw new ManifoldCFException("IO exception signalling change: " + e3.getMessage(), e3);
        }
    }
    
    public static void sleep(final long milliseconds) throws InterruptedException {
        final Integer x = new Integer(0);
        synchronized (x) {
            x.wait(milliseconds);
        }
    }
    
    public static void writeBytes(final OutputStream os, final byte[] byteArray) throws IOException {
        os.write(byteArray, 0, byteArray.length);
    }
    
    public static void writeByte(final OutputStream os, final int byteValue) throws IOException {
        writeBytes(os, new byte[] { (byte)byteValue });
    }
    
    public static void writeWord(final OutputStream os, final int wordValue) throws IOException {
        final byte[] buffer = { (byte)(wordValue & 0xFF), (byte)(wordValue >>> 8 & 0xFF) };
        writeBytes(os, buffer);
    }
    
    public static void writeDword(final OutputStream os, final int dwordValue) throws IOException {
        if (dwordValue < 0) {
            throw new IllegalArgumentException("Attempt to use an unsigned operator to write a signed value");
        }
        writeSdword(os, dwordValue);
    }
    
    public static void writeSdword(final OutputStream os, final int dwordValue) throws IOException {
        final byte[] buffer = { (byte)(dwordValue & 0xFF), (byte)(dwordValue >>> 8 & 0xFF), (byte)(dwordValue >>> 16 & 0xFF), (byte)(dwordValue >>> 24 & 0xFF) };
        writeBytes(os, buffer);
    }
    
    public static void writeLong(final OutputStream os, final Long longValue) throws IOException {
        if (longValue == null) {
            writeByte(os, 1);
        }
        else {
            writeByte(os, 0);
            final long value = longValue;
            final byte[] buffer = { (byte)(value & 0xFFL), (byte)(Long.rotateRight(value, 8) & 0xFFL), (byte)(Long.rotateRight(value, 16) & 0xFFL), (byte)(Long.rotateRight(value, 24) & 0xFFL), (byte)(Long.rotateRight(value, 32) & 0xFFL), (byte)(Long.rotateRight(value, 40) & 0xFFL), (byte)(Long.rotateRight(value, 48) & 0xFFL), (byte)(Long.rotateRight(value, 56) & 0xFFL) };
            writeBytes(os, buffer);
        }
    }
    
    public static void writeString(final OutputStream os, final String stringValue) throws IOException {
        byte[] characters;
        if (stringValue == null) {
            characters = null;
        }
        else {
            characters = stringValue.getBytes(StandardCharsets.UTF_8);
        }
        writeByteArray(os, characters);
    }
    
    public static void writeByteArray(final OutputStream os, final byte[] byteArray) throws IOException {
        if (byteArray == null) {
            writeSdword(os, -1);
        }
        else {
            writeSdword(os, byteArray.length);
            writeBytes(os, byteArray);
        }
    }
    
    public static void writefloat(final OutputStream os, final float floatValue) throws IOException {
        writeSdword(os, Float.floatToIntBits(floatValue));
    }
    
    public static void readBytes(final InputStream is, final byte[] byteArray) throws IOException {
        int amt;
        for (int amtSoFar = 0; amtSoFar < byteArray.length; amtSoFar += amt) {
            amt = is.read(byteArray, amtSoFar, byteArray.length - amtSoFar);
            if (amt == -1) {
                throw new IOException("Unexpected EOF");
            }
        }
    }
    
    public static int readByte(final InputStream is) throws IOException {
        final byte[] inputArray = { 0 };
        readBytes(is, inputArray);
        return inputArray[0] & 0xFF;
    }
    
    public static int readWord(final InputStream is) throws IOException {
        final byte[] inputArray = new byte[2];
        readBytes(is, inputArray);
        return (inputArray[0] & 0xFF) + ((inputArray[1] & 0xFF) << 8);
    }
    
    public static int readDword(final InputStream is) throws IOException {
        final byte[] inputArray = new byte[4];
        readBytes(is, inputArray);
        return (inputArray[0] & 0xFF) + ((inputArray[1] & 0xFF) << 8) + ((inputArray[2] & 0xFF) << 16) + ((inputArray[3] & 0xFF) << 24);
    }
    
    public static int readSdword(final InputStream is) throws IOException {
        final byte[] inputArray = new byte[4];
        readBytes(is, inputArray);
        return (inputArray[0] & 0xFF) + ((inputArray[1] & 0xFF) << 8) + ((inputArray[2] & 0xFF) << 16) + (inputArray[3] << 24);
    }
    
    public static Long readLong(final InputStream is) throws IOException {
        final int value = readByte(is);
        if (value == 1) {
            return null;
        }
        final byte[] inputArray = new byte[8];
        readBytes(is, inputArray);
        return new Long((inputArray[0] & 0xFF) + Long.rotateLeft(inputArray[1] & 0xFF, 8) + Long.rotateLeft(inputArray[2] & 0xFF, 16) + Long.rotateLeft(inputArray[3] & 0xFF, 24) + Long.rotateLeft(inputArray[4] & 0xFF, 32) + Long.rotateLeft(inputArray[5] & 0xFF, 40) + Long.rotateLeft(inputArray[6] & 0xFF, 48) + Long.rotateLeft(inputArray[7] & 0xFF, 56));
    }
    
    public static String readString(final InputStream is) throws IOException {
        final byte[] bytes = readByteArray(is);
        if (bytes == null) {
            return null;
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
    
    public static byte[] readByteArray(final InputStream is) throws IOException {
        final int length = readSdword(is);
        if (length == -1) {
            return null;
        }
        final byte[] byteArray = new byte[length];
        readBytes(is, byteArray);
        return byteArray;
    }
    
    public static float readfloat(final InputStream os) throws IOException {
        return Float.intBitsToFloat(readSdword(os));
    }
    
    public static void addShutdownHook(final IShutdownHook hook) {
        synchronized (ManifoldCF.cleanupHooks) {
            ManifoldCF.cleanupHooks.add(hook);
        }
    }
    
    public static void addPollingHook(final IPollingHook hook) {
        synchronized (ManifoldCF.pollingHooks) {
            ManifoldCF.pollingHooks.add(hook);
        }
    }
    
    public static void pollAll(final IThreadContext threadContext) throws ManifoldCFException {
        synchronized (ManifoldCF.pollingHooks) {
            for (final IPollingHook hook : ManifoldCF.pollingHooks) {
                hook.doPoll(threadContext);
            }
        }
    }
    
    public static ManifoldCFResourceLoader createResourceLoader() throws ManifoldCFException {
        return new ManifoldCFResourceLoader(ManifoldCF.resourceLoader.getClassLoader());
    }
    
    public static Class findClass(final String cname) throws ClassNotFoundException, ManifoldCFException {
        return ManifoldCF.resourceLoader.findClass(cname);
    }
    
    @Deprecated
    public static void cleanUpEnvironment() {
        cleanUpEnvironment(ThreadContextFactory.make());
    }
    
    public static void cleanUpEnvironment(final IThreadContext threadContext) {
        synchronized (ManifoldCF.initializeFlagLock) {
            --ManifoldCF.initializeLevel;
            if (ManifoldCF.initializeLevel == 0 && !ManifoldCF.alreadyShutdown) {
                synchronized (ManifoldCF.cleanupHooks) {
                    int i = ManifoldCF.cleanupHooks.size();
                    while (i > 0) {
                        --i;
                        final IShutdownHook hook = ManifoldCF.cleanupHooks.get(i);
                        try {
                            hook.doCleanup(threadContext);
                        }
                        catch (ManifoldCFException e) {
                            Logging.root.warn((Object)("Error during system shutdown: " + e.getMessage()), (Throwable)e);
                        }
                    }
                    ManifoldCF.cleanupHooks.clear();
                }
                synchronized (ManifoldCF.pollingHooks) {
                    ManifoldCF.pollingHooks.clear();
                }
                ManifoldCF.alreadyShutdown = true;
            }
        }
    }
    
    static {
        ManifoldCF.processID = null;
        ManifoldCF.workingDirectory = null;
        ManifoldCF.resourceLoader = null;
        ManifoldCF.tracker = null;
        ManifoldCF.dbShutdown = null;
        cleanupHooks = new ArrayList<IShutdownHook>();
        pollingHooks = new ArrayList<IPollingHook>();
        ManifoldCF.shutdownThread = new ShutdownThread();
        try {
            Runtime.getRuntime().addShutdownHook(ManifoldCF.shutdownThread);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        catch (Error e2) {
            e2.printStackTrace();
        }
        ManifoldCF.initializeLevel = 0;
        ManifoldCF.alreadyClosed = false;
        ManifoldCF.alreadyShutdown = false;
        ManifoldCF.initializeFlagLock = new Integer(0);
        ManifoldCF.mcfVersion = null;
        ManifoldCF.masterDatabaseName = null;
        ManifoldCF.masterDatabaseUsername = null;
        ManifoldCF.masterDatabasePassword = null;
        ManifoldCF.localConfiguration = null;
        ManifoldCF.propertyFilelastMod = -1L;
        ManifoldCF.propertyFilePath = null;
        ManifoldCF.OBFUSCATION_PASSCODE = "NowIsTheTime";
        ManifoldCF.OBFUSCATION_SALT = "Salty";
    }
    
    protected static class OverrideableManifoldCFConfiguration extends ManifoldCFConfiguration
    {
        public OverrideableManifoldCFConfiguration() {
        }
        
        @Override
        public String getProperty(final String s) {
            String rval = System.getProperty(s);
            if (rval == null) {
                rval = super.getProperty(s);
            }
            return rval;
        }
    }
    
    protected static class FileTrack implements IShutdownHook
    {
        protected Set<File> filesToDelete;
        
        public FileTrack() {
            this.filesToDelete = new HashSet<File>();
        }
        
        public void addFile(final File f) {
            synchronized (this) {
                this.filesToDelete.add(f);
            }
        }
        
        public void deleteFile(final File f) {
            ManifoldCF.recursiveDelete(f);
            synchronized (this) {
                this.filesToDelete.remove(f);
            }
        }
        
        @Override
        public void doCleanup(final IThreadContext threadContext) throws ManifoldCFException {
            synchronized (this) {
                for (final File f : this.filesToDelete) {
                    f.delete();
                }
                this.filesToDelete.clear();
            }
        }
        
        @Override
        protected void finalize() throws Throwable {
            try {
                this.doCleanup(ThreadContextFactory.make());
            }
            finally {
                super.finalize();
            }
        }
    }
    
    protected static class CachePoll implements IPollingHook
    {
        public CachePoll() {
        }
        
        @Override
        public void doPoll(final IThreadContext threadContext) throws ManifoldCFException {
            final ICacheManager cacheManager = CacheManagerFactory.make(threadContext);
            cacheManager.expireObjects(System.currentTimeMillis());
        }
    }
    
    protected static class DatabaseShutdown implements IShutdownHook
    {
        public DatabaseShutdown() {
        }
        
        @Override
        public void doCleanup(final IThreadContext threadContext) throws ManifoldCFException {
            final Thread t = new DatabaseConnectionReleaseThread();
            t.start();
            try {
                t.join(15000L);
            }
            catch (InterruptedException ex) {}
            this.closeDatabase();
        }
        
        protected void closeDatabase() throws ManifoldCFException {
            synchronized (ManifoldCF.initializeFlagLock) {
                if (ManifoldCF.initializeLevel == 0 && !ManifoldCF.alreadyClosed) {
                    final IThreadContext threadcontext = ThreadContextFactory.make();
                    final String databaseName = ManifoldCF.getMasterDatabaseName();
                    final String databaseUsername = ManifoldCF.getMasterDatabaseUsername();
                    final String databasePassword = ManifoldCF.getMasterDatabasePassword();
                    DBInterfaceFactory.make(threadcontext, databaseName, databaseUsername, databasePassword).closeDatabase();
                    ManifoldCF.alreadyClosed = true;
                }
            }
        }
        
        @Override
        protected void finalize() throws Throwable {
            try {
                this.closeDatabase();
            }
            finally {
                super.finalize();
            }
        }
    }
    
    protected static class ShutdownThread extends Thread
    {
        public ShutdownThread() {
            this.setName("Shutdown thread");
        }
        
        @Override
        public void run() {
            ManifoldCF.cleanUpEnvironment(ThreadContextFactory.make());
        }
    }
    
    protected static class DatabaseConnectionReleaseThread extends Thread
    {
        public DatabaseConnectionReleaseThread() {
            this.setName("Database connection release thread");
            this.setDaemon(true);
        }
        
        @Override
        public void run() {
            ConnectionFactory.releaseAll();
        }
    }
}
