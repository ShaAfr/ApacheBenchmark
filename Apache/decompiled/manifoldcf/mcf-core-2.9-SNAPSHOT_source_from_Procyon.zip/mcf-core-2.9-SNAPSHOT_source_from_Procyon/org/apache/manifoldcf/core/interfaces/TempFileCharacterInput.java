// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.InputStreamReader;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import org.apache.manifoldcf.core.system.ManifoldCF;
import java.io.IOException;
import java.io.Reader;
import java.io.File;

public class TempFileCharacterInput extends CharacterInput
{
    public static final String _rcsid = "@(#)$Id: TempFileCharacterInput.java 988245 2010-08-23 18:39:35Z kwright $";
    protected File file;
    protected byte[] inMemoryBuffer;
    protected static final int CHUNK_SIZE = 65536;
    protected static final int DEFAULT_MAX_MEM_SIZE = 8192;
    
    public TempFileCharacterInput(final Reader is) throws ManifoldCFException, IOException {
        this(is, -1L);
    }
    
    public TempFileCharacterInput(final Reader is, final long length) throws ManifoldCFException, IOException {
        this(is, length, 8192);
    }
    
    public TempFileCharacterInput(final Reader is, final long length, final int maxInMemoryLength) throws ManifoldCFException, IOException {
        final int chunkSize = 65536;
        final char[] buffer = new char[chunkSize];
        int chunkTotal = 0;
        boolean eofSeen = false;
        while (true) {
            int chunkAmount;
            if (length == -1L || length > chunkSize) {
                chunkAmount = chunkSize - chunkTotal;
            }
            else {
                chunkAmount = (int)(length - chunkTotal);
                eofSeen = true;
            }
            if (chunkAmount == 0) {
                break;
            }
            final int readsize = is.read(buffer, chunkTotal, chunkAmount);
            if (readsize == -1) {
                eofSeen = true;
                break;
            }
            chunkTotal += readsize;
        }
        final MessageDigest md = ManifoldCF.startHash();
        final String chunkString = new String(buffer, 0, chunkTotal);
        ManifoldCF.addToHash(md, chunkString);
        byte[] byteBuffer;
        if (eofSeen) {
            byteBuffer = chunkString.getBytes(StandardCharsets.UTF_8);
        }
        else {
            byteBuffer = null;
        }
        if (eofSeen && byteBuffer.length <= maxInMemoryLength) {
            this.file = null;
            this.inMemoryBuffer = byteBuffer;
            this.charLength = chunkTotal;
            this.hashValue = ManifoldCF.getHashValue(md);
        }
        else {
            this.inMemoryBuffer = null;
            long totalMoved = 0L;
            File outfile;
            try {
                outfile = File.createTempFile("_MC_", "");
            }
            catch (IOException e) {
                CharacterInput.handleIOException(e, "creating backing file");
                outfile = null;
            }
            try {
                ManifoldCF.addFile(outfile);
                OutputStreamWriter outWriter;
                try {
                    final FileOutputStream outStream = new FileOutputStream(outfile);
                    outWriter = new OutputStreamWriter(outStream, StandardCharsets.UTF_8);
                }
                catch (IOException e2) {
                    CharacterInput.handleIOException(e2, "opening backing file");
                    final FileOutputStream outStream = null;
                    outWriter = null;
                }
                try {
                    try {
                        outWriter.write(buffer, 0, chunkTotal);
                    }
                    catch (IOException e2) {
                        CharacterInput.handleIOException(e2, "writing backing file");
                    }
                    totalMoved += chunkTotal;
                    while (true) {
                        int moveAmount;
                        if (length == -1L || length - totalMoved > chunkSize) {
                            moveAmount = chunkSize;
                        }
                        else {
                            moveAmount = (int)(length - totalMoved);
                        }
                        if (moveAmount == 0) {
                            break;
                        }
                        final int readsize2 = is.read(buffer, 0, moveAmount);
                        if (readsize2 == -1) {
                            break;
                        }
                        try {
                            outWriter.write(buffer, 0, readsize2);
                        }
                        catch (IOException e3) {
                            CharacterInput.handleIOException(e3, "writing backing file");
                        }
                        ManifoldCF.addToHash(md, new String(buffer, 0, readsize2));
                        totalMoved += readsize2;
                    }
                }
                finally {
                    try {
                        outWriter.close();
                    }
                    catch (IOException e4) {
                        CharacterInput.handleIOException(e4, "closing backing file");
                    }
                }
                this.file = outfile;
                this.charLength = totalMoved;
                this.hashValue = ManifoldCF.getHashValue(md);
            }
            catch (Throwable e5) {
                ManifoldCF.deleteFile(outfile);
                if (e5 instanceof Error) {
                    throw (Error)e5;
                }
                if (e5 instanceof RuntimeException) {
                    throw (RuntimeException)e5;
                }
                if (e5 instanceof ManifoldCFException) {
                    throw (ManifoldCFException)e5;
                }
                if (e5 instanceof IOException) {
                    throw (IOException)e5;
                }
                throw new RuntimeException("Unexpected throwable of type " + e5.getClass().getName() + ": " + e5.getMessage(), e5);
            }
        }
    }
    
    public TempFileCharacterInput(final File tempFile) {
        this.inMemoryBuffer = null;
        ManifoldCF.addFile(this.file = tempFile);
    }
    
    protected TempFileCharacterInput() {
    }
    
    @Override
    public InputStream getUtf8Stream() throws ManifoldCFException {
        if (this.file != null) {
            try {
                return new FileInputStream(this.file);
            }
            catch (FileNotFoundException e) {
                throw new ManifoldCFException("No such file: " + e.getMessage(), e, 0);
            }
        }
        if (this.inMemoryBuffer != null) {
            return new ByteArrayInputStream(this.inMemoryBuffer);
        }
        return null;
    }
    
    @Override
    public long getUtf8StreamLength() throws ManifoldCFException {
        if (this.file != null) {
            return this.file.length();
        }
        if (this.inMemoryBuffer != null) {
            return this.inMemoryBuffer.length;
        }
        return 0L;
    }
    
    @Override
    protected void openStream() throws ManifoldCFException {
        if (this.file != null) {
            try {
                final InputStream binaryStream = new FileInputStream(this.file);
                this.stream = new InputStreamReader(binaryStream, StandardCharsets.UTF_8);
                return;
            }
            catch (FileNotFoundException e) {
                throw new ManifoldCFException("Can't create stream: " + e.getMessage(), e, 0);
            }
        }
        if (this.inMemoryBuffer != null) {
            this.stream = new InputStreamReader(new ByteArrayInputStream(this.inMemoryBuffer), StandardCharsets.UTF_8);
        }
    }
    
    @Override
    public CharacterInput transfer() {
        final TempFileCharacterInput rval = new TempFileCharacterInput();
        rval.file = this.file;
        rval.inMemoryBuffer = this.inMemoryBuffer;
        rval.stream = this.stream;
        rval.charLength = this.charLength;
        rval.hashValue = this.hashValue;
        this.file = null;
        this.inMemoryBuffer = null;
        this.stream = null;
        this.charLength = -1L;
        this.hashValue = null;
        return rval;
    }
    
    @Override
    public void discard() throws ManifoldCFException {
        super.discard();
        if (this.file != null) {
            ManifoldCF.deleteFile(this.file);
            this.file = null;
        }
    }
    
    @Override
    protected void calculateLength() throws ManifoldCFException {
        this.scanFile();
    }
    
    @Override
    protected void calculateHashValue() throws ManifoldCFException {
        this.scanFile();
    }
    
    private void scanFile() throws ManifoldCFException {
        try {
            InputStream binaryStream;
            if (this.file != null) {
                binaryStream = new FileInputStream(this.file);
            }
            else if (this.inMemoryBuffer != null) {
                binaryStream = new ByteArrayInputStream(this.inMemoryBuffer);
            }
            else {
                binaryStream = null;
            }
            final Reader reader = new InputStreamReader(binaryStream, StandardCharsets.UTF_8);
            try {
                final MessageDigest md = ManifoldCF.startHash();
                final char[] buffer = new char[65536];
                long totalMoved = 0L;
                while (true) {
                    final int moveAmount = 65536;
                    final int readsize = reader.read(buffer, 0, moveAmount);
                    if (readsize == -1) {
                        break;
                    }
                    ManifoldCF.addToHash(md, new String(buffer, 0, readsize));
                    totalMoved += readsize;
                }
                this.charLength = totalMoved;
                this.hashValue = ManifoldCF.getHashValue(md);
            }
            finally {
                reader.close();
            }
        }
        catch (IOException e) {
            CharacterInput.handleIOException(e, "scanning file");
        }
    }
}
