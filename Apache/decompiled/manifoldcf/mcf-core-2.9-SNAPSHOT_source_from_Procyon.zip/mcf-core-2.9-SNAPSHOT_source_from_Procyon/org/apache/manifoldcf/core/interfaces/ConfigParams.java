// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import org.apache.manifoldcf.core.system.ManifoldCF;
import java.io.InputStream;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;

public class ConfigParams extends Configuration
{
    public static final String _rcsid = "@(#)$Id: ConfigParams.java 988245 2010-08-23 18:39:35Z kwright $";
    protected static final String PARAMETER_TYPE = "_PARAMETER_";
    protected static final String ATTR_NAME = "name";
    protected Map<String, String> params;
    
    public ConfigParams() {
        super("configuration");
        this.params = new HashMap<String, String>();
    }
    
    public ConfigParams(final Map<String, String> map) {
        super("configuration");
        this.params = new HashMap<String, String>();
        for (final String key : map.keySet()) {
            final String value = map.get(key);
            final ConfigNode cn = new ConfigNode("_PARAMETER_");
            cn.setAttribute("name", key);
            cn.setValue(value);
            this.addChild(this.getChildCount(), cn);
        }
    }
    
    public ConfigParams(final String xml) throws ManifoldCFException {
        super("configuration");
        this.params = new HashMap<String, String>();
        this.fromXML(xml);
    }
    
    public ConfigParams(final InputStream xmlstream) throws ManifoldCFException {
        super("configuration");
        this.params = new HashMap<String, String>();
        this.fromXML(xmlstream);
    }
    
    @Override
    protected Configuration createNew() {
        return new ConfigParams();
    }
    
    @Override
    protected ConfigurationNode createNewNode(final String type) {
        return new ConfigNode(type);
    }
    
    @Override
    protected void clearOuterNodes() {
        this.params.clear();
    }
    
    @Override
    protected void addOuterNode(final ConfigurationNode node) {
        if (node.getType().equals("_PARAMETER_")) {
            final String name = node.getAttributeValue("name");
            final String value = node.getValue();
            if (name != null && value != null) {
                this.params.put(name, value);
            }
        }
    }
    
    @Override
    protected void removeOuterNode(final ConfigurationNode node) {
        if (node.getType().equals("_PARAMETER_")) {
            final String name = node.getAttributeValue("name");
            if (name != null) {
                this.params.remove(name);
            }
        }
    }
    
    public String getParameter(final String key) {
        return this.params.get(key);
    }
    
    public String getObfuscatedParameter(final String key) {
        final String rval = this.getParameter(key);
        if (rval == null) {
            return rval;
        }
        try {
            return ManifoldCF.deobfuscate(rval);
        }
        catch (ManifoldCFException e) {
            return "";
        }
    }
    
    public void setParameter(final String key, final String value) {
        if (this.params.get(key) != null) {
            for (int i = 0; i < this.children.size(); ++i) {
                final ConfigNode node = this.children.get(i);
                if (node.getType().equals("_PARAMETER_")) {
                    final String name = node.getAttributeValue("name");
                    if (name.equals(key)) {
                        this.removeChild(i);
                        break;
                    }
                }
            }
        }
        if (value != null) {
            final ConfigNode cn = new ConfigNode("_PARAMETER_");
            cn.setAttribute("name", key);
            cn.setValue(value);
            this.addChild(this.getChildCount(), cn);
        }
    }
    
    public void setObfuscatedParameter(final String key, String value) {
        if (value != null) {
            try {
                value = ManifoldCF.obfuscate(value);
            }
            catch (ManifoldCFException e) {
                value = "";
            }
        }
        this.setParameter(key, value);
    }
    
    public Iterator listParameters() {
        return this.params.keySet().iterator();
    }
    
    public ConfigParams duplicate() {
        return (ConfigParams)this.createDuplicate(false);
    }
    
    public ConfigNode getChild(final int index) {
        return (ConfigNode)this.findChild(index);
    }
}
