// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public class Specification extends Configuration
{
    public static final String _rcsid = "@(#)$Id: Specification.java 988245 2010-08-23 18:39:35Z kwright $";
    
    public Specification() {
        super("specification");
    }
    
    public Specification(final String xml) throws ManifoldCFException {
        super("specification");
        this.fromXML(xml);
    }
    
    @Override
    protected Configuration createNew() {
        return new Specification();
    }
    
    @Override
    protected ConfigurationNode createNewNode(final String type) {
        return new SpecificationNode(type);
    }
    
    public SpecificationNode getChild(final int index) {
        return (SpecificationNode)this.findChild(index);
    }
    
    public Specification duplicate(final boolean readOnly) {
        if (readOnly && this.readOnly) {
            return this;
        }
        final Specification rval = new Specification();
        int i = 0;
        while (i < this.children.size()) {
            final SpecificationNode node = this.children.get(i++);
            rval.children.add(node.duplicate(readOnly));
        }
        rval.readOnly = readOnly;
        return rval;
    }
}
