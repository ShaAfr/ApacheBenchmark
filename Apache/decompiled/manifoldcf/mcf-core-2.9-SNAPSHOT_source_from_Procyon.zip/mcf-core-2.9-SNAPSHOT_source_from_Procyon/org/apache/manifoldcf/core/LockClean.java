// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core;

import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.io.File;
import org.apache.manifoldcf.core.system.Logging;
import org.apache.manifoldcf.core.lockmanager.FileLockManager;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.interfaces.ThreadContextFactory;

public class LockClean implements InitializationCommand
{
    public static final String _rcsid = "@(#)$Id: LockClean.java 988245 2010-08-23 18:39:35Z kwright $";
    
    @Override
    public void execute() throws ManifoldCFException {
        ManifoldCF.initializeEnvironment(ThreadContextFactory.make());
        final File synchDir = FileLockManager.getSynchDirectoryProperty();
        if (synchDir != null && synchDir.isDirectory()) {
            this.removeContentsOfDirectory(synchDir);
        }
        Logging.root.info((Object)"Synchronization storage cleaned up");
    }
    
    private void removeContentsOfDirectory(final File directory) {
        final File[] files = directory.listFiles();
        for (int i = 0; i < files.length; ++i) {
            if (files[i].isDirectory()) {
                this.removeDirectory(files[i]);
            }
            else {
                files[i].delete();
            }
        }
    }
    
    private void removeDirectory(final File directory) {
        this.removeContentsOfDirectory(directory);
        directory.delete();
    }
    
    public static void main(final String[] args) {
        if (args.length != 0) {
            System.err.println("Usage: LockClean");
            System.exit(1);
        }
        final LockClean lockClean = new LockClean();
        try {
            lockClean.execute();
            System.err.println("Synchronization storage cleaned up");
        }
        catch (ManifoldCFException e) {
            e.printStackTrace(System.err);
            System.exit(2);
        }
    }
}
