// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.IThreadContext;

public class DBInterfaceMariaDB extends DBInterfaceMySQL
{
    private static final String _driver = "org.mariadb.jdbc.Driver";
    
    public DBInterfaceMariaDB(final IThreadContext tc, final String databaseName, final String userName, final String password) throws ManifoldCFException {
        super(tc, "org.mariadb.jdbc.Driver", databaseName, userName, password);
    }
    
    @Override
    protected String getJdbcDriverClass() {
        return "org.mariadb.jdbc.Driver";
    }
}
