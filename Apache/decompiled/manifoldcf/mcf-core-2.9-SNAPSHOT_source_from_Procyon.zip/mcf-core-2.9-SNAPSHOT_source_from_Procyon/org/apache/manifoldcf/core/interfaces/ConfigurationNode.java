// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class ConfigurationNode implements IHierarchyParent
{
    public static final String _rcsid = "@(#)$Id: ConfigurationNode.java 988245 2010-08-23 18:39:35Z kwright $";
    protected List<ConfigurationNode> children;
    protected Map<String, String> attributes;
    protected String type;
    protected String value;
    protected boolean readOnly;
    
    public ConfigurationNode(final String type) {
        this.children = null;
        this.attributes = null;
        this.type = null;
        this.value = null;
        this.readOnly = false;
        this.type = type;
    }
    
    public ConfigurationNode(final ConfigurationNode source) {
        this.children = null;
        this.attributes = null;
        this.type = null;
        this.value = null;
        this.readOnly = false;
        this.type = source.type;
        this.value = source.value;
        this.readOnly = source.readOnly;
        if (source.attributes != null) {
            for (final String attribute : source.attributes.keySet()) {
                final String attrValue = source.attributes.get(attribute);
                if (this.attributes == null) {
                    this.attributes = new HashMap<String, String>();
                }
                this.attributes.put(attribute, attrValue);
            }
        }
        int i = 0;
        while (i < source.getChildCount()) {
            final ConfigurationNode child = source.findChild(i++);
            this.addChild(this.getChildCount(), this.createNewNode(child));
        }
    }
    
    protected ConfigurationNode createNewNode() {
        return new ConfigurationNode(this.type);
    }
    
    protected ConfigurationNode createNewNode(final ConfigurationNode source) {
        return new ConfigurationNode(source);
    }
    
    public void makeReadOnly() {
        if (this.readOnly) {
            return;
        }
        if (this.children != null) {
            int i = 0;
            while (i < this.children.size()) {
                final ConfigurationNode child = this.children.get(i++);
                child.makeReadOnly();
            }
        }
        this.readOnly = true;
    }
    
    protected ConfigurationNode createDuplicate(final boolean readOnly) {
        if (readOnly && this.readOnly) {
            return this;
        }
        final ConfigurationNode rval = this.createNewNode();
        rval.value = this.value;
        if (this.attributes != null) {
            rval.attributes = cloneAttributes(this.attributes);
        }
        if (this.children != null) {
            rval.children = new ArrayList<ConfigurationNode>();
            int i = 0;
            while (i < this.children.size()) {
                final ConfigurationNode node = this.children.get(i++);
                rval.children.add(node.createDuplicate(readOnly));
            }
        }
        rval.readOnly = readOnly;
        return rval;
    }
    
    public String getType() {
        return this.type;
    }
    
    public void setValue(final String value) {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        this.value = value;
    }
    
    public String getValue() {
        return this.value;
    }
    
    @Override
    public int getChildCount() {
        if (this.children == null) {
            return 0;
        }
        return this.children.size();
    }
    
    @Override
    public ConfigurationNode findChild(final int index) {
        return this.children.get(index);
    }
    
    @Override
    public void removeChild(final int index) {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        if (this.children != null) {
            this.children.remove(index);
            if (this.children.size() == 0) {
                this.children = null;
            }
        }
    }
    
    @Override
    public void addChild(final int index, final ConfigurationNode child) {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        if (this.children == null) {
            this.children = new ArrayList<ConfigurationNode>();
        }
        this.children.add(index, child);
    }
    
    @Override
    public void clearChildren() {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        this.children.clear();
    }
    
    public void setAttribute(final String attribute, final String value) {
        if (this.readOnly) {
            throw new IllegalStateException("Attempt to change read-only object");
        }
        if (value == null) {
            if (this.attributes != null) {
                this.attributes.remove(attribute);
                if (this.attributes.size() == 0) {
                    this.attributes = null;
                }
            }
        }
        else {
            if (this.attributes == null) {
                this.attributes = new HashMap<String, String>();
            }
            this.attributes.put(attribute, value);
        }
    }
    
    public int getAttributeCount() {
        if (this.attributes == null) {
            return 0;
        }
        return this.attributes.size();
    }
    
    public Iterator<String> getAttributes() {
        if (this.attributes == null) {
            return new HashMap<String, Object>().keySet().iterator();
        }
        return this.attributes.keySet().iterator();
    }
    
    public String getAttributeValue(final String attribute) {
        if (this.attributes == null) {
            return null;
        }
        return this.attributes.get(attribute);
    }
    
    @Override
    public int hashCode() {
        int rval = this.type.hashCode();
        if (this.value != null) {
            rval += this.value.hashCode();
        }
        if (this.attributes != null) {
            for (final String key : this.attributes.keySet()) {
                final String attrValue = this.attributes.get(key);
                rval += key.hashCode() + attrValue.hashCode();
            }
        }
        if (this.children != null) {
            for (int i = 0; i < this.children.size(); rval += this.children.get(i++).hashCode()) {}
        }
        return rval;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof ConfigurationNode)) {
            return false;
        }
        final ConfigurationNode n = (ConfigurationNode)o;
        if (((this.attributes == null) ? 0 : this.attributes.size()) != ((n.attributes == null) ? 0 : n.attributes.size())) {
            return false;
        }
        if (((this.children == null) ? 0 : this.children.size()) != ((n.children == null) ? 0 : n.children.size())) {
            return false;
        }
        if (!this.type.equals(n.type)) {
            return false;
        }
        if (this.value == null || n.value == null) {
            if (this.value != n.value) {
                return false;
            }
        }
        else if (!this.value.equals(n.value)) {
            return false;
        }
        if (this.attributes != null && n.attributes != null) {
            for (final String key : this.attributes.keySet()) {
                final String attrValue = this.attributes.get(key);
                final String nAttrValue = n.attributes.get(key);
                if (nAttrValue == null || !attrValue.equals(nAttrValue)) {
                    return false;
                }
            }
        }
        if (this.children != null && n.children != null) {
            for (int i = 0; i < this.children.size(); ++i) {
                final ConfigurationNode child = this.children.get(i);
                final ConfigurationNode nChild = n.children.get(i);
                if (!child.equals(nChild)) {
                    return false;
                }
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(this.type);
        if (this.value != null) {
            sb.append(":").append(this.value);
        }
        if (this.attributes != null) {
            final Iterator<String> iter = this.attributes.keySet().iterator();
            while (iter.hasNext()) {
                sb.append(" ");
                final String key = iter.next();
                final String attrValue = this.attributes.get(key);
                sb.append(key).append("='").append(attrValue).append("'");
            }
        }
        sb.append(" [");
        if (this.children != null) {
            int i = 0;
            while (i < this.children.size()) {
                if (i > 0) {
                    sb.append(", ");
                }
                final ConfigurationNode cn = this.children.get(i++);
                sb.append(cn.toString());
            }
        }
        sb.append("])");
        return sb.toString();
    }
    
    protected static Map<String, String> cloneAttributes(final Map<String, String> attributes) {
        final Map<String, String> rval = new HashMap<String, String>();
        for (final Map.Entry<String, String> entry : attributes.entrySet()) {
            rval.put(entry.getKey(), entry.getValue());
        }
        return rval;
    }
}
