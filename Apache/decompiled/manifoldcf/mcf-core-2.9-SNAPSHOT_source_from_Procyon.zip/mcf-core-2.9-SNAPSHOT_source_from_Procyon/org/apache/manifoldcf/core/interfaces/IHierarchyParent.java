// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IHierarchyParent
{
    public static final String _rcsid = "@(#)$Id$";
    
    void clearChildren();
    
    int getChildCount();
    
    ConfigurationNode findChild(final int p0);
    
    void removeChild(final int p0);
    
    void addChild(final int p0, final ConfigurationNode p1);
}
