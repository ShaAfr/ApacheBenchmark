// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.manifoldcf.core.system.ManifoldCF;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;

public class TempFileInput extends BinaryInput
{
    public static final String _rcsid = "@(#)$Id: TempFileInput.java 988245 2010-08-23 18:39:35Z kwright $";
    protected File file;
    protected byte[] inMemoryBuffer;
    protected static final int CHUNK_SIZE = 65536;
    protected static final int DEFAULT_MAX_MEM_SIZE = 8192;
    
    public TempFileInput(final InputStream is) throws ManifoldCFException, IOException {
        this(is, -1L);
    }
    
    public TempFileInput(final InputStream is, final long length) throws ManifoldCFException, IOException {
        this(is, length, 8192);
    }
    
    public TempFileInput(final InputStream is, final long length, final int maxMemSize) throws ManifoldCFException, IOException {
        final int chunkSize = 65536;
        final byte[] buffer = new byte[chunkSize];
        int chunkTotal = 0;
        boolean eofSeen = false;
        while (true) {
            int chunkAmount;
            if (length == -1L || length > chunkSize) {
                chunkAmount = chunkSize - chunkTotal;
            }
            else {
                chunkAmount = (int)(length - chunkTotal);
                eofSeen = true;
            }
            if (chunkAmount == 0) {
                break;
            }
            final int readsize = is.read(buffer, chunkTotal, chunkAmount);
            if (readsize == -1) {
                eofSeen = true;
                break;
            }
            chunkTotal += readsize;
        }
        if (eofSeen && chunkTotal < maxMemSize) {
            this.file = null;
            this.inMemoryBuffer = new byte[chunkTotal];
            for (int i = 0; i < this.inMemoryBuffer.length; ++i) {
                this.inMemoryBuffer[i] = buffer[i];
            }
            this.length = chunkTotal;
        }
        else {
            this.inMemoryBuffer = null;
            File outfile;
            try {
                outfile = File.createTempFile("_MC_", "");
            }
            catch (IOException e) {
                BinaryInput.handleIOException(e, "creating backing file");
                outfile = null;
            }
            try {
                ManifoldCF.addFile(outfile);
                FileOutputStream outStream;
                try {
                    outStream = new FileOutputStream(outfile);
                }
                catch (IOException e2) {
                    BinaryInput.handleIOException(e2, "opening backing file");
                    outStream = null;
                }
                try {
                    long totalMoved = 0L;
                    try {
                        outStream.write(buffer, 0, chunkTotal);
                    }
                    catch (IOException e3) {
                        BinaryInput.handleIOException(e3, "writing backing file");
                    }
                    totalMoved += chunkTotal;
                    while (true) {
                        int moveAmount;
                        if (length == -1L || length - totalMoved > chunkSize) {
                            moveAmount = chunkSize;
                        }
                        else {
                            moveAmount = (int)(length - totalMoved);
                        }
                        if (moveAmount == 0) {
                            break;
                        }
                        final int readsize2 = is.read(buffer, 0, moveAmount);
                        if (readsize2 == -1) {
                            break;
                        }
                        try {
                            outStream.write(buffer, 0, readsize2);
                        }
                        catch (IOException e4) {
                            BinaryInput.handleIOException(e4, "writing backing file");
                        }
                        totalMoved += readsize2;
                    }
                }
                finally {
                    try {
                        outStream.close();
                    }
                    catch (IOException e5) {
                        BinaryInput.handleIOException(e5, "closing backing file");
                    }
                }
                this.file = outfile;
                this.length = this.file.length();
            }
            catch (Throwable e6) {
                ManifoldCF.deleteFile(outfile);
                if (e6 instanceof Error) {
                    throw (Error)e6;
                }
                if (e6 instanceof RuntimeException) {
                    throw (RuntimeException)e6;
                }
                if (e6 instanceof ManifoldCFException) {
                    throw (ManifoldCFException)e6;
                }
                if (e6 instanceof IOException) {
                    throw (IOException)e6;
                }
                throw new RuntimeException("Unexpected throwable of type " + e6.getClass().getName() + ": " + e6.getMessage(), e6);
            }
        }
    }
    
    public TempFileInput(final File tempFile) {
        this.inMemoryBuffer = null;
        ManifoldCF.addFile(this.file = tempFile);
    }
    
    protected TempFileInput() {
    }
    
    @Override
    public BinaryInput transfer() {
        final TempFileInput rval = new TempFileInput();
        rval.file = this.file;
        rval.inMemoryBuffer = this.inMemoryBuffer;
        rval.stream = this.stream;
        rval.length = this.length;
        this.file = null;
        this.inMemoryBuffer = null;
        this.stream = null;
        this.length = -1L;
        return rval;
    }
    
    @Override
    public void discard() throws ManifoldCFException {
        super.discard();
        if (this.file != null) {
            ManifoldCF.deleteFile(this.file);
            this.file = null;
        }
    }
    
    @Override
    protected void openStream() throws ManifoldCFException {
        if (this.file != null) {
            try {
                this.stream = new FileInputStream(this.file);
                return;
            }
            catch (FileNotFoundException e) {
                throw new ManifoldCFException("Can't create stream: " + e.getMessage(), e, 0);
            }
        }
        if (this.inMemoryBuffer != null) {
            this.stream = new ByteArrayInputStream(this.inMemoryBuffer);
        }
    }
    
    @Override
    protected void calculateLength() throws ManifoldCFException {
        if (this.file != null) {
            this.length = this.file.length();
        }
        else if (this.inMemoryBuffer != null) {
            this.length = this.inMemoryBuffer.length;
        }
    }
}
