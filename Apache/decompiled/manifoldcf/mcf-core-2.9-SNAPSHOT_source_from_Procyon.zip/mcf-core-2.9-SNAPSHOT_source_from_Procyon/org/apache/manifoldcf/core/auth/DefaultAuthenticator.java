// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.auth;

import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import org.apache.manifoldcf.core.interfaces.IAuth;

public class DefaultAuthenticator implements IAuth
{
    public static final String loginUserNameProperty = "org.apache.manifoldcf.login.name";
    public static final String loginPasswordProperty = "org.apache.manifoldcf.login.password";
    public static final String apiLoginUserNameProperty = "org.apache.manifoldcf.apilogin.name";
    public static final String apiLoginPasswordProperty = "org.apache.manifoldcf.apilogin.password";
    protected final String loginUserName;
    protected final String loginPassword;
    protected final String apiLoginUserName;
    protected final String apiLoginPassword;
    
    public DefaultAuthenticator(final IThreadContext threadContext) throws ManifoldCFException {
        this.loginUserName = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.login.name", "admin");
        this.loginPassword = LockManagerFactory.getPossiblyObfuscatedStringProperty(threadContext, "org.apache.manifoldcf.login.password", "admin");
        this.apiLoginUserName = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.apilogin.name", "");
        this.apiLoginPassword = LockManagerFactory.getPossiblyObfuscatedStringProperty(threadContext, "org.apache.manifoldcf.apilogin.password", "");
    }
    
    @Override
    public boolean verifyUILogin(final String userId, final String password) throws ManifoldCFException {
        return userId != null && password != null && userId.equals(this.loginUserName) && password.equals(this.loginPassword);
    }
    
    @Override
    public boolean verifyAPILogin(final String userId, final String password) throws ManifoldCFException {
        return userId != null && password != null && userId.equals(this.apiLoginUserName) && password.equals(this.apiLoginPassword);
    }
    
    @Override
    public boolean checkCapability(final String userId, final int capability) throws ManifoldCFException {
        return true;
    }
}
