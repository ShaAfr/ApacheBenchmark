// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import java.util.Collection;
import org.apache.manifoldcf.core.interfaces.StringSetBuffer;
import org.apache.manifoldcf.core.interfaces.IResultRow;
import org.apache.manifoldcf.core.interfaces.IResultSet;
import java.util.HashMap;
import java.util.Locale;
import org.apache.manifoldcf.core.interfaces.ILimitChecker;
import org.apache.manifoldcf.core.interfaces.ResultSpecification;
import org.apache.manifoldcf.core.interfaces.IDFactory;
import org.apache.manifoldcf.core.interfaces.IndexDescription;
import org.apache.manifoldcf.core.interfaces.ColumnDescription;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.StringSet;
import java.sql.SQLException;
import org.apache.manifoldcf.core.system.Logging;
import java.sql.Connection;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import org.apache.manifoldcf.core.interfaces.CacheKeyFactory;
import java.util.ArrayList;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import java.util.Map;
import java.util.List;
import org.apache.manifoldcf.core.interfaces.ILockManager;
import org.apache.manifoldcf.core.interfaces.IDBInterface;

public class DBInterfaceMySQL extends Database implements IDBInterface
{
    public static final String _rcsid = "@(#)$Id: DBInterfaceMySQL.java 999670 2010-09-21 22:18:19Z kwright $";
    public static final String mysqlServerProperty = "org.apache.manifoldcf.mysql.server";
    public static final String mysqlClientProperty = "org.apache.manifoldcf.mysql.client";
    private static final String _driver = "com.mysql.jdbc.Driver";
    protected ILockManager lockManager;
    protected int serializableDepth;
    protected List<String> tablesToAnalyze;
    protected static Map<String, TableStatistics> currentAnalyzeStatistics;
    protected static Map<String, Integer> analyzeThresholds;
    protected static final int commitThreshold = 100;
    protected static final String statslockAnalyzePrefix = "statslock-analyze-";
    protected static final String statsAnalyzePrefix = "stats-analyze-";
    protected String cacheKey;
    
    public DBInterfaceMySQL(final IThreadContext tc, final String databaseName, final String userName, final String password) throws ManifoldCFException {
        this(tc, "com.mysql.jdbc.Driver", databaseName, userName, password);
    }
    
    protected DBInterfaceMySQL(final IThreadContext tc, final String jdbcDriverClass, final String databaseName, final String userName, final String password) throws ManifoldCFException {
        super(tc, getJdbcUrl(tc, databaseName), jdbcDriverClass, databaseName, userName, password);
        this.serializableDepth = 0;
        this.tablesToAnalyze = new ArrayList<String>();
        this.cacheKey = CacheKeyFactory.makeDatabaseKey(this.databaseName);
        this.lockManager = LockManagerFactory.make(tc);
    }
    
    private static String getJdbcUrl(final IThreadContext tc, final String theDatabaseName) throws ManifoldCFException {
        String server = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.mysql.server");
        if (server == null || server.length() == 0) {
            server = "localhost";
        }
        return "jdbc:mysql://" + server + "/" + theDatabaseName + "?useUnicode=true&characterEncoding=utf8";
    }
    
    protected String getJdbcDriverClass() {
        return "com.mysql.jdbc.Driver";
    }
    
    @Override
    protected void interruptCleanup(final Connection connection) {
    }
    
    protected ManifoldCFException reinterpretException(final ManifoldCFException theException) {
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Reinterpreting exception '" + theException.getMessage() + "'.  The exception type is " + Integer.toString(theException.getErrorCode())));
        }
        if (theException.getErrorCode() != 4) {
            return theException;
        }
        final Throwable e = theException.getCause();
        if (!(e instanceof SQLException)) {
            return theException;
        }
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Exception " + theException.getMessage() + " is possibly a transaction abort signal"));
        }
        final SQLException sqlException = (SQLException)e;
        final String message = sqlException.getMessage();
        final String sqlState = sqlException.getSQLState();
        if (sqlState != null && sqlState.equals("23000")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("40001")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("40P01")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("HY000")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("41000")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("23505")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Exception " + theException.getMessage() + " is NOT a transaction abort signal"));
        }
        return theException;
    }
    
    @Override
    protected String mapLookupName(final String rawColumnName, final String rawLabelName) {
        return rawLabelName;
    }
    
    @Override
    public void openDatabase() throws ManifoldCFException {
    }
    
    @Override
    public void closeDatabase() throws ManifoldCFException {
    }
    
    @Override
    public String getDatabaseCacheKey() {
        return this.cacheKey;
    }
    
    @Override
    public void performInsert(final String tableName, final Map<String, Object> parameterMap, final StringSet invalidateKeys) throws ManifoldCFException {
        final List paramArray = new ArrayList();
        final StringBuilder bf = new StringBuilder();
        bf.append("INSERT INTO ");
        bf.append(tableName);
        bf.append(" (");
        final StringBuilder values = new StringBuilder(" VALUES (");
        final Iterator<Map.Entry<String, Object>> it = parameterMap.entrySet().iterator();
        boolean first = true;
        while (it.hasNext()) {
            final Map.Entry<String, Object> e = it.next();
            final String key = e.getKey();
            final Object o = e.getValue();
            if (o != null) {
                paramArray.add(o);
                if (!first) {
                    bf.append(',');
                    values.append(',');
                }
                bf.append(key);
                values.append('?');
                first = false;
            }
        }
        bf.append(')');
        values.append(')');
        bf.append((CharSequence)values);
        this.performModification(bf.toString(), paramArray, invalidateKeys);
    }
    
    @Override
    public void performUpdate(final String tableName, final Map<String, Object> parameterMap, final String whereClause, final List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        final List paramArray = new ArrayList();
        final StringBuilder bf = new StringBuilder();
        bf.append("UPDATE ");
        bf.append(tableName);
        bf.append(" SET ");
        final Iterator<Map.Entry<String, Object>> it = parameterMap.entrySet().iterator();
        boolean first = true;
        while (it.hasNext()) {
            final Map.Entry<String, Object> e = it.next();
            final String key = e.getKey();
            final Object o = e.getValue();
            if (!first) {
                bf.append(',');
            }
            bf.append(key);
            bf.append('=');
            if (o == null) {
                bf.append("NULL");
            }
            else {
                bf.append('?');
                paramArray.add(o);
            }
            first = false;
        }
        if (whereClause != null) {
            bf.append(' ');
            bf.append(whereClause);
            if (whereParameters != null) {
                for (int i = 0; i < whereParameters.size(); ++i) {
                    final Object value = whereParameters.get(i);
                    paramArray.add(value);
                }
            }
        }
        this.performModification(bf.toString(), paramArray, invalidateKeys);
    }
    
    @Override
    public void performDelete(final String tableName, final String whereClause, List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        final StringBuilder bf = new StringBuilder();
        bf.append("DELETE FROM ");
        bf.append(tableName);
        if (whereClause != null) {
            bf.append(' ');
            bf.append(whereClause);
        }
        else {
            whereParameters = null;
        }
        this.performModification(bf.toString(), whereParameters, invalidateKeys);
    }
    
    @Override
    public void performCreate(final String tableName, final Map<String, ColumnDescription> columnMap, final StringSet invalidateKeys) throws ManifoldCFException {
        final StringBuilder queryBuffer = new StringBuilder("CREATE TABLE ");
        queryBuffer.append(tableName);
        queryBuffer.append('(');
        final Iterator<String> iter = columnMap.keySet().iterator();
        boolean first = true;
        while (iter.hasNext()) {
            final String columnName = iter.next();
            final ColumnDescription cd = columnMap.get(columnName);
            if (!first) {
                queryBuffer.append(',');
            }
            else {
                first = false;
            }
            appendDescription(queryBuffer, columnName, cd, false, true);
        }
        queryBuffer.append(')');
        this.performModification(queryBuffer.toString(), null, invalidateKeys);
    }
    
    protected static void appendDescription(final StringBuilder queryBuffer, final String columnName, final ColumnDescription cd, final boolean forceNull, final boolean includeRestrict) {
        queryBuffer.append(columnName);
        queryBuffer.append(' ');
        queryBuffer.append(mapType(cd.getTypeString()));
        if (forceNull || cd.getIsNull()) {
            queryBuffer.append(" NULL");
        }
        else {
            queryBuffer.append(" NOT NULL");
        }
        if (cd.getIsPrimaryKey()) {
            queryBuffer.append(" PRIMARY KEY");
        }
        if (cd.getReferenceTable() != null && includeRestrict) {
            queryBuffer.append(" REFERENCES ");
            queryBuffer.append(cd.getReferenceTable());
            queryBuffer.append('(');
            queryBuffer.append(cd.getReferenceColumn());
            queryBuffer.append(") ON DELETE");
            if (cd.getReferenceCascade()) {
                queryBuffer.append(" CASCADE");
            }
            else {
                queryBuffer.append(" RESTRICT");
            }
        }
    }
    
    protected static String mapType(final String inputType) {
        if (inputType.equalsIgnoreCase("float")) {
            return "DOUBLE";
        }
        if (inputType.equalsIgnoreCase("blob")) {
            return "LONGBLOB";
        }
        return inputType;
    }
    
    @Override
    public void performAlter(final String tableName, final Map<String, ColumnDescription> columnMap, final Map<String, ColumnDescription> columnModifyMap, final List<String> columnDeleteList, final StringSet invalidateKeys) throws ManifoldCFException {
        this.beginTransaction(0);
        try {
            if (columnDeleteList != null) {
                int i = 0;
                while (i < columnDeleteList.size()) {
                    final String columnName = columnDeleteList.get(i++);
                    this.performModification("ALTER TABLE " + tableName + " DROP " + columnName, null, invalidateKeys);
                }
            }
            if (columnModifyMap != null) {
                for (final String columnName : columnModifyMap.keySet()) {
                    final ColumnDescription cd = columnModifyMap.get(columnName);
                    final StringBuilder sb = new StringBuilder();
                    appendDescription(sb, columnName, cd, false, false);
                    this.performModification("ALTER TABLE " + tableName + " CHANGE " + columnName + " " + sb.toString(), null, invalidateKeys);
                }
            }
            if (columnMap != null) {
                for (final String columnName : columnMap.keySet()) {
                    final ColumnDescription cd = columnMap.get(columnName);
                    final StringBuilder sb = new StringBuilder();
                    appendDescription(sb, columnName, cd, false, true);
                    this.performModification("ALTER TABLE " + tableName + " ADD " + sb.toString(), null, invalidateKeys);
                }
            }
        }
        catch (ManifoldCFException e) {
            this.signalRollback();
            throw e;
        }
        catch (Error e2) {
            this.signalRollback();
            throw e2;
        }
        finally {
            this.endTransaction();
        }
    }
    
    @Override
    public void addTableIndex(final String tableName, final boolean unique, final List<String> columnList) throws ManifoldCFException {
        final String[] columns = new String[columnList.size()];
        for (int i = 0; i < columns.length; ++i) {
            columns[i] = columnList.get(i);
        }
        this.performAddIndex(null, tableName, new IndexDescription(unique, columns));
    }
    
    @Override
    public void performAddIndex(String indexName, final String tableName, final IndexDescription description) throws ManifoldCFException {
        final String[] columnNames = description.getColumnNames();
        if (columnNames.length == 0) {
            return;
        }
        if (indexName == null) {
            indexName = "I" + IDFactory.make(this.context);
        }
        final StringBuilder queryBuffer = new StringBuilder("CREATE ");
        if (description.getIsUnique()) {
            queryBuffer.append("UNIQUE ");
        }
        queryBuffer.append("INDEX ");
        queryBuffer.append(indexName);
        queryBuffer.append(" ON ");
        queryBuffer.append(tableName);
        queryBuffer.append(" (");
        for (int i = 0; i < columnNames.length; ++i) {
            final String colName = columnNames[i];
            if (i > 0) {
                queryBuffer.append(',');
            }
            queryBuffer.append(colName);
        }
        queryBuffer.append(')');
        this.performModification(queryBuffer.toString(), null, null);
    }
    
    @Override
    public void performRemoveIndex(final String indexName, final String tableName) throws ManifoldCFException {
        this.performModification("DROP INDEX " + indexName + " ON " + tableName, null, null);
    }
    
    protected int readDatum(final String datumName) throws ManifoldCFException {
        final byte[] bytes = this.lockManager.readData(datumName);
        if (bytes == null) {
            return 0;
        }
        return (bytes[0] & 0xFF) + ((bytes[1] & 0xFF) << 8) + ((bytes[2] & 0xFF) << 16) + ((bytes[3] & 0xFF) << 24);
    }
    
    protected void writeDatum(final String datumName, final int value) throws ManifoldCFException {
        final byte[] bytes = { (byte)(value & 0xFF), (byte)(value >> 8 & 0xFF), (byte)(value >> 16 & 0xFF), (byte)(value >> 24 & 0xFF) };
        this.lockManager.writeData(datumName, bytes);
    }
    
    @Override
    public void analyzeTable(final String tableName) throws ManifoldCFException {
        final String tableStatisticsLock = "statslock-analyze-" + tableName;
        this.lockManager.enterWriteCriticalSection(tableStatisticsLock);
        try {
            final TableStatistics ts = DBInterfaceMySQL.currentAnalyzeStatistics.get(tableName);
            this.lockManager.enterWriteLock(tableStatisticsLock);
            try {
                final String eventDatum = "stats-analyze-" + tableName;
                this.analyzeTableInternal(tableName);
                this.writeDatum(eventDatum, 0);
                if (ts != null) {
                    ts.reset();
                }
            }
            finally {
                this.lockManager.leaveWriteLock(tableStatisticsLock);
            }
        }
        finally {
            this.lockManager.leaveWriteCriticalSection(tableStatisticsLock);
        }
    }
    
    @Override
    public void reindexTable(final String tableName) throws ManifoldCFException {
    }
    
    protected void analyzeTableInternal(final String tableName) throws ManifoldCFException {
        if (this.getTransactionID() == null) {
            this.performModification("ANALYZE TABLE " + tableName, null, null);
        }
        else {
            this.tablesToAnalyze.add(tableName);
        }
    }
    
    @Override
    public void performDrop(final String tableName, final StringSet invalidateKeys) throws ManifoldCFException {
        this.performModification("DROP TABLE " + tableName, null, invalidateKeys);
    }
    
    @Override
    public void createUserAndDatabase(final String adminUserName, final String adminPassword, final StringSet invalidateKeys) throws ManifoldCFException {
        String client = this.lockManager.getSharedConfiguration().getProperty("org.apache.manifoldcf.mysql.client");
        if (client == null || client.length() == 0) {
            client = "localhost";
        }
        final Database masterDatabase = new DBInterfaceMySQL(this.context, this.getJdbcDriverClass(), "mysql", adminUserName, adminPassword);
        try {
            final List list = new ArrayList();
            try {
                list.add("utf8");
                list.add("utf8_bin");
                masterDatabase.executeQuery("CREATE DATABASE " + this.databaseName + " CHARACTER SET ? COLLATE ?", list, null, invalidateKeys, null, false, 0, null, null);
            }
            catch (ManifoldCFException e) {
                if (e.getErrorCode() != 4) {
                    throw new ManifoldCFException(e.getMessage());
                }
            }
            if (this.userName != null) {
                try {
                    list.clear();
                    list.add(this.userName);
                    list.add(client);
                    list.add(this.password);
                    masterDatabase.executeQuery("GRANT ALL ON " + this.databaseName + ".* TO ?@? IDENTIFIED BY ?", list, null, invalidateKeys, null, false, 0, null, null);
                }
                catch (ManifoldCFException e) {
                    if (e.getErrorCode() != 4) {
                        throw new ManifoldCFException(e.getMessage());
                    }
                }
            }
        }
        catch (ManifoldCFException e2) {
            throw this.reinterpretException(e2);
        }
    }
    
    @Override
    public void dropUserAndDatabase(final String adminUserName, final String adminPassword, final StringSet invalidateKeys) throws ManifoldCFException {
        final Database masterDatabase = new DBInterfaceMySQL(this.context, this.getJdbcDriverClass(), "mysql", adminUserName, adminPassword);
        try {
            masterDatabase.executeQuery("DROP DATABASE " + this.databaseName, null, null, invalidateKeys, null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public void performModification(final String query, final List params, final StringSet invalidateKeys) throws ManifoldCFException {
        try {
            this.executeQuery(query, params, null, invalidateKeys, null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public Map<String, ColumnDescription> getTableSchema(final String tableName, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        StringBuilder query = new StringBuilder();
        final List list = new ArrayList();
        list.add(this.databaseName.toLowerCase(Locale.ROOT));
        list.add(tableName.toLowerCase(Locale.ROOT));
        query.append("SELECT column_name, is_nullable, data_type, character_maximum_length ").append("FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=?");
        final IResultSet set = this.performQuery(query.toString(), list, cacheKeys, queryClass);
        if (set.getRowCount() == 0) {
            return null;
        }
        query = new StringBuilder();
        query.append("SELECT t1.column_name ").append("FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE t1, INFORMATION_SCHEMA.TABLE_CONSTRAINTS t2 ").append("WHERE t1.CONSTRAINT_NAME=t2.CONSTRAINT_NAME AND t1.TABLE_NAME=t2.TABLE_NAME AND ").append("t1.TABLE_SCHEMA=t2.TABLE_SCHEMA AND ").append("t1.TABLE_SCHEMA=? AND t1.TABLE_NAME=? AND t2.CONSTRAINT_TYPE='PRIMARY KEY'");
        final IResultSet primarySet = this.performQuery(query.toString(), list, cacheKeys, queryClass);
        String primaryKey = null;
        if (primarySet.getRowCount() != 0) {
            primaryKey = ((String)primarySet.getRow(0).getValue("column_name")).toLowerCase(Locale.ROOT);
        }
        if (primaryKey == null) {
            primaryKey = "";
        }
        final Map<String, ColumnDescription> rval = new HashMap<String, ColumnDescription>();
        int i = 0;
        while (i < set.getRowCount()) {
            final IResultRow row = set.getRow(i++);
            final String fieldName = ((String)row.getValue("column_name")).toLowerCase(Locale.ROOT);
            final String type = (String)row.getValue("data_type");
            final Long width = (Long)row.getValue("character_maximum_length");
            final String isNullable = (String)row.getValue("is_nullable");
            final boolean isPrimaryKey = primaryKey.equals(fieldName);
            final boolean isNull = isNullable.equals("YES");
            if (type.equals("VARCHAR")) {
                final String dataType = "VARCHAR(" + width.toString() + ")";
            }
            else if (type.equals("CHAR")) {
                final String dataType = "CHAR(" + width.toString() + ")";
            }
            else if (type.equals("LONGBLOB")) {
                final String dataType = "BLOB";
            }
            else if (type.equals("DOUBLE PRECISION")) {
                final String dataType = "FLOAT";
            }
            else {
                final String dataType = type;
            }
            rval.put(fieldName, new ColumnDescription(type, isPrimaryKey, isNull, null, null, false));
        }
        return rval;
    }
    
    @Override
    public Map<String, IndexDescription> getTableIndexes(final String tableName, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        final Map<String, IndexDescription> rval = new HashMap<String, IndexDescription>();
        final String query = "SELECT index_name,column_name,non_unique,seq_in_index FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA=? AND TABLE_NAME=? ORDER BY index_name,seq_in_index ASC";
        final List list = new ArrayList();
        list.add(this.databaseName.toLowerCase(Locale.ROOT));
        list.add(tableName.toLowerCase(Locale.ROOT));
        final IResultSet result = this.performQuery(query, list, cacheKeys, queryClass);
        String lastIndexName = null;
        List<String> indexColumns = null;
        boolean isUnique = false;
        int i = 0;
        while (i < result.getRowCount()) {
            final IResultRow row = result.getRow(i++);
            final String indexName = ((String)row.getValue("index_name")).toLowerCase(Locale.ROOT);
            final String columnName = ((String)row.getValue("column_name")).toLowerCase(Locale.ROOT);
            final String nonUnique = row.getValue("non_unique").toString();
            if (lastIndexName != null && !lastIndexName.equals(indexName)) {
                this.addIndex(rval, lastIndexName, isUnique, indexColumns);
                lastIndexName = null;
                indexColumns = null;
                isUnique = false;
            }
            if (lastIndexName == null) {
                lastIndexName = indexName;
                indexColumns = new ArrayList<String>();
                isUnique = false;
            }
            indexColumns.add(columnName);
            isUnique = nonUnique.equals("0");
        }
        if (lastIndexName != null) {
            this.addIndex(rval, lastIndexName, isUnique, indexColumns);
        }
        return rval;
    }
    
    protected void addIndex(final Map rval, final String indexName, final boolean isUnique, final List<String> indexColumns) {
        if (indexName.equals("primary")) {
            return;
        }
        final String[] columnNames = new String[indexColumns.size()];
        for (int i = 0; i < columnNames.length; ++i) {
            columnNames[i] = indexColumns.get(i);
        }
        rval.put(indexName, new IndexDescription(isUnique, columnNames));
    }
    
    @Override
    public StringSet getAllTables(final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        final IResultSet set = this.performQuery("SHOW TABLES", null, cacheKeys, queryClass);
        final StringSetBuffer ssb = new StringSetBuffer();
        final String columnName = "Tables_in_" + this.databaseName.toLowerCase(Locale.ROOT);
        int i = 0;
        while (i < set.getRowCount()) {
            final IResultRow row = set.getRow(i++);
            final String value = row.getValue(columnName).toString();
            ssb.add(value);
        }
        return new StringSet(ssb);
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, -1, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass, final int maxResults, final ILimitChecker returnLimit) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, maxResults, null, returnLimit);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass, final int maxResults, final ResultSpecification resultSpec, final ILimitChecker returnLimit) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, maxResults, resultSpec, returnLimit);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public String constructIndexHintClause(final String tableName, final IndexDescription description) throws ManifoldCFException {
        final Map indexes = this.getTableIndexes(tableName, null, null);
        for (final String indexName : indexes.keySet()) {
            final IndexDescription id = indexes.get(indexName);
            if (id.equals(description)) {
                return "FORCE INDEX (" + indexName + ")";
            }
        }
        throw new ManifoldCFException("Expected index description " + description + " not found");
    }
    
    @Override
    public String constructDoubleCastClause(final String value) {
        return value;
    }
    
    @Override
    public String constructCountClause(final String column) {
        return "COUNT(" + column + ")";
    }
    
    @Override
    public String constructRegexpClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        return column + " LIKE " + regularExpression;
    }
    
    @Override
    public String constructSubstringClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        return regularExpression;
    }
    
    @Override
    public String constructOffsetLimitClause(final int offset, final int limit, final boolean afterOrderBy) {
        final StringBuilder sb = new StringBuilder();
        if (limit != -1) {
            sb.append("LIMIT ").append(Integer.toString(limit));
        }
        if (offset != 0) {
            if (limit != -1) {
                sb.append(" ");
            }
            sb.append("OFFSET ").append(Integer.toString(offset));
        }
        return sb.toString();
    }
    
    @Override
    public String constructDistinctOnClause(final List outputParameters, final String baseQuery, final List baseParameters, final String[] distinctFields, final String[] orderFields, final boolean[] orderFieldsAscending, final Map<String, String> otherFields) {
        if (baseParameters != null) {
            outputParameters.addAll(baseParameters);
        }
        final StringBuilder sb = new StringBuilder("SELECT ");
        boolean needComma = false;
        for (final String fieldName : otherFields.keySet()) {
            final String columnValue = otherFields.get(fieldName);
            if (needComma) {
                sb.append(",");
            }
            needComma = true;
            sb.append("txxx1.").append(columnValue).append(" AS ").append(fieldName);
        }
        sb.append(" FROM (").append(baseQuery).append(") txxx1");
        if (distinctFields.length > 0 || orderFields.length > 0) {
            sb.append(" ORDER BY ");
            int k = 0;
            for (int i = 0; i < distinctFields.length; ++i) {
                if (k > 0) {
                    sb.append(",");
                }
                sb.append(distinctFields[i]).append(" ASC");
                ++k;
            }
            for (int i = 0; i < orderFields.length; ++i, ++k) {
                if (k > 0) {
                    sb.append(",");
                }
                sb.append(orderFields[i]).append(" ");
                if (orderFieldsAscending[i]) {
                    sb.append("ASC");
                }
                else {
                    sb.append("DESC");
                }
            }
        }
        return sb.toString();
    }
    
    @Override
    public int getMaxInClause() {
        return 100;
    }
    
    @Override
    public int getMaxOrClause() {
        return 25;
    }
    
    @Override
    public int getWindowedReportMaxRows() {
        return 5000;
    }
    
    @Override
    public void beginTransaction() throws ManifoldCFException {
        this.beginTransaction(0);
    }
    
    protected int getActualTransactionType() {
        if (this.th == null) {
            return -1;
        }
        return this.th.getTransactionType();
    }
    
    @Override
    public void beginTransaction(int transactionType) throws ManifoldCFException {
        if (this.getCurrentTransactionType() == 2) {
            ++this.serializableDepth;
            return;
        }
        if (transactionType == 0) {
            transactionType = this.getCurrentTransactionType();
        }
        switch (transactionType) {
            case 3: {
                if (transactionType != this.getActualTransactionType()) {
                    this.performModification("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ", null, null);
                }
                super.beginTransaction(transactionType);
                break;
            }
            case 1: {
                if (transactionType != this.getActualTransactionType()) {
                    this.performModification("SET TRANSACTION ISOLATION LEVEL READ COMMITTED", null, null);
                }
                super.beginTransaction(transactionType);
                break;
            }
            case 2: {
                if (transactionType != this.getActualTransactionType()) {
                    this.performModification("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE", null, null);
                }
                super.beginTransaction(2);
                break;
            }
            default: {
                throw new ManifoldCFException("Bad transaction type: " + Integer.toString(transactionType));
            }
        }
    }
    
    @Override
    protected void startATransaction() throws ManifoldCFException {
        try {
            this.executeViaThread(this.connection.getConnection(), "START TRANSACTION", null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    protected void commitCurrentTransaction() throws ManifoldCFException {
        try {
            this.executeViaThread(this.connection.getConnection(), "COMMIT", null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public void signalRollback() {
        if (this.serializableDepth == 0) {
            super.signalRollback();
        }
    }
    
    @Override
    public void endTransaction() throws ManifoldCFException {
        if (this.serializableDepth > 0) {
            --this.serializableDepth;
            return;
        }
        super.endTransaction();
        if (this.getTransactionID() == null) {
            for (int i = 0; i < this.tablesToAnalyze.size(); ++i) {
                this.analyzeTableInternal(this.tablesToAnalyze.get(i));
            }
            this.tablesToAnalyze.clear();
        }
    }
    
    @Override
    protected void rollbackCurrentTransaction() throws ManifoldCFException {
        try {
            this.executeViaThread(this.connection.getConnection(), "ROLLBACK", null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    protected void noteModificationsNoTransactions(final String tableName, final int insertCount, final int modifyCount, final int deleteCount) throws ManifoldCFException {
        final int eventCount = modifyCount + insertCount;
        final String tableStatisticsLock = "statslock-analyze-" + tableName;
        this.lockManager.enterWriteCriticalSection(tableStatisticsLock);
        try {
            final Integer threshold = DBInterfaceMySQL.analyzeThresholds.get(tableName);
            int analyzeThreshold;
            if (threshold == null) {
                analyzeThreshold = this.lockManager.getSharedConfiguration().getIntProperty("org.apache.manifoldcf.db.mysql.analyze." + tableName, 10000);
                DBInterfaceMySQL.analyzeThresholds.put(tableName, new Integer(analyzeThreshold));
            }
            else {
                analyzeThreshold = threshold;
            }
            TableStatistics ts = DBInterfaceMySQL.currentAnalyzeStatistics.get(tableName);
            if (ts == null) {
                ts = new TableStatistics();
                DBInterfaceMySQL.currentAnalyzeStatistics.put(tableName, ts);
            }
            ts.add(eventCount);
            if (ts.getEventCount() >= 100) {
                this.lockManager.enterWriteLock(tableStatisticsLock);
                try {
                    final String eventDatum = "stats-analyze-" + tableName;
                    int oldEventCount = this.readDatum(eventDatum);
                    oldEventCount += ts.getEventCount();
                    if (oldEventCount >= analyzeThreshold) {
                        this.analyzeTableInternal(tableName);
                        this.writeDatum(eventDatum, 0);
                    }
                    else {
                        this.writeDatum(eventDatum, oldEventCount);
                    }
                    ts.reset();
                }
                finally {
                    this.lockManager.leaveWriteLock(tableStatisticsLock);
                }
            }
        }
        finally {
            this.lockManager.leaveWriteCriticalSection(tableStatisticsLock);
        }
    }
    
    static {
        DBInterfaceMySQL.currentAnalyzeStatistics = new HashMap<String, TableStatistics>();
        DBInterfaceMySQL.analyzeThresholds = new HashMap<String, Integer>();
    }
    
    protected static class TableStatistics
    {
        protected int eventCount;
        
        public TableStatistics() {
            this.eventCount = 0;
        }
        
        public void reset() {
            this.eventCount = 0;
        }
        
        public void add(final int eventCount) {
            this.eventCount += eventCount;
        }
        
        public int getEventCount() {
            return this.eventCount;
        }
    }
}
