// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import java.util.ArrayList;
import org.apache.manifoldcf.core.interfaces.IResultRow;
import java.util.List;
import org.apache.manifoldcf.core.interfaces.IResultSet;

public class RSet implements IResultSet
{
    public static final String _rcsid = "@(#)$Id: RSet.java 988245 2010-08-23 18:39:35Z kwright $";
    protected List<IResultRow> rows;
    
    public RSet() {
        this.rows = new ArrayList<IResultRow>();
    }
    
    public void addRow(final IResultRow m) {
        this.rows.add(m);
    }
    
    @Override
    public IResultRow getRow(final int rowNumber) {
        return this.rows.get(rowNumber);
    }
    
    @Override
    public int getRowCount() {
        return this.rows.size();
    }
    
    @Override
    public IResultRow[] getRows() {
        final IResultRow[] rval = new IResultRow[this.rows.size()];
        for (int i = 0; i < this.rows.size(); ++i) {
            rval[i] = this.rows.get(i);
        }
        return rval;
    }
}
