// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public class TimeMarker
{
    public static final String _rcsid = "@(#)$Id: TimeMarker.java 988245 2010-08-23 18:39:35Z kwright $";
    long timeValue;
    
    public TimeMarker(final long timeValue) {
        this.timeValue = timeValue;
    }
    
    public long longValue() {
        return this.timeValue;
    }
    
    @Override
    public String toString() {
        return new Long(this.timeValue).toString();
    }
}
