// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.cachemanager;

import org.apache.manifoldcf.core.interfaces.ICacheClass;
import org.apache.manifoldcf.core.interfaces.ICacheDescription;

public abstract class BaseDescription implements ICacheDescription
{
    public static final String _rcsid = "@(#)$Id: BaseDescription.java 988245 2010-08-23 18:39:35Z kwright $";
    protected ICacheClass cacheClass;
    protected static final Integer max_value;
    
    public BaseDescription(final String objectClassName) {
        this.cacheClass = null;
        if (objectClassName != null) {
            this.cacheClass = new LocalCacheClass(objectClassName);
        }
    }
    
    public BaseDescription(final String objectClassName, final int maxLRUCount) {
        this.cacheClass = null;
        if (objectClassName != null) {
            this.cacheClass = new LocalCacheClass(objectClassName, maxLRUCount);
        }
    }
    
    @Override
    public ICacheClass getObjectClass() {
        return this.cacheClass;
    }
    
    @Override
    public long getObjectExpirationTime(final long currentTime) {
        return -1L;
    }
    
    static {
        max_value = new Integer(Integer.MAX_VALUE);
    }
    
    protected class LocalCacheClass implements ICacheClass
    {
        protected String objectClassName;
        protected Integer maxLRUCount;
        
        public LocalCacheClass(final BaseDescription this$0, final String objectClassName) {
            this(this$0, objectClassName, -1);
        }
        
        public LocalCacheClass(final String objectClassName, final int maxLRUCount) {
            this.maxLRUCount = null;
            this.objectClassName = objectClassName;
            if (maxLRUCount != -1) {
                this.maxLRUCount = new Integer(maxLRUCount);
            }
        }
        
        @Override
        public String getClassName() {
            return this.objectClassName;
        }
        
        @Override
        public int getMaxLRUCount() {
            if (this.maxLRUCount == null) {
                try {
                    final String x = null;
                    if (x == null) {
                        this.maxLRUCount = BaseDescription.max_value;
                    }
                    else {
                        this.maxLRUCount = new Integer(x);
                    }
                }
                catch (Exception e) {
                    this.maxLRUCount = BaseDescription.max_value;
                }
            }
            return this.maxLRUCount;
        }
    }
}
