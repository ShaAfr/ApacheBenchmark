// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.Arrays;
import java.util.Map;
import java.util.Vector;
import java.util.Iterator;
import java.util.HashMap;

public class StringSet
{
    public static final String _rcsid = "@(#)$Id: StringSet.java 988245 2010-08-23 18:39:35Z kwright $";
    protected HashMap hashtable;
    protected String descriptiveString;
    
    public StringSet() {
        this.hashtable = new HashMap();
        this.descriptiveString = null;
    }
    
    public StringSet(final StringSetBuffer buffer) {
        this.hashtable = new HashMap();
        this.descriptiveString = null;
        final Iterator x = buffer.getKeys();
        while (x.hasNext()) {
            final String key = x.next();
            this.hashtable.put(key, key);
        }
    }
    
    public StringSet(final String x) {
        this.hashtable = new HashMap();
        this.descriptiveString = null;
        this.hashtable.put(x, x);
    }
    
    public StringSet(final String[] array) {
        this.hashtable = new HashMap();
        this.descriptiveString = null;
        int i = 0;
        while (i < array.length) {
            final String x = array[i++];
            this.hashtable.put(x, x);
        }
    }
    
    public StringSet(final Vector stringVector) {
        this.hashtable = new HashMap();
        this.descriptiveString = null;
        int i = 0;
        while (i < stringVector.size()) {
            final String x = stringVector.elementAt(i++);
            this.hashtable.put(x, x);
        }
    }
    
    public StringSet(final Map table) {
        this.hashtable = new HashMap();
        this.descriptiveString = null;
        for (final String key : table.values()) {
            this.hashtable.put(key, key);
        }
    }
    
    public boolean contains(final String key) {
        return this.hashtable.get(key) != null;
    }
    
    public boolean contains(final StringSet x) {
        final Iterator iter = x.getKeys();
        while (iter.hasNext()) {
            final String key = iter.next();
            if (this.contains(key)) {
                return true;
            }
        }
        return false;
    }
    
    public Iterator getKeys() {
        return this.hashtable.keySet().iterator();
    }
    
    public int size() {
        return this.hashtable.size();
    }
    
    public String[] getArray(final String prefix) {
        final String[] rval = new String[this.hashtable.size()];
        int i = 0;
        for (String x : this.hashtable.keySet()) {
            if (prefix != null) {
                x = prefix + x;
            }
            rval[i++] = x;
        }
        return rval;
    }
    
    public StringSet(final StringSet oldOne, final String prefix) {
        this.hashtable = new HashMap();
        this.descriptiveString = null;
        for (String x : oldOne.hashtable.keySet()) {
            if (prefix != null) {
                x = prefix + x;
            }
            this.hashtable.put(x, x);
        }
    }
    
    @Override
    public int hashCode() {
        return this.hashtable.hashCode();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof StringSet)) {
            return false;
        }
        final StringSet set = (StringSet)o;
        return this.hashtable.equals(set.hashtable);
    }
    
    public String getDescriptiveString() {
        if (this.descriptiveString == null) {
            final String[] array = this.getArray(null);
            Arrays.sort(array);
            final StringBuilder sb = new StringBuilder();
            int i = 0;
            while (i < array.length) {
                if (i > 0) {
                    sb.append(":");
                }
                sb.append(array[i++]);
            }
            this.descriptiveString = sb.toString();
        }
        return this.descriptiveString;
    }
}
