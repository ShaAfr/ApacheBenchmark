// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.IOException;

public interface IHTTPOutputActivity
{
    public static final String _rcsid = "@(#)$Id$";
    
    void flush() throws IOException;
    
    void newLine() throws IOException;
    
    void print(final boolean p0) throws IOException;
    
    void print(final char p0) throws IOException;
    
    void print(final char[] p0) throws IOException;
    
    void print(final double p0) throws IOException;
    
    void print(final float p0) throws IOException;
    
    void print(final int p0) throws IOException;
    
    void print(final long p0) throws IOException;
    
    void print(final Object p0) throws IOException;
    
    void print(final String p0) throws IOException;
    
    void println(final boolean p0) throws IOException;
    
    void println(final char p0) throws IOException;
    
    void println(final char[] p0) throws IOException;
    
    void println(final double p0) throws IOException;
    
    void println(final float p0) throws IOException;
    
    void println(final int p0) throws IOException;
    
    void println(final long p0) throws IOException;
    
    void println(final Object p0) throws IOException;
    
    void println(final String p0) throws IOException;
}
