// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IPasswordMapperActivity
{
    public static final String _rcsid = "@(#)$Id$";
    
    String mapPasswordToKey(final String p0);
    
    String mapKeyToPassword(final String p0);
}
