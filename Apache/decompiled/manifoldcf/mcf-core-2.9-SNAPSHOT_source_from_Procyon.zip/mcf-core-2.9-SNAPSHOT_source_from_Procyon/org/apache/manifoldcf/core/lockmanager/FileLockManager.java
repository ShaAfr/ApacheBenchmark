// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InterruptedIOException;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.io.File;

public class FileLockManager extends BaseLockManager
{
    public static final String _rcsid = "@(#)$Id$";
    public static final String synchDirectoryProperty = "org.apache.manifoldcf.synchdirectory";
    protected static final Integer lockPoolInitialization;
    protected static LockPool myFileLocks;
    protected File synchDirectory;
    protected static final int BASE_SIZE = 128;
    
    public FileLockManager(final File synchDirectory) throws ManifoldCFException {
        this.synchDirectory = null;
        this.synchDirectory = synchDirectory;
        if (synchDirectory == null) {
            throw new ManifoldCFException("Synch directory cannot be null");
        }
        if (!synchDirectory.isDirectory()) {
            throw new ManifoldCFException("Synch directory must point to an existing, writeable directory!", 3);
        }
        synchronized (FileLockManager.lockPoolInitialization) {
            if (FileLockManager.myFileLocks == null) {
                FileLockManager.myFileLocks = new LockPool(new FileLockObjectFactory(synchDirectory));
            }
        }
    }
    
    public FileLockManager() throws ManifoldCFException {
        this(getSynchDirectoryProperty());
    }
    
    public static File getSynchDirectoryProperty() throws ManifoldCFException {
        return ManifoldCF.getFileProperty("org.apache.manifoldcf.synchdirectory");
    }
    
    protected static String getFlagResourceName(final String flagName) {
        return "flag-" + flagName;
    }
    
    @Override
    public void setGlobalFlag(final String flagName) throws ManifoldCFException {
        final String resourceName = getFlagResourceName(flagName);
        final String path = this.makeFilePath(resourceName);
        new File(path).mkdirs();
        final File f = new File(path, ManifoldCF.safeFileName(resourceName));
        try {
            f.createNewFile();
        }
        catch (InterruptedIOException e) {
            throw new ManifoldCFException("Interrupted: " + e.getMessage(), e, 2);
        }
        catch (IOException e2) {
            throw new ManifoldCFException(e2.getMessage(), e2);
        }
    }
    
    @Override
    public void clearGlobalFlag(final String flagName) throws ManifoldCFException {
        final String resourceName = getFlagResourceName(flagName);
        final File f = new File(this.makeFilePath(resourceName), ManifoldCF.safeFileName(resourceName));
        f.delete();
    }
    
    @Override
    public boolean checkGlobalFlag(final String flagName) throws ManifoldCFException {
        final String resourceName = getFlagResourceName(flagName);
        final File f = new File(this.makeFilePath(resourceName), ManifoldCF.safeFileName(resourceName));
        return f.exists();
    }
    
    @Override
    public byte[] readData(final String resourceName) throws ManifoldCFException {
        final File f = new File(this.makeFilePath(resourceName), ManifoldCF.safeFileName(resourceName));
        try {
            final InputStream is = new FileInputStream(f);
            try {
                final ByteArrayBuffer bab = new ByteArrayBuffer();
                while (true) {
                    final int x = is.read();
                    if (x == -1) {
                        break;
                    }
                    bab.add((byte)x);
                }
                return bab.toArray();
            }
            finally {
                is.close();
            }
        }
        catch (FileNotFoundException e3) {
            return null;
        }
        catch (InterruptedIOException e) {
            throw new ManifoldCFException("Interrupted: " + e.getMessage(), e, 2);
        }
        catch (IOException e2) {
            throw new ManifoldCFException("IO exception: " + e2.getMessage(), e2);
        }
    }
    
    @Override
    public void writeData(final String resourceName, final byte[] data) throws ManifoldCFException {
        try {
            final String path = this.makeFilePath(resourceName);
            new File(path).mkdirs();
            final File f = new File(path, ManifoldCF.safeFileName(resourceName));
            if (data == null) {
                f.delete();
                return;
            }
            final FileOutputStream os = new FileOutputStream(f);
            try {
                os.write(data, 0, data.length);
            }
            finally {
                os.close();
            }
        }
        catch (InterruptedIOException e) {
            throw new ManifoldCFException("Interrupted: " + e.getMessage(), e, 2);
        }
        catch (IOException e2) {
            throw new ManifoldCFException("IO exception: " + e2.getMessage(), e2);
        }
    }
    
    @Override
    protected LockPool getGlobalLockPool() {
        return FileLockManager.myFileLocks;
    }
    
    protected String makeFilePath(final String key) {
        final int hashcode = key.hashCode();
        final int outerDirNumber = hashcode & 0x3FF;
        final int innerDirNumber = hashcode >> 10 & 0x3FF;
        String fullDir = this.synchDirectory.toString();
        if (fullDir.length() == 0 || !fullDir.endsWith("/")) {
            fullDir += "/";
        }
        fullDir = fullDir + Integer.toString(outerDirNumber) + "/" + Integer.toString(innerDirNumber);
        return fullDir;
    }
    
    static {
        lockPoolInitialization = new Integer(0);
        FileLockManager.myFileLocks = null;
    }
    
    protected static class ByteArrayBuffer
    {
        protected byte[] buffer;
        protected int length;
        
        public ByteArrayBuffer() {
            this.buffer = new byte[128];
            this.length = 0;
        }
        
        public void add(final byte b) {
            if (this.length == this.buffer.length) {
                final byte[] oldbuffer = this.buffer;
                System.arraycopy(oldbuffer, 0, this.buffer = new byte[this.length * 2], 0, this.length);
            }
            this.buffer[this.length++] = b;
        }
        
        public byte[] toArray() {
            final byte[] rval = new byte[this.length];
            System.arraycopy(this.buffer, 0, rval, 0, this.length);
            return rval;
        }
    }
}
