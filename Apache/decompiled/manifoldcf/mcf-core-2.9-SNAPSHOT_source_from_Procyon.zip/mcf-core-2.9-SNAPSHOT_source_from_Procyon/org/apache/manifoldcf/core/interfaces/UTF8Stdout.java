// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.io.Writer;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.io.PrintWriter;

public final class UTF8Stdout
{
    public static final String _rcsid = "@(#)$Id: UTF8Stdout.java 988245 2010-08-23 18:39:35Z kwright $";
    private static PrintWriter out;
    
    private UTF8Stdout() {
    }
    
    public static void close() {
        UTF8Stdout.out.close();
    }
    
    public static void println() {
        UTF8Stdout.out.println();
    }
    
    public static void println(final Object x) {
        UTF8Stdout.out.println(x);
    }
    
    public static void println(final boolean x) {
        UTF8Stdout.out.println(x);
    }
    
    public static void println(final char x) {
        UTF8Stdout.out.println(x);
    }
    
    public static void println(final double x) {
        UTF8Stdout.out.println(x);
    }
    
    public static void println(final float x) {
        UTF8Stdout.out.println(x);
    }
    
    public static void println(final int x) {
        UTF8Stdout.out.println(x);
    }
    
    public static void println(final long x) {
        UTF8Stdout.out.println(x);
    }
    
    public static void print() {
        UTF8Stdout.out.flush();
    }
    
    public static void print(final Object x) {
        UTF8Stdout.out.print(x);
        UTF8Stdout.out.flush();
    }
    
    public static void print(final boolean x) {
        UTF8Stdout.out.print(x);
        UTF8Stdout.out.flush();
    }
    
    public static void print(final char x) {
        UTF8Stdout.out.print(x);
        UTF8Stdout.out.flush();
    }
    
    public static void print(final double x) {
        UTF8Stdout.out.print(x);
        UTF8Stdout.out.flush();
    }
    
    public static void print(final float x) {
        UTF8Stdout.out.print(x);
        UTF8Stdout.out.flush();
    }
    
    public static void print(final int x) {
        UTF8Stdout.out.print(x);
        UTF8Stdout.out.flush();
    }
    
    public static void print(final long x) {
        UTF8Stdout.out.print(x);
        UTF8Stdout.out.flush();
    }
    
    public static void printStackTrace(final Throwable e) {
        e.printStackTrace(UTF8Stdout.out);
    }
    
    static {
        UTF8Stdout.out = new PrintWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8), true);
    }
}
