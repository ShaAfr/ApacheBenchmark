// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.Iterator;
import java.util.Arrays;
import java.util.HashMap;

public class ResultSpecification
{
    public static final int FORM_DEFAULT = 0;
    public static final int FORM_STRING = 1;
    public static final int FORM_STREAM = 2;
    protected HashMap columnSpecifications;
    
    public ResultSpecification() {
        this.columnSpecifications = new HashMap();
    }
    
    @Override
    public int hashCode() {
        final String[] keys = new String[this.columnSpecifications.size()];
        final Iterator iter = this.columnSpecifications.keySet().iterator();
        int i = 0;
        while (iter.hasNext()) {
            keys[i++] = iter.next();
        }
        Arrays.sort(keys);
        int rval;
        String key;
        ColumnSpecification cs;
        for (rval = 0, i = 0; i < keys.length; key = keys[i++], rval += key.hashCode(), cs = this.columnSpecifications.get(key), rval += cs.hashCode()) {}
        return rval;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof ResultSpecification)) {
            return false;
        }
        final ResultSpecification other = (ResultSpecification)o;
        if (other.columnSpecifications.size() != this.columnSpecifications.size()) {
            return false;
        }
        for (final String key : this.columnSpecifications.keySet()) {
            final ColumnSpecification thisSpec = this.columnSpecifications.get(key);
            final ColumnSpecification otherSpec = other.columnSpecifications.get(key);
            if (otherSpec == null) {
                return false;
            }
            if (!thisSpec.equals(otherSpec)) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        final String[] keys = new String[this.columnSpecifications.size()];
        final Iterator iter = this.columnSpecifications.keySet().iterator();
        int i = 0;
        while (iter.hasNext()) {
            keys[i++] = iter.next();
        }
        Arrays.sort(keys);
        sb.append(Integer.toString(keys.length));
        i = 0;
        while (i < keys.length) {
            final String key = keys[i++];
            sb.append("-").append(key);
            final ColumnSpecification cs = this.columnSpecifications.get(key);
            sb.append("-").append(cs.toString());
        }
        return sb.toString();
    }
    
    public void setForm(final String columnName, final int formValue) {
        ColumnSpecification cs = this.columnSpecifications.get(columnName);
        if (cs == null) {
            if (formValue == 0) {
                return;
            }
            cs = new ColumnSpecification();
            this.columnSpecifications.put(columnName, cs);
        }
        else if (formValue == 0) {
            this.columnSpecifications.remove(columnName);
            return;
        }
        cs.setForm(formValue);
    }
    
    public int getForm(final String columnName) {
        final ColumnSpecification cs = this.columnSpecifications.get(columnName);
        if (cs == null) {
            return 0;
        }
        return cs.getForm();
    }
    
    protected static class ColumnSpecification
    {
        protected int formValue;
        
        public ColumnSpecification() {
            this.formValue = 0;
        }
        
        public void setForm(final int formValue) {
            this.formValue = formValue;
        }
        
        public int getForm() {
            return this.formValue;
        }
        
        @Override
        public String toString() {
            return Integer.toString(this.formValue);
        }
        
        @Override
        public int hashCode() {
            return this.formValue;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (!(o instanceof ColumnSpecification)) {
                return false;
            }
            final ColumnSpecification other = (ColumnSpecification)o;
            return other.formValue == this.formValue;
        }
    }
}
