// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.cachemanager;

import java.util.Map;
import java.nio.charset.StandardCharsets;
import org.apache.manifoldcf.core.interfaces.ICacheClass;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.StringSetBuffer;
import org.apache.manifoldcf.core.system.Logging;
import org.apache.manifoldcf.core.interfaces.ICacheCreateHandle;
import org.apache.manifoldcf.core.interfaces.ICacheHandle;
import java.util.ArrayList;
import org.apache.manifoldcf.core.interfaces.ICacheExecutor;
import org.apache.manifoldcf.core.interfaces.StringSet;
import org.apache.manifoldcf.core.interfaces.ICacheDescription;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import java.util.HashMap;
import org.apache.manifoldcf.core.interfaces.ILockManager;
import org.apache.manifoldcf.core.interfaces.ICacheManager;

public class CacheManager implements ICacheManager
{
    public static final String _rcsid = "@(#)$Id: CacheManager.java 988245 2010-08-23 18:39:35Z kwright $";
    protected static final String cacheLockPrefix = "_Cache_";
    protected ILockManager lockManager;
    protected static GeneralCache cache;
    protected HashMap transactionHash;
    
    public CacheManager(final IThreadContext context) throws ManifoldCFException {
        this.transactionHash = new HashMap();
        this.lockManager = LockManagerFactory.make(context);
    }
    
    @Override
    public void findObjectsAndExecute(final ICacheDescription[] locateObjectDescriptions, final StringSet invalidateKeys, final ICacheExecutor execObject, final String transactionID) throws ManifoldCFException {
        final ICacheHandle handle = this.enterCache(locateObjectDescriptions, invalidateKeys, transactionID);
        try {
            if (locateObjectDescriptions != null) {
                final HashMap allObjects = new HashMap();
                final ICacheCreateHandle createHandle = this.enterCreateSection(handle);
                try {
                    final ArrayList createList = new ArrayList();
                    int i = 0;
                    while (i < locateObjectDescriptions.length) {
                        final ICacheDescription objectDescription = locateObjectDescriptions[i++];
                        final StringSet set = objectDescription.getObjectKeys();
                        if (set == null) {
                            createList.add(objectDescription);
                        }
                        else {
                            final Object o = this.lookupObject(createHandle, objectDescription);
                            if (o == null) {
                                createList.add(objectDescription);
                            }
                            else {
                                allObjects.put(objectDescription, o);
                            }
                        }
                    }
                    final ICacheDescription[] createDescriptions = new ICacheDescription[createList.size()];
                    for (i = 0; i < createList.size(); ++i) {
                        createDescriptions[i] = createList.get(i);
                    }
                    final Object[] createdObjects = execObject.create(createDescriptions);
                    if (createdObjects == null) {
                        return;
                    }
                    for (i = 0; i < createdObjects.length; ++i) {
                        this.saveObject(createHandle, createDescriptions[i], createdObjects[i]);
                        allObjects.put(createDescriptions[i], createdObjects[i]);
                    }
                }
                finally {
                    this.leaveCreateSection(createHandle);
                }
                int i = 0;
                while (i < locateObjectDescriptions.length) {
                    final ICacheDescription objectDescription2 = locateObjectDescriptions[i++];
                    final Object o2 = allObjects.get(objectDescription2);
                    execObject.exists(objectDescription2, o2);
                }
            }
            if (execObject != null) {
                execObject.execute();
            }
            this.invalidateKeys(handle);
        }
        finally {
            this.leaveCache(handle);
        }
    }
    
    @Override
    public ICacheHandle enterCache(final ICacheDescription[] locateObjectDescriptions, final StringSet invalidateKeys, final String transactionID) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            final StringBuilder sb = new StringBuilder();
            if (locateObjectDescriptions != null) {
                sb.append("{");
                for (int i = 0; i < locateObjectDescriptions.length; ++i) {
                    if (i > 0) {
                        sb.append(",");
                    }
                    sb.append(locateObjectDescriptions[i].getCriticalSectionName());
                }
                sb.append("}");
            }
            else {
                sb.append("NULL");
            }
            final StringBuilder inv = new StringBuilder();
            if (invalidateKeys != null) {
                inv.append("{");
                boolean isFirst = true;
                final Iterator iter = invalidateKeys.getKeys();
                while (iter.hasNext()) {
                    if (isFirst) {
                        isFirst = false;
                    }
                    else {
                        inv.append(",");
                    }
                    inv.append(iter.next());
                }
                inv.append("}");
            }
            else {
                inv.append("NULL");
            }
            Logging.cache.debug((Object)("Entering cacher; objects = " + sb.toString() + " invalidate keys = " + inv.toString()));
        }
        final StringSetBuffer readLockTable = new StringSetBuffer();
        if (locateObjectDescriptions != null) {
            int i = 0;
            while (i < locateObjectDescriptions.length) {
                final ICacheDescription objectDescription = locateObjectDescriptions[i++];
                final StringSet keys = objectDescription.getObjectKeys();
                if (keys != null) {
                    readLockTable.add(keys);
                }
            }
        }
        final StringSet readKeys = new StringSet(readLockTable);
        CacheHandle ch;
        if (transactionID == null) {
            String[] writeLocks = null;
            if (invalidateKeys != null) {
                writeLocks = invalidateKeys.getArray("_Cache_");
            }
            final String[] readLocks = readKeys.getArray("_Cache_");
            ch = new CacheHandle(readLocks, writeLocks, locateObjectDescriptions, invalidateKeys, transactionID);
            Logging.lock.debug((Object)"Starting cache outside transaction");
            this.lockManager.enterLocks(readLocks, null, writeLocks);
            Logging.lock.debug((Object)" Done starting cache");
        }
        else {
            final CacheTransactionHandle handle = this.transactionHash.get(transactionID);
            if (handle == null) {
                final ManifoldCFException ex = new ManifoldCFException("Illegal transaction ID: '" + transactionID + "'", 0);
                Logging.cache.error((Object)(Thread.currentThread().toString() + ": enterCache: " + transactionID + ": " + this.toString() + ": Transaction hash = " + this.transactionHash.toString()), (Throwable)ex);
                throw ex;
            }
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)("Starting cache in transaction " + transactionID));
            }
            ch = new CacheHandle(null, null, locateObjectDescriptions, invalidateKeys, transactionID);
            final StringSet newReadLocks = handle.getRemainingReadLocks(readKeys, invalidateKeys);
            final StringSet newWriteLocks = handle.getRemainingWriteLocks(readKeys, invalidateKeys);
            this.lockManager.enterLocks(newReadLocks.getArray("_Cache_"), null, newWriteLocks.getArray("_Cache_"));
            handle.addLocks(newReadLocks, newWriteLocks);
        }
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Successfully entered cacher; handle = " + ch.toString()));
        }
        return ch;
    }
    
    @Override
    public ICacheCreateHandle enterCreateSection(final ICacheHandle handle) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Entering cache create section; cache handle = " + handle.toString()));
        }
        final ICacheDescription[] locateObjectDescriptions = handle.getObjectDescriptions();
        if (locateObjectDescriptions == null) {
            throw new ManifoldCFException("Can't enter create section without objects to create", 0);
        }
        int i = 0;
        final ArrayList writeCriticalSectionArray = new ArrayList();
        while (i < locateObjectDescriptions.length) {
            final ICacheDescription objectDescription = locateObjectDescriptions[i++];
            final StringSet set = objectDescription.getObjectKeys();
            if (set != null) {
                writeCriticalSectionArray.add(objectDescription.getCriticalSectionName());
            }
        }
        final String[] writeCriticalSections = new String[writeCriticalSectionArray.size()];
        for (i = 0; i < writeCriticalSectionArray.size(); ++i) {
            writeCriticalSections[i] = writeCriticalSectionArray.get(i);
        }
        final CacheCreateHandle ch = new CacheCreateHandle(writeCriticalSections, handle.getTransactionID());
        this.lockManager.enterCriticalSections(null, null, writeCriticalSections);
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Successfully entered cache create section for handle = " + handle.toString() + "; section handle = " + ch.toString()));
        }
        return ch;
    }
    
    @Override
    public Object lookupObject(final ICacheCreateHandle handle, final ICacheDescription objectDescription) throws ManifoldCFException {
        if (handle == null) {
            throw new ManifoldCFException("Can't do lookup outside of create section", 0);
        }
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Looking up object in section handle = " + handle.toString() + "; object name = '" + objectDescription.getCriticalSectionName() + "'"));
        }
        final StringSet set = objectDescription.getObjectKeys();
        if (set == null) {
            return null;
        }
        final String transactionID = handle.getTransactionID();
        if (transactionID != null) {
            CacheTransactionHandle transactionHandle = this.transactionHash.get(transactionID);
            if (transactionHandle == null) {
                final ManifoldCFException ex = new ManifoldCFException("Illegal transaction id", 0);
                Logging.cache.error((Object)(Thread.currentThread().toString() + ": lookupObject: " + transactionID + ": " + this.toString() + ": Transaction hash = " + this.transactionHash.toString()), (Throwable)ex);
                throw ex;
            }
            while (transactionHandle != null) {
                final Object q = transactionHandle.lookupObject(objectDescription);
                if (q != null) {
                    if (Logging.cache.isDebugEnabled()) {
                        Logging.cache.debug((Object)(" Object '" + objectDescription.getCriticalSectionName() + "' found in transaction cache"));
                    }
                    return q;
                }
                if (transactionHandle.checkCacheKeys(set)) {
                    return null;
                }
                transactionHandle = transactionHandle.getParentTransaction();
            }
        }
        final Object o = CacheManager.cache.lookup(objectDescription);
        if (o == null) {
            return null;
        }
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)(" Object '" + objectDescription.getCriticalSectionName() + "' exists locally; checking if local copy is valid"));
        }
        final long expireTime = CacheManager.cache.getObjectExpirationTime(objectDescription);
        if (expireTime != -1L && expireTime <= handle.getLookupTime()) {
            CacheManager.cache.deleteObject(objectDescription);
            return null;
        }
        final long createTime = CacheManager.cache.getObjectCreationTime(objectDescription);
        final StringSet keys = CacheManager.cache.getObjectInvalidationKeys(objectDescription);
        final Iterator iter = keys.getKeys();
        while (iter.hasNext()) {
            final String key = iter.next();
            if (this.hasExpired(key, createTime)) {
                CacheManager.cache.deleteObject(objectDescription);
                return null;
            }
        }
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)(" Object '" + objectDescription.getCriticalSectionName() + "' is valid; resetting local expiration"));
        }
        this.resetObjectExpiration(objectDescription, handle.getLookupTime());
        return o;
    }
    
    protected boolean hasExpired(final String key, final long createTime) throws ManifoldCFException {
        final long createdDate = this.readSharedData(key);
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)(" Checking whether our cached copy of object with key = " + key + " has been invalidated.  It has create time " + new Long(createTime).toString() + ", and the last change is " + new Long(createdDate).toString()));
        }
        return createdDate != 0L && createdDate >= createTime;
    }
    
    protected void resetObjectExpiration(final ICacheDescription objectDescription, final long currentTime) {
        final long expireInterval = objectDescription.getObjectExpirationTime(currentTime);
        CacheManager.cache.setObjectExpiration(objectDescription, expireInterval);
        final ICacheClass objectClass = objectDescription.getObjectClass();
        if (objectClass != null) {
            CacheManager.cache.setObjectClass(objectDescription, objectClass.getClassName(), objectClass.getMaxLRUCount());
        }
        else {
            CacheManager.cache.setObjectClass(objectDescription, null, Integer.MAX_VALUE);
        }
    }
    
    @Override
    public void saveObject(final ICacheCreateHandle handle, final ICacheDescription objectDescription, final Object object) throws ManifoldCFException {
        if (handle == null) {
            throw new ManifoldCFException("Can't do save outside of create section", 0);
        }
        if (Logging.cache.isDebugEnabled()) {
            final StringSet ks = objectDescription.getObjectKeys();
            final StringBuilder sb = new StringBuilder();
            if (ks != null) {
                sb.append("{");
                final Iterator iter = ks.getKeys();
                boolean isFirst = true;
                while (iter.hasNext()) {
                    if (isFirst) {
                        isFirst = false;
                    }
                    else {
                        sb.append(",");
                    }
                    sb.append(iter.next());
                }
                sb.append("}");
            }
            else {
                sb.append("NULL");
            }
            Logging.cache.debug((Object)("Saving new object in section handle = " + handle.toString() + "; object description = '" + objectDescription.getCriticalSectionName() + "; cache keys = " + sb.toString()));
        }
        final StringSet keys = objectDescription.getObjectKeys();
        if (keys != null) {
            final String transactionID = handle.getTransactionID();
            if (transactionID == null) {
                CacheManager.cache.setObject(objectDescription, object, keys, handle.getLookupTime());
                this.resetObjectExpiration(objectDescription, handle.getLookupTime());
            }
            else {
                final CacheTransactionHandle transactionHandle = this.transactionHash.get(transactionID);
                if (transactionHandle == null) {
                    final ManifoldCFException ex = new ManifoldCFException("Bad transaction handle", 0);
                    Logging.cache.error((Object)(Thread.currentThread().toString() + ": saveObject: " + transactionID + ": " + this.toString() + ": Transaction hash = " + this.transactionHash.toString()), (Throwable)ex);
                    throw ex;
                }
                transactionHandle.saveObject(objectDescription, object, keys);
            }
        }
    }
    
    @Override
    public void leaveCreateSection(final ICacheCreateHandle handle) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Leaving cache create section; section handle = " + handle.toString()));
        }
        this.lockManager.leaveCriticalSections(null, null, handle.getCriticalSectionNames());
    }
    
    @Override
    public void invalidateKeys(final ICacheHandle handle) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Invalidating keys; handle = " + handle.toString()));
        }
        final StringSet invalidateKeys = handle.getInvalidationKeys();
        final String transactionID = handle.getTransactionID();
        if (transactionID == null) {
            this.performInvalidation(invalidateKeys);
        }
        else {
            final CacheTransactionHandle transactionHandle = this.transactionHash.get(transactionID);
            if (transactionHandle == null) {
                final ManifoldCFException ex = new ManifoldCFException("Bad transaction ID!", 0);
                Logging.cache.error((Object)(Thread.currentThread().toString() + ": invalidateKeys: " + transactionID + ": " + this.toString() + ": Transaction hash = " + this.transactionHash.toString()), (Throwable)ex);
                throw ex;
            }
            transactionHandle.invalidateKeys(invalidateKeys);
        }
    }
    
    protected void performInvalidation(final StringSet keys) throws ManifoldCFException {
        if (keys != null) {
            final long invalidationTime = System.currentTimeMillis();
            final Iterator iter = keys.getKeys();
            while (iter.hasNext()) {
                final String keyName = iter.next();
                if (Logging.cache.isDebugEnabled()) {
                    Logging.cache.debug((Object)(" Invalidating key = " + keyName + " as of time = " + new Long(invalidationTime).toString()));
                }
                this.writeSharedData(keyName, invalidationTime);
            }
            CacheManager.cache.invalidateKeys(keys);
        }
    }
    
    @Override
    public void leaveCache(final ICacheHandle handle) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Leaving cacher; handle = " + handle.toString()));
        }
        this.lockManager.leaveLocks(handle.getReadLockStrings(), null, handle.getWriteLockStrings());
    }
    
    @Override
    public void startTransaction(final String startingTransactionID, final String enclosingTransactionID) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)(Thread.currentThread().toString() + ": Starting transaction: " + startingTransactionID + ": " + this.toString() + ": " + this.transactionHash.toString()));
        }
        CacheTransactionHandle parent;
        if (enclosingTransactionID == null) {
            parent = null;
        }
        else {
            parent = this.transactionHash.get(enclosingTransactionID);
            if (parent == null) {
                final ManifoldCFException ex = new ManifoldCFException("Illegal parent transaction ID: " + enclosingTransactionID, 0);
                Logging.cache.error((Object)(Thread.currentThread().toString() + ": startTransaction: " + this.toString() + ": Transaction hash = " + this.transactionHash.toString()), (Throwable)ex);
                throw ex;
            }
        }
        this.transactionHash.put(startingTransactionID, new CacheTransactionHandle(parent));
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)("Successfully created transaction: " + startingTransactionID + ": " + this.toString() + ": " + this.transactionHash.toString()));
        }
    }
    
    @Override
    public void commitTransaction(final String transactionID) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)(Thread.currentThread().toString() + ": Committing transaction: " + transactionID + ": " + this.toString() + ": " + this.transactionHash.toString()));
        }
        final CacheTransactionHandle handle = this.transactionHash.get(transactionID);
        if (handle == null) {
            throw new ManifoldCFException("Cache manager: commit transaction without start!", 0);
        }
        final CacheTransactionHandle parentTransaction = handle.getParentTransaction();
        final Iterator iter = handle.getCurrentObjects();
        final StringSet invalidationKeys = handle.getInvalidationKeys();
        if (parentTransaction == null) {
            this.performInvalidation(invalidationKeys);
            final long currentTime = System.currentTimeMillis();
            while (iter.hasNext()) {
                final ICacheDescription desc = iter.next();
                final Object o = handle.lookupObject(desc);
                CacheManager.cache.setObject(desc, o, desc.getObjectKeys(), currentTime);
                this.resetObjectExpiration(desc, currentTime);
            }
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)("Ending transaction write locks for transaction " + transactionID));
            }
            this.lockManager.leaveLocks(null, null, handle.getWriteLocks().getArray("_Cache_"));
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)("Ending transaction read locks for transaction " + transactionID));
            }
            this.lockManager.leaveLocks(handle.getReadLocks().getArray("_Cache_"), null, null);
            if (Logging.lock.isDebugEnabled()) {
                Logging.lock.debug((Object)("Done ending " + transactionID));
            }
        }
        else {
            parentTransaction.invalidateKeys(invalidationKeys);
            while (iter.hasNext()) {
                final ICacheDescription desc2 = iter.next();
                final Object o2 = handle.lookupObject(desc2);
                parentTransaction.saveObject(desc2, o2, desc2.getObjectKeys());
            }
            parentTransaction.addLocks(handle.getReadLocks(), handle.getWriteLocks());
        }
        this.transactionHash.remove(transactionID);
    }
    
    @Override
    public void rollbackTransaction(final String transactionID) throws ManifoldCFException {
        if (Logging.cache.isDebugEnabled()) {
            Logging.cache.debug((Object)(Thread.currentThread().toString() + ": Rolling back transaction: " + transactionID + ": " + this.toString() + ": " + this.transactionHash.toString()));
        }
        final CacheTransactionHandle handle = this.transactionHash.get(transactionID);
        if (handle == null) {
            throw new ManifoldCFException("Cache manager: rollback transaction without start!", 0);
        }
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Ending rollback write locks for transaction " + transactionID));
        }
        this.lockManager.leaveLocks(null, null, handle.getWriteLocks().getArray("_Cache_"));
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Ending rollback read locks for transaction " + transactionID));
        }
        this.lockManager.leaveLocks(handle.getReadLocks().getArray("_Cache_"), null, null);
        if (Logging.lock.isDebugEnabled()) {
            Logging.lock.debug((Object)("Done rolling back " + transactionID));
        }
        this.transactionHash.remove(transactionID);
    }
    
    @Override
    public void expireObjects(final long currentTimestamp) throws ManifoldCFException {
        CacheManager.cache.expireRecords(currentTimestamp);
    }
    
    protected long readSharedData(final String key) throws ManifoldCFException {
        final byte[] cacheResourceData = this.lockManager.readData("cache-" + key);
        if (cacheResourceData == null) {
            return 0L;
        }
        final String expiration = new String(cacheResourceData, StandardCharsets.UTF_8);
        return new Long(expiration);
    }
    
    protected void writeSharedData(final String key, final long value) throws ManifoldCFException {
        if (value == 0L) {
            this.lockManager.writeData(key, null);
        }
        else {
            this.lockManager.writeData("cache-" + key, Long.toString(value).getBytes(StandardCharsets.UTF_8));
        }
    }
    
    static {
        CacheManager.cache = new GeneralCache();
    }
    
    protected class CacheHandle implements ICacheHandle
    {
        protected String[] readLocks;
        protected String[] writeLocks;
        protected ICacheDescription[] objectDescriptions;
        protected StringSet invalidationKeys;
        protected String transactionID;
        
        public CacheHandle(final String[] readLocks, final String[] writeLocks, final ICacheDescription[] descriptions, final StringSet invalidationKeys, final String transactionID) {
            this.readLocks = readLocks;
            this.writeLocks = writeLocks;
            this.objectDescriptions = descriptions;
            this.invalidationKeys = invalidationKeys;
            this.transactionID = transactionID;
        }
        
        @Override
        public String[] getReadLockStrings() {
            return this.readLocks;
        }
        
        @Override
        public String[] getWriteLockStrings() {
            return this.writeLocks;
        }
        
        @Override
        public ICacheDescription[] getObjectDescriptions() {
            return this.objectDescriptions;
        }
        
        @Override
        public StringSet getInvalidationKeys() {
            return this.invalidationKeys;
        }
        
        @Override
        public String getTransactionID() {
            return this.transactionID;
        }
    }
    
    protected class CacheCreateHandle implements ICacheCreateHandle
    {
        protected String[] criticalSectionNames;
        protected long theTime;
        protected String transactionID;
        
        public CacheCreateHandle(final String[] criticalSectionNames, final String transactionID) {
            this.criticalSectionNames = criticalSectionNames;
            this.theTime = System.currentTimeMillis();
            this.transactionID = transactionID;
        }
        
        @Override
        public String[] getCriticalSectionNames() {
            return this.criticalSectionNames;
        }
        
        @Override
        public long getLookupTime() {
            return this.theTime;
        }
        
        @Override
        public String getTransactionID() {
            return this.transactionID;
        }
    }
    
    protected class CacheTransactionHandle
    {
        protected CacheTransactionHandle parentTransaction;
        protected HashMap objectHash;
        protected HashMap cacheKeyMap;
        protected HashMap cacheKeyReadLocks;
        protected HashMap cacheKeyWriteLocks;
        protected StringSetBuffer invalidationKeys;
        
        public CacheTransactionHandle(final CacheTransactionHandle parentTransaction) {
            this.objectHash = new HashMap();
            this.cacheKeyMap = new HashMap();
            this.cacheKeyReadLocks = new HashMap();
            this.cacheKeyWriteLocks = new HashMap();
            this.invalidationKeys = new StringSetBuffer();
            this.parentTransaction = parentTransaction;
        }
        
        public CacheTransactionHandle getParentTransaction() {
            return this.parentTransaction;
        }
        
        public StringSet getWriteLocks() {
            return new StringSet(this.cacheKeyWriteLocks);
        }
        
        public StringSet getReadLocks() {
            return new StringSet(this.cacheKeyReadLocks);
        }
        
        public StringSet getInvalidationKeys() {
            return new StringSet(this.invalidationKeys);
        }
        
        public Object lookupObject(final ICacheDescription descriptionObject) {
            return this.objectHash.get(descriptionObject);
        }
        
        public void saveObject(final ICacheDescription descriptionObject, final Object object, final StringSet cacheKeys) {
            this.objectHash.put(descriptionObject, object);
            final Iterator iter = cacheKeys.getKeys();
            while (iter.hasNext()) {
                final String key = iter.next();
                HashMap thisHash = this.cacheKeyMap.get(key);
                if (thisHash == null) {
                    thisHash = new HashMap();
                    this.cacheKeyMap.put(key, thisHash);
                }
                thisHash.put(descriptionObject, descriptionObject);
            }
        }
        
        public void invalidateKeys(final StringSet keys) {
            if (keys == null) {
                return;
            }
            this.invalidationKeys.add(keys);
            final Iterator iter = keys.getKeys();
            while (iter.hasNext()) {
                final String keyName = iter.next();
                final HashMap x = this.cacheKeyMap.get(keyName);
                if (x != null) {
                    for (final ICacheDescription desc : x.keySet()) {
                        this.objectHash.remove(desc);
                    }
                    this.cacheKeyMap.remove(keyName);
                }
            }
        }
        
        public boolean checkCacheKeys(final StringSet cacheKeys) {
            return this.invalidationKeys.contains(cacheKeys);
        }
        
        public StringSet getRemainingReadLocks(final StringSet cacheKeys, final StringSet keys) {
            final StringSetBuffer accumulator = new StringSetBuffer();
            if (cacheKeys != null) {
                final Iterator iter = cacheKeys.getKeys();
                while (iter.hasNext()) {
                    final String cacheKey = iter.next();
                    if (keys != null && keys.contains(cacheKey)) {
                        continue;
                    }
                    CacheTransactionHandle ptr = this;
                    boolean found = false;
                    while (ptr != null) {
                        if (ptr.cacheKeyReadLocks.get(cacheKey) != null || ptr.cacheKeyWriteLocks.get(cacheKey) != null) {
                            found = true;
                            break;
                        }
                        ptr = ptr.parentTransaction;
                    }
                    if (found) {
                        continue;
                    }
                    accumulator.add(cacheKey);
                }
            }
            return new StringSet(accumulator);
        }
        
        public StringSet getRemainingWriteLocks(final StringSet cacheKeys, final StringSet keys) throws ManifoldCFException {
            final StringSetBuffer accumulator = new StringSetBuffer();
            if (keys != null) {
                final Iterator iter = keys.getKeys();
                while (iter.hasNext()) {
                    final String invKey = iter.next();
                    CacheTransactionHandle ptr = this;
                    boolean found = false;
                    while (ptr != null) {
                        if (ptr.cacheKeyWriteLocks.get(invKey) != null) {
                            found = true;
                            break;
                        }
                        if (ptr.cacheKeyReadLocks.get(invKey) != null) {
                            break;
                        }
                        ptr = ptr.parentTransaction;
                    }
                    if (found) {
                        continue;
                    }
                    accumulator.add(invKey);
                }
            }
            return new StringSet(accumulator);
        }
        
        public void addLocks(final StringSet thrownReadLocks, final StringSet thrownWriteLocks) {
            Iterator iter = thrownReadLocks.getKeys();
            while (iter.hasNext()) {
                final String x = iter.next();
                this.cacheKeyReadLocks.put(x, x);
            }
            iter = thrownWriteLocks.getKeys();
            while (iter.hasNext()) {
                final String x = iter.next();
                this.cacheKeyWriteLocks.put(x, x);
            }
        }
        
        public Iterator getCurrentObjects() {
            return this.objectHash.keySet().iterator();
        }
    }
}
