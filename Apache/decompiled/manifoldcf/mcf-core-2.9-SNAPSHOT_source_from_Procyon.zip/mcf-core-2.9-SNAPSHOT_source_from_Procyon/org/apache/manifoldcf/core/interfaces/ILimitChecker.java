// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface ILimitChecker
{
    public static final String _rcsid = "@(#)$Id: ILimitChecker.java 988245 2010-08-23 18:39:35Z kwright $";
    
    boolean doesCompareWork();
    
    ILimitChecker duplicate();
    
    int hashCode();
    
    boolean equals(final Object p0);
    
    boolean checkInclude(final IResultRow p0) throws ManifoldCFException;
    
    boolean checkContinue() throws ManifoldCFException;
}
