// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core;

import org.apache.manifoldcf.core.interfaces.ManifoldCFException;

public interface InitializationCommand
{
    void execute() throws ManifoldCFException;
}
