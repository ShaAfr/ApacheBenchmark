// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.util;

import org.apache.manifoldcf.core.interfaces.ManifoldCFException;

public class Converter
{
    public static final String _rcsid = "@(#)$Id$";
    
    public static double asDouble(final Object o) throws ManifoldCFException {
        if (o instanceof Double) {
            return (double)o;
        }
        if (o instanceof String) {
            return new Double((String)o);
        }
        if (o instanceof Float) {
            return (float)o;
        }
        if (o instanceof Long) {
            return (double)(long)o;
        }
        throw new ManifoldCFException("Can't convert to double");
    }
    
    public static long asLong(final Object o) throws ManifoldCFException {
        if (o instanceof Long) {
            return (long)o;
        }
        if (o instanceof Double) {
            return (long)(double)o;
        }
        if (o instanceof String) {
            return new Long((String)o);
        }
        if (o instanceof Float) {
            return (long)(float)o;
        }
        throw new ManifoldCFException("Can't convert to long");
    }
}
