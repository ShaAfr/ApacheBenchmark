// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IResultSet
{
    public static final String _rcsid = "@(#)$Id: IResultSet.java 988245 2010-08-23 18:39:35Z kwright $";
    
    IResultRow getRow(final int p0);
    
    int getRowCount();
    
    IResultRow[] getRows();
}
