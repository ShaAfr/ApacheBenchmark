// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import java.io.File;

public class FileLockObjectFactory extends LockObjectFactory
{
    public static final String _rcsid = "@(#)$Id$";
    protected final File synchDir;
    
    public FileLockObjectFactory(final File synchDir) {
        this.synchDir = synchDir;
    }
    
    @Override
    public LockObject newLockObject(final LockPool lockPool, final Object lockKey) {
        return new FileLockObject(lockPool, lockKey, this.synchDir);
    }
}
