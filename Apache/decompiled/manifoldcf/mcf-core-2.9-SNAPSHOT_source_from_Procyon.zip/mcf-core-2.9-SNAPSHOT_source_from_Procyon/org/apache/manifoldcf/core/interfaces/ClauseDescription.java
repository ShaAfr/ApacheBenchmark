// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.List;

public interface ClauseDescription
{
    public static final String _rcsid = "@(#)$Id$";
    
    String getColumnName();
    
    String getOperation();
    
    List getValues();
    
    String getJoinColumnName();
}
