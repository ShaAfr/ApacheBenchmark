// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import org.apache.manifoldcf.core.interfaces.IResultRow;
import java.util.ArrayList;
import org.apache.manifoldcf.core.interfaces.IResultSet;

public class MergedResultSet implements IResultSet
{
    public static final String _rcsid = "@(#)$Id: MergedResultSet.java 988245 2010-08-23 18:39:35Z kwright $";
    protected ArrayList resultSets;
    protected int totalRowCount;
    
    public MergedResultSet() {
        this.resultSets = new ArrayList();
        this.totalRowCount = 0;
    }
    
    public void addResultSet(final IResultSet set) {
        this.resultSets.add(set);
        this.totalRowCount += set.getRowCount();
    }
    
    @Override
    public IResultRow getRow(int rowNumber) {
        int j = 0;
        while (j < this.resultSets.size()) {
            final IResultSet set = this.resultSets.get(j++);
            if (set.getRowCount() > rowNumber) {
                return set.getRow(rowNumber);
            }
            rowNumber -= set.getRowCount();
        }
        return null;
    }
    
    @Override
    public int getRowCount() {
        return this.totalRowCount;
    }
    
    @Override
    public IResultRow[] getRows() {
        final IResultRow[] rval = new IResultRow[this.totalRowCount];
        int i = 0;
        int j = 0;
        while (j < this.resultSets.size()) {
            final IResultSet set = this.resultSets.get(j++);
            for (int k = 0; k < set.getRowCount(); rval[i++] = set.getRow(k++)) {}
        }
        return rval;
    }
}
