// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class IDFactory
{
    public static final String _rcsid = "@(#)$Id: IDFactory.java 988245 2010-08-23 18:39:35Z kwright $";
    private static ArrayList idPool;
    private static final int poolSize = 100;
    private static final String criticalSectionName = "_IDFACTORY_";
    private static final String globalLockName = "_IDFACTORY_";
    private static final String globalIDDataName = "_IDFACTORY_";
    
    private IDFactory() {
    }
    
    public static String make(final IThreadContext tc) throws ManifoldCFException {
        final ILockManager lockManager = LockManagerFactory.make(tc);
        lockManager.enterWriteCriticalSection("_IDFACTORY_");
        try {
            if (IDFactory.idPool.size() == 0) {
                lockManager.enterWriteLock("_IDFACTORY_");
                try {
                    final byte[] idData = lockManager.readData("_IDFACTORY_");
                    long _id;
                    if (idData == null) {
                        _id = 0L;
                    }
                    else {
                        _id = new Long(new String(idData, StandardCharsets.UTF_8));
                    }
                    for (int i = 0; i < 100; ++i) {
                        long newid = System.currentTimeMillis();
                        if (newid <= _id) {
                            newid = _id + 1L;
                        }
                        _id = newid;
                        IDFactory.idPool.add(Long.toString(newid));
                    }
                    lockManager.writeData("_IDFACTORY_", Long.toString(_id).getBytes(StandardCharsets.UTF_8));
                }
                finally {
                    lockManager.leaveWriteLock("_IDFACTORY_");
                }
            }
            return IDFactory.idPool.remove(IDFactory.idPool.size() - 1);
        }
        finally {
            lockManager.leaveWriteCriticalSection("_IDFACTORY_");
        }
    }
    
    static {
        IDFactory.idPool = new ArrayList();
    }
}
