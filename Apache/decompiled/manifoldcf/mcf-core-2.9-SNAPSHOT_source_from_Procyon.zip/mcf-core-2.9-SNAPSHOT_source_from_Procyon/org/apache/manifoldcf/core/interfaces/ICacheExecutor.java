// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface ICacheExecutor
{
    public static final String _rcsid = "@(#)$Id: ICacheExecutor.java 988245 2010-08-23 18:39:35Z kwright $";
    
    Object[] create(final ICacheDescription[] p0) throws ManifoldCFException;
    
    void exists(final ICacheDescription p0, final Object p1) throws ManifoldCFException;
    
    void execute() throws ManifoldCFException;
}
