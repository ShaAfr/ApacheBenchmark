// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.threadcontext;

import java.util.Hashtable;
import org.apache.manifoldcf.core.interfaces.IThreadContext;

public class ThreadContext implements IThreadContext
{
    public static final String _rcsid = "@(#)$Id: ThreadContext.java 988245 2010-08-23 18:39:35Z kwright $";
    protected Hashtable hashtable;
    
    public ThreadContext() {
        this.hashtable = new Hashtable();
    }
    
    @Override
    public void save(final Object key, final Object object) {
        if (object == null) {
            this.hashtable.remove(key);
        }
        else {
            this.hashtable.put(key, object);
        }
    }
    
    @Override
    public Object get(final Object key) {
        return this.hashtable.get(key);
    }
}
