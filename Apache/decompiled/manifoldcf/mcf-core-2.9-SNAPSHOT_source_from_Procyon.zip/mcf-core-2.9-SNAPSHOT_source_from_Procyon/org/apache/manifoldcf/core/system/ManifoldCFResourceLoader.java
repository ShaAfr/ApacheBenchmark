// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.system;

import java.net.URLClassLoader;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.FileFilter;
import java.io.File;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.util.ArrayList;

public class ManifoldCFResourceLoader
{
    public static final String _rcsid = "@(#)$Id: ManifoldCFResourceLoader.java 988245 2010-08-23 18:39:35Z kwright $";
    protected ClassLoader parent;
    protected ClassLoader classLoader;
    protected ArrayList currentClasspath;
    
    public ManifoldCFResourceLoader(final ClassLoader parent) throws ManifoldCFException {
        this.classLoader = null;
        this.currentClasspath = new ArrayList();
        this.parent = parent;
    }
    
    public synchronized void setClassPath(final ArrayList libdirList) throws ManifoldCFException {
        if (this.currentClasspath.size() > 0) {
            this.currentClasspath.clear();
            this.classLoader = null;
        }
        int i = 0;
        while (i < libdirList.size()) {
            final File dir = libdirList.get(i++);
            this.addToClassPath(dir, null);
        }
    }
    
    public synchronized void clearClassPath() {
        if (this.currentClasspath.size() == 0) {
            return;
        }
        this.currentClasspath.clear();
        this.classLoader = null;
    }
    
    public synchronized void addToClassPath(final File file) throws ManifoldCFException {
        if (file.canRead()) {
            this.addDirsToClassPath(new File[] { file.getParentFile() }, new FileFilter[] { new FileFilter() {
                    @Override
                    public boolean accept(final File pathname) {
                        return pathname.equals(file);
                    }
                } });
            return;
        }
        throw new ManifoldCFException("Path '" + file.toString() + "' does not exist or is not readable");
    }
    
    public synchronized void addToClassPath(final File dir, final FileFilter filter) throws ManifoldCFException {
        this.addDirsToClassPath(new File[] { dir }, new FileFilter[] { filter });
    }
    
    public synchronized ClassLoader getClassLoader() throws ManifoldCFException {
        if (this.classLoader == null) {
            if (this.currentClasspath.size() == 0) {
                this.classLoader = this.parent;
            }
            else {
                final URL[] elements = new URL[this.currentClasspath.size()];
                for (int j = 0; j < this.currentClasspath.size(); ++j) {
                    try {
                        final URL element = this.currentClasspath.get(j).toURI().normalize().toURL();
                        elements[j] = element;
                    }
                    catch (MalformedURLException e) {
                        throw new ManifoldCFException(e.getMessage(), e);
                    }
                }
                this.classLoader = URLClassLoader.newInstance(elements, this.parent);
            }
        }
        return this.classLoader;
    }
    
    public Class findClass(final String cname) throws ClassNotFoundException, ManifoldCFException {
        return Class.forName(cname, true, this.getClassLoader());
    }
    
    protected void addDirsToClassPath(final File[] baseList, final FileFilter[] filterList) throws ManifoldCFException {
        for (int i = 0; i < baseList.length; ++i) {
            final File base = baseList[i];
            FileFilter filter;
            if (filterList != null) {
                filter = filterList[i];
            }
            else {
                filter = null;
            }
            if (!base.canRead() || !base.isDirectory()) {
                throw new ManifoldCFException("Supposed directory '" + base.toString() + "' is either not a directory, or is unreadable.");
            }
            final File[] files = base.listFiles(filter);
            if (files != null && files.length > 0) {
                int j = 0;
                while (j < files.length) {
                    final File file = files[j++];
                    this.currentClasspath.add(file);
                    this.classLoader = null;
                }
            }
        }
    }
}
