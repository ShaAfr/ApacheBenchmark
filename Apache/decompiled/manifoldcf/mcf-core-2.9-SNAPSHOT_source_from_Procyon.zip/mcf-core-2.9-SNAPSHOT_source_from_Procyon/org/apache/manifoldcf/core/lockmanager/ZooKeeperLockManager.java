// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import org.apache.manifoldcf.core.interfaces.IThreadContext;
import java.io.FileInputStream;
import org.apache.manifoldcf.core.interfaces.ThreadContextFactory;
import java.io.File;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import org.apache.manifoldcf.core.interfaces.IServiceDataAcceptor;
import java.util.Iterator;
import java.util.List;
import org.apache.manifoldcf.core.interfaces.IServiceCleanup;
import org.apache.manifoldcf.core.interfaces.IShutdownHook;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.interfaces.ManifoldCFConfiguration;
import org.apache.manifoldcf.core.interfaces.ILockManager;

public class ZooKeeperLockManager extends BaseLockManager implements ILockManager
{
    public static final String _rcsid = "@(#)$Id: LockManager.java 988245 2010-08-23 18:39:35Z kwright $";
    protected static final String zookeeperConnectStringParameter = "org.apache.manifoldcf.zookeeper.connectstring";
    protected static final String zookeeperSessionTimeoutParameter = "org.apache.manifoldcf.zookeeper.sessiontimeout";
    private static final String CONFIGURATION_PATH = "/org.apache.manifoldcf/configuration";
    private static final String RESOURCE_PATH_PREFIX = "/org.apache.manifoldcf/resources-";
    private static final String FLAG_PATH_PREFIX = "/org.apache.manifoldcf/flags-";
    private static final String SERVICETYPE_LOCK_PATH_PREFIX = "/org.apache.manifoldcf/servicelock-";
    private static final String SERVICETYPE_ACTIVE_PATH_PREFIX = "/org.apache.manifoldcf/serviceactive-";
    private static final String SERVICETYPE_REGISTER_PATH_PREFIX = "/org.apache.manifoldcf/service-";
    private static final String SERVICETYPE_ANONYMOUS_COUNTER_PREFIX = "/org.apache.manifoldcf/serviceanon-";
    protected static final String anonymousServiceNamePrefix = "_ANON_";
    protected static Integer connectionPoolLock;
    protected static ZooKeeperConnectionPool pool;
    protected static Integer zookeeperPoolLocker;
    protected static LockPool myZooKeeperLocks;
    protected static Integer ephemeralPoolLocker;
    protected static ZooKeeperEphemeralNodePool myEphemeralNodes;
    protected ManifoldCFConfiguration cachedConfiguration;
    
    public ZooKeeperLockManager() throws ManifoldCFException {
        this.cachedConfiguration = null;
        synchronized (ZooKeeperLockManager.connectionPoolLock) {
            if (ZooKeeperLockManager.pool == null) {
                final String connectString = ManifoldCF.getStringProperty("org.apache.manifoldcf.zookeeper.connectstring", null);
                if (connectString == null) {
                    throw new ManifoldCFException("Zookeeper lock manager requires a valid org.apache.manifoldcf.zookeeper.connectstring property");
                }
                final int sessionTimeout = ManifoldCF.getIntProperty("org.apache.manifoldcf.zookeeper.sessiontimeout", 300000);
                ManifoldCF.addShutdownHook(new ZooKeeperShutdown());
                ZooKeeperLockManager.pool = new ZooKeeperConnectionPool(connectString, sessionTimeout);
            }
        }
        synchronized (ZooKeeperLockManager.zookeeperPoolLocker) {
            if (ZooKeeperLockManager.myZooKeeperLocks == null) {
                ZooKeeperLockManager.myZooKeeperLocks = new LockPool(new ZooKeeperLockObjectFactory(ZooKeeperLockManager.pool));
            }
        }
        synchronized (ZooKeeperLockManager.ephemeralPoolLocker) {
            if (ZooKeeperLockManager.myEphemeralNodes == null) {
                ZooKeeperLockManager.myEphemeralNodes = new ZooKeeperEphemeralNodePool(ZooKeeperLockManager.pool);
            }
        }
    }
    
    @Override
    public String registerServiceBeginServiceActivity(final String serviceType, final String serviceName, final IServiceCleanup cleanup) throws ManifoldCFException {
        return this.registerServiceBeginServiceActivity(serviceType, serviceName, null, cleanup);
    }
    
    @Override
    public String registerServiceBeginServiceActivity(final String serviceType, String serviceName, final byte[] initialData, final IServiceCleanup cleanup) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryWriteLock(connection, serviceType);
                try {
                    if (serviceName == null) {
                        serviceName = this.constructUniqueServiceName(connection, serviceType);
                    }
                    final String encodedServiceName = ZooKeeperConnection.zooKeeperSafeName(serviceName);
                    final String activePath = buildServiceTypeActivePath(serviceType, encodedServiceName);
                    if (connection.checkNodeExists(activePath)) {
                        throw new ManifoldCFException("Service '" + serviceName + "' of type '" + serviceType + "' is already active");
                    }
                    final String registrationNodePath = buildServiceTypeRegistrationPath(serviceType);
                    final List<String> children = connection.getChildren(registrationNodePath);
                    boolean foundService = false;
                    boolean foundActiveService = false;
                    for (final String encodedRegisteredServiceName : children) {
                        if (encodedRegisteredServiceName.equals(encodedServiceName)) {
                            foundService = true;
                        }
                        if (connection.checkNodeExists(buildServiceTypeActivePath(serviceType, encodedRegisteredServiceName))) {
                            foundActiveService = true;
                        }
                    }
                    boolean unregisterAll = false;
                    if (cleanup != null) {
                        if (children.size() == 0) {
                            cleanup.cleanUpAllServices();
                            cleanup.clusterInit();
                        }
                        else if (foundService && foundActiveService) {
                            cleanup.cleanUpService(serviceName);
                        }
                        else if (!foundActiveService) {
                            cleanup.cleanUpAllServices();
                            cleanup.clusterInit();
                            unregisterAll = true;
                        }
                    }
                    if (unregisterAll) {
                        for (final String encodedRegisteredServiceName2 : children) {
                            if (!encodedRegisteredServiceName2.equals(encodedServiceName)) {
                                connection.deleteChild(registrationNodePath, encodedRegisteredServiceName2);
                            }
                        }
                    }
                    if (!foundService) {
                        connection.createChild(registrationNodePath, encodedServiceName);
                    }
                    ZooKeeperLockManager.myEphemeralNodes.createNode(activePath, initialData);
                    return serviceName;
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public void updateServiceData(final String serviceType, final String serviceName, final byte[] serviceData) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryWriteLock(connection, serviceType);
                try {
                    final String activePath = buildServiceTypeActivePath(serviceType, ZooKeeperConnection.zooKeeperSafeName(serviceName));
                    ZooKeeperLockManager.myEphemeralNodes.setNodeData(activePath, (serviceData == null) ? new byte[0] : serviceData);
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public byte[] retrieveServiceData(final String serviceType, final String serviceName) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryReadLock(connection, serviceType);
                try {
                    final String activePath = buildServiceTypeActivePath(serviceType, ZooKeeperConnection.zooKeeperSafeName(serviceName));
                    return connection.getNodeData(activePath);
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public void scanServiceData(final String serviceType, final IServiceDataAcceptor dataAcceptor) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryReadLock(connection, serviceType);
                try {
                    final String registrationNodePath = buildServiceTypeRegistrationPath(serviceType);
                    final List<String> children = connection.getChildren(registrationNodePath);
                    for (final String encodedRegisteredServiceName : children) {
                        final String activeNodePath = buildServiceTypeActivePath(serviceType, encodedRegisteredServiceName);
                        if (connection.checkNodeExists(activeNodePath)) {
                            final byte[] serviceData = connection.getNodeData(activeNodePath);
                            if (dataAcceptor.acceptServiceData(ZooKeeperConnection.zooKeeperDecodeSafeName(encodedRegisteredServiceName), serviceData)) {
                                break;
                            }
                            continue;
                        }
                    }
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public int countActiveServices(final String serviceType) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryReadLock(connection, serviceType);
                try {
                    final String registrationNodePath = buildServiceTypeRegistrationPath(serviceType);
                    final List<String> children = connection.getChildren(registrationNodePath);
                    int activeServiceCount = 0;
                    for (final String encodedRegisteredServiceName : children) {
                        if (connection.checkNodeExists(buildServiceTypeActivePath(serviceType, encodedRegisteredServiceName))) {
                            ++activeServiceCount;
                        }
                    }
                    return activeServiceCount;
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public boolean cleanupInactiveService(final String serviceType, final IServiceCleanup cleanup) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryWriteLock(connection, serviceType);
                try {
                    final String registrationNodePath = buildServiceTypeRegistrationPath(serviceType);
                    final List<String> children = connection.getChildren(registrationNodePath);
                    String encodedServiceName = null;
                    for (final String encodedRegisteredServiceName : children) {
                        if (!connection.checkNodeExists(buildServiceTypeActivePath(serviceType, encodedRegisteredServiceName))) {
                            encodedServiceName = encodedRegisteredServiceName;
                            break;
                        }
                    }
                    if (encodedServiceName == null) {
                        return true;
                    }
                    cleanup.cleanUpService(ZooKeeperConnection.zooKeeperDecodeSafeName(encodedServiceName));
                    connection.deleteChild(registrationNodePath, encodedServiceName);
                    return false;
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public void endServiceActivity(final String serviceType, final String serviceName) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryWriteLock(connection, serviceType);
                try {
                    ZooKeeperLockManager.myEphemeralNodes.deleteNode(buildServiceTypeActivePath(serviceType, ZooKeeperConnection.zooKeeperSafeName(serviceName)));
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public boolean checkServiceActive(final String serviceType, final String serviceName) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                this.enterServiceRegistryReadLock(connection, serviceType);
                try {
                    return connection.checkNodeExists(buildServiceTypeActivePath(serviceType, ZooKeeperConnection.zooKeeperSafeName(serviceName)));
                }
                finally {
                    this.leaveServiceRegistryLock(connection);
                }
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    protected void enterServiceRegistryReadLock(final ZooKeeperConnection connection, final String serviceType) throws ManifoldCFException, InterruptedException {
        final String serviceTypeLock = buildServiceTypeLockPath(serviceType);
        while (!connection.obtainReadLockNoWait(serviceTypeLock)) {
            ManifoldCF.sleep(100L);
        }
    }
    
    protected void enterServiceRegistryWriteLock(final ZooKeeperConnection connection, final String serviceType) throws ManifoldCFException, InterruptedException {
        final String serviceTypeLock = buildServiceTypeLockPath(serviceType);
        while (!connection.obtainWriteLockNoWait(serviceTypeLock)) {
            ManifoldCF.sleep(100L);
        }
    }
    
    protected void leaveServiceRegistryLock(final ZooKeeperConnection connection) throws ManifoldCFException, InterruptedException {
        connection.releaseLock();
    }
    
    protected String constructUniqueServiceName(final ZooKeeperConnection connection, final String serviceType) throws ManifoldCFException, InterruptedException {
        final String serviceCounterName = makeServiceCounterName(serviceType);
        final int serviceUID = this.readServiceCounter(connection, serviceCounterName);
        this.writeServiceCounter(connection, serviceCounterName, serviceUID + 1);
        return "_ANON_" + serviceUID;
    }
    
    protected static String makeServiceCounterName(final String serviceType) {
        return "/org.apache.manifoldcf/serviceanon-" + ZooKeeperConnection.zooKeeperSafeName(serviceType);
    }
    
    protected int readServiceCounter(final ZooKeeperConnection connection, final String serviceCounterName) throws ManifoldCFException, InterruptedException {
        final byte[] serviceCounterData = connection.readData(serviceCounterName);
        int rval;
        if (serviceCounterData == null || serviceCounterData.length != 4) {
            rval = 0;
        }
        else {
            rval = (serviceCounterData[0] & 0xFF) + (serviceCounterData[1] << 8 & 0xFF00) + (serviceCounterData[2] << 16 & 0xFF0000) + (serviceCounterData[3] << 24 & 0xFF000000);
        }
        return rval;
    }
    
    protected void writeServiceCounter(final ZooKeeperConnection connection, final String serviceCounterName, final int counter) throws ManifoldCFException, InterruptedException {
        final byte[] serviceCounterData = { (byte)(counter & 0xFF), (byte)(counter >> 8 & 0xFF), (byte)(counter >> 16 & 0xFF), (byte)(counter >> 24 & 0xFF) };
        connection.writeData(serviceCounterName, serviceCounterData);
    }
    
    protected static String buildServiceTypeLockPath(final String serviceType) {
        return "/org.apache.manifoldcf/servicelock-" + ZooKeeperConnection.zooKeeperSafeName(serviceType);
    }
    
    protected static String buildServiceTypeActivePath(final String serviceType, final String encodedServiceName) {
        return "/org.apache.manifoldcf/serviceactive-" + ZooKeeperConnection.zooKeeperSafeName(serviceType) + "-" + encodedServiceName;
    }
    
    protected static String buildServiceTypeRegistrationPath(final String serviceType) {
        return "/org.apache.manifoldcf/service-" + ZooKeeperConnection.zooKeeperSafeName(serviceType);
    }
    
    @Override
    public ManifoldCFConfiguration getSharedConfiguration() throws ManifoldCFException {
        if (this.cachedConfiguration == null) {
            try {
                final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
                try {
                    final byte[] configurationData = connection.readData("/org.apache.manifoldcf/configuration");
                    if (configurationData != null) {
                        this.cachedConfiguration = new ManifoldCFConfiguration(new ByteArrayInputStream(configurationData));
                    }
                    else {
                        this.cachedConfiguration = new ManifoldCFConfiguration();
                    }
                }
                finally {
                    ZooKeeperLockManager.pool.release(connection);
                }
            }
            catch (InterruptedException e) {
                throw new ManifoldCFException(e.getMessage(), e, 2);
            }
        }
        return this.cachedConfiguration;
    }
    
    public void setSharedConfiguration(final InputStream configurationInputStream) throws ManifoldCFException {
        try {
            final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            final byte[] data = new byte[65536];
            while (true) {
                final int nRead = configurationInputStream.read(data, 0, data.length);
                if (nRead == -1) {
                    break;
                }
                buffer.write(data, 0, nRead);
            }
            buffer.flush();
            final byte[] toWrite = buffer.toByteArray();
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                connection.writeData("/org.apache.manifoldcf/configuration", toWrite);
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedIOException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
        catch (IOException e2) {
            throw new ManifoldCFException(e2.getMessage(), e2);
        }
        catch (InterruptedException e3) {
            throw new ManifoldCFException(e3.getMessage(), e3, 2);
        }
    }
    
    @Override
    public void setGlobalFlag(final String flagName) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                connection.setGlobalFlag("/org.apache.manifoldcf/flags-" + ZooKeeperConnection.zooKeeperSafeName(flagName));
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public void clearGlobalFlag(final String flagName) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                connection.clearGlobalFlag("/org.apache.manifoldcf/flags-" + ZooKeeperConnection.zooKeeperSafeName(flagName));
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public boolean checkGlobalFlag(final String flagName) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                return connection.checkGlobalFlag("/org.apache.manifoldcf/flags-" + ZooKeeperConnection.zooKeeperSafeName(flagName));
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public byte[] readData(final String resourceName) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                return connection.readData("/org.apache.manifoldcf/resources-" + ZooKeeperConnection.zooKeeperSafeName(resourceName));
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    @Override
    public void writeData(final String resourceName, final byte[] data) throws ManifoldCFException {
        try {
            final ZooKeeperConnection connection = ZooKeeperLockManager.pool.grab();
            try {
                connection.writeData("/org.apache.manifoldcf/resources-" + ZooKeeperConnection.zooKeeperSafeName(resourceName), data);
            }
            finally {
                ZooKeeperLockManager.pool.release(connection);
            }
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    public static void main(final String[] argv) {
        if (argv.length != 1) {
            System.err.println("Usage: ZooKeeperLockManager <shared_configuration_file>");
            System.exit(1);
        }
        final File file = new File(argv[0]);
        try {
            final IThreadContext tc = ThreadContextFactory.make();
            ManifoldCF.initializeEnvironment(tc);
            try {
                final FileInputStream fis = new FileInputStream(file);
                try {
                    new ZooKeeperLockManager().setSharedConfiguration(fis);
                }
                finally {
                    fis.close();
                }
            }
            finally {
                ManifoldCF.cleanUpEnvironment(tc);
            }
        }
        catch (Throwable e) {
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }
    
    @Override
    protected LockPool getGlobalLockPool() {
        return ZooKeeperLockManager.myZooKeeperLocks;
    }
    
    protected static void shutdownPool() throws ManifoldCFException {
        synchronized (ZooKeeperLockManager.ephemeralPoolLocker) {
            if (ZooKeeperLockManager.myEphemeralNodes != null) {
                try {
                    ZooKeeperLockManager.myEphemeralNodes.deleteAll();
                    ZooKeeperLockManager.myEphemeralNodes = null;
                }
                catch (InterruptedException e) {
                    throw new ManifoldCFException(e.getMessage(), e, 2);
                }
            }
        }
        synchronized (ZooKeeperLockManager.connectionPoolLock) {
            if (ZooKeeperLockManager.pool != null) {
                try {
                    ZooKeeperLockManager.pool.closeAll();
                    ZooKeeperLockManager.pool = null;
                }
                catch (InterruptedException e) {
                    throw new ManifoldCFException(e.getMessage(), e, 2);
                }
            }
        }
    }
    
    static {
        ZooKeeperLockManager.connectionPoolLock = new Integer(0);
        ZooKeeperLockManager.pool = null;
        ZooKeeperLockManager.zookeeperPoolLocker = new Integer(0);
        ZooKeeperLockManager.myZooKeeperLocks = null;
        ZooKeeperLockManager.ephemeralPoolLocker = new Integer(0);
        ZooKeeperLockManager.myEphemeralNodes = null;
    }
    
    protected static class ZooKeeperShutdown implements IShutdownHook
    {
        public ZooKeeperShutdown() {
        }
        
        @Override
        public void doCleanup(final IThreadContext threadContext) throws ManifoldCFException {
            ZooKeeperLockManager.shutdownPool();
        }
    }
}
