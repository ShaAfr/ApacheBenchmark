// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.List;

public class NullCheckClause implements ClauseDescription
{
    public static final String _rcsid = "@(#)$Id$";
    protected String columnName;
    protected boolean isNull;
    
    public NullCheckClause(final String columnName, final boolean isNull) {
        this.columnName = columnName;
        this.isNull = isNull;
    }
    
    @Override
    public String getColumnName() {
        return this.columnName;
    }
    
    @Override
    public String getOperation() {
        return this.isNull ? " IS NULL" : " IS NOT NULL";
    }
    
    @Override
    public List getValues() {
        return null;
    }
    
    @Override
    public String getJoinColumnName() {
        return null;
    }
}
