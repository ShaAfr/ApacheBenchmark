// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import org.apache.zookeeper.WatchedEvent;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.zookeeper.data.Stat;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.zookeeper.KeeperException;
import java.util.List;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooDefs;
import java.io.IOException;
import java.io.InterruptedIOException;
import org.apache.zookeeper.Watcher;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.zookeeper.ZooKeeper;

public class ZooKeeperConnection
{
    public static final String _rcsid = "@(#)$Id$";
    private static final String READ_PREFIX = "read-";
    private static final String NONEXWRITE_PREFIX = "nonexwrite-";
    private static final String WRITE_PREFIX = "write-";
    private static final String CHILD_PREFIX = "child-";
    protected final String connectString;
    protected final int sessionTimeout;
    protected ZooKeeper zookeeper;
    protected ZooKeeperWatcher zookeeperWatcher;
    protected String lockNode;
    protected String nodePath;
    protected byte[] nodeData;
    
    public ZooKeeperConnection(final String connectString, final int sessionTimeout) throws ManifoldCFException, InterruptedException {
        this.zookeeper = null;
        this.zookeeperWatcher = null;
        this.lockNode = null;
        this.nodePath = null;
        this.nodeData = null;
        this.connectString = connectString;
        this.sessionTimeout = sessionTimeout;
        this.zookeeperWatcher = new ZooKeeperWatcher();
        this.createSession();
    }
    
    protected void createSession() throws ManifoldCFException, InterruptedException {
        try {
            this.zookeeper = new ZooKeeper(this.connectString, this.sessionTimeout, (Watcher)this.zookeeperWatcher);
        }
        catch (InterruptedIOException e) {
            throw new InterruptedException(e.getMessage());
        }
        catch (IOException e2) {
            throw new ManifoldCFException("Zookeeper initialization error: " + e2.getMessage(), e2);
        }
    }
    
    public void createNode(final String nodePath, final byte[] nodeData) throws ManifoldCFException, InterruptedException {
        if (this.nodePath != null) {
            throw new IllegalStateException("Ephemeral node '" + this.nodePath + "' already open; can't open '" + nodePath + "'.");
        }
        while (true) {
            try {
                if (this.nodePath == null) {
                    this.zookeeper.create(nodePath, nodeData, (List)ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
                    this.nodePath = nodePath;
                    this.nodeData = nodeData;
                }
            }
            catch (KeeperException e) {
                this.handleEphemeralNodeKeeperException(e, false);
                continue;
            }
            break;
        }
    }
    
    public boolean checkNodeExists(final String nodePath) throws ManifoldCFException, InterruptedException {
        try {
            return this.zookeeper.exists(nodePath, false) != null;
        }
        catch (KeeperException e) {
            this.handleKeeperException(e, true);
            return this.zookeeper.exists(nodePath, false) != null;
        }
    }
    
    public byte[] getNodeData(final String nodePath) throws ManifoldCFException, InterruptedException {
        return this.readData(nodePath);
    }
    
    public void setNodeData(final byte[] data) throws ManifoldCFException, InterruptedException {
        if (this.nodePath == null) {
            throw new IllegalStateException("Can't set data for a node path we did not create: '" + this.nodePath + "'");
        }
        this.writeData(this.nodePath, data);
        this.nodeData = data;
    }
    
    public void deleteNode() throws ManifoldCFException, InterruptedException {
        if (this.nodePath == null) {
            throw new IllegalStateException("Can't delete ephemeral node that isn't registered: '" + this.nodePath + "'");
        }
        while (true) {
            try {
                if (this.nodePath != null) {
                    this.zookeeper.delete(this.nodePath, -1);
                    this.nodePath = null;
                    this.nodeData = null;
                }
            }
            catch (KeeperException e) {
                this.handleEphemeralNodeKeeperException(e, false);
                continue;
            }
            break;
        }
    }
    
    public void deleteNodeChildren(final String nodePath) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                final List<String> children = (List<String>)this.zookeeper.getChildren(nodePath, false);
                for (final String child : children) {
                    this.zookeeper.delete(nodePath + "/" + child, -1);
                }
            }
            catch (KeeperException.NoNodeException e2) {}
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    public List<String> getChildren(final String nodePath) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                final List<String> children = (List<String>)this.zookeeper.getChildren(nodePath, false);
                final List<String> rval = new ArrayList<String>();
                for (final String child : children) {
                    if (child.startsWith("child-")) {
                        rval.add(child.substring("child-".length()));
                    }
                }
                return rval;
            }
            catch (KeeperException.NoNodeException e2) {
                return new ArrayList<String>();
            }
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    public void createChild(final String nodePath, final String childName) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                this.createPersistentPath(nodePath + "/" + "child-" + childName, null);
            }
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    protected void createPersistentPath(final String path, final byte[] data) throws KeeperException, InterruptedException {
        while (true) {
            try {
                this.zookeeper.create(path, data, (List)ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
            }
            catch (KeeperException.NoNodeException e) {
                final int lastIndex = path.lastIndexOf("/");
                if (lastIndex == -1 || lastIndex == 0) {
                    throw e;
                }
                this.createPersistentPath(path.substring(0, lastIndex), null);
                continue;
            }
            catch (KeeperException.NodeExistsException e2) {
                if (data != null) {
                    try {
                        this.zookeeper.setData(path, data, -1);
                    }
                    catch (KeeperException.NoNodeException e3) {
                        continue;
                    }
                }
            }
            break;
        }
    }
    
    public void deleteChild(final String nodePath, final String childName) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                this.zookeeper.delete(nodePath + "/" + "child-" + childName, -1);
            }
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    public boolean obtainWriteLockNoWait(final String lockPath) throws ManifoldCFException, InterruptedException {
        if (this.lockNode != null) {
            throw new IllegalStateException("Already have a lock in place: '" + this.lockNode + "'; can't also write lock '" + lockPath + "'");
        }
        while (true) {
            try {
                if (this.lockNode == null) {
                    this.lockNode = this.createSequentialChild(lockPath, "write-");
                }
                final String lockSequenceNumber = this.lockNode.substring(lockPath.length() + 1 + "write-".length());
                final List<String> children = (List<String>)this.zookeeper.getChildren(lockPath, false);
                for (final String x : children) {
                    String otherLock;
                    if (x.startsWith("write-")) {
                        otherLock = x.substring("write-".length());
                    }
                    else if (x.startsWith("nonexwrite-")) {
                        otherLock = x.substring("nonexwrite-".length());
                    }
                    else {
                        if (!x.startsWith("read-")) {
                            continue;
                        }
                        otherLock = x.substring("read-".length());
                    }
                    if (otherLock.compareTo(lockSequenceNumber) < 0) {
                        this.releaseLock();
                        return false;
                    }
                }
                return true;
            }
            catch (InterruptedException e) {
                this.lockNode = null;
                throw e;
            }
            catch (KeeperException e2) {
                this.handleEphemeralNodeKeeperException(e2, true);
                continue;
            }
            break;
        }
    }
    
    public void obtainWriteLock(final String lockPath) throws ManifoldCFException, InterruptedException {
        if (this.lockNode != null) {
            throw new IllegalStateException("Already have a lock in place: '" + this.lockNode + "'; can't also write lock '" + lockPath + "'");
        }
        while (true) {
            try {
                if (this.lockNode == null) {
                    this.lockNode = this.createSequentialChild(lockPath, "write-");
                }
                final long lockSequenceNumber = new Long(this.lockNode.substring(lockPath.length() + 1 + "write-".length()));
                while (true) {
                    final List<String> children = (List<String>)this.zookeeper.getChildren(lockPath, false);
                    String previousLock = null;
                    boolean gotLock = true;
                    long highestPreviousLockIndex = -1L;
                    for (final String x : children) {
                        String otherLock;
                        if (x.startsWith("write-")) {
                            otherLock = x.substring("write-".length());
                        }
                        else if (x.startsWith("nonexwrite-")) {
                            otherLock = x.substring("nonexwrite-".length());
                        }
                        else {
                            if (!x.startsWith("read-")) {
                                continue;
                            }
                            otherLock = x.substring("read-".length());
                        }
                        final long otherLockSequenceNumber = new Long(otherLock);
                        if (otherLockSequenceNumber < lockSequenceNumber) {
                            gotLock = false;
                            if (otherLockSequenceNumber <= highestPreviousLockIndex) {
                                continue;
                            }
                            previousLock = x;
                            highestPreviousLockIndex = otherLockSequenceNumber;
                        }
                    }
                    if (gotLock) {
                        break;
                    }
                    if (previousLock == null) {
                        continue;
                    }
                    final ExistsWatcher w = new ExistsWatcher();
                    final Stat s = this.zookeeper.exists(lockPath + "/" + previousLock, (Watcher)w);
                    if (s == null) {
                        continue;
                    }
                    w.waitForEvent();
                }
            }
            catch (InterruptedException e) {
                this.lockNode = null;
                throw e;
            }
            catch (KeeperException e2) {
                this.handleEphemeralNodeKeeperException(e2, true);
                continue;
            }
            break;
        }
    }
    
    public boolean obtainNonExWriteLockNoWait(final String lockPath) throws ManifoldCFException, InterruptedException {
        if (this.lockNode != null) {
            throw new IllegalStateException("Already have a lock in place: '" + this.lockNode + "'; can't also non-ex write lock '" + lockPath + "'");
        }
        while (true) {
            break Label_0051;
            try {
                String lockSequenceNumber;
                List<String> children;
                do {
                    if (this.lockNode == null) {
                        this.lockNode = this.createSequentialChild(lockPath, "nonexwrite-");
                    }
                    lockSequenceNumber = this.lockNode.substring(lockPath.length() + 1 + "nonexwrite-".length());
                    children = null;
                    while (true) {
                        try {
                            children = (List<String>)this.zookeeper.getChildren(lockPath, false);
                        }
                        catch (KeeperException.NoNodeException e4) {}
                        catch (KeeperException e) {
                            this.handleKeeperException(e, true);
                            continue;
                        }
                        break;
                    }
                } while (children == null);
                for (final String x : children) {
                    String otherLock;
                    if (x.startsWith("write-")) {
                        otherLock = x.substring("write-".length());
                    }
                    else {
                        if (!x.startsWith("read-")) {
                            continue;
                        }
                        otherLock = x.substring("read-".length());
                    }
                    if (otherLock.compareTo(lockSequenceNumber) < 0) {
                        this.releaseLock();
                        return false;
                    }
                }
                return true;
            }
            catch (InterruptedException e2) {
                this.lockNode = null;
                throw e2;
            }
            catch (KeeperException e3) {
                this.handleEphemeralNodeKeeperException(e3, true);
                continue;
            }
            break;
        }
    }
    
    public void obtainNonExWriteLock(final String lockPath) throws ManifoldCFException, InterruptedException {
        if (this.lockNode != null) {
            throw new IllegalStateException("Already have a lock in place: '" + this.lockNode + "'; can't also non-ex write lock '" + lockPath + "'");
        }
        while (true) {
            break Label_0051;
            try {
            Block_11:
                while (true) {
                    if (this.lockNode == null) {
                        this.lockNode = this.createSequentialChild(lockPath, "nonexwrite-");
                    }
                    final long lockSequenceNumber = new Long(this.lockNode.substring(lockPath.length() + 1 + "nonexwrite-".length()));
                    while (true) {
                        List<String> children = null;
                        while (true) {
                            try {
                                children = (List<String>)this.zookeeper.getChildren(lockPath, false);
                            }
                            catch (KeeperException.NoNodeException e4) {}
                            catch (KeeperException e) {
                                this.handleKeeperException(e, true);
                                continue;
                            }
                            break;
                        }
                        if (children == null) {
                            break;
                        }
                        String previousLock = null;
                        boolean gotLock = true;
                        long highestPreviousLockIndex = -1L;
                        for (final String x : children) {
                            String otherLock;
                            if (x.startsWith("write-")) {
                                otherLock = x.substring("write-".length());
                            }
                            else {
                                if (!x.startsWith("read-")) {
                                    continue;
                                }
                                otherLock = x.substring("read-".length());
                            }
                            final long otherLockSequenceNumber = new Long(otherLock);
                            if (otherLockSequenceNumber < lockSequenceNumber) {
                                gotLock = false;
                                if (otherLockSequenceNumber <= highestPreviousLockIndex) {
                                    continue;
                                }
                                previousLock = x;
                                highestPreviousLockIndex = otherLockSequenceNumber;
                            }
                        }
                        if (gotLock) {
                            break Block_11;
                        }
                        if (previousLock == null) {
                            continue;
                        }
                        final ExistsWatcher w = new ExistsWatcher();
                        final Stat s = this.zookeeper.exists(lockPath + "/" + previousLock, (Watcher)w);
                        if (s == null) {
                            continue;
                        }
                        w.waitForEvent();
                    }
                }
            }
            catch (InterruptedException e2) {
                this.lockNode = null;
                throw e2;
            }
            catch (KeeperException e3) {
                this.handleEphemeralNodeKeeperException(e3, true);
                continue;
            }
            break;
        }
    }
    
    public boolean obtainReadLockNoWait(final String lockPath) throws ManifoldCFException, InterruptedException {
        if (this.lockNode != null) {
            throw new IllegalStateException("Already have a lock in place: '" + this.lockNode + "'; can't also read lock '" + lockPath + "'");
        }
        while (true) {
            break Label_0051;
            try {
                String lockSequenceNumber;
                List<String> children;
                do {
                    if (this.lockNode == null) {
                        this.lockNode = this.createSequentialChild(lockPath, "read-");
                    }
                    lockSequenceNumber = this.lockNode.substring(lockPath.length() + 1 + "read-".length());
                    children = null;
                    while (true) {
                        try {
                            children = (List<String>)this.zookeeper.getChildren(lockPath, false);
                        }
                        catch (KeeperException.NoNodeException e4) {}
                        catch (KeeperException e) {
                            this.handleKeeperException(e, true);
                            continue;
                        }
                        break;
                    }
                } while (children == null);
                for (final String x : children) {
                    String otherLock;
                    if (x.startsWith("write-")) {
                        otherLock = x.substring("write-".length());
                    }
                    else {
                        if (!x.startsWith("nonexwrite-")) {
                            continue;
                        }
                        otherLock = x.substring("nonexwrite-".length());
                    }
                    if (otherLock.compareTo(lockSequenceNumber) < 0) {
                        this.releaseLock();
                        return false;
                    }
                }
                return true;
            }
            catch (InterruptedException e2) {
                this.lockNode = null;
                throw e2;
            }
            catch (KeeperException e3) {
                this.handleEphemeralNodeKeeperException(e3, true);
                continue;
            }
            break;
        }
    }
    
    public void obtainReadLock(final String lockPath) throws ManifoldCFException, InterruptedException {
        if (this.lockNode != null) {
            throw new IllegalStateException("Already have a lock in place: '" + this.lockNode + "'; can't also read lock '" + lockPath + "'");
        }
        while (true) {
            break Label_0051;
            try {
            Block_11:
                while (true) {
                    if (this.lockNode == null) {
                        this.lockNode = this.createSequentialChild(lockPath, "read-");
                    }
                    final long lockSequenceNumber = new Long(this.lockNode.substring(lockPath.length() + 1 + "read-".length()));
                    while (true) {
                        List<String> children = null;
                        while (true) {
                            try {
                                children = (List<String>)this.zookeeper.getChildren(lockPath, false);
                            }
                            catch (KeeperException.NoNodeException e4) {}
                            catch (KeeperException e) {
                                this.handleKeeperException(e, true);
                                continue;
                            }
                            break;
                        }
                        if (children == null) {
                            break;
                        }
                        String previousLock = null;
                        boolean gotLock = true;
                        long highestPreviousLockIndex = -1L;
                        for (final String x : children) {
                            String otherLock;
                            if (x.startsWith("write-")) {
                                otherLock = x.substring("write-".length());
                            }
                            else {
                                if (!x.startsWith("nonexwrite-")) {
                                    continue;
                                }
                                otherLock = x.substring("nonexwrite-".length());
                            }
                            final long otherLockSequenceNumber = new Long(otherLock);
                            if (otherLockSequenceNumber < lockSequenceNumber) {
                                gotLock = false;
                                if (otherLockSequenceNumber <= highestPreviousLockIndex) {
                                    continue;
                                }
                                previousLock = x;
                                highestPreviousLockIndex = otherLockSequenceNumber;
                            }
                        }
                        if (gotLock) {
                            break Block_11;
                        }
                        if (previousLock == null) {
                            continue;
                        }
                        final ExistsWatcher w = new ExistsWatcher();
                        final Stat s = this.zookeeper.exists(lockPath + "/" + previousLock, (Watcher)w);
                        if (s == null) {
                            continue;
                        }
                        w.waitForEvent();
                    }
                }
            }
            catch (InterruptedException e2) {
                this.lockNode = null;
                throw e2;
            }
            catch (KeeperException e3) {
                this.handleEphemeralNodeKeeperException(e3, true);
                continue;
            }
            break;
        }
    }
    
    public void releaseLock() throws ManifoldCFException, InterruptedException {
        if (this.lockNode == null) {
            throw new IllegalStateException("Can't release lock we don't hold");
        }
        while (this.lockNode != null) {
            try {
                this.zookeeper.delete(this.lockNode, -1);
                this.lockNode = null;
            }
            catch (InterruptedException e) {
                this.lockNode = null;
                throw e;
            }
            catch (KeeperException e2) {
                this.handleEphemeralNodeKeeperException(e2, true);
                continue;
            }
        }
    }
    
    public byte[] readData(final String resourcePath) throws ManifoldCFException, InterruptedException {
        try {
            return this.zookeeper.getData(resourcePath, false, (Stat)null);
        }
        catch (KeeperException.NoNodeException e2) {
            return null;
        }
        catch (KeeperException e) {
            this.handleKeeperException(e, true);
            return this.zookeeper.getData(resourcePath, false, (Stat)null);
        }
    }
    
    public void writeData(final String resourcePath, final byte[] data) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                if (data == null) {
                    try {
                        this.zookeeper.delete(resourcePath, -1);
                    }
                    catch (KeeperException.NoNodeException ex) {}
                }
                else {
                    try {
                        this.zookeeper.setData(resourcePath, data, -1);
                    }
                    catch (KeeperException.NoNodeException e2) {
                        this.createPersistentPath(resourcePath, data);
                    }
                }
            }
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    public void setGlobalFlag(final String flagPath) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                this.createPersistentPath(flagPath, null);
            }
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    public void clearGlobalFlag(final String flagPath) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                try {
                    this.zookeeper.delete(flagPath, -1);
                }
                catch (KeeperException.NoNodeException ex) {}
            }
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    public boolean checkGlobalFlag(final String flagPath) throws ManifoldCFException, InterruptedException {
        while (true) {
            try {
                final Stat s = this.zookeeper.exists(flagPath, false);
                return s != null;
            }
            catch (KeeperException e) {
                this.handleKeeperException(e, true);
                continue;
            }
            break;
        }
    }
    
    public void close() throws InterruptedException {
        if (this.lockNode != null) {
            throw new IllegalStateException("Should not be closing handles that have open locks!  Locknode: '" + this.lockNode + "'");
        }
        this.zookeeper.close();
        this.zookeeper = null;
        this.zookeeperWatcher = null;
    }
    
    protected void handleEphemeralNodeKeeperException(final KeeperException e, final boolean recreate) throws ManifoldCFException, InterruptedException {
        if (!(e instanceof KeeperException.ConnectionLossException)) {
            if (!(e instanceof KeeperException.SessionExpiredException)) {
                throw new ManifoldCFException(e.getMessage(), (Throwable)e);
            }
        }
        while (true) {
            try {
                this.lockNode = null;
                if (!recreate) {
                    this.nodePath = null;
                    this.nodeData = null;
                }
                this.zookeeper.close();
                this.createSession();
                if (this.nodePath != null) {
                    this.zookeeper.create(this.nodePath, this.nodeData, (List)ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
                }
                return;
            }
            catch (KeeperException e2) {
                if (!(e2 instanceof KeeperException.ConnectionLossException) && !(e2 instanceof KeeperException.SessionExpiredException)) {
                    throw new ManifoldCFException(e2.getMessage(), (Throwable)e2);
                }
                continue;
            }
            break;
        }
        throw new ManifoldCFException(e.getMessage(), (Throwable)e);
    }
    
    protected void handleKeeperException(final KeeperException e, final boolean recreate) throws ManifoldCFException, InterruptedException {
        if (!(e instanceof KeeperException.ConnectionLossException)) {
            if (e instanceof KeeperException.SessionExpiredException) {
                while (true) {
                    try {
                        this.lockNode = null;
                        if (!recreate) {
                            this.nodePath = null;
                            this.nodeData = null;
                        }
                        this.zookeeper.close();
                        this.createSession();
                        if (this.nodePath != null) {
                            this.zookeeper.create(this.nodePath, this.nodeData, (List)ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
                        }
                        return;
                    }
                    catch (KeeperException e2) {
                        if (!(e2 instanceof KeeperException.ConnectionLossException) && !(e2 instanceof KeeperException.SessionExpiredException)) {
                            throw new ManifoldCFException(e2.getMessage(), (Throwable)e2);
                        }
                        continue;
                    }
                    break;
                }
            }
            throw new ManifoldCFException(e.getMessage(), (Throwable)e);
        }
        ManifoldCF.sleep(100L);
    }
    
    public static String zooKeeperSafeName(final String input) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); ++i) {
            final char x = input.charAt(i);
            if (x == '/') {
                sb.append('\\').append('0');
            }
            else if (x == '\u007f') {
                sb.append('\\').append('1');
            }
            else if (x == '\\') {
                sb.append('\\').append('\\');
            }
            else if (x >= '\0' && x < ' ') {
                sb.append('\\').append(x + '@');
            }
            else if (x >= '\u0080' && x < ' ') {
                sb.append('\\').append(x + '`' - 128);
            }
            else {
                sb.append(x);
            }
        }
        return sb.toString();
    }
    
    public static String zooKeeperDecodeSafeName(final String input) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); ++i) {
            char x = input.charAt(i);
            if (x == '\\') {
                if (++i == input.length()) {
                    throw new RuntimeException("Supposedly safe zookeeper name is not properly encoded!!");
                }
                x = input.charAt(i);
                if (x == '0') {
                    sb.append('/');
                }
                else if (x == '1') {
                    sb.append('\u007f');
                }
                else if (x == '\\') {
                    sb.append('\\');
                }
                else if (x >= '@' && x < '`') {
                    sb.append(x - '@');
                }
                else {
                    if (x < '`' || x >= '\u0080') {
                        throw new RuntimeException("Supposedly safe zookeeper name is not properly encoded!!");
                    }
                    sb.append(x - '`' + 128);
                }
            }
            else {
                sb.append(x);
            }
        }
        return sb.toString();
    }
    
    protected String createSequentialChild(final String mainNode, final String childPrefix) throws KeeperException, InterruptedException {
        try {
            return this.zookeeper.create(mainNode + "/" + childPrefix, new byte[0], (List)ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);
        }
        catch (KeeperException.NoNodeException e) {
            try {
                this.zookeeper.create(mainNode, new byte[0], (List)ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
            }
            catch (KeeperException.NodeExistsException ex) {}
            return this.zookeeper.create(mainNode + "/" + childPrefix, new byte[0], (List)ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);
        }
    }
    
    protected static class ZooKeeperWatcher implements Watcher
    {
        public ZooKeeperWatcher() {
        }
        
        public void process(final WatchedEvent event) {
        }
    }
    
    protected static class ExistsWatcher implements Watcher
    {
        protected boolean eventTriggered;
        
        public ExistsWatcher() {
            this.eventTriggered = false;
        }
        
        public void process(final WatchedEvent event) {
            synchronized (this) {
                this.eventTriggered = true;
                this.notifyAll();
            }
        }
        
        public void waitForEvent() throws InterruptedException {
            synchronized (this) {
                if (this.eventTriggered) {
                    return;
                }
                this.wait();
            }
        }
    }
}
