// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IServiceCleanup
{
    public static final String _rcsid = "@(#)$Id$";
    
    void cleanUpService(final String p0) throws ManifoldCFException;
    
    void cleanUpAllServices() throws ManifoldCFException;
    
    void clusterInit() throws ManifoldCFException;
}
