// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import org.apache.manifoldcf.core.interfaces.ClauseDescription;
import java.util.Collection;
import org.apache.manifoldcf.core.interfaces.StringSetBuffer;
import org.apache.manifoldcf.core.interfaces.IResultRow;
import java.util.HashMap;
import java.sql.SQLException;
import org.apache.manifoldcf.core.system.Logging;
import org.apache.manifoldcf.core.interfaces.IResultSet;
import org.apache.manifoldcf.core.interfaces.IDFactory;
import org.apache.manifoldcf.core.interfaces.IndexDescription;
import org.apache.manifoldcf.core.interfaces.ColumnDescription;
import java.util.Iterator;
import java.util.ArrayList;
import org.apache.manifoldcf.core.interfaces.StringSet;
import java.sql.Statement;
import java.sql.DriverManager;
import org.apache.manifoldcf.core.interfaces.ILimitChecker;
import org.apache.manifoldcf.core.interfaces.ResultSpecification;
import java.util.List;
import java.util.Locale;
import java.sql.Connection;
import java.io.File;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import org.apache.manifoldcf.core.interfaces.CacheKeyFactory;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import java.util.Map;
import org.apache.manifoldcf.core.interfaces.IDBInterface;

public class DBInterfaceHSQLDB extends Database implements IDBInterface
{
    public static final String _rcsid = "@(#)$Id$";
    private static final String _localUrl = "jdbc:hsqldb:file:";
    private static final String _remoteUrl = "jdbc:hsqldb:";
    private static final String _driver = "org.hsqldb.jdbcDriver";
    private static Map<String, String> legalProtocolValues;
    public static final String databasePathProperty = "org.apache.manifoldcf.hsqldbdatabasepath";
    public static final String databaseProtocolProperty = "org.apache.manifoldcf.hsqldbdatabaseprotocol";
    public static final String databaseServerProperty = "org.apache.manifoldcf.hsqldbdatabaseserver";
    public static final String databasePortProperty = "org.apache.manifoldcf.hsqldbdatabaseport";
    public static final String databaseInstanceProperty = "org.apache.manifoldcf.hsqldbdatabaseinstance";
    protected String cacheKey;
    protected int serializableDepth;
    protected boolean isRemote;
    protected String schemaNameForQueries;
    protected int depthCount;
    protected boolean inTransaction;
    protected int desiredTransactionType;
    
    public DBInterfaceHSQLDB(final IThreadContext tc, final String databaseName, final String userName, final String password) throws ManifoldCFException {
        super(tc, getJDBCString(tc, databaseName), "org.hsqldb.jdbcDriver", getDatabaseString(tc, databaseName), userName, password);
        this.serializableDepth = 0;
        this.depthCount = 0;
        this.inTransaction = false;
        this.desiredTransactionType = 2;
        this.cacheKey = CacheKeyFactory.makeDatabaseKey(this.databaseName);
        this.isRemote = (LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.hsqldbdatabaseprotocol") != null);
        this.userName = userName;
        this.password = password;
        if (this.isRemote) {
            this.schemaNameForQueries = databaseName;
        }
        else {
            this.schemaNameForQueries = "PUBLIC";
        }
    }
    
    protected static String getJDBCString(final IThreadContext tc, final String databaseName) throws ManifoldCFException {
        final String protocol = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.hsqldbdatabaseprotocol");
        if (protocol == null) {
            return "jdbc:hsqldb:file:" + getFullDatabasePath(databaseName);
        }
        if (DBInterfaceHSQLDB.legalProtocolValues.get(protocol) == null) {
            throw new ManifoldCFException("The value of the 'org.apache.manifoldcf.hsqldbdatabaseprotocol' property was illegal; try hsql, http, or https");
        }
        String server = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.hsqldbdatabaseserver");
        if (server == null) {
            throw new ManifoldCFException("HSQLDB remote mode requires 'org.apache.manifoldcf.hsqldbdatabaseserver' property, containing a server name or IP address");
        }
        final String port = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.hsqldbdatabaseport");
        if (port != null && port.length() > 0) {
            server = server + ":" + port;
        }
        final String instanceName = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.hsqldbdatabaseinstance");
        if (instanceName != null && instanceName.length() > 0) {
            server = server + "/" + instanceName;
        }
        return "jdbc:hsqldb:" + protocol + "://" + server;
    }
    
    protected static String getDatabaseString(final IThreadContext tc, final String databaseName) throws ManifoldCFException {
        final String protocol = LockManagerFactory.getProperty(tc, "org.apache.manifoldcf.hsqldbdatabaseprotocol");
        if (protocol == null) {
            return getFullDatabasePath(databaseName);
        }
        return databaseName;
    }
    
    protected static String getFullDatabasePath(final String databaseName) throws ManifoldCFException {
        final File path = ManifoldCF.getFileProperty("org.apache.manifoldcf.hsqldbdatabasepath");
        if (path == null) {
            throw new ManifoldCFException("HSQLDB database requires 'org.apache.manifoldcf.hsqldbdatabasepath' property, containing a relative path");
        }
        String pathString = path.toString().replace("\\\\", "/");
        if (!pathString.endsWith("/")) {
            pathString += "/";
        }
        return pathString + databaseName;
    }
    
    @Override
    protected void initializeConnection(final Connection connection) throws ManifoldCFException {
        super.initializeConnection(connection);
        this.executeViaThread(connection, "SET SCHEMA " + this.schemaNameForQueries.toUpperCase(Locale.ROOT), null, false, -1, null, null);
    }
    
    @Override
    public void openDatabase() throws ManifoldCFException {
    }
    
    @Override
    public void closeDatabase() throws ManifoldCFException {
        if (!this.isRemote) {
            try {
                Class.forName("org.hsqldb.jdbcDriver").newInstance();
            }
            catch (Exception e) {
                throw new ManifoldCFException(e.getMessage(), e);
            }
            try {
                final Connection c = DriverManager.getConnection("jdbc:hsqldb:file:" + this.databaseName, this.userName, this.password);
                final Statement s = c.createStatement();
                s.execute("SHUTDOWN");
                c.close();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public String getDatabaseCacheKey() {
        return this.cacheKey;
    }
    
    @Override
    public void performInsert(final String tableName, final Map<String, Object> parameterMap, final StringSet invalidateKeys) throws ManifoldCFException {
        final List paramArray = new ArrayList();
        final StringBuilder bf = new StringBuilder();
        bf.append("INSERT INTO ");
        bf.append(tableName);
        bf.append(" (");
        final StringBuilder values = new StringBuilder(" VALUES (");
        final Iterator<Map.Entry<String, Object>> it = parameterMap.entrySet().iterator();
        boolean first = true;
        while (it.hasNext()) {
            final Map.Entry<String, Object> e = it.next();
            final String key = e.getKey();
            final Object o = e.getValue();
            if (o != null) {
                paramArray.add(o);
                if (!first) {
                    bf.append(',');
                    values.append(',');
                }
                bf.append(key);
                values.append('?');
                first = false;
            }
        }
        bf.append(')');
        values.append(')');
        bf.append((CharSequence)values);
        this.performModification(bf.toString(), paramArray, invalidateKeys);
    }
    
    @Override
    public void performUpdate(final String tableName, final Map<String, Object> parameterMap, final String whereClause, final List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        final List paramArray = new ArrayList();
        final StringBuilder bf = new StringBuilder();
        bf.append("UPDATE ");
        bf.append(tableName);
        bf.append(" SET ");
        final Iterator<Map.Entry<String, Object>> it = parameterMap.entrySet().iterator();
        boolean first = true;
        while (it.hasNext()) {
            final Map.Entry<String, Object> e = it.next();
            final String key = e.getKey();
            final Object o = e.getValue();
            if (!first) {
                bf.append(',');
            }
            bf.append(key);
            bf.append('=');
            if (o == null) {
                bf.append("NULL");
            }
            else {
                bf.append('?');
                paramArray.add(o);
            }
            first = false;
        }
        if (whereClause != null) {
            bf.append(' ');
            bf.append(whereClause);
            if (whereParameters != null) {
                for (int i = 0; i < whereParameters.size(); ++i) {
                    final Object value = whereParameters.get(i);
                    paramArray.add(value);
                }
            }
        }
        this.performModification(bf.toString(), paramArray, invalidateKeys);
    }
    
    @Override
    public void performDelete(final String tableName, final String whereClause, List whereParameters, final StringSet invalidateKeys) throws ManifoldCFException {
        final StringBuilder bf = new StringBuilder();
        bf.append("DELETE FROM ");
        bf.append(tableName);
        if (whereClause != null) {
            bf.append(' ');
            bf.append(whereClause);
        }
        else {
            whereParameters = null;
        }
        this.performModification(bf.toString(), whereParameters, invalidateKeys);
    }
    
    @Override
    public void performCreate(final String tableName, final Map<String, ColumnDescription> columnMap, final StringSet invalidateKeys) throws ManifoldCFException {
        final StringBuilder queryBuffer = new StringBuilder("CREATE CACHED TABLE ");
        queryBuffer.append(tableName);
        queryBuffer.append('(');
        final Iterator<String> iter = columnMap.keySet().iterator();
        boolean first = true;
        while (iter.hasNext()) {
            final String columnName = iter.next();
            final ColumnDescription cd = columnMap.get(columnName);
            if (!first) {
                queryBuffer.append(',');
            }
            else {
                first = false;
            }
            appendDescription(queryBuffer, columnName, cd, false);
        }
        queryBuffer.append(')');
        this.performModification(queryBuffer.toString(), null, invalidateKeys);
    }
    
    protected static void appendDescription(final StringBuilder queryBuffer, final String columnName, final ColumnDescription cd, final boolean forceNull) {
        queryBuffer.append(columnName);
        queryBuffer.append(' ');
        queryBuffer.append(mapType(cd.getTypeString()));
        if (forceNull || cd.getIsNull()) {
            queryBuffer.append(" NULL");
        }
        else {
            queryBuffer.append(" NOT NULL");
        }
        if (cd.getIsPrimaryKey()) {
            queryBuffer.append(" PRIMARY KEY");
        }
        if (cd.getReferenceTable() != null) {
            queryBuffer.append(" REFERENCES ");
            queryBuffer.append(cd.getReferenceTable());
            queryBuffer.append('(');
            queryBuffer.append(cd.getReferenceColumn());
            queryBuffer.append(") ON DELETE");
            if (cd.getReferenceCascade()) {
                queryBuffer.append(" CASCADE");
            }
            else {
                queryBuffer.append(" RESTRICT");
            }
        }
    }
    
    @Override
    public void performAlter(final String tableName, final Map<String, ColumnDescription> columnMap, final Map<String, ColumnDescription> columnModifyMap, final List<String> columnDeleteList, final StringSet invalidateKeys) throws ManifoldCFException {
        this.beginTransaction(0);
        try {
            if (columnDeleteList != null) {
                int i = 0;
                while (i < columnDeleteList.size()) {
                    final String columnName = columnDeleteList.get(i++);
                    this.performModification("ALTER TABLE " + tableName + " DROP " + columnName, null, invalidateKeys);
                }
            }
            if (columnModifyMap != null) {
                for (final String columnName2 : columnModifyMap.keySet()) {
                    final ColumnDescription cd = columnModifyMap.get(columnName2);
                    final StringBuilder sb = new StringBuilder();
                    appendDescription(sb, columnName2, cd, false);
                    this.performModification("ALTER TABLE " + tableName + " ALTER COLUMN " + sb.toString(), null, invalidateKeys);
                }
            }
            if (columnMap != null) {
                for (final String columnName : columnMap.keySet()) {
                    final ColumnDescription cd2 = columnMap.get(columnName);
                    final StringBuilder sb2 = new StringBuilder();
                    appendDescription(sb2, columnName, cd2, false);
                    this.performModification("ALTER TABLE " + tableName + " ADD " + sb2.toString(), null, invalidateKeys);
                }
            }
        }
        catch (ManifoldCFException e) {
            this.signalRollback();
            throw e;
        }
        catch (Error e2) {
            this.signalRollback();
            throw e2;
        }
        finally {
            this.endTransaction();
        }
    }
    
    protected static String mapType(final String inputType) {
        if (inputType.equalsIgnoreCase("longtext")) {
            return "longvarchar";
        }
        return inputType;
    }
    
    @Override
    public void addTableIndex(final String tableName, final boolean unique, final List<String> columnList) throws ManifoldCFException {
        final String[] columns = new String[columnList.size()];
        for (int i = 0; i < columns.length; ++i) {
            columns[i] = columnList.get(i);
        }
        this.performAddIndex(null, tableName, new IndexDescription(unique, columns));
    }
    
    @Override
    public void performAddIndex(String indexName, final String tableName, final IndexDescription description) throws ManifoldCFException {
        final String[] columnNames = description.getColumnNames();
        if (columnNames.length == 0) {
            return;
        }
        if (indexName == null) {
            indexName = "I" + IDFactory.make(this.context);
        }
        final StringBuilder queryBuffer = new StringBuilder("CREATE ");
        if (description.getIsUnique()) {
            queryBuffer.append("UNIQUE ");
        }
        queryBuffer.append("INDEX ");
        queryBuffer.append(indexName);
        queryBuffer.append(" ON ");
        queryBuffer.append(tableName);
        queryBuffer.append(" (");
        for (int i = 0; i < columnNames.length; ++i) {
            final String colName = columnNames[i];
            if (i > 0) {
                queryBuffer.append(',');
            }
            queryBuffer.append(colName);
        }
        queryBuffer.append(')');
        this.performModification(queryBuffer.toString(), null, null);
    }
    
    @Override
    public void performRemoveIndex(final String indexName, final String tableName) throws ManifoldCFException {
        this.performModification("DROP INDEX " + indexName, null, null);
    }
    
    @Override
    public void analyzeTable(final String tableName) throws ManifoldCFException {
    }
    
    @Override
    public void reindexTable(final String tableName) throws ManifoldCFException {
    }
    
    @Override
    public void performDrop(final String tableName, final StringSet invalidateKeys) throws ManifoldCFException {
        this.performModification("DROP TABLE " + tableName, null, invalidateKeys);
    }
    
    @Override
    public void createUserAndDatabase(final String adminUserName, final String adminPassword, final StringSet invalidateKeys) throws ManifoldCFException {
        if (this.isRemote) {
            final Database masterDatabase = new DBInterfaceHSQLDB(this.context, "PUBLIC", adminUserName, adminPassword);
            final ArrayList params = new ArrayList();
            params.add(this.userName);
            final IResultSet userResult = masterDatabase.executeQuery("SELECT * FROM INFORMATION_SCHEMA.SYSTEM_USERS WHERE USER_NAME=?", params, null, null, null, true, -1, null, null);
            if (userResult.getRowCount() == 0) {
                masterDatabase.executeQuery("CREATE USER " + quoteString(this.userName) + " PASSWORD " + quoteString(this.password), null, null, invalidateKeys, null, false, 0, null, null);
            }
            params.clear();
            params.add(this.databaseName.toUpperCase(Locale.ROOT));
            final IResultSet schemaResult = masterDatabase.executeQuery("SELECT * FROM INFORMATION_SCHEMA.SYSTEM_SCHEMAS WHERE TABLE_SCHEM=?", params, null, null, null, true, -1, null, null);
            if (schemaResult.getRowCount() == 0) {
                masterDatabase.executeQuery("CREATE SCHEMA " + this.databaseName.toUpperCase(Locale.ROOT) + " AUTHORIZATION " + quoteString(this.userName), null, null, invalidateKeys, null, false, 0, null, null);
            }
        }
        else {
            try {
                Class.forName("org.hsqldb.jdbcDriver").newInstance();
                DriverManager.getConnection("jdbc:hsqldb:file:" + this.databaseName, this.userName, this.password).close();
            }
            catch (Exception e) {
                throw new ManifoldCFException(e.getMessage(), e, 3);
            }
            this.performModification("SET DATABASE TRANSACTION CONTROL MVCC", null, null);
            this.performModification("SET FILES SCALE 512", null, null);
        }
    }
    
    private static String quoteString(final String password) {
        final StringBuilder sb = new StringBuilder();
        sb.append("\"");
        for (int i = 0; i < password.length(); ++i) {
            final char x = password.charAt(i);
            if (x == '\"') {
                sb.append("\"");
            }
            sb.append(x);
        }
        sb.append("\"");
        return sb.toString();
    }
    
    @Override
    public void dropUserAndDatabase(final String adminUserName, final String adminPassword, final StringSet invalidateKeys) throws ManifoldCFException {
        if (this.isRemote) {
            final Database masterDatabase = new DBInterfaceHSQLDB(this.context, "PUBLIC", adminUserName, adminPassword);
            try {
                masterDatabase.executeQuery("DROP SCHEMA " + this.databaseName, null, null, invalidateKeys, null, false, 0, null, null);
                masterDatabase.executeQuery("DROP USER " + quoteString(this.userName), null, null, invalidateKeys, null, false, 0, null, null);
            }
            catch (ManifoldCFException e) {
                throw this.reinterpretException(e);
            }
        }
        else {
            final File f = new File(this.databaseName + ".properties");
            if (f.exists()) {
                ConnectionFactory.releaseAll();
                this.closeDatabase();
                singleDelete(f);
                singleDelete(new File(this.databaseName + ".data"));
                singleDelete(new File(this.databaseName + ".lck"));
                singleDelete(new File(this.databaseName + ".log"));
                singleDelete(new File(this.databaseName + ".script"));
                recursiveDelete(new File(this.databaseName + ".tmp"));
            }
        }
    }
    
    protected static void recursiveDelete(final File f) {
        if (f.exists()) {
            final File[] files = f.listFiles();
            if (files != null) {
                int i = 0;
                while (i < files.length) {
                    final File newf = files[i++];
                    if (newf.isDirectory()) {
                        recursiveDelete(newf);
                    }
                    else {
                        singleDelete(newf);
                    }
                }
            }
            if (!f.delete()) {
                System.out.println("Failed to delete directory " + f.toString());
            }
        }
    }
    
    protected static void singleDelete(final File f) {
        if (f.exists() && !f.delete()) {
            System.out.println("Failed to delete file " + f.toString());
        }
    }
    
    protected ManifoldCFException reinterpretException(final ManifoldCFException theException) {
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Reinterpreting exception '" + theException.getMessage() + "'.  The exception type is " + Integer.toString(theException.getErrorCode())));
        }
        if (theException.getErrorCode() != 4) {
            return theException;
        }
        final Throwable e = theException.getCause();
        if (!(e instanceof SQLException)) {
            return theException;
        }
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Exception " + theException.getMessage() + " is possibly a transaction abort signal"));
        }
        final SQLException sqlException = (SQLException)e;
        final String message = sqlException.getMessage();
        final String sqlState = sqlException.getSQLState();
        if (sqlState != null && sqlState.equals("40001")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("40P01")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (sqlState != null && sqlState.equals("23505")) {
            return new ManifoldCFException(message, e, 6);
        }
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Exception " + theException.getMessage() + " is NOT a transaction abort signal"));
        }
        return theException;
    }
    
    @Override
    public void performModification(final String query, final List params, final StringSet invalidateKeys) throws ManifoldCFException {
        try {
            this.executeQuery(query, params, null, invalidateKeys, null, false, 0, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public Map<String, ColumnDescription> getTableSchema(final String tableName, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        StringBuilder query = new StringBuilder();
        final List list = new ArrayList();
        list.add(this.schemaNameForQueries.toUpperCase(Locale.ROOT));
        list.add(tableName.toUpperCase(Locale.ROOT));
        query.append("SELECT column_name, is_nullable, data_type, character_maximum_length ").append("FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema=? AND table_name=?");
        final IResultSet set = this.performQuery(query.toString(), list, cacheKeys, queryClass);
        if (set.getRowCount() == 0) {
            return null;
        }
        query = new StringBuilder();
        query.append("SELECT column_name ").append("FROM INFORMATION_SCHEMA.SYSTEM_PRIMARYKEYS WHERE table_schem=? AND table_name=?");
        final IResultSet primarySet = this.performQuery(query.toString(), list, cacheKeys, queryClass);
        String primaryKey = null;
        if (primarySet.getRowCount() != 0) {
            primaryKey = ((String)primarySet.getRow(0).getValue("column_name")).toLowerCase(Locale.ROOT);
        }
        if (primaryKey == null) {
            primaryKey = "";
        }
        final Map<String, ColumnDescription> rval = new HashMap<String, ColumnDescription>();
        int i = 0;
        while (i < set.getRowCount()) {
            final IResultRow row = set.getRow(i++);
            final String fieldName = ((String)row.getValue("column_name")).toLowerCase(Locale.ROOT);
            final String type = (String)row.getValue("data_type");
            final Long width = (Long)row.getValue("character_maximum_length");
            final String isNullable = (String)row.getValue("is_nullable");
            final boolean isPrimaryKey = primaryKey.equals(fieldName);
            final boolean isNull = isNullable.equals("YES");
            if (type.equals("CHARACTER VARYING")) {
                final String dataType = "VARCHAR(" + width.toString() + ")";
            }
            else if (type.equals("CLOB")) {
                final String dataType = "LONGVARCHAR";
            }
            else {
                final String dataType = type;
            }
            rval.put(fieldName, new ColumnDescription(type, isPrimaryKey, isNull, null, null, false));
        }
        return rval;
    }
    
    @Override
    public Map<String, IndexDescription> getTableIndexes(final String tableName, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        final Map<String, IndexDescription> rval = new HashMap<String, IndexDescription>();
        final String query = "SELECT index_name,column_name,non_unique,ordinal_position FROM INFORMATION_SCHEMA.SYSTEM_INDEXINFO WHERE table_schem=? AND TABLE_NAME=? ORDER BY index_name,ordinal_position ASC";
        final List list = new ArrayList();
        list.add(this.schemaNameForQueries.toUpperCase(Locale.ROOT));
        list.add(tableName.toUpperCase(Locale.ROOT));
        final IResultSet result = this.performQuery(query, list, cacheKeys, queryClass);
        String lastIndexName = null;
        List<String> indexColumns = null;
        boolean isUnique = false;
        int i = 0;
        while (i < result.getRowCount()) {
            final IResultRow row = result.getRow(i++);
            final String indexName = ((String)row.getValue("index_name")).toLowerCase(Locale.ROOT);
            final String columnName = ((String)row.getValue("column_name")).toLowerCase(Locale.ROOT);
            final String nonUnique = row.getValue("non_unique").toString();
            if (lastIndexName != null && !lastIndexName.equals(indexName)) {
                this.addIndex(rval, lastIndexName, isUnique, indexColumns);
                lastIndexName = null;
                indexColumns = null;
                isUnique = false;
            }
            if (lastIndexName == null) {
                lastIndexName = indexName;
                indexColumns = new ArrayList<String>();
                isUnique = false;
            }
            indexColumns.add(columnName);
            isUnique = nonUnique.equals("false");
        }
        if (lastIndexName != null) {
            this.addIndex(rval, lastIndexName, isUnique, indexColumns);
        }
        return rval;
    }
    
    protected void addIndex(final Map rval, final String indexName, final boolean isUnique, final List<String> indexColumns) {
        if (indexName.indexOf("sys_idx") != -1) {
            return;
        }
        final String[] columnNames = new String[indexColumns.size()];
        for (int i = 0; i < columnNames.length; ++i) {
            columnNames[i] = indexColumns.get(i);
        }
        rval.put(indexName, new IndexDescription(isUnique, columnNames));
    }
    
    @Override
    public StringSet getAllTables(final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        final ArrayList list = new ArrayList();
        list.add(this.schemaNameForQueries.toUpperCase(Locale.ROOT));
        final IResultSet set = this.performQuery("SELECT table_name FROM INFORMATION_SCHEMA.TABLES WHERE table_schema=?", list, cacheKeys, queryClass);
        final StringSetBuffer ssb = new StringSetBuffer();
        final String columnName = "table_name";
        int i = 0;
        while (i < set.getRowCount()) {
            final IResultRow row = set.getRow(i++);
            final String value = row.getValue(columnName).toString();
            ssb.add(value);
        }
        return new StringSet(ssb);
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, -1, null, null);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass, final int maxResults, final ILimitChecker returnLimit) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, maxResults, null, returnLimit);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public IResultSet performQuery(final String query, final List params, final StringSet cacheKeys, final String queryClass, final int maxResults, final ResultSpecification resultSpec, final ILimitChecker returnLimit) throws ManifoldCFException {
        try {
            return this.executeQuery(query, params, cacheKeys, null, queryClass, true, maxResults, resultSpec, returnLimit);
        }
        catch (ManifoldCFException e) {
            throw this.reinterpretException(e);
        }
    }
    
    @Override
    public String constructIndexOrderByClause(final String[] fieldNames, final boolean direction) {
        if (fieldNames.length == 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder("ORDER BY ");
        for (int i = 0; i < fieldNames.length; ++i) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(fieldNames[i]);
            if (direction) {
                sb.append(" ASC");
            }
            else {
                sb.append(" DESC");
            }
        }
        return sb.toString();
    }
    
    @Override
    public String constructDoubleCastClause(final String value) {
        return "CAST(" + value + " AS DOUBLE PRECISION)";
    }
    
    @Override
    public String constructCountClause(final String column) {
        return "CAST(COUNT(" + column + ") AS bigint)";
    }
    
    @Override
    public String constructRegexpClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        return "REGEXP_MATCHES(CAST(" + column + " AS VARCHAR(4096))," + regularExpression + ")";
    }
    
    @Override
    public String constructSubstringClause(final String column, final String regularExpression, final boolean caseInsensitive) {
        return "REGEXP_SUBSTRING(CAST(" + column + " AS VARCHAR(4096))," + regularExpression + ")";
    }
    
    @Override
    public String constructOffsetLimitClause(final int offset, final int limit, final boolean afterOrderBy) {
        final StringBuilder sb = new StringBuilder();
        if (offset != 0) {
            sb.append("OFFSET ").append(Integer.toString(offset));
        }
        if (limit != -1) {
            if (offset != 0) {
                sb.append(" ");
            }
            sb.append("LIMIT ").append(Integer.toString(limit));
            if (afterOrderBy) {
                sb.append(" USING INDEX");
            }
        }
        return sb.toString();
    }
    
    @Override
    public String constructDistinctOnClause(final List outputParameters, final String baseQuery, final List baseParameters, final String[] distinctFields, final String[] orderFields, final boolean[] orderFieldsAscending, final Map<String, String> otherFields) {
        if (baseParameters != null) {
            outputParameters.addAll(baseParameters);
        }
        final StringBuilder sb = new StringBuilder("WITH txxx1 (");
        boolean needComma = false;
        for (final String fieldName : otherFields.keySet()) {
            if (needComma) {
                sb.append(",");
            }
            sb.append(fieldName);
            needComma = true;
        }
        sb.append(") AS (SELECT ");
        needComma = false;
        for (final String fieldName : otherFields.keySet()) {
            final String columnValue = otherFields.get(fieldName);
            if (needComma) {
                sb.append(",");
            }
            needComma = true;
            sb.append("txxx2.").append(columnValue).append(" AS ").append(fieldName);
        }
        sb.append(" FROM (").append(baseQuery).append(") txxx2)");
        sb.append(" SELECT * FROM (SELECT DISTINCT ");
        final Map<String, String> distinctMap = new HashMap<String, String>();
        for (int i = 0; i < distinctFields.length; ++i) {
            final String distinctField = distinctFields[i];
            if (i > 0) {
                sb.append(",");
            }
            sb.append(distinctField);
            distinctMap.put(distinctField, distinctField);
        }
        sb.append(" FROM txxx1) AS txxx3, LATERAL (SELECT ");
        final Iterator<String> iter = otherFields.keySet().iterator();
        needComma = false;
        while (iter.hasNext()) {
            final String fieldName2 = iter.next();
            if (distinctMap.get(fieldName2) == null) {
                if (needComma) {
                    sb.append(",");
                }
                needComma = true;
                sb.append(fieldName2);
            }
        }
        sb.append(" FROM txxx1 WHERE ");
        for (int i = 0; i < distinctFields.length; ++i) {
            final String distinctField = distinctFields[i];
            if (i > 0) {
                sb.append(" AND ");
            }
            sb.append(distinctField).append("=txxx3.").append(distinctField);
        }
        if (distinctFields.length > 0 || orderFields.length > 0) {
            sb.append(" ORDER BY ");
            int k = 0;
            for (int i = 0; i < distinctFields.length; ++i) {
                if (k > 0) {
                    sb.append(",");
                }
                sb.append(distinctFields[i]).append(" ASC");
                ++k;
            }
            for (int i = 0; i < orderFields.length; ++i, ++k) {
                if (k > 0) {
                    sb.append(",");
                }
                sb.append(orderFields[i]).append(" ");
                if (orderFieldsAscending[i]) {
                    sb.append("ASC");
                }
                else {
                    sb.append("DESC");
                }
            }
        }
        sb.append(" LIMIT 1) AS txxx4");
        return sb.toString();
    }
    
    @Override
    public int findConjunctionClauseMax(final ClauseDescription[] otherClauseDescriptions) {
        if (otherClauseDescriptions.length == 0) {
            return super.findConjunctionClauseMax(otherClauseDescriptions);
        }
        int number = 1;
        for (int i = 0; i < otherClauseDescriptions.length; ++i) {
            final ClauseDescription otherClause = otherClauseDescriptions[i];
            final List values = otherClause.getValues();
            if (values != null) {
                number *= values.size();
            }
        }
        int rval = this.getMaxOrClause() / number;
        if (rval == 0) {
            rval = 1;
        }
        return rval;
    }
    
    @Override
    public String buildConjunctionClause(final List outputParameters, final ClauseDescription[] clauseDescriptions) {
        if (clauseDescriptions.length == 1) {
            return super.buildConjunctionClause(outputParameters, clauseDescriptions);
        }
        final StringBuilder sb = new StringBuilder("(");
        final int[] counters = new int[clauseDescriptions.length];
        for (int i = 0; i < counters.length; ++i) {
            counters[i] = 0;
        }
        boolean isFirst = true;
    Label_0056:
        while (true) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sb.append(" OR ");
            }
            for (int j = 0; j < counters.length; ++j) {
                final ClauseDescription cd = clauseDescriptions[j];
                if (j > 0) {
                    sb.append(" AND ");
                }
                final List values = cd.getValues();
                final String joinColumn = cd.getJoinColumnName();
                sb.append(cd.getColumnName()).append(cd.getOperation());
                if (values != null) {
                    sb.append("?");
                    outputParameters.add(values.get(counters[j]));
                }
                else if (joinColumn != null) {
                    sb.append(joinColumn);
                }
            }
            int k = 0;
            while (k != counters.length) {
                final int[] array = counters;
                final int n = k;
                ++array[n];
                final ClauseDescription cd = clauseDescriptions[k];
                final List values = cd.getValues();
                int size = 1;
                if (values != null) {
                    size = values.size();
                }
                if (counters[k] < size) {
                    continue Label_0056;
                }
                ++k;
                for (int l = 0; l < k; ++l) {
                    counters[l] = 0;
                }
            }
            break;
        }
        sb.append(")");
        return sb.toString();
    }
    
    @Override
    public int getMaxInClause() {
        return 100;
    }
    
    @Override
    public int getMaxOrClause() {
        return 25;
    }
    
    @Override
    public int getWindowedReportMaxRows() {
        return 1000;
    }
    
    @Override
    public void beginTransaction() throws ManifoldCFException {
        this.beginTransaction(0);
    }
    
    @Override
    public void beginTransaction(int transactionType) throws ManifoldCFException {
        if (this.getCurrentTransactionType() == 2) {
            ++this.serializableDepth;
            return;
        }
        if (transactionType == 0) {
            transactionType = this.getCurrentTransactionType();
        }
        switch (transactionType) {
            case 1: {
                this.desiredTransactionType = 2;
                super.beginTransaction(1);
                break;
            }
            case 2: {
                this.desiredTransactionType = 8;
                super.beginTransaction(2);
                break;
            }
            default: {
                throw new ManifoldCFException("Bad transaction type: " + Integer.toString(transactionType));
            }
        }
    }
    
    @Override
    public void signalRollback() {
        if (this.serializableDepth == 0) {
            super.signalRollback();
        }
    }
    
    @Override
    public void endTransaction() throws ManifoldCFException {
        if (this.serializableDepth > 0) {
            --this.serializableDepth;
            return;
        }
        super.endTransaction();
    }
    
    @Override
    protected void startATransaction() throws ManifoldCFException {
        if (!this.inTransaction) {
            try {
                this.connection.getConnection().setAutoCommit(false);
                this.connection.getConnection().setTransactionIsolation(this.desiredTransactionType);
            }
            catch (SQLException e) {
                throw new ManifoldCFException(e.getMessage(), e, 4);
            }
            this.inTransaction = true;
        }
        ++this.depthCount;
    }
    
    @Override
    protected void commitCurrentTransaction() throws ManifoldCFException {
        if (this.inTransaction) {
            if (this.depthCount == 1) {
                try {
                    if (this.connection != null) {
                        this.connection.getConnection().commit();
                        this.connection.getConnection().setAutoCommit(true);
                    }
                }
                catch (SQLException e) {
                    throw new ManifoldCFException(e.getMessage(), e, 4);
                }
                this.inTransaction = false;
            }
            --this.depthCount;
            return;
        }
        throw new ManifoldCFException("Transaction nesting error!");
    }
    
    @Override
    protected void rollbackCurrentTransaction() throws ManifoldCFException {
        if (this.inTransaction) {
            if (this.depthCount == 1) {
                try {
                    if (this.connection != null) {
                        this.connection.getConnection().rollback();
                        this.connection.getConnection().setAutoCommit(true);
                    }
                }
                catch (SQLException e) {
                    throw new ManifoldCFException(e.getMessage(), e, 4);
                }
                this.inTransaction = false;
            }
            --this.depthCount;
            return;
        }
        throw new ManifoldCFException("Transaction nesting error!");
    }
    
    @Override
    protected void explainQuery(final String query, final List params) throws ManifoldCFException {
        final IResultSet x = this.executeUncachedQuery("EXPLAIN PLAN FOR " + query, null, true, -1, null, null);
        int k = 0;
        while (k < x.getRowCount()) {
            final IResultRow row = x.getRow(k++);
            final Iterator<String> iter = row.getColumns();
            final String colName = iter.next();
            Logging.db.warn((Object)(" Plan: " + row.getValue(colName).toString()));
        }
        Logging.db.warn((Object)"");
    }
    
    @Override
    protected String mapLabelName(final String rawLabelName) {
        return rawLabelName.toLowerCase(Locale.ROOT);
    }
    
    static {
        (DBInterfaceHSQLDB.legalProtocolValues = new HashMap<String, String>()).put("hsql", "hsql");
        DBInterfaceHSQLDB.legalProtocolValues.put("http", "http");
        DBInterfaceHSQLDB.legalProtocolValues.put("https", "https");
    }
}
