// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.common;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.io.InputStream;
import java.io.StringReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.io.OutputStream;
import java.io.Reader;

public class Base64
{
    public static final String _rcsid = "@(#)$Id: Base64.java 988245 2010-08-23 18:39:35Z kwright $";
    private static final char[] base64CharacterArray;
    private static final byte[] mapArray;
    private static final char base64PadCharacter = '=';
    protected char[] characterBuffer;
    protected byte[] byteBuffer;
    
    public Base64() {
        this.characterBuffer = new char[4];
        this.byteBuffer = new byte[3];
    }
    
    public boolean decodeNextWord(final Reader inputBuffer, final OutputStream outputBuffer) throws ManifoldCFException {
        try {
            int bufferIndex = 0;
            while (bufferIndex < this.characterBuffer.length) {
                final int character = inputBuffer.read();
                if (character == -1) {
                    if (bufferIndex != 0) {
                        throw new ManifoldCFException("Unexpected end of base64 input");
                    }
                    return false;
                }
                else {
                    final char ch = (char)character;
                    if (ch != '=' && (ch >= Base64.mapArray.length || Base64.mapArray[ch] == 127)) {
                        continue;
                    }
                    this.characterBuffer[bufferIndex++] = ch;
                }
            }
            int outlen = 3;
            if (this.characterBuffer[3] == '=') {
                outlen = 2;
            }
            if (this.characterBuffer[2] == '=') {
                outlen = 1;
            }
            final int b0 = Base64.mapArray[this.characterBuffer[0]];
            final int b2 = Base64.mapArray[this.characterBuffer[1]];
            final int b3 = Base64.mapArray[this.characterBuffer[2]];
            final int b4 = Base64.mapArray[this.characterBuffer[3]];
            switch (outlen) {
                case 1: {
                    outputBuffer.write((byte)((b0 << 2 & 0xFC) | (b2 >> 4 & 0x3)));
                    break;
                }
                case 2: {
                    outputBuffer.write((byte)((b0 << 2 & 0xFC) | (b2 >> 4 & 0x3)));
                    outputBuffer.write((byte)((b2 << 4 & 0xF0) | (b3 >> 2 & 0xF)));
                    break;
                }
                case 3: {
                    outputBuffer.write((byte)((b0 << 2 & 0xFC) | (b2 >> 4 & 0x3)));
                    outputBuffer.write((byte)((b2 << 4 & 0xF0) | (b3 >> 2 & 0xF)));
                    outputBuffer.write((byte)((b3 << 6 & 0xC0) | (b4 & 0x3F)));
                    break;
                }
                default: {
                    throw new RuntimeException("Should never occur");
                }
            }
            return true;
        }
        catch (IOException e) {
            throw new ManifoldCFException("IO error converting from base 64", e);
        }
    }
    
    public void decodeStream(final Reader inputBuffer, final OutputStream outputBuffer) throws ManifoldCFException {
        while (this.decodeNextWord(inputBuffer, outputBuffer)) {}
    }
    
    public byte[] decodeString(final String inputString) throws ManifoldCFException {
        try {
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream((inputString.length() >> 2) * 3 + 3);
            try {
                final Reader reader = new StringReader(inputString);
                try {
                    this.decodeStream(reader, outputStream);
                    outputStream.flush();
                    return outputStream.toByteArray();
                }
                finally {
                    reader.close();
                }
            }
            finally {
                outputStream.close();
            }
        }
        catch (IOException e) {
            throw new ManifoldCFException("Error streaming through base64 decoder", e);
        }
    }
    
    public boolean encodeNextWord(final InputStream inputStream, final Writer outputWriter) throws ManifoldCFException {
        try {
            final int actualLength = inputStream.read(this.byteBuffer);
            if (actualLength == -1) {
                return false;
            }
            switch (actualLength) {
                case 0: {
                    throw new ManifoldCFException("Read 0 bytes!");
                }
                case 1: {
                    final int i = this.byteBuffer[0] & 0xFF;
                    outputWriter.write(Base64.base64CharacterArray[i >> 2]);
                    outputWriter.write(Base64.base64CharacterArray[i << 4 & 0x3F]);
                    outputWriter.write(61);
                    outputWriter.write(61);
                    break;
                }
                case 2: {
                    final int i = ((this.byteBuffer[0] & 0xFF) << 8) + (this.byteBuffer[1] & 0xFF);
                    outputWriter.write(Base64.base64CharacterArray[i >> 10]);
                    outputWriter.write(Base64.base64CharacterArray[i >> 4 & 0x3F]);
                    outputWriter.write(Base64.base64CharacterArray[i << 2 & 0x3F]);
                    outputWriter.write(61);
                    break;
                }
                case 3: {
                    final int i = ((this.byteBuffer[0] & 0xFF) << 16) + ((this.byteBuffer[1] & 0xFF) << 8) + (this.byteBuffer[2] & 0xFF);
                    outputWriter.write(Base64.base64CharacterArray[i >> 18]);
                    outputWriter.write(Base64.base64CharacterArray[i >> 12 & 0x3F]);
                    outputWriter.write(Base64.base64CharacterArray[i >> 6 & 0x3F]);
                    outputWriter.write(Base64.base64CharacterArray[i & 0x3F]);
                    break;
                }
                default: {
                    throw new RuntimeException("Should never get here");
                }
            }
            return true;
        }
        catch (IOException e) {
            throw new ManifoldCFException("IO error encoding in base64", e);
        }
    }
    
    public void encodeStream(final InputStream inputStream, final Writer outputWriter) throws ManifoldCFException {
        while (this.encodeNextWord(inputStream, outputWriter)) {}
    }
    
    public String encodeByteArray(final byte[] inputByteArray) throws ManifoldCFException {
        try {
            final Writer writer = new StringWriter(inputByteArray.length * 4 / 3 + 4);
            try {
                final InputStream is = new ByteArrayInputStream(inputByteArray);
                try {
                    this.encodeStream(is, writer);
                    writer.flush();
                    return writer.toString();
                }
                finally {
                    is.close();
                }
            }
            finally {
                writer.close();
            }
        }
        catch (IOException e) {
            throw new ManifoldCFException("Error streaming through base64 encoder", e);
        }
    }
    
    static {
        base64CharacterArray = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
        mapArray = new byte[128];
        for (int i = 0; i < Base64.mapArray.length; Base64.mapArray[i++] = 127) {}
        for (int i = 0; i < Base64.base64CharacterArray.length; ++i) {
            Base64.mapArray[Base64.base64CharacterArray[i]] = (byte)i;
        }
    }
}
