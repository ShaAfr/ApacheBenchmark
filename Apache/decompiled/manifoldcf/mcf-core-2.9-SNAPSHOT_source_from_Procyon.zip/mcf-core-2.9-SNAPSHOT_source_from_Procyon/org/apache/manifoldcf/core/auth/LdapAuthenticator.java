// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.auth;

import javax.naming.NamingEnumeration;
import javax.naming.directory.DirContext;
import javax.naming.NamingException;
import javax.naming.directory.SearchResult;
import javax.naming.directory.SearchControls;
import javax.naming.directory.InitialDirContext;
import org.apache.manifoldcf.core.system.Logging;
import org.apache.commons.lang.StringUtils;
import java.util.Hashtable;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import org.apache.manifoldcf.core.interfaces.IAuth;

public class LdapAuthenticator implements IAuth
{
    private static final String CONTEXT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
    private static final String PROVIDER_URL_PROPERTY = "org.apache.manifoldcf.login.ldap.providerurl";
    private static final String SECURITY_AUTHENTICATION_TYPE = "org.apache.manifoldcf.login.ldap.securityauthenticationtype";
    private static final String SECURITY_PRINCIPLE = "org.apache.manifoldcf.login.ldap.securityprincipal";
    private static final String CONTEXT_SEARCH_QUERY = "org.apache.manifoldcf.login.ldap.contextsearchquery";
    private static final String SEARCH_ATTRIBUTE = "org.apache.manifoldcf.login.ldap.searchattribute";
    protected final String securityPrincipal;
    protected final String securityAuthenticationType;
    protected final String providerURLProperty;
    protected final String contextSearchQuery;
    protected final String searchAttribute;
    
    public LdapAuthenticator(final IThreadContext threadContext) throws ManifoldCFException {
        this.securityPrincipal = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.login.ldap.securityprincipal", "");
        this.securityAuthenticationType = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.login.ldap.securityauthenticationtype", "simple");
        this.providerURLProperty = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.login.ldap.providerurl", "");
        this.contextSearchQuery = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.login.ldap.contextsearchquery", "");
        this.searchAttribute = LockManagerFactory.getStringProperty(threadContext, "org.apache.manifoldcf.login.ldap.searchattribute", "uid");
    }
    
    private Hashtable<String, String> buildEnvironment(final String userID, final String password) {
        final Hashtable<String, String> environment = new Hashtable<String, String>();
        environment.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
        environment.put("java.naming.provider.url", this.providerURLProperty);
        environment.put("java.naming.security.authentication", this.securityAuthenticationType);
        environment.put("java.naming.security.principal", substituteUser(this.securityPrincipal, userID));
        environment.put("java.naming.security.credentials", password);
        return environment;
    }
    
    private static String substituteUser(final String source, final String substitution) {
        return source.replace("$(userID)", substitution);
    }
    
    @Override
    public boolean verifyUILogin(final String userId, final String password) throws ManifoldCFException {
        return this.verifyLogin(userId, password);
    }
    
    @Override
    public boolean verifyAPILogin(final String userId, final String password) throws ManifoldCFException {
        return this.verifyLogin(userId, password);
    }
    
    protected boolean verifyLogin(final String userId, final String password) throws ManifoldCFException {
        boolean authenticated = false;
        if (StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(password)) {
            try {
                Logging.misc.info((Object)("Authentication attempt for user = " + userId));
                final DirContext ctx = new InitialDirContext(this.buildEnvironment(userId, password));
                NamingEnumeration results = null;
                try {
                    final SearchControls controls = new SearchControls();
                    controls.setSearchScope(2);
                    results = ctx.search("", substituteUser(this.contextSearchQuery, userId), controls);
                    while (results.hasMore()) {
                        final SearchResult searchResult = results.next();
                        if (userId.equals(searchResult.getAttributes().get(this.searchAttribute).get())) {
                            Logging.misc.info((Object)("Successfully authenticated : " + userId));
                            authenticated = true;
                            break;
                        }
                    }
                }
                catch (Exception e) {
                    Logging.misc.error((Object)("User not authenticated = " + userId + " exception = " + e.getMessage()), (Throwable)e);
                    throw new ManifoldCFException("User not authenticated: " + e.getMessage(), e);
                }
                finally {
                    if (results != null) {
                        try {
                            results.close();
                        }
                        catch (Exception ex) {}
                    }
                    if (ctx != null) {
                        try {
                            ctx.close();
                        }
                        catch (Exception ex2) {}
                    }
                }
            }
            catch (NamingException e2) {
                Logging.misc.error((Object)("Exception authenticating user = " + userId + " exception = " + e2.getMessage()), (Throwable)e2);
                throw new ManifoldCFException("Exception authenticating user: " + e2.getMessage(), e2);
            }
        }
        return authenticated;
    }
    
    @Override
    public boolean checkCapability(final String userId, final int capability) throws ManifoldCFException {
        return true;
    }
}
