// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import org.apache.manifoldcf.core.system.ManifoldCF;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class ManifoldCFConfiguration extends Configuration
{
    public static final String _rcsid = "@(#)$Id: ManifoldCFConfiguration.java 988245 2010-08-23 18:39:35Z kwright $";
    public static final String NODE_PROPERTY = "property";
    public static final String ATTRIBUTE_NAME = "name";
    public static final String ATTRIBUTE_VALUE = "value";
    protected final Map<String, String> localProperties;
    
    public ManifoldCFConfiguration() {
        super("configuration");
        this.localProperties = new HashMap<String, String>();
    }
    
    public ManifoldCFConfiguration(final InputStream xmlStream) throws ManifoldCFException {
        super("configuration");
        this.localProperties = new HashMap<String, String>();
        this.fromXML(xmlStream);
        this.parseProperties();
    }
    
    public String getProperty(final String s) {
        return this.localProperties.get(s);
    }
    
    public String getStringProperty(final String s, final String defaultValue) {
        String rval = this.getProperty(s);
        if (rval == null) {
            rval = defaultValue;
        }
        return rval;
    }
    
    public String getPossiblyObfuscatedStringProperty(final String s, final String defaultValue) throws ManifoldCFException {
        final String obfuscatedPropertyName = s + ".obfuscated";
        String rval = this.getProperty(obfuscatedPropertyName);
        if (rval != null) {
            return ManifoldCF.deobfuscate(rval);
        }
        rval = this.getProperty(s);
        if (rval == null) {
            rval = defaultValue;
        }
        return rval;
    }
    
    public boolean getBooleanProperty(final String s, final boolean defaultValue) throws ManifoldCFException {
        final String value = this.getProperty(s);
        if (value == null) {
            return defaultValue;
        }
        if (value.equals("true") || value.equals("yes")) {
            return true;
        }
        if (value.equals("false") || value.equals("no")) {
            return false;
        }
        throw new ManifoldCFException("Illegal property value for boolean property '" + s + "': '" + value + "'");
    }
    
    public int getIntProperty(final String s, final int defaultValue) throws ManifoldCFException {
        final String value = this.getProperty(s);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value);
        }
        catch (NumberFormatException e) {
            throw new ManifoldCFException("Illegal property value for integer property '" + s + "': '" + value + "': " + e.getMessage(), e, 3);
        }
    }
    
    public long getLongProperty(final String s, final long defaultValue) throws ManifoldCFException {
        final String value = this.getProperty(s);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Long.parseLong(value);
        }
        catch (NumberFormatException e) {
            throw new ManifoldCFException("Illegal property value for long property '" + s + "': '" + value + "': " + e.getMessage(), e, 3);
        }
    }
    
    public double getDoubleProperty(final String s, final double defaultValue) throws ManifoldCFException {
        final String value = this.getProperty(s);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Double.parseDouble(value);
        }
        catch (NumberFormatException e) {
            throw new ManifoldCFException("Illegal property value for double property '" + s + "': '" + value + "': " + e.getMessage(), e, 3);
        }
    }
    
    protected void parseProperties() throws ManifoldCFException {
        this.localProperties.clear();
        for (int i = 0; i < this.getChildCount(); ++i) {
            final ConfigurationNode cn = this.findChild(i);
            if (cn.getType().equals("property")) {
                final String name = cn.getAttributeValue("name");
                final String value = cn.getAttributeValue("value");
                if (name == null) {
                    throw new ManifoldCFException("Node type 'property' requires a 'name' attribute");
                }
                this.localProperties.put(name, value);
            }
        }
    }
    
    @Override
    public void fromXML(final InputStream is) throws ManifoldCFException {
        super.fromXML(is);
        this.parseProperties();
    }
    
    @Override
    protected Configuration createNew() {
        return new ManifoldCFConfiguration();
    }
}
