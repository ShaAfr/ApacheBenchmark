// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.ArrayList;
import java.util.List;

public class UnitaryClause implements ClauseDescription
{
    public static final String _rcsid = "@(#)$Id$";
    protected String columnName;
    protected String operationName;
    protected List values;
    
    public UnitaryClause(final String columnName, final String operationName, final Object value) {
        this.columnName = columnName;
        this.operationName = operationName;
        (this.values = new ArrayList()).add(value);
    }
    
    public UnitaryClause(final String columnName, final Object value) {
        this(columnName, "=", value);
    }
    
    @Override
    public String getColumnName() {
        return this.columnName;
    }
    
    @Override
    public String getOperation() {
        return this.operationName;
    }
    
    @Override
    public List getValues() {
        return this.values;
    }
    
    @Override
    public String getJoinColumnName() {
        return null;
    }
}
