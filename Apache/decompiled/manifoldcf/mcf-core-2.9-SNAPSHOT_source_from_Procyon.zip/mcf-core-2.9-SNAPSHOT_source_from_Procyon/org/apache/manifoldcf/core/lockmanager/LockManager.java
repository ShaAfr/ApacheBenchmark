// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import org.apache.manifoldcf.core.interfaces.LockException;
import org.apache.manifoldcf.core.interfaces.ManifoldCFConfiguration;
import org.apache.manifoldcf.core.interfaces.IServiceDataAcceptor;
import org.apache.manifoldcf.core.interfaces.IServiceCleanup;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.io.File;
import org.apache.manifoldcf.core.interfaces.ILockManager;

public class LockManager implements ILockManager
{
    public static final String _rcsid = "@(#)$Id: LockManager.java 988245 2010-08-23 18:39:35Z kwright $";
    protected final ILockManager lockManager;
    
    public LockManager() throws ManifoldCFException {
        final File synchDirectory = FileLockManager.getSynchDirectoryProperty();
        if (synchDirectory != null) {
            this.lockManager = new FileLockManager(synchDirectory);
        }
        else {
            this.lockManager = new BaseLockManager();
        }
    }
    
    @Override
    public String registerServiceBeginServiceActivity(final String serviceType, final String serviceName, final IServiceCleanup cleanup) throws ManifoldCFException {
        return this.lockManager.registerServiceBeginServiceActivity(serviceType, serviceName, cleanup);
    }
    
    @Override
    public String registerServiceBeginServiceActivity(final String serviceType, final String serviceName, final byte[] initialData, final IServiceCleanup cleanup) throws ManifoldCFException {
        return this.lockManager.registerServiceBeginServiceActivity(serviceType, serviceName, initialData, cleanup);
    }
    
    @Override
    public void updateServiceData(final String serviceType, final String serviceName, final byte[] serviceData) throws ManifoldCFException {
        this.lockManager.updateServiceData(serviceType, serviceName, serviceData);
    }
    
    @Override
    public byte[] retrieveServiceData(final String serviceType, final String serviceName) throws ManifoldCFException {
        return this.lockManager.retrieveServiceData(serviceType, serviceName);
    }
    
    @Override
    public void scanServiceData(final String serviceType, final IServiceDataAcceptor dataAcceptor) throws ManifoldCFException {
        this.lockManager.scanServiceData(serviceType, dataAcceptor);
    }
    
    @Override
    public boolean cleanupInactiveService(final String serviceType, final IServiceCleanup cleanup) throws ManifoldCFException {
        return this.lockManager.cleanupInactiveService(serviceType, cleanup);
    }
    
    @Override
    public int countActiveServices(final String serviceType) throws ManifoldCFException {
        return this.lockManager.countActiveServices(serviceType);
    }
    
    @Override
    public void endServiceActivity(final String serviceType, final String serviceName) throws ManifoldCFException {
        this.lockManager.endServiceActivity(serviceType, serviceName);
    }
    
    @Override
    public boolean checkServiceActive(final String serviceType, final String serviceName) throws ManifoldCFException {
        return this.lockManager.checkServiceActive(serviceType, serviceName);
    }
    
    @Override
    public ManifoldCFConfiguration getSharedConfiguration() throws ManifoldCFException {
        return this.lockManager.getSharedConfiguration();
    }
    
    @Override
    public void setGlobalFlag(final String flagName) throws ManifoldCFException {
        this.lockManager.setGlobalFlag(flagName);
    }
    
    @Override
    public void clearGlobalFlag(final String flagName) throws ManifoldCFException {
        this.lockManager.clearGlobalFlag(flagName);
    }
    
    @Override
    public boolean checkGlobalFlag(final String flagName) throws ManifoldCFException {
        return this.lockManager.checkGlobalFlag(flagName);
    }
    
    @Override
    public byte[] readData(final String resourceName) throws ManifoldCFException {
        return this.lockManager.readData(resourceName);
    }
    
    @Override
    public void writeData(final String resourceName, final byte[] data) throws ManifoldCFException {
        this.lockManager.writeData(resourceName, data);
    }
    
    @Override
    public void timedWait(final int time) throws ManifoldCFException {
        this.lockManager.timedWait(time);
    }
    
    @Override
    public void enterNonExWriteLock(final String lockKey) throws ManifoldCFException {
        this.lockManager.enterNonExWriteLock(lockKey);
    }
    
    @Override
    public void enterNonExWriteLockNoWait(final String lockKey) throws ManifoldCFException, LockException {
        this.lockManager.enterNonExWriteLockNoWait(lockKey);
    }
    
    @Override
    public void leaveNonExWriteLock(final String lockKey) throws ManifoldCFException {
        this.lockManager.leaveNonExWriteLock(lockKey);
    }
    
    @Override
    public void enterWriteLock(final String lockKey) throws ManifoldCFException {
        this.lockManager.enterWriteLock(lockKey);
    }
    
    @Override
    public void enterWriteLockNoWait(final String lockKey) throws ManifoldCFException, LockException {
        this.lockManager.enterWriteLockNoWait(lockKey);
    }
    
    @Override
    public void leaveWriteLock(final String lockKey) throws ManifoldCFException {
        this.lockManager.leaveWriteLock(lockKey);
    }
    
    @Override
    public void enterReadLock(final String lockKey) throws ManifoldCFException {
        this.lockManager.enterReadLock(lockKey);
    }
    
    @Override
    public void enterReadLockNoWait(final String lockKey) throws ManifoldCFException, LockException {
        this.lockManager.enterReadLockNoWait(lockKey);
    }
    
    @Override
    public void leaveReadLock(final String lockKey) throws ManifoldCFException {
        this.lockManager.leaveReadLock(lockKey);
    }
    
    @Override
    public void clearLocks() throws ManifoldCFException {
        this.lockManager.clearLocks();
    }
    
    @Override
    public void enterLocks(final String[] readLocks, final String[] nonExWriteLocks, final String[] writeLocks) throws ManifoldCFException {
        this.lockManager.enterLocks(readLocks, nonExWriteLocks, writeLocks);
    }
    
    @Override
    public void enterLocksNoWait(final String[] readLocks, final String[] nonExWriteLocks, final String[] writeLocks) throws ManifoldCFException, LockException {
        this.lockManager.enterLocksNoWait(readLocks, nonExWriteLocks, writeLocks);
    }
    
    @Override
    public void leaveLocks(final String[] readLocks, final String[] writeNonExLocks, final String[] writeLocks) throws ManifoldCFException {
        this.lockManager.leaveLocks(readLocks, writeNonExLocks, writeLocks);
    }
    
    @Override
    public void enterReadCriticalSection(final String sectionKey) throws ManifoldCFException {
        this.lockManager.enterReadCriticalSection(sectionKey);
    }
    
    @Override
    public void leaveReadCriticalSection(final String sectionKey) throws ManifoldCFException {
        this.lockManager.leaveReadCriticalSection(sectionKey);
    }
    
    @Override
    public void enterNonExWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        this.lockManager.enterNonExWriteCriticalSection(sectionKey);
    }
    
    @Override
    public void leaveNonExWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        this.lockManager.leaveNonExWriteCriticalSection(sectionKey);
    }
    
    @Override
    public void enterWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        this.lockManager.enterWriteCriticalSection(sectionKey);
    }
    
    @Override
    public void leaveWriteCriticalSection(final String sectionKey) throws ManifoldCFException {
        this.lockManager.leaveWriteCriticalSection(sectionKey);
    }
    
    @Override
    public void enterCriticalSections(final String[] readSectionKeys, final String[] nonExSectionKeys, final String[] writeSectionKeys) throws ManifoldCFException {
        this.lockManager.enterCriticalSections(readSectionKeys, nonExSectionKeys, writeSectionKeys);
    }
    
    @Override
    public void leaveCriticalSections(final String[] readSectionKeys, final String[] nonExSectionKeys, final String[] writeSectionKeys) throws ManifoldCFException {
        this.lockManager.leaveCriticalSections(readSectionKeys, nonExSectionKeys, writeSectionKeys);
    }
}
