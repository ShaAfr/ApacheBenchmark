// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core;

import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.interfaces.ThreadContextFactory;

public abstract class DBInitializationCommand implements InitializationCommand
{
    private final String userName;
    private final String password;
    
    public DBInitializationCommand(final String userName, final String password) {
        this.userName = userName;
        this.password = password;
    }
    
    @Override
    public void execute() throws ManifoldCFException {
        final IThreadContext tc = ThreadContextFactory.make();
        ManifoldCF.initializeEnvironment(tc);
        this.doExecute(tc);
    }
    
    protected abstract void doExecute(final IThreadContext p0) throws ManifoldCFException;
    
    protected String getPassword() {
        return this.password;
    }
    
    protected String getUserName() {
        return this.userName;
    }
}
