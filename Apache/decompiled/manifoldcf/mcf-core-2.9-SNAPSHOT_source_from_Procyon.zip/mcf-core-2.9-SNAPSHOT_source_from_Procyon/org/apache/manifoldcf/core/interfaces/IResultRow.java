// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

import java.util.Iterator;

public interface IResultRow
{
    public static final String _rcsid = "@(#)$Id: IResultRow.java 988245 2010-08-23 18:39:35Z kwright $";
    
    int getColumnCount();
    
    Iterator<String> getColumns();
    
    Object getValue(final String p0);
}
