// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.i18n;

import java.util.HashSet;
import org.apache.manifoldcf.core.system.Logging;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.io.InputStream;
import java.util.Locale;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.commons.collections.ExtendedProperties;
import org.apache.velocity.app.VelocityEngine;
import java.util.Set;

public class Messages
{
    protected static Set<BundleKey> bundleSet;
    protected static Set<MessageKey> messageSet;
    protected static Set<ResourceKey> resourceSet;
    
    protected Messages() {
    }
    
    public static VelocityEngine createVelocityEngine(final Class classInstance) throws ManifoldCFException {
        final VelocityEngine engine = new VelocityEngine();
        final ExtendedProperties configuration = new ExtendedProperties();
        configuration.setProperty("resource.loader", (Object)"mcf");
        configuration.setProperty("mcf.resource.loader.instance", (Object)new MCFVelocityResourceLoader(classInstance));
        engine.setExtendedProperties(configuration);
        engine.setProperty("runtime.log.logsystem.class", (Object)"org.apache.velocity.runtime.log.Log4JLogChute");
        engine.setProperty("runtime.log.logsystem.log4j.logger", (Object)"velocity");
        return engine;
    }
    
    public static InputStream getResourceAsStream(final Class classInstance, final String pathName, final Locale originalLocale, final String resourceKey) throws ManifoldCFException {
        Locale locale = originalLocale;
        InputStream is = classInstance.getResourceAsStream(localizeResourceName(pathName, resourceKey, locale));
        if (is == null) {
            complainMissingResource("No resource in path '" + pathName + "' named '" + resourceKey + "' found for locale '" + locale.toString() + "'", new Exception("Resource not found"), pathName, locale, resourceKey);
            locale = new Locale(locale.getLanguage());
            is = classInstance.getResourceAsStream(localizeResourceName(pathName, resourceKey, locale));
            if (is == null) {
                complainMissingResource("No resource in path '" + pathName + "' named '" + resourceKey + "' found for locale '" + locale.toString() + "'", new Exception("Resource not found"), pathName, locale, resourceKey);
                locale = Locale.US;
                is = classInstance.getResourceAsStream(localizeResourceName(pathName, resourceKey, locale));
                if (is == null) {
                    complainMissingResource("No resource in path '" + pathName + "' named '" + resourceKey + "' found for locale '" + locale.toString() + "'", new Exception("Resource not found"), pathName, locale, resourceKey);
                    locale = new Locale(locale.getLanguage());
                    is = classInstance.getResourceAsStream(localizeResourceName(pathName, resourceKey, locale));
                    if (is == null) {
                        complainMissingResource("No resource in path '" + pathName + "' named '" + resourceKey + "' found for locale '" + locale.toString() + "'", new Exception("Resource not found"), pathName, locale, resourceKey);
                        is = classInstance.getResourceAsStream(localizeResourceName(pathName, resourceKey, null));
                        if (is == null) {
                            throw new ManifoldCFException("No matching language resource in path '" + pathName + "' named '" + resourceKey + "' found for locale '" + originalLocale.toString() + "'");
                        }
                    }
                }
            }
        }
        return is;
    }
    
    private static String localizeResourceName(final String pathName, final String resourceName, final Locale locale) {
        if (locale == null) {
            return resourceName;
        }
        final int dotIndex = resourceName.lastIndexOf(".");
        if (dotIndex == -1) {
            return resourceName + "_" + locale.toString();
        }
        return resourceName.substring(0, dotIndex) + "_" + locale.toString() + resourceName.substring(dotIndex);
    }
    
    public static ResourceBundle getResourceBundle(final Class clazz, final String bundleName, Locale locale) {
        final ClassLoader classLoader = clazz.getClassLoader();
        ResourceBundle resources;
        try {
            resources = ResourceBundle.getBundle(bundleName, locale, classLoader);
        }
        catch (MissingResourceException e) {
            complainMissingBundle("Missing resource bundle '" + bundleName + "' for locale '" + locale.toString() + "': " + e.getMessage() + "; trying " + locale.getLanguage(), e, bundleName, locale);
            locale = new Locale(locale.getLanguage());
            try {
                resources = ResourceBundle.getBundle(bundleName, locale, classLoader);
            }
            catch (MissingResourceException e2) {
                complainMissingBundle("Missing resource bundle '" + bundleName + "' for locale '" + locale.toString() + "': " + e2.getMessage() + "; trying en_US", e2, bundleName, locale);
                locale = Locale.US;
                try {
                    resources = ResourceBundle.getBundle(bundleName, locale, classLoader);
                }
                catch (MissingResourceException e3) {
                    complainMissingBundle("No backup en_US bundle found! " + e3.getMessage(), e3, bundleName, locale);
                    locale = new Locale(locale.getLanguage());
                    try {
                        resources = ResourceBundle.getBundle(bundleName, locale, classLoader);
                    }
                    catch (MissingResourceException e4) {
                        complainMissingBundle("No backup en bundle found! " + e4.getMessage(), e4, bundleName, locale);
                        return null;
                    }
                }
            }
        }
        return resources;
    }
    
    public static String getMessage(final Class clazz, final String bundleName, final Locale locale, final String messageKey) {
        final ResourceBundle resources = getResourceBundle(clazz, bundleName, locale);
        if (resources == null) {
            return null;
        }
        return getMessage(resources, bundleName, locale, messageKey);
    }
    
    public static String getMessage(final ResourceBundle resources, final String bundleName, final Locale locale, final String messageKey) {
        try {
            return resources.getString(messageKey);
        }
        catch (MissingResourceException e) {
            complainMissingMessage("Missing resource '" + messageKey + "' in bundle '" + bundleName + "' for locale '" + locale.toString() + "'", e, bundleName, locale, messageKey);
            return null;
        }
    }
    
    public static String getString(final ResourceBundle resourceBundle, final String bundleName, final Locale locale, final String messageKey) {
        return getString(resourceBundle, bundleName, locale, messageKey, null);
    }
    
    public static String getString(final Class clazz, final String bundleName, final Locale locale, final String messageKey, final Object[] args) {
        final String message = getMessage(clazz, bundleName, locale, messageKey);
        if (message == null) {
            return messageKey;
        }
        String formatMessage;
        if (args != null) {
            final MessageFormat fm = new MessageFormat(message, Locale.ROOT);
            fm.setLocale(locale);
            formatMessage = fm.format(args);
        }
        else {
            formatMessage = message;
        }
        return formatMessage;
    }
    
    public static String getString(final ResourceBundle resourceBundle, final String bundleName, Locale locale, final String messageKey, final Object[] args) {
        final String message = getMessage(resourceBundle, bundleName, locale, messageKey);
        if (message == null) {
            return messageKey;
        }
        String formatMessage;
        if (args != null) {
            if (locale == null) {
                locale = Locale.ROOT;
            }
            final MessageFormat fm = new MessageFormat(message, locale);
            formatMessage = fm.format(args);
        }
        else {
            formatMessage = message;
        }
        return formatMessage;
    }
    
    protected static void complainMissingBundle(final String errorMessage, final Throwable exception, final String bundleName, final Locale locale) {
        final String localeName = locale.toString();
        final BundleKey bk = new BundleKey(bundleName, localeName);
        synchronized (Messages.bundleSet) {
            if (Messages.bundleSet.contains(bk)) {
                return;
            }
            Messages.bundleSet.add(bk);
        }
        logError(errorMessage, exception);
    }
    
    protected static void complainMissingMessage(final String errorMessage, final Throwable exception, final String bundleName, final Locale locale, final String messageKey) {
        final String localeName = locale.toString();
        final MessageKey bk = new MessageKey(bundleName, localeName, messageKey);
        synchronized (Messages.messageSet) {
            if (Messages.messageSet.contains(bk)) {
                return;
            }
            Messages.messageSet.add(bk);
        }
        logError(errorMessage, exception);
    }
    
    protected static void complainMissingResource(final String errorMessage, final Throwable exception, final String pathName, final Locale locale, final String resourceKey) {
        final String localeName = locale.toString();
        final ResourceKey bk = new ResourceKey(pathName, localeName, resourceKey);
        synchronized (Messages.resourceSet) {
            if (Messages.resourceSet.contains(bk)) {
                return;
            }
            Messages.resourceSet.add(bk);
        }
        logError(errorMessage, exception);
    }
    
    protected static void logError(final String errorMessage, final Throwable exception) {
        if (Logging.misc == null) {
            System.err.println(errorMessage);
            exception.printStackTrace(System.err);
        }
        else {
            Logging.misc.error((Object)errorMessage, exception);
        }
    }
    
    static {
        Messages.bundleSet = new HashSet<BundleKey>();
        Messages.messageSet = new HashSet<MessageKey>();
        Messages.resourceSet = new HashSet<ResourceKey>();
    }
    
    protected static class BundleKey
    {
        protected String bundleName;
        protected String localeName;
        
        public BundleKey(final String bundleName, final String localeName) {
            this.bundleName = bundleName;
            this.localeName = localeName;
        }
        
        @Override
        public int hashCode() {
            return this.bundleName.hashCode() + this.localeName.hashCode();
        }
        
        @Override
        public boolean equals(final Object o) {
            if (!(o instanceof BundleKey)) {
                return false;
            }
            final BundleKey b = (BundleKey)o;
            return b.bundleName.equals(this.bundleName) && b.localeName.equals(this.localeName);
        }
    }
    
    protected static class MessageKey
    {
        protected String bundleName;
        protected String localeName;
        protected String messageKey;
        
        public MessageKey(final String bundleName, final String localeName, final String messageKey) {
            this.bundleName = bundleName;
            this.localeName = localeName;
            this.messageKey = messageKey;
        }
        
        @Override
        public int hashCode() {
            return this.bundleName.hashCode() + this.localeName.hashCode() + this.messageKey.hashCode();
        }
        
        @Override
        public boolean equals(final Object o) {
            if (!(o instanceof MessageKey)) {
                return false;
            }
            final MessageKey b = (MessageKey)o;
            return b.bundleName.equals(this.bundleName) && b.localeName.equals(this.localeName) && b.messageKey.equals(this.messageKey);
        }
    }
    
    protected static class ResourceKey
    {
        protected String pathName;
        protected String localeName;
        protected String resourceKey;
        
        public ResourceKey(final String pathName, final String localeName, final String resourceKey) {
            this.pathName = pathName;
            this.localeName = localeName;
            this.resourceKey = resourceKey;
        }
        
        @Override
        public int hashCode() {
            return this.pathName.hashCode() + this.localeName.hashCode() + this.resourceKey.hashCode();
        }
        
        @Override
        public boolean equals(final Object o) {
            if (!(o instanceof ResourceKey)) {
                return false;
            }
            final ResourceKey b = (ResourceKey)o;
            return b.pathName.equals(this.pathName) && b.localeName.equals(this.localeName) && b.resourceKey.equals(this.resourceKey);
        }
    }
}
