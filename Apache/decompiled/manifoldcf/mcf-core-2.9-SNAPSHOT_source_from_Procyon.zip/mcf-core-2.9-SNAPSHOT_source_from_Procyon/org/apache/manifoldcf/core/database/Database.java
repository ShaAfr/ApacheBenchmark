// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.database;

import org.apache.manifoldcf.core.cachemanager.ExecutorBase;
import java.sql.Clob;
import java.io.InputStream;
import org.apache.manifoldcf.core.interfaces.TempFileCharacterInput;
import org.apache.manifoldcf.core.interfaces.TempFileInput;
import java.sql.Blob;
import java.sql.Timestamp;
import org.apache.manifoldcf.core.interfaces.TimeMarker;
import java.util.Date;
import org.apache.manifoldcf.core.interfaces.CharacterInput;
import org.apache.manifoldcf.core.interfaces.BinaryInput;
import java.sql.ResultSetMetaData;
import org.apache.manifoldcf.core.interfaces.PersistentDatabaseObject;
import org.apache.manifoldcf.core.interfaces.IResultRow;
import java.util.Locale;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import org.apache.manifoldcf.core.interfaces.ClauseDescription;
import org.apache.manifoldcf.core.interfaces.IndexDescription;
import org.apache.manifoldcf.core.system.ManifoldCF;
import java.util.Iterator;
import org.apache.manifoldcf.core.interfaces.ICacheExecutor;
import org.apache.manifoldcf.core.interfaces.ICacheDescription;
import org.apache.manifoldcf.core.system.Logging;
import org.apache.manifoldcf.core.interfaces.IResultSet;
import org.apache.manifoldcf.core.interfaces.ILimitChecker;
import org.apache.manifoldcf.core.interfaces.ResultSpecification;
import org.apache.manifoldcf.core.interfaces.StringSet;
import java.util.List;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.CacheManagerFactory;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import java.util.HashMap;
import java.util.Random;
import java.util.Map;
import org.apache.manifoldcf.core.jdbcpool.WrappedConnection;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import org.apache.manifoldcf.core.interfaces.ICacheManager;

public abstract class Database
{
    public static final String _rcsid = "@(#)$Id: Database.java 988245 2010-08-23 18:39:35Z kwright $";
    protected final ICacheManager cacheManager;
    protected final IThreadContext context;
    protected final String jdbcUrl;
    protected final String jdbcDriverClass;
    protected final String databaseName;
    protected String userName;
    protected String password;
    protected TransactionHandle th;
    protected WrappedConnection connection;
    protected boolean doRollback;
    protected boolean commitDone;
    protected int delayedTransactionDepth;
    protected Map<String, Modifications> modificationsSet;
    protected final long maxQueryTime;
    protected final boolean debug;
    protected final int maxDBConnections;
    protected static Random random;
    protected static final String _TRANSACTION_ = "_TRANSACTION_";
    
    public Database(final IThreadContext context, final String jdbcUrl, final String jdbcDriverClass, final String databaseName, final String userName, final String password) throws ManifoldCFException {
        this.th = null;
        this.connection = null;
        this.doRollback = false;
        this.commitDone = false;
        this.delayedTransactionDepth = 0;
        this.modificationsSet = new HashMap<String, Modifications>();
        this.context = context;
        this.jdbcUrl = jdbcUrl;
        this.jdbcDriverClass = jdbcDriverClass;
        this.databaseName = databaseName;
        this.userName = userName;
        this.password = password;
        this.maxQueryTime = LockManagerFactory.getIntProperty(context, "org.apache.manifoldcf.database.maxquerytime", 60) * 1000L;
        this.debug = LockManagerFactory.getBooleanProperty(context, "org.apache.manifoldcf.database.connectiontracking", false);
        this.maxDBConnections = LockManagerFactory.getIntProperty(context, "org.apache.manifoldcf.database.maxhandles", 50);
        this.cacheManager = CacheManagerFactory.make(context);
    }
    
    public String getDatabaseName() {
        return this.databaseName;
    }
    
    public String getTransactionID() {
        if (this.th == null) {
            return null;
        }
        return this.th.getTransactionID();
    }
    
    protected void startATransaction() throws ManifoldCFException {
    }
    
    protected void commitCurrentTransaction() throws ManifoldCFException {
    }
    
    protected void rollbackCurrentTransaction() throws ManifoldCFException {
    }
    
    protected void explainQuery(final String query, final List params) throws ManifoldCFException {
    }
    
    protected String mapLookupName(final String rawColumnName, final String rawLabelName) {
        return rawColumnName;
    }
    
    protected String mapLabelName(final String rawLabelName) {
        return rawLabelName;
    }
    
    public void prepareForDatabaseCreate() throws ManifoldCFException {
        if (this.connection != null) {
            throw new ManifoldCFException("Can't do a database create within a transaction");
        }
        ConnectionFactory.flush();
    }
    
    public IResultSet executeQuery(final String query, final List params, StringSet cacheKeys, final StringSet invalidateKeys, final String queryClass, final boolean needResult, final int maxReturn, final ResultSpecification spec, final ILimitChecker returnLimits) throws ManifoldCFException {
        if (this.commitDone) {
            throw new ManifoldCFException("Commit already done");
        }
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Requested query: [" + query + "]"));
        }
        if (!needResult) {
            cacheKeys = null;
        }
        final QueryDescription[] queryDescriptions = { new QueryDescription(this.databaseName, query, params, queryClass, cacheKeys, maxReturn, spec, returnLimits) };
        final QueryCacheExecutor executor = new QueryCacheExecutor(this, needResult);
        this.cacheManager.findObjectsAndExecute(queryDescriptions, invalidateKeys, executor, this.getTransactionID());
        return executor.getResult();
    }
    
    public int getCurrentTransactionType() {
        if (this.th == null) {
            return 1;
        }
        return this.th.getTransactionType();
    }
    
    public void beginTransaction(final int transactionType) throws ManifoldCFException {
        if (Logging.db.isDebugEnabled()) {
            Logging.db.debug((Object)("Beginning transaction of type " + Integer.toString(transactionType)));
        }
        final String enclosingID = (this.th == null) ? null : this.th.getTransactionID();
        ++this.delayedTransactionDepth;
        this.th = new TransactionHandle(this.context, this.th, transactionType);
        this.cacheManager.startTransaction(this.th.getTransactionID(), enclosingID);
        this.doRollback = false;
        this.commitDone = false;
    }
    
    protected void synchronizeTransactions() throws ManifoldCFException {
        while (this.delayedTransactionDepth > 0) {
            this.internalTransactionBegin();
            --this.delayedTransactionDepth;
        }
    }
    
    protected void internalTransactionBegin() throws ManifoldCFException {
        if (this.connection == null) {
            this.connection = ConnectionFactory.getConnection(this.jdbcUrl, this.jdbcDriverClass, this.databaseName, this.userName, this.password, this.maxDBConnections, this.debug);
            try {
                this.initializeConnection(this.connection.getConnection());
                this.startATransaction();
                return;
            }
            catch (ManifoldCFException e) {
                if (e.getErrorCode() == 2) {
                    this.connection = null;
                    throw e;
                }
                ConnectionFactory.releaseConnection(this.connection);
                this.connection = null;
                throw e;
            }
            catch (Error e2) {
                ConnectionFactory.releaseConnection(this.connection);
                this.connection = null;
                throw e2;
            }
        }
        try {
            this.startATransaction();
        }
        catch (ManifoldCFException e) {
            if (e.getErrorCode() == 2) {
                this.connection = null;
            }
            throw e;
        }
    }
    
    public void performCommit() throws ManifoldCFException {
        if (this.doRollback) {
            return;
        }
        if (this.delayedTransactionDepth == 0) {
            Logging.db.debug((Object)"Committing transaction!");
            this.commitCurrentTransaction();
            this.commitDone = true;
        }
    }
    
    public void signalRollback() {
        this.doRollback = true;
    }
    
    public void endTransaction() throws ManifoldCFException {
        Logging.db.debug((Object)"Ending transaction");
        if (this.th == null) {
            throw new ManifoldCFException("End transaction without begin!", 0);
        }
        final TransactionHandle parentTransaction = this.th.getParent();
        try {
            if (this.delayedTransactionDepth > 0) {
                --this.delayedTransactionDepth;
            }
            else {
                try {
                    if (this.doRollback) {
                        if (this.commitDone) {
                            this.doRollback = false;
                            throw new ManifoldCFException("Cannot roll back an already committed transaction");
                        }
                        Logging.db.debug((Object)"Rolling transaction back!");
                        this.rollbackCurrentTransaction();
                    }
                    else if (!this.commitDone) {
                        Logging.db.debug((Object)"Committing transaction!");
                        this.commitCurrentTransaction();
                    }
                }
                catch (ManifoldCFException e) {
                    if (e.getErrorCode() == 2) {
                        this.connection = null;
                    }
                    throw e;
                }
                finally {
                    if (parentTransaction == null && this.connection != null) {
                        ConnectionFactory.releaseConnection(this.connection);
                        this.connection = null;
                    }
                }
            }
        }
        finally {
            if (this.doRollback) {
                this.cacheManager.rollbackTransaction(this.th.getTransactionID());
            }
            else {
                this.cacheManager.commitTransaction(this.th.getTransactionID());
            }
            this.commitDone = false;
            this.doRollback = false;
            this.th = parentTransaction;
            if (this.th == null) {
                if (this.doRollback) {
                    this.modificationsSet.clear();
                }
                else {
                    this.playbackModifications();
                }
            }
        }
    }
    
    private void playbackModifications() throws ManifoldCFException {
        for (final String tableName : this.modificationsSet.keySet()) {
            final Modifications c = this.modificationsSet.get(tableName);
            this.noteModificationsNoTransactions(tableName, c.getInsertCount(), c.getModifyCount(), c.getDeleteCount());
        }
        this.modificationsSet.clear();
    }
    
    public void noteModifications(final String tableName, final int insertCount, final int modifyCount, final int deleteCount) throws ManifoldCFException {
        if (this.th != null) {
            Modifications c = this.modificationsSet.get(tableName);
            if (c == null) {
                c = new Modifications();
                this.modificationsSet.put(tableName, c);
            }
            c.update(insertCount, modifyCount, deleteCount);
        }
        else {
            this.noteModificationsNoTransactions(tableName, insertCount, modifyCount, deleteCount);
        }
    }
    
    protected void noteModificationsNoTransactions(final String tableName, final int insertCount, final int modifyCount, final int deleteCount) throws ManifoldCFException {
    }
    
    public long getSleepAmt() {
        return (long)(Database.random.nextDouble() * 60000.0 + 500.0);
    }
    
    public void sleepFor(final long amt) throws ManifoldCFException {
        if (amt == 0L) {
            return;
        }
        try {
            ManifoldCF.sleep(amt);
        }
        catch (InterruptedException e) {
            throw new ManifoldCFException("Interrupted", e, 2);
        }
    }
    
    public String constructIndexHintClause(final String tableName, final IndexDescription description) throws ManifoldCFException {
        return "";
    }
    
    public String constructIndexOrderByClause(final String[] fieldNames, final boolean direction) {
        if (fieldNames.length == 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder("ORDER BY ");
        sb.append(fieldNames[0]);
        if (direction) {
            sb.append(" ASC");
        }
        else {
            sb.append(" DESC");
        }
        return sb.toString();
    }
    
    public String constructOffsetLimitClause(final int offset, final int limit) {
        return this.constructOffsetLimitClause(offset, limit, false);
    }
    
    public abstract String constructOffsetLimitClause(final int p0, final int p1, final boolean p2);
    
    public int findConjunctionClauseMax(final ClauseDescription[] otherClauseDescriptions) {
        return this.getMaxInClause();
    }
    
    public abstract int getMaxInClause();
    
    public String buildConjunctionClause(final List outputParameters, final ClauseDescription[] clauseDescriptions) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < clauseDescriptions.length; ++i) {
            final ClauseDescription cd = clauseDescriptions[i];
            if (i > 0) {
                sb.append(" AND ");
            }
            sb.append(cd.getColumnName());
            final String operation = cd.getOperation();
            final List values = cd.getValues();
            final String joinColumn = cd.getJoinColumnName();
            if (values != null) {
                if (values.size() > 1) {
                    sb.append(" IN (");
                    for (int j = 0; j < values.size(); ++j) {
                        if (j > 0) {
                            sb.append(",");
                        }
                        sb.append("?");
                        outputParameters.add(values.get(j));
                    }
                    sb.append(")");
                }
                else {
                    sb.append(operation).append("?");
                    outputParameters.add(values.get(0));
                }
            }
            else if (joinColumn != null) {
                sb.append(operation).append(joinColumn);
            }
            else {
                sb.append(operation);
            }
        }
        return sb.toString();
    }
    
    protected IResultSet executeViaThread(final Connection connection, final String query, final List params, final boolean bResults, final int maxResults, final ResultSpecification spec, final ILimitChecker returnLimit) throws ManifoldCFException {
        if (connection == null) {
            return null;
        }
        final ExecuteQueryThread t = new ExecuteQueryThread(connection, query, params, bResults, maxResults, spec, returnLimit);
        try {
            t.start();
            return t.finishUp();
        }
        catch (InterruptedException e) {
            t.interrupt();
            this.interruptCleanup(connection);
            throw new ManifoldCFException(e.getMessage(), e, 2);
        }
    }
    
    protected void interruptCleanup(final Connection connection) {
        try {
            if (!connection.getAutoCommit()) {
                connection.rollback();
            }
            connection.close();
        }
        catch (Exception ex) {}
    }
    
    protected IResultSet executeUncachedQuery(final String query, final List params, final boolean bResults, final int maxResults, final ResultSpecification spec, final ILimitChecker returnLimit) throws ManifoldCFException {
        if (this.connection != null) {
            try {
                return this.executeViaThread(this.connection.getConnection(), query, params, bResults, maxResults, spec, returnLimit);
            }
            catch (ManifoldCFException e) {
                if (e.getErrorCode() == 2) {
                    this.connection = null;
                }
                throw e;
            }
        }
        WrappedConnection tempConnection = ConnectionFactory.getConnection(this.jdbcUrl, this.jdbcDriverClass, this.databaseName, this.userName, this.password, this.maxDBConnections, this.debug);
        try {
            this.initializeConnection(tempConnection.getConnection());
            return this.executeViaThread(tempConnection.getConnection(), query, params, bResults, maxResults, spec, returnLimit);
        }
        catch (ManifoldCFException e2) {
            if (e2.getErrorCode() == 2) {
                tempConnection = null;
            }
            throw e2;
        }
        finally {
            if (tempConnection != null) {
                ConnectionFactory.releaseConnection(tempConnection);
            }
        }
    }
    
    protected void initializeConnection(final Connection connection) throws ManifoldCFException {
    }
    
    protected IResultSet execute(final Connection connection, final String query, final List params, final boolean bResults, final int maxResults, final ResultSpecification spec, final ILimitChecker returnLimit) throws ManifoldCFException {
        IResultSet rval = null;
        try {
            long queryStartTime = 0L;
            if (Logging.db.isDebugEnabled()) {
                queryStartTime = System.currentTimeMillis();
                Logging.db.debug((Object)("Actual query: [" + query + "]"));
                if (params != null) {
                    for (int i = 0; i < params.size(); ++i) {
                        Logging.db.debug((Object)("  Parameter " + i + ": '" + params.get(i).toString() + "'"));
                    }
                }
            }
            if (params == null) {
                final Statement stmt = connection.createStatement();
                try {
                    stmt.execute(query);
                    final ResultSet rs = stmt.getResultSet();
                    try {
                        rval = this.getData(rs, bResults, maxResults, spec, returnLimit);
                    }
                    finally {
                        if (rs != null) {
                            rs.close();
                        }
                    }
                }
                finally {
                    stmt.close();
                }
            }
            else {
                final PreparedStatement ps = connection.prepareStatement(query);
                try {
                    loadPS(ps, params);
                    if (bResults) {
                        final ResultSet rs = ps.executeQuery();
                        try {
                            rval = this.getData(rs, true, maxResults, spec, returnLimit);
                        }
                        finally {
                            if (rs != null) {
                                rs.close();
                            }
                        }
                    }
                    else {
                        ps.executeUpdate();
                        rval = this.getData(null, false, 0, spec, null);
                    }
                }
                finally {
                    ps.close();
                }
            }
            if (Logging.db.isDebugEnabled()) {
                Logging.db.debug((Object)("Done actual query (" + new Long(System.currentTimeMillis() - queryStartTime).toString() + "ms): [" + query + "]"));
            }
        }
        catch (SQLException e) {
            throw new ManifoldCFException("SQLException doing query" + ((e.getSQLState() != null) ? (" (" + e.getSQLState() + ")") : "") + ": " + e.getMessage(), e, 4);
        }
        finally {
            if (params != null) {
                cleanupParameters(params);
            }
        }
        return rval;
    }
    
    protected IResultSet getData(final ResultSet rs, final boolean bResults, int maxResults, final ResultSpecification spec, final ILimitChecker returnLimit) throws ManifoldCFException {
        final RSet results = new RSet();
        try {
            try {
                if (rs != null) {
                    int colcount = 0;
                    String[] resultCols = null;
                    String[] resultLabels = null;
                    final ResultSetMetaData rsmd = rs.getMetaData();
                    if (rsmd != null) {
                        colcount = rsmd.getColumnCount();
                        resultCols = new String[colcount];
                        resultLabels = new String[colcount];
                        for (int i = 0; i < colcount; ++i) {
                            final String labelName = rsmd.getColumnLabel(i + 1);
                            resultCols[i] = this.mapLookupName(rsmd.getColumnName(i + 1), labelName);
                            resultLabels[i] = this.mapLabelName(labelName);
                        }
                    }
                    if (bResults) {
                        if (colcount == 0) {
                            throw new ManifoldCFException("Empty query, no columns returned", 0);
                        }
                        while (rs.next() && (maxResults == -1 || maxResults > 0) && (returnLimit == null || returnLimit.checkContinue())) {
                            final RRow m = new RRow();
                            for (int j = 0; j < colcount; ++j) {
                                final String key = resultCols[j];
                                final int colnum = this.findColumn(rs, key);
                                Object value = null;
                                if (colnum > -1) {
                                    value = this.getObject(rs, rsmd, colnum, (spec == null) ? 0 : spec.getForm(key.toLowerCase(Locale.ROOT)));
                                }
                                m.put(resultLabels[j], value);
                            }
                            boolean include = true;
                            if (returnLimit != null) {
                                include = returnLimit.checkInclude(m);
                            }
                            if (include) {
                                if (maxResults != -1) {
                                    --maxResults;
                                }
                                results.addRow(m);
                            }
                            else {
                                final Iterator iter = m.getColumns();
                                while (iter.hasNext()) {
                                    final String columnName = iter.next();
                                    final Object colValue = m.getValue(columnName);
                                    if (colValue instanceof PersistentDatabaseObject) {
                                        ((PersistentDatabaseObject)colValue).discard();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (SQLException e) {
                throw new ManifoldCFException("SQLException getting resultset" + ((e.getSQLState() != null) ? (" (" + e.getSQLState() + ")") : "") + ": " + e.getMessage(), e, 4);
            }
        }
        catch (Throwable e2) {
            int k = 0;
            while (k < results.getRowCount()) {
                final IResultRow row = results.getRow(k++);
                final int l = 0;
                final Iterator iter2 = row.getColumns();
                while (iter2.hasNext()) {
                    final String colName = iter2.next();
                    final Object o = row.getValue(colName);
                    if (o instanceof PersistentDatabaseObject) {
                        ((PersistentDatabaseObject)o).discard();
                    }
                }
            }
            if (e2 instanceof ManifoldCFException) {
                throw (ManifoldCFException)e2;
            }
            if (e2 instanceof RuntimeException) {
                throw (RuntimeException)e2;
            }
            if (e2 instanceof Error) {
                throw (Error)e2;
            }
            throw new Error("Unexpected exception caught: " + e2.getMessage(), e2);
        }
        return results;
    }
    
    protected static void loadPS(final PreparedStatement ps, final List data) throws SQLException, ManifoldCFException {
        if (data != null) {
            for (int i = 0; i < data.size(); ++i) {
                final Object x = data.get(i);
                if (x instanceof String) {
                    final String value = (String)x;
                    ps.setString(i + 1, value);
                }
                if (x instanceof BinaryInput) {
                    final BinaryInput value2 = (BinaryInput)x;
                    final long length = value2.getLength();
                    ps.setBinaryStream(i + 1, value2.getStream(), (length == -1L) ? Integer.MAX_VALUE : ((int)length));
                }
                if (x instanceof CharacterInput) {
                    final CharacterInput value3 = (CharacterInput)x;
                    final long length = value3.getCharacterLength();
                    ps.setCharacterStream(i + 1, value3.getStream(), (length == -1L) ? Integer.MAX_VALUE : ((int)length));
                }
                if (x instanceof Date) {
                    ps.setDate(i + 1, new java.sql.Date(((Date)x).getTime()));
                }
                if (x instanceof Long) {
                    ps.setLong(i + 1, (long)x);
                }
                if (x instanceof TimeMarker) {
                    ps.setTimestamp(i + 1, new Timestamp(((TimeMarker)x).longValue()));
                }
                if (x instanceof Double) {
                    ps.setDouble(i + 1, (double)x);
                }
                if (x instanceof Integer) {
                    ps.setInt(i + 1, (int)x);
                }
                if (x instanceof Float) {
                    ps.setFloat(i + 1, (float)x);
                }
            }
        }
    }
    
    protected static void cleanupParameters(final List data) throws ManifoldCFException {
        if (data != null) {
            for (final Object x : data) {
                if (x instanceof PersistentDatabaseObject) {
                    ((PersistentDatabaseObject)x).doneWithStream();
                }
            }
        }
    }
    
    protected int findColumn(final ResultSet rs, final String name) throws ManifoldCFException {
        try {
            return rs.findColumn(name);
        }
        catch (SQLException e2) {
            return -1;
        }
        catch (Exception e) {
            throw new ManifoldCFException("Error finding " + name + " in resultset: " + e.getMessage(), e, 1);
        }
    }
    
    protected Blob getBLOB(final ResultSet rs, final int col) throws ManifoldCFException {
        try {
            return rs.getBlob(col);
        }
        catch (SQLException e) {
            throw new ManifoldCFException("SQLException in getBlob" + ((e.getSQLState() != null) ? (" (" + e.getSQLState() + ")") : "") + ": " + e.getMessage(), e, 4);
        }
        catch (Exception sqle) {
            throw new ManifoldCFException("Error in getBlob", sqle, 1);
        }
    }
    
    protected boolean isBLOB(final ResultSetMetaData rsmd, final int col) throws ManifoldCFException {
        try {
            final int type = rsmd.getColumnType(col);
            return type == 2004;
        }
        catch (SQLException e) {
            throw new ManifoldCFException("SQLException doing isBlob(" + col + ")" + ((e.getSQLState() != null) ? (" (" + e.getSQLState() + ")") : "") + ": " + e.getMessage(), e, 4);
        }
        catch (Exception sqle) {
            throw new ManifoldCFException("Error in isBlob(" + col + "): " + sqle.getMessage(), sqle, 1);
        }
    }
    
    protected boolean isBinary(final ResultSetMetaData rsmd, final int col) throws ManifoldCFException {
        try {
            final int type = rsmd.getColumnType(col);
            return type == -3 || type == -2 || type == -4;
        }
        catch (SQLException e) {
            throw new ManifoldCFException("SQLException doing isBinary(" + col + ")" + ((e.getSQLState() != null) ? (" (" + e.getSQLState() + ")") : "") + ": " + e.getMessage(), e, 4);
        }
        catch (Exception sqle) {
            throw new ManifoldCFException("Error in isBinary(" + col + "): " + sqle.getMessage(), sqle, 1);
        }
    }
    
    protected Object getObject(final ResultSet rs, final ResultSetMetaData rsmd, final int col, final int desiredForm) throws ManifoldCFException {
        Object result = null;
        try {
            try {
                if (this.isBLOB(rsmd, col)) {
                    final Blob blob = this.getBLOB(rs, col);
                    if (blob != null) {
                        result = new TempFileInput(blob.getBinaryStream(), blob.length());
                    }
                }
                else if (this.isBinary(rsmd, col)) {
                    final InputStream is = rs.getBinaryStream(col);
                    if (is != null) {
                        result = new TempFileInput(is);
                    }
                }
                else {
                    final int colType = rsmd.getColumnType(col);
                    Label_0835: {
                        switch (colType) {
                            case 1:
                            case 12: {
                                switch (desiredForm) {
                                    case 0:
                                    case 1: {
                                        final String resultString;
                                        if ((resultString = rs.getString(col)) != null) {
                                            result = resultString;
                                            break Label_0835;
                                        }
                                        break Label_0835;
                                    }
                                    case 2: {
                                        result = new TempFileCharacterInput(rs.getCharacterStream(col));
                                        break Label_0835;
                                    }
                                    default: {
                                        throw new ManifoldCFException("Illegal form requested for column " + Integer.toString(col) + ": " + Integer.toString(desiredForm));
                                    }
                                }
                                break;
                            }
                            case 2005: {
                                switch (desiredForm) {
                                    case 0:
                                    case 1: {
                                        final Clob clob;
                                        if ((clob = rs.getClob(col)) != null) {
                                            result = clob.getSubString(1L, (int)clob.length());
                                            break Label_0835;
                                        }
                                        break Label_0835;
                                    }
                                    case 2: {
                                        result = new TempFileCharacterInput(rs.getCharacterStream(col));
                                        break Label_0835;
                                    }
                                    default: {
                                        throw new ManifoldCFException("Illegal form requested for column " + Integer.toString(col) + ": " + Integer.toString(desiredForm));
                                    }
                                }
                                break;
                            }
                            case -5: {
                                final long l = rs.getLong(col);
                                if (!rs.wasNull()) {
                                    result = new Long(l);
                                    break;
                                }
                                break;
                            }
                            case 4: {
                                final int i = rs.getInt(col);
                                if (!rs.wasNull()) {
                                    result = new Integer(i);
                                    break;
                                }
                                break;
                            }
                            case 5: {
                                final short s = rs.getShort(col);
                                if (!rs.wasNull()) {
                                    result = new Short(s);
                                    break;
                                }
                                break;
                            }
                            case 6:
                            case 7: {
                                final float f = rs.getFloat(col);
                                if (!rs.wasNull()) {
                                    result = new Float(f);
                                    break;
                                }
                                break;
                            }
                            case 8: {
                                final double d = rs.getDouble(col);
                                if (!rs.wasNull()) {
                                    result = new Double(d);
                                    break;
                                }
                                break;
                            }
                            case 91: {
                                final java.sql.Date date;
                                if ((date = rs.getDate(col)) != null) {
                                    result = new Date(date.getTime());
                                    break;
                                }
                                break;
                            }
                            case 93: {
                                final Timestamp timestamp;
                                if ((timestamp = rs.getTimestamp(col)) != null) {
                                    result = new TimeMarker(timestamp.getTime());
                                    break;
                                }
                                break;
                            }
                            case 16: {
                                final boolean b = rs.getBoolean(col);
                                if (!rs.wasNull()) {
                                    result = new Boolean(b);
                                    break;
                                }
                                break;
                            }
                            case 2004: {
                                throw new ManifoldCFException("BLOB is not a string, column = " + col, 0);
                            }
                            default: {
                                switch (desiredForm) {
                                    case 0:
                                    case 1: {
                                        result = rs.getString(col);
                                        break Label_0835;
                                    }
                                    case 2: {
                                        result = new TempFileCharacterInput(rs.getCharacterStream(col));
                                        break Label_0835;
                                    }
                                    default: {
                                        throw new ManifoldCFException("Illegal form requested for column " + Integer.toString(col) + ": " + Integer.toString(desiredForm));
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if (rs.wasNull()) {
                        if (result instanceof CharacterInput) {
                            ((CharacterInput)result).discard();
                        }
                        result = null;
                    }
                }
            }
            catch (SQLException e) {
                throw new ManifoldCFException("SQLException doing getObject()" + ((e.getSQLState() != null) ? (" (" + e.getSQLState() + ")") : "") + ": " + e.getMessage(), e, 4);
            }
        }
        catch (Throwable e2) {
            if (result instanceof PersistentDatabaseObject) {
                ((PersistentDatabaseObject)result).discard();
            }
            if (e2 instanceof ManifoldCFException) {
                throw (ManifoldCFException)e2;
            }
            if (e2 instanceof RuntimeException) {
                throw (RuntimeException)e2;
            }
            if (e2 instanceof Error) {
                throw (Error)e2;
            }
            throw new Error("Unexpected exception caught: " + e2.getMessage(), e2);
        }
        return result;
    }
    
    static {
        Database.random = new Random();
    }
    
    protected static class Modifications
    {
        protected int insertCount;
        protected int modifyCount;
        protected int deleteCount;
        
        public Modifications() {
            this.insertCount = 0;
            this.modifyCount = 0;
            this.deleteCount = 0;
        }
        
        public void update(final int insertCount, final int modifyCount, final int deleteCount) {
            this.insertCount += insertCount;
            this.modifyCount += modifyCount;
            this.deleteCount += deleteCount;
        }
        
        public int getInsertCount() {
            return this.insertCount;
        }
        
        public int getModifyCount() {
            return this.modifyCount;
        }
        
        public int getDeleteCount() {
            return this.deleteCount;
        }
    }
    
    protected class ExecuteQueryThread extends Thread
    {
        protected Connection connection;
        protected String query;
        protected List params;
        protected boolean bResults;
        protected int maxResults;
        protected ResultSpecification spec;
        protected ILimitChecker returnLimit;
        protected Throwable exception;
        protected IResultSet rval;
        
        public ExecuteQueryThread(final Connection connection, final String query, final List params, final boolean bResults, final int maxResults, final ResultSpecification spec, final ILimitChecker returnLimit) {
            this.exception = null;
            this.rval = null;
            this.setDaemon(true);
            this.connection = connection;
            this.query = query;
            this.params = params;
            this.bResults = bResults;
            this.maxResults = maxResults;
            this.spec = spec;
            this.returnLimit = returnLimit;
        }
        
        @Override
        public void run() {
            try {
                this.rval = Database.this.execute(this.connection, this.query, this.params, this.bResults, this.maxResults, this.spec, this.returnLimit);
            }
            catch (Throwable e) {
                this.exception = e;
            }
        }
        
        public IResultSet finishUp() throws ManifoldCFException, InterruptedException {
            this.join();
            final Throwable thr = this.exception;
            if (thr == null) {
                return this.rval;
            }
            if (thr instanceof ManifoldCFException) {
                final ManifoldCFException me = (ManifoldCFException)thr;
                throw new ManifoldCFException("Database exception: " + me.getMessage(), me.getCause(), me.getErrorCode());
            }
            if (thr instanceof Error) {
                throw (Error)thr;
            }
            if (thr instanceof RuntimeException) {
                throw (RuntimeException)thr;
            }
            throw new RuntimeException("Unknown exception: " + thr.getClass().getName() + ": " + thr.getMessage(), thr);
        }
    }
    
    public static class QueryCacheExecutor extends ExecutorBase
    {
        protected Database database;
        protected boolean needResult;
        protected IResultSet resultset;
        
        public QueryCacheExecutor(final Database database, final boolean needResult) {
            this.resultset = null;
            this.database = database;
            this.needResult = needResult;
        }
        
        public IResultSet getResult() {
            return this.resultset;
        }
        
        @Override
        public Object[] create(final ICacheDescription[] objectDescriptions) throws ManifoldCFException {
            final Object[] rval = new Object[objectDescriptions.length];
            for (int i = 0; i < objectDescriptions.length; ++i) {
                this.database.synchronizeTransactions();
                final QueryDescription description = (QueryDescription)objectDescriptions[i];
                final ILimitChecker limit = description.getReturnLimit();
                final ResultSpecification spec = description.getResultSpecification();
                final long startTime = System.currentTimeMillis();
                rval[i] = this.database.executeUncachedQuery(description.getQuery(), description.getParameters(), this.needResult, description.getMaxReturn(), spec, limit);
                final long endTime = System.currentTimeMillis();
                if (endTime - startTime > this.database.maxQueryTime && description.getQuery().length() >= 6 && ("SELECT".equalsIgnoreCase(description.getQuery().substring(0, 6)) || "UPDATE".equalsIgnoreCase(description.getQuery().substring(0, 6)))) {
                    Logging.db.warn((Object)("Found a long-running query (" + new Long(endTime - startTime).toString() + " ms): [" + description.getQuery() + "]"));
                    if (description.getParameters() != null) {
                        for (int j = 0; j < description.getParameters().size(); ++j) {
                            Logging.db.warn((Object)("  Parameter " + j + ": '" + description.getParameters().get(j).toString() + "'"));
                        }
                    }
                    try {
                        this.database.explainQuery(description.getQuery(), description.getParameters());
                    }
                    catch (ManifoldCFException e) {
                        if (e.getErrorCode() == 6 || e.getErrorCode() == 2) {
                            throw e;
                        }
                        Logging.db.warn((Object)("Explain failed with error " + e.getMessage()), (Throwable)e);
                    }
                }
            }
            return rval;
        }
        
        @Override
        public void exists(final ICacheDescription objectDescription, final Object cachedObject) throws ManifoldCFException {
            this.resultset = (IResultSet)cachedObject;
        }
        
        @Override
        public void execute() throws ManifoldCFException {
        }
    }
}
