// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.cachemanager;

import org.apache.manifoldcf.core.interfaces.ICacheExecutor;

public abstract class ExecutorBase implements ICacheExecutor
{
    public static final String _rcsid = "@(#)$Id: ExecutorBase.java 988245 2010-08-23 18:39:35Z kwright $";
}
