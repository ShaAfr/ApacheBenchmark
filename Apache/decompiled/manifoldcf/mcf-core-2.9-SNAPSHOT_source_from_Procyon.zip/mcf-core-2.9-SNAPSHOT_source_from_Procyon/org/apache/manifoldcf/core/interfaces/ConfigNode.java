// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public class ConfigNode extends ConfigurationNode
{
    public static final String _rcsid = "@(#)$Id: ConfigNode.java 988245 2010-08-23 18:39:35Z kwright $";
    
    public ConfigNode(final String type) {
        super(type);
    }
    
    public ConfigNode(final ConfigurationNode source) {
        super(source);
    }
    
    @Override
    protected ConfigurationNode createNewNode() {
        return new ConfigNode(this.type);
    }
    
    @Override
    protected ConfigurationNode createNewNode(final ConfigurationNode source) {
        return new ConfigNode(source);
    }
    
    public ConfigNode duplicate(final boolean readOnly) {
        return (ConfigNode)this.createDuplicate(readOnly);
    }
    
    public ConfigNode getChild(final int index) {
        return (ConfigNode)this.findChild(index);
    }
}
