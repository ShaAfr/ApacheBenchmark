// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IServiceDataAcceptor
{
    public static final String _rcsid = "@(#)$Id$";
    
    boolean acceptServiceData(final String p0, final byte[] p1) throws ManifoldCFException;
}
