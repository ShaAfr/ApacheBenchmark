// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface IShutdownHook
{
    void doCleanup(final IThreadContext p0) throws ManifoldCFException;
}
