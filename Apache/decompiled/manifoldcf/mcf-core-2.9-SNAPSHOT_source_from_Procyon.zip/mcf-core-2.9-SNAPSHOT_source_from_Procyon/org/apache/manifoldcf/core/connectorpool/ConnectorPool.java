// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.connectorpool;

import org.apache.manifoldcf.core.interfaces.IServiceDataAcceptor;
import org.apache.manifoldcf.core.interfaces.ILockManager;
import org.apache.manifoldcf.core.interfaces.IServiceCleanup;
import org.apache.manifoldcf.core.interfaces.LockManagerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Arrays;
import java.lang.reflect.Array;
import org.apache.manifoldcf.core.interfaces.ConfigParams;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.apache.manifoldcf.core.system.ManifoldCF;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import org.apache.manifoldcf.core.interfaces.IThreadContext;
import java.util.HashMap;
import java.util.Random;
import java.util.Map;
import org.apache.manifoldcf.core.interfaces.IConnector;

public abstract class ConnectorPool<T extends IConnector>
{
    public static final String _rcsid = "@(#)$Id$";
    protected static final String targetCalcLockPrefix = "_POOLTARGET_";
    protected final String serviceTypePrefix;
    protected final Map<String, Pool> poolHash;
    protected static final Random randomNumberGenerator;
    
    protected ConnectorPool(final String serviceTypePrefix) {
        this.poolHash = new HashMap<String, Pool>();
        this.serviceTypePrefix = serviceTypePrefix;
    }
    
    protected abstract boolean isInstalled(final IThreadContext p0, final String p1) throws ManifoldCFException;
    
    protected abstract boolean isConnectionNameValid(final IThreadContext p0, final String p1) throws ManifoldCFException;
    
    protected T createConnectorInstance(final IThreadContext threadContext, final String className) throws ManifoldCFException {
        if (!this.isInstalled(threadContext, className)) {
            return null;
        }
        try {
            final Class theClass = ManifoldCF.findClass(className);
            final Class[] argumentClasses = new Class[0];
            final Constructor c = theClass.getConstructor((Class[])argumentClasses);
            final Object[] arguments = new Object[0];
            final Object o = c.newInstance(arguments);
            try {
                return (T)o;
            }
            catch (ClassCastException e8) {
                throw new ManifoldCFException("Class '" + className + "' does not implement IConnector.");
            }
        }
        catch (InvocationTargetException e) {
            final Throwable z = e.getTargetException();
            if (z instanceof Error) {
                throw (Error)z;
            }
            if (z instanceof RuntimeException) {
                throw (RuntimeException)z;
            }
            if (z instanceof ManifoldCFException) {
                throw (ManifoldCFException)z;
            }
            throw new RuntimeException("Unknown exception type: " + z.getClass().getName() + ": " + z.getMessage(), z);
        }
        catch (ClassNotFoundException e9) {
            return null;
        }
        catch (NoSuchMethodException e2) {
            throw new ManifoldCFException("No appropriate constructor for IConnector implementation '" + className + "'.  Need xxx(ConfigParams).", e2);
        }
        catch (SecurityException e3) {
            throw new ManifoldCFException("Protected constructor for IConnector implementation '" + className + "'", e3);
        }
        catch (IllegalAccessException e4) {
            throw new ManifoldCFException("Unavailable constructor for IConnector implementation '" + className + "'", e4);
        }
        catch (IllegalArgumentException e5) {
            throw new ManifoldCFException("Shouldn't happen!!!", e5);
        }
        catch (InstantiationException e6) {
            throw new ManifoldCFException("InstantiationException for IConnector implementation '" + className + "'", e6);
        }
        catch (ExceptionInInitializerError e7) {
            throw new ManifoldCFException("ExceptionInInitializerError for IConnector implementation '" + className + "'", e7);
        }
    }
    
    public T[] grabMultiple(final IThreadContext threadContext, final Class<T> clazz, final String[] orderingKeys, final String[] connectionNames, final String[] classNames, final ConfigParams[] configInfos, final int[] maxPoolSizes) throws ManifoldCFException {
        final T[] rval = (T[])Array.newInstance(clazz, classNames.length);
        final Map<String, Integer> orderMap = new HashMap<String, Integer>();
        for (int i = 0; i < orderingKeys.length; ++i) {
            if (orderMap.get(orderingKeys[i]) != null) {
                throw new ManifoldCFException("Found duplicate order key");
            }
            orderMap.put(orderingKeys[i], new Integer(i));
        }
        Arrays.sort(orderingKeys);
        for (int i = 0; i < orderingKeys.length; ++i) {
            String orderingKey = orderingKeys[i];
            int index = orderMap.get(orderingKey);
            final String connectionName = connectionNames[index];
            final String className = classNames[index];
            final ConfigParams cp = configInfos[index];
            final int maxPoolSize = maxPoolSizes[index];
            try {
                final T connector = this.grab(threadContext, connectionName, className, cp, maxPoolSize);
                rval[index] = connector;
            }
            catch (Throwable e) {
                while (i > 0) {
                    --i;
                    orderingKey = orderingKeys[i];
                    index = orderMap.get(orderingKey);
                    try {
                        this.release(threadContext, connectionName, rval[index]);
                    }
                    catch (ManifoldCFException ex) {}
                }
                if (e instanceof ManifoldCFException) {
                    throw (ManifoldCFException)e;
                }
                if (e instanceof RuntimeException) {
                    throw (RuntimeException)e;
                }
                if (e instanceof Error) {
                    throw (Error)e;
                }
                throw new RuntimeException("Unexpected exception type: " + e.getClass().getName() + ": " + e.getMessage(), e);
            }
        }
        return rval;
    }
    
    public T grab(final IThreadContext threadContext, final String connectionName, final String className, final ConfigParams configInfo, final int maxPoolSize) throws ManifoldCFException {
        T rval;
        do {
            Pool p;
            synchronized (this.poolHash) {
                p = this.poolHash.get(connectionName);
                if (p == null) {
                    p = new Pool(threadContext, maxPoolSize, connectionName);
                    this.poolHash.put(connectionName, p);
                    p.pollAll(threadContext);
                }
                else {
                    p.updateMaximumPoolSize(threadContext, maxPoolSize);
                }
            }
            rval = p.getConnector(threadContext, className, configInfo);
        } while (rval == null);
        return rval;
    }
    
    public void releaseMultiple(final IThreadContext threadContext, final String[] connectionNames, final T[] connectors) throws ManifoldCFException {
        ManifoldCFException currentException = null;
        for (int i = 0; i < connectors.length; ++i) {
            final String connectionName = connectionNames[i];
            final T c = connectors[i];
            try {
                this.release(threadContext, connectionName, c);
            }
            catch (ManifoldCFException e) {
                if (currentException == null) {
                    currentException = e;
                }
            }
        }
        if (currentException != null) {
            throw currentException;
        }
    }
    
    public void release(final IThreadContext threadContext, final String connectionName, final T connector) throws ManifoldCFException {
        if (connector == null) {
            return;
        }
        final Pool p;
        synchronized (this.poolHash) {
            p = this.poolHash.get(connectionName);
        }
        if (p != null) {
            p.releaseConnector(threadContext, connector);
        }
        else {
            connector.setThreadContext(threadContext);
            try {
                connector.disconnect();
            }
            finally {
                connector.clearThreadContext();
            }
        }
    }
    
    public void pollAllConnectors(final IThreadContext threadContext) throws ManifoldCFException {
        synchronized (this.poolHash) {
            final Iterator<String> iter = this.poolHash.keySet().iterator();
            while (iter.hasNext()) {
                final String connectionName = iter.next();
                final Pool p = this.poolHash.get(connectionName);
                if (this.isConnectionNameValid(threadContext, connectionName)) {
                    p.pollAll(threadContext);
                }
                else {
                    p.releaseAll(threadContext);
                    iter.remove();
                }
            }
        }
    }
    
    public void flushUnusedConnectors(final IThreadContext threadContext) throws ManifoldCFException {
        synchronized (this.poolHash) {
            for (final Pool p : this.poolHash.values()) {
                p.flushUnused(threadContext);
            }
        }
    }
    
    public void closeAllConnectors(final IThreadContext threadContext) throws ManifoldCFException {
        synchronized (this.poolHash) {
            final Iterator<Pool> iter = this.poolHash.values().iterator();
            while (iter.hasNext()) {
                final Pool p = iter.next();
                p.releaseAll(threadContext);
                iter.remove();
            }
        }
    }
    
    protected String buildServiceTypeName(final String connectionName) {
        return this.serviceTypePrefix + connectionName;
    }
    
    protected String buildTargetCalcLockName(final String connectionName) {
        return "_POOLTARGET_" + this.serviceTypePrefix + connectionName;
    }
    
    protected static int unpackTarget(final byte[] data) {
        if (data == null || data.length != 8) {
            return 0;
        }
        return (data[0] & 0xFF) + (data[1] << 8 & 0xFF00) + (data[2] << 16 & 0xFF0000) + (data[3] << 24 & 0xFF000000);
    }
    
    protected static int unpackInUse(final byte[] data) {
        if (data == null || data.length != 8) {
            return 0;
        }
        return (data[4] & 0xFF) + (data[5] << 8 & 0xFF00) + (data[6] << 16 & 0xFF0000) + (data[7] << 24 & 0xFF000000);
    }
    
    protected static byte[] pack(final int target, final int inUse) {
        final byte[] rval = { (byte)(target & 0xFF), (byte)(target >> 8 & 0xFF), (byte)(target >> 16 & 0xFF), (byte)(target >> 24 & 0xFF), (byte)(inUse & 0xFF), (byte)(inUse >> 8 & 0xFF), (byte)(inUse >> 16 & 0xFF), (byte)(inUse >> 24 & 0xFF) };
        return rval;
    }
    
    static {
        randomNumberGenerator = new Random();
    }
    
    protected class Pool
    {
        protected boolean isAlive;
        protected int globalMax;
        protected final String serviceTypeName;
        protected final String serviceName;
        protected final String targetCalcLockName;
        protected final List<T> stack;
        protected int numFree;
        protected int localMax;
        protected int localInUse;
        
        public Pool(final IThreadContext threadContext, final int maxCount, final String connectionName) throws ManifoldCFException {
            this.isAlive = true;
            this.stack = new ArrayList<T>();
            this.numFree = 0;
            this.localMax = 0;
            this.localInUse = 0;
            this.globalMax = maxCount;
            this.targetCalcLockName = ConnectorPool.this.buildTargetCalcLockName(connectionName);
            this.serviceTypeName = ConnectorPool.this.buildServiceTypeName(connectionName);
            final ILockManager lockManager = LockManagerFactory.make(threadContext);
            this.serviceName = lockManager.registerServiceBeginServiceActivity(this.serviceTypeName, null, null);
        }
        
        public synchronized void updateMaximumPoolSize(final IThreadContext threadContext, final int maxPoolSize) throws ManifoldCFException {
            this.globalMax = maxPoolSize;
        }
        
        public synchronized T getConnector(final IThreadContext threadContext, final String className, final ConfigParams configParams) throws ManifoldCFException {
            while (this.isAlive && this.numFree <= 0) {
                try {
                    this.wait();
                    continue;
                }
                catch (InterruptedException e) {
                    throw new ManifoldCFException("Interrupted: " + e.getMessage(), e, 2);
                }
                break;
            }
            if (!this.isAlive) {
                return null;
            }
            while (true) {
                if (this.stack.size() == 0) {
                    final T newrc = ConnectorPool.this.createConnectorInstance(threadContext, className);
                    if (newrc == null) {
                        return null;
                    }
                    newrc.connect(configParams);
                    this.stack.add(newrc);
                }
                final T rc = this.stack.remove(this.stack.size() - 1);
                rc.setThreadContext(threadContext);
                if (rc.getClass().getName().equals(className)) {
                    if (rc.getConfiguration().equals(configParams)) {
                        --this.numFree;
                        return rc;
                    }
                }
                try {
                    rc.disconnect();
                }
                finally {
                    rc.clearThreadContext();
                }
            }
        }
        
        public synchronized void releaseConnector(final IThreadContext threadContext, final T connector) throws ManifoldCFException {
            if (connector == null) {
                return;
            }
            connector.clearThreadContext();
            this.stack.add(connector);
            ++this.numFree;
            while (this.stack.size() > 0 && this.stack.size() > this.numFree) {
                int j;
                for (j = 0; j < this.stack.size() && this.stack.get(j).isConnected(); ++j) {}
                T rc;
                if (j == this.stack.size()) {
                    rc = this.stack.remove(this.stack.size() - 1);
                }
                else {
                    rc = this.stack.remove(j);
                }
                rc.setThreadContext(threadContext);
                try {
                    rc.disconnect();
                }
                finally {
                    rc.clearThreadContext();
                }
            }
            this.notifyAll();
        }
        
        public synchronized void pollAll(final IThreadContext threadContext) throws ManifoldCFException {
            final ILockManager lockManager = LockManagerFactory.make(threadContext);
            lockManager.enterWriteLock(this.targetCalcLockName);
            try {
                final SumClass sumClass = new SumClass(this.serviceName);
                lockManager.scanServiceData(this.serviceTypeName, sumClass);
                final int numServices = sumClass.getNumServices();
                if (numServices == 0) {
                    return;
                }
                final int globalTarget = sumClass.getGlobalTarget();
                final int globalInUse = sumClass.getGlobalInUse();
                int maximumTarget = this.globalMax - globalTarget;
                if (maximumTarget > this.globalMax - globalInUse) {
                    maximumTarget = this.globalMax - globalInUse;
                }
                if (maximumTarget < 0) {
                    maximumTarget = 0;
                }
                int fairTarget = this.globalMax / numServices;
                final int remainder = this.globalMax % numServices;
                if (ConnectorPool.randomNumberGenerator.nextInt(numServices) < remainder) {
                    ++fairTarget;
                }
                int localInUse = this.localMax - this.numFree;
                for (final T rc : this.stack) {
                    rc.setThreadContext(threadContext);
                    try {
                        rc.poll();
                        if (!rc.isConnected()) {
                            continue;
                        }
                        ++localInUse;
                    }
                    finally {
                        rc.clearThreadContext();
                    }
                }
                int optimalTarget = this.localMax;
                if (this.localMax > localInUse) {
                    --optimalTarget;
                }
                else {
                    int increment = this.globalMax >> 2;
                    if (increment == 0) {
                        increment = 1;
                    }
                    optimalTarget += increment;
                }
                int target = maximumTarget;
                if (target > fairTarget) {
                    target = fairTarget;
                }
                if (target > optimalTarget) {
                    target = optimalTarget;
                }
                lockManager.updateServiceData(this.serviceTypeName, this.serviceName, ConnectorPool.pack(target, localInUse));
                if (target == this.localMax) {
                    return;
                }
                localInUse = this.localMax - this.numFree;
                this.localMax = target;
                this.numFree = this.localMax - localInUse;
                this.notifyAll();
            }
            finally {
                lockManager.leaveWriteLock(this.targetCalcLockName);
            }
            while (this.stack.size() > 0 && this.stack.size() > this.numFree) {
                int j;
                for (j = 0; j < this.stack.size() && this.stack.get(j).isConnected(); ++j) {}
                T rc2;
                if (j == this.stack.size()) {
                    rc2 = this.stack.remove(this.stack.size() - 1);
                }
                else {
                    rc2 = this.stack.remove(j);
                }
                rc2.setThreadContext(threadContext);
                try {
                    rc2.disconnect();
                }
                finally {
                    rc2.clearThreadContext();
                }
            }
        }
        
        public synchronized void flushUnused(final IThreadContext threadContext) throws ManifoldCFException {
            while (this.stack.size() > 0) {
                final T rc = this.stack.remove(this.stack.size() - 1);
                rc.setThreadContext(threadContext);
                try {
                    rc.disconnect();
                }
                finally {
                    rc.clearThreadContext();
                }
            }
        }
        
        public synchronized void releaseAll(final IThreadContext threadContext) throws ManifoldCFException {
            this.flushUnused(threadContext);
            if (this.isAlive) {
                this.isAlive = false;
                this.notifyAll();
                final ILockManager lockManager = LockManagerFactory.make(threadContext);
                lockManager.endServiceActivity(this.serviceTypeName, this.serviceName);
            }
        }
    }
    
    protected static class SumClass implements IServiceDataAcceptor
    {
        protected final String serviceName;
        protected int numServices;
        protected int globalTargetTally;
        protected int globalInUseTally;
        
        public SumClass(final String serviceName) {
            this.numServices = 0;
            this.globalTargetTally = 0;
            this.globalInUseTally = 0;
            this.serviceName = serviceName;
        }
        
        @Override
        public boolean acceptServiceData(final String serviceName, final byte[] serviceData) throws ManifoldCFException {
            ++this.numServices;
            if (!serviceName.equals(this.serviceName)) {
                this.globalTargetTally += ConnectorPool.unpackTarget(serviceData);
                this.globalInUseTally += ConnectorPool.unpackInUse(serviceData);
            }
            return false;
        }
        
        public int getNumServices() {
            return this.numServices;
        }
        
        public int getGlobalTarget() {
            return this.globalTargetTally;
        }
        
        public int getGlobalInUse() {
            return this.globalInUseTally;
        }
    }
}
