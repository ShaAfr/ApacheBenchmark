// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.lockmanager;

import org.apache.manifoldcf.core.interfaces.LockException;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.util.ArrayList;
import java.util.List;

public class LockGate
{
    protected final List<Long> threadRequests;
    protected final LockObject lockObject;
    protected final Object lockKey;
    protected LockPool lockPool;
    
    public LockGate(final Object lockKey, final LockObject lockObject, final LockPool lockPool) {
        this.threadRequests = new ArrayList<Long>();
        this.lockKey = lockKey;
        this.lockObject = lockObject;
        this.lockPool = lockPool;
    }
    
    public void makeInvalid() {
        synchronized (this) {
            this.lockPool = null;
            this.lockObject.makeInvalid();
        }
    }
    
    protected void waitForPermission(final Long threadID) throws InterruptedException, ExpiredObjectException {
        Label_0025: {
            synchronized (this) {
                this.threadRequests.add(threadID);
                break Label_0025;
            }
            try {
                while (true) {
                    synchronized (this) {
                        if (this.lockPool == null) {
                            throw new ExpiredObjectException("Invalid");
                        }
                        if (this.threadRequests.get(0).equals(threadID)) {
                            return;
                        }
                        this.wait();
                    }
                }
            }
            catch (InterruptedException e) {
                this.freePermission(threadID);
                throw e;
            }
            catch (ExpiredObjectException e2) {
                this.freePermission(threadID);
                throw e2;
            }
            catch (Error e3) {
                this.freePermission(threadID);
                throw e3;
            }
            catch (RuntimeException e4) {
                this.freePermission(threadID);
                throw e4;
            }
        }
    }
    
    protected void freePermission(final Long threadID) {
        synchronized (this) {
            this.threadRequests.remove(threadID);
            this.notifyAll();
        }
    }
    
    public void enterWriteLock(final Long threadID) throws ManifoldCFException, InterruptedException, ExpiredObjectException {
        this.waitForPermission(threadID);
        try {
            this.lockObject.enterWriteLock();
        }
        finally {
            this.freePermission(threadID);
        }
    }
    
    public void enterWriteLockNoWait(final Long threadID) throws ManifoldCFException, LockException, LocalLockException, InterruptedException, ExpiredObjectException {
        this.waitForPermission(threadID);
        try {
            this.lockObject.enterWriteLockNoWait();
        }
        finally {
            this.freePermission(threadID);
        }
    }
    
    public void leaveWriteLock() throws ManifoldCFException, InterruptedException, ExpiredObjectException {
        synchronized (this) {
            if (this.lockObject.leaveWriteLock() && this.threadRequests.size() == 0 && this.lockPool != null) {
                this.lockPool.releaseObject(this.lockKey, this);
            }
        }
    }
    
    public void enterNonExWriteLock(final Long threadID) throws ManifoldCFException, InterruptedException, ExpiredObjectException {
        this.waitForPermission(threadID);
        try {
            this.lockObject.enterNonExWriteLock();
        }
        finally {
            this.freePermission(threadID);
        }
    }
    
    public void enterNonExWriteLockNoWait(final Long threadID) throws ManifoldCFException, LockException, LocalLockException, InterruptedException, ExpiredObjectException {
        this.waitForPermission(threadID);
        try {
            this.lockObject.enterNonExWriteLockNoWait();
        }
        finally {
            this.freePermission(threadID);
        }
    }
    
    public void leaveNonExWriteLock() throws ManifoldCFException, InterruptedException, ExpiredObjectException {
        synchronized (this) {
            if (this.lockObject.leaveNonExWriteLock() && this.threadRequests.size() == 0 && this.lockPool != null) {
                this.lockPool.releaseObject(this.lockKey, this);
            }
        }
    }
    
    public void enterReadLock(final Long threadID) throws ManifoldCFException, InterruptedException, ExpiredObjectException {
        this.waitForPermission(threadID);
        try {
            this.lockObject.enterReadLock();
        }
        finally {
            this.freePermission(threadID);
        }
    }
    
    public void enterReadLockNoWait(final Long threadID) throws ManifoldCFException, LockException, LocalLockException, InterruptedException, ExpiredObjectException {
        this.waitForPermission(threadID);
        try {
            this.lockObject.enterReadLockNoWait();
        }
        finally {
            this.freePermission(threadID);
        }
    }
    
    public void leaveReadLock() throws ManifoldCFException, InterruptedException, ExpiredObjectException {
        synchronized (this) {
            if (this.lockObject.leaveReadLock() && this.threadRequests.size() == 0 && this.lockPool != null) {
                this.lockPool.releaseObject(this.lockKey, this);
            }
        }
    }
}
