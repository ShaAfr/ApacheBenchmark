// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.common;

import java.io.IOException;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;
import javax.xml.transform.Transformer;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Comment;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Text;
import org.w3c.dom.Element;
import java.io.StringWriter;
import org.apache.manifoldcf.core.system.Logging;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.EntityResolver;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.manifoldcf.core.interfaces.ManifoldCFException;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.StringTokenizer;
import java.util.ArrayList;
import org.w3c.dom.Document;

public class XMLDoc
{
    public static final String _rcsid = "@(#)$Id: XMLDoc.java 988245 2010-08-23 18:39:35Z kwright $";
    private static final String _wildchar = "*";
    private static final String _slash = "/";
    private static int _blocksiz;
    private Document _doc;
    
    protected Object getDocument() {
        return this._doc;
    }
    
    protected void setDocument(final Object d) {
        this._doc = (Document)d;
    }
    
    public ArrayList processPath(final String path, final Object o) {
        final ArrayList l = new ArrayList();
        this.processPath(l, path, o);
        return l;
    }
    
    public void processPath(final ArrayList returnList, String path, final Object currentRoot) {
        Object element = currentRoot;
        final StringBuilder bf = new StringBuilder();
        boolean bWild = false;
        final ArrayList working = new ArrayList();
        if (path.endsWith("/")) {
            path += "*";
        }
        final StringTokenizer tokenizer = new StringTokenizer(path, "/", false);
        int depth = 0;
        final int pathDepth = tokenizer.countTokens();
        String attribute = null;
        String value = null;
        while (tokenizer.hasMoreTokens()) {
            ++depth;
            String s = tokenizer.nextToken().trim();
            if (s != null && s.length() > 0) {
                value = (attribute = null);
                s = s.trim();
                String elementName;
                if (s.indexOf(61) > -1) {
                    bWild = true;
                    int i = s.indexOf(32);
                    elementName = s.substring(0, i);
                    s = s.substring(i).trim();
                    i = s.indexOf(61);
                    attribute = s.substring(0, i);
                    value = s.substring(i + 1);
                    bf.append('/').append(elementName).append(attribute);
                    bf.append('=').append(value);
                }
                else {
                    elementName = s;
                    if (elementName.equals("*")) {
                        elementName = null;
                    }
                    else {
                        bf.append("/").append(s);
                    }
                }
                final ArrayList l = this.getElements(element, elementName);
                element = null;
                if (depth == pathDepth) {
                    working.addAll(l);
                }
                else {
                    final int j = this.searchArrayForAttribute(l, 0, attribute, value);
                    if (j != -1) {
                        element = l.get(j);
                    }
                }
                if (element == null) {
                    break;
                }
                continue;
            }
        }
        if (bWild) {
            for (int k = 0; k < working.size(); ++k) {
                final int m = this.searchArrayForAttribute(working, k, attribute, value);
                if (m <= -1) {
                    break;
                }
                returnList.add(working.get(m));
            }
        }
        else {
            returnList.addAll(working);
        }
    }
    
    protected int searchArrayForAttribute(final ArrayList l, int i, final String attribute, final String value) {
        int index = -1;
        while (i < l.size()) {
            final Object element = l.get(i);
            if (attribute == null || attribute.length() == 0) {
                index = i;
                break;
            }
            if (value.equals(this.getValue(element, attribute))) {
                index = i;
                break;
            }
            ++i;
        }
        return index;
    }
    
    public String getXML() throws ManifoldCFException {
        return new String(this.toByteArray(), StandardCharsets.UTF_8);
    }
    
    public String getXMLNoEntityPreamble() throws ManifoldCFException {
        final String initial = this.getXML();
        final int index = initial.indexOf(">");
        return initial.substring(index + 1);
    }
    
    public byte[] toByteArray() throws ManifoldCFException {
        final ByteArrayOutputStream os = new ByteArrayOutputStream(XMLDoc._blocksiz);
        this.dumpOutput(os);
        return os.toByteArray();
    }
    
    public XMLDoc() throws ManifoldCFException {
        this._doc = null;
        try {
            final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            final DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setEntityResolver(new MyEntityResolver());
            this._doc = builder.newDocument();
        }
        catch (Exception e) {
            throw new ManifoldCFException("Error setting up parser: " + e.getMessage(), e);
        }
    }
    
    public XMLDoc(final String data) throws ManifoldCFException {
        this._doc = null;
        final ByteArrayInputStream bis = new ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8));
        this._doc = this.init(bis);
    }
    
    public XMLDoc(final StringBuilder data) throws ManifoldCFException {
        this._doc = null;
        final ByteArrayInputStream bis = new ByteArrayInputStream(data.toString().getBytes(StandardCharsets.UTF_8));
        this._doc = this.init(bis);
    }
    
    public XMLDoc(final InputStream is) throws ManifoldCFException {
        this._doc = null;
        this._doc = this.init(is);
    }
    
    public XMLDoc(final XMLDoc oldDoc, final Object parent) throws ManifoldCFException {
        this._doc = null;
        try {
            final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(false);
            final DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setEntityResolver(new MyEntityResolver());
            this._doc = builder.newDocument();
            NodeList nodes;
            if (parent == null) {
                nodes = oldDoc._doc.getChildNodes();
            }
            else {
                nodes = ((Node)parent).getChildNodes();
            }
            for (int sz = nodes.getLength(), index = 0; index < sz; ++index) {
                final Node node = nodes.item(index);
                if (node.getNodeType() == 1) {
                    this._doc.appendChild(this.duplicateNode(node));
                }
            }
        }
        catch (Exception e) {
            throw new ManifoldCFException("Error setting up parser: " + e.getMessage(), e);
        }
    }
    
    private Document init(final InputStream is) throws ManifoldCFException {
        Document doc = null;
        try {
            final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(false);
            final DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setEntityResolver(new MyEntityResolver());
            doc = builder.parse(is);
        }
        catch (Exception e) {
            if (Logging.misc.isDebugEnabled()) {
                final StringWriter sw = new StringWriter();
                try {
                    is.reset();
                    final byte[] buf = new byte[65536];
                    final int len = is.read(buf);
                    if (len != -1) {
                        sw.append(new String(buf, 0, len, StandardCharsets.UTF_8));
                        if (len == buf.length) {
                            sw.append("...");
                        }
                    }
                }
                catch (Exception ex) {}
                Logging.misc.debug((Object)sw.toString(), (Throwable)e);
            }
            throw new ManifoldCFException("XML parsing error: " + e.getMessage(), e);
        }
        return doc;
    }
    
    public final String getValue(final Object elo, final String a) {
        final Element el = (Element)elo;
        return el.getAttribute(a);
    }
    
    public final String getNodeName(final Object el) {
        String name = null;
        final Node node = (Node)el;
        if (node.getNodeType() == 1) {
            name = node.getNodeName();
        }
        return name;
    }
    
    public final String getData(final Object obj) {
        final Node enode = (Node)obj;
        final StringBuilder data = new StringBuilder();
        final NodeList cdata = enode.getChildNodes();
        for (int sz = cdata.getLength(), j = 0; j < sz; ++j) {
            final Node node = cdata.item(j);
            if (node.getNodeType() == 3) {
                final Text sec = (Text)node;
                sec.normalize();
                data.append(sec.getData().trim());
            }
            else if (node.getNodeType() == 4) {
                final CDATASection sec2 = (CDATASection)node;
                data.append(sec2.getData().trim());
            }
        }
        return data.toString();
    }
    
    public Object getRoot() {
        return this.getRoot(this._doc);
    }
    
    public Object getRoot(final Object obj) {
        final NodeList nodes = ((Document)obj).getChildNodes();
        return nodes.item(0);
    }
    
    private final ArrayList getElements(final Object n) {
        return this.getElements(n, null);
    }
    
    public final ArrayList getAttributes(final Object n) {
        final ArrayList atts = new ArrayList();
        final NamedNodeMap map = ((Node)n).getAttributes();
        for (int i = 0; i < map.getLength(); ++i) {
            final Attr att = (Attr)map.item(i);
            atts.add(att.getName());
        }
        return atts;
    }
    
    public Object getElement(final Object parent, final String tagname) {
        final ArrayList l = this.getElements(parent, tagname);
        if (l.size() < 1) {
            return null;
        }
        return l.get(0);
    }
    
    private final ArrayList getElements(final Object parent, final String tagname) {
        final ArrayList list = new ArrayList();
        final NodeList nodes = (parent == null) ? this._doc.getChildNodes() : ((Node)parent).getChildNodes();
        final int sz = nodes.getLength();
        final ArrayList tags = new ArrayList();
        int tagsz = 0;
        if (tagname != null) {
            final StringTokenizer st = new StringTokenizer(tagname, ",");
            while (st.hasMoreTokens()) {
                tags.add(st.nextToken());
            }
        }
        tagsz = tags.size();
        for (int index = 0; index < sz; ++index) {
            final Node node = nodes.item(index);
            if (node.getNodeType() == 1) {
                final String theTag = node.getNodeName();
                if (tagsz == 0) {
                    list.add(node);
                }
                else {
                    for (int j = 0; j < tagsz; ++j) {
                        if (theTag.equalsIgnoreCase(tags.get(j))) {
                            list.add(node);
                            break;
                        }
                    }
                }
            }
        }
        return list;
    }
    
    public Object createElement(final Object who, final String ename) {
        final Element element = this._doc.createElement(ename);
        if (who == null) {
            this._doc.appendChild(element);
        }
        else {
            ((Element)who).appendChild(element);
        }
        return element;
    }
    
    public void addDocumentElement(final Object where, final XMLDoc oldDoc, final Object parent) {
        NodeList nodes;
        if (parent == null) {
            nodes = oldDoc._doc.getChildNodes();
        }
        else {
            nodes = ((Node)parent).getChildNodes();
        }
        for (int sz = nodes.getLength(), index = 0; index < sz; ++index) {
            final Node node = nodes.item(index);
            if (where == null) {
                this._doc.appendChild(this.duplicateNode(node));
            }
            else {
                ((Element)where).appendChild(this.duplicateNode(node));
            }
        }
    }
    
    public void setAttribute(final Object e, final String sName, final String sValue) {
        ((Element)e).setAttribute(sName, sValue);
    }
    
    public Object createText(final Object who, final String data) {
        final Text element = this._doc.createTextNode(data);
        if (who == null) {
            this._doc.appendChild(element);
        }
        else {
            ((Element)who).appendChild(element);
        }
        return element;
    }
    
    protected Node duplicateNode(final Node node) {
        final int type = node.getNodeType();
        Node rval = null;
        switch (type) {
            case 1: {
                rval = this._doc.createElement(node.getNodeName());
                final NamedNodeMap nmap = node.getAttributes();
                int i = 0;
                while (i < nmap.getLength()) {
                    final Attr attribute = (Attr)nmap.item(i++);
                    ((Element)rval).setAttribute(attribute.getName(), attribute.getValue());
                }
                final NodeList children = node.getChildNodes();
                i = 0;
                while (i < children.getLength()) {
                    rval.appendChild(this.duplicateNode(children.item(i++)));
                }
                break;
            }
            case 3: {
                rval = this._doc.createTextNode(((Text)node).getData());
                break;
            }
            case 4: {
                rval = this._doc.createCDATASection(((CDATASection)node).getNodeValue());
                break;
            }
            case 8: {
                rval = this._doc.createComment(((Comment)node).getNodeValue());
                break;
            }
            default: {
                return null;
            }
        }
        return rval;
    }
    
    private void dumpOutput(final OutputStream os) throws ManifoldCFException {
        try {
            final StreamResult res = new StreamResult(os);
            final TransformerFactory tFactory = TransformerFactory.newInstance();
            final Transformer transformer = tFactory.newTransformer();
            final DOMSource source = new DOMSource(this._doc);
            transformer.transform(source, res);
        }
        catch (Exception e) {
            throw new ManifoldCFException("Error dumping output: " + e.getMessage(), e);
        }
    }
    
    static {
        XMLDoc._blocksiz = 1024;
    }
    
    protected static class MyEntityResolver implements EntityResolver
    {
        @Override
        public InputSource resolveEntity(final String publicId, final String systemId) throws SAXException, IOException {
            return new InputSource(new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-8'?>".getBytes(StandardCharsets.UTF_8)));
        }
    }
}
