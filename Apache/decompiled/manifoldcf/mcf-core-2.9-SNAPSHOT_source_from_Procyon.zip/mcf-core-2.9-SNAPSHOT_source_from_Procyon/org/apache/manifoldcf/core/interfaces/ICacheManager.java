// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.manifoldcf.core.interfaces;

public interface ICacheManager
{
    public static final String _rcsid = "@(#)$Id: ICacheManager.java 988245 2010-08-23 18:39:35Z kwright $";
    
    void findObjectsAndExecute(final ICacheDescription[] p0, final StringSet p1, final ICacheExecutor p2, final String p3) throws ManifoldCFException;
    
    ICacheHandle enterCache(final ICacheDescription[] p0, final StringSet p1, final String p2) throws ManifoldCFException;
    
    ICacheCreateHandle enterCreateSection(final ICacheHandle p0) throws ManifoldCFException;
    
    Object lookupObject(final ICacheCreateHandle p0, final ICacheDescription p1) throws ManifoldCFException;
    
    void saveObject(final ICacheCreateHandle p0, final ICacheDescription p1, final Object p2) throws ManifoldCFException;
    
    void leaveCreateSection(final ICacheCreateHandle p0) throws ManifoldCFException;
    
    void invalidateKeys(final ICacheHandle p0) throws ManifoldCFException;
    
    void leaveCache(final ICacheHandle p0) throws ManifoldCFException;
    
    void startTransaction(final String p0, final String p1) throws ManifoldCFException;
    
    void commitTransaction(final String p0) throws ManifoldCFException;
    
    void rollbackTransaction(final String p0) throws ManifoldCFException;
    
    void expireObjects(final long p0) throws ManifoldCFException;
}
