// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.lang.Bytes;
import java.util.Locale;

public abstract class AbstractResourceStream implements IResourceStream
{
    private static final long serialVersionUID = 1L;
    private Locale locale;
    private String style;
    private String variation;
    
    @Override
    public Locale getLocale() {
        return this.locale;
    }
    
    @Override
    public void setLocale(final Locale locale) {
        this.locale = locale;
    }
    
    @Override
    public String getStyle() {
        return this.style;
    }
    
    @Override
    public String getVariation() {
        return this.variation;
    }
    
    @Override
    public void setStyle(final String style) {
        this.style = style;
    }
    
    @Override
    public void setVariation(final String variation) {
        this.variation = variation;
    }
    
    @Override
    public Bytes length() {
        return null;
    }
    
    @Override
    public String getContentType() {
        return null;
    }
    
    @Override
    public Time lastModifiedTime() {
        return null;
    }
}
