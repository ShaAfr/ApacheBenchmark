// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import org.apache.wicket.util.string.AppendingStringBuffer;
import java.io.Writer;

public class StringBufferWriter extends Writer
{
    private AppendingStringBuffer buffer;
    
    public StringBufferWriter() {
        this.buffer = new AppendingStringBuffer(4096);
    }
    
    public AppendingStringBuffer getStringBuffer() {
        return this.buffer;
    }
    
    public void setStringBuffer(final AppendingStringBuffer buffer) {
        this.buffer = buffer;
    }
    
    public void write(final char ch) {
        this.buffer.append(ch);
    }
    
    @Override
    public void write(final char[] charArray) {
        this.buffer.append(charArray);
    }
    
    @Override
    public void write(final char[] charArray, final int offset, final int length) {
        this.buffer.append(charArray, offset, length);
    }
    
    @Override
    public void write(final String string) {
        this.buffer.append(string);
    }
    
    @Override
    public void write(final String string, final int offset, final int length) {
        this.buffer.append(string.substring(offset, offset + length));
    }
    
    @Override
    public void flush() {
    }
    
    public void reset() {
        this.buffer.setLength(0);
    }
    
    @Override
    public void close() {
    }
}
