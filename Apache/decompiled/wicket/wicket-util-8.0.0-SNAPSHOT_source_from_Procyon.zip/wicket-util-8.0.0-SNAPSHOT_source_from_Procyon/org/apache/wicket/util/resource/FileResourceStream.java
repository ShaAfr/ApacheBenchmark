// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.apache.wicket.util.lang.Bytes;
import org.apache.wicket.util.time.Time;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.net.URLConnection;
import java.io.IOException;
import org.apache.wicket.util.lang.Args;
import java.io.InputStream;
import org.apache.wicket.util.file.File;

public class FileResourceStream extends AbstractResourceStream implements IFixedLocationResourceStream
{
    private static final long serialVersionUID = 1L;
    private final File file;
    private transient InputStream inputStream;
    
    public FileResourceStream(final File file) {
        Args.notNull(file, "file");
        this.file = file;
    }
    
    public FileResourceStream(final java.io.File file) {
        this.file = new File(file);
    }
    
    @Override
    public void close() throws IOException {
        if (this.inputStream != null) {
            this.inputStream.close();
            this.inputStream = null;
        }
    }
    
    @Override
    public String getContentType() {
        String contentType = null;
        if (this.file != null) {
            contentType = URLConnection.getFileNameMap().getContentTypeFor(this.file.getName());
        }
        return contentType;
    }
    
    public File getFile() {
        return this.file;
    }
    
    @Override
    public InputStream getInputStream() throws ResourceStreamNotFoundException {
        if (this.inputStream == null) {
            try {
                this.inputStream = new FileInputStream(this.file);
            }
            catch (FileNotFoundException e) {
                throw new ResourceStreamNotFoundException("Resource " + this.file + " could not be found", e);
            }
        }
        return this.inputStream;
    }
    
    @Override
    public Time lastModifiedTime() {
        if (this.file != null) {
            return this.file.lastModifiedTime();
        }
        return null;
    }
    
    @Override
    public String toString() {
        if (this.file != null) {
            return this.file.toString();
        }
        return "";
    }
    
    @Override
    public Bytes length() {
        if (this.file != null) {
            return Bytes.bytes(this.file.length());
        }
        return null;
    }
    
    @Override
    public String locationAsString() {
        if (this.file != null) {
            return this.file.getAbsolutePath();
        }
        return null;
    }
}
