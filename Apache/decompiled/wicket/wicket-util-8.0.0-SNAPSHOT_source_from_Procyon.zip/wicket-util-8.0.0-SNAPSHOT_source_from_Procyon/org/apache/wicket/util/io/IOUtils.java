// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import org.slf4j.LoggerFactory;
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.OutputStreamWriter;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.Writer;
import java.io.CharArrayWriter;
import java.io.Reader;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.Closeable;
import org.slf4j.Logger;

public final class IOUtils
{
    private static final Logger log;
    private static final int DEFAULT_BUFFER_SIZE = 4096;
    
    public static void close(final Closeable closeable) throws IOException {
        if (closeable != null) {
            closeable.close();
        }
    }
    
    public static void closeQuietly(final Closeable closeable) {
        try {
            close(closeable);
        }
        catch (IOException e) {
            IOUtils.log.debug("closing resource failed: " + e.getMessage(), (Throwable)e);
        }
    }
    
    public static byte[] toByteArray(final InputStream input) throws IOException {
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        copy(input, output);
        return output.toByteArray();
    }
    
    public static byte[] toByteArray(final Reader input) throws IOException {
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        copy(input, output);
        return output.toByteArray();
    }
    
    public static byte[] toByteArray(final Reader input, final String encoding) throws IOException {
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        copy(input, output, encoding);
        return output.toByteArray();
    }
    
    public static char[] toCharArray(final InputStream is) throws IOException {
        final CharArrayWriter output = new CharArrayWriter();
        copy(is, output);
        return output.toCharArray();
    }
    
    public static char[] toCharArray(final InputStream is, final String encoding) throws IOException {
        final CharArrayWriter output = new CharArrayWriter();
        copy(is, output, encoding);
        return output.toCharArray();
    }
    
    public static char[] toCharArray(final Reader input) throws IOException {
        final CharArrayWriter sw = new CharArrayWriter();
        copy(input, sw);
        return sw.toCharArray();
    }
    
    public static String toString(final InputStream input) throws IOException {
        final StringWriter sw = new StringWriter();
        copy(input, sw);
        return sw.toString();
    }
    
    public static String toString(final InputStream input, final String encoding) throws IOException {
        final StringWriter sw = new StringWriter();
        copy(input, sw, encoding);
        return sw.toString();
    }
    
    public static String toString(final Reader input) throws IOException {
        final StringWriter sw = new StringWriter();
        copy(input, sw);
        return sw.toString();
    }
    
    public static void write(final byte[] data, final OutputStream output) throws IOException {
        if (data != null) {
            output.write(data);
        }
    }
    
    public static void write(final byte[] data, final Writer output) throws IOException {
        if (data != null) {
            output.write(new String(data));
        }
    }
    
    public static void write(final byte[] data, final Writer output, final String encoding) throws IOException {
        if (data != null) {
            if (encoding == null) {
                write(data, output);
            }
            else {
                output.write(new String(data, encoding));
            }
        }
    }
    
    public static void write(final char[] data, final Writer output) throws IOException {
        if (data != null) {
            output.write(data);
        }
    }
    
    public static void write(final char[] data, final OutputStream output) throws IOException {
        if (data != null) {
            output.write(new String(data).getBytes());
        }
    }
    
    public static void write(final char[] data, final OutputStream output, final String encoding) throws IOException {
        if (data != null) {
            if (encoding == null) {
                write(data, output);
            }
            else {
                output.write(new String(data).getBytes(encoding));
            }
        }
    }
    
    public static void write(final String data, final Writer output) throws IOException {
        if (data != null) {
            output.write(data);
        }
    }
    
    public static void write(final String data, final OutputStream output) throws IOException {
        if (data != null) {
            output.write(data.getBytes());
        }
    }
    
    public static void write(final String data, final OutputStream output, final String encoding) throws IOException {
        if (data != null) {
            if (encoding == null) {
                write(data, output);
            }
            else {
                output.write(data.getBytes(encoding));
            }
        }
    }
    
    public static void write(final StringBuilder data, final Writer output) throws IOException {
        if (data != null) {
            output.write(data.toString());
        }
    }
    
    public static void write(final StringBuilder data, final OutputStream output) throws IOException {
        if (data != null) {
            output.write(data.toString().getBytes());
        }
    }
    
    public static void write(final StringBuilder data, final OutputStream output, final String encoding) throws IOException {
        if (data != null) {
            if (encoding == null) {
                write(data, output);
            }
            else {
                output.write(data.toString().getBytes(encoding));
            }
        }
    }
    
    public static int copy(final InputStream input, final OutputStream output) throws IOException {
        final byte[] buffer = new byte[4096];
        int count = 0;
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }
    
    public static void copy(final InputStream input, final Writer output) throws IOException {
        final InputStreamReader in = new InputStreamReader(input);
        copy(in, output);
    }
    
    public static void copy(final InputStream input, final Writer output, final String encoding) throws IOException {
        if (encoding == null) {
            copy(input, output);
        }
        else {
            final InputStreamReader in = new InputStreamReader(input, encoding);
            copy(in, output);
        }
    }
    
    public static int copy(final Reader input, final Writer output) throws IOException {
        final char[] buffer = new char[4096];
        int count = 0;
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }
    
    public static void copy(final Reader input, final OutputStream output) throws IOException {
        final OutputStreamWriter out = new OutputStreamWriter(output);
        copy(input, out);
        out.flush();
    }
    
    public static void copy(final Reader input, final OutputStream output, final String encoding) throws IOException {
        if (encoding == null) {
            copy(input, output);
        }
        else {
            final OutputStreamWriter out = new OutputStreamWriter(output, encoding);
            copy(input, out);
            out.flush();
        }
    }
    
    public static boolean contentEquals(InputStream input1, InputStream input2) throws IOException {
        if (!(input1 instanceof BufferedInputStream)) {
            input1 = new BufferedInputStream(input1);
        }
        if (!(input2 instanceof BufferedInputStream)) {
            input2 = new BufferedInputStream(input2);
        }
        for (int ch = input1.read(); -1 != ch; ch = input1.read()) {
            final int ch2 = input2.read();
            if (ch != ch2) {
                return false;
            }
        }
        final int ch2 = input2.read();
        return ch2 == -1;
    }
    
    public static boolean contentEquals(Reader input1, Reader input2) throws IOException {
        if (!(input1 instanceof BufferedReader)) {
            input1 = new BufferedReader(input1);
        }
        if (!(input2 instanceof BufferedReader)) {
            input2 = new BufferedReader(input2);
        }
        for (int ch = input1.read(); -1 != ch; ch = input1.read()) {
            final int ch2 = input2.read();
            if (ch != ch2) {
                return false;
            }
        }
        final int ch2 = input2.read();
        return ch2 == -1;
    }
    
    static {
        log = LoggerFactory.getLogger((Class)IOUtils.class);
    }
}
