// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import java.io.IOException;
import java.io.InputStream;
import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.lang.Bytes;
import java.util.Locale;

public abstract class AbstractResourceStreamWriter implements IResourceStreamWriter
{
    private static final long serialVersionUID = 1L;
    private Locale locale;
    private String variation;
    private String style;
    
    @Override
    public Bytes length() {
        return null;
    }
    
    @Override
    public Locale getLocale() {
        return this.locale;
    }
    
    @Override
    public void setLocale(final Locale locale) {
        this.locale = locale;
    }
    
    @Override
    public Time lastModifiedTime() {
        return Time.now();
    }
    
    @Override
    public final InputStream getInputStream() {
        throw new IllegalStateException("getInputStream() is not used with IResourceStreamWriter");
    }
    
    @Override
    public void close() throws IOException {
    }
    
    @Override
    public String getContentType() {
        return null;
    }
    
    @Override
    public String getStyle() {
        return this.style;
    }
    
    @Override
    public void setStyle(final String style) {
        this.style = style;
    }
    
    @Override
    public String getVariation() {
        return this.variation;
    }
    
    @Override
    public void setVariation(final String variation) {
        this.variation = variation;
    }
}
