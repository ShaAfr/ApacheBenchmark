// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.value;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Iterator;
import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.string.StringValue;
import java.lang.reflect.Array;
import org.apache.wicket.util.time.Duration;
import org.apache.wicket.util.string.StringValueConversionException;
import org.apache.wicket.util.string.IStringIterator;
import org.apache.wicket.util.parse.metapattern.parsers.VariableAssignmentParser;
import org.apache.wicket.util.string.StringList;
import org.apache.wicket.util.parse.metapattern.MetaPattern;
import java.util.Map;
import java.util.LinkedHashMap;

public class ValueMap extends LinkedHashMap<String, Object> implements IValueMap
{
    public static final ValueMap EMPTY_MAP;
    private static final long serialVersionUID = 1L;
    private boolean immutable;
    
    public ValueMap() {
        this.immutable = false;
    }
    
    public ValueMap(final Map<? extends String, ?> map) {
        this.immutable = false;
        super.putAll(map);
    }
    
    public ValueMap(final String keyValuePairs) {
        this(keyValuePairs, ",");
    }
    
    public ValueMap(final String keyValuePairs, final String delimiter) {
        this.immutable = false;
        int start = 0;
        int equalsIndex = keyValuePairs.indexOf(61);
        int delimiterIndex = keyValuePairs.indexOf(delimiter, equalsIndex);
        if (delimiterIndex == -1) {
            delimiterIndex = keyValuePairs.length();
        }
        while (equalsIndex != -1) {
            if (delimiterIndex < keyValuePairs.length()) {
                final int equalsIndex2 = keyValuePairs.indexOf(61, delimiterIndex + 1);
                if (equalsIndex2 != -1) {
                    delimiterIndex = keyValuePairs.lastIndexOf(delimiter, equalsIndex2);
                }
                else {
                    delimiterIndex = keyValuePairs.length();
                }
            }
            final String key = keyValuePairs.substring(start, equalsIndex);
            final String value = keyValuePairs.substring(equalsIndex + 1, delimiterIndex);
            this.add(key, value);
            if (delimiterIndex < keyValuePairs.length()) {
                start = delimiterIndex + 1;
                equalsIndex = keyValuePairs.indexOf(61, start);
                if (equalsIndex == -1) {
                    continue;
                }
                delimiterIndex = keyValuePairs.indexOf(delimiter, equalsIndex);
                if (delimiterIndex != -1) {
                    continue;
                }
                delimiterIndex = keyValuePairs.length();
            }
            else {
                equalsIndex = -1;
            }
        }
    }
    
    public ValueMap(final String keyValuePairs, final String delimiter, final MetaPattern valuePattern) {
        this.immutable = false;
        final StringList pairs = StringList.tokenize(keyValuePairs, delimiter);
        for (final String pair : pairs) {
            final VariableAssignmentParser parser = new VariableAssignmentParser(pair, valuePattern);
            if (!parser.matches()) {
                throw new IllegalArgumentException("Invalid key value list: '" + keyValuePairs + '\'');
            }
            this.put(parser.getKey(), parser.getValue());
        }
    }
    
    @Override
    public final void clear() {
        this.checkMutability();
        super.clear();
    }
    
    @Override
    public final boolean getBoolean(final String key) throws StringValueConversionException {
        return this.getStringValue(key).toBoolean();
    }
    
    @Override
    public final double getDouble(final String key) throws StringValueConversionException {
        return this.getStringValue(key).toDouble();
    }
    
    @Override
    public final double getDouble(final String key, final double defaultValue) {
        return this.getStringValue(key).toDouble(defaultValue);
    }
    
    @Override
    public final Duration getDuration(final String key) throws StringValueConversionException {
        return this.getStringValue(key).toDuration();
    }
    
    @Override
    public final int getInt(final String key) throws StringValueConversionException {
        return this.getStringValue(key).toInt();
    }
    
    @Override
    public final int getInt(final String key, final int defaultValue) {
        return this.getStringValue(key).toInt(defaultValue);
    }
    
    @Override
    public final long getLong(final String key) throws StringValueConversionException {
        return this.getStringValue(key).toLong();
    }
    
    @Override
    public final long getLong(final String key, final long defaultValue) {
        return this.getStringValue(key).toLong(defaultValue);
    }
    
    @Override
    public final String getString(final String key, final String defaultValue) {
        final String value = this.getString(key);
        return (value != null) ? value : defaultValue;
    }
    
    @Override
    public final String getString(final String key) {
        final Object o = ((LinkedHashMap<K, Object>)this).get(key);
        if (o == null) {
            return null;
        }
        if (!o.getClass().isArray() || Array.getLength(o) <= 0) {
            return o.toString();
        }
        final Object arrayValue = Array.get(o, 0);
        if (arrayValue == null) {
            return null;
        }
        return arrayValue.toString();
    }
    
    @Override
    public final CharSequence getCharSequence(final String key) {
        final Object o = ((LinkedHashMap<K, Object>)this).get(key);
        if (o == null) {
            return null;
        }
        if (o.getClass().isArray() && Array.getLength(o) > 0) {
            final Object arrayValue = Array.get(o, 0);
            if (arrayValue == null) {
                return null;
            }
            if (arrayValue instanceof CharSequence) {
                return (CharSequence)arrayValue;
            }
            return arrayValue.toString();
        }
        else {
            if (o instanceof CharSequence) {
                return (CharSequence)o;
            }
            return o.toString();
        }
    }
    
    @Override
    public String[] getStringArray(final String key) {
        final Object o = ((LinkedHashMap<K, Object>)this).get(key);
        if (o == null) {
            return null;
        }
        if (o instanceof String[]) {
            return (String[])o;
        }
        if (o.getClass().isArray()) {
            final int length = Array.getLength(o);
            final String[] array = new String[length];
            for (int i = 0; i < length; ++i) {
                final Object arrayValue = Array.get(o, i);
                if (arrayValue != null) {
                    array[i] = arrayValue.toString();
                }
            }
            return array;
        }
        return new String[] { o.toString() };
    }
    
    @Override
    public StringValue getStringValue(final String key) {
        return StringValue.valueOf(this.getString(key));
    }
    
    @Override
    public final Time getTime(final String key) throws StringValueConversionException {
        return this.getStringValue(key).toTime();
    }
    
    @Override
    public final boolean isImmutable() {
        return this.immutable;
    }
    
    @Override
    public final IValueMap makeImmutable() {
        this.immutable = true;
        return this;
    }
    
    @Override
    public Object put(final String key, final Object value) {
        this.checkMutability();
        return super.put(key, value);
    }
    
    public final Object add(final String key, final String value) {
        this.checkMutability();
        final Object o = ((LinkedHashMap<K, Object>)this).get(key);
        if (o == null) {
            return this.put(key, value);
        }
        if (o.getClass().isArray()) {
            final int length = Array.getLength(o);
            final String[] destArray = new String[length + 1];
            for (int i = 0; i < length; ++i) {
                final Object arrayValue = Array.get(o, i);
                if (arrayValue != null) {
                    destArray[i] = arrayValue.toString();
                }
            }
            destArray[length] = value;
            return this.put(key, destArray);
        }
        return this.put(key, new String[] { o.toString(), value });
    }
    
    @Override
    public void putAll(final Map<? extends String, ?> map) {
        this.checkMutability();
        super.putAll(map);
    }
    
    @Override
    public Object remove(final Object key) {
        this.checkMutability();
        return super.remove(key);
    }
    
    @Override
    public String getKey(final String key) {
        for (final String other : ((LinkedHashMap<String, V>)this).keySet()) {
            if (other.equalsIgnoreCase(key)) {
                return other;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        final StringBuilder buffer = new StringBuilder();
        boolean first = true;
        for (final Map.Entry<String, Object> entry : this.entrySet()) {
            if (!first) {
                buffer.append(' ');
            }
            first = false;
            buffer.append(entry.getKey());
            buffer.append(" = \"");
            final Object value = entry.getValue();
            if (value == null) {
                buffer.append("null");
            }
            else if (value.getClass().isArray()) {
                buffer.append(Arrays.asList((Object[])value));
            }
            else {
                buffer.append(value);
            }
            buffer.append('\"');
        }
        return buffer.toString();
    }
    
    private void checkMutability() {
        if (this.immutable) {
            throw new UnsupportedOperationException("Map is immutable");
        }
    }
    
    @Override
    public Boolean getAsBoolean(final String key) {
        if (!this.containsKey(key)) {
            return null;
        }
        try {
            return this.getBoolean(key);
        }
        catch (StringValueConversionException ignored) {
            return null;
        }
    }
    
    @Override
    public boolean getAsBoolean(final String key, final boolean defaultValue) {
        if (!this.containsKey(key)) {
            return defaultValue;
        }
        try {
            return this.getBoolean(key);
        }
        catch (StringValueConversionException ignored) {
            return defaultValue;
        }
    }
    
    @Override
    public Integer getAsInteger(final String key) {
        if (!this.containsKey(key)) {
            return null;
        }
        try {
            return this.getInt(key);
        }
        catch (StringValueConversionException ignored) {
            return null;
        }
    }
    
    @Override
    public int getAsInteger(final String key, final int defaultValue) {
        return this.getInt(key, defaultValue);
    }
    
    @Override
    public Long getAsLong(final String key) {
        if (!this.containsKey(key)) {
            return null;
        }
        try {
            return this.getLong(key);
        }
        catch (StringValueConversionException ignored) {
            return null;
        }
    }
    
    @Override
    public long getAsLong(final String key, final long defaultValue) {
        return this.getLong(key, defaultValue);
    }
    
    @Override
    public Double getAsDouble(final String key) {
        if (!this.containsKey(key)) {
            return null;
        }
        try {
            return this.getDouble(key);
        }
        catch (StringValueConversionException ignored) {
            return null;
        }
    }
    
    @Override
    public double getAsDouble(final String key, final double defaultValue) {
        return this.getDouble(key, defaultValue);
    }
    
    @Override
    public Duration getAsDuration(final String key) {
        return this.getAsDuration(key, null);
    }
    
    @Override
    public Duration getAsDuration(final String key, final Duration defaultValue) {
        if (!this.containsKey(key)) {
            return defaultValue;
        }
        try {
            return this.getDuration(key);
        }
        catch (StringValueConversionException ignored) {
            return defaultValue;
        }
    }
    
    @Override
    public Time getAsTime(final String key) {
        return this.getAsTime(key, null);
    }
    
    @Override
    public Time getAsTime(final String key, final Time defaultValue) {
        if (!this.containsKey(key)) {
            return defaultValue;
        }
        try {
            return this.getTime(key);
        }
        catch (StringValueConversionException ignored) {
            return defaultValue;
        }
    }
    
    @Override
    public <T extends Enum<T>> T getAsEnum(final String key, final Class<T> eClass) {
        return this.getEnumImpl(key, eClass, (T)null);
    }
    
    @Override
    public <T extends Enum<T>> T getAsEnum(final String key, final T defaultValue) {
        if (defaultValue == null) {
            throw new IllegalArgumentException("Default value cannot be null");
        }
        return this.getEnumImpl(key, defaultValue.getClass(), defaultValue);
    }
    
    @Override
    public <T extends Enum<T>> T getAsEnum(final String key, final Class<T> eClass, final T defaultValue) {
        return (T)this.getEnumImpl(key, eClass, (Enum)defaultValue);
    }
    
    private <T extends Enum<T>> T getEnumImpl(final String key, final Class<?> eClass, final T defaultValue) {
        if (eClass == null) {
            throw new IllegalArgumentException("eClass value cannot be null");
        }
        final String value = this.getString(key);
        if (value == null) {
            return defaultValue;
        }
        Method valueOf = null;
        try {
            valueOf = eClass.getMethod("valueOf", String.class);
        }
        catch (NoSuchMethodException e) {
            throw new RuntimeException("Could not find method valueOf(String s) for " + eClass.getName(), e);
        }
        try {
            return (T)valueOf.invoke(eClass, value);
        }
        catch (IllegalAccessException e2) {
            throw new RuntimeException("Could not invoke method valueOf(String s) on " + eClass.getName(), e2);
        }
        catch (InvocationTargetException e3) {
            if (e3.getCause() instanceof IllegalArgumentException) {
                return defaultValue;
            }
            throw new RuntimeException(e3);
        }
    }
    
    static {
        (EMPTY_MAP = new ValueMap()).makeImmutable();
    }
}
