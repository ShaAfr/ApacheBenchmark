// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util;

import java.util.function.Function;

@Deprecated
public interface IContextProvider<T, C> extends Function<C, T>
{
    T get(final C p0);
    
    default T apply(final C context) {
        return this.get(context);
    }
}
