// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.util.Date;
import java.text.DateFormat;
import java.util.Locale;
import java.sql.Time;

public class SqlTimeConverter extends AbstractDateConverter<Time>
{
    private static final long serialVersionUID = 1L;
    
    @Override
    protected Time createDateLike(final long date) {
        return new Time(date);
    }
    
    @Override
    public DateFormat getDateFormat(Locale locale) {
        if (locale == null) {
            locale = Locale.getDefault(Locale.Category.FORMAT);
        }
        return (DateFormat)DateFormat.getTimeInstance(3, locale).clone();
    }
    
    @Override
    protected Class<Time> getTargetType() {
        return Time.class;
    }
}
