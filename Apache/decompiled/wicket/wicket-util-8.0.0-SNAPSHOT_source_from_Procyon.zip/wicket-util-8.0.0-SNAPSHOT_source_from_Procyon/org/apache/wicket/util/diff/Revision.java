// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Revision extends ToString
{
    List<Delta> deltas_;
    
    public Revision() {
        this.deltas_ = new LinkedList<Delta>();
    }
    
    public synchronized void addDelta(final Delta delta) {
        if (delta == null) {
            throw new IllegalArgumentException("new delta is null");
        }
        this.deltas_.add(delta);
    }
    
    public synchronized void insertDelta(final Delta delta) {
        if (delta == null) {
            throw new IllegalArgumentException("new delta is null");
        }
        this.deltas_.add(0, delta);
    }
    
    public Delta getDelta(final int i) {
        return this.deltas_.get(i);
    }
    
    public int size() {
        return this.deltas_.size();
    }
    
    public Object[] patch(final Object[] src) throws PatchFailedException {
        final List<Object> target = new ArrayList<Object>(Arrays.asList(src));
        this.applyTo(target);
        return target.toArray();
    }
    
    public synchronized void applyTo(final List<Object> target) throws PatchFailedException {
        final ListIterator<Delta> i = this.deltas_.listIterator(this.deltas_.size());
        while (i.hasPrevious()) {
            final Delta delta = i.previous();
            delta.patch(target);
        }
    }
    
    @Override
    public synchronized void toString(final StringBuilder s) {
        for (final Delta delta : this.deltas_) {
            delta.toString(s);
        }
    }
    
    public synchronized void toRCSString(final StringBuilder s, final String EOL) {
        for (final Delta deltas : this.deltas_) {
            deltas.toRCSString(s, EOL);
        }
    }
    
    public void toRCSString(final StringBuilder s) {
        this.toRCSString(s, Diff.NL);
    }
    
    public String toRCSString(final String EOL) {
        final StringBuilder s = new StringBuilder();
        this.toRCSString(s, EOL);
        return s.toString();
    }
    
    public String toRCSString() {
        return this.toRCSString(Diff.NL);
    }
    
    public void accept(final RevisionVisitor visitor) {
        visitor.visit(this);
        for (final Delta delta : this.deltas_) {
            delta.accept(visitor);
        }
    }
}
