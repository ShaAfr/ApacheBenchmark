// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

public class NoCryptFactory implements ICryptFactory
{
    private static final ICrypt crypt;
    
    @Override
    public ICrypt newCrypt() {
        return NoCryptFactory.crypt;
    }
    
    static {
        crypt = new NoCrypt();
    }
}
