// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.thread;

import org.slf4j.LoggerFactory;
import org.apache.wicket.util.time.Duration;
import org.apache.wicket.util.time.Time;
import org.slf4j.Logger;

public final class Task
{
    private boolean isDaemon;
    private boolean isStarted;
    private Logger log;
    private final String name;
    private Time startTime;
    private boolean stop;
    private Thread thread;
    
    public Task(final String name) {
        this.isDaemon = true;
        this.isStarted = false;
        this.log = null;
        this.startTime = Time.now();
        this.name = name;
    }
    
    public final synchronized void run(final Duration frequency, final ICode code) {
        if (!this.isStarted) {
            final Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    Task.this.startTime.fromNow().sleep();
                    final Logger log = Task.this.getLog();
                    try {
                        while (!Task.this.stop) {
                            final Time startOfPeriod = Time.now();
                            if (log.isTraceEnabled()) {
                                log.trace("Run the job: '{}'", (Object)code);
                            }
                            try {
                                code.run(Task.this.getLog());
                            }
                            catch (Exception e) {
                                log.error("Unhandled exception thrown by user code in task " + Task.this.name, (Throwable)e);
                            }
                            if (log.isTraceEnabled()) {
                                log.trace("Finished with job: '{}'", (Object)code);
                            }
                            startOfPeriod.add(frequency).fromNow().sleep();
                        }
                    }
                    catch (Exception x) {
                        log.error("Task '{}' terminated", (Object)Task.this.name, (Object)x);
                    }
                    finally {
                        Task.this.isStarted = false;
                    }
                }
            };
            (this.thread = new Thread(runnable, this.name + " Task")).setDaemon(this.isDaemon);
            this.thread.start();
            this.isStarted = true;
            return;
        }
        throw new IllegalStateException("Attempt to start task that has already been started");
    }
    
    public synchronized void setDaemon(final boolean daemon) {
        if (this.isStarted) {
            throw new IllegalStateException("Attempt to set daemon state of a task that has already been started");
        }
        this.isDaemon = daemon;
    }
    
    public synchronized void setLog(final Logger log) {
        this.log = log;
    }
    
    public synchronized void setStartTime(final Time startTime) {
        if (this.isStarted) {
            throw new IllegalStateException("Attempt to set start time of task that has already been started");
        }
        this.startTime = startTime;
    }
    
    @Override
    public String toString() {
        return "[name=" + this.name + ", startTime=" + this.startTime + ", isDaemon=" + this.isDaemon + ", isStarted=" + this.isStarted + ", codeListener=" + this.log + "]";
    }
    
    protected synchronized Logger getLog() {
        if (this.log == null) {
            this.log = LoggerFactory.getLogger((Class)Task.class);
        }
        return this.log;
    }
    
    public void stop() {
        this.stop = true;
    }
    
    public void interrupt() {
        this.stop();
        if (this.thread != null) {
            this.thread.interrupt();
        }
    }
    
    public void setPriority(int prio) {
        if (prio < 1) {
            prio = 1;
        }
        else if (prio > 10) {
            prio = 10;
        }
        this.thread.setPriority(prio);
    }
    
    public int getPriority() {
        return this.thread.getPriority();
    }
}
