// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util;

import org.apache.wicket.util.io.IClusterable;
import java.util.function.Supplier;

public abstract class LazyInitializer<T> implements Supplier<T>, IClusterable
{
    private static final long serialVersionUID = 1L;
    private transient volatile T instance;
    
    public LazyInitializer() {
        this.instance = null;
    }
    
    @Override
    public T get() {
        if (this.instance == null) {
            synchronized (this) {
                if (this.instance == null) {
                    this.instance = this.createInstance();
                }
            }
        }
        return this.instance;
    }
    
    protected abstract T createInstance();
}
