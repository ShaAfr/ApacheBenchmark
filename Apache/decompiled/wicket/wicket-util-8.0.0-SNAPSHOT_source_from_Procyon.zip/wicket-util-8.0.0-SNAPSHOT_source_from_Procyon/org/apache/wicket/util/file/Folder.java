// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import java.io.FileFilter;
import java.util.List;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import org.apache.wicket.util.lang.Bytes;
import java.io.IOException;
import java.net.URI;

public class Folder extends File
{
    private static final long serialVersionUID = 1L;
    
    public Folder(final Folder parent, final String child) {
        super(parent, child);
    }
    
    public Folder(final java.io.File file) {
        this(file.getPath());
    }
    
    public Folder(final String pathname) {
        super(pathname);
    }
    
    public Folder(final String parent, final String child) {
        super(parent, child);
    }
    
    public Folder(final URI uri) {
        super(uri);
    }
    
    public void ensureExists() throws IOException {
        if (!this.exists() && !this.mkdirs()) {
            throw new IOException("Unable to create folder " + this);
        }
    }
    
    public Folder folder(final String name) {
        return new Folder(this, name);
    }
    
    public Bytes freeDiskSpace() {
        return Bytes.bytes(super.getFreeSpace());
    }
    
    public File[] getFiles() {
        return this.getFiles(FileFilter.ALL_FILES);
    }
    
    public File[] getNestedFiles() {
        return this.getNestedFiles(FileFilter.ALL_FILES);
    }
    
    public File[] getNestedFiles(final FileFilter filter) {
        final List<File> files = new ArrayList<File>();
        files.addAll(Arrays.asList(this.getFiles(filter)));
        final Folder[] folders2;
        final Folder[] folders = folders2 = this.getFolders();
        for (final Folder folder : folders2) {
            files.addAll(Arrays.asList(folder.getNestedFiles(filter)));
        }
        return files.toArray(new File[files.size()]);
    }
    
    public File[] getFiles(final FileFilter filter) {
        final java.io.File[] files = this.listFiles(new java.io.FileFilter() {
            @Override
            public boolean accept(final java.io.File file) {
                return file.isFile() && filter.accept(new File(file));
            }
        });
        if (files != null) {
            final File[] wicketFiles = new File[files.length];
            for (int i = 0; i < files.length; ++i) {
                wicketFiles[i] = new File(files[i]);
            }
            return wicketFiles;
        }
        return new File[0];
    }
    
    public Folder[] getFolders() {
        return this.getFolders(new FolderFilter() {
            @Override
            public boolean accept(final Folder folder) {
                final String name = folder.getName();
                return !name.equals(".") && !name.equals("..");
            }
        });
    }
    
    public Folder[] getFolders(final FolderFilter filter) {
        final java.io.File[] files = this.listFiles(new java.io.FileFilter() {
            @Override
            public boolean accept(final java.io.File file) {
                return file.isDirectory() && filter.accept(new Folder(file.getPath()));
            }
        });
        if (files != null) {
            final Folder[] wicketFolders = new Folder[files.length];
            for (int i = 0; i < files.length; ++i) {
                wicketFolders[i] = new Folder(files[i]);
            }
            return wicketFolders;
        }
        return new Folder[0];
    }
    
    @Override
    public boolean remove() {
        return this.remove(this);
    }
    
    public boolean removeFiles() {
        final File[] files = this.getFiles();
        boolean success = true;
        for (final File file : files) {
            success = (file.remove() && success);
        }
        return success;
    }
    
    private boolean remove(final Folder folder) {
        final Folder[] folders = this.getFolders();
        boolean success = true;
        for (final Folder subfolder : folders) {
            success = (subfolder.remove() && success);
        }
        success = (this.removeFiles() && success);
        return folder.delete() && success;
    }
    
    public interface FileFilter
    {
        public static final FileFilter ALL_FILES = new FileFilter() {
            @Override
            public boolean accept(final File file) {
                return true;
            }
        };
        
        boolean accept(final File p0);
    }
    
    public interface FolderFilter
    {
        boolean accept(final Folder p0);
    }
}
