// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.visit;

import java.util.Collections;
import java.util.Iterator;
import org.apache.wicket.util.lang.Args;

public class Visits
{
    private Visits() {
    }
    
    public static <S, R> R visit(final Iterable<? super S> container, final IVisitor<S, R> visitor) {
        return visitChildren(new SingletonIterable<Object>((Object)container), visitor, IVisitFilter.ANY);
    }
    
    public static <S, R> R visit(final Iterable<? super S> container, final IVisitor<S, R> visitor, final IVisitFilter filter) {
        return (R)visitChildren(new SingletonIterable<Object>(container), (IVisitor<Object, Object>)visitor, filter);
    }
    
    public static <S, R> R visitChildren(final Iterable<? super S> container, final IVisitor<S, R> visitor, final IVisitFilter filter) {
        final Visit<R> visit = new Visit<R>();
        visitChildren(container, visitor, filter, visit);
        return visit.getResult();
    }
    
    private static <S, R> void visitChildren(final Iterable<? super S> container, final IVisitor<S, R> visitor, final IVisitFilter filter, final Visit<R> visit) {
        Args.notNull(visitor, "visitor");
        for (final Object child : container) {
            if (filter.visitObject(child)) {
                final Visit<R> childTraversal = new Visit<R>();
                final S s = (S)child;
                visitor.component(s, childTraversal);
                if (childTraversal.isStopped()) {
                    visit.stop(childTraversal.getResult());
                    return;
                }
                if (childTraversal.isDontGoDeeper()) {
                    continue;
                }
            }
            if (!visit.isDontGoDeeper() && child instanceof Iterable && filter.visitChildren(child)) {
                visitChildren((Iterable<? super Object>)child, (IVisitor<Object, Object>)visitor, filter, (Visit<Object>)visit);
                if (visit.isStopped()) {
                    return;
                }
                continue;
            }
        }
    }
    
    public static <S, R> R visitChildren(final Iterable<? super S> container, final IVisitor<S, R> visitor) {
        return visitChildren(container, visitor, IVisitFilter.ANY);
    }
    
    public static <S, R> R visitPostOrder(final S root, final IVisitor<S, R> visitor) {
        return visitPostOrder(root, visitor, IVisitFilter.ANY);
    }
    
    public static <S, R> R visitPostOrder(final Object root, final IVisitor<S, R> visitor, final IVisitFilter filter) {
        Args.notNull(visitor, "visitor");
        final Visit<R> visit = new Visit<R>();
        visitPostOrderHelper(root, visitor, filter, visit);
        return visit.getResult();
    }
    
    private static <S, R> void visitPostOrderHelper(final Object component, final IVisitor<S, R> visitor, final IVisitFilter filter, final Visit<R> visit) {
        if (component instanceof Iterable) {
            final Iterable<?> container = (Iterable<?>)component;
            if (filter.visitChildren(container)) {
                final Visit<R> childTraversal = new Visit<R>();
                for (final Object child : (Iterable)component) {
                    visitPostOrderHelper(child, (IVisitor<Object, Object>)visitor, filter, (Visit<Object>)childTraversal);
                    if (childTraversal.isStopped()) {
                        visit.stop(childTraversal.getResult());
                        return;
                    }
                }
            }
        }
        if (filter.visitObject(component)) {
            visitor.component((S)component, visit);
        }
    }
    
    private static class SingletonIterable<T> implements Iterable<T>
    {
        private final T singleton;
        
        public SingletonIterable(final T singleton) {
            this.singleton = singleton;
        }
        
        @Override
        public Iterator<T> iterator() {
            return Collections.singleton(this.singleton).iterator();
        }
    }
}
