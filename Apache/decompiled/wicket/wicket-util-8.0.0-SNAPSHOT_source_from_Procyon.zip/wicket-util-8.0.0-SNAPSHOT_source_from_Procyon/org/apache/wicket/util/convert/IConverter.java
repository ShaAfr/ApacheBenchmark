// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert;

import java.util.Locale;
import org.apache.wicket.util.io.IClusterable;

public interface IConverter<C> extends IClusterable
{
    C convertToObject(final String p0, final Locale p1) throws ConversionException;
    
    String convertToString(final C p0, final Locale p1);
}
