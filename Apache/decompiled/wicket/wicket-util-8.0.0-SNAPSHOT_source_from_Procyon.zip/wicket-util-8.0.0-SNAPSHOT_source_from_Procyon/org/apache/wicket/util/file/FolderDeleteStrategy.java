// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import java.io.IOException;
import java.io.File;
import org.apache.commons.io.FileDeleteStrategy;

public class FolderDeleteStrategy extends FileDeleteStrategy
{
    protected FolderDeleteStrategy() {
        super("folder");
    }
    
    public boolean deleteQuietly(final File folder) {
        if (folder == null || folder.isFile()) {
            return false;
        }
        final File[] files = folder.listFiles();
        if (files != null) {
            for (final File file : files) {
                if (file.isDirectory()) {
                    this.deleteQuietly(file);
                }
                else {
                    super.deleteQuietly(file);
                }
            }
        }
        return super.deleteQuietly(folder);
    }
    
    public void delete(final File folder) throws IOException {
        if (folder == null || folder.isFile()) {
            return;
        }
        final File[] files = folder.listFiles();
        if (files != null) {
            for (final File file : files) {
                super.delete(file);
            }
        }
    }
}
