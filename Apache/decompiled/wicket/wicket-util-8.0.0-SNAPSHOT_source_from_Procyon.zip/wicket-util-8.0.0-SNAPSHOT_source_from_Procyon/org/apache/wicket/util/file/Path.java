// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import java.io.IOException;
import org.apache.wicket.util.resource.FileResourceStream;
import org.apache.wicket.util.resource.IResourceStream;

public class Path implements IResourceFinder
{
    private final Folder folder;
    
    public Path(final String folder) {
        this(new Folder(folder));
    }
    
    public Path(final Folder folder) {
        if (!folder.exists()) {
            throw new IllegalArgumentException("Folder " + folder + " does not exist");
        }
        this.folder = folder;
    }
    
    @Override
    public IResourceStream find(final Class<?> clazz, final String pathname) {
        final File file = new File(this.folder, pathname);
        if (file.exists()) {
            return new FileResourceStream(file);
        }
        return null;
    }
    
    @Override
    public String toString() {
        try {
            return "[Path: folder = " + this.folder.getCanonicalPath() + "]";
        }
        catch (IOException e) {
            return "[Path: exception while inspecting folder]";
        }
    }
}
