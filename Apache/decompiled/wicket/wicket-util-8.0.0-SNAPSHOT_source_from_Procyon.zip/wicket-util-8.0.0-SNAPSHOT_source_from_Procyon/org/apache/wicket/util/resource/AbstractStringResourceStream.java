// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.apache.wicket.util.string.Strings;
import org.apache.wicket.util.lang.Bytes;
import java.io.UnsupportedEncodingException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.io.Reader;
import java.io.Closeable;
import org.apache.wicket.util.io.IOUtils;
import java.io.IOException;
import org.apache.wicket.util.io.Streams;
import java.io.InputStreamReader;
import org.apache.wicket.util.time.Time;

public abstract class AbstractStringResourceStream extends AbstractResourceStream implements IStringResourceStream
{
    private static final long serialVersionUID = 1L;
    public static final String DEFAULT_CONTENT_TYPE = "text";
    private String charsetName;
    private final String contentType;
    private Time lastModified;
    
    public AbstractStringResourceStream() {
        this("text");
    }
    
    public AbstractStringResourceStream(final String contentType) {
        this.lastModified = null;
        this.contentType = contentType;
        this.lastModified = Time.now();
    }
    
    @Override
    public String asString() {
        Reader reader = null;
        try {
            if (this.charsetName == null) {
                reader = new InputStreamReader(this.getInputStream());
            }
            else {
                reader = new InputStreamReader(this.getInputStream(), this.getCharset());
            }
            return Streams.readString(reader);
        }
        catch (IOException e) {
            throw new RuntimeException("Unable to read resource as String", e);
        }
        catch (ResourceStreamNotFoundException e2) {
            throw new RuntimeException("Unable to read resource as String", e2);
        }
        finally {
            IOUtils.closeQuietly(reader);
            IOUtils.closeQuietly(this);
        }
    }
    
    protected Charset getCharset() {
        return (this.charsetName != null) ? Charset.forName(this.charsetName) : null;
    }
    
    @Override
    public void setCharset(final Charset charset) {
        this.charsetName = ((charset != null) ? charset.name() : null);
    }
    
    @Override
    public void close() throws IOException {
    }
    
    @Override
    public String getContentType() {
        return this.contentType;
    }
    
    @Override
    public InputStream getInputStream() throws ResourceStreamNotFoundException {
        if (this.getCharset() != null) {
            try {
                final byte[] bytes = this.getString().getBytes(this.getCharset().name());
                return new ByteArrayInputStream(bytes);
            }
            catch (UnsupportedEncodingException e) {
                throw new ResourceStreamNotFoundException("Could not encode resource", e);
            }
        }
        final byte[] bytes = this.getString().getBytes();
        return new ByteArrayInputStream(bytes);
    }
    
    @Override
    public Time lastModifiedTime() {
        return this.lastModified;
    }
    
    public void setLastModified(final Time lastModified) {
        this.lastModified = lastModified;
    }
    
    protected abstract String getString();
    
    @Override
    public final Bytes length() {
        final int lengthInBytes = Strings.lengthInBytes(this.getString(), this.getCharset());
        return Bytes.bytes(lengthInBytes);
    }
}
