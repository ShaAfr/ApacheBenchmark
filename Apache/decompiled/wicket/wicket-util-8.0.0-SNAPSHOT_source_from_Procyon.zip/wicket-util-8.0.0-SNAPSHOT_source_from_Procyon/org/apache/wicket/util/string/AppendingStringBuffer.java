// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public final class AppendingStringBuffer implements Serializable, CharSequence
{
    private static final long serialVersionUID = 1L;
    private static final AppendingStringBuffer NULL;
    private static final StringBuilder SB_NULL;
    private static final StringBuffer SBF_NULL;
    private char[] value;
    private int count;
    
    public AppendingStringBuffer() {
        this(16);
    }
    
    public AppendingStringBuffer(final int length) {
        this.value = new char[length];
    }
    
    public AppendingStringBuffer(final CharSequence str) {
        this(str.length() + 16);
        this.append(str);
    }
    
    @Override
    public int length() {
        return this.count;
    }
    
    public int capacity() {
        return this.value.length;
    }
    
    public void ensureCapacity(final int minimumCapacity) {
        if (minimumCapacity > this.value.length) {
            this.expandCapacity(minimumCapacity);
        }
    }
    
    private void expandCapacity(final int minimumCapacity) {
        int newCapacity = (this.value.length + 1) * 2;
        if (newCapacity < 0) {
            newCapacity = Integer.MAX_VALUE;
        }
        else if (minimumCapacity > newCapacity) {
            newCapacity = minimumCapacity;
        }
        final char[] newValue = new char[newCapacity];
        System.arraycopy(this.value, 0, newValue, 0, this.count);
        this.value = newValue;
    }
    
    public void setLength(final int newLength) {
        if (newLength < 0) {
            throw new StringIndexOutOfBoundsException(newLength);
        }
        if (newLength > this.value.length) {
            this.expandCapacity(newLength);
        }
        if (this.count < newLength) {
            while (this.count < newLength) {
                this.value[this.count] = '\0';
                ++this.count;
            }
        }
        else {
            this.count = newLength;
        }
    }
    
    @Override
    public char charAt(final int index) {
        if (index < 0 || index >= this.count) {
            throw new StringIndexOutOfBoundsException(index);
        }
        return this.value[index];
    }
    
    public void getChars(final int srcBegin, final int srcEnd, final char[] dst, final int dstBegin) {
        if (srcBegin < 0) {
            throw new StringIndexOutOfBoundsException(srcBegin);
        }
        if (srcEnd < 0 || srcEnd > this.count) {
            throw new StringIndexOutOfBoundsException(srcEnd);
        }
        if (srcBegin > srcEnd) {
            throw new StringIndexOutOfBoundsException("srcBegin > srcEnd");
        }
        System.arraycopy(this.value, srcBegin, dst, dstBegin, srcEnd - srcBegin);
    }
    
    public void setCharAt(final int index, final char ch) {
        if (index < 0 || index >= this.count) {
            throw new StringIndexOutOfBoundsException(index);
        }
        this.value[index] = ch;
    }
    
    public AppendingStringBuffer append(final Object obj) {
        if (obj instanceof AppendingStringBuffer) {
            return this.append((AppendingStringBuffer)obj);
        }
        if (obj instanceof StringBuilder) {
            return this.append((StringBuilder)obj);
        }
        if (obj instanceof StringBuffer) {
            return this.append(obj.toString());
        }
        return this.append(String.valueOf(obj));
    }
    
    public AppendingStringBuffer append(String str) {
        if (str == null) {
            str = String.valueOf(str);
        }
        final int len = str.length();
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        str.getChars(0, len, this.value, this.count);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer append(AppendingStringBuffer sb) {
        if (sb == null) {
            sb = AppendingStringBuffer.NULL;
        }
        final int len = sb.length();
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        sb.getChars(0, len, this.value, this.count);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer append(StringBuilder sb) {
        if (sb == null) {
            sb = AppendingStringBuffer.SB_NULL;
        }
        final int len = sb.length();
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        sb.getChars(0, len, this.value, this.count);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer append(final char[] str) {
        final int len = str.length;
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        System.arraycopy(str, 0, this.value, this.count, len);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer append(final char[] str, final int offset, final int len) {
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        System.arraycopy(str, offset, this.value, this.count, len);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer append(final boolean b) {
        if (b) {
            final int newcount = this.count + 4;
            if (newcount > this.value.length) {
                this.expandCapacity(newcount);
            }
            this.value[this.count++] = 't';
            this.value[this.count++] = 'r';
            this.value[this.count++] = 'u';
            this.value[this.count++] = 'e';
        }
        else {
            final int newcount = this.count + 5;
            if (newcount > this.value.length) {
                this.expandCapacity(newcount);
            }
            this.value[this.count++] = 'f';
            this.value[this.count++] = 'a';
            this.value[this.count++] = 'l';
            this.value[this.count++] = 's';
            this.value[this.count++] = 'e';
        }
        return this;
    }
    
    public AppendingStringBuffer append(final char c) {
        final int newcount = this.count + 1;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        this.value[this.count++] = c;
        return this;
    }
    
    public AppendingStringBuffer append(final int i) {
        return this.append(String.valueOf(i));
    }
    
    public AppendingStringBuffer append(final long l) {
        return this.append(String.valueOf(l));
    }
    
    public AppendingStringBuffer append(final float f) {
        return this.append(String.valueOf(f));
    }
    
    public AppendingStringBuffer append(final double d) {
        return this.append(String.valueOf(d));
    }
    
    public AppendingStringBuffer delete(final int start, int end) {
        if (start < 0) {
            throw new StringIndexOutOfBoundsException(start);
        }
        if (end > this.count) {
            end = this.count;
        }
        if (start > end) {
            throw new StringIndexOutOfBoundsException();
        }
        final int len = end - start;
        if (len > 0) {
            System.arraycopy(this.value, start + len, this.value, start, this.count - end);
            this.count -= len;
        }
        return this;
    }
    
    public AppendingStringBuffer deleteCharAt(final int index) {
        if (index < 0 || index >= this.count) {
            throw new StringIndexOutOfBoundsException();
        }
        System.arraycopy(this.value, index + 1, this.value, index, this.count - index - 1);
        --this.count;
        return this;
    }
    
    public AppendingStringBuffer replace(final int start, int end, final String str) {
        if (start < 0) {
            throw new StringIndexOutOfBoundsException(start);
        }
        if (end > this.count) {
            end = this.count;
        }
        if (start > end) {
            throw new StringIndexOutOfBoundsException();
        }
        final int len = str.length();
        final int newCount = this.count + len - (end - start);
        if (newCount > this.value.length) {
            this.expandCapacity(newCount);
        }
        System.arraycopy(this.value, end, this.value, start + len, this.count - end);
        str.getChars(0, len, this.value, start);
        this.count = newCount;
        return this;
    }
    
    public String substring(final int start) {
        return this.substring(start, this.count);
    }
    
    @Override
    public CharSequence subSequence(final int start, final int end) {
        return this.substring(start, end);
    }
    
    public String substring(final int start, final int end) {
        if (start < 0) {
            throw new StringIndexOutOfBoundsException(start);
        }
        if (end > this.count) {
            throw new StringIndexOutOfBoundsException(end);
        }
        if (start > end) {
            throw new StringIndexOutOfBoundsException(end - start);
        }
        return new String(this.value, start, end - start);
    }
    
    public AppendingStringBuffer insert(final int index, final char[] str, final int offset, final int len) {
        if (index < 0 || index > this.count) {
            throw new StringIndexOutOfBoundsException();
        }
        if (offset < 0 || offset + len < 0 || offset + len > str.length) {
            throw new StringIndexOutOfBoundsException(offset);
        }
        if (len < 0) {
            throw new StringIndexOutOfBoundsException(len);
        }
        final int newCount = this.count + len;
        if (newCount > this.value.length) {
            this.expandCapacity(newCount);
        }
        System.arraycopy(this.value, index, this.value, index + len, this.count - index);
        System.arraycopy(str, offset, this.value, index, len);
        this.count = newCount;
        return this;
    }
    
    public AppendingStringBuffer insert(final int offset, final Object obj) {
        if (obj instanceof AppendingStringBuffer) {
            final AppendingStringBuffer asb = (AppendingStringBuffer)obj;
            return this.insert(offset, asb.value, 0, asb.count);
        }
        if (obj instanceof StringBuffer) {
            return this.insert(offset, (StringBuffer)obj);
        }
        if (obj instanceof StringBuilder) {
            return this.insert(offset, (StringBuilder)obj);
        }
        return this.insert(offset, String.valueOf(obj));
    }
    
    public AppendingStringBuffer insert(final int offset, String str) {
        if (offset < 0 || offset > this.count) {
            throw new StringIndexOutOfBoundsException();
        }
        if (str == null) {
            str = String.valueOf(str);
        }
        final int len = str.length();
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        System.arraycopy(this.value, offset, this.value, offset + len, this.count - offset);
        str.getChars(0, len, this.value, offset);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer insert(final int offset, StringBuilder str) {
        if (offset < 0 || offset > this.count) {
            throw new StringIndexOutOfBoundsException();
        }
        if (str == null) {
            str = AppendingStringBuffer.SB_NULL;
        }
        final int len = str.length();
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        System.arraycopy(this.value, offset, this.value, offset + len, this.count - offset);
        str.getChars(0, len, this.value, offset);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer insert(final int offset, StringBuffer str) {
        if (offset < 0 || offset > this.count) {
            throw new StringIndexOutOfBoundsException();
        }
        if (str == null) {
            str = AppendingStringBuffer.SBF_NULL;
        }
        final int len = str.length();
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        System.arraycopy(this.value, offset, this.value, offset + len, this.count - offset);
        str.getChars(0, len, this.value, offset);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer insert(final int offset, final char[] str) {
        if (offset < 0 || offset > this.count) {
            throw new StringIndexOutOfBoundsException();
        }
        final int len = str.length;
        final int newcount = this.count + len;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        System.arraycopy(this.value, offset, this.value, offset + len, this.count - offset);
        System.arraycopy(str, 0, this.value, offset, len);
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer insert(final int offset, final boolean b) {
        return this.insert(offset, String.valueOf(b));
    }
    
    public AppendingStringBuffer insert(final int offset, final char c) {
        final int newcount = this.count + 1;
        if (newcount > this.value.length) {
            this.expandCapacity(newcount);
        }
        System.arraycopy(this.value, offset, this.value, offset + 1, this.count - offset);
        this.value[offset] = c;
        this.count = newcount;
        return this;
    }
    
    public AppendingStringBuffer insert(final int offset, final int i) {
        return this.insert(offset, String.valueOf(i));
    }
    
    public AppendingStringBuffer insert(final int offset, final long l) {
        return this.insert(offset, String.valueOf(l));
    }
    
    public AppendingStringBuffer insert(final int offset, final float f) {
        return this.insert(offset, String.valueOf(f));
    }
    
    public AppendingStringBuffer insert(final int offset, final double d) {
        return this.insert(offset, String.valueOf(d));
    }
    
    public int indexOf(final String str) {
        return this.indexOf(str, 0);
    }
    
    public int indexOf(final String str, final int fromIndex) {
        return indexOf(this.value, 0, this.count, str.toCharArray(), 0, str.length(), fromIndex);
    }
    
    static int indexOf(final char[] source, final int sourceOffset, final int sourceCount, final char[] target, final int targetOffset, final int targetCount, int fromIndex) {
        if (fromIndex >= sourceCount) {
            return (targetCount == 0) ? sourceCount : -1;
        }
        if (fromIndex < 0) {
            fromIndex = 0;
        }
        if (targetCount == 0) {
            return fromIndex;
        }
        final char first = target[targetOffset];
        int i = sourceOffset + fromIndex;
        final int max = sourceOffset + (sourceCount - targetCount);
    Label_0053:
        while (true) {
            if (i <= max && source[i] != first) {
                ++i;
            }
            else {
                if (i > max) {
                    return -1;
                }
                int j = i + 1;
                final int end = j + targetCount - 1;
                int k = targetOffset + 1;
                while (j < end) {
                    if (source[j++] != target[k++]) {
                        ++i;
                        continue Label_0053;
                    }
                }
                return i - sourceOffset;
            }
        }
    }
    
    public int lastIndexOf(final String str) {
        return this.lastIndexOf(str, this.count);
    }
    
    public int lastIndexOf(final String str, final int fromIndex) {
        return lastIndexOf(this.value, 0, this.count, str.toCharArray(), 0, str.length(), fromIndex);
    }
    
    static int lastIndexOf(final char[] source, final int sourceOffset, final int sourceCount, final char[] target, final int targetOffset, final int targetCount, int fromIndex) {
        final int rightIndex = sourceCount - targetCount;
        if (fromIndex < 0) {
            return -1;
        }
        if (fromIndex > rightIndex) {
            fromIndex = rightIndex;
        }
        if (targetCount == 0) {
            return fromIndex;
        }
        final int strLastIndex = targetOffset + targetCount - 1;
        final char strLastChar = target[strLastIndex];
        final int min = sourceOffset + targetCount - 1;
        int i = min + fromIndex;
    Label_0062:
        while (true) {
            if (i >= min && source[i] != strLastChar) {
                --i;
            }
            else {
                if (i < min) {
                    return -1;
                }
                int j = i - 1;
                final int start = j - (targetCount - 1);
                int k = strLastIndex - 1;
                while (j > start) {
                    if (source[j--] != target[k--]) {
                        --i;
                        continue Label_0062;
                    }
                }
                return start - sourceOffset + 1;
            }
        }
    }
    
    public boolean startsWith(final CharSequence prefix, final int toffset) {
        final char[] ta = this.value;
        int to = toffset;
        int po = 0;
        int pc = prefix.length();
        if (toffset < 0 || toffset > this.count - pc) {
            return false;
        }
        while (--pc >= 0) {
            if (ta[to++] != prefix.charAt(po++)) {
                return false;
            }
        }
        return true;
    }
    
    public boolean startsWith(final CharSequence prefix) {
        return this.startsWith(prefix, 0);
    }
    
    public boolean endsWith(final CharSequence suffix) {
        return this.startsWith(suffix, this.count - suffix.length());
    }
    
    @Override
    public String toString() {
        return new String(this.value, 0, this.count);
    }
    
    public final char[] getValue() {
        return this.value;
    }
    
    private void readObject(final ObjectInputStream s) throws IOException, ClassNotFoundException {
        s.defaultReadObject();
        this.value = this.value.clone();
    }
    
    @Override
    public boolean equals(final Object anObject) {
        if (this == anObject) {
            return true;
        }
        if (anObject instanceof AppendingStringBuffer) {
            final AppendingStringBuffer anotherString = (AppendingStringBuffer)anObject;
            int n = this.count;
            if (n == anotherString.count) {
                final char[] v1 = this.value;
                final char[] v2 = anotherString.value;
                int i = 0;
                while (n-- != 0) {
                    if (v1[i] != v2[i++]) {
                        return false;
                    }
                }
                return true;
            }
        }
        else if (anObject instanceof CharSequence) {
            final CharSequence sequence = (CharSequence)anObject;
            int n = this.count;
            if (sequence.length() == this.count) {
                final char[] v1 = this.value;
                int j = 0;
                while (n-- != 0) {
                    if (v1[j] != sequence.charAt(j++)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        int h = 0;
        if (h == 0) {
            int off = 0;
            final char[] val = this.value;
            for (int len = this.count, i = 0; i < len; ++i) {
                h = 31 * h + val[off++];
            }
        }
        return h;
    }
    
    public void clear() {
        this.count = 0;
    }
    
    static {
        NULL = new AppendingStringBuffer("null");
        SB_NULL = new StringBuilder("null");
        SBF_NULL = new StringBuffer("null");
    }
}
