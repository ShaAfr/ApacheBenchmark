// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.EmptyStackException;
import java.util.Collection;
import java.util.ArrayList;

public class ArrayListStack<T> extends ArrayList<T>
{
    private static final long serialVersionUID = 1L;
    
    public ArrayListStack(final int initialCapacity) {
        super(initialCapacity);
    }
    
    public ArrayListStack() {
        this(10);
    }
    
    public ArrayListStack(final Collection<T> collection) {
        super(collection);
    }
    
    public final void push(final T item) {
        this.add(item);
    }
    
    public final T pop() {
        final T top = this.peek();
        this.remove(this.size() - 1);
        return top;
    }
    
    public final T peek() {
        final int size = this.size();
        if (size == 0) {
            throw new EmptyStackException();
        }
        return this.get(size - 1);
    }
    
    public final boolean empty() {
        return this.size() == 0;
    }
    
    public final int search(final T o) {
        final int i = this.lastIndexOf(o);
        if (i >= 0) {
            return this.size() - i;
        }
        return -1;
    }
}
