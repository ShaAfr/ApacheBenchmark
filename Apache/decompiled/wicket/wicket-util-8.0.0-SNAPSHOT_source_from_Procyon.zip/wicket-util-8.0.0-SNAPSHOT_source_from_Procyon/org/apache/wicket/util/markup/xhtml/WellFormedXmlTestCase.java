// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.markup.xhtml;

import org.xml.sax.InputSource;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.SAXParseException;
import javax.xml.parsers.DocumentBuilder;
import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import org.junit.Test;
import java.io.File;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import java.io.FileFilter;
import javax.xml.parsers.DocumentBuilderFactory;

public class WellFormedXmlTestCase
{
    private DocumentBuilderFactory factory;
    private static final FileFilter fileFilter;
    private static final ErrorHandler errorHandler;
    private static final EntityResolver entityResolver;
    
    @Test
    public void markupFiles() {
        (this.factory = DocumentBuilderFactory.newInstance()).setNamespaceAware(true);
        final File root = new File("").getAbsoluteFile();
        this.processDirectory(root);
    }
    
    private void processDirectory(final File dir) {
        for (final File f : dir.listFiles(WellFormedXmlTestCase.fileFilter)) {
            if (f.isDirectory()) {
                this.processDirectory(f);
            }
            else {
                this.processFile(f);
            }
        }
    }
    
    private void processFile(final File file) {
        DocumentBuilder builder;
        try {
            builder = this.factory.newDocumentBuilder();
        }
        catch (ParserConfigurationException e) {
            throw new RuntimeException("Configuration exception while parsing xml markup.", e);
        }
        builder.setEntityResolver(WellFormedXmlTestCase.entityResolver);
        builder.setErrorHandler(WellFormedXmlTestCase.errorHandler);
        try {
            builder.parse(file);
        }
        catch (SAXException e2) {
            throw new RuntimeException("Parsing xml sax failed, file: " + file, e2);
        }
        catch (IOException e3) {
            throw new RuntimeException("Parsing xml io failed, file: " + file, e3);
        }
    }
    
    static {
        fileFilter = new FileFilter() {
            @Override
            public boolean accept(final File pathname) {
                final String path = pathname.getAbsolutePath().replace('\\', '/');
                return !path.contains("/src/test/") && !path.contains("/target/") && !"package.html".equals(pathname.getName()) && (pathname.isDirectory() || pathname.getName().endsWith(".html"));
            }
        };
        errorHandler = new ErrorHandler() {
            @Override
            public void warning(final SAXParseException exception) throws SAXException {
                throw exception;
            }
            
            @Override
            public void error(final SAXParseException exception) throws SAXException {
                throw exception;
            }
            
            @Override
            public void fatalError(final SAXParseException exception) throws SAXException {
                throw exception;
            }
        };
        entityResolver = new EntityResolver() {
            private final Map<String, String> systemIdToUri;
            
            {
                (this.systemIdToUri = new HashMap<String, String>()).put("http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd", "xhtml1-transitional.dtd");
                this.systemIdToUri.put("http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd", "xhtml1-strict.dtd");
                this.systemIdToUri.put("http://www.w3.org/TR/html4/loose.dtd", "xhtml1-transitional.dtd");
                this.systemIdToUri.put("http://www.w3.org/TR/html4/strict.dtd", "xhtml1-strict.dtd");
            }
            
            @Override
            public InputSource resolveEntity(final String publicId, final String systemId) throws SAXException, IOException {
                final String uri = this.systemIdToUri.get(systemId);
                if (uri != null) {
                    return new InputSource(WellFormedXmlTestCase.class.getResource(uri).toString());
                }
                return null;
            }
        };
    }
}
