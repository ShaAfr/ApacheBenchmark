// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.text.DateFormat;
import java.text.Format;
import org.apache.wicket.util.string.Strings;
import java.util.Locale;
import java.util.Date;

public abstract class AbstractDateConverter<D extends Date> extends AbstractConverter<D>
{
    private static final long serialVersionUID = 1L;
    
    protected abstract D createDateLike(final long p0);
    
    @Override
    public D convertToObject(final String value, final Locale locale) {
        if (Strings.isEmpty(value)) {
            return null;
        }
        final DateFormat format = this.getDateFormat(locale);
        final Date date = this.parse(format, value, locale);
        return this.createDateLike(date.getTime());
    }
    
    @Override
    public String convertToString(final D value, final Locale locale) {
        if (value == null) {
            return null;
        }
        final DateFormat dateFormat = this.getDateFormat(locale);
        if (dateFormat != null) {
            return dateFormat.format(value);
        }
        return value.toString();
    }
    
    public DateFormat getDateFormat(Locale locale) {
        if (locale == null) {
            locale = Locale.getDefault(Locale.Category.FORMAT);
        }
        return (DateFormat)DateFormat.getDateInstance(3, locale).clone();
    }
}
