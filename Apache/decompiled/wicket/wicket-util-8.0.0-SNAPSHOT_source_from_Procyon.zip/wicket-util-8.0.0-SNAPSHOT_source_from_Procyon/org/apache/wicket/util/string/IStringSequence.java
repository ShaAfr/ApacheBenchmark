// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

public interface IStringSequence
{
    String get(final int p0) throws IndexOutOfBoundsException;
    
    IStringIterator iterator();
    
    int size();
}
