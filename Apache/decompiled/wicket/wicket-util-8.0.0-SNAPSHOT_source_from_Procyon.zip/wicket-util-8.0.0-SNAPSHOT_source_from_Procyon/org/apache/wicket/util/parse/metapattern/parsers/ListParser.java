// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern.parsers;

import java.util.ArrayList;
import java.util.List;
import org.apache.wicket.util.parse.metapattern.MetaPattern;
import org.apache.wicket.util.parse.metapattern.Group;

public class ListParser extends MetaPatternParser
{
    private final Group entryGroup;
    private final MetaPattern separatorPattern;
    private final List<String> values;
    
    public ListParser(final MetaPattern entryPattern, final MetaPattern separatorPattern, final CharSequence input) {
        super(input);
        this.values = new ArrayList<String>();
        this.entryGroup = new Group(entryPattern);
        this.separatorPattern = separatorPattern;
    }
    
    @Override
    public final boolean matches() {
        if (this.advance(this.entryGroup)) {
            final String value = this.entryGroup.get(this.matcher());
            this.values.add(value);
            while (this.advance(this.separatorPattern) && this.advance(this.entryGroup)) {
                this.values.add(this.entryGroup.get(this.matcher()));
            }
            return true;
        }
        return false;
    }
    
    public final List<String> getValues() {
        return this.values;
    }
}
