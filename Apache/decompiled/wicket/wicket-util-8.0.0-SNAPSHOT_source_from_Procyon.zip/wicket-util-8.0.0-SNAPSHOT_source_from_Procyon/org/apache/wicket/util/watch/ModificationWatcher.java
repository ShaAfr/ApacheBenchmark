// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.watch;

import org.apache.wicket.util.listener.ChangeListenerSet;
import org.slf4j.LoggerFactory;
import java.util.Set;
import java.util.Iterator;
import org.apache.wicket.util.thread.ICode;
import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.listener.IChangeListener;
import org.apache.wicket.util.time.Duration;
import org.apache.wicket.util.lang.Generics;
import org.apache.wicket.util.thread.Task;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;

public class ModificationWatcher implements IModificationWatcher
{
    private static final Logger log;
    private final ConcurrentHashMap<IModifiable, Entry> modifiableToEntry;
    private Task task;
    
    public ModificationWatcher() {
        this.modifiableToEntry = Generics.newConcurrentHashMap();
    }
    
    public ModificationWatcher(final Duration pollFrequency) {
        this.modifiableToEntry = Generics.newConcurrentHashMap();
        this.start(pollFrequency);
    }
    
    @Override
    public final boolean add(final IModifiable modifiable, final IChangeListener<IModifiable> listener) {
        final Entry entry = this.modifiableToEntry.get(modifiable);
        if (entry == null) {
            final Time lastModifiedTime = modifiable.lastModifiedTime();
            if (lastModifiedTime != null) {
                final Entry newEntry = new Entry();
                newEntry.modifiable = modifiable;
                newEntry.lastModifiedTime = lastModifiedTime;
                newEntry.listeners.add(listener);
                this.modifiableToEntry.putIfAbsent(modifiable, newEntry);
            }
            else {
                ModificationWatcher.log.info("Cannot track modifications to resource '{}'", (Object)modifiable);
            }
            return true;
        }
        return !entry.listeners.add(listener);
    }
    
    @Override
    public IModifiable remove(final IModifiable modifiable) {
        final Entry entry = this.modifiableToEntry.remove(modifiable);
        if (entry != null) {
            return entry.modifiable;
        }
        return null;
    }
    
    @Override
    public void start(final Duration pollFrequency) {
        (this.task = new Task("ModificationWatcher")).run(pollFrequency, new ICode() {
            @Override
            public void run(final Logger log) {
                ModificationWatcher.this.checkModified();
            }
        });
    }
    
    protected void checkModified() {
        for (final Entry entry : this.modifiableToEntry.values()) {
            final Time modifiableLastModified = entry.modifiable.lastModifiedTime();
            if (modifiableLastModified != null && modifiableLastModified.after(entry.lastModifiedTime)) {
                entry.listeners.notifyListeners(entry.modifiable);
                entry.lastModifiedTime = modifiableLastModified;
            }
        }
    }
    
    @Override
    public void destroy() {
        if (this.task != null) {
            this.task.interrupt();
        }
    }
    
    @Override
    public final Set<IModifiable> getEntries() {
        return this.modifiableToEntry.keySet();
    }
    
    static {
        log = LoggerFactory.getLogger((Class)ModificationWatcher.class);
    }
    
    protected static final class Entry
    {
        public Time lastModifiedTime;
        public final ChangeListenerSet<IModifiable> listeners;
        public IModifiable modifiable;
        
        protected Entry() {
            this.listeners = new ChangeListenerSet<IModifiable>();
        }
    }
}
