// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import java.util.Arrays;
import java.util.regex.Matcher;
import org.junit.Assert;
import org.apache.wicket.util.string.Strings;
import java.io.File;
import java.util.List;
import java.util.regex.Pattern;

class JavaLicenseHeaderHandler extends AbstractLicenseHeaderHandler
{
    private final Pattern javaHeaderPattern;
    
    public JavaLicenseHeaderHandler(final List<String> ignoreFiles) {
        super(ignoreFiles);
        this.javaHeaderPattern = Pattern.compile("^(.*?)package.*$", 40);
    }
    
    @Override
    public boolean addLicenseHeader(final File file) {
        boolean added = false;
        try {
            final String fileContent = new org.apache.wicket.util.file.File(file).readString();
            final Matcher mat = this.javaHeaderPattern.matcher(fileContent);
            if (mat.matches()) {
                final String header = mat.group(1);
                if (!header.equals(this.getLicenseHeader())) {
                    String newContent = Strings.replaceAll(fileContent, header, "").toString();
                    newContent = this.getLicenseHeader().trim() + JavaLicenseHeaderHandler.LINE_ENDING + newContent;
                    new org.apache.wicket.util.file.File(file).write(newContent);
                    added = true;
                }
            }
            else {
                Assert.fail();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
        return added;
    }
    
    @Override
    public boolean checkLicenseHeader(final File file) {
        final String header = this.extractLicenseHeader(file, 0, 16);
        return this.getLicenseHeader().equals(header);
    }
    
    @Override
    public List<String> getSuffixes() {
        return Arrays.asList("java");
    }
    
    @Override
    protected String getLicenseHeaderFilename() {
        return "javaLicense.txt";
    }
    
    @Override
    public String getLicenseType(final File file) {
        String licenseType = null;
        final String header = this.extractLicenseHeader(file, 0, 20);
        if (header.contains("Apache License, Version 2.0")) {
            licenseType = "ASL2";
        }
        else if (header.contains("The Apache Software License, Version 1.1")) {
            licenseType = "ASL1.1";
        }
        return licenseType;
    }
}
