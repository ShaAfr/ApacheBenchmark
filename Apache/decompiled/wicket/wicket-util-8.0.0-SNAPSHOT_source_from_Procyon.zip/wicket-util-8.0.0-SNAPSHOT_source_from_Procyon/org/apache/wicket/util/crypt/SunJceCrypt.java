// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

import javax.crypto.spec.PBEKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import java.security.Key;
import java.security.GeneralSecurityException;
import javax.crypto.Cipher;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.SecretKey;
import org.apache.wicket.util.lang.Args;
import javax.crypto.spec.PBEParameterSpec;

public class SunJceCrypt extends AbstractCrypt
{
    private static final int COUNT = 17;
    public static final String DEFAULT_CRYPT_METHOD = "PBEWithMD5AndDES";
    public static final byte[] SALT;
    private static final PBEParameterSpec PARAMETER_SPEC;
    private final String cryptMethod;
    
    public SunJceCrypt() {
        this("PBEWithMD5AndDES");
    }
    
    public SunJceCrypt(final String cryptMethod) {
        this.cryptMethod = Args.notNull(cryptMethod, "Crypt method");
    }
    
    @Override
    protected byte[] crypt(final byte[] input, final int mode) throws GeneralSecurityException {
        final SecretKey key = this.generateSecretKey();
        final AlgorithmParameterSpec spec = this.createParameterSpec();
        final Cipher ciph = this.createCipher(key, spec, mode);
        return ciph.doFinal(input);
    }
    
    protected Cipher createCipher(final SecretKey key, final AlgorithmParameterSpec spec, final int mode) throws GeneralSecurityException {
        final Cipher cipher = Cipher.getInstance(this.cryptMethod);
        cipher.init(mode, key, spec);
        return cipher;
    }
    
    protected SecretKey generateSecretKey() throws NoSuchAlgorithmException, InvalidKeySpecException {
        final SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(this.cryptMethod);
        final KeySpec spec = this.createKeySpec();
        return keyFactory.generateSecret(spec);
    }
    
    protected AlgorithmParameterSpec createParameterSpec() {
        return SunJceCrypt.PARAMETER_SPEC;
    }
    
    protected KeySpec createKeySpec() {
        return new PBEKeySpec(this.getKey().toCharArray());
    }
    
    static {
        SALT = new byte[] { 21, -116, -93, 74, 102, 81, 42, -68 };
        PARAMETER_SPEC = new PBEParameterSpec(SunJceCrypt.SALT, 17);
    }
}
