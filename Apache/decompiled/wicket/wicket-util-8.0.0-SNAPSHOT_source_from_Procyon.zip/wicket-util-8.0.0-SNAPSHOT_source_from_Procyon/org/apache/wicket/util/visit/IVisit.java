// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.visit;

public interface IVisit<R>
{
    void stop();
    
    void stop(final R p0);
    
    void dontGoDeeper();
}
