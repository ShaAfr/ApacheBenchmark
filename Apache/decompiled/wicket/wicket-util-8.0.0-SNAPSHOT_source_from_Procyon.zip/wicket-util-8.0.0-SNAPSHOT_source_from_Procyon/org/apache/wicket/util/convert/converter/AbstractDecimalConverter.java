// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.text.NumberFormat;
import java.util.Locale;

public abstract class AbstractDecimalConverter<N extends Number> extends AbstractNumberConverter<N>
{
    private static final long serialVersionUID = 1L;
    
    @Override
    protected NumberFormat newNumberFormat(final Locale locale) {
        return NumberFormat.getInstance(locale);
    }
}
