// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.io.Serializable;
import java.net.URL;
import java.util.Comparator;

public class UrlExternalFormComparator implements Comparator<URL>, Serializable
{
    private static final long serialVersionUID = 1L;
    
    @Override
    public int compare(final URL url1, final URL url2) {
        return url1.toExternalForm().compareTo(url2.toExternalForm());
    }
}
