// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

import org.slf4j.LoggerFactory;
import org.apache.wicket.util.lang.Objects;
import org.apache.wicket.util.lang.Args;
import java.text.ParseException;
import java.text.NumberFormat;
import org.apache.wicket.util.time.Duration;
import org.apache.wicket.util.time.Time;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import org.slf4j.Logger;
import org.apache.wicket.util.io.IClusterable;

public class StringValue implements IClusterable
{
    private static final long serialVersionUID = 1L;
    private static final Logger LOG;
    private final Locale locale;
    private final String text;
    
    public static StringValue repeat(final int times, final char c) {
        final AppendingStringBuffer buffer = new AppendingStringBuffer(times);
        for (int i = 0; i < times; ++i) {
            buffer.append(c);
        }
        return valueOf(buffer);
    }
    
    public static StringValue repeat(final int times, final String s) {
        final AppendingStringBuffer buffer = new AppendingStringBuffer(times);
        for (int i = 0; i < times; ++i) {
            buffer.append(s);
        }
        return valueOf(buffer);
    }
    
    public static StringValue valueOf(final double value) {
        return valueOf(value, Locale.getDefault(Locale.Category.FORMAT));
    }
    
    public static StringValue valueOf(final double value, final int places, final Locale locale) {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            return valueOf("N/A");
        }
        final DecimalFormat format = new DecimalFormat("#." + repeat(places, '#'), new DecimalFormatSymbols(locale));
        return valueOf(format.format(value));
    }
    
    public static StringValue valueOf(final double value, final Locale locale) {
        return valueOf(value, 1, locale);
    }
    
    public static StringValue valueOf(final Object object) {
        return valueOf(Strings.toString(object));
    }
    
    public static StringValue valueOf(final Object object, final Locale locale) {
        return valueOf(Strings.toString(object), locale);
    }
    
    public static StringValue valueOf(final String string) {
        return new StringValue(string);
    }
    
    public static StringValue valueOf(final String string, final Locale locale) {
        return new StringValue(string, locale);
    }
    
    public static StringValue valueOf(final AppendingStringBuffer buffer) {
        return valueOf(buffer.toString());
    }
    
    protected StringValue(final String text) {
        this(text, Locale.getDefault());
    }
    
    protected StringValue(final String text, final Locale locale) {
        this.text = text;
        this.locale = locale;
    }
    
    public final String afterFirst(final char c) {
        return Strings.afterFirst(this.text, c);
    }
    
    public final String afterLast(final char c) {
        return Strings.afterLast(this.text, c);
    }
    
    public final String beforeFirst(final char c) {
        return Strings.beforeFirst(this.text, c);
    }
    
    public final String beforeLast(final char c) {
        return Strings.afterLast(this.text, c);
    }
    
    public final CharSequence replaceAll(final CharSequence searchFor, final CharSequence replaceWith) {
        return Strings.replaceAll(this.text, searchFor, replaceWith);
    }
    
    public final <T> T to(final Class<T> type) throws StringValueConversionException {
        if (type == null) {
            return null;
        }
        if (type == String.class) {
            return (T)this.toString();
        }
        if (type == Integer.TYPE || type == Integer.class) {
            return (T)this.toInteger();
        }
        if (type == Long.TYPE || type == Long.class) {
            return (T)this.toLongObject();
        }
        if (type == Boolean.TYPE || type == Boolean.class) {
            return (T)this.toBooleanObject();
        }
        if (type == Double.TYPE || type == Double.class) {
            return (T)this.toDoubleObject();
        }
        if (type == Character.TYPE || type == Character.class) {
            return (T)this.toCharacter();
        }
        if (type == Time.class) {
            return (T)this.toTime();
        }
        if (type == Duration.class) {
            return (T)this.toDuration();
        }
        if (type.isEnum()) {
            return this.toEnum(type);
        }
        throw new StringValueConversionException("Cannot convert '" + this.toString() + "'to type " + type);
    }
    
    public final <T> T toOptional(final Class<T> type) throws StringValueConversionException {
        return (T)(Strings.isEmpty(this.text) ? null : this.to((Class<Object>)type));
    }
    
    public final boolean toBoolean() throws StringValueConversionException {
        return Strings.isTrue(this.text);
    }
    
    public final boolean toBoolean(final boolean defaultValue) {
        if (this.text != null) {
            try {
                return this.toBoolean();
            }
            catch (StringValueConversionException x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to a boolean: %s", this.text, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final Boolean toBooleanObject() throws StringValueConversionException {
        return Strings.toBoolean(this.text);
    }
    
    public final char toChar() throws StringValueConversionException {
        return Strings.toChar(this.text);
    }
    
    public final char toChar(final char defaultValue) {
        if (this.text != null) {
            try {
                return this.toChar();
            }
            catch (StringValueConversionException x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to a character: %s", this.text, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final Character toCharacter() throws StringValueConversionException {
        return this.toChar();
    }
    
    public final double toDouble() throws StringValueConversionException {
        try {
            return NumberFormat.getNumberInstance(this.locale).parse(this.text).doubleValue();
        }
        catch (ParseException e) {
            throw new StringValueConversionException("Unable to convert '" + this.text + "' to a double value", e);
        }
    }
    
    public final double toDouble(final double defaultValue) {
        if (this.text != null) {
            try {
                return this.toDouble();
            }
            catch (Exception x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to a double: %s", this.text, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final Double toDoubleObject() throws StringValueConversionException {
        return this.toDouble();
    }
    
    public final Duration toDuration() throws StringValueConversionException {
        return Duration.valueOf(this.text, this.locale);
    }
    
    public final Duration toDuration(final Duration defaultValue) {
        if (this.text != null) {
            try {
                return this.toDuration();
            }
            catch (Exception x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to a Duration: %s", this.text, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final int toInt() throws StringValueConversionException {
        try {
            return Integer.parseInt(this.text);
        }
        catch (NumberFormatException e) {
            throw new StringValueConversionException("Unable to convert '" + this.text + "' to an int value", e);
        }
    }
    
    public final int toInt(final int defaultValue) {
        if (this.text != null) {
            try {
                return this.toInt();
            }
            catch (StringValueConversionException x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to an integer: %s", this.text, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final Integer toInteger() throws StringValueConversionException {
        try {
            return new Integer(this.text);
        }
        catch (NumberFormatException e) {
            throw new StringValueConversionException("Unable to convert '" + this.text + "' to an Integer value", e);
        }
    }
    
    public final long toLong() throws StringValueConversionException {
        try {
            return Long.parseLong(this.text);
        }
        catch (NumberFormatException e) {
            throw new StringValueConversionException("Unable to convert '" + this.text + "' to a long value", e);
        }
    }
    
    public final long toLong(final long defaultValue) {
        if (this.text != null) {
            try {
                return this.toLong();
            }
            catch (StringValueConversionException x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to a long: %s", this.text, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final Long toLongObject() throws StringValueConversionException {
        try {
            return new Long(this.text);
        }
        catch (NumberFormatException e) {
            throw new StringValueConversionException("Unable to convert '" + this.text + "' to a Long value", e);
        }
    }
    
    public final Boolean toOptionalBoolean() throws StringValueConversionException {
        return Strings.isEmpty(this.text) ? null : this.toBooleanObject();
    }
    
    public final Character toOptionalCharacter() throws StringValueConversionException {
        return Strings.isEmpty(this.text) ? null : this.toCharacter();
    }
    
    public final Double toOptionalDouble() throws StringValueConversionException {
        return Strings.isEmpty(this.text) ? null : this.toDoubleObject();
    }
    
    public final Duration toOptionalDuration() throws StringValueConversionException {
        return Strings.isEmpty(this.text) ? null : this.toDuration();
    }
    
    public final Integer toOptionalInteger() throws StringValueConversionException {
        return Strings.isEmpty(this.text) ? null : this.toInteger();
    }
    
    public final Long toOptionalLong() throws StringValueConversionException {
        return Strings.isEmpty(this.text) ? null : this.toLongObject();
    }
    
    public final String toOptionalString() {
        return this.text;
    }
    
    public final Time toOptionalTime() throws StringValueConversionException {
        return Strings.isEmpty(this.text) ? null : this.toTime();
    }
    
    @Override
    public final String toString() {
        return this.text;
    }
    
    public final String toString(final String defaultValue) {
        return (this.text == null) ? defaultValue : this.text;
    }
    
    public final Time toTime() throws StringValueConversionException {
        try {
            return Time.valueOf(this.text);
        }
        catch (ParseException e) {
            throw new StringValueConversionException("Unable to convert '" + this.text + "' to a Time value", e);
        }
    }
    
    public final Time toTime(final Time defaultValue) {
        if (this.text != null) {
            try {
                return this.toTime();
            }
            catch (StringValueConversionException x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to a Time: %s", this.text, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final <T extends Enum<T>> T toEnum(final Class<T> eClass) throws StringValueConversionException {
        return Strings.toEnum(this.text, eClass);
    }
    
    public final <T extends Enum<T>> T toEnum(final T defaultValue) {
        Args.notNull(defaultValue, "defaultValue");
        return this.toEnum((Class<T>)defaultValue.getClass(), defaultValue);
    }
    
    public final <T extends Enum<T>> T toEnum(final Class<T> eClass, final T defaultValue) {
        if (this.text != null) {
            try {
                return this.toEnum(eClass);
            }
            catch (StringValueConversionException x) {
                if (StringValue.LOG.isDebugEnabled()) {
                    StringValue.LOG.debug(String.format("An error occurred while converting '%s' to a %s: %s", this.text, eClass, x.getMessage()), (Throwable)x);
                }
            }
        }
        return defaultValue;
    }
    
    public final <T extends Enum<T>> T toOptionalEnum(final Class<T> eClass) throws StringValueConversionException {
        return (T)(Strings.isEmpty(this.text) ? null : this.toEnum((Class<Enum<T>>)eClass));
    }
    
    public boolean isNull() {
        return this.text == null;
    }
    
    public boolean isEmpty() {
        return Strings.isEmpty(this.text);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(this.locale, this.text);
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof StringValue) {
            final StringValue stringValue = (StringValue)obj;
            return Objects.isEqual(this.text, stringValue.text) && this.locale.equals(stringValue.locale);
        }
        return false;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StringValue.class);
    }
}
