// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import java.io.File;
import java.util.List;

interface ILicenseHeaderHandler
{
    List<String> getSuffixes();
    
    List<String> getIgnoreFiles();
    
    boolean addLicenseHeader(final File p0);
    
    boolean checkLicenseHeader(final File p0);
    
    String getLicenseType(final File p0);
}
