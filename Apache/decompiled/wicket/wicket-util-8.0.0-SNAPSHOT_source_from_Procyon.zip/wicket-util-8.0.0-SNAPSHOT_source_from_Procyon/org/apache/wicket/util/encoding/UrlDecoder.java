// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.encoding;

import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import org.apache.wicket.util.string.Strings;
import java.nio.charset.Charset;
import org.slf4j.Logger;

public class UrlDecoder
{
    private static final Logger LOG;
    private final boolean decodePlus;
    public static final UrlDecoder QUERY_INSTANCE;
    public static final UrlDecoder PATH_INSTANCE;
    
    private UrlDecoder(final boolean decodePlus) {
        this.decodePlus = decodePlus;
    }
    
    public String decode(final String s, final Charset enc) {
        return this.decode(s, enc.name());
    }
    
    public String decode(final String s, final String enc) {
        if (Strings.isEmpty(s)) {
            return s;
        }
        final int numChars = s.length();
        final StringBuilder sb = new StringBuilder((numChars > 500) ? (numChars / 2) : numChars);
        int i = 0;
        if (enc.length() == 0) {
            throw new RuntimeException(new UnsupportedEncodingException("URLDecoder: empty string enc parameter"));
        }
        byte[] bytes = null;
        while (i < numChars) {
            char c = s.charAt(i);
            switch (c) {
                case '+': {
                    sb.append(this.decodePlus ? ' ' : '+');
                    ++i;
                    continue;
                }
                case '%': {
                    try {
                        if (bytes == null) {
                            bytes = new byte[(numChars - i) / 3];
                        }
                        int pos = 0;
                        while (i + 2 < numChars && c == '%') {
                            bytes[pos++] = (byte)Integer.parseInt(s.substring(i + 1, i + 3), 16);
                            i += 3;
                            if (i < numChars) {
                                c = s.charAt(i);
                            }
                        }
                        if (i < numChars && c == '%') {
                            UrlDecoder.LOG.info("Incomplete trailing escape (%) pattern in '%s'. The escape character (%) will be ignored.", (Object)s);
                            ++i;
                        }
                        else {
                            try {
                                sb.append(new String(bytes, 0, pos, enc));
                            }
                            catch (UnsupportedEncodingException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                    catch (NumberFormatException e2) {
                        UrlDecoder.LOG.info("Illegal hex characters in escape (%) pattern in '{}'. The escape character (%) will be ignored. NumberFormatException: {} ", (Object)s, (Object)e2.getMessage());
                        ++i;
                    }
                    continue;
                }
                default: {
                    sb.append(c);
                    ++i;
                    continue;
                }
            }
        }
        return sb.toString().replace("\u0000", "NULL");
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)UrlDecoder.class);
        QUERY_INSTANCE = new UrlDecoder(true);
        PATH_INSTANCE = new UrlDecoder(false);
    }
}
