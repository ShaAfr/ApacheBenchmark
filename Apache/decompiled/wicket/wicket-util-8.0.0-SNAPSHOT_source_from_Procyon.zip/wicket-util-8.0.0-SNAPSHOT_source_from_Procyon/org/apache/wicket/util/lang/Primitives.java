// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

public final class Primitives
{
    public static int hashCode(final long value) {
        return (int)value ^ (int)(value >> 32);
    }
}
