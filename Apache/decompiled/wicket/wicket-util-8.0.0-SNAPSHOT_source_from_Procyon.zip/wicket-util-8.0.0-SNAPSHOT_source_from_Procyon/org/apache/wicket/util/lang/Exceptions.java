// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

public class Exceptions
{
    private Exceptions() {
    }
    
    public Throwable getRootCause(final Throwable throwable) {
        Throwable cursor;
        for (cursor = throwable; cursor.getCause() != null; cursor = cursor.getCause()) {}
        return cursor;
    }
    
    public static <T extends Throwable> T findCause(final Throwable throwable, final Class<T> causeType) {
        return visit(throwable, (IThrowableVisitor<T>)new IThrowableVisitor<T>() {
            @Override
            public void visit(final Throwable throwable, final Visit<T> visit) {
                if (causeType.isAssignableFrom(throwable.getClass())) {
                    visit.stop((T)throwable);
                }
            }
        });
    }
    
    public static <T> T visit(final Throwable throwable, final IThrowableVisitor<T> visitor) {
        final Visit<T> visit = new Visit<T>();
        for (Throwable cursor = throwable; cursor != null; cursor = cursor.getCause()) {
            visitor.visit(cursor, visit);
            if (((Visit<Object>)visit).stopped) {
                return (T)((Visit<Object>)visit).result;
            }
        }
        return null;
    }
    
    public static class Visit<T>
    {
        private T result;
        private boolean stopped;
        
        public void stop(final T result) {
            this.result = result;
            this.stop();
        }
        
        public void stop() {
            this.stopped = true;
        }
    }
    
    public interface IThrowableVisitor<T>
    {
        void visit(final Throwable p0, final Visit<T> p1);
    }
}
