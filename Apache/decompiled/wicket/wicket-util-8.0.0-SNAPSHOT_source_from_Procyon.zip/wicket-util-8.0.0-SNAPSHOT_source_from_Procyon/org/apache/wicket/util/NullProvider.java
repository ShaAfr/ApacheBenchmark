// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util;

import java.util.function.Supplier;

public class NullProvider<T> implements Supplier<T>
{
    @Override
    public T get() {
        return null;
    }
}
