// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.value;

import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.string.StringValue;
import org.apache.wicket.util.time.Duration;
import org.apache.wicket.util.string.StringValueConversionException;
import java.util.Map;

public interface IValueMap extends Map<String, Object>
{
    boolean getBoolean(final String p0) throws StringValueConversionException;
    
    double getDouble(final String p0) throws StringValueConversionException;
    
    double getDouble(final String p0, final double p1) throws StringValueConversionException;
    
    Duration getDuration(final String p0) throws StringValueConversionException;
    
    int getInt(final String p0) throws StringValueConversionException;
    
    int getInt(final String p0, final int p1) throws StringValueConversionException;
    
    long getLong(final String p0) throws StringValueConversionException;
    
    long getLong(final String p0, final long p1) throws StringValueConversionException;
    
    String getString(final String p0, final String p1);
    
    String getString(final String p0);
    
    CharSequence getCharSequence(final String p0);
    
    String[] getStringArray(final String p0);
    
    StringValue getStringValue(final String p0);
    
    Time getTime(final String p0) throws StringValueConversionException;
    
    boolean isImmutable();
    
    IValueMap makeImmutable();
    
    String getKey(final String p0);
    
    Boolean getAsBoolean(final String p0);
    
    boolean getAsBoolean(final String p0, final boolean p1);
    
    Integer getAsInteger(final String p0);
    
    int getAsInteger(final String p0, final int p1);
    
    Long getAsLong(final String p0);
    
    long getAsLong(final String p0, final long p1);
    
    Double getAsDouble(final String p0);
    
    double getAsDouble(final String p0, final double p1);
    
    Duration getAsDuration(final String p0);
    
    Duration getAsDuration(final String p0, final Duration p1);
    
    Time getAsTime(final String p0);
    
    Time getAsTime(final String p0, final Time p1);
    
     <T extends Enum<T>> T getAsEnum(final String p0, final Class<T> p1);
    
     <T extends Enum<T>> T getAsEnum(final String p0, final T p1);
    
     <T extends Enum<T>> T getAsEnum(final String p0, final Class<T> p1, final T p2);
}
