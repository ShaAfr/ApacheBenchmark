// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import org.apache.wicket.util.string.interpolator.MapVariableInterpolator;
import java.util.HashMap;
import java.util.Iterator;
import java.lang.management.RuntimeMXBean;
import java.util.Map;
import java.lang.management.ManagementFactory;
import org.slf4j.Logger;

public class Threads
{
    private static final String FORMAT = "\"${name}\"${isDaemon} prio=${priority} tid=${threadIdDec} state=${state} ";
    
    private Threads() {
    }
    
    public static void dumpAllThreads(final Logger logger) {
        Args.notNull(logger, "logger");
        if (!logger.isWarnEnabled()) {
            return;
        }
        final RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
        final StringBuilder dump = new StringBuilder();
        dump.append("Full thread dump ").append(runtimeMXBean.getVmName()).append('(').append(runtimeMXBean.getVmVersion()).append(')');
        logger.warn(dump.toString());
        final Map<Thread, StackTraceElement[]> allStackTraces = Thread.getAllStackTraces();
        for (final Map.Entry<Thread, StackTraceElement[]> entry : allStackTraces.entrySet()) {
            dumpSingleThread(logger, entry.getKey(), entry.getValue());
        }
    }
    
    public static void dumpSingleThread(final Logger logger, final Thread thread) {
        Args.notNull(logger, "logger");
        if (!logger.isWarnEnabled()) {
            return;
        }
        dumpSingleThread(logger, thread, thread.getStackTrace());
    }
    
    private static void dumpSingleThread(final Logger logger, final Thread thread, final StackTraceElement[] trace) {
        final Map<CharSequence, Object> variables = new HashMap<CharSequence, Object>();
        variables.put("name", thread.getName());
        variables.put("isDaemon", thread.isDaemon() ? " daemon" : "");
        variables.put("priority", thread.getPriority());
        variables.put("threadIdDec", thread.getId());
        variables.put("state", thread.getState());
        final ThreadDump throwable = new ThreadDump();
        throwable.setStackTrace(trace);
        logger.warn(MapVariableInterpolator.interpolate("\"${name}\"${isDaemon} prio=${priority} tid=${threadIdDec} state=${state} ", variables), (Throwable)throwable);
    }
    
    private static class ThreadDump extends RuntimeException
    {
        private static final long serialVersionUID = 1L;
        
        @Override
        public synchronized Throwable fillInStackTrace() {
            return null;
        }
    }
}
