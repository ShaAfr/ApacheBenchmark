// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.Locale;
import org.apache.wicket.util.string.Strings;
import java.util.Set;
import java.util.regex.Pattern;

public class ResourceUtils
{
    public static final String MIN_POSTFIX_DEFAULT = "min";
    public static final String MIN_POSTFIX_DEFAULT_AS_EXTENSION = ".min.";
    private static final Pattern LOCALE_MIN_PATTERN;
    private static final Set<String> isoCountries;
    private static final Set<String> isoLanguages;
    
    public static String getMinifiedName(final String name, final String minPostfix) {
        final int idxOfExtension = name.lastIndexOf(46);
        final String dottedPostfix = "." + minPostfix;
        String minifiedName;
        if (idxOfExtension > -1) {
            final String extension = name.substring(idxOfExtension);
            final String baseName = name.substring(0, name.length() - extension.length() + 1);
            if (!dottedPostfix.equals(extension) && !baseName.endsWith(dottedPostfix + ".")) {
                minifiedName = baseName + minPostfix + extension;
            }
            else {
                minifiedName = name;
            }
        }
        else {
            minifiedName = name + dottedPostfix;
        }
        return minifiedName;
    }
    
    public static PathLocale getLocaleFromFilename(String path) {
        String extension = "";
        final int pos = path.lastIndexOf(46);
        if (pos != -1) {
            extension = path.substring(pos);
            path = path.substring(0, pos);
        }
        final String filename = Strings.lastPathComponent(path, '/');
        final Matcher matcher = ResourceUtils.LOCALE_MIN_PATTERN.matcher(filename);
        if (matcher.find()) {
            String language = matcher.group(1);
            String country = matcher.group(3);
            String variant = matcher.group(5);
            final String min = matcher.group(6);
            if (language != null && !ResourceUtils.isoLanguages.contains(language)) {
                language = null;
                country = null;
                variant = null;
            }
            if (language != null && country != null && !ResourceUtils.isoCountries.contains(country)) {
                country = null;
                variant = null;
            }
            if (language != null) {
                final int languagePos = path.length() - filename.length() + matcher.start();
                final String basePath = path.substring(0, languagePos) + ((min == null) ? "" : min) + extension;
                final Locale locale = new Locale(language, (country != null) ? country : "", (variant != null) ? variant : "");
                return new PathLocale(basePath, locale);
            }
        }
        return new PathLocale(path + extension, null);
    }
    
    static {
        LOCALE_MIN_PATTERN = Pattern.compile("_([a-z]{2})(_([A-Z]{2})(_([^_\\.]+))?)?(\\.min)?$");
        isoCountries = new HashSet<String>(Arrays.asList(Locale.getISOCountries()));
        isoLanguages = new HashSet<String>(Arrays.asList(Locale.getISOLanguages()));
    }
    
    public static class PathLocale
    {
        public final String path;
        public final Locale locale;
        
        public PathLocale(final String path, final Locale locale) {
            this.path = path;
            this.locale = locale;
        }
    }
}
