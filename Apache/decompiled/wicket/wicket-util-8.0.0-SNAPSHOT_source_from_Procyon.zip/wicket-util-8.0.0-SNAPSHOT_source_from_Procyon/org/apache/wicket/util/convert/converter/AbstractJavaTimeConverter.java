// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import org.apache.wicket.util.string.Strings;
import java.util.Locale;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.Temporal;

public abstract class AbstractJavaTimeConverter<T extends Temporal> extends AbstractConverter<T>
{
    private static final long serialVersionUID = 1L;
    
    protected abstract T createTemporal(final TemporalAccessor p0);
    
    @Override
    public T convertToObject(final String value, final Locale locale) {
        if (Strings.isEmpty(value)) {
            return null;
        }
        final DateTimeFormatter dateTimeFormatter = this.getDateTimeFormatter(locale);
        TemporalAccessor temporalAccessor;
        try {
            temporalAccessor = dateTimeFormatter.parse(value);
        }
        catch (DateTimeParseException ex) {
            throw this.newConversionException("Cannot parse '" + value, value, locale);
        }
        return this.createTemporal(temporalAccessor);
    }
    
    @Override
    public String convertToString(final T value, final Locale locale) {
        if (value == null) {
            return null;
        }
        final DateTimeFormatter dateTimeFormatter = this.getDateTimeFormatter(locale);
        if (dateTimeFormatter != null) {
            return dateTimeFormatter.format(value);
        }
        return value.toString();
    }
    
    public DateTimeFormatter getDateTimeFormatter(Locale locale) {
        if (locale == null) {
            locale = Locale.getDefault();
        }
        return this.getDateTimeFormatter().withLocale(locale);
    }
    
    protected abstract DateTimeFormatter getDateTimeFormatter();
}
