// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.string.AppendingStringBuffer;

public class StringBufferResourceStream extends AbstractStringResourceStream
{
    private static final long serialVersionUID = 1L;
    private final AppendingStringBuffer buffer;
    
    public StringBufferResourceStream() {
        this.buffer = new AppendingStringBuffer(128);
    }
    
    public StringBufferResourceStream(final String contentType) {
        super(contentType);
        this.buffer = new AppendingStringBuffer(128);
    }
    
    public StringBufferResourceStream append(final CharSequence s) {
        this.buffer.append(s);
        this.setLastModified(Time.now());
        return this;
    }
    
    public StringBufferResourceStream prepend(final CharSequence s) {
        this.buffer.insert(0, s);
        this.setLastModified(Time.now());
        return this;
    }
    
    public StringBufferResourceStream clear() {
        this.buffer.delete(0, this.buffer.length());
        return this;
    }
    
    @Override
    protected String getString() {
        return this.buffer.toString();
    }
}
