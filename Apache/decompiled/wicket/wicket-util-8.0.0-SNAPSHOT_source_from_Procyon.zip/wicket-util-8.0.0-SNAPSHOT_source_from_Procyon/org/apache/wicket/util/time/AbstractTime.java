// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.time;

import java.util.Locale;
import java.util.Date;
import org.apache.wicket.util.value.LongValue;
import java.text.SimpleDateFormat;
import java.util.Calendar;

abstract class AbstractTime extends AbstractTimeValue
{
    private static final long serialVersionUID = 1L;
    static final Calendar localtime;
    static final SimpleDateFormat timeFormat;
    
    AbstractTime(final long milliseconds) {
        super(milliseconds);
    }
    
    public final boolean after(final AbstractTimeValue that) {
        return this.greaterThan(that);
    }
    
    public final boolean before(final AbstractTimeValue that) {
        return this.lessThan(that);
    }
    
    public final String toTimeString() {
        return this.toTimeString(AbstractTime.localtime);
    }
    
    public final String toTimeString(final Calendar calendar) {
        synchronized (AbstractTime.timeFormat) {
            synchronized (calendar) {
                AbstractTime.timeFormat.setCalendar(calendar);
                return AbstractTime.timeFormat.format(new Date(this.getMilliseconds())).toLowerCase();
            }
        }
    }
    
    @Override
    public String toString() {
        return this.toTimeString();
    }
    
    static {
        localtime = Calendar.getInstance();
        timeFormat = new SimpleDateFormat("h.mma", Locale.ENGLISH);
    }
}
