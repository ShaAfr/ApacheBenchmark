// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import java.nio.charset.Charset;

public interface IStringResourceStream extends IResourceStream
{
    void setCharset(final Charset p0);
    
    String asString();
}
