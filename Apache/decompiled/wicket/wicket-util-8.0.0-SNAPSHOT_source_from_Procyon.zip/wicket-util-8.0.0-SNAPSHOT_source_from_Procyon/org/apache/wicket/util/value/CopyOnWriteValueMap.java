// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.value;

import java.util.Collection;
import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.string.StringValue;
import org.apache.wicket.util.time.Duration;
import org.apache.wicket.util.string.StringValueConversionException;
import java.util.Set;
import java.util.Map;
import java.io.Serializable;

public class CopyOnWriteValueMap implements IValueMap, Serializable
{
    private static final long serialVersionUID = 1L;
    private IValueMap wrapped;
    
    public CopyOnWriteValueMap(final IValueMap wrapped) {
        this.wrapped = wrapped;
    }
    
    @Override
    public void clear() {
        this.checkAndCopy();
        this.wrapped.clear();
    }
    
    private void checkAndCopy() {
        if (this.wrapped.isImmutable()) {
            this.wrapped = new ValueMap(this.wrapped);
        }
    }
    
    @Override
    public boolean containsKey(final Object key) {
        return this.wrapped.containsKey(key);
    }
    
    @Override
    public boolean containsValue(final Object value) {
        return this.wrapped.containsValue(value);
    }
    
    @Override
    public Set<Map.Entry<String, Object>> entrySet() {
        this.checkAndCopy();
        return this.wrapped.entrySet();
    }
    
    @Override
    public boolean equals(final Object o) {
        return this.wrapped.equals(o);
    }
    
    @Override
    public int hashCode() {
        return this.wrapped.hashCode();
    }
    
    @Override
    public Object get(final Object key) {
        return ((Map<K, Object>)this.wrapped).get(key);
    }
    
    @Override
    public boolean getBoolean(final String key) throws StringValueConversionException {
        return this.wrapped.getBoolean(key);
    }
    
    @Override
    public CharSequence getCharSequence(final String key) {
        return this.wrapped.getCharSequence(key);
    }
    
    @Override
    public double getDouble(final String key) throws StringValueConversionException {
        return this.wrapped.getDouble(key);
    }
    
    @Override
    public double getDouble(final String key, final double defaultValue) {
        return this.wrapped.getDouble(key, defaultValue);
    }
    
    @Override
    public Duration getDuration(final String key) throws StringValueConversionException {
        return this.wrapped.getDuration(key);
    }
    
    @Override
    public int getInt(final String key, final int defaultValue) {
        return this.wrapped.getInt(key, defaultValue);
    }
    
    @Override
    public int getInt(final String key) throws StringValueConversionException {
        return this.wrapped.getInt(key);
    }
    
    @Override
    public String getKey(final String key) {
        return this.wrapped.getKey(key);
    }
    
    @Override
    public long getLong(final String key, final long defaultValue) {
        return this.wrapped.getLong(key, defaultValue);
    }
    
    @Override
    public long getLong(final String key) throws StringValueConversionException {
        return this.wrapped.getLong(key);
    }
    
    @Override
    public String getString(final String key, final String defaultValue) {
        return this.wrapped.getString(key, defaultValue);
    }
    
    @Override
    public String getString(final String key) {
        return this.wrapped.getString(key);
    }
    
    @Override
    public String[] getStringArray(final String key) {
        return this.wrapped.getStringArray(key);
    }
    
    @Override
    public StringValue getStringValue(final String key) {
        return this.wrapped.getStringValue(key);
    }
    
    @Override
    public Time getTime(final String key) throws StringValueConversionException {
        return this.wrapped.getTime(key);
    }
    
    @Override
    public boolean isEmpty() {
        return this.wrapped.isEmpty();
    }
    
    @Override
    public boolean isImmutable() {
        return false;
    }
    
    @Override
    public Set<String> keySet() {
        this.checkAndCopy();
        return ((Map<String, V>)this.wrapped).keySet();
    }
    
    @Override
    public IValueMap makeImmutable() {
        return this.wrapped.makeImmutable();
    }
    
    @Override
    public Object put(final String key, final Object value) {
        this.checkAndCopy();
        return this.wrapped.put(key, value);
    }
    
    @Override
    public void putAll(final Map<? extends String, ?> map) {
        this.checkAndCopy();
        this.wrapped.putAll(map);
    }
    
    @Override
    public Object remove(final Object key) {
        this.checkAndCopy();
        return ((Map<K, Object>)this.wrapped).remove(key);
    }
    
    @Override
    public int size() {
        return this.wrapped.size();
    }
    
    @Override
    public Collection<Object> values() {
        return ((Map<K, Object>)this.wrapped).values();
    }
    
    @Override
    public Boolean getAsBoolean(final String key) {
        return this.wrapped.getAsBoolean(key);
    }
    
    @Override
    public boolean getAsBoolean(final String key, final boolean defaultValue) {
        return this.wrapped.getAsBoolean(key, defaultValue);
    }
    
    @Override
    public Integer getAsInteger(final String key) {
        return this.wrapped.getAsInteger(key);
    }
    
    @Override
    public int getAsInteger(final String key, final int defaultValue) {
        return this.wrapped.getAsInteger(key, defaultValue);
    }
    
    @Override
    public Long getAsLong(final String key) {
        return this.wrapped.getAsLong(key);
    }
    
    @Override
    public long getAsLong(final String key, final long defaultValue) {
        return this.wrapped.getAsLong(key, defaultValue);
    }
    
    @Override
    public Double getAsDouble(final String key) {
        return this.wrapped.getAsDouble(key);
    }
    
    @Override
    public double getAsDouble(final String key, final double defaultValue) {
        return this.wrapped.getAsDouble(key, defaultValue);
    }
    
    @Override
    public Duration getAsDuration(final String key) {
        return this.wrapped.getAsDuration(key);
    }
    
    @Override
    public Duration getAsDuration(final String key, final Duration defaultValue) {
        return this.wrapped.getAsDuration(key, defaultValue);
    }
    
    @Override
    public Time getAsTime(final String key) {
        return this.wrapped.getAsTime(key);
    }
    
    @Override
    public Time getAsTime(final String key, final Time defaultValue) {
        return this.wrapped.getAsTime(key, defaultValue);
    }
    
    @Override
    public <T extends Enum<T>> T getAsEnum(final String key, final Class<T> eClass) {
        return this.wrapped.getAsEnum(key, eClass);
    }
    
    @Override
    public <T extends Enum<T>> T getAsEnum(final String key, final T defaultValue) {
        return this.wrapped.getAsEnum(key, defaultValue);
    }
    
    @Override
    public <T extends Enum<T>> T getAsEnum(final String key, final Class<T> eClass, final T defaultValue) {
        return this.wrapped.getAsEnum(key, eClass, defaultValue);
    }
}
