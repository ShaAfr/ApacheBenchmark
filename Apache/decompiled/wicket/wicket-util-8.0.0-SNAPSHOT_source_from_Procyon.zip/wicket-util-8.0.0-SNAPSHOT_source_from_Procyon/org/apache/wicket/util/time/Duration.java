// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.time;

import java.util.regex.Matcher;
import org.apache.wicket.util.string.StringValue;
import org.apache.wicket.util.string.StringValueConversionException;
import java.util.Locale;
import org.slf4j.Logger;
import org.apache.wicket.util.thread.ICode;
import java.util.regex.Pattern;

public class Duration extends AbstractTimeValue
{
    private static final long serialVersionUID = 1L;
    public static final Duration MAXIMUM;
    public static final Duration NONE;
    public static final Duration ONE_DAY;
    public static final Duration ONE_HOUR;
    public static final Duration ONE_MINUTE;
    public static final Duration ONE_SECOND;
    public static final Duration ONE_WEEK;
    private static final Pattern pattern;
    
    public static Duration benchmark(final ICode code, final Logger log) {
        final Time start = Time.now();
        code.run(log);
        return Time.now().subtract(start);
    }
    
    public static Duration benchmark(final Runnable code) {
        final Time start = Time.now();
        code.run();
        return Time.now().subtract(start);
    }
    
    public static Duration days(final double days) {
        return hours(24.0 * days);
    }
    
    public static Duration days(final int days) {
        return hours(24 * days);
    }
    
    public static Duration elapsed(final Time start) {
        return start.elapsedSince();
    }
    
    public static Duration hours(final double hours) {
        return minutes(60.0 * hours);
    }
    
    public static Duration hours(final int hours) {
        return minutes(60 * hours);
    }
    
    public static Duration milliseconds(final double milliseconds) {
        return milliseconds(Math.round(milliseconds));
    }
    
    public static Duration milliseconds(final long milliseconds) {
        return new Duration(milliseconds);
    }
    
    public static Duration minutes(final double minutes) {
        return seconds(60.0 * minutes);
    }
    
    public static Duration minutes(final int minutes) {
        return seconds(60 * minutes);
    }
    
    public static Duration seconds(final double seconds) {
        return milliseconds(seconds * 1000.0);
    }
    
    public static Duration seconds(final int seconds) {
        return milliseconds(seconds * 1000L);
    }
    
    public static Duration valueOf(final long time) {
        return new Duration(time);
    }
    
    public static Duration valueOf(final String string) throws StringValueConversionException {
        return valueOf(string, Locale.getDefault(Locale.Category.FORMAT));
    }
    
    public static Duration valueOf(final String string, final Locale locale) throws StringValueConversionException {
        final Matcher matcher = Duration.pattern.matcher(string);
        if (!matcher.matches()) {
            throw new StringValueConversionException("Unable to parse duration: " + string);
        }
        final double value = StringValue.valueOf(matcher.group(1), locale).toDouble();
        final String units = matcher.group(3);
        if (units.equalsIgnoreCase("millisecond")) {
            return milliseconds(value);
        }
        if (units.equalsIgnoreCase("second")) {
            return seconds(value);
        }
        if (units.equalsIgnoreCase("minute")) {
            return minutes(value);
        }
        if (units.equalsIgnoreCase("hour")) {
            return hours(value);
        }
        if (units.equalsIgnoreCase("day")) {
            return days(value);
        }
        throw new StringValueConversionException("Unrecognized units: " + string);
    }
    
    protected Duration(final long milliseconds) {
        super(milliseconds);
    }
    
    public Duration add(final Duration duration) {
        return valueOf(this.getMilliseconds() + duration.getMilliseconds());
    }
    
    public final double days() {
        return this.hours() / 24.0;
    }
    
    public final double hours() {
        return this.minutes() / 60.0;
    }
    
    public final double minutes() {
        return this.seconds() / 60.0;
    }
    
    public final double seconds() {
        return this.getMilliseconds() / 1000.0;
    }
    
    public final void sleep() {
        if (this.getMilliseconds() > 0L) {
            try {
                Thread.sleep(this.getMilliseconds());
            }
            catch (InterruptedException ex) {}
        }
    }
    
    public Duration subtract(final Duration that) {
        return valueOf(this.getMilliseconds() - that.getMilliseconds());
    }
    
    public void wait(final Object object) {
        try {
            object.wait(this.getMilliseconds());
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public String toString() {
        return this.toString(Locale.getDefault(Locale.Category.FORMAT));
    }
    
    public String toString(final Locale locale) {
        if (this.getMilliseconds() < 0L) {
            return "N/A";
        }
        if (this.days() >= 1.0) {
            return this.unitString(this.days(), "day", locale);
        }
        if (this.hours() >= 1.0) {
            return this.unitString(this.hours(), "hour", locale);
        }
        if (this.minutes() >= 1.0) {
            return this.unitString(this.minutes(), "minute", locale);
        }
        if (this.seconds() >= 1.0) {
            return this.unitString(this.seconds(), "second", locale);
        }
        return this.unitString((double)this.getMilliseconds(), "millisecond", locale);
    }
    
    private String unitString(final double value, final String units, final Locale locale) {
        return StringValue.valueOf(value, locale) + " " + units + ((value > 1.0) ? "s" : "");
    }
    
    static {
        MAXIMUM = milliseconds(Long.MAX_VALUE);
        NONE = milliseconds(0L);
        ONE_DAY = days(1);
        ONE_HOUR = hours(1);
        ONE_MINUTE = minutes(1);
        ONE_SECOND = seconds(1);
        ONE_WEEK = days(7);
        pattern = Pattern.compile("([0-9]+([.,][0-9]+)?)\\s+(millisecond|second|minute|hour|day)s?", 2);
    }
}
