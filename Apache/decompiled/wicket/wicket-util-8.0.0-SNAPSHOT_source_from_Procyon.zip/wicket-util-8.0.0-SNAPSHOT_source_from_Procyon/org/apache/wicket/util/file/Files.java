// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import org.slf4j.LoggerFactory;
import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.encoding.UrlDecoder;
import java.net.URL;
import java.io.Closeable;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.OutputStream;
import org.apache.wicket.util.io.Streams;
import java.io.FileOutputStream;
import org.apache.wicket.util.io.IOUtils;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.io.FileDeleteStrategy;
import org.apache.wicket.util.lang.Args;
import java.io.File;
import org.apache.wicket.util.string.Strings;
import org.slf4j.Logger;

public class Files
{
    private static final Logger logger;
    private static final String URL_FILE_PREFIX = "file:";
    private static final String URL_LOCAL_JAR_FILE_PREFIX = "jar:file:";
    private static final String FILENAME_FORBIDDEN_CHARACTERS = "\"*/:<>?\\|,";
    
    private Files() {
    }
    
    public static String basePath(final String path, final String extension) {
        if (extension != null) {
            return path.substring(0, path.length() - extension.length() - 1);
        }
        return path;
    }
    
    public static String extension(final String path) {
        if (path.indexOf(46) != -1) {
            return Strings.lastPathComponent(path, '.');
        }
        return null;
    }
    
    public static String filename(final String path) {
        return Strings.lastPathComponent(path.replace('/', File.separatorChar), File.separatorChar);
    }
    
    public static boolean remove(final File file) {
        if (file != null && file.isFile()) {
            for (int j = 0; j < 5; ++j) {
                for (int i = 0; i < 10; ++i) {
                    if (file.delete()) {
                        return true;
                    }
                }
                try {
                    Thread.sleep(100L);
                }
                catch (InterruptedException ix) {
                    Thread.currentThread().interrupt();
                }
            }
        }
        return false;
    }
    
    public static boolean removeFolder(final File folder) {
        if (folder == null) {
            return false;
        }
        if (folder.isDirectory()) {
            final File[] files = folder.listFiles();
            if (files != null) {
                for (final File file : files) {
                    if (file.isDirectory()) {
                        removeFolder(file);
                    }
                    else {
                        remove(file);
                    }
                }
            }
        }
        return folder.delete();
    }
    
    public static boolean removeAsync(final File file, final IFileCleaner fileCleaner) {
        if (file == null || file.isDirectory()) {
            return false;
        }
        Args.notNull(fileCleaner, "fileCleaner");
        fileCleaner.track(file, new Object());
        return true;
    }
    
    public static boolean removeFolderAsync(final File folder, final IFileCleaner fileCleaner) {
        if (folder == null || folder.isFile()) {
            return false;
        }
        Args.notNull(fileCleaner, "fileCleaner");
        fileCleaner.track(folder, new Object(), new FolderDeleteStrategy());
        return true;
    }
    
    public static int writeTo(final File file, final InputStream input) throws IOException {
        return writeTo(file, input, 4096);
    }
    
    public static byte[] readBytes(final File file) throws IOException {
        final FileInputStream stream = new FileInputStream(file);
        try {
            return IOUtils.toByteArray(stream);
        }
        finally {
            stream.close();
        }
    }
    
    public static int writeTo(final File file, final InputStream input, final int bufSize) throws IOException {
        final FileOutputStream out = new FileOutputStream(file);
        try {
            return Streams.copy(input, out, bufSize);
        }
        finally {
            out.close();
        }
    }
    
    public static String cleanupFilename(final String filename) {
        String name = filename;
        for (int i = 0; i < "\"*/:<>?\\|,".length(); ++i) {
            name = name.replace("\"*/:<>?\\|,".charAt(i), '_');
        }
        return name;
    }
    
    public static void copy(final File sourceFile, final File targetFile) throws IOException {
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        try {
            in = new BufferedInputStream(new FileInputStream(sourceFile));
            out = new BufferedOutputStream(new FileOutputStream(targetFile));
            IOUtils.copy(in, out);
        }
        finally {
            try {
                IOUtils.close(in);
            }
            finally {
                IOUtils.close(out);
            }
        }
    }
    
    public static File getLocalFileFromUrl(final URL url) {
        final URL location = Args.notNull(url, "url");
        return getLocalFileFromUrl(UrlDecoder.PATH_INSTANCE.decode(location.toExternalForm(), "UTF-8"));
    }
    
    public static File getLocalFileFromUrl(final String url) {
        final String location = Args.notNull(url, "url");
        if (location.startsWith("file:")) {
            return new File(location.substring("file:".length()));
        }
        if (!location.startsWith("jar:file:")) {
            return null;
        }
        final String path = location.substring("jar:file:".length());
        final int resourceAt = path.indexOf(33);
        if (resourceAt == -1) {
            return null;
        }
        return new File(path.substring(0, resourceAt));
    }
    
    public static Time getLastModified(final File file) {
        final long millis = file.lastModified();
        if (millis == 0L) {
            return null;
        }
        return Time.millis(millis);
    }
    
    public static boolean mkdirs(final File folder) {
        for (int j = 0; j < 5; ++j) {
            for (int i = 0; i < 10; ++i) {
                if (folder.mkdirs()) {
                    return true;
                }
            }
            try {
                Thread.sleep(100L);
                if (folder.exists()) {
                    return true;
                }
            }
            catch (InterruptedException ix) {
                Thread.currentThread().interrupt();
            }
        }
        Files.logger.error("Failed to create directory: " + folder);
        return false;
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)Files.class);
    }
}
