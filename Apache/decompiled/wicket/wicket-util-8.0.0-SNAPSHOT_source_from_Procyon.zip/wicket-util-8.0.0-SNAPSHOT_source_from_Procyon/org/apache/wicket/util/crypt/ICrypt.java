// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

public interface ICrypt
{
    String decryptUrlSafe(final String p0);
    
    String encryptUrlSafe(final String p0);
    
    void setKey(final String p0);
}
