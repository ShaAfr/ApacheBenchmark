// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Chunk extends ToString
{
    protected int anchor;
    protected int count;
    protected List<Object> chunk;
    
    public Chunk(final int pos, final int count) {
        this.anchor = pos;
        this.count = ((count >= 0) ? count : 0);
    }
    
    public Chunk(final Object[] iseq, final int pos, final int count) {
        this(pos, count);
        this.chunk = slice(iseq, pos, count);
    }
    
    public Chunk(final Object[] iseq, final int pos, final int count, final int offset) {
        this(offset, count);
        this.chunk = slice(iseq, pos, count);
    }
    
    public Chunk(final List<Object> iseq, final int pos, final int count) {
        this(pos, count);
        this.chunk = slice(iseq, pos, count);
    }
    
    public Chunk(final List<Object> iseq, final int pos, final int count, final int offset) {
        this(offset, count);
        this.chunk = slice(iseq, pos, count);
    }
    
    public int anchor() {
        return this.anchor;
    }
    
    public int size() {
        return this.count;
    }
    
    public int first() {
        return this.anchor();
    }
    
    public int last() {
        return this.anchor() + this.size() - 1;
    }
    
    public int rcsfrom() {
        return this.anchor + 1;
    }
    
    public int rcsto() {
        return this.anchor + this.count;
    }
    
    public List<Object> chunk() {
        return this.chunk;
    }
    
    public boolean verify(final List<Object> target) {
        if (this.chunk == null) {
            return true;
        }
        if (this.last() > target.size()) {
            return false;
        }
        for (int i = 0; i < this.count; ++i) {
            if (!target.get(this.anchor + i).equals(this.chunk.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    public void applyDelete(final List<Object> target) {
        for (int i = this.last(); i >= this.first(); --i) {
            target.remove(i);
        }
    }
    
    public void applyAdd(int start, final List<Object> target) {
        for (final Object aChunk : this.chunk) {
            target.add(start++, aChunk);
        }
    }
    
    @Override
    public void toString(final StringBuilder s) {
        this.toString(s, "", "");
    }
    
    public StringBuilder toString(final StringBuilder s, final String prefix, final String postfix) {
        if (this.chunk != null) {
            for (final Object aChunk : this.chunk) {
                s.append(prefix);
                s.append(aChunk);
                s.append(postfix);
            }
        }
        return s;
    }
    
    public static <T> List<T> slice(final List<T> seq, final int pos, final int count) {
        if (count <= 0) {
            return new ArrayList<T>();
        }
        return new ArrayList<T>((Collection<? extends T>)seq.subList(pos, pos + count));
    }
    
    public static List<Object> slice(final Object[] seq, final int pos, final int count) {
        return slice((List<Object>)Arrays.asList((T[])seq), pos, count);
    }
    
    public String rangeString() {
        final StringBuilder result = new StringBuilder();
        this.rangeString(result);
        return result.toString();
    }
    
    public void rangeString(final StringBuilder s) {
        this.rangeString(s, ",");
    }
    
    public void rangeString(final StringBuilder s, final String separ) {
        if (this.size() <= 1) {
            s.append(Integer.toString(this.rcsfrom()));
        }
        else {
            s.append(Integer.toString(this.rcsfrom()));
            s.append(separ);
            s.append(Integer.toString(this.rcsto()));
        }
    }
}
