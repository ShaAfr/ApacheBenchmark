// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

public interface IFixedLocationResourceStream
{
    String locationAsString();
}
