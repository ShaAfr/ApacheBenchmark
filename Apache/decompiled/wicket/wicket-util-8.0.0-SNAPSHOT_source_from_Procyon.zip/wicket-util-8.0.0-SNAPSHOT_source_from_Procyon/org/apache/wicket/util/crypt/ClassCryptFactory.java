// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

import org.slf4j.LoggerFactory;
import org.apache.wicket.util.lang.Args;
import java.lang.ref.WeakReference;
import org.slf4j.Logger;

public class ClassCryptFactory implements ICryptFactory
{
    private static final Logger log;
    private final WeakReference<Class<?>> cryptClass;
    private final String encryptionKey;
    
    public ClassCryptFactory(final Class<?> cryptClass, final String encryptionKey) {
        Args.notNull(cryptClass, "cryptClass");
        if (!ICrypt.class.isAssignableFrom(cryptClass)) {
            throw new IllegalArgumentException("cryptClass must implement ICrypt interface");
        }
        this.cryptClass = new WeakReference<Class<?>>(cryptClass);
        this.encryptionKey = encryptionKey;
    }
    
    @Override
    public ICrypt newCrypt() {
        try {
            final ICrypt crypt = this.cryptClass.get().newInstance();
            ClassCryptFactory.log.info("using encryption/decryption object {}", (Object)crypt);
            crypt.setKey(this.encryptionKey);
            return crypt;
        }
        catch (Exception e) {
            ClassCryptFactory.log.warn("************************** WARNING **************************");
            ClassCryptFactory.log.warn("As the instantiation of encryption/decryption class:");
            ClassCryptFactory.log.warn("\t" + this.cryptClass);
            ClassCryptFactory.log.warn("failed, Wicket will fallback on a dummy implementation");
            ClassCryptFactory.log.warn("\t(" + NoCrypt.class.getName() + ")");
            ClassCryptFactory.log.warn("This is NOT recommended for production systems.");
            ClassCryptFactory.log.warn("Please override method org.apache.wicket.util.crypt.ICryptFactory.newCrypt()");
            ClassCryptFactory.log.warn("to provide a custom encryption/decryption implementation.");
            ClassCryptFactory.log.warn("The cause of the instantiation failure: ");
            ClassCryptFactory.log.warn("\t" + e.getMessage());
            if (ClassCryptFactory.log.isDebugEnabled()) {
                ClassCryptFactory.log.debug("exception: ", (Throwable)e);
            }
            else {
                ClassCryptFactory.log.warn("Set log level to DEBUG to display the stack trace.");
            }
            ClassCryptFactory.log.warn("*************************************************************");
            return new NoCrypt();
        }
    }
    
    static {
        log = LoggerFactory.getLogger((Class)ClassCryptFactory.class);
    }
}
