// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.watch;

import org.apache.wicket.util.time.Time;

public interface IModifiable
{
    Time lastModifiedTime();
}
