// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.value;

import org.apache.wicket.util.lang.Primitives;
import java.io.Serializable;

public class IntValue implements Comparable<IntValue>, Serializable
{
    private static final long serialVersionUID = 1L;
    protected final int value;
    
    public IntValue(final int value) {
        this.value = value;
    }
    
    @Override
    public final int compareTo(final IntValue that) {
        if (this.value < that.value) {
            return -1;
        }
        if (this.value > that.value) {
            return 1;
        }
        return 0;
    }
    
    @Override
    public final boolean equals(final Object that) {
        return that instanceof IntValue && this.value == ((IntValue)that).value;
    }
    
    public final boolean greaterThan(final int value) {
        return this.value > value;
    }
    
    public final boolean greaterThan(final IntValue that) {
        return this.value > that.value;
    }
    
    @Override
    public final int hashCode() {
        return Primitives.hashCode(this.value);
    }
    
    public final boolean lessThan(final int that) {
        return this.value < that;
    }
    
    public final boolean lessThan(final IntValue that) {
        return this.value < that.value;
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}
