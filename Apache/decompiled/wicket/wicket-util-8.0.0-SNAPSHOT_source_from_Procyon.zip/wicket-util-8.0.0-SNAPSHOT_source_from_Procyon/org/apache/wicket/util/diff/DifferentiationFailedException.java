// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

public class DifferentiationFailedException extends DiffException
{
    private static final long serialVersionUID = 1L;
    
    public DifferentiationFailedException() {
    }
    
    public DifferentiationFailedException(final String msg) {
        super(msg);
    }
}
