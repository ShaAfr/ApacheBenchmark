// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.apache.wicket.util.lang.Bytes;
import java.nio.file.attribute.FileTime;
import java.nio.file.LinkOption;
import java.nio.file.attribute.BasicFileAttributes;
import org.apache.wicket.util.time.Time;
import java.net.URLConnection;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.io.File;
import org.apache.wicket.util.lang.Args;
import java.io.InputStream;
import java.nio.file.Path;

public class FileSystemResourceStream extends AbstractResourceStream implements IFixedLocationResourceStream
{
    private static final long serialVersionUID = 1L;
    private final Path path;
    private transient InputStream inputStream;
    
    public FileSystemResourceStream(final Path path) {
        Args.notNull(path, "path");
        this.path = path;
    }
    
    public FileSystemResourceStream(final File file) {
        Args.notNull(file, "file");
        this.path = file.toPath();
    }
    
    public FileSystemResourceStream(final org.apache.wicket.util.file.File file) {
        Args.notNull(file, "file");
        this.path = file.toPath();
    }
    
    @Override
    public InputStream getInputStream() throws ResourceStreamNotFoundException {
        if (this.inputStream == null) {
            try {
                this.inputStream = Files.newInputStream(this.path, new OpenOption[0]);
            }
            catch (IOException e) {
                throw new ResourceStreamNotFoundException("Input stream of path " + this.path + " could not be acquired", e);
            }
        }
        return this.inputStream;
    }
    
    @Override
    public void close() throws IOException {
        if (this.inputStream != null) {
            this.inputStream.close();
            this.inputStream = null;
        }
    }
    
    @Override
    public String getContentType() {
        try {
            String contentType = Files.probeContentType(this.path);
            if (contentType == null) {
                contentType = URLConnection.getFileNameMap().getContentTypeFor(this.path.getFileName().toString());
            }
            return contentType;
        }
        catch (IOException e) {
            throw new RuntimeException("Content type of path " + this.path + " could not be acquired", e);
        }
    }
    
    public final Path getPath() {
        return this.path;
    }
    
    @Override
    public Time lastModifiedTime() {
        try {
            final BasicFileAttributes attributes = Files.readAttributes(this.path, BasicFileAttributes.class, new LinkOption[0]);
            final FileTime lastModifiedTime = attributes.lastModifiedTime();
            final long millis = lastModifiedTime.toMillis();
            return Time.millis(millis);
        }
        catch (IOException e) {
            throw new RuntimeException("Modification time of path " + this.path + " could not be acquired", e);
        }
    }
    
    @Override
    public Bytes length() {
        try {
            final BasicFileAttributes attributes = Files.readAttributes(this.path, BasicFileAttributes.class, new LinkOption[0]);
            final long size = attributes.size();
            return Bytes.bytes(size);
        }
        catch (IOException e) {
            throw new RuntimeException("Length of path " + this.path + " could not be acquired", e);
        }
    }
    
    @Override
    public String locationAsString() {
        return this.path.toString();
    }
    
    @Override
    public String toString() {
        return this.locationAsString();
    }
}
