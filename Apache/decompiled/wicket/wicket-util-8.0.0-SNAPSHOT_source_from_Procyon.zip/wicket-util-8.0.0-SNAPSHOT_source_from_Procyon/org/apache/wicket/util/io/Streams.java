// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLConnection;
import org.apache.wicket.util.lang.Args;
import java.net.URL;
import java.util.Properties;
import java.io.IOException;
import java.io.Closeable;
import java.io.OutputStream;
import java.io.InputStream;

public final class Streams
{
    public static int copyAndClose(final InputStream in, final OutputStream out) throws IOException {
        try {
            return copy(in, out);
        }
        finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
        }
    }
    
    public static int copy(final InputStream in, final OutputStream out) throws IOException {
        return copy(in, out, 4096);
    }
    
    public static int copy(final InputStream in, final OutputStream out, final int bufSize) throws IOException {
        if (bufSize <= 0) {
            throw new IllegalArgumentException("The parameter 'bufSize' must not be <= 0");
        }
        final byte[] buffer = new byte[bufSize];
        int bytesCopied = 0;
        while (true) {
            final int byteCount = in.read(buffer, 0, buffer.length);
            if (byteCount <= 0) {
                break;
            }
            out.write(buffer, 0, byteCount);
            bytesCopied += byteCount;
        }
        return bytesCopied;
    }
    
    public static void loadFromXml(final Properties properties, final InputStream inputStream) throws IOException {
        if (properties == null) {
            throw new IllegalArgumentException("properties must not be null");
        }
        if (inputStream == null) {
            throw new IllegalArgumentException("inputStream must not be null");
        }
        properties.loadFromXML(inputStream);
    }
    
    public static InputStream readNonCaching(final URL url) throws IOException {
        Args.notNull(url, "url");
        final URLConnection urlConnection = url.openConnection();
        urlConnection.setUseCaches(false);
        final InputStream inputStream = urlConnection.getInputStream();
        return inputStream;
    }
    
    public static String readString(final InputStream in) throws IOException {
        return readString(new BufferedReader(new InputStreamReader(in)));
    }
    
    public static String readString(final InputStream in, final CharSequence encoding) throws IOException {
        return readString(new BufferedReader(new InputStreamReader(in, encoding.toString())));
    }
    
    public static String readString(final Reader in) throws IOException {
        final StringBuilder buffer = new StringBuilder(2048);
        int value;
        while ((value = in.read()) != -1) {
            buffer.append((char)value);
        }
        return buffer.toString();
    }
    
    private Streams() {
    }
}
