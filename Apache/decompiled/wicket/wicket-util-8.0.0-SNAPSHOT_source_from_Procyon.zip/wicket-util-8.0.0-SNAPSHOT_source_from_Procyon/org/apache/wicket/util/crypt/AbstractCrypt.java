// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.Base64;
import java.util.UUID;
import org.slf4j.Logger;

public abstract class AbstractCrypt implements ICrypt
{
    private static final String CHARACTER_ENCODING = "UTF-8";
    private static final Logger log;
    private String encryptionKey;
    
    public AbstractCrypt() {
        this.encryptionKey = UUID.randomUUID().toString();
    }
    
    @Override
    public final String decryptUrlSafe(final String text) {
        try {
            final byte[] decoded = Base64.getUrlDecoder().decode(text);
            return new String(this.decryptByteArray(decoded), "UTF-8");
        }
        catch (Exception ex) {
            AbstractCrypt.log.debug("Error decoding text: " + text, (Throwable)ex);
            return null;
        }
    }
    
    @Override
    public final String encryptUrlSafe(final String plainText) {
        try {
            final byte[] encrypted = this.encryptStringToByteArray(plainText);
            final Base64.Encoder encoder = Base64.getUrlEncoder().withoutPadding();
            final byte[] encoded = encoder.encode(encrypted);
            return new String(encoded, "UTF-8");
        }
        catch (GeneralSecurityException e) {
            AbstractCrypt.log.error("Unable to encrypt text '" + plainText + "'", (Throwable)e);
            return null;
        }
        catch (UnsupportedEncodingException e2) {
            AbstractCrypt.log.error("Unable to encrypt text '" + plainText + "'", (Throwable)e2);
            return null;
        }
    }
    
    public String getKey() {
        return this.encryptionKey;
    }
    
    @Override
    public void setKey(final String key) {
        this.encryptionKey = key;
    }
    
    protected abstract byte[] crypt(final byte[] p0, final int p1) throws GeneralSecurityException;
    
    private byte[] decryptByteArray(final byte[] encrypted) {
        try {
            return this.crypt(encrypted, 2);
        }
        catch (GeneralSecurityException e) {
            throw new RuntimeException("Unable to decrypt the text '" + new String(encrypted) + "'", e);
        }
    }
    
    private byte[] encryptStringToByteArray(final String plainText) throws GeneralSecurityException {
        try {
            return this.crypt(plainText.getBytes("UTF-8"), 1);
        }
        catch (UnsupportedEncodingException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }
    
    static {
        log = LoggerFactory.getLogger((Class)AbstractCrypt.class);
    }
}
