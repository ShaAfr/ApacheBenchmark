// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.util.Date;

public class DateConverter extends AbstractDateConverter<Date>
{
    private static final long serialVersionUID = 1L;
    
    @Override
    protected Date createDateLike(final long date) {
        return new Date(date);
    }
    
    @Override
    protected Class<Date> getTargetType() {
        return Date.class;
    }
}
