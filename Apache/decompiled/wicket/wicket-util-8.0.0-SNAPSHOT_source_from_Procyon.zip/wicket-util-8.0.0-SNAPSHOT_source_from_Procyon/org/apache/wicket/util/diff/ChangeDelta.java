// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.List;

public class ChangeDelta extends Delta
{
    ChangeDelta() {
    }
    
    public ChangeDelta(final Chunk orig, final Chunk rev) {
        this.init(orig, rev);
    }
    
    @Override
    public void verify(final List<Object> target) throws PatchFailedException {
        if (!this.original.verify(target)) {
            throw new PatchFailedException();
        }
        if (this.original.first() > target.size()) {
            throw new PatchFailedException("original.first() > target.size()");
        }
    }
    
    @Override
    public void applyTo(final List<Object> target) {
        this.original.applyDelete(target);
        this.revised.applyAdd(this.original.first(), target);
    }
    
    @Override
    public void toString(final StringBuilder s) {
        this.original.rangeString(s);
        s.append("c");
        this.revised.rangeString(s);
        s.append(Diff.NL);
        this.original.toString(s, "< ", "\n");
        s.append("---");
        s.append(Diff.NL);
        this.revised.toString(s, "> ", "\n");
    }
    
    @Override
    public void toRCSString(final StringBuilder s, final String EOL) {
        s.append("d");
        s.append(this.original.rcsfrom());
        s.append(" ");
        s.append(this.original.size());
        s.append(EOL);
        s.append("a");
        s.append(this.original.rcsto());
        s.append(" ");
        s.append(this.revised.size());
        s.append(EOL);
        this.revised.toString(s, "", EOL);
    }
    
    @Override
    public void accept(final RevisionVisitor visitor) {
        visitor.visit(this);
    }
}
