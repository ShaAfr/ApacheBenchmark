// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import java.util.Arrays;
import java.util.List;

class HtmlLicenseHeaderHandler extends XmlLicenseHeaderHandler
{
    public HtmlLicenseHeaderHandler(final List<String> ignoreFiles) {
        super(ignoreFiles);
    }
    
    @Override
    public List<String> getSuffixes() {
        return Arrays.asList("html");
    }
}
