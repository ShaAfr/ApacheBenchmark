// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.listener;

import org.slf4j.LoggerFactory;
import org.apache.wicket.util.collections.ReverseListIterator;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.List;
import org.slf4j.Logger;
import java.io.Serializable;

public abstract class ListenerCollection<T> implements Serializable, Iterable<T>
{
    private static final long serialVersionUID = 1L;
    private static final Logger logger;
    private final List<T> listeners;
    
    public ListenerCollection() {
        this.listeners = new CopyOnWriteArrayList<T>();
    }
    
    public boolean add(final T listener) {
        if (listener == null && !this.isAllowingNulls()) {
            return false;
        }
        if (!this.isAllowingDuplicates() && this.listeners.contains(listener)) {
            return false;
        }
        this.listeners.add(listener);
        return true;
    }
    
    protected void notify(final INotifier<T> notifier) {
        for (final T listener : this.listeners) {
            notifier.notify(listener);
        }
    }
    
    protected void notifyIgnoringExceptions(final INotifier<T> notifier) {
        for (final T listener : this.listeners) {
            try {
                notifier.notify(listener);
            }
            catch (Exception e) {
                ListenerCollection.logger.error("Error invoking listener: " + listener, (Throwable)e);
            }
        }
    }
    
    protected void reversedNotifyIgnoringExceptions(final INotifier<T> notifier) {
        this.reversedNotify(new INotifier<T>() {
            @Override
            public void notify(final T listener) {
                try {
                    notifier.notify(listener);
                }
                catch (Exception e) {
                    ListenerCollection.logger.error("Error invoking listener: " + listener, (Throwable)e);
                }
            }
        });
    }
    
    protected void reversedNotify(final INotifier<T> notifier) {
        final Iterator<T> it = new ReverseListIterator<T>(this.listeners);
        while (it.hasNext()) {
            final T listener = it.next();
            notifier.notify(listener);
        }
    }
    
    public void remove(final T listener) {
        this.listeners.remove(listener);
    }
    
    protected boolean isAllowingDuplicates() {
        return true;
    }
    
    protected boolean isAllowingNulls() {
        return false;
    }
    
    @Override
    public Iterator<T> iterator() {
        return this.listeners.iterator();
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)ListenerCollection.class);
    }
    
    protected interface INotifier<T>
    {
        void notify(final T p0);
    }
}
