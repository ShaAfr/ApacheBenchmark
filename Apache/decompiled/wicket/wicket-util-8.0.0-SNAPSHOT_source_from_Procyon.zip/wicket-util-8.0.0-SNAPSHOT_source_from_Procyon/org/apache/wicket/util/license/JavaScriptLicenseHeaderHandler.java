// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import java.util.Arrays;
import java.io.File;
import java.util.List;

class JavaScriptLicenseHeaderHandler extends AbstractLicenseHeaderHandler
{
    public JavaScriptLicenseHeaderHandler(final List<String> ignoreFiles) {
        super(ignoreFiles);
    }
    
    @Override
    protected String getLicenseHeaderFilename() {
        return "javaScriptLicense.txt";
    }
    
    @Override
    public boolean checkLicenseHeader(final File file) {
        final String header = this.extractLicenseHeader(file, 0, 16);
        return this.getLicenseHeader().equals(header);
    }
    
    @Override
    public List<String> getSuffixes() {
        return Arrays.asList("js", "json");
    }
    
    @Override
    public boolean addLicenseHeader(final File file) {
        this.prependLicenseHeader(file);
        return true;
    }
}
