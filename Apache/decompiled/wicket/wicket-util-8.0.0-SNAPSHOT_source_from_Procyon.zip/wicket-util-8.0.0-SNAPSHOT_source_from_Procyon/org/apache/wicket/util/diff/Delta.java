// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.List;

public abstract class Delta extends ToString
{
    protected Chunk original;
    protected Chunk revised;
    static Class<?>[][] DeltaClass;
    
    public static Delta newDelta(final Chunk orig, final Chunk rev) {
        final Class<?> c = Delta.DeltaClass[orig.size() > 0][rev.size() > 0];
        Delta result;
        try {
            result = (Delta)c.newInstance();
        }
        catch (Exception e) {
            return null;
        }
        result.init(orig, rev);
        return result;
    }
    
    protected Delta() {
    }
    
    protected Delta(final Chunk orig, final Chunk rev) {
        this.init(orig, rev);
    }
    
    protected void init(final Chunk orig, final Chunk rev) {
        this.original = orig;
        this.revised = rev;
    }
    
    public abstract void verify(final List<Object> p0) throws PatchFailedException;
    
    public final void patch(final List<Object> target) throws PatchFailedException {
        this.verify(target);
        try {
            this.applyTo(target);
        }
        catch (Exception e) {
            throw new PatchFailedException(e.getMessage());
        }
    }
    
    public abstract void applyTo(final List<Object> p0);
    
    @Override
    public void toString(final StringBuilder s) {
        this.original.rangeString(s);
        s.append("x");
        this.revised.rangeString(s);
        s.append(Diff.NL);
        this.original.toString(s, "> ", "\n");
        s.append("---");
        s.append(Diff.NL);
        this.revised.toString(s, "< ", "\n");
    }
    
    public abstract void toRCSString(final StringBuilder p0, final String p1);
    
    public String toRCSString(final String EOL) {
        final StringBuilder s = new StringBuilder();
        this.toRCSString(s, EOL);
        return s.toString();
    }
    
    public Chunk getOriginal() {
        return this.original;
    }
    
    public Chunk getRevised() {
        return this.revised;
    }
    
    public abstract void accept(final RevisionVisitor p0);
    
    static {
        Delta.DeltaClass = (Class<?>[][])new Class[2][2];
        try {
            Delta.DeltaClass[0][0] = ChangeDelta.class;
            Delta.DeltaClass[0][1] = AddDelta.class;
            Delta.DeltaClass[1][0] = DeleteDelta.class;
            Delta.DeltaClass[1][1] = ChangeDelta.class;
        }
        catch (Exception ex) {}
    }
}
