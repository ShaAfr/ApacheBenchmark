// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util;

import org.apache.wicket.util.string.PrependingStringBuffer;

public class LongEncoder
{
    public static final String DEFAULT = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
    private LongEncoder() {
    }
    
    public static String encode(final long value) {
        return encode(value, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
    }
    
    public static long decode(final String value) {
        return decode(value, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
    }
    
    public static String encode(long value, final String alphabet) {
        final int len = alphabet.length() - 1;
        final PrependingStringBuffer buff = new PrependingStringBuffer();
        final boolean negative = value < 0L;
        if (negative) {
            value = -value;
        }
        do {
            final int mod = (int)(value % len);
            buff.prepend(alphabet.charAt(mod));
            value /= len;
        } while (value > 0L);
        if (negative) {
            buff.prepend(alphabet.charAt(len));
        }
        return buff.toString();
    }
    
    public static long decode(final String value, final String alphabet) {
        final int factor = alphabet.length() - 1;
        final boolean negative = alphabet.charAt(factor) == value.charAt(0);
        long num = 0L;
        for (int i = negative ? 1 : 0, len = value.length(); i < len; ++i) {
            num = num * factor + alphabet.indexOf(value.charAt(i));
        }
        if (negative) {
            num = -num;
        }
        return num;
    }
}
