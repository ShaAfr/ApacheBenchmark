// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.List;
import java.io.IOException;
import java.util.LinkedList;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.StringReader;

public class ToString
{
    @Override
    public String toString() {
        final StringBuilder s = new StringBuilder();
        this.toString(s);
        return s.toString();
    }
    
    public void toString(final StringBuilder s) {
        s.append(super.toString());
    }
    
    public static String[] stringToArray(final String value) {
        final BufferedReader reader = new BufferedReader(new StringReader(value));
        final List<String> l = new LinkedList<String>();
        try {
            String s;
            while ((s = reader.readLine()) != null) {
                l.add(s);
            }
        }
        catch (IOException ex) {}
        return l.toArray(new String[l.size()]);
    }
    
    public static String arrayToString(final Object[] o) {
        return arrayToString(o, System.getProperty("line.separator"));
    }
    
    public static String arrayToString(final Object[] o, final String EOL) {
        final StringBuilder buf = new StringBuilder();
        for (int i = 0; i < o.length - 1; ++i) {
            buf.append(o[i]);
            buf.append(EOL);
        }
        buf.append(o[o.length - 1]);
        return buf.toString();
    }
}
