// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import org.apache.wicket.util.string.Strings;

public class Checks
{
    public static void notNull(final Object argument, final String message, final Object... params) {
        if (argument == null) {
            throw new IllegalStateException(Args.format(message, params));
        }
    }
    
    public static void notEmpty(final String argument, final String message, final Object... params) {
        if (Strings.isEmpty(argument)) {
            throw new IllegalStateException(Args.format(message, params));
        }
    }
    
    public static <T extends Comparable<? super T>> void withinRange(final T min, final T max, final T value, final String message) {
        notNull(min, message, new Object[0]);
        notNull(max, message, new Object[0]);
        if (value.compareTo((Object)min) < 0 || value.compareTo((Object)max) > 0) {
            throw new IllegalStateException(message);
        }
    }
    
    public static void notNullShort(final Object argument, final String name) {
        notNull(argument, name + " may not be null.", new Object[0]);
    }
    
    public static void notEmptyShort(final String argument, final String name) {
        notEmpty(argument, name + " may not be null or empty string.", new Object[0]);
    }
    
    public static <T extends Comparable<? super T>> void withinRangeShort(final T min, final T max, final T value, final String name) {
        withinRange(min, max, (Comparable)value, String.format("%s must have a value within [%s,%s], but was %s", name, min, max, value));
    }
}
