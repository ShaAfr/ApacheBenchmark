// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import org.slf4j.LoggerFactory;
import java.io.FileFilter;
import java.util.Iterator;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.junit.Before;
import org.apache.wicket.util.string.Strings;
import org.apache.wicket.util.lang.Generics;
import java.util.List;
import java.io.File;
import org.slf4j.Logger;
import org.junit.Assert;

public abstract class ApacheLicenseHeaderTestCase extends Assert
{
    private static final Logger log;
    private static final String LINE_ENDING;
    private ILicenseHeaderHandler[] licenseHeaderHandlers;
    private File baseDirectory;
    protected List<String> javaIgnore;
    protected List<String> htmlIgnore;
    protected List<String> xmlPrologIgnore;
    protected List<String> propertiesIgnore;
    protected List<String> xmlIgnore;
    protected List<String> cssIgnore;
    protected List<String> velocityIgnore;
    protected List<String> javaScriptIgnore;
    protected boolean addHeaders;
    
    public ApacheLicenseHeaderTestCase() {
        this.baseDirectory = new File("").getAbsoluteFile();
        this.javaIgnore = (List<String>)Generics.newArrayList();
        this.htmlIgnore = (List<String>)Generics.newArrayList();
        this.xmlPrologIgnore = (List<String>)Generics.newArrayList();
        this.propertiesIgnore = (List<String>)Generics.newArrayList();
        this.xmlIgnore = (List<String>)Generics.newArrayList();
        this.cssIgnore = (List<String>)Generics.newArrayList();
        this.velocityIgnore = (List<String>)Generics.newArrayList();
        this.javaScriptIgnore = (List<String>)Generics.newArrayList();
        this.addHeaders = false;
        this.xmlIgnore.add(".settings");
        this.xmlIgnore.add("EclipseCodeFormat.xml");
        this.xmlIgnore.add("nb-configuration.xml");
        this.htmlIgnore.add("src/test/java");
        this.propertiesIgnore.add("src/test/java");
        this.xmlPrologIgnore.add("src/test/java");
        this.xmlPrologIgnore.add("package.html");
    }
    
    @Before
    public final void before() {
        final String property = System.getProperty("basedir");
        if (!Strings.isEmpty(property)) {
            this.baseDirectory = new File(property).getAbsoluteFile();
        }
    }
    
    @Test
    public void licenseHeaders() {
        this.licenseHeaderHandlers = new ILicenseHeaderHandler[] { new JavaLicenseHeaderHandler(this.javaIgnore), new JavaScriptLicenseHeaderHandler(this.javaScriptIgnore), new XmlLicenseHeaderHandler(this.xmlIgnore), new PropertiesLicenseHeaderHandler(this.propertiesIgnore), new HtmlLicenseHeaderHandler(this.htmlIgnore), new VelocityLicenseHeaderHandler(this.velocityIgnore), new XmlPrologHeaderHandler(this.xmlPrologIgnore), new CssLicenseHeaderHandler(this.cssIgnore) };
        final Map<ILicenseHeaderHandler, List<File>> badFiles = new HashMap<ILicenseHeaderHandler, List<File>>();
        for (final ILicenseHeaderHandler licenseHeaderHandler : this.licenseHeaderHandlers) {
            this.visitFiles(licenseHeaderHandler.getSuffixes(), licenseHeaderHandler.getIgnoreFiles(), new FileVisitor() {
                @Override
                public void visitFile(final File file) {
                    if (!licenseHeaderHandler.checkLicenseHeader(file) && (!ApacheLicenseHeaderTestCase.this.addHeaders || !licenseHeaderHandler.addLicenseHeader(file))) {
                        List<File> files = badFiles.get(licenseHeaderHandler);
                        if (files == null) {
                            files = new ArrayList<File>();
                            badFiles.put(licenseHeaderHandler, files);
                        }
                        files.add(file);
                    }
                }
            });
        }
        this.failIncorrectLicenceHeaders(badFiles);
    }
    
    private void failIncorrectLicenceHeaders(final Map<ILicenseHeaderHandler, List<File>> files) {
        if (files.size() > 0) {
            final StringBuilder failString = new StringBuilder();
            for (final Map.Entry<ILicenseHeaderHandler, List<File>> entry : files.entrySet()) {
                final ILicenseHeaderHandler licenseHeaderHandler = entry.getKey();
                final List<File> fileList = entry.getValue();
                failString.append('\n');
                failString.append(licenseHeaderHandler.getClass().getName());
                failString.append(" failed. The following files(");
                failString.append(fileList.size());
                failString.append(") didn't have correct license header:\n");
                for (final File file : fileList) {
                    final String filename = file.getAbsolutePath();
                    final String licenseType = licenseHeaderHandler.getLicenseType(file);
                    if (licenseType == null) {
                        failString.append("NONE");
                    }
                    else {
                        failString.append(licenseType);
                    }
                    failString.append(' ').append(filename).append(ApacheLicenseHeaderTestCase.LINE_ENDING);
                }
            }
            System.out.println(failString);
            fail(failString.toString());
        }
    }
    
    private void visitFiles(final List<String> suffixes, final List<String> ignoreFiles, final FileVisitor fileVisitor) {
        this.visitDirectory(suffixes, ignoreFiles, this.baseDirectory, fileVisitor);
    }
    
    private void visitDirectory(final List<String> suffixes, final List<String> ignoreFiles, final File directory, final FileVisitor fileVisitor) {
        File[] files = directory.listFiles(new SuffixAndIgnoreFileFilter((List)suffixes, (List)ignoreFiles));
        if (files != null) {
            for (final File file : files) {
                fileVisitor.visitFile(file);
            }
        }
        files = directory.listFiles(new DirectoryFileFilter());
        if (files != null) {
            for (final File childDirectory : files) {
                this.visitDirectory(suffixes, ignoreFiles, childDirectory, fileVisitor);
            }
        }
    }
    
    static {
        log = LoggerFactory.getLogger((Class)ApacheLicenseHeaderTestCase.class);
        LINE_ENDING = System.getProperty("line.separator");
    }
    
    private class SuffixAndIgnoreFileFilter implements FileFilter
    {
        private final List<String> suffixes;
        private final List<String> ignoreFiles;
        
        private SuffixAndIgnoreFileFilter(final List<String> suffixes, final List<String> ignoreFiles) {
            this.suffixes = suffixes;
            this.ignoreFiles = ignoreFiles;
        }
        
        @Override
        public boolean accept(final File pathname) {
            boolean accept = false;
            if (pathname.isFile()) {
                if (!this.ignoreFile(pathname)) {
                    for (final String suffix : this.suffixes) {
                        if (pathname.getName().endsWith("." + suffix)) {
                            accept = true;
                            break;
                        }
                        ApacheLicenseHeaderTestCase.log.debug("File ignored: '{}'", (Object)pathname);
                    }
                }
                else {
                    ApacheLicenseHeaderTestCase.log.debug("File ignored: '{}'", (Object)pathname);
                }
            }
            return accept;
        }
        
        private boolean ignoreFile(final File pathname) {
            boolean ignore = false;
            if (this.ignoreFiles != null) {
                String relativePathname = pathname.getAbsolutePath();
                relativePathname = Strings.replaceAll(relativePathname, ApacheLicenseHeaderTestCase.this.baseDirectory.getAbsolutePath() + System.getProperty("file.separator"), "").toString();
                for (String ignorePath : this.ignoreFiles) {
                    ignorePath = Strings.replaceAll(ignorePath, "/", System.getProperty("file.separator")).toString();
                    final File ignoreFile = new File(ApacheLicenseHeaderTestCase.this.baseDirectory, ignorePath);
                    if (ignoreFile.isDirectory()) {
                        if (pathname.getAbsolutePath().startsWith(ignoreFile.getAbsolutePath())) {
                            ignore = true;
                            break;
                        }
                        continue;
                    }
                    else if (ignoreFile.isFile()) {
                        if (relativePathname.equals(ignorePath)) {
                            ignore = true;
                            break;
                        }
                        continue;
                    }
                    else {
                        if (pathname.getName().equals(ignorePath)) {
                            ignore = true;
                            break;
                        }
                        continue;
                    }
                }
            }
            return ignore;
        }
    }
    
    private class DirectoryFileFilter implements FileFilter
    {
        private final String[] ignoreDirectory;
        
        private DirectoryFileFilter() {
            this.ignoreDirectory = new String[] { ".git" };
        }
        
        @Override
        public boolean accept(final File pathname) {
            boolean accept = false;
            if (pathname.isDirectory()) {
                String relativePathname = pathname.getAbsolutePath();
                relativePathname = Strings.replaceAll(relativePathname, ApacheLicenseHeaderTestCase.this.baseDirectory.getAbsolutePath() + System.getProperty("file.separator"), "").toString();
                if (!"target".equals(relativePathname)) {
                    boolean found = false;
                    for (final String ignore : this.ignoreDirectory) {
                        if (pathname.getName().equals(ignore)) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        accept = true;
                    }
                }
            }
            return accept;
        }
    }
    
    interface FileVisitor
    {
        void visitFile(final File p0);
    }
}
