// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import java.io.IOException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.Closeable;
import org.apache.wicket.util.io.IOUtils;
import org.junit.Assert;
import java.io.Reader;
import java.io.LineNumberReader;
import java.io.InputStreamReader;
import org.apache.wicket.util.string.Strings;
import java.io.File;
import java.util.List;

abstract class AbstractLicenseHeaderHandler implements ILicenseHeaderHandler
{
    protected static final String LINE_ENDING;
    private String licenseHeader;
    private final List<String> ignoreFiles;
    
    public AbstractLicenseHeaderHandler(final List<String> ignoreFiles) {
        this.ignoreFiles = ignoreFiles;
    }
    
    @Override
    public List<String> getIgnoreFiles() {
        return this.ignoreFiles;
    }
    
    @Override
    public boolean addLicenseHeader(final File file) {
        System.out.println("Not supported yet.");
        return false;
    }
    
    @Override
    public String getLicenseType(final File file) {
        return null;
    }
    
    protected abstract String getLicenseHeaderFilename();
    
    protected String getLicenseHeader() {
        if (Strings.isEmpty(this.licenseHeader)) {
            LineNumberReader lineNumberReader = null;
            InputStream inputStream = null;
            InputStreamReader inputStreamReader = null;
            try {
                inputStream = ApacheLicenseHeaderTestCase.class.getResourceAsStream(this.getLicenseHeaderFilename());
                inputStreamReader = new InputStreamReader(inputStream);
                lineNumberReader = new LineNumberReader(inputStreamReader);
                final StringBuilder header = new StringBuilder();
                for (String line = lineNumberReader.readLine(); line != null; line = lineNumberReader.readLine()) {
                    header.append(line);
                    header.append(AbstractLicenseHeaderHandler.LINE_ENDING);
                }
                this.licenseHeader = header.toString().trim();
            }
            catch (Exception e) {
                Assert.fail(e.getMessage());
            }
            finally {
                IOUtils.closeQuietly(lineNumberReader);
                IOUtils.closeQuietly(inputStream);
                IOUtils.closeQuietly(inputStreamReader);
            }
        }
        return this.licenseHeader;
    }
    
    protected String extractLicenseHeader(final File file, final int start, final int length) {
        final StringBuilder header = new StringBuilder();
        LineNumberReader lineNumberReader = null;
        try {
            final FileReader fileReader = new FileReader(file);
            lineNumberReader = new LineNumberReader(fileReader);
            for (int i = start; i < length; ++i) {
                header.append(lineNumberReader.readLine());
                header.append(AbstractLicenseHeaderHandler.LINE_ENDING);
            }
        }
        catch (Exception e) {
            Assert.fail(e.getMessage());
            try {
                IOUtils.close(lineNumberReader);
            }
            catch (IOException e2) {
                Assert.fail(e2.getMessage());
            }
        }
        finally {
            try {
                IOUtils.close(lineNumberReader);
            }
            catch (IOException e3) {
                Assert.fail(e3.getMessage());
            }
        }
        return header.toString().trim();
    }
    
    protected void prependLicenseHeader(final File file) {
        try {
            String content = new org.apache.wicket.util.file.File(file).readString();
            content = this.getLicenseHeader() + AbstractLicenseHeaderHandler.LINE_ENDING + content;
            new org.apache.wicket.util.file.File(file).write(content);
        }
        catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }
    
    static {
        LINE_ENDING = System.getProperty("line.separator");
    }
}
