// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

public interface ICryptFactory
{
    ICrypt newCrypt();
}
