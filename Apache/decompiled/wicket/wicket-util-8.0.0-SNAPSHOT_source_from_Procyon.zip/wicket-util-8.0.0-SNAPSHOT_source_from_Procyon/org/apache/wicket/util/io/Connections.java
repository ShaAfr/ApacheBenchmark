// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.net.HttpURLConnection;
import java.io.IOException;
import java.net.URLConnection;
import java.io.File;
import java.net.JarURLConnection;
import org.apache.wicket.util.file.Files;
import org.apache.wicket.util.time.Time;
import java.net.URL;

public class Connections
{
    private Connections() {
    }
    
    public static Time getLastModified(final URL url) throws IOException {
        final File file = Files.getLocalFileFromUrl(url);
        if (file != null) {
            return Files.getLastModified(file);
        }
        final URLConnection connection = url.openConnection();
        try {
            long milliseconds;
            if (connection instanceof JarURLConnection) {
                final JarURLConnection jarUrlConnection = (JarURLConnection)connection;
                final URL jarFileUrl = jarUrlConnection.getJarFileURL();
                final URLConnection jarFileConnection = jarFileUrl.openConnection();
                jarFileConnection.setDoInput(false);
                milliseconds = jarFileConnection.getLastModified();
            }
            else {
                milliseconds = connection.getLastModified();
            }
            if (milliseconds == 0L) {
                return null;
            }
            return Time.millis(milliseconds);
        }
        finally {
            closeQuietly(connection);
        }
    }
    
    public static void closeQuietly(final URLConnection connection) {
        try {
            close(connection);
        }
        catch (Exception ex) {}
    }
    
    public static void close(final URLConnection connection) throws IOException {
        if (connection == null) {
            return;
        }
        final String protocol = connection.getURL().getProtocol();
        if ("file".equals(protocol)) {
            connection.getInputStream().close();
        }
        if (connection instanceof HttpURLConnection) {
            ((HttpURLConnection)connection).disconnect();
        }
    }
}
