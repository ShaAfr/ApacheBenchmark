// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import java.io.ObjectStreamException;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.wicket.util.string.StringValue;

public abstract class EnumeratedType extends StringValue
{
    private static final long serialVersionUID = 1L;
    private static final Map<String, List<EnumeratedType>> valueListByClass;
    
    public EnumeratedType(final String name) {
        super(name);
        getValues(this.getClass()).add(this);
    }
    
    public static List<EnumeratedType> getValues(final Class<? extends EnumeratedType> c) {
        List<EnumeratedType> valueList = EnumeratedType.valueListByClass.get(c.getName());
        if (valueList == null) {
            valueList = new ArrayList<EnumeratedType>();
            EnumeratedType.valueListByClass.put(c.getName(), valueList);
        }
        return valueList;
    }
    
    public Object readResolve() throws ObjectStreamException {
        EnumeratedType result = this;
        final List<EnumeratedType> values = getValues(this.getClass());
        for (final EnumeratedType value : values) {
            if (value.toString() != null && value.toString().equals(this.toString())) {
                result = value;
                break;
            }
        }
        return result;
    }
    
    static {
        valueListByClass = Generics.newConcurrentHashMap();
    }
}
