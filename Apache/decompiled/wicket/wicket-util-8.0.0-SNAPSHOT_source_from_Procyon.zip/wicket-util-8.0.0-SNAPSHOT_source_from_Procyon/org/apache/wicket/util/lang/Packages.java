// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import org.apache.wicket.util.string.StringList;

public final class Packages
{
    public static String absolutePath(final Class<?> p, final String path) {
        final String packName = (p != null) ? extractPackageName(p) : "";
        return absolutePath(packName, path);
    }
    
    public static String absolutePath(final Package p, final String relativePath) {
        return absolutePath(p.getName(), relativePath);
    }
    
    public static String absolutePath(final String packageName, final String path) {
        if (path.startsWith("/")) {
            return path.substring(1);
        }
        final StringList absolutePath = StringList.tokenize(packageName, ".");
        final StringList folders = StringList.tokenize(path, "/\\");
        for (int i = 0, size = folders.size(); i < size; ++i) {
            final String folder = folders.get(i);
            if ("..".equals(folder)) {
                if (absolutePath.size() <= 0) {
                    throw new IllegalArgumentException("Invalid path " + path);
                }
                absolutePath.removeLast();
            }
            else {
                absolutePath.add(folder);
            }
        }
        return absolutePath.join("/");
    }
    
    public static String extractPackageName(final Class<?> forClass) {
        return parent(forClass.getName());
    }
    
    public static String parent(final String packageName) {
        int pos = packageName.lastIndexOf(".");
        if (pos < 0) {
            pos = packageName.lastIndexOf("/");
            if (pos < 0) {
                pos = 0;
            }
        }
        final String parent = packageName.substring(0, pos);
        return parent;
    }
    
    public static String resolveScope(final Class<?> forClass) {
        final String packName = extractPackageName(forClass);
        return packName.replace('.', '/');
    }
    
    private Packages() {
    }
}
