// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.value;

import java.util.Map;

public final class AttributeMap extends ValueMap
{
    private static final long serialVersionUID = 1L;
    
    public AttributeMap() {
    }
    
    public AttributeMap(final Map<String, Object> map) {
        super(map);
    }
}
