// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import org.apache.wicket.util.convert.IConverter;
import java.math.BigDecimal;

public class FloatConverter extends AbstractDecimalConverter<Float>
{
    private static final long serialVersionUID = 1L;
    private static final BigDecimal MIN_VALUE;
    private static final BigDecimal MAX_VALUE;
    public static final IConverter<Float> INSTANCE;
    
    @Override
    public Float convertToObject(final String value, final Locale locale) {
        final BigDecimal number = this.parse(value, FloatConverter.MIN_VALUE, FloatConverter.MAX_VALUE, locale);
        if (number == null) {
            return null;
        }
        return number.floatValue();
    }
    
    @Override
    protected Class<Float> getTargetType() {
        return Float.class;
    }
    
    static {
        MIN_VALUE = new BigDecimal(-3.4028234663852886E38);
        MAX_VALUE = new BigDecimal(3.4028234663852886E38);
        INSTANCE = new FloatConverter();
    }
}
