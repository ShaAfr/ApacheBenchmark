// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.AbstractList;
import java.util.Collection;
import java.util.NoSuchElementException;
import java.util.AbstractSet;
import java.util.Set;
import java.util.Iterator;
import java.io.Serializable;
import java.util.Map;

public class MiniMap<K, V> implements Map<K, V>, Serializable
{
    private static final long serialVersionUID = 1L;
    private final K[] keys;
    private final V[] values;
    private int size;
    private int lastSearchIndex;
    
    public MiniMap(final int maxEntries) {
        this.keys = (K[])new Object[maxEntries];
        this.values = (V[])new Object[maxEntries];
    }
    
    public MiniMap(final Map<? extends K, ? extends V> map, final int maxEntries) {
        this(maxEntries);
        this.putAll(map);
    }
    
    public boolean isFull() {
        return this.size == this.keys.length;
    }
    
    @Override
    public int size() {
        return this.size;
    }
    
    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }
    
    @Override
    public boolean containsKey(final Object key) {
        return this.findKey(0, key) != -1;
    }
    
    @Override
    public boolean containsValue(final Object value) {
        return this.findValue(0, value) != -1;
    }
    
    @Override
    public V get(final Object key) {
        final int index = this.findKey(key);
        if (index != -1) {
            return this.values[index];
        }
        return null;
    }
    
    @Override
    public V put(final K key, final V value) {
        final int index = this.findKey(key);
        if (index != -1) {
            final V oldValue = this.values[index];
            this.values[index] = value;
            return oldValue;
        }
        if (this.size < this.keys.length) {
            final int nullIndex = this.nextNullKey(this.lastSearchIndex);
            this.lastSearchIndex = this.nextIndex(nullIndex);
            this.keys[nullIndex] = key;
            this.values[nullIndex] = value;
            ++this.size;
            return null;
        }
        throw new IllegalStateException("Map full");
    }
    
    @Override
    public V remove(final Object key) {
        final int index = this.findKey(key);
        if (index != -1) {
            final V oldValue = this.values[index];
            this.keys[index] = null;
            this.values[index] = null;
            --this.size;
            return oldValue;
        }
        return null;
    }
    
    @Override
    public void putAll(final Map<? extends K, ? extends V> map) {
        for (final Entry<? extends K, ? extends V> entry : map.entrySet()) {
            this.put(entry.getKey(), entry.getValue());
        }
    }
    
    @Override
    public void clear() {
        for (int i = 0; i < this.keys.length; ++i) {
            this.keys[i] = null;
            this.values[i] = null;
        }
        this.size = 0;
    }
    
    @Override
    public Set<K> keySet() {
        return new AbstractSet<K>() {
            @Override
            public Iterator<K> iterator() {
                return new Iterator<K>() {
                    int i = -1;
                    
                    @Override
                    public boolean hasNext() {
                        return this.i < MiniMap.this.size - 1;
                    }
                    
                    @Override
                    public K next() {
                        if (!this.hasNext()) {
                            throw new NoSuchElementException();
                        }
                        this.i = MiniMap.this.nextKey(MiniMap.this.nextIndex(this.i));
                        return MiniMap.this.keys[this.i];
                    }
                    
                    @Override
                    public void remove() {
                        MiniMap.this.keys[this.i] = null;
                        MiniMap.this.values[this.i] = null;
                        MiniMap.this.size--;
                    }
                };
            }
            
            @Override
            public int size() {
                return MiniMap.this.size;
            }
        };
    }
    
    @Override
    public Collection<V> values() {
        return new AbstractList<V>() {
            @Override
            public V get(final int index) {
                if (index > MiniMap.this.size - 1) {
                    throw new IndexOutOfBoundsException();
                }
                int keyIndex = MiniMap.this.nextKey(0);
                for (int i = 0; i < index; ++i) {
                    keyIndex = MiniMap.this.nextKey(keyIndex + 1);
                }
                return MiniMap.this.values[keyIndex];
            }
            
            @Override
            public int size() {
                return MiniMap.this.size;
            }
        };
    }
    
    @Override
    public Set<Entry<K, V>> entrySet() {
        return new AbstractSet<Entry<K, V>>() {
            @Override
            public Iterator<Entry<K, V>> iterator() {
                return new Iterator<Entry<K, V>>() {
                    int keyIndex = -1;
                    int index = 0;
                    
                    @Override
                    public boolean hasNext() {
                        return this.index < MiniMap.this.size;
                    }
                    
                    @Override
                    public Entry<K, V> next() {
                        if (!this.hasNext()) {
                            throw new NoSuchElementException();
                        }
                        this.keyIndex = MiniMap.this.nextKey(MiniMap.this.nextIndex(this.keyIndex));
                        ++this.index;
                        return new Entry<K, V>() {
                            @Override
                            public K getKey() {
                                return MiniMap.this.keys[Iterator.this.keyIndex];
                            }
                            
                            @Override
                            public V getValue() {
                                return MiniMap.this.values[Iterator.this.keyIndex];
                            }
                            
                            @Override
                            public V setValue(final V value) {
                                final V oldValue = MiniMap.this.values[Iterator.this.keyIndex];
                                MiniMap.this.values[Iterator.this.keyIndex] = value;
                                return oldValue;
                            }
                        };
                    }
                    
                    @Override
                    public void remove() {
                        MiniMap.this.keys[this.keyIndex] = null;
                        MiniMap.this.values[this.keyIndex] = null;
                    }
                };
            }
            
            @Override
            public int size() {
                return MiniMap.this.size;
            }
        };
    }
    
    private int nextIndex(final int index) {
        return (index + 1) % this.keys.length;
    }
    
    private int nextKey(final int start) {
        int i = start;
        while (this.keys[i] == null) {
            i = this.nextIndex(i);
            if (i == start) {
                return -1;
            }
        }
        return i;
    }
    
    private int nextNullKey(final int start) {
        int i = start;
        while (this.keys[i] != null) {
            i = this.nextIndex(i);
            if (i == start) {
                return -1;
            }
        }
        return i;
    }
    
    private int findKey(final Object key) {
        if (this.size > 0) {
            final int index = this.findKey(this.lastSearchIndex, key);
            if (index != -1) {
                this.lastSearchIndex = this.nextIndex(index);
                return index;
            }
        }
        return -1;
    }
    
    private int findKey(final int start, final Object key) {
        int i = start;
        while (!key.equals(this.keys[i])) {
            i = this.nextIndex(i);
            if (i == start) {
                return -1;
            }
        }
        return i;
    }
    
    private int findValue(final int start, final Object value) {
        int i = start;
        while (!value.equals(this.values[i])) {
            i = this.nextIndex(i);
            if (i == start) {
                return -1;
            }
        }
        return i;
    }
}
