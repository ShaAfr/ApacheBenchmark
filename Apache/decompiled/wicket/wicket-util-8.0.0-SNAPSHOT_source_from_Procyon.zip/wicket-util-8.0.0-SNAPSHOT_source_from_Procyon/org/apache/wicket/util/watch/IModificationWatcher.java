// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.watch;

import java.util.Set;
import org.apache.wicket.util.time.Duration;
import org.apache.wicket.util.listener.IChangeListener;

public interface IModificationWatcher
{
    boolean add(final IModifiable p0, final IChangeListener<IModifiable> p1);
    
    IModifiable remove(final IModifiable p0);
    
    void start(final Duration p0);
    
    void destroy();
    
    Set<IModifiable> getEntries();
}
