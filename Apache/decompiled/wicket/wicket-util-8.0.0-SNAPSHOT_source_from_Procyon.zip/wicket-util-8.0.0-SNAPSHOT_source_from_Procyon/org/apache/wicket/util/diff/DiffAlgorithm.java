// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

public interface DiffAlgorithm
{
    Revision diff(final Object[] p0, final Object[] p1) throws DifferentiationFailedException;
}
