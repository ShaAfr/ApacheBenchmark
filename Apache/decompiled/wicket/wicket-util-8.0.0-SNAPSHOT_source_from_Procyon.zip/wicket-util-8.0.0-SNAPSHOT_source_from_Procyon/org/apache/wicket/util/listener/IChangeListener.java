// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.listener;

@FunctionalInterface
public interface IChangeListener<T>
{
    void onChange(final T p0);
}
