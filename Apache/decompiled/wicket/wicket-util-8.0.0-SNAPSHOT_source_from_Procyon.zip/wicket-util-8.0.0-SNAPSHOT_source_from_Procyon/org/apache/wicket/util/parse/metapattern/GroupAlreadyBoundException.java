// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern;

public final class GroupAlreadyBoundException extends RuntimeException
{
    private static final long serialVersionUID = 1L;
}
