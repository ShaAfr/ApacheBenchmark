// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.time.format.FormatStyle;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAccessor;
import java.time.format.DateTimeFormatter;
import java.time.ZonedDateTime;

public class ZonedDateTimeConverter extends AbstractJavaTimeConverter<ZonedDateTime>
{
    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter DATE_TIME_FORMATTER;
    
    @Override
    protected Class<ZonedDateTime> getTargetType() {
        return ZonedDateTime.class;
    }
    
    @Override
    protected ZonedDateTime createTemporal(final TemporalAccessor temporalAccessor) {
        return ZonedDateTime.from(temporalAccessor);
    }
    
    @Override
    protected DateTimeFormatter getDateTimeFormatter() {
        return ZonedDateTimeConverter.DATE_TIME_FORMATTER;
    }
    
    static {
        DATE_TIME_FORMATTER = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.FULL);
    }
}
