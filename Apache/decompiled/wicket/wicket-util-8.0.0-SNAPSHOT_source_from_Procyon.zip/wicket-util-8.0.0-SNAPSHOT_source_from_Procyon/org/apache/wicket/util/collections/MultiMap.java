// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import java.util.HashMap;

public class MultiMap<K, V> extends HashMap<K, List<V>>
{
    private static final long serialVersionUID = 1L;
    
    public MultiMap() {
    }
    
    public MultiMap(final int initialCapacity, final float loadFactor) {
        super(initialCapacity, loadFactor);
    }
    
    public MultiMap(final int initialCapacity) {
        super(initialCapacity);
    }
    
    public MultiMap(final Map<? extends K, ? extends List<V>> m) {
        super(m);
    }
    
    public void addValue(final K key, final V value) {
        List<V> list = this.get(key);
        if (list == null) {
            list = new ArrayList<V>(1);
            this.put(key, list);
        }
        list.add(value);
    }
    
    public void removeValue(final K key, final V value) {
        final List<V> list = this.get(key);
        if (list != null) {
            list.remove(value);
        }
    }
    
    public void replaceValues(final K key, final V value) {
        final List<V> list = this.get(key);
        if (list != null) {
            list.clear();
            list.add(value);
        }
        else {
            this.addValue(key, value);
        }
    }
    
    public V getFirstValue(final K key) {
        final List<V> list = this.get(key);
        if (list != null && !list.isEmpty()) {
            return list.get(0);
        }
        return null;
    }
}
