// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.visit;

public interface IVisitFilter
{
    public static final IVisitFilter ANY = new IVisitFilter() {
        @Override
        public boolean visitObject(final Object object) {
            return true;
        }
        
        @Override
        public boolean visitChildren(final Object object) {
            return true;
        }
    };
    
    boolean visitObject(final Object p0);
    
    boolean visitChildren(final Object p0);
}
