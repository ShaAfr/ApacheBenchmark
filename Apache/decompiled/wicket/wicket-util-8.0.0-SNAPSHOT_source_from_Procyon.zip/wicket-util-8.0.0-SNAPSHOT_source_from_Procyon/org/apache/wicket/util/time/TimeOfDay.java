// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.time;

import org.apache.wicket.util.lang.EnumeratedType;
import org.apache.wicket.util.value.LongValue;
import java.text.ParseException;
import java.util.Calendar;

public final class TimeOfDay extends AbstractTime
{
    private static final long serialVersionUID = 1L;
    public static final Meridian AM;
    public static final TimeOfDay MIDNIGHT;
    public static final Meridian PM;
    public static final TimeOfDay NOON;
    
    public static TimeOfDay militaryTime(final int hour, final int minute, final int second) {
        if (hour > 23 || hour < 0) {
            throw new IllegalArgumentException("Hour " + hour + " is not valid");
        }
        if (minute > 59 || minute < 0) {
            throw new IllegalArgumentException("Minute " + minute + " is not valid");
        }
        if (second > 59 || second < 0) {
            throw new IllegalArgumentException("Second " + second + " is not valid");
        }
        return valueOf(Duration.hours(hour).add(Duration.minutes(minute)).add(Duration.seconds(second)));
    }
    
    public static TimeOfDay now() {
        return valueOf(Time.now());
    }
    
    public static TimeOfDay now(final Calendar calendar) {
        return valueOf(calendar, Time.now());
    }
    
    public static TimeOfDay time(final int hour, final int minute, final int second, final Meridian meridian) {
        if (meridian == TimeOfDay.PM) {
            if (hour == 12) {
                return militaryTime(12, minute, second);
            }
            return militaryTime(hour + 12, minute, second);
        }
        else {
            if (hour == 12) {
                return militaryTime(0, minute, second);
            }
            return militaryTime(hour, minute, second);
        }
    }
    
    public static TimeOfDay time(final int hour, final int minute, final Meridian meridian) {
        return time(hour, minute, 0, meridian);
    }
    
    public static TimeOfDay valueOf(final Calendar calendar, final String time) throws ParseException {
        synchronized (TimeOfDay.timeFormat) {
            synchronized (calendar) {
                TimeOfDay.timeFormat.setCalendar(calendar);
                return new TimeOfDay(TimeOfDay.timeFormat.parse(time).getTime());
            }
        }
    }
    
    public static TimeOfDay valueOf(final Calendar calendar, final Time time) {
        return militaryTime(time.getHour(calendar), time.getMinute(calendar), time.getSecond(calendar));
    }
    
    public static TimeOfDay valueOf(final Duration duration) {
        return new TimeOfDay(duration.getMilliseconds());
    }
    
    public static TimeOfDay valueOf(final long time) {
        return new TimeOfDay(time);
    }
    
    public static TimeOfDay valueOf(final String time) throws ParseException {
        return valueOf(TimeOfDay.localtime, time);
    }
    
    public static TimeOfDay valueOf(final Time time) {
        return valueOf(AbstractTime.localtime, time);
    }
    
    private TimeOfDay(final long time) {
        super(time);
        if (Duration.valueOf(time).greaterThan(Duration.ONE_DAY)) {
            throw new IllegalArgumentException("Time " + this + " is not a time of day value");
        }
    }
    
    public int hour() {
        return this.toHours(this.getMilliseconds());
    }
    
    public int minute() {
        return this.toMinutes(this.getMilliseconds()) % 60;
    }
    
    public Time next() {
        return this.next(AbstractTime.localtime);
    }
    
    public Time next(final Calendar calendar) {
        final Time timeToday = Time.valueOf(calendar, this);
        if (timeToday.before(Time.now())) {
            return Time.valueOf(calendar, this).add(Duration.ONE_DAY);
        }
        return timeToday;
    }
    
    public int second() {
        return this.toSeconds(this.getMilliseconds()) % 60;
    }
    
    @Override
    public String toString() {
        final int second = this.second();
        return "" + this.hour() + ":" + this.minute() + ((second != 0) ? (":" + second) : "");
    }
    
    private int toHours(final long milliseconds) {
        return this.toMinutes(milliseconds) / 60;
    }
    
    private int toMinutes(final long milliseconds) {
        return this.toSeconds(milliseconds) / 60;
    }
    
    private int toSeconds(final long milliseconds) {
        return (int)(milliseconds / 1000L);
    }
    
    static {
        AM = new Meridian("AM");
        MIDNIGHT = time(12, 0, TimeOfDay.AM);
        PM = new Meridian("PM");
        NOON = time(12, 0, TimeOfDay.PM);
    }
    
    public static final class Meridian extends EnumeratedType
    {
        private static final long serialVersionUID = 1L;
        
        Meridian(final String name) {
            super(name);
        }
    }
}
