// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.thread;

import org.slf4j.Logger;

@FunctionalInterface
public interface ICode
{
    void run(final Logger p0);
}
