// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.visit;

@FunctionalInterface
public interface IVisitor<T, R>
{
    void component(final T p0, final IVisit<R> p1);
}
