// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.time.format.FormatStyle;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAccessor;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class LocalDateTimeConverter extends AbstractJavaTimeConverter<LocalDateTime>
{
    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter DATE_TIME_FORMATTER;
    
    @Override
    protected Class<LocalDateTime> getTargetType() {
        return LocalDateTime.class;
    }
    
    @Override
    protected LocalDateTime createTemporal(final TemporalAccessor temporalAccessor) {
        return LocalDateTime.from(temporalAccessor);
    }
    
    @Override
    protected DateTimeFormatter getDateTimeFormatter() {
        return LocalDateTimeConverter.DATE_TIME_FORMATTER;
    }
    
    static {
        DATE_TIME_FORMATTER = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
    }
}
