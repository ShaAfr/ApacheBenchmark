// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import org.apache.wicket.util.convert.IConverter;
import java.math.BigDecimal;

public class LongConverter extends AbstractIntegerConverter<Long>
{
    private static final long serialVersionUID = 1L;
    private static final BigDecimal MIN_VALUE;
    private static final BigDecimal MAX_VALUE;
    public static final IConverter<Long> INSTANCE;
    
    @Override
    public Long convertToObject(final String value, final Locale locale) {
        final BigDecimal number = this.parse(value, LongConverter.MIN_VALUE, LongConverter.MAX_VALUE, locale);
        if (number == null) {
            return null;
        }
        return number.longValue();
    }
    
    @Override
    protected Class<Long> getTargetType() {
        return Long.class;
    }
    
    static {
        MIN_VALUE = new BigDecimal(Long.MIN_VALUE);
        MAX_VALUE = new BigDecimal(Long.MAX_VALUE);
        INSTANCE = new LongConverter();
    }
}
