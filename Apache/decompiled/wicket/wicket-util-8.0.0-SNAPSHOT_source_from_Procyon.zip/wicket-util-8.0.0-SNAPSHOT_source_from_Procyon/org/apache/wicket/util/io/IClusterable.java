// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.io.Serializable;

public interface IClusterable extends Serializable
{
}
