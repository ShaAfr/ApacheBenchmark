// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import java.util.regex.Matcher;
import org.apache.wicket.util.string.Strings;
import java.util.Arrays;
import org.apache.wicket.util.diff.Revision;
import org.junit.Assert;
import org.apache.wicket.util.diff.Diff;
import java.io.File;
import java.util.List;
import java.util.regex.Pattern;

class XmlLicenseHeaderHandler extends AbstractLicenseHeaderHandler
{
    private final Pattern xmlHeader;
    
    public XmlLicenseHeaderHandler(final List<String> ignoreFiles) {
        super(ignoreFiles);
        this.xmlHeader = Pattern.compile("^(\\<\\?xml[^" + XmlLicenseHeaderHandler.LINE_ENDING + "]+?)" + XmlLicenseHeaderHandler.LINE_ENDING + "(.*)$", 40);
    }
    
    @Override
    protected String getLicenseHeaderFilename() {
        return "xmlLicense.txt";
    }
    
    @Override
    public boolean checkLicenseHeader(final File file) {
        Revision revision = null;
        try {
            String header = this.extractLicenseHeader(file, 0, 17);
            if (header.startsWith("<?xml")) {
                header = header.substring(header.indexOf(XmlLicenseHeaderHandler.LINE_ENDING) + XmlLicenseHeaderHandler.LINE_ENDING.length());
            }
            else {
                final String[] headers = header.split(XmlLicenseHeaderHandler.LINE_ENDING);
                final StringBuilder sb = new StringBuilder();
                for (int i = 0; i < 16 && i < headers.length; ++i) {
                    if (sb.length() > 0) {
                        sb.append(XmlLicenseHeaderHandler.LINE_ENDING);
                    }
                    sb.append(headers[i]);
                }
                header = sb.toString();
            }
            revision = Diff.diff(this.getLicenseHeader().split(XmlLicenseHeaderHandler.LINE_ENDING), header.split(XmlLicenseHeaderHandler.LINE_ENDING));
        }
        catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
        return revision.size() == 0;
    }
    
    @Override
    public List<String> getSuffixes() {
        return Arrays.asList("xml", "fml");
    }
    
    @Override
    public boolean addLicenseHeader(final File file) {
        boolean added = false;
        try {
            String content = new org.apache.wicket.util.file.File(file).readString();
            String xml = "";
            final StringBuilder newContent = new StringBuilder();
            final Matcher mat = this.xmlHeader.matcher(content);
            if (mat.matches()) {
                xml = mat.group(1);
                content = mat.group(2);
            }
            if (!Strings.isEmpty(xml)) {
                newContent.append(xml).append(XmlLicenseHeaderHandler.LINE_ENDING);
            }
            newContent.append(this.getLicenseHeader()).append(XmlLicenseHeaderHandler.LINE_ENDING);
            newContent.append(content);
            new org.apache.wicket.util.file.File(file).write(newContent.toString());
            added = true;
        }
        catch (Exception e) {
            Assert.fail(e.getMessage());
        }
        return added;
    }
}
