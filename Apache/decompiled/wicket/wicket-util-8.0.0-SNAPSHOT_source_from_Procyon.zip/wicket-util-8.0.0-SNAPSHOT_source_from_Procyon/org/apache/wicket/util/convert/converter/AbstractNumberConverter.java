// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.text.Format;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

public abstract class AbstractNumberConverter<N extends Number> extends AbstractConverter<N>
{
    private static final long serialVersionUID = 1L;
    private final ConcurrentHashMap<Locale, NumberFormat> numberFormats;
    
    public AbstractNumberConverter() {
        this.numberFormats = new ConcurrentHashMap<Locale, NumberFormat>();
    }
    
    public NumberFormat getNumberFormat(final Locale locale) {
        NumberFormat numberFormat = this.numberFormats.get(locale);
        if (numberFormat == null) {
            numberFormat = this.newNumberFormat(locale);
            if (numberFormat instanceof DecimalFormat) {
                ((DecimalFormat)numberFormat).setParseBigDecimal(true);
            }
            final NumberFormat tmpNumberFormat = this.numberFormats.putIfAbsent(locale, numberFormat);
            if (tmpNumberFormat != null) {
                numberFormat = tmpNumberFormat;
            }
        }
        return (NumberFormat)numberFormat.clone();
    }
    
    protected abstract NumberFormat newNumberFormat(final Locale p0);
    
    protected BigDecimal parse(Object value, final BigDecimal min, final BigDecimal max, Locale locale) {
        if (locale == null) {
            locale = Locale.getDefault(Locale.Category.FORMAT);
        }
        if (value == null) {
            return null;
        }
        if (value instanceof String) {
            value = ((String)value).replaceAll("(\\d+)\\s(?=\\d)", "$1 ");
        }
        final NumberFormat numberFormat = this.getNumberFormat(locale);
        final N number = this.parse(numberFormat, value, locale);
        if (number == null) {
            return null;
        }
        BigDecimal bigDecimal;
        if (number instanceof BigDecimal) {
            bigDecimal = (BigDecimal)number;
        }
        else {
            bigDecimal = new BigDecimal(number.toString());
        }
        if (min != null && bigDecimal.compareTo(min) < 0) {
            throw this.newConversionException("Value cannot be less than " + min, value, locale).setFormat(numberFormat);
        }
        if (max != null && bigDecimal.compareTo(max) > 0) {
            throw this.newConversionException("Value cannot be greater than " + max, value, locale).setFormat(numberFormat);
        }
        return bigDecimal;
    }
    
    @Override
    public String convertToString(final N value, final Locale locale) {
        final NumberFormat fmt = this.getNumberFormat(locale);
        if (fmt != null) {
            return fmt.format(value);
        }
        return value.toString();
    }
}
