// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern;

import java.util.List;

public final class OptionalMetaPattern extends MetaPattern
{
    private static final long serialVersionUID = 1L;
    
    public OptionalMetaPattern(final String pattern) {
        super(pattern);
    }
    
    public OptionalMetaPattern(final MetaPattern pattern) {
        super(pattern);
    }
    
    public OptionalMetaPattern(final List<MetaPattern> patterns) {
        super(patterns);
    }
    
    public OptionalMetaPattern(final MetaPattern[] patterns) {
        super(patterns);
    }
    
    @Override
    public String toString() {
        return "(?:" + super.toString() + ")?";
    }
}
