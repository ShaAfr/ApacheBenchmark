// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import org.apache.wicket.util.diff.myers.MyersDiff;

public class Diff extends ToString
{
    public static final String NL;
    public static final String RCS_EOL = "\n";
    protected final Object[] orig;
    protected DiffAlgorithm algorithm;
    
    public Diff(final Object[] original) {
        this(original, null);
    }
    
    public Diff(final Object[] original, final DiffAlgorithm algorithm) {
        if (original == null) {
            throw new IllegalArgumentException();
        }
        this.orig = original;
        if (algorithm != null) {
            this.algorithm = algorithm;
        }
        else {
            this.algorithm = this.defaultAlgorithm();
        }
    }
    
    protected DiffAlgorithm defaultAlgorithm() {
        return new MyersDiff();
    }
    
    public static Revision diff(final Object[] orig, final Object[] rev) throws DifferentiationFailedException {
        if (orig == null || rev == null) {
            throw new IllegalArgumentException();
        }
        return diff(orig, rev, null);
    }
    
    public static Revision diff(final Object[] orig, final Object[] rev, final DiffAlgorithm algorithm) throws DifferentiationFailedException {
        if (orig == null || rev == null) {
            throw new IllegalArgumentException();
        }
        return new Diff(orig, algorithm).diff(rev);
    }
    
    public Revision diff(final Object[] rev) throws DifferentiationFailedException {
        if (this.orig.length == 0 && rev.length == 0) {
            return new Revision();
        }
        return this.algorithm.diff(this.orig, rev);
    }
    
    public static boolean compare(final Object[] orig, final Object[] rev) {
        if (orig.length != rev.length) {
            return false;
        }
        for (int i = 0; i < orig.length; ++i) {
            if (!orig[i].equals(rev[i])) {
                return false;
            }
        }
        return true;
    }
    
    public static String arrayToString(final Object[] o) {
        return ToString.arrayToString(o, Diff.NL);
    }
    
    public static Object[] editAll(final Object[] text) {
        final Object[] result = new String[text.length];
        for (int i = 0; i < text.length; ++i) {
            result[i] = text[i] + " <edited>";
        }
        return result;
    }
    
    public static Object[] randomEdit(final Object[] text) {
        return randomEdit(text, text.length);
    }
    
    public static Object[] randomEdit(final Object[] text, final long seed) {
        final List<Object> result = new ArrayList<Object>(Arrays.asList(text));
        final Random r = new Random(seed);
        for (int nops = r.nextInt(10), i = 0; i < nops; ++i) {
            final boolean del = r.nextBoolean();
            int pos = r.nextInt(result.size() + 1);
            final int len = Math.min(result.size() - pos, 1 + r.nextInt(4));
            if (del && result.size() > 0) {
                result.subList(pos, pos + len).clear();
            }
            else {
                for (int k = 0; k < len; ++k, ++pos) {
                    result.add(pos, "[" + i + "] random edit[" + i + "][" + i + "]");
                }
            }
        }
        return result.toArray();
    }
    
    public static Object[] shuffle(final Object[] text) {
        return shuffle(text, text.length);
    }
    
    public static Object[] shuffle(final Object[] text, final long seed) {
        final List<Object> result = new ArrayList<Object>(Arrays.asList(text));
        Collections.shuffle(result);
        return result.toArray();
    }
    
    public static Object[] randomSequence(final int size) {
        return randomSequence(size, size);
    }
    
    public static Object[] randomSequence(final int size, final long seed) {
        final Integer[] result = new Integer[size];
        final Random r = new Random(seed);
        for (int i = 0; i < result.length; ++i) {
            result[i] = r.nextInt(size);
        }
        return result;
    }
    
    static {
        NL = System.getProperty("line.separator");
    }
}
