// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.lang.Bytes;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.Iterator;
import javax.xml.transform.Transformer;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import java.io.Closeable;
import org.apache.wicket.util.io.IOUtils;
import javax.xml.transform.TransformerFactory;
import java.io.OutputStream;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.util.Map;
import java.io.ByteArrayOutputStream;

public class XSLTResourceStream extends AbstractResourceStream
{
    private static final long serialVersionUID = 1L;
    private final transient ByteArrayOutputStream out;
    
    protected Map<Object, Object> getParameters() {
        return null;
    }
    
    public XSLTResourceStream(final IResourceStream xsltResource, final IResourceStream xmlResource) {
        try {
            final Source xmlSource = new StreamSource(xmlResource.getInputStream());
            final Source xsltSource = new StreamSource(xsltResource.getInputStream());
            this.out = new ByteArrayOutputStream();
            final Result result = new StreamResult(this.out);
            final TransformerFactory transFact = TransformerFactory.newInstance();
            final Transformer trans = transFact.newTransformer(xsltSource);
            final Map<Object, Object> parameters = this.getParameters();
            if (parameters != null) {
                for (final Map.Entry<Object, Object> e : parameters.entrySet()) {
                    trans.setParameter(e.getKey().toString(), e.getValue().toString());
                }
            }
            trans.transform(xmlSource, result);
        }
        catch (Exception e2) {
            throw new RuntimeException(e2);
        }
        finally {
            IOUtils.closeQuietly(xmlResource);
            IOUtils.closeQuietly(xsltResource);
        }
    }
    
    @Override
    public void close() throws IOException {
    }
    
    @Override
    public String getContentType() {
        return null;
    }
    
    @Override
    public InputStream getInputStream() throws ResourceStreamNotFoundException {
        return new ByteArrayInputStream(this.out.toByteArray());
    }
    
    @Override
    public Bytes length() {
        return Bytes.bytes(this.out.size());
    }
    
    @Override
    public Time lastModifiedTime() {
        return null;
    }
}
