// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import org.apache.wicket.util.string.StringValueConversionException;
import org.apache.wicket.util.string.Strings;
import java.util.Locale;
import org.apache.wicket.util.convert.IConverter;

public class BooleanConverter extends AbstractConverter<Boolean>
{
    private static final long serialVersionUID = 1L;
    public static final IConverter<Boolean> INSTANCE;
    
    @Override
    public Boolean convertToObject(final String value, final Locale locale) {
        try {
            return Strings.toBoolean(value);
        }
        catch (StringValueConversionException e) {
            throw this.newConversionException("Cannot convert '" + value + "' to Boolean", value, locale);
        }
    }
    
    @Override
    protected Class<Boolean> getTargetType() {
        return Boolean.class;
    }
    
    static {
        INSTANCE = new BooleanConverter();
    }
}
