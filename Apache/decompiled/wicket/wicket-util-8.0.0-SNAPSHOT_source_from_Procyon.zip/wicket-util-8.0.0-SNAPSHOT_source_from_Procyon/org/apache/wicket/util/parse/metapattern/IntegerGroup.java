// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern;

import java.util.regex.Matcher;

public final class IntegerGroup extends Group
{
    private static final long serialVersionUID = 1L;
    private final int radix;
    
    public IntegerGroup() {
        this(IntegerGroup.INTEGER);
    }
    
    public IntegerGroup(final MetaPattern pattern) {
        this(pattern, 10);
    }
    
    public IntegerGroup(final MetaPattern pattern, final int radix) {
        super(pattern);
        this.radix = radix;
    }
    
    public int getInt(final Matcher matcher) {
        return this.getInt(matcher, -1);
    }
    
    public int getInt(final Matcher matcher, final int defaultValue) {
        final String value = this.get(matcher);
        return (value == null) ? defaultValue : Integer.parseInt(value, this.radix);
    }
    
    public long getLong(final Matcher matcher) {
        return this.getLong(matcher, -1L);
    }
    
    public long getLong(final Matcher matcher, final long defaultValue) {
        final String value = this.get(matcher);
        return (value == null) ? defaultValue : Long.parseLong(value, this.radix);
    }
}
