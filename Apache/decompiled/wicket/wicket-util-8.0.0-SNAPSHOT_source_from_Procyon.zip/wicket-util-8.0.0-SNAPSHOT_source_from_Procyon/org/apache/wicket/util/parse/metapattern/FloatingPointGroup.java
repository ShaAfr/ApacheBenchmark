// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern;

import java.util.regex.Matcher;

public final class FloatingPointGroup extends Group
{
    private static final long serialVersionUID = 1L;
    
    public FloatingPointGroup() {
        super(FloatingPointGroup.FLOATING_POINT_NUMBER);
    }
    
    public float getFloat(final Matcher matcher) {
        return this.getFloat(matcher, -1.0f);
    }
    
    public float getFloat(final Matcher matcher, final float defaultValue) {
        final String value = this.get(matcher);
        return (value == null) ? defaultValue : Float.parseFloat(value);
    }
    
    public double getDouble(final Matcher matcher) {
        return this.getDouble(matcher, -1.0);
    }
    
    public double getDouble(final Matcher matcher, final double defaultValue) {
        final String value = this.get(matcher);
        return (value == null) ? defaultValue : Double.parseDouble(value);
    }
}
