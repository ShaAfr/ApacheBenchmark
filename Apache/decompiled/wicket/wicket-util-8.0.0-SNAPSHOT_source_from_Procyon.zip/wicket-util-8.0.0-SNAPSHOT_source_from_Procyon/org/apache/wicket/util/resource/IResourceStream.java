// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import java.util.Locale;
import java.io.IOException;
import java.io.InputStream;
import org.apache.wicket.util.lang.Bytes;
import java.io.Closeable;
import org.apache.wicket.util.io.IClusterable;
import org.apache.wicket.util.watch.IModifiable;

public interface IResourceStream extends IModifiable, IClusterable, Closeable
{
    String getContentType();
    
    Bytes length();
    
    InputStream getInputStream() throws ResourceStreamNotFoundException;
    
    void close() throws IOException;
    
    Locale getLocale();
    
    void setLocale(final Locale p0);
    
    String getStyle();
    
    void setStyle(final String p0);
    
    String getVariation();
    
    void setVariation(final String p0);
}
