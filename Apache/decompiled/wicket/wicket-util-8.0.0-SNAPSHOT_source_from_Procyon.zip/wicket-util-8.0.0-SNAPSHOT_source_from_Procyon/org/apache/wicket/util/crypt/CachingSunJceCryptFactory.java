// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

public class CachingSunJceCryptFactory extends CryptFactoryCachingDecorator
{
    public CachingSunJceCryptFactory(final String encryptionKey) {
        super(new ClassCryptFactory(SunJceCrypt.class, encryptionKey));
    }
}
