// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import org.apache.wicket.util.convert.IConverter;

public class CharacterConverter extends AbstractConverter<Character>
{
    private static final long serialVersionUID = 1L;
    public static final IConverter<Character> INSTANCE;
    
    @Override
    public Character convertToObject(final String value, final Locale locale) {
        final int length = value.length();
        if (length == 0) {
            return null;
        }
        if (length == 1) {
            return value.charAt(0);
        }
        throw this.newConversionException("Cannot convert '" + value + "' to Character", value, locale);
    }
    
    @Override
    protected Class<Character> getTargetType() {
        return Character.class;
    }
    
    static {
        INSTANCE = new CharacterConverter();
    }
}
