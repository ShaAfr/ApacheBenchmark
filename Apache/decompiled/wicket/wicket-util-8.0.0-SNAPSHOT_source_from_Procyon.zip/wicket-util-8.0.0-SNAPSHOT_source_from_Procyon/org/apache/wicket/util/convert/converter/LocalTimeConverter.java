// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.time.temporal.Temporal;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.time.LocalTime;

public class LocalTimeConverter extends AbstractJavaTimeConverter<LocalTime>
{
    private static final long serialVersionUID = 1L;
    
    @Override
    protected Class<LocalTime> getTargetType() {
        return LocalTime.class;
    }
    
    @Override
    protected LocalTime createTemporal(final TemporalAccessor temporalAccessor) {
        return LocalTime.from(temporalAccessor);
    }
    
    @Override
    protected DateTimeFormatter getDateTimeFormatter() {
        return DateTimeFormatter.ISO_LOCAL_TIME;
    }
}
