// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import org.apache.commons.io.FileDeleteStrategy;
import java.io.File;
import org.apache.wicket.util.lang.Args;
import org.apache.commons.io.FileCleaningTracker;

public class FileCleanerTrackerAdapter extends FileCleaningTracker
{
    private final IFileCleaner fileCleaner;
    
    public FileCleanerTrackerAdapter(final IFileCleaner fileCleaner) {
        this.fileCleaner = Args.notNull(fileCleaner, "fileCleaner");
    }
    
    public void track(final File file, final Object marker) {
        this.fileCleaner.track(file, marker);
    }
    
    public void track(final File file, final Object marker, final FileDeleteStrategy deleteStrategy) {
        this.fileCleaner.track(file, marker, deleteStrategy);
    }
    
    public void track(final String path, final Object marker) {
        this.fileCleaner.track(new org.apache.wicket.util.file.File(path), marker);
    }
    
    public void track(final String path, final Object marker, final FileDeleteStrategy deleteStrategy) {
        this.fileCleaner.track(new org.apache.wicket.util.file.File(path), marker, deleteStrategy);
    }
}
