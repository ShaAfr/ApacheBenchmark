// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.Map;
import java.util.LinkedHashMap;

public class MostRecentlyUsedMap<K, V> extends LinkedHashMap<K, V>
{
    private static final long serialVersionUID = 1L;
    protected V removedValue;
    private final int maxEntries;
    
    public MostRecentlyUsedMap(final int maxEntries) {
        super(10, 0.75f, true);
        if (maxEntries <= 0) {
            throw new IllegalArgumentException("Must have at least one entry");
        }
        this.maxEntries = maxEntries;
    }
    
    public V getRemovedValue() {
        return this.removedValue;
    }
    
    @Override
    protected boolean removeEldestEntry(final Map.Entry<K, V> eldest) {
        final boolean remove = this.size() > this.maxEntries;
        if (remove) {
            this.removedValue = eldest.getValue();
        }
        else {
            this.removedValue = null;
        }
        return remove;
    }
}
