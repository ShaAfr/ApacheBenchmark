// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.math.BigDecimal;
import java.util.Locale;
import java.math.BigInteger;

public class BigIntegerConverter extends AbstractIntegerConverter<BigInteger>
{
    private static final long serialVersionUID = 1L;
    
    @Override
    protected Class<BigInteger> getTargetType() {
        return BigInteger.class;
    }
    
    @Override
    public BigInteger convertToObject(final String value, final Locale locale) {
        final BigDecimal number = this.parse(value, null, null, locale);
        if (number == null) {
            return null;
        }
        return number.toBigInteger();
    }
}
