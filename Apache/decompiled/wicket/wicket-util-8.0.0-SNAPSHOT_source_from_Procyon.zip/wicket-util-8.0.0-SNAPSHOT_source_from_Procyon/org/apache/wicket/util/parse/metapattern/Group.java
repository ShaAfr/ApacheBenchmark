// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern;

import java.util.regex.Matcher;

public class Group extends MetaPattern
{
    private static final long serialVersionUID = 1L;
    private int group;
    
    public Group(final MetaPattern pattern) {
        super(pattern);
        this.group = -1;
    }
    
    public final String get(final Matcher matcher) {
        if (this.group == -1) {
            throw new GroupNotBoundException();
        }
        return matcher.group(this.group);
    }
    
    @Override
    public String toString() {
        return "(" + super.toString() + ")";
    }
    
    final void bind(final int bindTo) {
        if (this.group == -1) {
            this.group = bindTo;
            return;
        }
        throw new GroupAlreadyBoundException();
    }
}
