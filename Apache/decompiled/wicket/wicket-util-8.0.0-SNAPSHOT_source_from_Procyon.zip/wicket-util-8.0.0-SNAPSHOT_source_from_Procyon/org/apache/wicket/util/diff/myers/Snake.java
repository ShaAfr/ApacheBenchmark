// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff.myers;

public final class Snake extends PathNode
{
    public Snake(final int i, final int j, final PathNode prev) {
        super(i, j, prev);
    }
    
    @Override
    public boolean isSnake() {
        return true;
    }
}
