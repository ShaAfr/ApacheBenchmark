// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import org.apache.wicket.util.resource.IResourceStream;

@FunctionalInterface
public interface IResourceFinder
{
    IResourceStream find(final Class<?> p0, final String p1);
}
