// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string.interpolator;

import org.apache.wicket.util.string.Strings;
import java.util.Map;

public class MapVariableInterpolator extends VariableInterpolator
{
    private Map<?, ?> variables;
    
    public MapVariableInterpolator(final String string, final Map<?, ?> variables) {
        super(string);
        this.variables = variables;
    }
    
    public MapVariableInterpolator(final String string, final Map<?, ?> variables, final boolean exceptionOnNullVarValue) {
        super(string, exceptionOnNullVarValue);
        this.variables = variables;
    }
    
    public final void setVariables(final Map<?, ?> variables) {
        this.variables = variables;
    }
    
    @Override
    protected String getValue(final String variableName) {
        return Strings.toString(this.variables.get(variableName));
    }
    
    public static String interpolate(final String string, final Map<?, ?> variables) {
        return new MapVariableInterpolator(string, variables).toString();
    }
}
