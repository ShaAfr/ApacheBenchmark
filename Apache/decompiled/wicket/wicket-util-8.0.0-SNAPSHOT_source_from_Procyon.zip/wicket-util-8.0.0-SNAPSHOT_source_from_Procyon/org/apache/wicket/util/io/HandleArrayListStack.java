// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.util.EmptyStackException;
import java.util.Collection;
import java.util.ArrayList;

final class HandleArrayListStack<T> extends ArrayList<T>
{
    private static final long serialVersionUID = 1L;
    
    public HandleArrayListStack() {
        this(10);
    }
    
    public HandleArrayListStack(final Collection<? extends T> collection) {
        super(collection);
    }
    
    public HandleArrayListStack(final int initialCapacity) {
        super(initialCapacity);
    }
    
    public final boolean empty() {
        return this.size() == 0;
    }
    
    @Override
    public int indexOf(final Object elem) {
        final int size = this.size();
        if (elem == null) {
            for (int i = 0; i < size; ++i) {
                if (this.get(i) == null) {
                    return i;
                }
            }
        }
        else {
            for (int i = 0; i < size; ++i) {
                if (elem == this.get(i)) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    @Override
    public int lastIndexOf(final Object elem) {
        if (elem == null) {
            for (int i = this.size() - 1; i >= 0; --i) {
                if (this.get(i) == null) {
                    return i;
                }
            }
        }
        else {
            for (int i = this.size() - 1; i >= 0; --i) {
                if (elem == this.get(i)) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public final T peek() {
        final int size = this.size();
        if (size == 0) {
            throw new EmptyStackException();
        }
        return this.get(size - 1);
    }
    
    public final T pop() {
        final T top = this.peek();
        this.remove(this.size() - 1);
        return top;
    }
    
    public final void push(final T item) {
        this.add(item);
    }
    
    public final int search(final Object o) {
        final int i = this.lastIndexOf(o);
        if (i >= 0) {
            return this.size() - i;
        }
        return -1;
    }
}
