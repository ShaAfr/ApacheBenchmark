// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import org.apache.commons.io.FileDeleteStrategy;
import java.io.File;
import org.apache.commons.io.FileCleaningTracker;

public class FileCleaner implements IFileCleaner
{
    private final FileCleaningTracker cleaner;
    
    public FileCleaner() {
        this.cleaner = new FileCleaningTracker();
    }
    
    @Override
    public void track(final File file, final Object marker) {
        this.cleaner.track(file, marker);
    }
    
    @Override
    public void track(final File file, final Object marker, final FileDeleteStrategy deleteStrategy) {
        this.cleaner.track(file, marker, deleteStrategy);
    }
    
    @Override
    public void destroy() {
        this.cleaner.exitWhenFinished();
    }
}
