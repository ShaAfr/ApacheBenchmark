// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

import java.security.GeneralSecurityException;

public class TrivialCrypt extends AbstractCrypt
{
    @Override
    protected byte[] crypt(final byte[] input, final int mode) throws GeneralSecurityException {
        final byte[] result = new byte[input.length];
        for (int i = 0; i < input.length; ++i) {
            result[i] = (byte)(input[i] ^ 0xFF);
        }
        return result;
    }
}
