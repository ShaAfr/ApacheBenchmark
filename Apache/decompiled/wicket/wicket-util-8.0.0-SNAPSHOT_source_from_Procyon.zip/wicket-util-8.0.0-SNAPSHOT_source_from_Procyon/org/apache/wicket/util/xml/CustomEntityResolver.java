// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.xml;

import java.io.InputStream;
import javax.servlet.Filter;
import java.io.IOException;
import org.xml.sax.SAXException;
import java.util.Iterator;
import org.xml.sax.InputSource;
import org.apache.wicket.util.lang.Args;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.EntityResolver;

public class CustomEntityResolver implements EntityResolver
{
    private final Map<EntityKey, EntityLocator> entities;
    
    public CustomEntityResolver() {
        this.entities = new HashMap<EntityKey, EntityLocator>(3);
    }
    
    public static CustomEntityResolver getPreloaded() {
        final CustomEntityResolver resolver = new CustomEntityResolver();
        resolver.put(new EntityKey("-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN", "http://java.sun.com/dtd/web-app_2_3.dtd"), new ServletApiEntityLocator("web-app_2_3.dtd"));
        return resolver;
    }
    
    public void put(final EntityKey key, final EntityLocator locator) {
        Args.notNull(key, "key");
        Args.notNull(locator, "locator");
        this.entities.put(key, locator);
    }
    
    @Override
    public InputSource resolveEntity(final String id, final String url) throws SAXException, IOException {
        for (final Map.Entry<EntityKey, EntityLocator> entry : this.entities.entrySet()) {
            if (entry.getKey().id.equals(id) || entry.getKey().url.equals(url)) {
                return entry.getValue().locateInputSource();
            }
        }
        return null;
    }
    
    public static class EntityKey
    {
        private final String id;
        private final String url;
        
        private EntityKey(final String id, final String url) {
            Args.notEmpty(id, "id");
            Args.notEmpty(url, "url");
            this.id = id;
            this.url = url;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof EntityKey)) {
                return false;
            }
            final EntityKey key = (EntityKey)o;
            return this.id.equals(key.id) && this.url.equals(key.url);
        }
        
        @Override
        public int hashCode() {
            int result = this.id.hashCode();
            result = 31 * result + this.url.hashCode();
            return result;
        }
    }
    
    public static class ServletApiEntityLocator implements EntityLocator
    {
        private final String name;
        
        private ServletApiEntityLocator(final String name) {
            this.name = name;
        }
        
        @Override
        public InputSource locateInputSource() {
            final InputStream stream = Filter.class.getResourceAsStream("resources/" + this.name);
            if (stream == null) {
                return null;
            }
            return new InputSource(stream);
        }
    }
    
    public interface EntityLocator
    {
        InputSource locateInputSource() throws SAXException, IOException;
    }
}
