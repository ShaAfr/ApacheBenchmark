// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.util.regex.Matcher;
import java.io.InputStreamReader;
import org.apache.wicket.util.string.Strings;
import java.io.IOException;
import java.io.BufferedInputStream;
import org.apache.wicket.util.lang.Args;
import java.io.InputStream;
import java.util.regex.Pattern;
import java.io.Reader;

public final class XmlReader extends Reader
{
    private static final Pattern xmlDecl;
    private static final Pattern encodingPattern;
    private String encoding;
    private final InputStream inputStream;
    private Reader reader;
    
    public XmlReader(final InputStream inputStream, final String defaultEncoding) throws IOException {
        Args.notNull(inputStream, "inputStream");
        if (!inputStream.markSupported()) {
            this.inputStream = new BufferedInputStream(new BOMInputStream(inputStream));
        }
        else {
            this.inputStream = new BOMInputStream(inputStream);
        }
        this.encoding = defaultEncoding;
        this.init();
    }
    
    public final String getEncoding() {
        return this.encoding;
    }
    
    public void init() throws IOException {
        final int readAheadSize = 80;
        this.inputStream.mark(80);
        final String xmlDeclaration = this.getXmlDeclaration(this.inputStream, 80);
        if (!Strings.isEmpty(xmlDeclaration)) {
            this.encoding = this.determineEncoding(xmlDeclaration);
        }
        else {
            this.inputStream.reset();
        }
        if (this.encoding == null) {
            this.reader = new InputStreamReader(this.inputStream);
        }
        else {
            this.reader = new InputStreamReader(this.inputStream, this.encoding);
        }
    }
    
    private String determineEncoding(final CharSequence string) {
        final Matcher matcher = XmlReader.encodingPattern.matcher(string);
        if (!matcher.find()) {
            return null;
        }
        String encoding = matcher.group(2);
        if (encoding == null || encoding.length() == 0) {
            encoding = matcher.group(3);
        }
        if (encoding != null) {
            encoding = encoding.trim();
        }
        return encoding;
    }
    
    private String getXmlDeclaration(final InputStream in, final int readAheadSize) throws IOException {
        final StringBuilder pushBack = new StringBuilder(readAheadSize);
        int value;
        while ((value = in.read()) != -1) {
            pushBack.append((char)value);
            if (value == 62 || value == 10 || value == 13 || pushBack.length() >= readAheadSize - 1) {
                break;
            }
        }
        final Matcher matcher = XmlReader.xmlDecl.matcher(pushBack);
        if (!matcher.matches()) {
            return null;
        }
        return pushBack.toString().trim();
    }
    
    @Override
    public void close() throws IOException {
        try {
            this.reader.close();
        }
        finally {
            this.inputStream.close();
        }
    }
    
    @Override
    public int read(final char[] buf, final int from, final int to) throws IOException {
        return this.reader.read(buf, from, to);
    }
    
    @Override
    public String toString() {
        return this.inputStream.toString() + " (" + this.encoding + ")";
    }
    
    static {
        xmlDecl = Pattern.compile("[\\s\\n\\r]*<\\?xml(\\s+.*)?\\?>");
        encodingPattern = Pattern.compile("\\s+encoding\\s*=\\s*([\"'](.*?)[\"']|(\\S*)).*\\?>");
    }
}
