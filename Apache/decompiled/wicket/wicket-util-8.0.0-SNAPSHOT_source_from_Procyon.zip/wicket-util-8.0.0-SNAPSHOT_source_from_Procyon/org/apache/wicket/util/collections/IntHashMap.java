// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.NoSuchElementException;
import java.util.ConcurrentModificationException;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Collection;
import java.util.Set;
import java.io.Serializable;

public class IntHashMap<V> implements Cloneable, Serializable
{
    transient volatile Set<Integer> keySet;
    transient volatile Collection<V> values;
    static final int DEFAULT_INITIAL_CAPACITY = 16;
    static final int MAXIMUM_CAPACITY = 1073741824;
    static final float DEFAULT_LOAD_FACTOR = 0.75f;
    transient Entry<V>[] table;
    transient int size;
    int threshold;
    final float loadFactor;
    transient AtomicInteger modCount;
    private transient Set<Entry<V>> entrySet;
    private static final long serialVersionUID = 362498820763181265L;
    
    public IntHashMap(int initialCapacity, final float loadFactor) {
        this.keySet = null;
        this.values = null;
        this.modCount = new AtomicInteger(0);
        this.entrySet = null;
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("Illegal initial capacity: " + initialCapacity);
        }
        if (initialCapacity > 1073741824) {
            initialCapacity = 1073741824;
        }
        if (loadFactor <= 0.0f || Float.isNaN(loadFactor)) {
            throw new IllegalArgumentException("Illegal load factor: " + loadFactor);
        }
        int capacity;
        for (capacity = 1; capacity < initialCapacity; capacity <<= 1) {}
        this.loadFactor = loadFactor;
        this.threshold = (int)(capacity * loadFactor);
        this.table = (Entry<V>[])new Entry[capacity];
        this.init();
    }
    
    public IntHashMap(final int initialCapacity) {
        this(initialCapacity, 0.75f);
    }
    
    public IntHashMap() {
        this.keySet = null;
        this.values = null;
        this.modCount = new AtomicInteger(0);
        this.entrySet = null;
        this.loadFactor = 0.75f;
        this.threshold = 12;
        this.table = (Entry<V>[])new Entry[16];
        this.init();
    }
    
    void init() {
    }
    
    static int indexFor(final int h, final int length) {
        return h & length - 1;
    }
    
    public int size() {
        return this.size;
    }
    
    public boolean isEmpty() {
        return this.size == 0;
    }
    
    public V get(final int key) {
        final int i = indexFor(key, this.table.length);
        for (Entry<V> e = this.table[i]; e != null; e = e.next) {
            if (key == e.key) {
                return e.value;
            }
        }
        return null;
    }
    
    public boolean containsKey(final int key) {
        final int i = indexFor(key, this.table.length);
        for (Entry<V> e = this.table[i]; e != null; e = e.next) {
            if (key == e.key) {
                return true;
            }
        }
        return false;
    }
    
    Entry<V> getEntry(final int key) {
        final int i = indexFor(key, this.table.length);
        Entry<V> e;
        for (e = this.table[i]; e != null && key != e.key; e = e.next) {}
        return e;
    }
    
    public V put(final int key, final V value) {
        final int i = indexFor(key, this.table.length);
        for (Entry<V> e = this.table[i]; e != null; e = e.next) {
            if (key == e.key) {
                final V oldValue = e.value;
                e.value = value;
                return oldValue;
            }
        }
        this.modCount.incrementAndGet();
        this.addEntry(key, value, i);
        return null;
    }
    
    private void putForCreate(final int key, final V value) {
        final int i = indexFor(key, this.table.length);
        for (Entry<V> e = this.table[i]; e != null; e = e.next) {
            if (key == e.key) {
                e.value = value;
                return;
            }
        }
        this.createEntry(key, value, i);
    }
    
    void putAllForCreate(final IntHashMap<V> m) {
        for (final Entry<V> entry : m.entrySet()) {
            this.putForCreate(entry.getKey(), entry.getValue());
        }
    }
    
    void resize(final int newCapacity) {
        final Entry<V>[] oldTable = this.table;
        final int oldCapacity = oldTable.length;
        if (oldCapacity == 1073741824) {
            this.threshold = Integer.MAX_VALUE;
            return;
        }
        final Entry<V>[] newTable = (Entry<V>[])new Entry[newCapacity];
        this.transfer(newTable);
        this.table = newTable;
        this.threshold = (int)(newCapacity * this.loadFactor);
    }
    
    void transfer(final Entry<V>[] newTable) {
        final Entry<V>[] src = this.table;
        final int newCapacity = newTable.length;
        for (int j = 0; j < src.length; ++j) {
            Entry<V> e = src[j];
            if (e != null) {
                src[j] = null;
                do {
                    final Entry<V> next = e.next;
                    final int i = indexFor(e.key, newCapacity);
                    e.next = newTable[i];
                    newTable[i] = e;
                    e = next;
                } while (e != null);
            }
        }
    }
    
    public void putAll(final IntHashMap<V> m) {
        final int numKeysToBeAdded = m.size();
        if (numKeysToBeAdded == 0) {
            return;
        }
        if (numKeysToBeAdded > this.threshold) {
            int targetCapacity = (int)(numKeysToBeAdded / this.loadFactor + 1.0f);
            if (targetCapacity > 1073741824) {
                targetCapacity = 1073741824;
            }
            int newCapacity;
            for (newCapacity = this.table.length; newCapacity < targetCapacity; newCapacity <<= 1) {}
            if (newCapacity > this.table.length) {
                this.resize(newCapacity);
            }
        }
        for (final Entry<V> entry : m.entrySet()) {
            this.put(entry.getKey(), entry.getValue());
        }
    }
    
    public V remove(final int key) {
        final Entry<V> e = this.removeEntryForKey(key);
        return (e == null) ? null : e.value;
    }
    
    Entry<V> removeEntryForKey(final int key) {
        final int i = indexFor(key, this.table.length);
        Entry<V> e;
        Entry<V> next;
        for (Entry<V> prev = e = this.table[i]; e != null; e = next) {
            next = e.next;
            if (key == e.key) {
                this.modCount.incrementAndGet();
                --this.size;
                if (prev == e) {
                    this.table[i] = next;
                }
                else {
                    prev.next = next;
                }
                return e;
            }
            prev = e;
        }
        return e;
    }
    
    Entry<V> removeMapping(final Object o) {
        if (!(o instanceof Entry)) {
            return null;
        }
        final Entry<V> entry = (Entry<V>)o;
        final int key = entry.getKey();
        final int i = indexFor(key, this.table.length);
        Entry<V> e;
        Entry<V> next;
        for (Entry<V> prev = e = this.table[i]; e != null; e = next) {
            next = e.next;
            if (e.key == key && e.equals(entry)) {
                this.modCount.incrementAndGet();
                --this.size;
                if (prev == e) {
                    this.table[i] = next;
                }
                else {
                    prev.next = next;
                }
                return e;
            }
            prev = e;
        }
        return e;
    }
    
    public void clear() {
        this.modCount.incrementAndGet();
        final Entry<V>[] tab = this.table;
        for (int i = 0; i < tab.length; ++i) {
            tab[i] = null;
        }
        this.size = 0;
    }
    
    public boolean containsValue(final Object value) {
        if (value == null) {
            return this.containsNullValue();
        }
        for (Entry<V> e : this.table) {
            final Entry<V> entry = e;
            while (e != null) {
                if (value.equals(e.value)) {
                    return true;
                }
                e = e.next;
            }
        }
        return false;
    }
    
    private boolean containsNullValue() {
        final Entry<V>[] table;
        final Entry<V>[] tab = table = this.table;
        for (Entry<V> e : table) {
            final Entry<V> tabEntry = e;
            while (e != null) {
                if (e.value == null) {
                    return true;
                }
                e = e.next;
            }
        }
        return false;
    }
    
    public Object clone() throws CloneNotSupportedException {
        IntHashMap<V> result = null;
        try {
            result = (IntHashMap)super.clone();
            result.table = (Entry<V>[])new Entry[this.table.length];
            result.entrySet = null;
            result.modCount.set(0);
            result.size = 0;
            result.init();
            result.putAllForCreate(this);
        }
        catch (CloneNotSupportedException ex) {}
        return result;
    }
    
    void addEntry(final int key, final V value, final int bucketIndex) {
        this.table[bucketIndex] = new Entry<V>(key, value, this.table[bucketIndex]);
        if (this.size++ >= this.threshold) {
            this.resize(2 * this.table.length);
        }
    }
    
    void createEntry(final int key, final V value, final int bucketIndex) {
        this.table[bucketIndex] = new Entry<V>(key, value, this.table[bucketIndex]);
        ++this.size;
    }
    
    Iterator<Integer> newKeyIterator() {
        return new KeyIterator();
    }
    
    Iterator<V> newValueIterator() {
        return new ValueIterator();
    }
    
    Iterator<Entry<V>> newEntryIterator() {
        return new EntryIterator();
    }
    
    public Set<Integer> keySet() {
        final Set<Integer> ks = this.keySet;
        return (ks != null) ? ks : (this.keySet = new KeySet());
    }
    
    public Collection<V> values() {
        final Collection<V> vs = this.values;
        return (vs != null) ? vs : (this.values = new Values());
    }
    
    public Set<Entry<V>> entrySet() {
        final Set<Entry<V>> es = this.entrySet;
        return (es != null) ? es : (this.entrySet = new EntrySet());
    }
    
    private void writeObject(final ObjectOutputStream s) throws IOException {
        s.defaultWriteObject();
        s.writeInt(this.table.length);
        s.writeInt(this.size);
        for (final Entry<V> entry : this.entrySet()) {
            s.writeInt(entry.getKey());
            s.writeObject(entry.getValue());
        }
    }
    
    private void readObject(final ObjectInputStream s) throws IOException, ClassNotFoundException {
        this.modCount = new AtomicInteger(0);
        s.defaultReadObject();
        final int numBuckets = s.readInt();
        this.table = (Entry<V>[])new Entry[numBuckets];
        this.init();
        for (int size = s.readInt(), i = 0; i < size; ++i) {
            final int key = s.readInt();
            final V value = (V)s.readObject();
            this.putForCreate(key, value);
        }
    }
    
    int capacity() {
        return this.table.length;
    }
    
    float loadFactor() {
        return this.loadFactor;
    }
    
    public static class Entry<V>
    {
        final int key;
        V value;
        Entry<V> next;
        
        Entry(final int k, final V v, final Entry<V> n) {
            this.value = v;
            this.next = n;
            this.key = k;
        }
        
        public int getKey() {
            return this.key;
        }
        
        public V getValue() {
            return this.value;
        }
        
        public V setValue(final V newValue) {
            final V oldValue = this.value;
            this.value = newValue;
            return oldValue;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (!(o instanceof Entry)) {
                return false;
            }
            final Entry<V> e = (Entry<V>)o;
            final int k1 = this.getKey();
            final int k2 = e.getKey();
            if (k1 == k2) {
                final Object v1 = this.getValue();
                final Object v2 = e.getValue();
                if (v1 == v2 || (v1 != null && v1.equals(v2))) {
                    return true;
                }
            }
            return false;
        }
        
        @Override
        public int hashCode() {
            return this.key ^ ((this.value == null) ? 0 : this.value.hashCode());
        }
        
        @Override
        public String toString() {
            return this.getKey() + "=" + this.getValue();
        }
    }
    
    private abstract class HashIterator<H> implements Iterator<H>
    {
        Entry<V> next;
        int expectedModCount;
        int index;
        Entry<V> current;
        
        HashIterator() {
            this.expectedModCount = IntHashMap.this.modCount.get();
            final Entry<V>[] t = IntHashMap.this.table;
            int i = t.length;
            Entry<V> n = null;
            if (IntHashMap.this.size != 0) {
                while (i > 0 && (n = t[--i]) == null) {}
            }
            this.next = n;
            this.index = i;
        }
        
        @Override
        public boolean hasNext() {
            return this.next != null;
        }
        
        Entry<V> nextEntry() {
            if (!IntHashMap.this.modCount.compareAndSet(this.expectedModCount, this.expectedModCount)) {
                throw new ConcurrentModificationException();
            }
            final Entry<V> e = this.next;
            if (e == null) {
                throw new NoSuchElementException();
            }
            Entry<V> n;
            Entry<V>[] t;
            int i;
            for (n = e.next, t = IntHashMap.this.table, i = this.index; n == null && i > 0; n = t[--i]) {}
            this.index = i;
            this.next = n;
            return this.current = e;
        }
        
        @Override
        public void remove() {
            if (this.current == null) {
                throw new IllegalStateException();
            }
            if (!IntHashMap.this.modCount.compareAndSet(this.expectedModCount, this.expectedModCount)) {
                throw new ConcurrentModificationException();
            }
            final int k = this.current.key;
            this.current = null;
            IntHashMap.this.removeEntryForKey(k);
            this.expectedModCount = IntHashMap.this.modCount.get();
        }
    }
    
    private class ValueIterator extends HashIterator<V>
    {
        @Override
        public V next() {
            return this.nextEntry().value;
        }
    }
    
    private class KeyIterator extends HashIterator<Integer>
    {
        @Override
        public Integer next() {
            return this.nextEntry().getKey();
        }
    }
    
    private class EntryIterator extends HashIterator<Entry<V>>
    {
        @Override
        public Entry<V> next() {
            return this.nextEntry();
        }
    }
    
    private class KeySet extends AbstractSet<Integer>
    {
        @Override
        public Iterator<Integer> iterator() {
            return IntHashMap.this.newKeyIterator();
        }
        
        @Override
        public int size() {
            return IntHashMap.this.size;
        }
        
        @Override
        public boolean contains(final Object o) {
            return o instanceof Number && IntHashMap.this.containsKey(((Number)o).intValue());
        }
        
        @Override
        public boolean remove(final Object o) {
            return o instanceof Number && IntHashMap.this.removeEntryForKey(((Number)o).intValue()) != null;
        }
        
        @Override
        public void clear() {
            IntHashMap.this.clear();
        }
    }
    
    private class Values extends AbstractCollection<V>
    {
        @Override
        public Iterator<V> iterator() {
            return IntHashMap.this.newValueIterator();
        }
        
        @Override
        public int size() {
            return IntHashMap.this.size;
        }
        
        @Override
        public boolean contains(final Object o) {
            return IntHashMap.this.containsValue(o);
        }
        
        @Override
        public void clear() {
            IntHashMap.this.clear();
        }
    }
    
    private class EntrySet extends AbstractSet<Entry<V>>
    {
        @Override
        public Iterator<Entry<V>> iterator() {
            return IntHashMap.this.newEntryIterator();
        }
        
        @Override
        public boolean contains(final Object o) {
            if (!(o instanceof Entry)) {
                return false;
            }
            final Entry<V> e = (Entry<V>)o;
            final Entry<V> candidate = IntHashMap.this.getEntry(e.getKey());
            return candidate != null && candidate.equals(e);
        }
        
        @Override
        public boolean remove(final Object o) {
            return IntHashMap.this.removeMapping(o) != null;
        }
        
        @Override
        public int size() {
            return IntHashMap.this.size;
        }
        
        @Override
        public void clear() {
            IntHashMap.this.clear();
        }
    }
}
