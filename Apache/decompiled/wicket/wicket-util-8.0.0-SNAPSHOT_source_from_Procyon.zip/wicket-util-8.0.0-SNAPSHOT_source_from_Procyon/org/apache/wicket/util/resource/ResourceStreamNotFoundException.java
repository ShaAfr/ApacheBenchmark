// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

public final class ResourceStreamNotFoundException extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public ResourceStreamNotFoundException() {
    }
    
    public ResourceStreamNotFoundException(final String message) {
        super(message);
    }
    
    public ResourceStreamNotFoundException(final Throwable cause) {
        super(cause);
    }
    
    public ResourceStreamNotFoundException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
