// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

public interface IStringIterator
{
    boolean hasNext();
    
    String next();
}
