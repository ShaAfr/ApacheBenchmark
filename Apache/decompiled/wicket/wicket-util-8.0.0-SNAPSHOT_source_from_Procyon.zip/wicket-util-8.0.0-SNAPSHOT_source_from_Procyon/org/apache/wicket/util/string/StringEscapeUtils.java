// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

import java.io.IOException;
import java.io.Writer;
import java.io.StringWriter;
import java.util.Locale;

class StringEscapeUtils
{
    public StringEscapeUtils() {
    }
    
    private static String hex(final char ch) {
        return Integer.toHexString(ch).toUpperCase(Locale.ENGLISH);
    }
    
    public static String escapeHtml(final String str) {
        if (str == null) {
            return null;
        }
        try {
            final StringWriter writer = new StringWriter((int)(str.length() * 1.5));
            escapeHtml(writer, str);
            return writer.toString();
        }
        catch (IOException ioe) {
            throw new RuntimeException(ioe);
        }
    }
    
    public static void escapeHtml(final Writer writer, final String string) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        }
        if (string == null) {
            return;
        }
        Entities.HTML40.escape(writer, string);
    }
    
    public static String unescapeHtml(final String str) {
        if (str == null) {
            return null;
        }
        try {
            final StringWriter writer = new StringWriter((int)(str.length() * 1.5));
            unescapeHtml(writer, str);
            return writer.toString();
        }
        catch (IOException ioe) {
            throw new RuntimeException(ioe);
        }
    }
    
    public static void unescapeHtml(final Writer writer, final String string) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        }
        if (string == null) {
            return;
        }
        Entities.HTML40.unescape(writer, string);
    }
    
    public static void escapeXml(final Writer writer, final String str) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        }
        if (str == null) {
            return;
        }
        Entities.XML.escape(writer, str);
    }
    
    public static String escapeXml(final String str) {
        if (str == null) {
            return null;
        }
        return Entities.XML.escape(str);
    }
    
    public static void unescapeXml(final Writer writer, final String str) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        }
        if (str == null) {
            return;
        }
        Entities.XML.unescape(writer, str);
    }
    
    public static String unescapeXml(final String str) {
        if (str == null) {
            return null;
        }
        return Entities.XML.unescape(str);
    }
}
