// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import java.util.Arrays;
import org.apache.wicket.util.diff.Revision;
import org.junit.Assert;
import org.apache.wicket.util.diff.Diff;
import java.io.File;
import java.util.List;

class CssLicenseHeaderHandler extends AbstractLicenseHeaderHandler
{
    public CssLicenseHeaderHandler(final List<String> ignoreFiles) {
        super(ignoreFiles);
    }
    
    @Override
    protected String getLicenseHeaderFilename() {
        return "cssLicense.txt";
    }
    
    @Override
    public boolean checkLicenseHeader(final File file) {
        Revision revision = null;
        try {
            final String header = this.extractLicenseHeader(file, 0, 16);
            revision = Diff.diff(this.getLicenseHeader().split(CssLicenseHeaderHandler.LINE_ENDING), header.split(CssLicenseHeaderHandler.LINE_ENDING));
        }
        catch (Exception e) {
            Assert.fail(e.getMessage());
        }
        return revision.size() == 0;
    }
    
    @Override
    public List<String> getSuffixes() {
        return Arrays.asList("css");
    }
    
    @Override
    public boolean addLicenseHeader(final File file) {
        this.prependLicenseHeader(file);
        return true;
    }
}
