// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import org.apache.wicket.util.lang.Args;
import java.util.Date;
import java.util.Calendar;
import org.apache.wicket.util.convert.IConverter;

public class CalendarConverter implements IConverter<Calendar>
{
    private static final long serialVersionUID = 1L;
    private final IConverter<Date> dateConverter;
    
    public CalendarConverter() {
        this(new DateConverter());
    }
    
    public CalendarConverter(final IConverter<Date> dateConverter) {
        Args.notNull(dateConverter, "dateConverter");
        this.dateConverter = dateConverter;
    }
    
    @Override
    public Calendar convertToObject(final String value, final Locale locale) {
        final Date date = this.dateConverter.convertToObject(value, locale);
        if (date == null) {
            return null;
        }
        final Calendar calendar = (locale != null) ? Calendar.getInstance(locale) : Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }
    
    @Override
    public String convertToString(final Calendar value, final Locale locale) {
        if (value == null) {
            return null;
        }
        return this.dateConverter.convertToString(value.getTime(), locale);
    }
}
