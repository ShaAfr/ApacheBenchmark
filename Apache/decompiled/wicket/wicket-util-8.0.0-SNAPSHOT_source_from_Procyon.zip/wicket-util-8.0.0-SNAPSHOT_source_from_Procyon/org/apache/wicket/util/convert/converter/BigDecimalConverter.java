// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import java.math.BigDecimal;

public class BigDecimalConverter extends AbstractDecimalConverter<BigDecimal>
{
    private static final long serialVersionUID = 1L;
    
    @Override
    protected Class<BigDecimal> getTargetType() {
        return BigDecimal.class;
    }
    
    @Override
    public BigDecimal convertToObject(final String value, final Locale locale) {
        return this.parse(value, null, null, locale);
    }
}
