// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.thread;

public final class Lock
{
}
