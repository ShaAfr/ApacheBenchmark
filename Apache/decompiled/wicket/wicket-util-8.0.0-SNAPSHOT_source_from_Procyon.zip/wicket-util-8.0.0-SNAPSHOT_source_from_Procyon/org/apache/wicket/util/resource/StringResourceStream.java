// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

public final class StringResourceStream extends AbstractStringResourceStream
{
    private static final long serialVersionUID = 1L;
    private final CharSequence string;
    
    public StringResourceStream(final CharSequence string) {
        this(string, null);
    }
    
    public StringResourceStream(final CharSequence string, final String contentType) {
        super(contentType);
        this.string = string;
    }
    
    @Override
    public String toString() {
        return super.toString() + ": " + this.string.toString();
    }
    
    @Override
    protected String getString() {
        return this.string.toString();
    }
    
    @Override
    public String asString() {
        return this.getString();
    }
}
