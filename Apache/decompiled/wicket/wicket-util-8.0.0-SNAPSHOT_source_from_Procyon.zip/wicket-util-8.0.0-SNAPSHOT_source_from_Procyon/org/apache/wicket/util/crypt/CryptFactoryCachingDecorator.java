// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

import org.apache.wicket.util.lang.Args;

public class CryptFactoryCachingDecorator implements ICryptFactory
{
    private final ICryptFactory delegate;
    private ICrypt cache;
    
    public CryptFactoryCachingDecorator(final ICryptFactory delegate) {
        Args.notNull(delegate, "delegate");
        this.delegate = delegate;
    }
    
    @Override
    public final ICrypt newCrypt() {
        if (this.cache == null) {
            this.cache = this.delegate.newCrypt();
        }
        return this.cache;
    }
}
