// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.time;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.io.Serializable;

public final class TimeMap implements Serializable
{
    private static final long serialVersionUID = 1L;
    private final Map<ITimeFrameSource, Object> sources;
    
    public TimeMap() {
        this.sources = new ConcurrentHashMap<ITimeFrameSource, Object>();
    }
    
    public Object get() {
        return this.get(Time.now());
    }
    
    public Object get(final Time time) {
        for (final ITimeFrameSource source : this.sources.keySet()) {
            final TimeFrame current = source.getTimeFrame();
            if (current.contains(time)) {
                return this.sources.get(current);
            }
        }
        return null;
    }
    
    public void put(final ITimeFrameSource source, final Object o) {
        final TimeFrame timeframe = source.getTimeFrame();
        for (final ITimeFrameSource tfs : this.sources.keySet()) {
            final TimeFrame current = tfs.getTimeFrame();
            if (timeframe.overlaps(current)) {
                throw new IllegalArgumentException("Timeframe " + timeframe + " overlaps timeframe " + current);
            }
        }
        this.sources.put(source, o);
    }
}
