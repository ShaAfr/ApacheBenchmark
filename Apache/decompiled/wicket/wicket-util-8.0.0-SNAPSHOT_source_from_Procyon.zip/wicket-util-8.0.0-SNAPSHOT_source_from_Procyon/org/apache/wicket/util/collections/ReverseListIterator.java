// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.List;
import java.util.ListIterator;
import java.util.Iterator;

public class ReverseListIterator<E> implements Iterator<E>, Iterable<E>
{
    private final ListIterator<E> delegateIterator;
    
    public ReverseListIterator(final List<E> list) {
        final int start = list.size();
        this.delegateIterator = list.listIterator(start);
    }
    
    @Override
    public boolean hasNext() {
        return this.delegateIterator.hasPrevious();
    }
    
    @Override
    public E next() {
        return this.delegateIterator.previous();
    }
    
    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public Iterator<E> iterator() {
        return this;
    }
}
