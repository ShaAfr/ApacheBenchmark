// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.crypt;

public class NoCrypt implements ICrypt
{
    @Override
    public final String decryptUrlSafe(final String text) {
        return text;
    }
    
    @Override
    public final String encryptUrlSafe(final String plainText) {
        return plainText;
    }
    
    @Override
    public void setKey(final String key) {
    }
}
