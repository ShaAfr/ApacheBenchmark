// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.apache.wicket.util.time.Time;
import java.util.Locale;
import java.io.IOException;
import java.io.InputStream;
import org.apache.wicket.util.lang.Bytes;
import org.apache.wicket.util.lang.Args;

public class ResourceStreamWrapper implements IResourceStream
{
    private static final long serialVersionUID = 1L;
    private final IResourceStream delegate;
    
    public ResourceStreamWrapper(final IResourceStream delegate) {
        this.delegate = Args.notNull(delegate, "delegate");
    }
    
    public IResourceStream getDelegate() {
        return this.delegate;
    }
    
    @Override
    public String getContentType() {
        return this.delegate.getContentType();
    }
    
    @Override
    public Bytes length() {
        return this.delegate.length();
    }
    
    @Override
    public InputStream getInputStream() throws ResourceStreamNotFoundException {
        return this.delegate.getInputStream();
    }
    
    @Override
    public void close() throws IOException {
        this.delegate.close();
    }
    
    @Override
    public Locale getLocale() {
        return this.delegate.getLocale();
    }
    
    @Override
    public void setLocale(final Locale locale) {
        this.delegate.setLocale(locale);
    }
    
    @Override
    public String getStyle() {
        return this.delegate.getStyle();
    }
    
    @Override
    public void setStyle(final String style) {
        this.delegate.setStyle(style);
    }
    
    @Override
    public String getVariation() {
        return this.delegate.getVariation();
    }
    
    @Override
    public void setVariation(final String variation) {
        this.delegate.setVariation(variation);
    }
    
    @Override
    public Time lastModifiedTime() {
        return this.delegate.lastModifiedTime();
    }
}
