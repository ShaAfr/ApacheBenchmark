// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public final class Numbers
{
    private static final Logger LOG;
    
    private Numbers() {
    }
    
    public static Number getMinValue(final Class<? extends Number> numberType) {
        Number result;
        if (Integer.class == numberType || Integer.TYPE == numberType) {
            result = Integer.MIN_VALUE;
        }
        else if (Long.class == numberType || Long.TYPE == numberType) {
            result = Long.MIN_VALUE;
        }
        else if (Float.class == numberType || Float.TYPE == numberType) {
            result = -3.4028235E38f;
        }
        else if (Double.class == numberType || Double.TYPE == numberType) {
            result = -1.7976931348623157E308;
        }
        else if (Byte.class == numberType || Byte.TYPE == numberType) {
            result = -128;
        }
        else if (Short.class == numberType || Short.TYPE == numberType) {
            result = -32768;
        }
        else {
            Numbers.LOG.debug("'{}' has no minimum value. Falling back to Double.", (Object)numberType);
            result = -1.7976931348623157E308;
        }
        return result;
    }
    
    public static Number getMaxValue(final Class<? extends Number> numberType) {
        Number result;
        if (Integer.class == numberType || Integer.TYPE == numberType) {
            result = Integer.MAX_VALUE;
        }
        else if (Long.class == numberType || Long.TYPE == numberType) {
            result = Long.MAX_VALUE;
        }
        else if (Float.class == numberType || Float.TYPE == numberType) {
            result = Float.MAX_VALUE;
        }
        else if (Double.class == numberType || Double.TYPE == numberType) {
            result = Double.MAX_VALUE;
        }
        else if (Byte.class == numberType || Byte.TYPE == numberType) {
            result = 127;
        }
        else if (Short.class == numberType || Short.TYPE == numberType) {
            result = 32767;
        }
        else {
            Numbers.LOG.debug("'{}' has no maximum value. Falling back to Double.MAX_VALUE.");
            result = Double.MAX_VALUE;
        }
        return result;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)Numbers.class);
    }
}
