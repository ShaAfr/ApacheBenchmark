// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.text.ParsePosition;
import java.util.Locale;
import java.text.Format;
import org.apache.wicket.util.convert.IConverter;

public abstract class AbstractConverter<C> implements IConverter<C>
{
    private static final long serialVersionUID = 1L;
    
    protected C parse(final Format format, final Object value, final Locale locale) {
        final ParsePosition position = new ParsePosition(0);
        final String stringValue = value.toString();
        final C result = (C)format.parseObject(stringValue, position);
        if (position.getIndex() != stringValue.length()) {
            throw this.newConversionException("Cannot parse '" + value + "' using format " + format, value, locale).setFormat(format);
        }
        return result;
    }
    
    protected ConversionException newConversionException(final String message, final Object value, final Locale locale) {
        return new ConversionException(message).setSourceValue(value).setTargetType(this.getTargetType()).setConverter(this).setLocale(locale);
    }
    
    protected abstract Class<C> getTargetType();
    
    @Override
    public String convertToString(final C value, final Locale locale) {
        if (value == null) {
            return null;
        }
        return value.toString();
    }
}
