// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern.parsers;

import org.apache.wicket.util.parse.metapattern.MetaPattern;
import org.apache.wicket.util.parse.metapattern.Group;

public final class WordParser extends MetaPatternParser
{
    private static final Group word;
    private static final MetaPattern wordPattern;
    
    public WordParser(final CharSequence input) {
        super(WordParser.wordPattern, input);
    }
    
    public String getWord() {
        return WordParser.word.get(this.matcher());
    }
    
    static {
        word = new Group(MetaPattern.WORD);
        wordPattern = new MetaPattern(new MetaPattern[] { MetaPattern.OPTIONAL_WHITESPACE, WordParser.word, MetaPattern.OPTIONAL_WHITESPACE });
    }
}
