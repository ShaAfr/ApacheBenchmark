// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.time;

import org.apache.wicket.util.value.LongValue;
import java.util.Locale;
import java.util.Date;
import java.text.ParseException;
import java.util.Calendar;
import java.util.TimeZone;
import java.text.SimpleDateFormat;

public final class Time extends AbstractTime
{
    private static final long serialVersionUID = 1L;
    public static final Time START_OF_UNIX_TIME;
    private static final SimpleDateFormat dateFormat;
    private static final SimpleDateFormat dateTimeFormat;
    private static final String[] DAYS;
    private static final String[] MONTHS;
    public static final TimeZone GMT;
    
    public static Time now() {
        return millis(System.currentTimeMillis());
    }
    
    public static Time millis(final long time) {
        return new Time(time);
    }
    
    public static Time parseDate(final Calendar calendar, final String string) throws ParseException {
        synchronized (Time.dateFormat) {
            synchronized (calendar) {
                Time.dateFormat.setCalendar(calendar);
                return valueOf(Time.dateFormat.parse(string));
            }
        }
    }
    
    public static Time parseDate(final String string) throws ParseException {
        return parseDate(Time.localtime, string);
    }
    
    public static Time valueOf(final Calendar calendar, final String string) throws ParseException {
        synchronized (Time.dateTimeFormat) {
            synchronized (calendar) {
                Time.dateTimeFormat.setCalendar(calendar);
                return valueOf(Time.dateTimeFormat.parse(string));
            }
        }
    }
    
    public static Time valueOf(final Calendar calendar, final TimeOfDay timeOfDay) {
        synchronized (calendar) {
            calendar.setTimeInMillis(System.currentTimeMillis());
            calendar.set(11, 0);
            calendar.set(12, 0);
            calendar.set(13, 0);
            calendar.set(14, 0);
            return millis(calendar.getTimeInMillis() + timeOfDay.getMilliseconds());
        }
    }
    
    public static Time valueOf(final Date date) {
        return new Time(date.getTime());
    }
    
    public static Time valueOf(final String string) throws ParseException {
        return valueOf(Time.localtime, string);
    }
    
    public static Time valueOf(final String string, final String pattern) throws ParseException {
        final SimpleDateFormat dateTimeFormat = new SimpleDateFormat(pattern, Locale.ENGLISH);
        dateTimeFormat.setCalendar(Time.localtime);
        return valueOf(dateTimeFormat.parse(string));
    }
    
    public static Time valueOf(final TimeOfDay timeOfDay) {
        return valueOf(Time.localtime, timeOfDay);
    }
    
    private Time(final long time) {
        super(time);
    }
    
    public Time add(final Duration duration) {
        return millis(this.getMilliseconds() + duration.getMilliseconds());
    }
    
    public Duration elapsedSince() {
        final Time now = now();
        if (this.greaterThan(now)) {
            throw new IllegalStateException("This time is in the future");
        }
        return now.subtract(this);
    }
    
    public Duration fromNow() {
        return this.subtract(now());
    }
    
    public int get(final Calendar calendar, final int field) {
        synchronized (calendar) {
            calendar.setTimeInMillis(this.getMilliseconds());
            return calendar.get(field);
        }
    }
    
    public int get(final int field) {
        return this.get(Time.localtime, field);
    }
    
    public int getDayOfMonth() {
        return this.getDayOfMonth(Time.localtime);
    }
    
    public int getDayOfMonth(final Calendar calendar) {
        return this.get(calendar, 5);
    }
    
    public int getHour() {
        return this.getHour(Time.localtime);
    }
    
    public int getHour(final Calendar calendar) {
        return this.get(calendar, 11);
    }
    
    public int getMinute() {
        return this.getMinute(Time.localtime);
    }
    
    public int getMinute(final Calendar calendar) {
        return this.get(calendar, 12);
    }
    
    public int getMonth() {
        return this.getMonth(Time.localtime);
    }
    
    public int getMonth(final Calendar calendar) {
        return this.get(calendar, 2);
    }
    
    public int getSecond() {
        return this.getSecond(Time.localtime);
    }
    
    public int getSecond(final Calendar calendar) {
        return this.get(calendar, 13);
    }
    
    public int getYear() {
        return this.getYear(Time.localtime);
    }
    
    public int getYear(final Calendar calendar) {
        return this.get(calendar, 1);
    }
    
    public Time subtract(final Duration duration) {
        return millis(this.getMilliseconds() - duration.getMilliseconds());
    }
    
    public Duration subtract(final Time that) {
        return Duration.milliseconds(this.getMilliseconds() - that.getMilliseconds());
    }
    
    public Date toDate() {
        return new Date(this.getMilliseconds());
    }
    
    public String toDateString() {
        return this.toDateString(Time.localtime);
    }
    
    public String toDateString(final Calendar calendar) {
        synchronized (Time.dateFormat) {
            synchronized (calendar) {
                Time.dateFormat.setCalendar(calendar);
                return Time.dateFormat.format(new Date(this.getMilliseconds())).toLowerCase();
            }
        }
    }
    
    @Override
    public String toString() {
        return this.toDateString() + "-" + this.toTimeString();
    }
    
    public String toString(final Calendar calendar, final String format) {
        final SimpleDateFormat dateTimeFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        dateTimeFormat.setCalendar((calendar == null) ? Time.localtime : calendar);
        return dateTimeFormat.format(new Date(this.getMilliseconds()));
    }
    
    public String toString(final String format) {
        return this.toString(null, format);
    }
    
    public String toRfc1123TimestampString() {
        final Calendar cal = Calendar.getInstance(Time.GMT);
        final StringBuilder buf = new StringBuilder(32);
        cal.setTimeInMillis(this.getMilliseconds());
        final int day_of_week = cal.get(7);
        final int day_of_month = cal.get(5);
        final int month = cal.get(2);
        int year = cal.get(1);
        final int century = year / 100;
        year %= 100;
        final int hours = cal.get(11);
        final int minutes = cal.get(12);
        final int seconds = cal.get(13);
        buf.append(Time.DAYS[day_of_week]);
        buf.append(',');
        buf.append(' ');
        appendTwoDigits(buf, day_of_month);
        buf.append(' ');
        buf.append(Time.MONTHS[month]);
        buf.append(' ');
        appendTwoDigits(buf, century);
        appendTwoDigits(buf, year);
        buf.append(' ');
        appendTwoDigits(buf, hours);
        buf.append(':');
        appendTwoDigits(buf, minutes);
        buf.append(':');
        appendTwoDigits(buf, seconds);
        buf.append(" GMT");
        return buf.toString();
    }
    
    private static void appendTwoDigits(final StringBuilder str, final int number) {
        str.append((char)(number / 10 + 48));
        str.append((char)(number % 10 + 48));
    }
    
    static {
        START_OF_UNIX_TIME = millis(0L);
        dateFormat = new SimpleDateFormat("yyyy.MM.dd", Locale.ENGLISH);
        dateTimeFormat = new SimpleDateFormat("yyyy.MM.dd-h.mma", Locale.ENGLISH);
        DAYS = new String[] { "Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
        MONTHS = new String[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan" };
        GMT = TimeZone.getTimeZone("GMT");
    }
}
