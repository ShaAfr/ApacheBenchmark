// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import org.apache.commons.io.FileDeleteStrategy;
import java.io.File;

public interface IFileCleaner
{
    void track(final File p0, final Object p1);
    
    void track(final File p0, final Object p1, final FileDeleteStrategy p2);
    
    void destroy();
}
