// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import java.io.IOException;
import java.io.OutputStream;

public interface IResourceStreamWriter extends IResourceStream
{
    void write(final OutputStream p0) throws IOException;
}
