// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.util.Date;
import java.text.DateFormat;
import java.util.Locale;
import java.sql.Timestamp;

public class SqlTimestampConverter extends AbstractDateConverter<Timestamp>
{
    private static final long serialVersionUID = 1L;
    private final int dateFormat;
    private final int timeFormat;
    
    public SqlTimestampConverter() {
        this(3, 3);
    }
    
    public SqlTimestampConverter(final int dateFormat) {
        this(dateFormat, 3);
    }
    
    public SqlTimestampConverter(final int dateFormat, final int timeFormat) {
        this.dateFormat = dateFormat;
        this.timeFormat = timeFormat;
    }
    
    @Override
    public DateFormat getDateFormat(Locale locale) {
        if (locale == null) {
            locale = Locale.getDefault(Locale.Category.FORMAT);
        }
        return (DateFormat)DateFormat.getDateTimeInstance(this.dateFormat, this.timeFormat, locale).clone();
    }
    
    @Override
    protected Timestamp createDateLike(final long date) {
        return new Timestamp(date);
    }
    
    @Override
    protected Class<Timestamp> getTargetType() {
        return Timestamp.class;
    }
}
