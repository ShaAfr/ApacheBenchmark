// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.visit;

import org.apache.wicket.util.lang.Args;

public class ClassVisitFilter implements IVisitFilter
{
    private final Class<?> clazz;
    
    public ClassVisitFilter(final Class<?> clazz) {
        Args.notNull(clazz, "clazz");
        this.clazz = clazz;
    }
    
    @Override
    public boolean visitChildren(final Object object) {
        return true;
    }
    
    @Override
    public boolean visitObject(final Object object) {
        return this.clazz.isAssignableFrom(object.getClass());
    }
}
