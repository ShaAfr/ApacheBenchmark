// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.text.ParseException;
import java.io.IOException;
import java.io.Reader;

public final class FullyBufferedReader
{
    private final String input;
    private int inputPosition;
    private int lineNumber;
    private int columnNumber;
    private int lastLineCountIndex;
    private int positionMarker;
    
    public FullyBufferedReader(final Reader reader) throws IOException {
        this(Streams.readString(reader));
    }
    
    public FullyBufferedReader(final String input) {
        this.lineNumber = 1;
        this.columnNumber = 1;
        this.input = input;
    }
    
    public final CharSequence getSubstring(int toPos) {
        if (toPos < 0) {
            toPos = this.input.length();
        }
        else if (toPos < this.positionMarker) {
            return "";
        }
        return this.input.subSequence(this.positionMarker, toPos);
    }
    
    public final CharSequence getSubstring(final int fromPos, final int toPos) {
        return this.input.subSequence(fromPos, toPos);
    }
    
    public final int getPosition() {
        return this.inputPosition;
    }
    
    public final void setPositionMarker(final int pos) {
        this.positionMarker = pos;
    }
    
    @Override
    public String toString() {
        return this.input;
    }
    
    public final void countLinesTo(final int end) {
        for (int i = this.lastLineCountIndex; i < end; ++i) {
            final char ch = this.input.charAt(i);
            if (ch == '\n') {
                this.columnNumber = 1;
                ++this.lineNumber;
            }
            else if (ch != '\r') {
                ++this.columnNumber;
            }
        }
        this.lastLineCountIndex = end;
    }
    
    public final int find(final char ch) {
        return this.input.indexOf(ch, this.inputPosition);
    }
    
    public final int find(final char ch, final int startPos) {
        return this.input.indexOf(ch, startPos);
    }
    
    public final int find(final String str) {
        return this.input.indexOf(str, this.inputPosition);
    }
    
    public final int find(final String str, final int startPos) {
        return this.input.indexOf(str, startPos);
    }
    
    public int findOutOfQuotes(final char ch, final int startPos) throws ParseException {
        return this.findOutOfQuotes(ch, startPos, '\0');
    }
    
    public int findOutOfQuotes(final char ch, final int startPos, char quotationChar) throws ParseException {
        final int closeBracketIndex = this.find(ch, startPos + 1);
        if (closeBracketIndex != -1) {
            final CharSequence tagCode = this.getSubstring(startPos, closeBracketIndex + 1);
            for (int i = 0; i < tagCode.length(); ++i) {
                final char currentChar = tagCode.charAt(i);
                final char previousTag = tagCode.charAt((i > 0) ? (i - 1) : 0);
                if (quotationChar == '\0' && (currentChar == '\'' || currentChar == '\"')) {
                    quotationChar = currentChar;
                    this.countLinesTo(startPos + i);
                }
                else if (currentChar == quotationChar && previousTag != '\\') {
                    quotationChar = '\0';
                }
                if (currentChar == ch && quotationChar != '\0') {
                    return this.findOutOfQuotes(ch, closeBracketIndex + 1, quotationChar);
                }
            }
        }
        else if (quotationChar != '\0') {
            throw new ParseException("Opening/closing quote not found for quote at (line " + this.getLineNumber() + ", column " + this.getColumnNumber() + ")", startPos);
        }
        return closeBracketIndex;
    }
    
    public final void setPosition(final int pos) {
        this.inputPosition = pos;
    }
    
    public final int getColumnNumber() {
        return this.columnNumber;
    }
    
    public final int getLineNumber() {
        return this.lineNumber;
    }
    
    public final int size() {
        return this.input.length();
    }
    
    public final char charAt(final int pos) {
        return this.input.charAt(pos);
    }
}
