// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.List;

public class DeleteDelta extends Delta
{
    DeleteDelta() {
    }
    
    public DeleteDelta(final Chunk orig) {
        this.init(orig, null);
    }
    
    @Override
    public void verify(final List<Object> target) throws PatchFailedException {
        if (!this.original.verify(target)) {
            throw new PatchFailedException();
        }
    }
    
    @Override
    public void applyTo(final List<Object> target) {
        this.original.applyDelete(target);
    }
    
    @Override
    public void toString(final StringBuilder s) {
        s.append(this.original.rangeString());
        s.append("d");
        s.append(this.revised.rcsto());
        s.append(Diff.NL);
        this.original.toString(s, "< ", Diff.NL);
    }
    
    @Override
    public void toRCSString(final StringBuilder s, final String EOL) {
        s.append("d");
        s.append(this.original.rcsfrom());
        s.append(" ");
        s.append(this.original.size());
        s.append(EOL);
    }
    
    @Override
    public void accept(final RevisionVisitor visitor) {
        visitor.visit(this);
    }
}
