// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import java.util.Collection;
import org.apache.wicket.util.string.Strings;

public class Args
{
    public static <T> T notNull(final T argument, final String name) {
        if (argument == null) {
            throw new IllegalArgumentException("Argument '" + name + "' may not be null.");
        }
        return argument;
    }
    
    public static <T extends CharSequence> T notEmpty(final T argument, final String name) {
        if (Strings.isEmpty(argument)) {
            throw new IllegalArgumentException("Argument '" + name + "' may not be null or empty.");
        }
        return argument;
    }
    
    public static <T extends Collection<?>> T notEmpty(final T collection, final String message, final Object... params) {
        if (collection == null || collection.isEmpty()) {
            throw new IllegalArgumentException(format(message, params));
        }
        return collection;
    }
    
    public static <T extends Collection<?>> T notEmpty(final T collection, final String name) {
        return notEmpty(collection, "Collection '%s' may not be null or empty.", name);
    }
    
    public static <T extends Comparable<? super T>> T withinRange(final T min, final T max, final T value, final String name) {
        notNull(min, name);
        notNull(max, name);
        if (value.compareTo((Object)min) < 0 || value.compareTo((Object)max) > 0) {
            throw new IllegalArgumentException(String.format("Argument '%s' must have a value within [%s,%s], but was %s", name, min, max, value));
        }
        return value;
    }
    
    public static boolean isTrue(final boolean argument, final String msg, final Object... params) {
        if (!argument) {
            throw new IllegalArgumentException(format(msg, params));
        }
        return argument;
    }
    
    public static boolean isFalse(final boolean argument, final String msg, final Object... params) {
        if (argument) {
            throw new IllegalArgumentException(format(msg, params));
        }
        return argument;
    }
    
    static String format(String msg, final Object... params) {
        msg = msg.replaceAll("\\{\\}", "%s");
        return String.format(msg, params);
    }
}
