// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import java.time.format.FormatStyle;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAccessor;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;

public class LocalDateConverter extends AbstractJavaTimeConverter<LocalDate>
{
    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter SHORT_DATE_TIME_FORMATTER;
    
    @Override
    protected Class<LocalDate> getTargetType() {
        return LocalDate.class;
    }
    
    @Override
    protected LocalDate createTemporal(final TemporalAccessor temporalAccessor) {
        return LocalDate.from(temporalAccessor);
    }
    
    @Override
    protected DateTimeFormatter getDateTimeFormatter() {
        return LocalDateConverter.SHORT_DATE_TIME_FORMATTER;
    }
    
    static {
        SHORT_DATE_TIME_FORMATTER = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
    }
}
