// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff.myers;

public abstract class PathNode
{
    public final int i;
    public final int j;
    public final PathNode prev;
    
    public PathNode(final int i, final int j, final PathNode prev) {
        this.i = i;
        this.j = j;
        this.prev = prev;
    }
    
    public abstract boolean isSnake();
    
    public boolean isBootstrap() {
        return this.i < 0 || this.j < 0;
    }
    
    public final PathNode previousSnake() {
        if (this.isBootstrap()) {
            return null;
        }
        if (!this.isSnake() && this.prev != null) {
            return this.prev.previousSnake();
        }
        return this;
    }
    
    @Override
    public String toString() {
        final StringBuilder buf = new StringBuilder("[");
        for (PathNode node = this; node != null; node = node.prev) {
            buf.append("(");
            buf.append(Integer.toString(node.i));
            buf.append(",");
            buf.append(Integer.toString(node.j));
            buf.append(")");
        }
        buf.append("]");
        return buf.toString();
    }
}
