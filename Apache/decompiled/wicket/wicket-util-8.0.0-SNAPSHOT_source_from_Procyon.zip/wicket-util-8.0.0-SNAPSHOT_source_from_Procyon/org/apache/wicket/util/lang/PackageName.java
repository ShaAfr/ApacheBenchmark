// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import org.apache.wicket.util.io.IClusterable;

public class PackageName implements IClusterable
{
    private static final long serialVersionUID = 1L;
    private final String name;
    
    public static PackageName forClass(final Class<?> c) {
        return new PackageName(Packages.extractPackageName(c));
    }
    
    public static PackageName forPackage(final Package p) {
        return new PackageName(p.getName());
    }
    
    private PackageName(final String name) {
        this.name = name;
    }
    
    @Override
    public boolean equals(final Object that) {
        return that instanceof PackageName && ((PackageName)that).name.equals(this.name);
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
        return result;
    }
    
    public String getName() {
        return this.name;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
}
