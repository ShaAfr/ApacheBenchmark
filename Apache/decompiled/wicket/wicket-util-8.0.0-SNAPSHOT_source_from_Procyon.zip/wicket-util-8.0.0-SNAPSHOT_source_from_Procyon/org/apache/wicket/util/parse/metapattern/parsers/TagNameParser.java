// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern.parsers;

import org.apache.wicket.util.parse.metapattern.OptionalMetaPattern;
import org.apache.wicket.util.parse.metapattern.MetaPattern;
import org.apache.wicket.util.parse.metapattern.Group;

public final class TagNameParser extends MetaPatternParser
{
    private static final Group namespaceGroup;
    private static final Group nameGroup;
    private static final MetaPattern pattern;
    
    public TagNameParser(final CharSequence input) {
        super(TagNameParser.pattern, input);
    }
    
    public String getNamespace() {
        final String namespace = TagNameParser.namespaceGroup.get(this.matcher());
        if (namespace != null) {
            return namespace.toLowerCase();
        }
        return namespace;
    }
    
    public String getName() {
        return TagNameParser.nameGroup.get(this.matcher());
    }
    
    static {
        namespaceGroup = new Group(MetaPattern.VARIABLE_NAME);
        nameGroup = new Group(MetaPattern.XML_ELEMENT_NAME);
        pattern = new MetaPattern(new MetaPattern[] { new OptionalMetaPattern(new MetaPattern[] { TagNameParser.namespaceGroup, MetaPattern.COLON }), TagNameParser.nameGroup });
    }
}
