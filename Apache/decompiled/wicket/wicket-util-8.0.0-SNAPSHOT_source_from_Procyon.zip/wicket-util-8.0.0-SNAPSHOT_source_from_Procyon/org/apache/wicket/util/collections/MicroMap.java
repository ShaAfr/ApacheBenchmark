// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.AbstractList;
import java.util.Collection;
import java.util.NoSuchElementException;
import java.util.Iterator;
import java.util.AbstractSet;
import java.util.Set;
import java.io.Serializable;
import java.util.Map;

public final class MicroMap<K, V> implements Map<K, V>, Serializable
{
    private static final long serialVersionUID = 1L;
    public static final int MAX_ENTRIES = 1;
    private K key;
    private V value;
    
    public MicroMap() {
    }
    
    public MicroMap(final K key, final V value) {
        this.put(key, value);
    }
    
    public boolean isFull() {
        return this.size() == 1;
    }
    
    @Override
    public int size() {
        return (this.key != null) ? 1 : 0;
    }
    
    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }
    
    @Override
    public boolean containsKey(final Object key) {
        return key.equals(this.key);
    }
    
    @Override
    public boolean containsValue(final Object value) {
        return value.equals(this.value);
    }
    
    @Override
    public V get(final Object key) {
        if (key.equals(this.key)) {
            return this.value;
        }
        return null;
    }
    
    @Override
    public V put(final K key, final V value) {
        if (key.equals(this.key)) {
            final V oldValue = this.value;
            this.value = value;
            return oldValue;
        }
        if (this.size() < 1) {
            this.key = key;
            this.value = value;
            return null;
        }
        throw new IllegalStateException("Map full");
    }
    
    @Override
    public V remove(final Object key) {
        if (key.equals(this.key)) {
            final V oldValue = this.value;
            this.key = null;
            this.value = null;
            return oldValue;
        }
        return null;
    }
    
    @Override
    public void putAll(final Map<? extends K, ? extends V> map) {
        if (map.size() <= 1) {
            final Entry<? extends K, ? extends V> e = map.entrySet().iterator().next();
            this.put(e.getKey(), e.getValue());
            return;
        }
        throw new IllegalStateException("Map full.  Cannot add " + map.size() + " entries");
    }
    
    @Override
    public void clear() {
        this.key = null;
        this.value = null;
    }
    
    @Override
    public Set<K> keySet() {
        return new AbstractSet<K>() {
            @Override
            public Iterator<K> iterator() {
                return new Iterator<K>() {
                    int index;
                    
                    @Override
                    public boolean hasNext() {
                        return this.index < MicroMap.this.size();
                    }
                    
                    @Override
                    public K next() {
                        if (!this.hasNext()) {
                            throw new NoSuchElementException();
                        }
                        ++this.index;
                        return MicroMap.this.key;
                    }
                    
                    @Override
                    public void remove() {
                        MicroMap.this.clear();
                    }
                };
            }
            
            @Override
            public int size() {
                return MicroMap.this.size();
            }
        };
    }
    
    @Override
    public Collection<V> values() {
        return new AbstractList<V>() {
            @Override
            public V get(final int index) {
                if (index > this.size() - 1) {
                    throw new IndexOutOfBoundsException();
                }
                return MicroMap.this.value;
            }
            
            @Override
            public int size() {
                return MicroMap.this.size();
            }
        };
    }
    
    @Override
    public Set<Entry<K, V>> entrySet() {
        return new AbstractSet<Entry<K, V>>() {
            @Override
            public Iterator<Entry<K, V>> iterator() {
                return new Iterator<Entry<K, V>>() {
                    int index = 0;
                    
                    @Override
                    public boolean hasNext() {
                        return this.index < MicroMap.this.size();
                    }
                    
                    @Override
                    public Entry<K, V> next() {
                        if (!this.hasNext()) {
                            throw new NoSuchElementException();
                        }
                        ++this.index;
                        return new Entry<K, V>() {
                            @Override
                            public K getKey() {
                                return MicroMap.this.key;
                            }
                            
                            @Override
                            public V getValue() {
                                return MicroMap.this.value;
                            }
                            
                            @Override
                            public V setValue(final V value) {
                                final V oldValue = MicroMap.this.value;
                                MicroMap.this.value = value;
                                return oldValue;
                            }
                        };
                    }
                    
                    @Override
                    public void remove() {
                        AbstractSet.this.clear();
                    }
                };
            }
            
            @Override
            public int size() {
                return MicroMap.this.size();
            }
        };
    }
}
