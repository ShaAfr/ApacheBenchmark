// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.io.UnsupportedEncodingException;
import org.apache.wicket.util.lang.Args;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.List;
import java.util.regex.Pattern;

public final class Strings
{
    public static final String LINE_SEPARATOR;
    private static final char[] HEX_DIGIT;
    private static final Pattern HTML_NUMBER_REGEX;
    private static final String[] NO_STRINGS;
    public static final String SESSION_ID_PARAM_NAME;
    private static final String SESSION_ID_PARAM;
    
    private Strings() {
    }
    
    public static String afterFirst(final String s, final char c) {
        if (s == null) {
            return null;
        }
        final int index = s.indexOf(c);
        if (index == -1) {
            return "";
        }
        return s.substring(index + 1);
    }
    
    public static String afterFirstPathComponent(final String path, final char separator) {
        return afterFirst(path, separator);
    }
    
    public static String afterLast(final String s, final char c) {
        if (s == null) {
            return null;
        }
        final int index = s.lastIndexOf(c);
        if (index == -1) {
            return "";
        }
        return s.substring(index + 1);
    }
    
    public static String beforeFirst(final String s, final char c) {
        if (s == null) {
            return null;
        }
        final int index = s.indexOf(c);
        if (index == -1) {
            return "";
        }
        return s.substring(0, index);
    }
    
    public static String beforeLast(final String s, final char c) {
        if (s == null) {
            return null;
        }
        final int index = s.lastIndexOf(c);
        if (index == -1) {
            return "";
        }
        return s.substring(0, index);
    }
    
    public static String beforeLastPathComponent(final String path, final char separator) {
        return beforeLast(path, separator);
    }
    
    public static String capitalize(final String s) {
        if (s == null) {
            return null;
        }
        final char[] chars = s.toCharArray();
        if (chars.length > 0) {
            chars[0] = Character.toUpperCase(chars[0]);
        }
        return new String(chars);
    }
    
    public static CharSequence escapeMarkup(final CharSequence s) {
        return escapeMarkup(s, false);
    }
    
    public static CharSequence escapeMarkup(final CharSequence s, final boolean escapeSpaces) {
        return escapeMarkup(s, escapeSpaces, false);
    }
    
    public static CharSequence escapeMarkup(final CharSequence s, final boolean escapeSpaces, final boolean convertToHtmlUnicodeEscapes) {
        if (s == null) {
            return null;
        }
        final int len = s.length();
        final AppendingStringBuffer buffer = new AppendingStringBuffer((int)(len * 1.1));
        for (int i = 0; i < len; ++i) {
            final char c = s.charAt(i);
            switch (c) {
                case '\t': {
                    if (escapeSpaces) {
                        buffer.append("&nbsp;&nbsp;&nbsp;&nbsp;");
                        break;
                    }
                    buffer.append(c);
                    break;
                }
                case ' ': {
                    if (escapeSpaces) {
                        buffer.append("&nbsp;");
                        break;
                    }
                    buffer.append(c);
                    break;
                }
                case '<': {
                    buffer.append("&lt;");
                    break;
                }
                case '>': {
                    buffer.append("&gt;");
                    break;
                }
                case '&': {
                    buffer.append("&amp;");
                    break;
                }
                case '\"': {
                    buffer.append("&quot;");
                    break;
                }
                case '\'': {
                    buffer.append("&#039;");
                    break;
                }
                default: {
                    final int ci = '\uffff' & c;
                    if ((ci < 32 && ci != 9 && ci != 10 && ci != 13) || (convertToHtmlUnicodeEscapes && ci > 159)) {
                        buffer.append("&#");
                        buffer.append(Integer.toString(ci));
                        buffer.append(';');
                        break;
                    }
                    buffer.append(c);
                    break;
                }
            }
        }
        return buffer;
    }
    
    public static CharSequence unescapeMarkup(final String markup) {
        final String unescapedMarkup = StringEscapeUtils.unescapeHtml(markup);
        return unescapedMarkup;
    }
    
    public static String firstPathComponent(final String path, final char separator) {
        if (path == null) {
            return null;
        }
        final int index = path.indexOf(separator);
        if (index == -1) {
            return path;
        }
        return path.substring(0, index);
    }
    
    public static String fromEscapedUnicode(final String escapedUnicodeString) {
        int off = 0;
        final char[] in = escapedUnicodeString.toCharArray();
        final int len = in.length;
        final char[] out = new char[len];
        int outLen = 0;
        final int end = off + len;
        while (off < end) {
            char aChar = in[off++];
            if (aChar == '\\') {
                aChar = in[off++];
                if (aChar == 'u') {
                    int value = 0;
                    for (int i = 0; i < 4; ++i) {
                        aChar = in[off++];
                        switch (aChar) {
                            case '0':
                            case '1':
                            case '2':
                            case '3':
                            case '4':
                            case '5':
                            case '6':
                            case '7':
                            case '8':
                            case '9': {
                                value = (value << 4) + aChar - 48;
                                break;
                            }
                            case 'a':
                            case 'b':
                            case 'c':
                            case 'd':
                            case 'e':
                            case 'f': {
                                value = (value << 4) + 10 + aChar - 97;
                                break;
                            }
                            case 'A':
                            case 'B':
                            case 'C':
                            case 'D':
                            case 'E':
                            case 'F': {
                                value = (value << 4) + 10 + aChar - 65;
                                break;
                            }
                            default: {
                                throw new IllegalArgumentException("Malformed \\uxxxx encoding.");
                            }
                        }
                    }
                    out[outLen++] = (char)value;
                }
                else {
                    if (aChar == 't') {
                        aChar = '\t';
                    }
                    else if (aChar == 'r') {
                        aChar = '\r';
                    }
                    else if (aChar == 'n') {
                        aChar = '\n';
                    }
                    else if (aChar == 'f') {
                        aChar = '\f';
                    }
                    out[outLen++] = aChar;
                }
            }
            else {
                out[outLen++] = aChar;
            }
        }
        return new String(out, 0, outLen);
    }
    
    public static boolean isEmpty(final CharSequence string) {
        return string == null || string.length() == 0 || string.toString().trim().length() == 0;
    }
    
    public static boolean isEqual(final String string1, final String string2) {
        return (string1 == null && string2 == null) || (isEmpty(string1) && isEmpty(string2)) || (string1 != null && string2 != null && string1.equals(string2));
    }
    
    public static boolean isTrue(final String s) throws StringValueConversionException {
        if (s == null) {
            return false;
        }
        if (s.equalsIgnoreCase("true")) {
            return true;
        }
        if (s.equalsIgnoreCase("false")) {
            return false;
        }
        if (s.equalsIgnoreCase("on") || s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("y") || s.equalsIgnoreCase("1")) {
            return true;
        }
        if (s.equalsIgnoreCase("off") || s.equalsIgnoreCase("no") || s.equalsIgnoreCase("n") || s.equalsIgnoreCase("0")) {
            return false;
        }
        if (isEmpty(s)) {
            return false;
        }
        throw new StringValueConversionException("Boolean value \"" + s + "\" not recognized");
    }
    
    public static String join(final String separator, final List<String> fragments) {
        if (fragments == null) {
            return "";
        }
        return join(separator, (String[])fragments.toArray(new String[fragments.size()]));
    }
    
    public static String join(final String separator, final String... fragments) {
        if (fragments == null || fragments.length < 1) {
            return "";
        }
        if (fragments.length < 2) {
            return fragments[0];
        }
        final StringBuilder buff = new StringBuilder(128);
        if (fragments[0] != null) {
            buff.append(fragments[0]);
        }
        for (int i = 1; i < fragments.length; ++i) {
            final String fragment = fragments[i];
            if (fragments[i - 1] != null || fragment != null) {
                final boolean lhsClosed = fragments[i - 1].endsWith(separator);
                final boolean rhsClosed = fragment.startsWith(separator);
                if (!isEmpty(separator) && lhsClosed && rhsClosed) {
                    buff.append(fragment.substring(1));
                }
                else if (!lhsClosed && !rhsClosed) {
                    if (!isEmpty(fragment)) {
                        buff.append(separator);
                    }
                    buff.append(fragment);
                }
                else {
                    buff.append(fragment);
                }
            }
        }
        return buff.toString();
    }
    
    public static String lastPathComponent(final String path, final char separator) {
        if (path == null) {
            return null;
        }
        final int index = path.lastIndexOf(separator);
        if (index == -1) {
            return path;
        }
        return path.substring(index + 1);
    }
    
    public static CharSequence replaceAll(final CharSequence s, final CharSequence searchFor, CharSequence replaceWith) {
        if (s == null) {
            return null;
        }
        if (searchFor == null || "".equals(searchFor)) {
            return s;
        }
        if (replaceWith == null) {
            replaceWith = "";
        }
        final String searchString = searchFor.toString();
        int matchIndex = search(s, searchString, 0);
        if (matchIndex == -1) {
            return s;
        }
        int size = s.length();
        final int replaceWithLength = replaceWith.length();
        final int searchForLength = searchFor.length();
        if (replaceWithLength > searchForLength) {
            size += replaceWithLength - searchForLength;
        }
        final AppendingStringBuffer buffer = new AppendingStringBuffer(size + 16);
        int pos = 0;
        do {
            append(buffer, s, pos, matchIndex);
            buffer.append(replaceWith);
            pos = matchIndex + searchForLength;
            matchIndex = search(s, searchString, pos);
        } while (matchIndex != -1);
        buffer.append(s.subSequence(pos, s.length()));
        return buffer;
    }
    
    public static String replaceHtmlEscapeNumber(String str) {
        if (str == null) {
            return null;
        }
        for (Matcher matcher = Strings.HTML_NUMBER_REGEX.matcher(str); matcher.find(); matcher = Strings.HTML_NUMBER_REGEX.matcher(str)) {
            final int pos = matcher.start();
            final int end = matcher.end();
            final int number = Integer.parseInt(str.substring(pos + 2, end - 1));
            final char ch = (char)number;
            str = str.substring(0, pos) + ch + str.substring(end);
        }
        return str;
    }
    
    public static String[] split(final String s, final char c) {
        if (s == null || s.length() == 0) {
            return Strings.NO_STRINGS;
        }
        final List<String> strings = new ArrayList<String>();
        int pos = 0;
        while (true) {
            final int next = s.indexOf(c, pos);
            if (next == -1) {
                break;
            }
            strings.add(s.substring(pos, next));
            pos = next + 1;
        }
        strings.add(s.substring(pos));
        final String[] result = new String[strings.size()];
        strings.toArray(result);
        return result;
    }
    
    public static String stripEnding(final String s, final String ending) {
        if (s == null) {
            return null;
        }
        if (ending == null || "".equals(ending)) {
            return s;
        }
        final int endingLength = ending.length();
        final int sLength = s.length();
        if (endingLength > sLength) {
            return s;
        }
        final int index = s.lastIndexOf(ending);
        final int endpos = sLength - endingLength;
        if (index == endpos) {
            return s.substring(0, endpos);
        }
        return s;
    }
    
    public static String stripJSessionId(final String url) {
        if (isEmpty(url)) {
            return url;
        }
        final int ixSemiColon = url.toLowerCase(Locale.ENGLISH).indexOf(Strings.SESSION_ID_PARAM);
        if (ixSemiColon == -1) {
            return url;
        }
        final int ixQuestionMark = url.indexOf(63);
        if (ixQuestionMark == -1) {
            return url.substring(0, ixSemiColon);
        }
        if (ixQuestionMark <= ixSemiColon) {
            return url;
        }
        return url.substring(0, ixSemiColon) + url.substring(ixQuestionMark);
    }
    
    public static Boolean toBoolean(final String s) throws StringValueConversionException {
        return isTrue(s);
    }
    
    public static char toChar(final String s) throws StringValueConversionException {
        if (s == null) {
            throw new StringValueConversionException("Character value was null");
        }
        if (s.length() == 1) {
            return s.charAt(0);
        }
        throw new StringValueConversionException("Expected single character, not \"" + s + "\"");
    }
    
    public static String toEscapedUnicode(final String unicodeString) {
        if (unicodeString == null || unicodeString.length() == 0) {
            return unicodeString;
        }
        final int len = unicodeString.length();
        final int bufLen = len * 2;
        final StringBuilder outBuffer = new StringBuilder(bufLen);
        for (int x = 0; x < len; ++x) {
            final char aChar = unicodeString.charAt(x);
            if (aChar > '=' && aChar < '\u007f') {
                if (aChar == '\\') {
                    outBuffer.append('\\');
                    outBuffer.append('\\');
                }
                else {
                    outBuffer.append(aChar);
                }
            }
            else {
                switch (aChar) {
                    case ' ': {
                        if (x == 0) {
                            outBuffer.append('\\');
                        }
                        outBuffer.append(' ');
                        break;
                    }
                    case '\t': {
                        outBuffer.append('\\');
                        outBuffer.append('t');
                        break;
                    }
                    case '\n': {
                        outBuffer.append('\\');
                        outBuffer.append('n');
                        break;
                    }
                    case '\r': {
                        outBuffer.append('\\');
                        outBuffer.append('r');
                        break;
                    }
                    case '\f': {
                        outBuffer.append('\\');
                        outBuffer.append('f');
                        break;
                    }
                    case '!':
                    case '#':
                    case ':':
                    case '=': {
                        outBuffer.append('\\');
                        outBuffer.append(aChar);
                        break;
                    }
                    default: {
                        if (aChar < ' ' || aChar > '~') {
                            outBuffer.append('\\');
                            outBuffer.append('u');
                            outBuffer.append(toHex(aChar >> 12 & 0xF));
                            outBuffer.append(toHex(aChar >> 8 & 0xF));
                            outBuffer.append(toHex(aChar >> 4 & 0xF));
                            outBuffer.append(toHex(aChar & '\u000f'));
                            break;
                        }
                        outBuffer.append(aChar);
                        break;
                    }
                }
            }
        }
        return outBuffer.toString();
    }
    
    public static CharSequence toMultilineMarkup(final CharSequence s) {
        if (s == null) {
            return null;
        }
        final AppendingStringBuffer buffer = new AppendingStringBuffer();
        int newlineCount = 0;
        buffer.append("<p>");
        for (int i = 0; i < s.length(); ++i) {
            final char c = s.charAt(i);
            switch (c) {
                case '\n': {
                    ++newlineCount;
                    break;
                }
                case '\r': {
                    break;
                }
                default: {
                    if (newlineCount == 1) {
                        buffer.append("<br/>");
                    }
                    else if (newlineCount > 1) {
                        buffer.append("</p><p>");
                    }
                    buffer.append(c);
                    newlineCount = 0;
                    break;
                }
            }
        }
        if (newlineCount == 1) {
            buffer.append("<br/>");
        }
        else if (newlineCount > 1) {
            buffer.append("</p><p>");
        }
        buffer.append("</p>");
        return buffer;
    }
    
    public static String toString(final Object object) {
        if (object == null) {
            return null;
        }
        if (object instanceof Throwable) {
            return toString((Throwable)object);
        }
        if (object instanceof String) {
            return (String)object;
        }
        if (object instanceof String[] && ((String[])object).length == 1) {
            return ((String[])object)[0];
        }
        return object.toString();
    }
    
    public static String toString(final Throwable throwable) {
        if (throwable != null) {
            final List<Throwable> al = new ArrayList<Throwable>();
            Throwable cause = throwable;
            al.add(cause);
            while (cause.getCause() != null && cause != cause.getCause()) {
                cause = cause.getCause();
                al.add(cause);
            }
            final AppendingStringBuffer sb = new AppendingStringBuffer(256);
            final int length = al.size() - 1;
            cause = al.get(length);
            if (throwable instanceof RuntimeException) {
                sb.append("Message: ");
                sb.append(throwable.getMessage());
                sb.append("\n\n");
            }
            sb.append("Root cause:\n\n");
            outputThrowable(cause, sb, false);
            if (length > 0) {
                sb.append("\n\nComplete stack:\n\n");
                for (int i = 0; i < length; ++i) {
                    outputThrowable(al.get(i), sb, true);
                    sb.append('\n');
                }
            }
            return sb.toString();
        }
        return "<Null Throwable>";
    }
    
    private static void append(final AppendingStringBuffer buffer, final CharSequence s, final int from, final int to) {
        if (s instanceof AppendingStringBuffer) {
            final AppendingStringBuffer asb = (AppendingStringBuffer)s;
            buffer.append(asb.getValue(), from, to - from);
        }
        else {
            buffer.append(s.subSequence(from, to));
        }
    }
    
    private static void outputThrowable(final Throwable cause, final AppendingStringBuffer sb, final boolean stopAtWicketServlet) {
        sb.append(cause);
        sb.append("\n");
        final StackTraceElement[] trace = cause.getStackTrace();
        for (int i = 0; i < trace.length; ++i) {
            final String traceString = trace[i].toString();
            if (!traceString.startsWith("sun.reflect.") || i <= 1) {
                sb.append("     at ");
                sb.append(traceString);
                sb.append("\n");
                if (stopAtWicketServlet && (traceString.startsWith("org.apache.wicket.protocol.http.WicketServlet") || traceString.startsWith("org.apache.wicket.protocol.http.WicketFilter"))) {
                    return;
                }
            }
        }
    }
    
    private static int search(final CharSequence s, final String searchString, final int pos) {
        if (s instanceof String) {
            return ((String)s).indexOf(searchString, pos);
        }
        if (s instanceof StringBuffer) {
            return ((StringBuffer)s).indexOf(searchString, pos);
        }
        if (s instanceof StringBuilder) {
            return ((StringBuilder)s).indexOf(searchString, pos);
        }
        if (s instanceof AppendingStringBuffer) {
            return ((AppendingStringBuffer)s).indexOf(searchString, pos);
        }
        return s.toString().indexOf(searchString, pos);
    }
    
    private static char toHex(final int nibble) {
        return Strings.HEX_DIGIT[nibble & 0xF];
    }
    
    public static int lengthInBytes(final String string, final Charset charset) {
        Args.notNull(string, "string");
        if (charset != null) {
            try {
                return string.getBytes(charset.name()).length;
            }
            catch (UnsupportedEncodingException e) {
                throw new RuntimeException("StringResourceStream created with unsupported charset: " + charset.name());
            }
        }
        return string.getBytes().length;
    }
    
    public static boolean startsWith(final String str, final String prefix, final boolean caseSensitive) {
        if (caseSensitive) {
            return str.startsWith(prefix);
        }
        return str.toLowerCase().startsWith(prefix.toLowerCase());
    }
    
    public static int indexOf(final CharSequence sequence, final char ch) {
        if (sequence != null) {
            for (int i = 0; i < sequence.length(); ++i) {
                if (sequence.charAt(i) == ch) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public static int getLevenshteinDistance(CharSequence s, CharSequence t) {
        if (s == null || t == null) {
            throw new IllegalArgumentException("Strings must not be null");
        }
        int n = s.length();
        int m = t.length();
        if (n == 0) {
            return m;
        }
        if (m == 0) {
            return n;
        }
        if (n > m) {
            final CharSequence tmp = s;
            s = t;
            t = tmp;
            n = m;
            m = t.length();
        }
        int[] p = new int[n + 1];
        int[] d = new int[n + 1];
        for (int i = 0; i <= n; ++i) {
            p[i] = i;
        }
        for (int j = 1; j <= m; ++j) {
            final char t_j = t.charAt(j - 1);
            d[0] = j;
            for (int i = 1; i <= n; ++i) {
                final int cost = (s.charAt(i - 1) != t_j) ? 1 : 0;
                d[i] = Math.min(Math.min(d[i - 1] + 1, p[i] + 1), p[i - 1] + cost);
            }
            final int[] _d = p;
            p = d;
            d = _d;
        }
        return p[n];
    }
    
    public static String toHexString(final byte[] bytes) {
        Args.notNull(bytes, "bytes");
        final StringBuilder hex = new StringBuilder(bytes.length << 1);
        for (final byte b : bytes) {
            hex.append(toHex(b >> 4));
            hex.append(toHex(b));
        }
        return hex.toString();
    }
    
    public static <T extends Enum<T>> T toEnum(final CharSequence value, final Class<T> enumClass) {
        Args.notNull(enumClass, "enumClass");
        Args.notNull(value, "value");
        try {
            return Enum.valueOf(enumClass, value.toString());
        }
        catch (Exception e) {
            throw new StringValueConversionException(String.format("Cannot convert '%s' to enum constant of type '%s'.", value, enumClass), e);
        }
    }
    
    public static String defaultIfEmpty(final String originalString, final String defaultValue) {
        return isEmpty(originalString) ? defaultValue : originalString;
    }
    
    static {
        HEX_DIGIT = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        HTML_NUMBER_REGEX = Pattern.compile("&#\\d+;");
        NO_STRINGS = new String[0];
        SESSION_ID_PARAM_NAME = System.getProperty("wicket.jsessionid.name", "jsessionid");
        SESSION_ID_PARAM = ';' + Strings.SESSION_ID_PARAM_NAME + '=';
        LINE_SEPARATOR = AccessController.doPrivileged((PrivilegedAction<String>)new PrivilegedAction<String>() {
            @Override
            public String run() {
                return System.getProperty("line.separator");
            }
        });
    }
}
