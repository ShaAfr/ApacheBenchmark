// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public abstract class AbstractStringList implements IStringSequence, Serializable
{
    private static final long serialVersionUID = 1L;
    
    @Override
    public abstract IStringIterator iterator();
    
    @Override
    public abstract int size();
    
    @Override
    public abstract String get(final int p0);
    
    public String[] toArray() {
        final int size = this.size();
        final String[] strings = new String[size];
        for (int i = 0; i < size; ++i) {
            strings[i] = this.get(i);
        }
        return strings;
    }
    
    public final List<String> toList() {
        final int size = this.size();
        final List<String> strings = new ArrayList<String>(size);
        for (int i = 0; i < size; ++i) {
            strings.add(this.get(i));
        }
        return strings;
    }
    
    public int totalLength() {
        final int size = this.size();
        int totalLength = 0;
        for (int i = 0; i < size; ++i) {
            totalLength += this.get(i).length();
        }
        return totalLength;
    }
    
    public final String join() {
        return this.join(", ");
    }
    
    public final String join(final String separator) {
        return this.join(0, this.size(), separator);
    }
    
    public final String join(final int first, final int last, final String separator) {
        final int length = this.totalLength() + separator.length() * Math.max(0, last - first - 1);
        final AppendingStringBuffer buf = new AppendingStringBuffer(length);
        for (int i = first; i < last; ++i) {
            buf.append(this.get(i));
            if (i != last - 1) {
                buf.append(separator);
            }
        }
        return buf.toString();
    }
    
    @Override
    public String toString() {
        return "[" + this.join() + "]";
    }
}
