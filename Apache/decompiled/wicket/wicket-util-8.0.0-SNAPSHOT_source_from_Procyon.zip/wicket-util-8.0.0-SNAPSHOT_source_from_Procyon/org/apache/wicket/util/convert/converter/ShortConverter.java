// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import org.apache.wicket.util.convert.IConverter;
import java.math.BigDecimal;

public class ShortConverter extends AbstractIntegerConverter<Short>
{
    private static final long serialVersionUID = 1L;
    private static final BigDecimal MIN_VALUE;
    private static final BigDecimal MAX_VALUE;
    public static final IConverter<Short> INSTANCE;
    
    @Override
    public Short convertToObject(final String value, final Locale locale) {
        final BigDecimal number = this.parse(value, ShortConverter.MIN_VALUE, ShortConverter.MAX_VALUE, locale);
        if (number == null) {
            return null;
        }
        return number.shortValue();
    }
    
    @Override
    protected Class<Short> getTargetType() {
        return Short.class;
    }
    
    static {
        MIN_VALUE = new BigDecimal(-32768);
        MAX_VALUE = new BigDecimal(32767);
        INSTANCE = new ShortConverter();
    }
}
