// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collection;
import java.util.StringTokenizer;
import java.util.List;

public final class StringList extends AbstractStringList
{
    private static final long serialVersionUID = 1L;
    private final List<String> strings;
    private int totalLength;
    
    public static StringList repeat(final int count, final String string) {
        final StringList list = new StringList(count);
        for (int i = 0; i < count; ++i) {
            list.add(string);
        }
        return list;
    }
    
    public static StringList tokenize(final String string) {
        return tokenize(string, ", ");
    }
    
    public static StringList tokenize(final String string, final String delimiters) {
        final StringTokenizer tokenizer = new StringTokenizer(string, delimiters);
        final StringList strings = new StringList();
        while (tokenizer.hasMoreTokens()) {
            strings.add(tokenizer.nextToken());
        }
        return strings;
    }
    
    public static StringList valueOf(final Collection<?> collection) {
        if (collection != null) {
            final StringList strings = new StringList(collection.size());
            for (final Object object : collection) {
                strings.add(StringValue.valueOf(object));
            }
            return strings;
        }
        return new StringList();
    }
    
    public static StringList valueOf(final Object[] objects) {
        final int length = (objects == null) ? 0 : objects.length;
        final StringList strings = new StringList(length);
        for (int i = 0; i < length; ++i) {
            strings.add(StringValue.valueOf(objects[i]));
        }
        return strings;
    }
    
    public static StringList valueOf(final String string) {
        final StringList strings = new StringList();
        if (string != null) {
            strings.add(string);
        }
        return strings;
    }
    
    public static StringList valueOf(final String[] array) {
        final int length = (array == null) ? 0 : array.length;
        final StringList strings = new StringList(length);
        for (int i = 0; i < length; ++i) {
            strings.add(array[i]);
        }
        return strings;
    }
    
    public StringList() {
        this.strings = new ArrayList<String>();
    }
    
    public StringList(final int size) {
        this.strings = new ArrayList<String>(size);
    }
    
    public void add(final String string) {
        this.add(this.size(), string);
    }
    
    public void add(final int pos, final String string) {
        this.strings.add(pos, (string == null) ? "" : string);
        this.totalLength += ((string == null) ? 0 : string.length());
    }
    
    public void add(final StringValue value) {
        this.add(value.toString());
    }
    
    public boolean contains(final String string) {
        return this.strings.contains(string);
    }
    
    @Override
    public String get(final int index) {
        return this.strings.get(index);
    }
    
    public List<String> getList() {
        return this.strings;
    }
    
    @Override
    public IStringIterator iterator() {
        return new IStringIterator() {
            private final Iterator<String> iterator = StringList.this.strings.iterator();
            
            @Override
            public boolean hasNext() {
                return this.iterator.hasNext();
            }
            
            @Override
            public String next() {
                return this.iterator.next();
            }
        };
    }
    
    public void prepend(final String string) {
        this.add(0, string);
    }
    
    public void remove(final int index) {
        final String string = this.strings.remove(index);
        this.totalLength -= string.length();
    }
    
    public void removeLast() {
        this.remove(this.size() - 1);
    }
    
    @Override
    public int size() {
        return this.strings.size();
    }
    
    public void sort() {
        Collections.sort(this.strings);
    }
    
    @Override
    public String[] toArray() {
        return this.strings.toArray(new String[0]);
    }
    
    @Override
    public int totalLength() {
        return this.totalLength;
    }
}
