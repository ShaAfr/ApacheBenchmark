// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import org.apache.wicket.util.convert.IConverter;
import java.math.BigDecimal;

public class ByteConverter extends AbstractIntegerConverter<Byte>
{
    private static final long serialVersionUID = 1L;
    private static final BigDecimal MIN_VALUE;
    private static final BigDecimal MAX_VALUE;
    public static final IConverter<Byte> INSTANCE;
    
    @Override
    public Byte convertToObject(final String value, final Locale locale) {
        final BigDecimal number = this.parse(value, ByteConverter.MIN_VALUE, ByteConverter.MAX_VALUE, locale);
        if (number == null) {
            return null;
        }
        return number.byteValue();
    }
    
    @Override
    protected Class<Byte> getTargetType() {
        return Byte.class;
    }
    
    static {
        MIN_VALUE = new BigDecimal(-128);
        MAX_VALUE = new BigDecimal(127);
        INSTANCE = new ByteConverter();
    }
}
