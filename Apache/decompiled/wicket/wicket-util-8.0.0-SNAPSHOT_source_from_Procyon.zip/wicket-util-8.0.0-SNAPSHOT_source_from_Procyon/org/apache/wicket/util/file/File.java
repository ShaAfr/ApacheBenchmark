// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.file;

import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.ObjectInputStream;
import java.io.IOException;
import org.apache.wicket.util.io.Streams;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import org.apache.wicket.util.time.Time;
import java.io.FileNotFoundException;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import org.apache.wicket.util.watch.IModifiable;

public class File extends java.io.File implements IModifiable
{
    private static final long serialVersionUID = 1L;
    
    public File(final File parent, final String child) {
        super(parent, child);
    }
    
    public File(final java.io.File parent, final String child) {
        super(parent, child);
    }
    
    public File(final java.io.File file) {
        super(file.getAbsolutePath());
    }
    
    public File(final String pathname) {
        super(pathname);
    }
    
    public File(final String parent, final String child) {
        super(parent, child);
    }
    
    public File(final URI uri) {
        super(uri);
    }
    
    public File file(final String name) {
        return new File(this, name);
    }
    
    public String getExtension() {
        final int lastDot = this.getName().lastIndexOf(46);
        if (lastDot >= 0) {
            return this.getName().substring(lastDot + 1);
        }
        return null;
    }
    
    public Folder getParentFolder() {
        return new Folder(this.getParent());
    }
    
    public InputStream inputStream() throws FileNotFoundException {
        return new BufferedInputStream(new FileInputStream(this));
    }
    
    @Override
    public Time lastModifiedTime() {
        final long time = this.lastModified();
        if (time == 0L) {
            return null;
        }
        return Time.millis(time);
    }
    
    public OutputStream outputStream() throws FileNotFoundException {
        final Folder parent = this.getParentFolder();
        if (!parent.exists() && !parent.mkdirs()) {
            throw new FileNotFoundException("Couldn't create path " + parent);
        }
        return new BufferedOutputStream(new FileOutputStream(this));
    }
    
    public String readString() throws IOException {
        final InputStream in = new FileInputStream(this);
        try {
            return Streams.readString(in);
        }
        finally {
            in.close();
        }
    }
    
    public Object readObject() throws IOException, ClassNotFoundException {
        return new ObjectInputStream(this.inputStream()).readObject();
    }
    
    public void writeObject(final Serializable object) throws IOException {
        new ObjectOutputStream(this.outputStream()).writeObject(object);
    }
    
    public boolean remove() {
        return Files.remove(this);
    }
    
    public void sync() throws IOException {
        final FileInputStream in = new FileInputStream(this);
        try {
            in.getFD().sync();
        }
        finally {
            in.close();
        }
    }
    
    public String toQuotedString() {
        return "\"" + this.toString() + "\"";
    }
    
    public int write(final File file) throws IOException {
        final InputStream in = new BufferedInputStream(new FileInputStream(file));
        try {
            return this.write(in);
        }
        finally {
            in.close();
        }
    }
    
    public int write(final InputStream input) throws IOException {
        return Files.writeTo(this, input);
    }
    
    public void write(final String string) throws IOException {
        final FileWriter out = new FileWriter(this);
        try {
            out.write(string);
        }
        finally {
            out.close();
        }
    }
}
