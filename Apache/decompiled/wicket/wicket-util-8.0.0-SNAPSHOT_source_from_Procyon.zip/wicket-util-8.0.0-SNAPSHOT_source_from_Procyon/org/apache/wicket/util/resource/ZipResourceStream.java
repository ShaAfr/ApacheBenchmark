// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.resource;

import org.slf4j.LoggerFactory;
import org.apache.wicket.util.time.Time;
import org.apache.wicket.util.lang.Bytes;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.zip.ZipEntry;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;
import org.apache.wicket.util.lang.Args;
import org.apache.wicket.util.file.File;
import java.io.ByteArrayOutputStream;
import org.slf4j.Logger;

public class ZipResourceStream extends AbstractResourceStream
{
    private static final long serialVersionUID = 1L;
    private static final Logger log;
    private final transient ByteArrayOutputStream bytearray;
    
    public ZipResourceStream(final File dir, final boolean recursive) {
        Args.notNull(dir, "dir");
        Args.isTrue(dir.isDirectory(), "Not a directory: '{}'", dir);
        this.bytearray = new ByteArrayOutputStream();
        try {
            final ZipOutputStream out = new ZipOutputStream(this.bytearray);
            try {
                zipDir(dir, out, "", recursive);
            }
            finally {
                out.close();
            }
        }
        catch (RuntimeException e) {
            throw e;
        }
        catch (Exception e2) {
            throw new RuntimeException(e2);
        }
    }
    
    public ZipResourceStream(final File dir) {
        this(dir, false);
    }
    
    private static void zipDir(final File dir, final ZipOutputStream out, final String path, final boolean recursive) throws IOException {
        Args.notNull(dir, "dir");
        Args.isTrue(dir.isDirectory(), "Not a directory: '{}'", dir);
        final String[] files = dir.list();
        final int BUFFER = 2048;
        final byte[] data = new byte[BUFFER];
        if (files != null) {
            for (final String file : files) {
                if (ZipResourceStream.log.isDebugEnabled()) {
                    ZipResourceStream.log.debug("Adding: '{}'", (Object)file);
                }
                final File f = new File(dir, file);
                if (f.isDirectory()) {
                    if (recursive) {
                        zipDir(f, out, path + f.getName() + "/", recursive);
                    }
                }
                else {
                    out.putNextEntry(new ZipEntry(path + f.getName()));
                    final FileInputStream fi = new FileInputStream(f);
                    final BufferedInputStream origin = new BufferedInputStream(fi, BUFFER);
                    try {
                        int count;
                        while ((count = origin.read(data, 0, BUFFER)) != -1) {
                            out.write(data, 0, count);
                        }
                    }
                    finally {
                        origin.close();
                    }
                }
            }
        }
        if ("".equals(path)) {
            out.close();
        }
    }
    
    @Override
    public void close() throws IOException {
    }
    
    @Override
    public String getContentType() {
        return null;
    }
    
    @Override
    public InputStream getInputStream() throws ResourceStreamNotFoundException {
        return new ByteArrayInputStream(this.bytearray.toByteArray());
    }
    
    @Override
    public Bytes length() {
        return Bytes.bytes(this.bytearray.size());
    }
    
    @Override
    public Time lastModifiedTime() {
        return null;
    }
    
    static {
        log = LoggerFactory.getLogger((Class)ZipResourceStream.class);
    }
}
