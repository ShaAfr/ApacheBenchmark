// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

import java.util.List;

public class AddDelta extends Delta
{
    AddDelta() {
    }
    
    public AddDelta(final int origpos, final Chunk rev) {
        this.init(new Chunk(origpos, 0), rev);
    }
    
    @Override
    public void verify(final List<Object> target) throws PatchFailedException {
        if (this.original.first() > target.size()) {
            throw new PatchFailedException("original.first() > target.size()");
        }
    }
    
    @Override
    public void applyTo(final List<Object> target) {
        this.revised.applyAdd(this.original.first(), target);
    }
    
    @Override
    public void toString(final StringBuilder s) {
        s.append(this.original.anchor());
        s.append("a");
        s.append(this.revised.rangeString());
        s.append(Diff.NL);
        this.revised.toString(s, "> ", Diff.NL);
    }
    
    @Override
    public void toRCSString(final StringBuilder s, final String EOL) {
        s.append("a");
        s.append(this.original.anchor());
        s.append(" ");
        s.append(this.revised.size());
        s.append(EOL);
        this.revised.toString(s, "", EOL);
    }
    
    @Override
    public void accept(final RevisionVisitor visitor) {
        visitor.visit(this);
    }
}
