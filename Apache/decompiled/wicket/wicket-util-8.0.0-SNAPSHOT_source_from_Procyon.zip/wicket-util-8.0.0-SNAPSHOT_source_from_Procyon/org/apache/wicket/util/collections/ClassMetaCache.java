// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.util.WeakHashMap;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class ClassMetaCache<T>
{
    private volatile Map<ClassLoader, ConcurrentHashMap<String, T>> cache;
    
    public ClassMetaCache() {
        this.cache = Collections.emptyMap();
    }
    
    public T put(final Class<?> key, final T value) {
        final ConcurrentHashMap<String, T> container = this.getClassLoaderCache(key.getClassLoader(), true);
        return container.put(key(key), value);
    }
    
    public T get(final Class<?> key) {
        final ConcurrentHashMap<String, T> container = this.getClassLoaderCache(key.getClassLoader(), false);
        if (container == null) {
            return null;
        }
        return container.get(key(key));
    }
    
    private ConcurrentHashMap<String, T> getClassLoaderCache(final ClassLoader classLoader, final boolean create) {
        ConcurrentHashMap<String, T> container = this.cache.get(classLoader);
        if (container == null) {
            if (!create) {
                return container;
            }
            synchronized (this) {
                container = this.cache.get(classLoader);
                if (container == null) {
                    container = new ConcurrentHashMap<String, T>();
                    final Map<ClassLoader, ConcurrentHashMap<String, T>> newCache = new WeakHashMap<ClassLoader, ConcurrentHashMap<String, T>>(this.cache);
                    newCache.put(classLoader, container);
                    this.cache = Collections.unmodifiableMap((Map<? extends ClassLoader, ? extends ConcurrentHashMap<String, T>>)newCache);
                }
            }
        }
        return container;
    }
    
    private static String key(final Class<?> clazz) {
        return clazz.getName();
    }
}
