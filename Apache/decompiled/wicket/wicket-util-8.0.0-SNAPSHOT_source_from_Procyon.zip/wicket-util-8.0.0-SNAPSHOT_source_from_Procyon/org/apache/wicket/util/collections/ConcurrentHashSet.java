// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.collections;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.Iterator;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.io.Serializable;
import java.util.Set;
import java.util.AbstractSet;

public class ConcurrentHashSet<E> extends AbstractSet<E> implements Set<E>, Cloneable, Serializable
{
    private static final long serialVersionUID = 1L;
    private transient ConcurrentHashMap<E, Object> map;
    private static final Object PRESENT;
    
    public ConcurrentHashSet() {
        this.map = new ConcurrentHashMap<E, Object>();
    }
    
    public ConcurrentHashSet(final Collection<? extends E> c) {
        this.map = new ConcurrentHashMap<E, Object>(Math.max((int)(c.size() / 0.75f) + 1, 16));
        this.addAll(c);
    }
    
    public ConcurrentHashSet(final int initialCapacity, final float loadFactor) {
        this.map = new ConcurrentHashMap<E, Object>(initialCapacity, loadFactor, 16);
    }
    
    public ConcurrentHashSet(final int initialCapacity) {
        this.map = new ConcurrentHashMap<E, Object>(initialCapacity);
    }
    
    @Override
    public Iterator<E> iterator() {
        return this.map.keySet().iterator();
    }
    
    @Override
    public int size() {
        return this.map.size();
    }
    
    @Override
    public boolean isEmpty() {
        return this.map.isEmpty();
    }
    
    @Override
    public boolean contains(final Object o) {
        return this.map.containsKey(o);
    }
    
    @Override
    public boolean add(final E o) {
        return this.map.put(o, ConcurrentHashSet.PRESENT) == null;
    }
    
    @Override
    public boolean remove(final Object o) {
        return this.map.remove(o) == ConcurrentHashSet.PRESENT;
    }
    
    @Override
    public void clear() {
        this.map.clear();
    }
    
    public Object clone() throws CloneNotSupportedException {
        try {
            final ConcurrentHashSet<E> newSet = (ConcurrentHashSet<E>)super.clone();
            newSet.map.putAll((Map<? extends E, ?>)this.map);
            return newSet;
        }
        catch (CloneNotSupportedException e) {
            throw new InternalError();
        }
    }
    
    private void writeObject(final ObjectOutputStream s) throws IOException {
        s.defaultWriteObject();
        s.writeInt(this.map.size());
        for (final E key : this.map.keySet()) {
            s.writeObject(key);
        }
    }
    
    private void readObject(final ObjectInputStream inputStream) throws ClassNotFoundException, IOException {
        inputStream.defaultReadObject();
        this.map = new ConcurrentHashMap<E, Object>();
        for (int size = inputStream.readInt(), i = 0; i < size; ++i) {
            final E e = (E)inputStream.readObject();
            this.map.put(e, ConcurrentHashSet.PRESENT);
        }
    }
    
    static {
        PRESENT = new Object();
    }
}
