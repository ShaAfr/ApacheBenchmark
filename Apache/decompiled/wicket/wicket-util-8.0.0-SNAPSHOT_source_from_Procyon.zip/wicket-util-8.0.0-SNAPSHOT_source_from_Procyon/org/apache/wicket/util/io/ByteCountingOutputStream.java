// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.io.IOException;
import java.io.OutputStream;

public final class ByteCountingOutputStream extends OutputStream
{
    private long size;
    
    @Override
    public void write(final int b) throws IOException {
        ++this.size;
    }
    
    @Override
    public void write(final byte[] b, final int off, final int len) throws IOException {
        this.size += len;
    }
    
    public long size() {
        return this.size;
    }
}
