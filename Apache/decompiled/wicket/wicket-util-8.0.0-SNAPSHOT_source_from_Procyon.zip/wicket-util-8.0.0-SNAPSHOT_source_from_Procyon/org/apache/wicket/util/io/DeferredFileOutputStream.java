// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.io;

import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.wicket.util.lang.Args;
import java.io.File;
import java.io.OutputStream;

public class DeferredFileOutputStream extends ThresholdingOutputStream
{
    private OutputStream currentOutputStream;
    private ByteArrayOutputStream memoryOutputStream;
    private File outputFile;
    private final FileFactory fileFactory;
    
    public DeferredFileOutputStream(final int threshold, final File outputFile) {
        super(threshold);
        this.outputFile = Args.notNull(outputFile, "outputFile");
        this.fileFactory = null;
        this.memoryOutputStream = new ByteArrayOutputStream();
        this.currentOutputStream = this.memoryOutputStream;
    }
    
    public DeferredFileOutputStream(final int threshold, final FileFactory fileFactory) {
        super(threshold);
        this.fileFactory = Args.notNull(fileFactory, "fileFactory");
        this.memoryOutputStream = new ByteArrayOutputStream();
        this.currentOutputStream = this.memoryOutputStream;
    }
    
    public byte[] getData() {
        if (this.memoryOutputStream != null) {
            return this.memoryOutputStream.toByteArray();
        }
        return null;
    }
    
    public File getFile() {
        return this.outputFile;
    }
    
    public boolean isInMemory() {
        return !this.isThresholdExceeded();
    }
    
    @Override
    protected OutputStream getStream() throws IOException {
        return this.currentOutputStream;
    }
    
    @Override
    protected void thresholdReached() throws IOException {
        final byte[] data = this.memoryOutputStream.toByteArray();
        if (this.outputFile == null) {
            this.outputFile = this.fileFactory.createFile();
        }
        final FileOutputStream fos = new FileOutputStream(this.outputFile);
        fos.write(data);
        this.currentOutputStream = fos;
        this.memoryOutputStream = null;
    }
    
    public interface FileFactory
    {
        File createFile();
    }
}
