// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.lang;

import java.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Generics
{
    private Generics() {
    }
    
    public static <T> Iterator<T> iterator(final Iterator<?> delegate) {
        return (Iterator<T>)delegate;
    }
    
    public static <K, V> HashMap<K, V> newHashMap() {
        return new HashMap<K, V>();
    }
    
    public static <K, V> HashMap<K, V> newHashMap(final int capacity) {
        return new HashMap<K, V>(capacity);
    }
    
    public static <T> ArrayList<T> newArrayList(final int capacity) {
        return new ArrayList<T>(capacity);
    }
    
    public static <T> ArrayList<T> newArrayList() {
        return new ArrayList<T>();
    }
    
    public static <K, V> ConcurrentHashMap<K, V> newConcurrentHashMap() {
        return new ConcurrentHashMap<K, V>();
    }
    
    public static <K, V> ConcurrentHashMap<K, V> newConcurrentHashMap(final int initialCapacity) {
        return new ConcurrentHashMap<K, V>(initialCapacity);
    }
}
