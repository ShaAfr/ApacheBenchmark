// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.value;

import org.apache.wicket.util.lang.Args;
import org.apache.wicket.util.lang.Primitives;
import java.io.Serializable;

public class LongValue implements Comparable<LongValue>, Serializable
{
    private static final long serialVersionUID = 1L;
    protected final long value;
    
    public LongValue(final long value) {
        this.value = value;
    }
    
    @Override
    public final int compareTo(final LongValue that) {
        if (this.value < that.value) {
            return -1;
        }
        if (this.value > that.value) {
            return 1;
        }
        return 0;
    }
    
    @Override
    public final boolean equals(final Object that) {
        return that instanceof LongValue && this.value == ((LongValue)that).value;
    }
    
    public final boolean greaterThan(final long value) {
        return this.value > value;
    }
    
    public final boolean greaterThanOrEqual(final long value) {
        return this.value >= value;
    }
    
    public final boolean greaterThan(final LongValue that) {
        return this.value > that.value;
    }
    
    public final boolean greaterThanOrEqual(final LongValue that) {
        return this.value >= that.value;
    }
    
    @Override
    public final int hashCode() {
        return Primitives.hashCode(this.value);
    }
    
    public final boolean lessThan(final long that) {
        return this.value < that;
    }
    
    public final boolean lessThanOrEqual(final long that) {
        return this.value <= that;
    }
    
    public final boolean lessThan(final LongValue that) {
        return this.value < that.value;
    }
    
    public final boolean lessThanOrEqual(final LongValue that) {
        return this.value <= that.value;
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
    
    public static <T extends LongValue> T min(final T lhs, final T rhs) {
        Args.notNull(lhs, "lhs");
        Args.notNull(rhs, "rhs");
        if (lhs.compareTo((LongValue)rhs) < 0) {
            return lhs;
        }
        return rhs;
    }
    
    public static <T extends LongValue> T max(final T lhs, final T rhs) {
        Args.notNull(lhs, "lhs");
        Args.notNull(rhs, "rhs");
        if (lhs.compareTo((LongValue)rhs) > 0) {
            return lhs;
        }
        return rhs;
    }
    
    public static <T extends LongValue> T maxNullSafe(final T lhs, final T rhs) {
        if (lhs == rhs) {
            return lhs;
        }
        if (lhs == null) {
            return rhs;
        }
        if (rhs == null) {
            return lhs;
        }
        return (T)max(lhs, (LongValue)rhs);
    }
}
