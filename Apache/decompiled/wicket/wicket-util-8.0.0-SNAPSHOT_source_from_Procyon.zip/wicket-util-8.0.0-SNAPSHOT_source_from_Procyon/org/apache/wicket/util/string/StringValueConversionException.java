// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string;

import org.apache.wicket.util.convert.ConversionException;

public final class StringValueConversionException extends ConversionException
{
    private static final long serialVersionUID = 1L;
    
    public StringValueConversionException(final String message) {
        super(message);
    }
    
    public StringValueConversionException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
