// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert.converter;

import org.apache.wicket.util.convert.ConversionException;
import java.util.Locale;
import org.apache.wicket.util.convert.IConverter;
import java.math.BigDecimal;

public class IntegerConverter extends AbstractIntegerConverter<Integer>
{
    private static final long serialVersionUID = 1L;
    private static final BigDecimal MIN_VALUE;
    private static final BigDecimal MAX_VALUE;
    public static final IConverter<Integer> INSTANCE;
    
    @Override
    public Integer convertToObject(final String value, final Locale locale) {
        final BigDecimal number = this.parse(value, IntegerConverter.MIN_VALUE, IntegerConverter.MAX_VALUE, locale);
        if (number == null) {
            return null;
        }
        return number.intValue();
    }
    
    @Override
    protected Class<Integer> getTargetType() {
        return Integer.class;
    }
    
    static {
        MIN_VALUE = new BigDecimal(Integer.MIN_VALUE);
        MAX_VALUE = new BigDecimal(Integer.MAX_VALUE);
        INSTANCE = new IntegerConverter();
    }
}
