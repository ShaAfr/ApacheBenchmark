// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

public class DiffException extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public DiffException() {
    }
    
    public DiffException(final String msg) {
        super(msg);
    }
}
