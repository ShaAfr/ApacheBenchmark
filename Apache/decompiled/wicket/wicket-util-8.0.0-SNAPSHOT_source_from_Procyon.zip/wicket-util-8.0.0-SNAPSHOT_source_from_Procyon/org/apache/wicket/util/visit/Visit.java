// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.visit;

public class Visit<R> implements IVisit<R>
{
    private R result;
    private Action action;
    
    public Visit() {
        this.action = Action.CONTINUE;
    }
    
    @Override
    public void stop() {
        this.stop(null);
    }
    
    @Override
    public void stop(final R result) {
        this.action = Action.STOP;
        this.result = result;
    }
    
    @Override
    public void dontGoDeeper() {
        this.action = Action.CONTINUE_BUT_DONT_GO_DEEPER;
    }
    
    public boolean isStopped() {
        return this.action == Action.STOP;
    }
    
    public boolean isContinue() {
        return this.action == Action.CONTINUE;
    }
    
    public boolean isDontGoDeeper() {
        return this.action == Action.CONTINUE_BUT_DONT_GO_DEEPER;
    }
    
    public R getResult() {
        return this.result;
    }
    
    private enum Action
    {
        CONTINUE, 
        CONTINUE_BUT_DONT_GO_DEEPER, 
        STOP;
    }
}
