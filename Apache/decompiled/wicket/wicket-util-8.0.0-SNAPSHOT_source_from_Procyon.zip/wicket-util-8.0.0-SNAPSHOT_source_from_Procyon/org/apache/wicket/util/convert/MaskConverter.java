// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert;

import java.util.Locale;
import java.text.ParseException;
import org.apache.wicket.util.lang.Args;
import javax.swing.text.MaskFormatter;

public class MaskConverter<C> implements IConverter<C>
{
    private static final long serialVersionUID = 1L;
    private final MaskFormatter maskFormatter;
    
    public MaskConverter(final MaskFormatter maskFormatter) {
        Args.notNull(maskFormatter, "maskFormatter");
        this.maskFormatter = maskFormatter;
    }
    
    public MaskConverter(final String mask) {
        this(mask, String.class);
    }
    
    public MaskConverter(final String mask, final Class<?> type) {
        try {
            (this.maskFormatter = new MaskFormatter(mask)).setValueClass(type);
            this.maskFormatter.setAllowsInvalid(true);
            this.maskFormatter.setValueContainsLiteralCharacters(true);
        }
        catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public C convertToObject(final String value, final Locale locale) {
        try {
            return (C)this.maskFormatter.stringToValue(value);
        }
        catch (ParseException e) {
            throw new ConversionException(e);
        }
    }
    
    @Override
    public String convertToString(final C value, final Locale locale) {
        try {
            return this.maskFormatter.valueToString(value);
        }
        catch (ParseException e) {
            throw new ConversionException(e);
        }
    }
}
