// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.encoding;

import java.nio.charset.UnsupportedCharsetException;
import java.nio.charset.IllegalCharsetNameException;
import java.io.UnsupportedEncodingException;
import org.apache.wicket.util.lang.Args;
import java.io.CharArrayWriter;
import java.nio.charset.Charset;
import java.util.BitSet;

public class UrlEncoder
{
    protected BitSet dontNeedEncoding;
    protected static final int caseDiff = 32;
    public static final UrlEncoder QUERY_INSTANCE;
    public static final UrlEncoder PATH_INSTANCE;
    public static final UrlEncoder HEADER_INSTANCE;
    
    protected UrlEncoder(final Type type) {
        this.dontNeedEncoding = new BitSet(256);
        for (int i = 97; i <= 122; ++i) {
            this.dontNeedEncoding.set(i);
        }
        for (int i = 65; i <= 90; ++i) {
            this.dontNeedEncoding.set(i);
        }
        for (int i = 48; i <= 57; ++i) {
            this.dontNeedEncoding.set(i);
        }
        this.dontNeedEncoding.set(45);
        this.dontNeedEncoding.set(46);
        this.dontNeedEncoding.set(95);
        this.dontNeedEncoding.set(126);
        this.dontNeedEncoding.set(33);
        this.dontNeedEncoding.set(36);
        switch (type) {
            case QUERY: {
                this.dontNeedEncoding.set(32);
                this.dontNeedEncoding.set(42);
                this.dontNeedEncoding.set(47);
                this.dontNeedEncoding.set(44);
                this.dontNeedEncoding.set(58);
                this.dontNeedEncoding.set(64);
                break;
            }
            case PATH: {
                this.dontNeedEncoding.set(42);
                this.dontNeedEncoding.set(38);
                this.dontNeedEncoding.set(43);
                this.dontNeedEncoding.set(44);
                this.dontNeedEncoding.set(59);
                this.dontNeedEncoding.set(61);
                this.dontNeedEncoding.set(58);
                this.dontNeedEncoding.set(64);
                break;
            }
            case HEADER: {
                this.dontNeedEncoding.set(35);
                this.dontNeedEncoding.set(38);
                this.dontNeedEncoding.set(43);
                this.dontNeedEncoding.set(94);
                this.dontNeedEncoding.set(96);
                this.dontNeedEncoding.set(124);
                break;
            }
        }
    }
    
    public String encode(final String s, final Charset charset) {
        return this.encode(s, charset.name());
    }
    
    public String encode(final String unsafeInput, final String charsetName) {
        final String s = unsafeInput.replace("\u0000", "NULL");
        final StringBuilder out = new StringBuilder(s.length());
        final CharArrayWriter charArrayWriter = new CharArrayWriter();
        Args.notNull(charsetName, "charsetName");
        Charset charset;
        try {
            charset = Charset.forName(charsetName);
        }
        catch (IllegalCharsetNameException | UnsupportedCharsetException ex2) {
            final IllegalArgumentException ex;
            final IllegalArgumentException e = ex;
            throw new RuntimeException(new UnsupportedEncodingException(charsetName));
        }
        int i = 0;
        while (i < s.length()) {
            int c = s.charAt(i);
            if (this.dontNeedEncoding.get(c)) {
                if (c == 32) {
                    c = 43;
                }
                out.append((char)c);
                ++i;
            }
            else {
                do {
                    charArrayWriter.write(c);
                    if (c >= 55296 && c <= 56319 && i + 1 < s.length()) {
                        final int d = s.charAt(i + 1);
                        if (d < 56320 || d > 57343) {
                            continue;
                        }
                        charArrayWriter.write(d);
                        ++i;
                    }
                } while (++i < s.length() && !this.dontNeedEncoding.get(c = s.charAt(i)));
                charArrayWriter.flush();
                final String str = new String(charArrayWriter.toCharArray());
                final byte[] bytes;
                final byte[] ba = bytes = str.getBytes(charset);
                for (final byte b : bytes) {
                    out.append('%');
                    char ch = Character.forDigit(b >> 4 & 0xF, 16);
                    if (Character.isLetter(ch)) {
                        ch -= ' ';
                    }
                    out.append(ch);
                    ch = Character.forDigit(b & 0xF, 16);
                    if (Character.isLetter(ch)) {
                        ch -= ' ';
                    }
                    out.append(ch);
                }
                charArrayWriter.reset();
            }
        }
        return out.toString();
    }
    
    static {
        QUERY_INSTANCE = new UrlEncoder(Type.QUERY);
        PATH_INSTANCE = new UrlEncoder(Type.PATH);
        HEADER_INSTANCE = new UrlEncoder(Type.HEADER);
    }
    
    public enum Type
    {
        QUERY, 
        PATH, 
        HEADER;
    }
}
