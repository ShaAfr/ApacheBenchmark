// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.listener;

public final class ChangeListenerSet<T> extends ListenerCollection<IChangeListener<T>>
{
    private static final long serialVersionUID = 1L;
    
    public void notifyListeners(final T t) {
        this.notify(new INotifier<IChangeListener<T>>() {
            @Override
            public void notify(final IChangeListener<T> listener) {
                listener.onChange(t);
            }
        });
    }
}
