// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.string.interpolator;

import java.util.Map;

public final class SystemVariableInterpolator extends MapVariableInterpolator
{
    public SystemVariableInterpolator(final String string) {
        super(string, System.getProperties());
    }
}
