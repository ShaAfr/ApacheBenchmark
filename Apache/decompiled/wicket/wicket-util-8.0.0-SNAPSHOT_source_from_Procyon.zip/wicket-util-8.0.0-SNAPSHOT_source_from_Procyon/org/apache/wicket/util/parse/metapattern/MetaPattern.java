// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern;

import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.wicket.util.io.IClusterable;

public class MetaPattern implements IClusterable
{
    private static final long serialVersionUID = 1L;
    private Pattern pattern;
    private List<MetaPattern> patterns;
    private Pattern compiledPattern;
    private static final String _DOUBLE_QUOTED_STRING = "\"[^\"]*?\"";
    private static final String _SINGLE_QUOTED_STRING = "'[^']*?'";
    private static final String _STRING = "(?:[\\w\\-\\.]+|\"[^\"]*?\"|'[^']*?')";
    private static final String _OPTIONAL_STRING = "(?:[\\w\\-\\.]+|\"[^\"]*?\"|'[^']*?')?";
    private static final String _VARIABLE_NAME = "[A-Za-z_][A-Za-z0-9_]*";
    private static final String _XML_NAME = "[A-Za-z_][A-Za-z0-9_.-]*";
    public static final MetaPattern WHITESPACE;
    public static final MetaPattern OPTIONAL_WHITESPACE;
    public static final MetaPattern NON_WORD;
    public static final MetaPattern COMMA;
    public static final MetaPattern COLON;
    public static final MetaPattern SEMICOLON;
    public static final MetaPattern SLASH;
    public static final MetaPattern BACKSLASH;
    public static final MetaPattern DOT;
    public static final MetaPattern PLUS;
    public static final MetaPattern MINUS;
    public static final MetaPattern DASH;
    public static final MetaPattern UNDERSCORE;
    public static final MetaPattern AMPERSAND;
    public static final MetaPattern PERCENT;
    public static final MetaPattern DOLLAR_SIGN;
    public static final MetaPattern POUND_SIGN;
    public static final MetaPattern AT_SIGN;
    public static final MetaPattern EXCLAMATION_POINT;
    public static final MetaPattern TILDE;
    public static final MetaPattern EQUALS;
    public static final MetaPattern STAR;
    public static final MetaPattern PIPE;
    public static final MetaPattern LEFT_PAREN;
    public static final MetaPattern RIGHT_PAREN;
    public static final MetaPattern LEFT_CURLY;
    public static final MetaPattern RIGHT_CURLY;
    public static final MetaPattern LEFT_SQUARE;
    public static final MetaPattern RIGHT_SQUARE;
    public static final MetaPattern DIGIT;
    public static final MetaPattern DIGITS;
    public static final MetaPattern INTEGER;
    public static final MetaPattern FLOATING_POINT_NUMBER;
    public static final MetaPattern POSITIVE_INTEGER;
    public static final MetaPattern HEXADECIMAL_DIGIT;
    public static final MetaPattern HEXADECIMAL_DIGITS;
    public static final MetaPattern ANYTHING;
    public static final MetaPattern ANYTHING_NON_EMPTY;
    public static final MetaPattern WORD;
    public static final MetaPattern OPTIONAL_WORD;
    public static final MetaPattern VARIABLE_NAME;
    public static final MetaPattern XML_ELEMENT_NAME;
    public static final MetaPattern XML_ATTRIBUTE_NAME;
    public static final MetaPattern PERL_INTERPOLATION;
    public static final MetaPattern DOUBLE_QUOTED_STRING;
    public static final MetaPattern STRING;
    public static final MetaPattern OPTIONAL_STRING;
    
    public MetaPattern(final String pattern) {
        this.pattern = Pattern.compile(pattern);
    }
    
    public MetaPattern(final MetaPattern pattern) {
        this.pattern = pattern.pattern;
        this.patterns = pattern.patterns;
        this.compiledPattern = pattern.compiledPattern;
    }
    
    public MetaPattern(final MetaPattern... patterns) {
        this(Arrays.asList(patterns));
    }
    
    public MetaPattern(final List<MetaPattern> patterns) {
        this.patterns = patterns;
    }
    
    public final Matcher matcher(final CharSequence input) {
        return this.matcher(input, 0);
    }
    
    public final Matcher matcher(final CharSequence input, final int flags) {
        this.compile(flags);
        return this.compiledPattern.matcher(input);
    }
    
    public final Pattern pattern() {
        return this.pattern(0);
    }
    
    public final Pattern pattern(final int flags) {
        this.compile(flags);
        return this.compiledPattern;
    }
    
    @Override
    public String toString() {
        if (this.pattern != null) {
            return this.pattern.pattern();
        }
        final StringBuilder buffer = new StringBuilder();
        for (final MetaPattern metaPattern : this.patterns) {
            buffer.append(metaPattern);
        }
        return buffer.toString();
    }
    
    private synchronized void compile(final int flags) {
        if (this.compiledPattern == null) {
            this.bind(1);
            this.compiledPattern = Pattern.compile(this.toString(), flags);
        }
    }
    
    private int bind(int group) {
        if (this instanceof Group) {
            ((Group)this).bind(group++);
        }
        if (this.patterns != null) {
            for (final MetaPattern metaPattern : this.patterns) {
                group = metaPattern.bind(group);
            }
        }
        return group;
    }
    
    static {
        WHITESPACE = new MetaPattern("\\s+");
        OPTIONAL_WHITESPACE = new MetaPattern("\\s*");
        NON_WORD = new MetaPattern("\\W+");
        COMMA = new MetaPattern(",");
        COLON = new MetaPattern(":");
        SEMICOLON = new MetaPattern(";");
        SLASH = new MetaPattern("/");
        BACKSLASH = new MetaPattern("\\\\");
        DOT = new MetaPattern("\\.");
        PLUS = new MetaPattern("\\+");
        MINUS = new MetaPattern("-");
        DASH = new MetaPattern("-");
        UNDERSCORE = new MetaPattern("_");
        AMPERSAND = new MetaPattern("&");
        PERCENT = new MetaPattern("%");
        DOLLAR_SIGN = new MetaPattern("$");
        POUND_SIGN = new MetaPattern("#");
        AT_SIGN = new MetaPattern("@");
        EXCLAMATION_POINT = new MetaPattern("!");
        TILDE = new MetaPattern("~");
        EQUALS = new MetaPattern("=");
        STAR = new MetaPattern("\\*");
        PIPE = new MetaPattern("\\|");
        LEFT_PAREN = new MetaPattern("\\(");
        RIGHT_PAREN = new MetaPattern("\\)");
        LEFT_CURLY = new MetaPattern("\\{");
        RIGHT_CURLY = new MetaPattern("\\}");
        LEFT_SQUARE = new MetaPattern("\\[");
        RIGHT_SQUARE = new MetaPattern("\\]");
        DIGIT = new MetaPattern("\\d");
        DIGITS = new MetaPattern("\\d+");
        INTEGER = new MetaPattern("-?\\d+");
        FLOATING_POINT_NUMBER = new MetaPattern("-?\\d+\\.?\\d*|-?\\.\\d+");
        POSITIVE_INTEGER = new MetaPattern("\\d+");
        HEXADECIMAL_DIGIT = new MetaPattern("[0-9a-fA-F]");
        HEXADECIMAL_DIGITS = new MetaPattern("[0-9a-fA-F]+");
        ANYTHING = new MetaPattern(".*");
        ANYTHING_NON_EMPTY = new MetaPattern(".+");
        WORD = new MetaPattern("\\w+");
        OPTIONAL_WORD = new MetaPattern("\\w*");
        VARIABLE_NAME = new MetaPattern("[A-Za-z_][A-Za-z0-9_]*");
        XML_ELEMENT_NAME = new MetaPattern("[A-Za-z_][A-Za-z0-9_.-]*");
        XML_ATTRIBUTE_NAME = new MetaPattern("[A-Za-z_][A-Za-z0-9_.-]*");
        PERL_INTERPOLATION = new MetaPattern("$\\{[A-Za-z_][A-Za-z0-9_]*\\}");
        DOUBLE_QUOTED_STRING = new MetaPattern("\"[^\"]*?\"");
        STRING = new MetaPattern("(?:[\\w\\-\\.]+|\"[^\"]*?\"|'[^']*?')");
        OPTIONAL_STRING = new MetaPattern("(?:[\\w\\-\\.]+|\"[^\"]*?\"|'[^']*?')?");
    }
}
