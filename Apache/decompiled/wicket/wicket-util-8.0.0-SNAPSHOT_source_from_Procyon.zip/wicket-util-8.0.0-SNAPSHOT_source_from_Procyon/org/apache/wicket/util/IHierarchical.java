// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util;

@FunctionalInterface
public interface IHierarchical<T>
{
    T getParent();
}
