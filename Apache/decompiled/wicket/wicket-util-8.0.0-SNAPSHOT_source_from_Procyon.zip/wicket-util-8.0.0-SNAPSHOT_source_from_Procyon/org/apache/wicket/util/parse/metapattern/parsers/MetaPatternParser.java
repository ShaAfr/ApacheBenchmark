// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern.parsers;

import org.apache.wicket.util.parse.metapattern.MetaPattern;
import java.util.regex.Matcher;

public abstract class MetaPatternParser
{
    private final CharSequence input;
    private final int length;
    private int pos;
    private Matcher matcher;
    
    public MetaPatternParser(final CharSequence input) {
        this.input = input;
        this.length = input.length();
    }
    
    public MetaPatternParser(final MetaPattern pattern, final CharSequence input) {
        this(input);
        this.setPattern(pattern);
    }
    
    public void setPattern(final MetaPattern pattern) {
        this.matcher = pattern.matcher(this.input);
    }
    
    protected final boolean advance(final MetaPattern pattern) {
        final CharSequence s = this.input.subSequence(this.pos, this.length);
        this.matcher = pattern.matcher(s);
        if (this.matcher.lookingAt()) {
            this.pos += this.matcher.end();
            return true;
        }
        return false;
    }
    
    public boolean matches() {
        return this.matcher.matches();
    }
    
    public final Matcher matcher() {
        return this.matcher;
    }
    
    public final boolean atEnd() {
        return this.pos == this.length;
    }
}
