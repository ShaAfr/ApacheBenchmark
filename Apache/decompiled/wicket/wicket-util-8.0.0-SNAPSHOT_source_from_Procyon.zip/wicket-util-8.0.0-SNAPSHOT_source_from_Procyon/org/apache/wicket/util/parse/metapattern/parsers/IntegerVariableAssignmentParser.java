// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.parse.metapattern.parsers;

import org.apache.wicket.util.parse.metapattern.MetaPattern;
import org.apache.wicket.util.parse.metapattern.IntegerGroup;
import org.apache.wicket.util.parse.metapattern.Group;

public final class IntegerVariableAssignmentParser extends MetaPatternParser
{
    private static final Group variable;
    private static final IntegerGroup value;
    private static final MetaPattern pattern;
    
    public IntegerVariableAssignmentParser(final CharSequence input) {
        super(IntegerVariableAssignmentParser.pattern, input);
    }
    
    public String getVariable() {
        return IntegerVariableAssignmentParser.variable.get(this.matcher());
    }
    
    public int getIntValue() {
        return IntegerVariableAssignmentParser.value.getInt(this.matcher());
    }
    
    public long getLongValue() {
        return IntegerVariableAssignmentParser.value.getLong(this.matcher());
    }
    
    static {
        variable = new Group(MetaPattern.VARIABLE_NAME);
        value = new IntegerGroup();
        pattern = new MetaPattern(new MetaPattern[] { IntegerVariableAssignmentParser.variable, MetaPattern.OPTIONAL_WHITESPACE, MetaPattern.EQUALS, MetaPattern.OPTIONAL_WHITESPACE, IntegerVariableAssignmentParser.value });
    }
}
