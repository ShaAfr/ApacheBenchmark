// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util;

import java.util.function.Supplier;

public class ValueProvider<T> implements Supplier<T>
{
    private final T value;
    
    public ValueProvider(final T value) {
        this.value = value;
    }
    
    @Override
    public T get() {
        return this.value;
    }
    
    public static <T> ValueProvider<T> of(final T value) {
        return new ValueProvider<T>(value);
    }
}
