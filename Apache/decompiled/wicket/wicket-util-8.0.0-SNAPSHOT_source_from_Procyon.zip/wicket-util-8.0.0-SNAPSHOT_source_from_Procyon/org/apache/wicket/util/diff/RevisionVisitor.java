// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.diff;

public interface RevisionVisitor
{
    void visit(final Revision p0);
    
    void visit(final DeleteDelta p0);
    
    void visit(final ChangeDelta p0);
    
    void visit(final AddDelta p0);
}
