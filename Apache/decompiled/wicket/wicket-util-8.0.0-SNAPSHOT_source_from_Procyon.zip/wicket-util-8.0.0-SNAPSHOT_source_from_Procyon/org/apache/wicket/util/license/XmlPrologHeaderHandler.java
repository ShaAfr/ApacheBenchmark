// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.license;

import org.junit.Assert;
import java.io.File;
import java.util.Arrays;
import java.util.List;

class XmlPrologHeaderHandler extends XmlLicenseHeaderHandler
{
    public XmlPrologHeaderHandler(final List<String> ignoreFiles) {
        super(ignoreFiles);
    }
    
    @Override
    public List<String> getSuffixes() {
        return Arrays.asList("html");
    }
    
    @Override
    public boolean checkLicenseHeader(final File file) {
        try {
            final String header = this.extractLicenseHeader(file, 0, 1);
            return header.startsWith("<?xml");
        }
        catch (Exception e) {
            Assert.fail(e.getMessage());
            return true;
        }
    }
}
