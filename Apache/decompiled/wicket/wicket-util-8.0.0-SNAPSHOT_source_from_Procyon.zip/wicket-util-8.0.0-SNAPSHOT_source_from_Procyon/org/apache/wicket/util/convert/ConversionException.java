// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.wicket.util.convert;

import org.apache.wicket.util.lang.Generics;
import org.apache.wicket.util.lang.Args;
import java.util.Map;
import java.util.Locale;
import java.text.Format;

public class ConversionException extends RuntimeException
{
    private static final long serialVersionUID = 1L;
    private IConverter<?> converter;
    private Format format;
    private Locale locale;
    private Object sourceValue;
    private Class<?> targetType;
    private String resourceKey;
    private Map<String, Object> vars;
    
    public ConversionException(final String message) {
        super(message);
    }
    
    public ConversionException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public ConversionException(final Throwable cause) {
        super(cause);
    }
    
    public final IConverter<?> getConverter() {
        return this.converter;
    }
    
    public final Format getFormat() {
        return this.format;
    }
    
    public final Locale getLocale() {
        return this.locale;
    }
    
    public final Object getSourceValue() {
        return this.sourceValue;
    }
    
    public final Class<?> getTargetType() {
        return this.targetType;
    }
    
    public final ConversionException setConverter(final IConverter<?> converter) {
        this.converter = converter;
        return this;
    }
    
    public final ConversionException setFormat(final Format format) {
        this.format = format;
        return this;
    }
    
    public final ConversionException setLocale(final Locale locale) {
        this.locale = locale;
        return this;
    }
    
    public final ConversionException setSourceValue(final Object sourceValue) {
        this.sourceValue = sourceValue;
        return this;
    }
    
    public final ConversionException setTargetType(final Class<?> targetType) {
        this.targetType = targetType;
        return this;
    }
    
    public String getResourceKey() {
        return this.resourceKey;
    }
    
    public ConversionException setResourceKey(final String resourceKey) {
        this.resourceKey = resourceKey;
        return this;
    }
    
    public ConversionException setVariable(final String name, final Object value) {
        Args.notEmpty(name, "name");
        Args.notNull(value, "value");
        if (this.vars == null) {
            this.vars = (Map<String, Object>)Generics.newHashMap(2);
        }
        this.vars.put(name, value);
        return this;
    }
    
    public Map<String, Object> getVariables() {
        return this.vars;
    }
}
