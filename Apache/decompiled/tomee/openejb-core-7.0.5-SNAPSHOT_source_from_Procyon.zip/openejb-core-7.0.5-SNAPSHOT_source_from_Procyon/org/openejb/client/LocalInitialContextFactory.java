// 
// Decompiled by Procyon v0.5.36
// 

package org.openejb.client;

@Deprecated
public class LocalInitialContextFactory extends org.apache.openejb.core.LocalInitialContextFactory
{
}
