// 
// Decompiled by Procyon v0.5.36
// 

package org.openejb;

import javax.transaction.TransactionManager;
import org.apache.openejb.spi.ApplicationServer;

public final class OpenEJB
{
    public static ApplicationServer getApplicationServer() {
        return org.apache.openejb.OpenEJB.getApplicationServer();
    }
    
    public static TransactionManager getTransactionManager() {
        return org.apache.openejb.OpenEJB.getTransactionManager();
    }
}
