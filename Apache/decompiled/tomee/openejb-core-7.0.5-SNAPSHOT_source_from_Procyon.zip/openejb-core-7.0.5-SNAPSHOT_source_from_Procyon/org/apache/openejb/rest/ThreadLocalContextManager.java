// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.ws.rs.core.Configuration;
import javax.ws.rs.container.ResourceContext;
import javax.ws.rs.container.ResourceInfo;
import javax.servlet.ServletContext;
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletRequest;
import javax.ws.rs.ext.Providers;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Request;
import java.util.Map;
import javax.ws.rs.core.Application;

public class ThreadLocalContextManager
{
    public static final ThreadLocalRequest REQUEST;
    public static final ThreadLocalServletConfig SERVLET_CONFIG;
    public static final ThreadLocalServletContext SERVLET_CONTEXT;
    public static final ThreadLocalServletRequest SERVLET_REQUEST;
    public static final ThreadLocalHttpServletRequest HTTP_SERVLET_REQUEST;
    public static final ThreadLocalHttpServletResponse HTTP_SERVLET_RESPONSE;
    public static final ThreadLocalUriInfo URI_INFO;
    public static final ThreadLocalHttpHeaders HTTP_HEADERS;
    public static final ThreadLocalSecurityContext SECURITY_CONTEXT;
    public static final ThreadLocalContextResolver CONTEXT_RESOLVER;
    public static final ThreadLocalProviders PROVIDERS;
    public static final ThreadLocal<Application> APPLICATION;
    public static final ThreadLocalConfiguration CONFIGURATION;
    public static final ThreadLocalResourceInfo RESOURCE_INFO;
    public static final ThreadLocalResourceContext RESOURCE_CONTEXT;
    public static final ThreadLocal<Map<String, Object>> OTHERS;
    
    public static void reset() {
        ThreadLocalContextManager.REQUEST.remove();
        ThreadLocalContextManager.SERVLET_REQUEST.remove();
        ThreadLocalContextManager.SERVLET_CONFIG.remove();
        ThreadLocalContextManager.SERVLET_CONTEXT.remove();
        ThreadLocalContextManager.HTTP_SERVLET_REQUEST.remove();
        ThreadLocalContextManager.HTTP_SERVLET_RESPONSE.remove();
        ThreadLocalContextManager.URI_INFO.remove();
        ThreadLocalContextManager.HTTP_HEADERS.remove();
        ThreadLocalContextManager.SECURITY_CONTEXT.remove();
        ThreadLocalContextManager.CONTEXT_RESOLVER.remove();
        ThreadLocalContextManager.PROVIDERS.remove();
        ThreadLocalContextManager.APPLICATION.remove();
        ThreadLocalContextManager.CONFIGURATION.remove();
        ThreadLocalContextManager.RESOURCE_INFO.remove();
        ThreadLocalContextManager.RESOURCE_CONTEXT.remove();
        final Map<String, Object> map = ThreadLocalContextManager.OTHERS.get();
        if (map != null) {
            map.clear();
        }
        ThreadLocalContextManager.OTHERS.remove();
    }
    
    public static Object findThreadLocal(final Class<?> type) {
        if (Request.class.equals(type)) {
            return ThreadLocalContextManager.REQUEST;
        }
        if (UriInfo.class.equals(type)) {
            return ThreadLocalContextManager.URI_INFO;
        }
        if (HttpHeaders.class.equals(type)) {
            return ThreadLocalContextManager.HTTP_HEADERS;
        }
        if (SecurityContext.class.equals(type)) {
            return ThreadLocalContextManager.SECURITY_CONTEXT;
        }
        if (ContextResolver.class.equals(type)) {
            return ThreadLocalContextManager.CONTEXT_RESOLVER;
        }
        if (Providers.class.equals(type)) {
            return ThreadLocalContextManager.PROVIDERS;
        }
        if (ServletRequest.class.equals(type)) {
            return ThreadLocalContextManager.SERVLET_REQUEST;
        }
        if (HttpServletRequest.class.equals(type)) {
            return ThreadLocalContextManager.HTTP_SERVLET_REQUEST;
        }
        if (HttpServletResponse.class.equals(type)) {
            return ThreadLocalContextManager.HTTP_SERVLET_RESPONSE;
        }
        if (ServletConfig.class.equals(type)) {
            return ThreadLocalContextManager.SERVLET_CONFIG;
        }
        if (ServletContext.class.equals(type)) {
            return ThreadLocalContextManager.SERVLET_CONTEXT;
        }
        if (ResourceInfo.class.equals(type)) {
            return ThreadLocalContextManager.RESOURCE_INFO;
        }
        if (ResourceContext.class.equals(type)) {
            return ThreadLocalContextManager.RESOURCE_CONTEXT;
        }
        if (Application.class.equals(type)) {
            return ThreadLocalContextManager.APPLICATION;
        }
        if (Configuration.class.equals(type)) {
            return ThreadLocalContextManager.CONFIGURATION;
        }
        return null;
    }
    
    static {
        REQUEST = new ThreadLocalRequest();
        SERVLET_CONFIG = new ThreadLocalServletConfig();
        SERVLET_CONTEXT = new ThreadLocalServletContext();
        SERVLET_REQUEST = new ThreadLocalServletRequest();
        HTTP_SERVLET_REQUEST = new ThreadLocalHttpServletRequest();
        HTTP_SERVLET_RESPONSE = new ThreadLocalHttpServletResponse();
        URI_INFO = new ThreadLocalUriInfo();
        HTTP_HEADERS = new ThreadLocalHttpHeaders();
        SECURITY_CONTEXT = new ThreadLocalSecurityContext();
        CONTEXT_RESOLVER = new ThreadLocalContextResolver();
        PROVIDERS = new ThreadLocalProviders();
        APPLICATION = new ThreadLocal<Application>();
        CONFIGURATION = new ThreadLocalConfiguration();
        RESOURCE_INFO = new ThreadLocalResourceInfo();
        RESOURCE_CONTEXT = new ThreadLocalResourceContext();
        OTHERS = new ThreadLocal<Map<String, Object>>();
    }
}
