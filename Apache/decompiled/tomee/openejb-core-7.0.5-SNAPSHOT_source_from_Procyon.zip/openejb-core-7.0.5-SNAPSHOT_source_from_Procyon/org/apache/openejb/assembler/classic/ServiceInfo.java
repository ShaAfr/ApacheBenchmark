// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.Properties;
import java.net.URI;
import java.util.List;

public class ServiceInfo extends InfoObject
{
    public String service;
    public List<String> types;
    public String description;
    public String id;
    public String displayName;
    public String className;
    public String codebase;
    public URI[] classpath;
    public String classpathAPI;
    public Properties properties;
    public final List<String> constructorArgs;
    public Properties unsetProperties;
    public String factoryMethod;
    
    public ServiceInfo() {
        this.types = new ArrayList<String>();
        this.constructorArgs = new ArrayList<String>();
    }
}
