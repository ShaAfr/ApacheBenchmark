// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.classloader;

import org.apache.xbean.finder.filter.Filter;

public class FalseFilter implements Filter
{
    public static final FalseFilter INSTANCE;
    
    public boolean accept(final String name) {
        return false;
    }
    
    static {
        INSTANCE = new FalseFilter();
    }
}
