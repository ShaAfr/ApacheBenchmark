// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

public class PlainTextPasswordCipher implements PasswordCipher
{
    @Override
    public String decrypt(final char[] encryptedPassword) {
        if (null == encryptedPassword) {
            throw new IllegalArgumentException("encodedPassword cannot be null.");
        }
        return new String(encryptedPassword);
    }
    
    @Override
    public char[] encrypt(final String plainPassword) {
        if (null == plainPassword) {
            throw new IllegalArgumentException("plainPassword cannot be null.");
        }
        return plainPassword.toCharArray();
    }
}
