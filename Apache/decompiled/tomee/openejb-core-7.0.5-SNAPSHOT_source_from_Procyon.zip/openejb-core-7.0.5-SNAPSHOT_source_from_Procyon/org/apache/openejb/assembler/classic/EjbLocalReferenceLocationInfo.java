// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class EjbLocalReferenceLocationInfo extends InfoObject
{
    public boolean remote;
    public String ejbDeploymentId;
}
