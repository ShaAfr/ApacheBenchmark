// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer.quartz;

import java.sql.SQLException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.io.ByteArrayInputStream;
import java.sql.ResultSet;
import org.apache.openejb.quartz.impl.jdbcjobstore.StdJDBCDelegate;

public class PatchedStdJDBCDelegate extends StdJDBCDelegate
{
    protected Object getObjectFromBlob(final ResultSet rs, final String colName) throws ClassNotFoundException, IOException, SQLException {
        Object obj = null;
        final Blob blobLocator = rs.getBlob(colName);
        if (blobLocator != null && blobLocator.length() != 0L) {
            final InputStream binaryInput = blobLocator.getBinaryStream();
            if (null != binaryInput && (!(binaryInput instanceof ByteArrayInputStream) || ((ByteArrayInputStream)binaryInput).available() != 0)) {
                final ObjectInputStream in = new QuartzObjectInputStream(binaryInput, this.classLoadHelper);
                try {
                    obj = in.readObject();
                }
                finally {
                    in.close();
                }
            }
        }
        return obj;
    }
}
