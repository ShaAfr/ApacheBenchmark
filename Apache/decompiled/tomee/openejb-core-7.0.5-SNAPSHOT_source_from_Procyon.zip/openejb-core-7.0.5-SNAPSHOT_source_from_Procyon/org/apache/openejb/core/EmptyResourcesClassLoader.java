// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.io.IOException;
import java.util.Enumeration;
import java.net.URL;

public class EmptyResourcesClassLoader extends ClassLoader
{
    public EmptyResourcesClassLoader() {
        super(null);
    }
    
    @Override
    protected URL findResource(final String name) {
        return null;
    }
    
    @Override
    public Enumeration<URL> getResources(final String name) throws IOException {
        return new Enumeration<URL>() {
            @Override
            public boolean hasMoreElements() {
                return false;
            }
            
            @Override
            public URL nextElement() {
                throw new UnsupportedOperationException("this enumeration has no elements");
            }
        };
    }
}
