// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.ApplicationException;
import org.apache.openejb.SystemException;
import javax.transaction.TransactionManager;
import javax.transaction.Transaction;

public class TxRequired extends JtaTransactionPolicy
{
    private final Transaction clientTx;
    private final Transaction currentTx;
    
    public TxRequired(final TransactionManager transactionManager) throws SystemException {
        super(TransactionType.Required, transactionManager);
        this.clientTx = this.getTransaction();
        if (this.clientTx == null) {
            this.currentTx = this.beginTransaction();
        }
        else {
            this.currentTx = this.clientTx;
        }
    }
    
    @Override
    public boolean isNewTransaction() {
        return this.clientTx == null;
    }
    
    @Override
    public boolean isClientTransaction() {
        return !this.isNewTransaction();
    }
    
    @Override
    public Transaction getCurrentTransaction() {
        return this.currentTx;
    }
    
    @Override
    public void commit() throws ApplicationException, SystemException {
        if (this.clientTx == null) {
            this.completeTransaction(this.currentTx);
        }
        else {
            this.fireNonTransactionalCompletion();
        }
    }
}
