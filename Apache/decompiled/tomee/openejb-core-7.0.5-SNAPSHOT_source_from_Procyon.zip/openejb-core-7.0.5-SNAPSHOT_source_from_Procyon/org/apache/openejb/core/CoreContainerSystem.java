// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.util.Locale;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.openejb.loader.SystemInstance;
import javax.naming.NamingException;
import org.apache.openejb.OpenEJBRuntimeException;
import java.util.concurrent.ConcurrentHashMap;
import javax.naming.Context;
import java.util.List;
import org.apache.openejb.Container;
import org.apache.openejb.BeanContext;
import org.apache.openejb.AppContext;
import java.util.Map;
import org.apache.openejb.spi.ContainerSystem;

public class CoreContainerSystem implements ContainerSystem
{
    private final Map<Object, AppContext> apps;
    private final Map<Object, BeanContext> deployments;
    private final Map<Object, Container> containers;
    private final Map<String, List<WebContext>> webDeployments;
    private final Context jndiContext;
    
    public CoreContainerSystem(final JndiFactory jndiFactory) {
        this.apps = new ConcurrentHashMap<Object, AppContext>();
        this.deployments = new ConcurrentHashMap<Object, BeanContext>();
        this.containers = new ConcurrentHashMap<Object, Container>();
        this.webDeployments = new ConcurrentHashMap<String, List<WebContext>>();
        if (jndiFactory == null) {
            throw new NullPointerException("JndiFactory required");
        }
        this.jndiContext = jndiFactory.createRootContext();
        try {
            if (!(this.jndiContext.lookup("openejb/local") instanceof Context) || !(this.jndiContext.lookup("openejb/remote") instanceof Context) || !(this.jndiContext.lookup("openejb/client") instanceof Context) || !(this.jndiContext.lookup("openejb/Deployment") instanceof Context) || !(this.jndiContext.lookup("openejb/global") instanceof Context)) {
                throw new OpenEJBRuntimeException("core openejb naming context not properly initialized.  It must have subcontexts for openejb/local, openejb/remote, openejb/client, and openejb/Deployment already present");
            }
        }
        catch (NamingException exception) {
            throw new OpenEJBRuntimeException("core openejb naming context not properly initialized.  It must have subcontexts for openejb/local, openejb/remote, openejb/client, and openejb/Deployment already present", exception);
        }
        SystemInstance.get().setComponent((Class)JndiFactory.class, (Object)jndiFactory);
    }
    
    @Override
    public BeanContext getBeanContext(final Object deploymentID) {
        return this.deployments.get(deploymentID);
    }
    
    @Override
    public BeanContext[] deployments() {
        return this.deployments.values().toArray(new BeanContext[this.deployments.size()]);
    }
    
    public void addDeployment(final BeanContext deployment) {
        this.deployments.put(deployment.getDeploymentID(), deployment);
    }
    
    public void removeBeanContext(final BeanContext info) {
        this.deployments.remove(info.getDeploymentID());
    }
    
    @Override
    public Container getContainer(final Object id) {
        return this.containers.get(id);
    }
    
    @Override
    public Container[] containers() {
        return this.containers.values().toArray(new Container[this.containers.size()]);
    }
    
    public void addContainer(final Object id, final Container c) {
        this.containers.put(id, c);
    }
    
    public void removeContainer(final Object id) {
        this.containers.remove(id);
    }
    
    @Override
    public WebContext getWebContextByHost(final String id, final String host) {
        final List<WebContext> webContexts = this.webDeployments.get(id);
        if (webContexts == null || webContexts.isEmpty()) {
            return null;
        }
        if (webContexts.size() == 1 && webContexts.get(0).getHost() == null) {
            return webContexts.get(0);
        }
        for (final WebContext web : webContexts) {
            if (web.getHost() != null && web.getHost().equals(host)) {
                return web;
            }
        }
        return null;
    }
    
    @Override
    public WebContext getWebContext(final String id) {
        final List<WebContext> webContexts = this.webDeployments.get(id);
        return (webContexts != null && !webContexts.isEmpty()) ? webContexts.get(0) : null;
    }
    
    public WebContext[] WebDeployments() {
        final Collection<WebContext> all = new ArrayList<WebContext>(this.webDeployments.size());
        for (final Collection<WebContext> list : this.webDeployments.values()) {
            all.addAll(list);
        }
        return all.toArray(new WebContext[all.size()]);
    }
    
    public void addWebContext(final WebContext webDeployment) {
        final String id = webDeployment.getId();
        List<WebContext> list = this.webDeployments.get(id);
        if (list == null) {
            list = new ArrayList<WebContext>();
            this.webDeployments.put(id, list);
        }
        list.add(webDeployment);
    }
    
    public void removeWebContext(final WebContext info) {
        this.webDeployments.remove(info.getId());
    }
    
    @Override
    public Context getJNDIContext() {
        return this.jndiContext;
    }
    
    @Override
    public List<AppContext> getAppContexts() {
        return new ArrayList<AppContext>(this.apps.values());
    }
    
    @Override
    public AppContext getAppContext(final Object id) {
        AppContext context = this.apps.get(id);
        if (null == context && null != id) {
            context = this.apps.get(id.toString().toLowerCase(Locale.ENGLISH));
        }
        return context;
    }
    
    public void addAppContext(final AppContext appContext) {
        this.apps.put(appContext.getId().toLowerCase(Locale.ENGLISH), appContext);
    }
    
    public AppContext removeAppContext(final Object id) {
        AppContext context = this.apps.remove(id);
        if (null == context && null != id) {
            context = this.apps.remove(id.toString().toLowerCase(Locale.ENGLISH));
        }
        return context;
    }
    
    public synchronized Object[] getAppContextKeys() {
        return this.apps.keySet().toArray();
    }
}
