// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.LinkedList;
import java.util.Properties;
import java.util.List;

public class ExclusionInfo extends InfoObject
{
    public final List<String> availableClasses;
    public final List<String> notAvailableClasses;
    public final List<String> systemPropertiesPresence;
    public final Properties systemProperties;
    
    public ExclusionInfo() {
        this.availableClasses = new LinkedList<String>();
        this.notAvailableClasses = new LinkedList<String>();
        this.systemPropertiesPresence = new LinkedList<String>();
        this.systemProperties = new Properties();
    }
}
