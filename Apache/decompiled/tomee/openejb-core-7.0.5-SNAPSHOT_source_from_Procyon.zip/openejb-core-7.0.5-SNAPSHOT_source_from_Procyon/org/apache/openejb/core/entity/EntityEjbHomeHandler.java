// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.entity;

import org.apache.openejb.Container;
import javax.ejb.EJBObject;
import javax.ejb.RemoveException;
import javax.ejb.EJBLocalObject;
import java.util.ArrayList;
import java.util.Enumeration;
import org.apache.openejb.util.ArrayEnumeration;
import org.apache.openejb.ProxyInfo;
import java.util.Vector;
import java.util.Collection;
import org.apache.openejb.OpenEJBException;
import java.lang.reflect.Method;
import org.apache.openejb.core.ivm.BaseEjbProxyHandler;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.core.ivm.EjbObjectProxyHandler;
import java.util.List;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ivm.EjbHomeProxyHandler;

public class EntityEjbHomeHandler extends EjbHomeProxyHandler
{
    public EntityEjbHomeHandler(final BeanContext beanContext, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        super(beanContext, interfaceType, interfaces, mainInterface);
    }
    
    @Override
    public Object createProxy(final Object primaryKey, final Class mainInterface) {
        final Object proxy = super.createProxy(primaryKey, mainInterface);
        final EjbObjectProxyHandler handler = (EjbObjectProxyHandler)ProxyManager.getInvocationHandler(proxy);
        this.registerHandler(handler.getRegistryId(), handler);
        return proxy;
    }
    
    @Override
    protected Object findX(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        Object retValue;
        try {
            retValue = this.container.invoke(this.deploymentID, this.interfaceType, interfce, method, args, null);
        }
        catch (OpenEJBException e) {
            EntityEjbHomeHandler.logger.debug("entityEjbHomeHandler.containerInvocationFailure", e, e.getMessage());
            throw e;
        }
        if (retValue instanceof Collection) {
            final Object[] proxyInfos = ((Collection)retValue).toArray();
            final Vector proxies = new Vector();
            for (int i = 0; i < proxyInfos.length; ++i) {
                final ProxyInfo proxyInfo = (ProxyInfo)proxyInfos[i];
                proxies.addElement(this.createProxy(proxyInfo.getPrimaryKey(), this.getMainInterface()));
            }
            return proxies;
        }
        if (retValue instanceof ArrayEnumeration) {
            final ArrayEnumeration enumeration = (ArrayEnumeration)retValue;
            for (int j = enumeration.size() - 1; j >= 0; --j) {
                final ProxyInfo proxyInfo2 = (ProxyInfo)enumeration.get(j);
                enumeration.set(j, this.createProxy(proxyInfo2.getPrimaryKey(), this.getMainInterface()));
            }
            return enumeration;
        }
        if (retValue instanceof Enumeration) {
            final Enumeration enumeration2 = (Enumeration)retValue;
            final List proxies2 = new ArrayList();
            while (enumeration2.hasMoreElements()) {
                final ProxyInfo proxyInfo2 = enumeration2.nextElement();
                proxies2.add(this.createProxy(proxyInfo2.getPrimaryKey(), this.getMainInterface()));
            }
            return new ArrayEnumeration(proxies2);
        }
        final ProxyInfo proxyInfo3 = (ProxyInfo)retValue;
        return this.createProxy(proxyInfo3.getPrimaryKey(), this.getMainInterface());
    }
    
    @Override
    protected Object removeByPrimaryKey(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        final Object primKey = args[0];
        if (primKey instanceof EJBLocalObject) {
            final Class ejbObjectProxyClass = primKey.getClass();
            String ejbObjectName = null;
            for (final Class clazz : ejbObjectProxyClass.getInterfaces()) {
                if (EJBLocalObject.class.isAssignableFrom(clazz)) {
                    ejbObjectName = clazz.getSimpleName();
                    break;
                }
            }
            throw new RemoveException("Invalid argument '" + ejbObjectName + "', expected primary key.  Update to ejbLocalHome.remove(" + lcfirst(ejbObjectName) + ".getPrimaryKey())");
        }
        if (primKey instanceof EJBObject) {
            final Class ejbObjectProxyClass = primKey.getClass();
            String ejbObjectName = null;
            for (final Class clazz : ejbObjectProxyClass.getInterfaces()) {
                if (EJBObject.class.isAssignableFrom(clazz)) {
                    ejbObjectName = clazz.getSimpleName();
                    break;
                }
            }
            throw new RemoveException("Invalid argument '" + ejbObjectName + "', expected primary key.  Update to ejbHome.remove(" + lcfirst(ejbObjectName) + ".getPrimaryKey())");
        }
        this.container.invoke(this.deploymentID, this.interfaceType, interfce, method, args, primKey);
        this.invalidateAllHandlers(EntityEjbObjectHandler.getRegistryId(this.container, this.deploymentID, primKey));
        return null;
    }
    
    private static String lcfirst(final String s) {
        if (s == null || s.length() < 1) {
            return s;
        }
        final StringBuilder sb = new StringBuilder(s);
        sb.setCharAt(0, Character.toLowerCase(sb.charAt(0)));
        return sb.toString();
    }
    
    @Override
    protected EjbObjectProxyHandler newEjbObjectHandler(final BeanContext beanContext, final Object pk, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        return new EntityEjbObjectHandler(this.getBeanContext(), pk, interfaceType, interfaces, mainInterface);
    }
}
