// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.singleton;

import org.apache.openejb.ProxyInfo;
import org.apache.openejb.core.webservices.AddressingSupport;
import org.apache.openejb.core.webservices.NoAddressingSupport;
import javax.xml.rpc.handler.MessageContext;
import java.util.Collection;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.interceptor.AroundInvoke;
import org.apache.xbean.finder.ClassFinder;
import java.util.ArrayList;
import java.util.Map;
import javax.ejb.ConcurrentAccessTimeoutException;
import org.apache.openejb.core.interceptor.InterceptorData;
import org.apache.openejb.core.transaction.TransactionPolicy;
import java.util.concurrent.locks.Lock;
import org.apache.openejb.core.ExceptionType;
import org.apache.openejb.core.interceptor.InterceptorStack;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import javax.ejb.LockType;
import javax.security.auth.login.LoginException;
import org.apache.openejb.core.BaseContext;
import org.apache.openejb.core.Operation;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.ApplicationException;
import javax.ejb.EJBAccessException;
import org.apache.openejb.core.security.AbstractSecurityService;
import org.apache.openejb.cdi.CurrentCreationalContext;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.core.timer.EjbTimerService;
import org.apache.openejb.ContainerType;
import org.apache.openejb.OpenEJBException;
import java.util.Iterator;
import org.apache.openejb.Container;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.openejb.util.Duration;
import org.apache.openejb.spi.SecurityService;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import org.apache.openejb.BeanContext;
import java.util.HashMap;
import org.apache.openejb.RpcContainer;

public class SingletonContainer implements RpcContainer
{
    private final SingletonInstanceManager instanceManager;
    private final HashMap<String, BeanContext> deploymentRegistry;
    private final ConcurrentMap<Class<?>, List<Method>> interceptorCache;
    private final Object containerID;
    private final SecurityService securityService;
    private Duration accessTimeout;
    
    public SingletonContainer(final Object id, final SecurityService securityService) throws OpenEJBException {
        this.deploymentRegistry = new HashMap<String, BeanContext>();
        this.interceptorCache = new ConcurrentHashMap<Class<?>, List<Method>>();
        this.containerID = id;
        this.securityService = securityService;
        this.instanceManager = new SingletonInstanceManager(securityService);
        for (final BeanContext beanContext : this.deploymentRegistry.values()) {
            beanContext.setContainer(this);
        }
    }
    
    public void setAccessTimeout(final Duration duration) {
        this.accessTimeout = duration;
    }
    
    @Override
    public synchronized BeanContext[] getBeanContexts() {
        return this.deploymentRegistry.values().toArray(new BeanContext[this.deploymentRegistry.size()]);
    }
    
    @Override
    public synchronized BeanContext getBeanContext(final Object deploymentID) {
        final String id = (String)deploymentID;
        return this.deploymentRegistry.get(id);
    }
    
    @Override
    public ContainerType getContainerType() {
        return ContainerType.SINGLETON;
    }
    
    @Override
    public Object getContainerID() {
        return this.containerID;
    }
    
    @Override
    public void deploy(final BeanContext beanContext) throws OpenEJBException {
        this.instanceManager.deploy(beanContext);
        final String id = (String)beanContext.getDeploymentID();
        synchronized (this) {
            this.deploymentRegistry.put(id, beanContext);
            beanContext.setContainer(this);
        }
    }
    
    @Override
    public void start(final BeanContext info) throws OpenEJBException {
        this.instanceManager.start(info);
        final EjbTimerService timerService = info.getEjbTimerService();
        if (timerService != null) {
            timerService.start();
        }
    }
    
    @Override
    public void stop(final BeanContext info) throws OpenEJBException {
        info.stop();
    }
    
    @Override
    public void undeploy(final BeanContext beanContext) {
        final ThreadContext threadContext = new ThreadContext(beanContext, null);
        final ThreadContext old = ThreadContext.enter(threadContext);
        try {
            this.instanceManager.freeInstance(threadContext);
        }
        finally {
            ThreadContext.exit(old);
        }
        this.instanceManager.undeploy(beanContext);
        synchronized (this) {
            final String id = (String)beanContext.getDeploymentID();
            beanContext.setContainer(null);
            beanContext.setContainerData(null);
            this.deploymentRegistry.remove(id);
        }
    }
    
    @Override
    public Object invoke(final Object deployID, InterfaceType type, final Class callInterface, final Method callMethod, final Object[] args, final Object primKey) throws OpenEJBException {
        final BeanContext beanContext = this.getBeanContext(deployID);
        if (beanContext == null) {
            throw new OpenEJBException("Deployment does not exist in this container. Deployment(id='" + deployID + "'), Container(id='" + this.containerID + "')");
        }
        if (type == null) {
            type = beanContext.getInterfaceType(callInterface);
        }
        final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        final CurrentCreationalContext currentCreationalContext = beanContext.get(CurrentCreationalContext.class);
        Object runAs = null;
        try {
            if (oldCallContext != null) {
                final BeanContext oldBc = oldCallContext.getBeanContext();
                if (oldBc.getRunAsUser() != null || oldBc.getRunAs() != null) {
                    runAs = AbstractSecurityService.class.cast(this.securityService).overrideWithRunAsContext(callContext, beanContext, oldBc);
                }
            }
            final boolean authorized = type == InterfaceType.TIMEOUT || this.getSecurityService().isCallerAuthorized(callMethod, type);
            if (!authorized) {
                throw new ApplicationException((Exception)new EJBAccessException("Unauthorized Access by Principal Denied"));
            }
            final Class declaringClass = callMethod.getDeclaringClass();
            if (EJBHome.class.isAssignableFrom(declaringClass) || EJBLocalHome.class.isAssignableFrom(declaringClass)) {
                if (callMethod.getName().startsWith("create")) {
                    return this.createEJBObject(beanContext, callMethod);
                }
                return null;
            }
            else {
                if (EJBObject.class == declaringClass || EJBLocalObject.class == declaringClass) {
                    return null;
                }
                final Instance instance = this.instanceManager.getInstance(callContext);
                callContext.setCurrentOperation((type == InterfaceType.TIMEOUT) ? Operation.TIMEOUT : Operation.BUSINESS);
                callContext.setCurrentAllowedStates(null);
                callContext.set(Method.class, runMethod);
                callContext.setInvokedInterface(callInterface);
                if (currentCreationalContext != null) {
                    currentCreationalContext.set(instance.creationalContext);
                }
                return this._invoke(callMethod, runMethod, args, instance, callContext, type);
            }
        }
        finally {
            if (runAs != null) {
                try {
                    this.securityService.associate(runAs);
                }
                catch (LoginException ex) {}
            }
            ThreadContext.exit(oldCallContext);
            if (currentCreationalContext != null) {
                currentCreationalContext.remove();
            }
        }
    }
    
    private SecurityService getSecurityService() {
        return this.securityService;
    }
    
    protected Object _invoke(final Method callMethod, final Method runMethod, final Object[] args, final Instance instance, final ThreadContext callContext, final InterfaceType callType) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final Duration accessTimeout = this.getAccessTimeout(beanContext, runMethod);
        final boolean read = LockType.READ.equals((Object)beanContext.getConcurrencyAttribute(runMethod));
        final Lock lock = this.aquireLock(read, accessTimeout, instance, runMethod);
        Object returnValue;
        try {
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, callType), callContext);
            returnValue = null;
            try {
                if (callType == InterfaceType.SERVICE_ENDPOINT) {
                    callContext.setCurrentOperation(Operation.BUSINESS_WS);
                    returnValue = this.invokeWebService(args, beanContext, runMethod, instance);
                }
                else {
                    final List<InterceptorData> interceptors = beanContext.getMethodInterceptors(runMethod);
                    final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, runMethod, (callType == InterfaceType.TIMEOUT) ? Operation.TIMEOUT : Operation.BUSINESS, interceptors, instance.interceptors);
                    returnValue = interceptorStack.invoke(args);
                }
            }
            catch (Throwable e) {
                final ExceptionType type = beanContext.getExceptionType(e);
                if (type == ExceptionType.SYSTEM) {
                    EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
                }
                else {
                    EjbTransactionUtil.handleApplicationException(txPolicy, e, type == ExceptionType.APPLICATION_ROLLBACK);
                }
            }
            finally {
                EjbTransactionUtil.afterInvoke(txPolicy, callContext);
            }
        }
        finally {
            lock.unlock();
        }
        return returnValue;
    }
    
    private Duration getAccessTimeout(final BeanContext beanContext, final Method callMethod) {
        Duration accessTimeout = beanContext.getAccessTimeout(callMethod);
        if (accessTimeout == null) {
            accessTimeout = beanContext.getAccessTimeout();
            if (accessTimeout == null) {
                accessTimeout = this.accessTimeout;
            }
        }
        return accessTimeout;
    }
    
    private Lock aquireLock(final boolean read, final Duration accessTimeout, final Instance instance, final Method runMethod) {
        Lock lock;
        if (read) {
            lock = instance.lock.readLock();
        }
        else {
            lock = instance.lock.writeLock();
        }
        boolean lockAcquired;
        if (accessTimeout == null || accessTimeout.getTime() < 0L) {
            lock.lock();
            lockAcquired = true;
        }
        else if (accessTimeout.getTime() == 0L) {
            lockAcquired = lock.tryLock();
        }
        else {
            try {
                lockAcquired = lock.tryLock(accessTimeout.getTime(), accessTimeout.getUnit());
            }
            catch (InterruptedException e) {
                throw (ConcurrentAccessTimeoutException)new ConcurrentAccessTimeoutException("Unable to get " + (read ? "read" : "write") + " lock within specified time on '" + runMethod.getName() + "' method for: " + instance.bean.getClass().getName()).initCause((Throwable)e);
            }
        }
        if (!lockAcquired) {
            throw new ConcurrentAccessTimeoutException("Unable to get " + (read ? "read" : "write") + " lock on '" + runMethod.getName() + "' method for: " + instance.bean.getClass().getName());
        }
        return lock;
    }
    
    private Object invokeWebService(final Object[] args, final BeanContext beanContext, final Method runMethod, final Instance instance) throws Exception {
        if (args.length < 2) {
            throw new IllegalArgumentException("WebService calls must follow format {messageContext, interceptor, [arg...]}.");
        }
        final Object messageContext = args[0];
        if (messageContext == null) {
            throw new IllegalArgumentException("MessageContext is null.");
        }
        final Object interceptor = args[1];
        if (interceptor == null) {
            throw new IllegalArgumentException("Interceptor instance is null.");
        }
        final Class<?> interceptorClass = interceptor.getClass();
        final Map<String, Object> interceptors = new HashMap<String, Object>(instance.interceptors);
        interceptors.put(interceptorClass.getName(), interceptor);
        final List<InterceptorData> interceptorDatas = new ArrayList<InterceptorData>();
        final InterceptorData providerData = new InterceptorData(interceptorClass);
        List<Method> aroundInvokes = this.interceptorCache.get(interceptorClass);
        if (aroundInvokes == null) {
            aroundInvokes = (List<Method>)new ClassFinder(new Class[] { interceptorClass }).findAnnotatedMethods((Class)AroundInvoke.class);
            if (SingletonContainer.class.getClassLoader() == interceptorClass.getClassLoader()) {
                final List<Method> value = new CopyOnWriteArrayList<Method>(aroundInvokes);
                aroundInvokes = this.interceptorCache.putIfAbsent(interceptorClass, value);
                if (aroundInvokes == null) {
                    aroundInvokes = value;
                }
            }
        }
        providerData.getAroundInvoke().addAll(aroundInvokes);
        interceptorDatas.add(0, providerData);
        interceptorDatas.addAll(beanContext.getMethodInterceptors(runMethod));
        final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, runMethod, Operation.BUSINESS_WS, interceptorDatas, interceptors);
        final Object[] params = new Object[runMethod.getParameterTypes().length];
        if (messageContext instanceof MessageContext) {
            ThreadContext.getThreadContext().set(MessageContext.class, (MessageContext)messageContext);
            return interceptorStack.invoke((MessageContext)messageContext, params);
        }
        if (messageContext instanceof javax.xml.ws.handler.MessageContext) {
            AddressingSupport wsaSupport = NoAddressingSupport.INSTANCE;
            for (int i = 2; i < args.length; ++i) {
                if (args[i] instanceof AddressingSupport) {
                    wsaSupport = (AddressingSupport)args[i];
                }
            }
            ThreadContext.getThreadContext().set(AddressingSupport.class, wsaSupport);
            ThreadContext.getThreadContext().set(javax.xml.ws.handler.MessageContext.class, (javax.xml.ws.handler.MessageContext)messageContext);
            return interceptorStack.invoke((javax.xml.ws.handler.MessageContext)messageContext, params);
        }
        throw new IllegalArgumentException("Uknown MessageContext type: " + messageContext.getClass().getName());
    }
    
    protected ProxyInfo createEJBObject(final BeanContext beanContext, final Method callMethod) {
        return new ProxyInfo(beanContext, null);
    }
}
