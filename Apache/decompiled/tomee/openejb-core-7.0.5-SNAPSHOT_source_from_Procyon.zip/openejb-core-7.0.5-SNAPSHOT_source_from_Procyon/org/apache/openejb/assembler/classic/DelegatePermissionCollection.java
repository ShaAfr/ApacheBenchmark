// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.ArrayEnumeration;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import org.apache.openejb.loader.SystemInstance;
import java.util.Enumeration;
import java.security.Permission;
import java.security.PermissionCollection;

public class DelegatePermissionCollection extends PermissionCollection
{
    private static final String PERMISSION_COLLECTION_CLASS = "openejb.permission-collection.class";
    private final PermissionCollection pc;
    
    public DelegatePermissionCollection() {
        this.pc = getPermissionCollection();
    }
    
    @Override
    public void add(final Permission permission) {
        this.pc.add(permission);
    }
    
    @Override
    public boolean implies(final Permission permission) {
        return this.pc.implies(permission);
    }
    
    @Override
    public Enumeration<Permission> elements() {
        return this.pc.elements();
    }
    
    public static PermissionCollection getPermissionCollection() {
        try {
            return (PermissionCollection)DelegatePermissionCollection.class.getClassLoader().loadClass(SystemInstance.get().getOptions().get("openejb.permission-collection.class", FastPermissionCollection.class.getName())).newInstance();
        }
        catch (Exception cnfe) {
            return new FastPermissionCollection();
        }
    }
    
    public static class FastPermissionCollection extends PermissionCollection
    {
        private static final int MAX_CACHE_SIZE;
        private final List<Permission> permissions;
        private final Map<Permission, Boolean> alreadyEvaluatedPermissions;
        
        public FastPermissionCollection() {
            this.permissions = new ArrayList<Permission>();
            this.alreadyEvaluatedPermissions = new ConcurrentHashMap<Permission, Boolean>();
        }
        
        @Override
        public synchronized void add(final Permission permission) {
            this.permissions.add(permission);
        }
        
        @Override
        public synchronized boolean implies(final Permission permission) {
            if (this.alreadyEvaluatedPermissions.containsKey(permission)) {
                return this.alreadyEvaluatedPermissions.get(permission);
            }
            if (this.alreadyEvaluatedPermissions.size() > FastPermissionCollection.MAX_CACHE_SIZE) {
                this.alreadyEvaluatedPermissions.clear();
            }
            for (final Permission perm : this.permissions) {
                if (perm.implies(permission)) {
                    this.alreadyEvaluatedPermissions.put(permission, true);
                    return true;
                }
            }
            this.alreadyEvaluatedPermissions.put(permission, false);
            return false;
        }
        
        @Override
        public synchronized Enumeration<Permission> elements() {
            return (Enumeration<Permission>)new ArrayEnumeration(this.permissions);
        }
        
        static {
            MAX_CACHE_SIZE = SystemInstance.get().getOptions().get("openejb.permission-collection.cache.size", 3000);
        }
    }
}
