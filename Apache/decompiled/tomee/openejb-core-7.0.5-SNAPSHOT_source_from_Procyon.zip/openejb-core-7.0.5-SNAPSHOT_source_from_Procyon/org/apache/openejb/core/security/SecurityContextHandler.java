// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security;

import javax.resource.spi.work.WorkContext;
import javax.security.auth.login.LoginException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.SecurityService;
import javax.resource.spi.work.WorkCompletedException;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.Subject;
import javax.resource.spi.work.SecurityContext;
import org.apache.geronimo.connector.work.WorkContextHandler;

public class SecurityContextHandler implements WorkContextHandler<SecurityContext>
{
    private ConnectorCallbackHandler callbackHandler;
    private final String securityRealmName;
    
    public SecurityContextHandler(final String securityRealmName) {
        this.securityRealmName = securityRealmName;
    }
    
    public void before(final SecurityContext securityContext) throws WorkCompletedException {
        if (securityContext != null) {
            this.callbackHandler = new ConnectorCallbackHandler(this.securityRealmName);
            final Subject clientSubject = new Subject();
            securityContext.setupSecurityContext((CallbackHandler)this.callbackHandler, clientSubject, (Subject)null);
        }
    }
    
    public void after(final SecurityContext securityContext) throws WorkCompletedException {
        final SecurityService securityService = (SecurityService)SystemInstance.get().getComponent((Class)SecurityService.class);
        final Object loginObj = securityService.disassociate();
        if (loginObj != null) {
            try {
                securityService.logout(loginObj);
            }
            catch (LoginException ex) {}
        }
    }
    
    public boolean supports(final Class<? extends WorkContext> clazz) {
        return SecurityContext.class.isAssignableFrom(clazz);
    }
    
    public boolean required() {
        return false;
    }
}
