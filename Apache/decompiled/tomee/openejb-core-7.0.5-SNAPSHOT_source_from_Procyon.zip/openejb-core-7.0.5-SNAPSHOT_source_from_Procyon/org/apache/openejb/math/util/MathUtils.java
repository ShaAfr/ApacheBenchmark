// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.util;

import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.Arrays;
import org.apache.openejb.math.MathRuntimeException;

public final class MathUtils
{
    public static final double EPSILON = 1.1102230246251565E-16;
    public static final double SAFE_MIN = Double.MIN_NORMAL;
    public static final double TWO_PI = 6.283185307179586;
    private static final byte NB = -1;
    private static final short NS = -1;
    private static final byte PB = 1;
    private static final short PS = 1;
    private static final byte ZB = 0;
    private static final short ZS = 0;
    private static final int NAN_GAP = 4194304;
    private static final long SGN_MASK = Long.MIN_VALUE;
    private static final long[] FACTORIALS;
    
    private MathUtils() {
    }
    
    public static int addAndCheck(final int x, final int y) {
        final long s = x + (long)y;
        if (s < -2147483648L || s > 2147483647L) {
            throw new ArithmeticException("overflow: add");
        }
        return (int)s;
    }
    
    public static long addAndCheck(final long a, final long b) {
        return addAndCheck(a, b, "overflow: add");
    }
    
    private static long addAndCheck(final long a, final long b, final String msg) {
        long ret;
        if (a > b) {
            ret = addAndCheck(b, a, msg);
        }
        else if (a < 0L) {
            if (b < 0L) {
                if (Long.MIN_VALUE - b > a) {
                    throw new ArithmeticException(msg);
                }
                ret = a + b;
            }
            else {
                ret = a + b;
            }
        }
        else {
            if (a > Long.MAX_VALUE - b) {
                throw new ArithmeticException(msg);
            }
            ret = a + b;
        }
        return ret;
    }
    
    public static long binomialCoefficient(final int n, final int k) {
        checkBinomial(n, k);
        if (n == k || k == 0) {
            return 1L;
        }
        if (k == 1 || k == n - 1) {
            return n;
        }
        if (k > n / 2) {
            return binomialCoefficient(n, n - k);
        }
        long result = 1L;
        if (n <= 61) {
            int i = n - k + 1;
            for (int j = 1; j <= k; ++j) {
                result = result * i / j;
                ++i;
            }
        }
        else if (n <= 66) {
            int i = n - k + 1;
            for (int j = 1; j <= k; ++j) {
                final long d = gcd(i, j);
                result = result / (j / d) * i / d;
                ++i;
            }
        }
        else {
            int i = n - k + 1;
            for (int j = 1; j <= k; ++j) {
                final long d = gcd(i, j);
                result = mulAndCheck(result / (j / d), i / d);
                ++i;
            }
        }
        return result;
    }
    
    public static double binomialCoefficientDouble(final int n, final int k) {
        checkBinomial(n, k);
        if (n == k || k == 0) {
            return 1.0;
        }
        if (k == 1 || k == n - 1) {
            return n;
        }
        if (k > n / 2) {
            return binomialCoefficientDouble(n, n - k);
        }
        if (n < 67) {
            return (double)binomialCoefficient(n, k);
        }
        double result = 1.0;
        for (int i = 1; i <= k; ++i) {
            result *= (n - k + i) / (double)i;
        }
        return Math.floor(result + 0.5);
    }
    
    public static double binomialCoefficientLog(final int n, final int k) {
        checkBinomial(n, k);
        if (n == k || k == 0) {
            return 0.0;
        }
        if (k == 1 || k == n - 1) {
            return Math.log(n);
        }
        if (n < 67) {
            return Math.log((double)binomialCoefficient(n, k));
        }
        if (n < 1030) {
            return Math.log(binomialCoefficientDouble(n, k));
        }
        if (k > n / 2) {
            return binomialCoefficientLog(n, n - k);
        }
        double logSum = 0.0;
        for (int i = n - k + 1; i <= n; ++i) {
            logSum += Math.log(i);
        }
        for (int i = 2; i <= k; ++i) {
            logSum -= Math.log(i);
        }
        return logSum;
    }
    
    private static void checkBinomial(final int n, final int k) throws IllegalArgumentException {
        if (n < k) {
            throw MathRuntimeException.createIllegalArgumentException("must have n >= k for binomial coefficient (n,k), got n = {0}, k = {1}", n, k);
        }
        if (n < 0) {
            throw MathRuntimeException.createIllegalArgumentException("must have n >= 0 for binomial coefficient (n,k), got n = {0}", n);
        }
    }
    
    public static int compareTo(final double x, final double y, final double eps) {
        if (equals(x, y, eps)) {
            return 0;
        }
        if (x < y) {
            return -1;
        }
        return 1;
    }
    
    public static double cosh(final double x) {
        return (Math.exp(x) + Math.exp(-x)) / 2.0;
    }
    
    public static boolean equals(final double x, final double y) {
        return (Double.isNaN(x) && Double.isNaN(y)) || x == y;
    }
    
    public static boolean equals(final double x, final double y, final double eps) {
        return equals(x, y) || Math.abs(y - x) <= eps;
    }
    
    public static boolean equals(final double x, final double y, final int maxUlps) {
        assert maxUlps > 0 && maxUlps < 4194304;
        long xInt = Double.doubleToLongBits(x);
        long yInt = Double.doubleToLongBits(y);
        if (xInt < 0L) {
            xInt = Long.MIN_VALUE - xInt;
        }
        if (yInt < 0L) {
            yInt = Long.MIN_VALUE - yInt;
        }
        return Math.abs(xInt - yInt) <= maxUlps;
    }
    
    public static boolean equals(final double[] x, final double[] y) {
        if (x == null || y == null) {
            return !(x == null ^ y == null);
        }
        if (x.length != y.length) {
            return false;
        }
        for (int i = 0; i < x.length; ++i) {
            if (!equals(x[i], y[i])) {
                return false;
            }
        }
        return true;
    }
    
    public static long factorial(final int n) {
        if (n < 0) {
            throw MathRuntimeException.createIllegalArgumentException("must have n >= 0 for n!, got n = {0}", n);
        }
        if (n > 20) {
            throw new ArithmeticException("factorial value is too large to fit in a long");
        }
        return MathUtils.FACTORIALS[n];
    }
    
    public static double factorialDouble(final int n) {
        if (n < 0) {
            throw MathRuntimeException.createIllegalArgumentException("must have n >= 0 for n!, got n = {0}", n);
        }
        if (n < 21) {
            return (double)factorial(n);
        }
        return Math.floor(Math.exp(factorialLog(n)) + 0.5);
    }
    
    public static double factorialLog(final int n) {
        if (n < 0) {
            throw MathRuntimeException.createIllegalArgumentException("must have n >= 0 for n!, got n = {0}", n);
        }
        if (n < 21) {
            return Math.log((double)factorial(n));
        }
        double logSum = 0.0;
        for (int i = 2; i <= n; ++i) {
            logSum += Math.log(i);
        }
        return logSum;
    }
    
    public static int gcd(final int p, final int q) {
        int u = p;
        int v = q;
        if (u == 0 || v == 0) {
            if (u == Integer.MIN_VALUE || v == Integer.MIN_VALUE) {
                throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^31", p, q);
            }
            return Math.abs(u) + Math.abs(v);
        }
        else {
            if (u > 0) {
                u = -u;
            }
            if (v > 0) {
                v = -v;
            }
            int k;
            for (k = 0; (u & 0x1) == 0x0 && (v & 0x1) == 0x0 && k < 31; u /= 2, v /= 2, ++k) {}
            if (k == 31) {
                throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^31", p, q);
            }
            int t = ((u & 0x1) == 0x1) ? v : (-(u / 2));
            while (true) {
                if ((t & 0x1) == 0x0) {
                    t /= 2;
                }
                else {
                    if (t > 0) {
                        u = -t;
                    }
                    else {
                        v = t;
                    }
                    t = (v - u) / 2;
                    if (t == 0) {
                        break;
                    }
                    continue;
                }
            }
            return -u * (1 << k);
        }
    }
    
    public static long gcd(final long p, final long q) {
        long u = p;
        long v = q;
        if (u == 0L || v == 0L) {
            if (u == Long.MIN_VALUE || v == Long.MIN_VALUE) {
                throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^63", p, q);
            }
            return Math.abs(u) + Math.abs(v);
        }
        else {
            if (u > 0L) {
                u = -u;
            }
            if (v > 0L) {
                v = -v;
            }
            int k;
            for (k = 0; (u & 0x1L) == 0x0L && (v & 0x1L) == 0x0L && k < 63; u /= 2L, v /= 2L, ++k) {}
            if (k == 63) {
                throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^63", p, q);
            }
            long t = ((u & 0x1L) == 0x1L) ? v : (-(u / 2L));
            while (true) {
                if ((t & 0x1L) == 0x0L) {
                    t /= 2L;
                }
                else {
                    if (t > 0L) {
                        u = -t;
                    }
                    else {
                        v = t;
                    }
                    t = (v - u) / 2L;
                    if (t == 0L) {
                        break;
                    }
                    continue;
                }
            }
            return -u * (1L << k);
        }
    }
    
    public static int hash(final double value) {
        return new Double(value).hashCode();
    }
    
    public static int hash(final double[] value) {
        return Arrays.hashCode(value);
    }
    
    public static byte indicator(final byte x) {
        return (byte)((x >= 0) ? 1 : -1);
    }
    
    public static double indicator(final double x) {
        if (Double.isNaN(x)) {
            return Double.NaN;
        }
        return (x >= 0.0) ? 1.0 : -1.0;
    }
    
    public static float indicator(final float x) {
        if (Float.isNaN(x)) {
            return Float.NaN;
        }
        return (x >= 0.0f) ? 1.0f : -1.0f;
    }
    
    public static int indicator(final int x) {
        return (x >= 0) ? 1 : -1;
    }
    
    public static long indicator(final long x) {
        return (x >= 0L) ? 1L : -1L;
    }
    
    public static short indicator(final short x) {
        return (short)((x >= 0) ? 1 : -1);
    }
    
    public static int lcm(final int a, final int b) {
        if (a == 0 || b == 0) {
            return 0;
        }
        final int lcm = Math.abs(mulAndCheck(a / gcd(a, b), b));
        if (lcm == Integer.MIN_VALUE) {
            throw MathRuntimeException.createArithmeticException("overflow: lcm({0}, {1}) is 2^31", a, b);
        }
        return lcm;
    }
    
    public static long lcm(final long a, final long b) {
        if (a == 0L || b == 0L) {
            return 0L;
        }
        final long lcm = Math.abs(mulAndCheck(a / gcd(a, b), b));
        if (lcm == Long.MIN_VALUE) {
            throw MathRuntimeException.createArithmeticException("overflow: lcm({0}, {1}) is 2^63", a, b);
        }
        return lcm;
    }
    
    public static double log(final double base, final double x) {
        return Math.log(x) / Math.log(base);
    }
    
    public static int mulAndCheck(final int x, final int y) {
        final long m = x * (long)y;
        if (m < -2147483648L || m > 2147483647L) {
            throw new ArithmeticException("overflow: mul");
        }
        return (int)m;
    }
    
    public static long mulAndCheck(final long a, final long b) {
        final String msg = "overflow: multiply";
        long ret;
        if (a > b) {
            ret = mulAndCheck(b, a);
        }
        else if (a < 0L) {
            if (b < 0L) {
                if (a < Long.MAX_VALUE / b) {
                    throw new ArithmeticException("overflow: multiply");
                }
                ret = a * b;
            }
            else if (b > 0L) {
                if (Long.MIN_VALUE / b > a) {
                    throw new ArithmeticException("overflow: multiply");
                }
                ret = a * b;
            }
            else {
                ret = 0L;
            }
        }
        else if (a > 0L) {
            if (a > Long.MAX_VALUE / b) {
                throw new ArithmeticException("overflow: multiply");
            }
            ret = a * b;
        }
        else {
            ret = 0L;
        }
        return ret;
    }
    
    public static double nextAfter(final double d, final double direction) {
        if (Double.isNaN(d) || Double.isInfinite(d)) {
            return d;
        }
        if (d == 0.0) {
            return (direction < 0.0) ? -4.9E-324 : Double.MIN_VALUE;
        }
        final long bits = Double.doubleToLongBits(d);
        final long sign = bits & Long.MIN_VALUE;
        final long exponent = bits & 0x7FF0000000000000L;
        final long mantissa = bits & 0xFFFFFFFFFFFFFL;
        if (d * (direction - d) >= 0.0) {
            if (mantissa == 4503599627370495L) {
                return Double.longBitsToDouble(sign | exponent + 4503599627370496L);
            }
            return Double.longBitsToDouble(sign | exponent | mantissa + 1L);
        }
        else {
            if (mantissa == 0L) {
                return Double.longBitsToDouble(sign | exponent - 4503599627370496L | 0xFFFFFFFFFFFFFL);
            }
            return Double.longBitsToDouble(sign | exponent | mantissa - 1L);
        }
    }
    
    public static double scalb(final double d, final int scaleFactor) {
        if (d == 0.0 || Double.isNaN(d) || Double.isInfinite(d)) {
            return d;
        }
        final long bits = Double.doubleToLongBits(d);
        final long exponent = bits & 0x7FF0000000000000L;
        final long rest = bits & 0x800FFFFFFFFFFFFFL;
        final long newBits = rest | exponent + ((long)scaleFactor << 52);
        return Double.longBitsToDouble(newBits);
    }
    
    public static double normalizeAngle(final double a, final double center) {
        return a - 6.283185307179586 * Math.floor((a + 3.141592653589793 - center) / 6.283185307179586);
    }
    
    public static double[] normalizeArray(final double[] values, final double normalizedSum) throws ArithmeticException, IllegalArgumentException {
        if (Double.isInfinite(normalizedSum)) {
            throw MathRuntimeException.createIllegalArgumentException("Cannot normalize to an infinite value", new Object[0]);
        }
        if (Double.isNaN(normalizedSum)) {
            throw MathRuntimeException.createIllegalArgumentException("Cannot normalize to NaN", new Object[0]);
        }
        double sum = 0.0;
        final int len = values.length;
        final double[] out = new double[len];
        for (int i = 0; i < len; ++i) {
            if (Double.isInfinite(values[i])) {
                throw MathRuntimeException.createArithmeticException("Array contains an infinite element, {0} at index {1}", values[i], i);
            }
            if (!Double.isNaN(values[i])) {
                sum += values[i];
            }
        }
        if (sum == 0.0) {
            throw MathRuntimeException.createArithmeticException("Array sums to zero", new Object[0]);
        }
        for (int i = 0; i < len; ++i) {
            if (Double.isNaN(values[i])) {
                out[i] = Double.NaN;
            }
            else {
                out[i] = values[i] * normalizedSum / sum;
            }
        }
        return out;
    }
    
    public static double round(final double x, final int scale) {
        return round(x, scale, 4);
    }
    
    public static double round(final double x, final int scale, final int roundingMethod) {
        try {
            return new BigDecimal(Double.toString(x)).setScale(scale, roundingMethod).doubleValue();
        }
        catch (NumberFormatException ex) {
            if (Double.isInfinite(x)) {
                return x;
            }
            return Double.NaN;
        }
    }
    
    public static float round(final float x, final int scale) {
        return round(x, scale, 4);
    }
    
    public static float round(final float x, final int scale, final int roundingMethod) {
        final float sign = indicator(x);
        final float factor = (float)Math.pow(10.0, scale) * sign;
        return (float)roundUnscaled(x * factor, sign, roundingMethod) / factor;
    }
    
    private static double roundUnscaled(double unscaled, final double sign, final int roundingMethod) {
        switch (roundingMethod) {
            case 2: {
                if (sign == -1.0) {
                    unscaled = Math.floor(nextAfter(unscaled, Double.NEGATIVE_INFINITY));
                    break;
                }
                unscaled = Math.ceil(nextAfter(unscaled, Double.POSITIVE_INFINITY));
                break;
            }
            case 1: {
                unscaled = Math.floor(nextAfter(unscaled, Double.NEGATIVE_INFINITY));
                break;
            }
            case 3: {
                if (sign == -1.0) {
                    unscaled = Math.ceil(nextAfter(unscaled, Double.POSITIVE_INFINITY));
                    break;
                }
                unscaled = Math.floor(nextAfter(unscaled, Double.NEGATIVE_INFINITY));
                break;
            }
            case 5: {
                unscaled = nextAfter(unscaled, Double.NEGATIVE_INFINITY);
                final double fraction = unscaled - Math.floor(unscaled);
                if (fraction > 0.5) {
                    unscaled = Math.ceil(unscaled);
                    break;
                }
                unscaled = Math.floor(unscaled);
                break;
            }
            case 6: {
                final double fraction = unscaled - Math.floor(unscaled);
                if (fraction > 0.5) {
                    unscaled = Math.ceil(unscaled);
                    break;
                }
                if (fraction < 0.5) {
                    unscaled = Math.floor(unscaled);
                    break;
                }
                if (Math.floor(unscaled) / 2.0 == Math.floor(Math.floor(unscaled) / 2.0)) {
                    unscaled = Math.floor(unscaled);
                    break;
                }
                unscaled = Math.ceil(unscaled);
                break;
            }
            case 4: {
                unscaled = nextAfter(unscaled, Double.POSITIVE_INFINITY);
                final double fraction = unscaled - Math.floor(unscaled);
                if (fraction >= 0.5) {
                    unscaled = Math.ceil(unscaled);
                    break;
                }
                unscaled = Math.floor(unscaled);
                break;
            }
            case 7: {
                if (unscaled != Math.floor(unscaled)) {
                    throw new ArithmeticException("Inexact result from rounding");
                }
                break;
            }
            case 0: {
                unscaled = Math.ceil(nextAfter(unscaled, Double.POSITIVE_INFINITY));
                break;
            }
            default: {
                throw MathRuntimeException.createIllegalArgumentException("invalid rounding method {0}, valid methods: {1} ({2}), {3} ({4}), {5} ({6}), {7} ({8}), {9} ({10}), {11} ({12}), {13} ({14}), {15} ({16})", roundingMethod, "ROUND_CEILING", 2, "ROUND_DOWN", 1, "ROUND_FLOOR", 3, "ROUND_HALF_DOWN", 5, "ROUND_HALF_EVEN", 6, "ROUND_HALF_UP", 4, "ROUND_UNNECESSARY", 7, "ROUND_UP", 0);
            }
        }
        return unscaled;
    }
    
    public static byte sign(final byte x) {
        return (byte)((x == 0) ? 0 : ((x > 0) ? 1 : -1));
    }
    
    public static double sign(final double x) {
        if (Double.isNaN(x)) {
            return Double.NaN;
        }
        return (x == 0.0) ? 0.0 : ((x > 0.0) ? 1.0 : -1.0);
    }
    
    public static float sign(final float x) {
        if (Float.isNaN(x)) {
            return Float.NaN;
        }
        return (x == 0.0f) ? 0.0f : ((x > 0.0f) ? 1.0f : -1.0f);
    }
    
    public static int sign(final int x) {
        return (x == 0) ? 0 : ((x > 0) ? 1 : -1);
    }
    
    public static long sign(final long x) {
        return (x == 0L) ? 0L : ((x > 0L) ? 1L : -1L);
    }
    
    public static short sign(final short x) {
        return (short)((x == 0) ? 0 : ((x > 0) ? 1 : -1));
    }
    
    public static double sinh(final double x) {
        return (Math.exp(x) - Math.exp(-x)) / 2.0;
    }
    
    public static int subAndCheck(final int x, final int y) {
        final long s = x - (long)y;
        if (s < -2147483648L || s > 2147483647L) {
            throw new ArithmeticException("overflow: subtract");
        }
        return (int)s;
    }
    
    public static long subAndCheck(final long a, final long b) {
        final String msg = "overflow: subtract";
        long ret;
        if (b == Long.MIN_VALUE) {
            if (a >= 0L) {
                throw new ArithmeticException("overflow: subtract");
            }
            ret = a - b;
        }
        else {
            ret = addAndCheck(a, -b, "overflow: subtract");
        }
        return ret;
    }
    
    public static int pow(final int k, int e) throws IllegalArgumentException {
        if (e < 0) {
            throw MathRuntimeException.createIllegalArgumentException("cannot raise an integral value to a negative power ({0}^{1})", k, e);
        }
        int result = 1;
        int k2p = k;
        while (e != 0) {
            if ((e & 0x1) != 0x0) {
                result *= k2p;
            }
            k2p *= k2p;
            e >>= 1;
        }
        return result;
    }
    
    public static int pow(final int k, long e) throws IllegalArgumentException {
        if (e < 0L) {
            throw MathRuntimeException.createIllegalArgumentException("cannot raise an integral value to a negative power ({0}^{1})", k, e);
        }
        int result = 1;
        int k2p = k;
        while (e != 0L) {
            if ((e & 0x1L) != 0x0L) {
                result *= k2p;
            }
            k2p *= k2p;
            e >>= 1;
        }
        return result;
    }
    
    public static long pow(final long k, int e) throws IllegalArgumentException {
        if (e < 0) {
            throw MathRuntimeException.createIllegalArgumentException("cannot raise an integral value to a negative power ({0}^{1})", k, e);
        }
        long result = 1L;
        long k2p = k;
        while (e != 0) {
            if ((e & 0x1) != 0x0) {
                result *= k2p;
            }
            k2p *= k2p;
            e >>= 1;
        }
        return result;
    }
    
    public static long pow(final long k, long e) throws IllegalArgumentException {
        if (e < 0L) {
            throw MathRuntimeException.createIllegalArgumentException("cannot raise an integral value to a negative power ({0}^{1})", k, e);
        }
        long result = 1L;
        long k2p = k;
        while (e != 0L) {
            if ((e & 0x1L) != 0x0L) {
                result *= k2p;
            }
            k2p *= k2p;
            e >>= 1;
        }
        return result;
    }
    
    public static BigInteger pow(final BigInteger k, final int e) throws IllegalArgumentException {
        if (e < 0) {
            throw MathRuntimeException.createIllegalArgumentException("cannot raise an integral value to a negative power ({0}^{1})", k, e);
        }
        return k.pow(e);
    }
    
    public static BigInteger pow(final BigInteger k, long e) throws IllegalArgumentException {
        if (e < 0L) {
            throw MathRuntimeException.createIllegalArgumentException("cannot raise an integral value to a negative power ({0}^{1})", k, e);
        }
        BigInteger result = BigInteger.ONE;
        BigInteger k2p = k;
        while (e != 0L) {
            if ((e & 0x1L) != 0x0L) {
                result = result.multiply(k2p);
            }
            k2p = k2p.multiply(k2p);
            e >>= 1;
        }
        return result;
    }
    
    public static BigInteger pow(final BigInteger k, BigInteger e) throws IllegalArgumentException {
        if (e.compareTo(BigInteger.ZERO) < 0) {
            throw MathRuntimeException.createIllegalArgumentException("cannot raise an integral value to a negative power ({0}^{1})", k, e);
        }
        BigInteger result = BigInteger.ONE;
        BigInteger k2p = k;
        while (!BigInteger.ZERO.equals(e)) {
            if (e.testBit(0)) {
                result = result.multiply(k2p);
            }
            k2p = k2p.multiply(k2p);
            e = e.shiftRight(1);
        }
        return result;
    }
    
    public static double distance1(final double[] p1, final double[] p2) {
        double sum = 0.0;
        for (int i = 0; i < p1.length; ++i) {
            sum += Math.abs(p1[i] - p2[i]);
        }
        return sum;
    }
    
    public static int distance1(final int[] p1, final int[] p2) {
        int sum = 0;
        for (int i = 0; i < p1.length; ++i) {
            sum += Math.abs(p1[i] - p2[i]);
        }
        return sum;
    }
    
    public static double distance(final double[] p1, final double[] p2) {
        double sum = 0.0;
        for (int i = 0; i < p1.length; ++i) {
            final double dp = p1[i] - p2[i];
            sum += dp * dp;
        }
        return Math.sqrt(sum);
    }
    
    public static double distance(final int[] p1, final int[] p2) {
        double sum = 0.0;
        for (int i = 0; i < p1.length; ++i) {
            final double dp = p1[i] - p2[i];
            sum += dp * dp;
        }
        return Math.sqrt(sum);
    }
    
    public static double distanceInf(final double[] p1, final double[] p2) {
        double max = 0.0;
        for (int i = 0; i < p1.length; ++i) {
            max = Math.max(max, Math.abs(p1[i] - p2[i]));
        }
        return max;
    }
    
    public static int distanceInf(final int[] p1, final int[] p2) {
        int max = 0;
        for (int i = 0; i < p1.length; ++i) {
            max = Math.max(max, Math.abs(p1[i] - p2[i]));
        }
        return max;
    }
    
    public static void checkOrder(final double[] val, final int dir, final boolean strict) {
        double previous = val[0];
        for (int max = val.length, i = 1; i < max; ++i) {
            if (dir > 0) {
                if (strict) {
                    if (val[i] <= previous) {
                        throw MathRuntimeException.createIllegalArgumentException("points {0} and {1} are not strictly increasing ({2} >= {3})", i - 1, i, previous, val[i]);
                    }
                }
                else if (val[i] < previous) {
                    throw MathRuntimeException.createIllegalArgumentException("points {0} and {1} are not increasing ({2} > {3})", i - 1, i, previous, val[i]);
                }
            }
            else if (strict) {
                if (val[i] >= previous) {
                    throw MathRuntimeException.createIllegalArgumentException("points {0} and {1} are not strictly decreasing ({2} <= {3})", i - 1, i, previous, val[i]);
                }
            }
            else if (val[i] > previous) {
                throw MathRuntimeException.createIllegalArgumentException("points {0} and {1} are not decreasing ({2} < {3})", i - 1, i, previous, val[i]);
            }
            previous = val[i];
        }
    }
    
    static {
        FACTORIALS = new long[] { 1L, 1L, 2L, 6L, 24L, 120L, 720L, 5040L, 40320L, 362880L, 3628800L, 39916800L, 479001600L, 6227020800L, 87178291200L, 1307674368000L, 20922789888000L, 355687428096000L, 6402373705728000L, 121645100408832000L, 2432902008176640000L };
    }
}
