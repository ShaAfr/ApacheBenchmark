// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.Strings;
import java.rmi.Remote;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;
import org.apache.openejb.util.Classes;
import java.util.TreeMap;
import java.util.Properties;
import org.apache.openejb.util.StringTemplate;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.spi.ContainerSystem;
import org.apache.openejb.AppContext;
import org.apache.openejb.ModuleContext;
import javax.naming.NameAlreadyBoundException;
import org.apache.openejb.core.ivm.naming.IntraVmJndiReference;
import javax.jms.MessageListener;
import org.apache.openejb.core.ivm.naming.ObjectReference;
import org.apache.openejb.core.ivm.naming.BusinessRemoteReference;
import org.apache.openejb.core.ivm.naming.BusinessLocalReference;
import javax.naming.NamingException;
import org.apache.openejb.OpenEJBRuntimeException;
import javax.naming.Reference;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.core.ivm.naming.BusinessLocalBeanReference;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.Map;
import org.apache.openejb.BeanContext;
import java.util.HashMap;
import org.apache.openejb.loader.Options;
import javax.ejb.embeddable.EJBContainer;
import org.apache.openejb.loader.SystemInstance;
import javax.naming.Context;
import org.apache.openejb.util.Logger;

public class JndiBuilder
{
    public static final String DEFAULT_NAME_KEY = "default";
    final boolean embeddedEjbContainerApi;
    public static final Logger logger;
    private static final boolean USE_OLD_JNDI_NAMES;
    private final Context openejbContext;
    private static final String JNDINAME_STRATEGY_CLASS = "openejb.jndiname.strategy.class";
    private static final String JNDINAME_FAILONCOLLISION = "openejb.jndiname.failoncollision";
    private final boolean failOnCollision;
    
    public JndiBuilder(final Context openejbContext) {
        this.openejbContext = openejbContext;
        final Options options = SystemInstance.get().getOptions();
        this.failOnCollision = options.get("openejb.jndiname.failoncollision", true);
        this.embeddedEjbContainerApi = options.get(EJBContainer.class.getName(), false);
    }
    
    public void build(final EjbJarInfo ejbJar, final HashMap<String, BeanContext> deployments) {
        final JndiNameStrategy strategy = createStrategy(ejbJar, deployments);
        for (final EnterpriseBeanInfo beanInfo : ejbJar.enterpriseBeans) {
            final BeanContext beanContext = deployments.get(beanInfo.ejbDeploymentId);
            strategy.begin(beanContext);
            try {
                this.bind(ejbJar, beanContext, beanInfo, strategy);
            }
            finally {
                strategy.end();
            }
        }
    }
    
    public static JndiNameStrategy createStrategy(final EjbJarInfo ejbJar, final Map<String, BeanContext> deployments) {
        final Options options = new Options(ejbJar.properties, SystemInstance.get().getOptions());
        final Class strategyClass = options.get("openejb.jndiname.strategy.class", (Class)TemplatedStrategy.class);
        final String strategyClassName = strategyClass.getName();
        try {
            try {
                final Constructor constructor = strategyClass.getConstructor(EjbJarInfo.class, Map.class);
                return constructor.newInstance(ejbJar, deployments);
            }
            catch (NoSuchMethodException ex) {
                final Constructor constructor = strategyClass.getConstructor((Class[])new Class[0]);
                return constructor.newInstance(new Object[0]);
            }
        }
        catch (InstantiationException e) {
            throw new IllegalStateException("Could not instantiate JndiNameStrategy: " + strategyClassName, e);
        }
        catch (IllegalAccessException e2) {
            throw new IllegalStateException("Could not access JndiNameStrategy: " + strategyClassName, e2);
        }
        catch (Throwable t) {
            throw new IllegalStateException("Could not create JndiNameStrategy: " + strategyClassName, t);
        }
    }
    
    public void bind(final EjbJarInfo ejbJarInfo, final BeanContext bean, final EnterpriseBeanInfo beanInfo, final JndiNameStrategy strategy) {
        if (BeanContext.Comp.class.equals(bean.getBeanClass())) {
            return;
        }
        final Bindings bindings = new Bindings();
        bean.set(Bindings.class, bindings);
        Reference simpleNameRef = null;
        final Object id = bean.getDeploymentID();
        try {
            if (bean.isLocalbean()) {
                final Class beanClass = bean.getBeanClass();
                final BeanContext.BusinessLocalBeanHome home = bean.getBusinessLocalBeanHome();
                final BusinessLocalBeanReference ref = new BusinessLocalBeanReference(home);
                this.optionalBind(bindings, (Reference)ref, "openejb/Deployment/" + format(id, beanClass.getName(), InterfaceType.LOCALBEAN));
                if (!bean.getBeanClass().isInterface()) {
                    for (Class<?> clazz = (Class<?>)bean.getBeanClass().getSuperclass(); !clazz.equals(Object.class); clazz = clazz.getSuperclass()) {
                        this.optionalBind(bindings, (Reference)ref, "openejb/Deployment/" + format(id, clazz.getName(), InterfaceType.LOCALBEAN));
                    }
                }
                final String internalName = "openejb/Deployment/" + format(id, beanClass.getName(), InterfaceType.BUSINESS_LOCALBEAN_HOME);
                this.bind(internalName, (Reference)ref, bindings, beanInfo, beanClass);
                final String name = strategy.getName(beanClass, "default", JndiNameStrategy.Interface.LOCALBEAN);
                this.bind("openejb/local/" + name, (Reference)ref, bindings, beanInfo, beanClass);
                this.bindJava(bean, beanClass, (Reference)ref, bindings, beanInfo);
                if (JndiBuilder.USE_OLD_JNDI_NAMES) {
                    bean.getModuleContext().getAppContext().getBindings().put(name, ref);
                }
                simpleNameRef = (Reference)ref;
            }
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("Unable to bind business remote deployment in jndi.", e);
        }
        try {
            for (final Class interfce : bean.getBusinessLocalInterfaces()) {
                final BeanContext.BusinessLocalHome home2 = bean.getBusinessLocalHome(interfce);
                final BusinessLocalReference ref2 = new BusinessLocalReference(home2);
                this.optionalBind(bindings, (Reference)ref2, "openejb/Deployment/" + format(id, interfce.getName()));
                final String internalName2 = "openejb/Deployment/" + format(id, interfce.getName(), InterfaceType.BUSINESS_LOCAL);
                this.bind(internalName2, (Reference)ref2, bindings, beanInfo, interfce);
                final String name2 = strategy.getName(interfce, "default", JndiNameStrategy.Interface.BUSINESS_LOCAL);
                final String externalName = "openejb/local/" + name2;
                this.bind(externalName, (Reference)ref2, bindings, beanInfo, interfce);
                this.bindJava(bean, interfce, (Reference)ref2, bindings, beanInfo);
                if (JndiBuilder.USE_OLD_JNDI_NAMES) {
                    bean.getModuleContext().getAppContext().getBindings().put(name2, ref2);
                }
                if (simpleNameRef == null) {
                    simpleNameRef = (Reference)ref2;
                }
            }
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("Unable to bind business local interface for deployment " + id, e);
        }
        try {
            for (final Class interfce : bean.getBusinessRemoteInterfaces()) {
                final BeanContext.BusinessRemoteHome home3 = bean.getBusinessRemoteHome(interfce);
                final BusinessRemoteReference ref3 = new BusinessRemoteReference(home3);
                this.optionalBind(bindings, (Reference)ref3, "openejb/Deployment/" + format(id, interfce.getName(), null));
                final String internalName2 = "openejb/Deployment/" + format(id, interfce.getName(), InterfaceType.BUSINESS_REMOTE);
                this.bind(internalName2, (Reference)ref3, bindings, beanInfo, interfce);
                final String name2 = strategy.getName(interfce, "default", JndiNameStrategy.Interface.BUSINESS_REMOTE);
                this.bind("openejb/local/" + name2, (Reference)ref3, bindings, beanInfo, interfce);
                this.bind("openejb/remote/" + name2, (Reference)ref3, bindings, beanInfo, interfce);
                this.bind("openejb/remote/" + this.computeGlobalName(bean, interfce), (Reference)ref3, bindings, beanInfo, interfce);
                this.bindJava(bean, interfce, (Reference)ref3, bindings, beanInfo);
                if (JndiBuilder.USE_OLD_JNDI_NAMES) {
                    bean.getModuleContext().getAppContext().getBindings().put(name2, ref3);
                }
                if (simpleNameRef == null) {
                    simpleNameRef = (Reference)ref3;
                }
            }
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("Unable to bind business remote deployment in jndi.", e);
        }
        try {
            final Class localHomeInterface = bean.getLocalHomeInterface();
            if (localHomeInterface != null) {
                final ObjectReference ref4 = new ObjectReference(bean.getEJBLocalHome());
                String name3 = strategy.getName(bean.getLocalHomeInterface(), "default", JndiNameStrategy.Interface.LOCAL_HOME);
                this.bind("openejb/local/" + name3, (Reference)ref4, bindings, beanInfo, localHomeInterface);
                this.optionalBind(bindings, (Reference)ref4, "openejb/Deployment/" + format(id, localHomeInterface.getName(), InterfaceType.EJB_LOCAL_HOME));
                name3 = "openejb/Deployment/" + format(id, bean.getLocalInterface().getName());
                this.bind(name3, (Reference)ref4, bindings, beanInfo, localHomeInterface);
                name3 = "openejb/Deployment/" + format(id, bean.getLocalInterface().getName(), InterfaceType.EJB_LOCAL);
                this.bind(name3, (Reference)ref4, bindings, beanInfo, localHomeInterface);
                this.bindJava(bean, localHomeInterface, (Reference)ref4, bindings, beanInfo);
                if (simpleNameRef == null) {
                    simpleNameRef = (Reference)ref4;
                }
            }
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("Unable to bind local home interface for deployment " + id, e);
        }
        try {
            final Class homeInterface = bean.getHomeInterface();
            if (homeInterface != null) {
                final ObjectReference ref4 = new ObjectReference(bean.getEJBHome());
                String name3 = strategy.getName(homeInterface, "default", JndiNameStrategy.Interface.REMOTE_HOME);
                this.bind("openejb/local/" + name3, (Reference)ref4, bindings, beanInfo, homeInterface);
                this.bind("openejb/remote/" + name3, (Reference)ref4, bindings, beanInfo, homeInterface);
                this.optionalBind(bindings, (Reference)ref4, "openejb/Deployment/" + format(id, homeInterface.getName(), InterfaceType.EJB_HOME));
                name3 = "openejb/Deployment/" + format(id, bean.getRemoteInterface().getName());
                this.bind(name3, (Reference)ref4, bindings, beanInfo, homeInterface);
                name3 = "openejb/Deployment/" + format(id, bean.getRemoteInterface().getName(), InterfaceType.EJB_OBJECT);
                this.bind(name3, (Reference)ref4, bindings, beanInfo, homeInterface);
                this.bindJava(bean, homeInterface, (Reference)ref4, bindings, beanInfo);
                if (simpleNameRef == null) {
                    simpleNameRef = (Reference)ref4;
                }
            }
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("Unable to bind remote home interface for deployment " + id, e);
        }
        try {
            if (simpleNameRef != null) {
                this.bindJava(bean, null, simpleNameRef, bindings, beanInfo);
            }
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("Unable to bind simple java:global name in jndi", e);
        }
        try {
            if (MessageListener.class.equals(bean.getMdbInterface())) {
                final String destinationId = bean.getDestinationId();
                final String jndiName = "openejb/Resource/" + destinationId;
                final Reference reference = (Reference)new IntraVmJndiReference(jndiName);
                final String deploymentId = id.toString();
                this.bind("openejb/local/" + deploymentId, reference, bindings, beanInfo, MessageListener.class);
                this.bind("openejb/remote/" + deploymentId, reference, bindings, beanInfo, MessageListener.class);
            }
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("Unable to bind mdb destination in jndi.", e);
        }
        catch (NoClassDefFoundError noClassDefFoundError) {}
    }
    
    private void optionalBind(final Bindings bindings, final Reference ref, final String name) throws NamingException {
        try {
            this.openejbContext.bind(name, ref);
            JndiBuilder.logger.debug("bound ejb at name: " + name + ", ref: " + ref);
            bindings.add(name);
        }
        catch (NamingException okIfBindFails) {
            JndiBuilder.logger.debug("failed to bind ejb at name: " + name + ", ref: " + ref);
        }
    }
    
    public static String format(final Object deploymentId, final String interfaceClassName) {
        return format((String)deploymentId, interfaceClassName, null);
    }
    
    public static String format(final Object deploymentId, final String interfaceClassName, final InterfaceType interfaceType) {
        return format((String)deploymentId, interfaceClassName, interfaceType);
    }
    
    public static String format(final String deploymentId, final String interfaceClassName, final InterfaceType interfaceType) {
        return deploymentId + "/" + interfaceClassName + ((interfaceType == null) ? "" : ("!" + interfaceType.getSpecName()));
    }
    
    private void bind(final String name, final Reference ref, final Bindings bindings, final EnterpriseBeanInfo beanInfo, final Class intrface) throws NamingException {
        if (name.startsWith("openejb/local/") || name.startsWith("openejb/remote/") || name.startsWith("openejb/localbean/") || name.startsWith("openejb/global/")) {
            final String externalName = name.replaceFirst("openejb/[^/]+/", "");
            if (bindings.contains(name)) {
                if (name.startsWith("openejb/local/")) {
                    JndiBuilder.logger.debug("Duplicate: Jndi(name=" + externalName + ")");
                }
                return;
            }
            try {
                this.openejbContext.bind(name, ref);
                bindings.add(name);
                if (!beanInfo.jndiNames.contains(externalName)) {
                    beanInfo.jndiNames.add(externalName);
                    final JndiNameInfo nameInfo = new JndiNameInfo();
                    nameInfo.intrface = ((intrface == null) ? null : intrface.getName());
                    nameInfo.name = externalName;
                    beanInfo.jndiNamess.add(nameInfo);
                    if (!this.embeddedEjbContainerApi && (!(beanInfo instanceof ManagedBeanInfo) || !((ManagedBeanInfo)beanInfo).hidden)) {
                        JndiBuilder.logger.info("Jndi(name=" + externalName + ") --> Ejb(deployment-id=" + beanInfo.ejbDeploymentId + ")");
                    }
                }
            }
            catch (NameAlreadyBoundException e) {
                final BeanContext deployment = this.findNameOwner(name);
                if (deployment != null) {
                    JndiBuilder.logger.error("Jndi(name=" + externalName + ") cannot be bound to Ejb(deployment-id=" + beanInfo.ejbDeploymentId + ").  Name already taken by Ejb(deployment-id=" + deployment.getDeploymentID() + ")");
                }
                else {
                    JndiBuilder.logger.error("Jndi(name=" + externalName + ") cannot be bound to Ejb(deployment-id=" + beanInfo.ejbDeploymentId + ").  Name already taken by another object in the system.");
                }
                if (this.failOnCollision) {
                    throw new NameAlreadyBoundException(externalName);
                }
            }
        }
        else {
            try {
                this.openejbContext.bind(name, ref);
                JndiBuilder.logger.debug("bound ejb at name: " + name + ", ref: " + ref);
                bindings.add(name);
            }
            catch (NameAlreadyBoundException e2) {
                JndiBuilder.logger.error("Jndi name could not be bound; it may be taken by another ejb.  Jndi(name=" + name + ")");
                throw new NameAlreadyBoundException(name);
            }
        }
    }
    
    private String computeGlobalName(final BeanContext cdi, final Class<?> intrface) {
        final ModuleContext module = cdi.getModuleContext();
        final AppContext application = module.getAppContext();
        final String appName = application.isStandaloneModule() ? "" : (application.getId() + "/");
        final String moduleName = this.moduleName(cdi);
        String beanName = cdi.getEjbName();
        if (intrface != null) {
            beanName = beanName + "!" + intrface.getName();
        }
        return "global/" + appName + moduleName + beanName;
    }
    
    private String moduleName(final BeanContext cdi) {
        String moduleName = cdi.getModuleName() + "/";
        if (moduleName.startsWith("ear-scoped-cdi-beans_")) {
            moduleName = moduleName.substring("ear-scoped-cdi-beans_".length());
        }
        return moduleName;
    }
    
    private void bindJava(final BeanContext cdi, final Class intrface, final Reference ref, final Bindings bindings, final EnterpriseBeanInfo beanInfo) throws NamingException {
        final ModuleContext module = cdi.getModuleContext();
        final AppContext application = module.getAppContext();
        final Context moduleContext = module.getModuleJndiContext();
        final Context appContext = application.getAppJndiContext();
        final Context globalContext = application.getGlobalJndiContext();
        final String appName = application.isStandaloneModule() ? "" : (application.getId() + "/");
        String moduleName = this.moduleName(cdi);
        if (moduleName.startsWith("/")) {
            moduleName = moduleName.substring(1);
        }
        String beanName = cdi.getEjbName();
        if (intrface != null) {
            beanName = beanName + "!" + intrface.getName();
        }
        final String globalName = "global/" + appName + moduleName + beanName;
        try {
            if (this.embeddedEjbContainerApi && (!(beanInfo instanceof ManagedBeanInfo) || !((ManagedBeanInfo)beanInfo).hidden)) {
                JndiBuilder.logger.info(String.format("Jndi(name=\"java:%s\")", globalName));
            }
            globalContext.bind(globalName, ref);
            application.getBindings().put(globalName, ref);
            this.bind("openejb/global/" + globalName, ref, bindings, beanInfo, intrface);
        }
        catch (NameAlreadyBoundException e) {
            return;
        }
        appContext.bind("app/" + moduleName + beanName, ref);
        application.getBindings().put("app/" + moduleName + beanName, ref);
        final String moduleJndi = "module/" + beanName;
        moduleContext.bind(moduleJndi, ref);
        ContextualEjbLookup contextual = ContextualEjbLookup.class.cast(application.getBindings().get(moduleJndi));
        if (contextual == null) {
            final Map<BeanContext, Object> potentials = new HashMap<BeanContext, Object>();
            contextual = new ContextualEjbLookup(potentials, ref);
            application.getBindings().put(moduleJndi, contextual);
        }
        contextual.potentials.put(cdi, ref);
    }
    
    private BeanContext findNameOwner(final String name) {
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        for (final BeanContext beanContext : containerSystem.deployments()) {
            final Bindings bindings = beanContext.get(Bindings.class);
            if (bindings != null && bindings.getBindings().contains(name)) {
                return beanContext;
            }
        }
        return null;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, JndiBuilder.class.getPackage().getName());
        USE_OLD_JNDI_NAMES = SystemInstance.get().getOptions().get("openejb.use-old-jndi-names", false);
    }
    
    public static class TemplatedStrategy implements JndiNameStrategy
    {
        private static final String JNDINAME_FORMAT = "openejb.jndiname.format";
        private static final String KEYS = "default,local,global,app";
        private final StringTemplate template;
        private final HashMap<String, EnterpriseBeanInfo> beanInfos;
        private BeanContext bean;
        private HashMap<String, Map<String, StringTemplate>> templates;
        private String format;
        private Map<String, String> appContext;
        private HashMap<String, String> beanContext;
        
        public TemplatedStrategy(final EjbJarInfo ejbJarInfo, final Map<String, BeanContext> deployments) {
            final Options options = new Options(ejbJarInfo.properties, SystemInstance.get().getOptions());
            this.format = options.get("openejb.jndiname.format", "{deploymentId}{interfaceType.annotationName}");
            final int index = this.format.indexOf(":");
            if (index > -1) {
                JndiBuilder.logger.error("Illegal openejb.jndiname.format contains a colon ':'.  Everything before the colon will be removed, '" + this.format + "' ");
                this.format = this.format.substring(index + 1);
            }
            this.template = new StringTemplate(this.format);
            this.beanInfos = new HashMap<String, EnterpriseBeanInfo>();
            for (final EnterpriseBeanInfo beanInfo : ejbJarInfo.enterpriseBeans) {
                this.beanInfos.put(beanInfo.ejbDeploymentId, beanInfo);
            }
            final Iterator<BeanContext> it = deployments.values().iterator();
            if (!it.hasNext()) {
                return;
            }
            final ModuleContext moduleContext = it.next().getModuleContext();
            this.putAll(this.appContext = new HashMap<String, String>(), SystemInstance.get().getProperties());
            this.putAll(this.appContext, moduleContext.getAppContext().getProperties());
            this.putAll(this.appContext, moduleContext.getProperties());
            this.appContext.put("appName", moduleContext.getAppContext().getId());
            this.appContext.put("appId", moduleContext.getAppContext().getId());
            this.appContext.put("moduleName", moduleContext.getId());
            this.appContext.put("moduleId", moduleContext.getId());
        }
        
        private void putAll(final Map<String, String> map, final Properties properties) {
            for (final Map.Entry<Object, Object> e : properties.entrySet()) {
                if (!(e.getValue() instanceof String)) {
                    continue;
                }
                if (!(e.getKey() instanceof String)) {
                    continue;
                }
                map.put(e.getKey(), e.getValue());
            }
        }
        
        private Map<String, StringTemplate> addTemplate(final Map<String, StringTemplate> map, final String key, final StringTemplate template) {
            Map<String, StringTemplate> m = map;
            if (m == null) {
                m = new TreeMap<String, StringTemplate>();
            }
            m.put(key, template);
            return m;
        }
        
        @Override
        public void begin(final BeanContext bean) {
            this.bean = bean;
            final EnterpriseBeanInfo beanInfo = this.beanInfos.get(bean.getDeploymentID());
            (this.templates = new HashMap<String, Map<String, StringTemplate>>()).put("", this.addTemplate(null, "default", this.template));
            for (final JndiNameInfo nameInfo : beanInfo.jndiNamess) {
                String intrface = nameInfo.intrface;
                if (intrface == null) {
                    intrface = "";
                }
                this.templates.put(intrface, this.addTemplate(this.templates.get(intrface), getType(nameInfo.name), new StringTemplate(nameInfo.name)));
            }
            beanInfo.jndiNames.clear();
            beanInfo.jndiNamess.clear();
            this.putAll(this.beanContext = new HashMap<String, String>(this.appContext), bean.getProperties());
            this.beanContext.put("ejbType", bean.getComponentType().name());
            this.beanContext.put("ejbClass", bean.getBeanClass().getName());
            this.beanContext.put("ejbClass.simpleName", bean.getBeanClass().getSimpleName());
            this.beanContext.put("ejbClass.packageName", Classes.packageName(bean.getBeanClass()));
            this.beanContext.put("ejbName", bean.getEjbName());
            this.beanContext.put("deploymentId", bean.getDeploymentID().toString());
        }
        
        private static String getType(final String name) {
            int start = 0;
            if (name.charAt(0) == '/') {
                start = 1;
            }
            final int end = name.substring(start).indexOf(47);
            if (end < 0) {
                return "default";
            }
            return name.substring(start, end);
        }
        
        @Override
        public void end() {
        }
        
        @Override
        public String getName(final Class interfce, final String key, final Interface type) {
            Map<String, StringTemplate> template = this.templates.get(interfce.getName());
            if (template == null) {
                template = this.templates.get(type.getAnnotationName());
            }
            if (template == null) {
                template = this.templates.get("");
            }
            final Map<String, String> contextData = new HashMap<String, String>(this.beanContext);
            contextData.put("interfaceType", type.getAnnotationName());
            contextData.put("interfaceType.annotationName", type.getAnnotationName());
            contextData.put("interfaceType.annotationNameLC", type.getAnnotationName().toLowerCase());
            contextData.put("interfaceType.xmlName", type.getXmlName());
            contextData.put("interfaceType.xmlNameCc", type.getXmlNameCc());
            contextData.put("interfaceType.openejbLegacyName", type.getOpenejbLegacy());
            contextData.put("interfaceClass", interfce.getName());
            contextData.put("interfaceClass.simpleName", interfce.getSimpleName());
            contextData.put("interfaceClass.packageName", Classes.packageName(interfce));
            StringTemplate stringTemplate = null;
            if (template.containsKey(key)) {
                stringTemplate = template.get(key);
            }
            else {
                stringTemplate = template.get("default");
            }
            if (stringTemplate == null) {
                stringTemplate = template.values().iterator().next();
            }
            return stringTemplate.apply(contextData);
        }
        
        @Override
        public Map<String, String> getNames(final Class interfce, final Interface type) {
            final Map<String, String> names = new HashMap<String, String>();
            for (final String key : "default,local,global,app".split(",")) {
                names.put(key, this.getName(interfce, key, type));
            }
            return names;
        }
    }
    
    public static class LegacyAddedSuffixStrategy implements JndiNameStrategy
    {
        private BeanContext beanContext;
        
        @Override
        public void begin(final BeanContext beanContext) {
            this.beanContext = beanContext;
        }
        
        @Override
        public void end() {
        }
        
        @Override
        public String getName(final Class interfce, final String key, final Interface type) {
            String id = String.valueOf(this.beanContext.getDeploymentID());
            if (id.charAt(0) == '/') {
                id = id.substring(1);
            }
            switch (type) {
                case REMOTE_HOME: {
                    return id;
                }
                case LOCAL_HOME: {
                    return id + "Local";
                }
                case BUSINESS_LOCAL: {
                    return id + "BusinessLocal";
                }
                case BUSINESS_REMOTE: {
                    return id + "BusinessRemote";
                }
                default: {
                    return id;
                }
            }
        }
        
        @Override
        public Map<String, String> getNames(final Class interfce, final Interface type) {
            final Map<String, String> names = new HashMap<String, String>();
            names.put("", this.getName(interfce, "default", type));
            return names;
        }
    }
    
    protected static final class Bindings
    {
        private final List<String> bindings;
        
        protected Bindings() {
            this.bindings = new ArrayList<String>();
        }
        
        public List<String> getBindings() {
            return this.bindings;
        }
        
        public boolean add(final String o) {
            return this.bindings.add(o);
        }
        
        public boolean contains(final String o) {
            return this.bindings.contains(o);
        }
    }
    
    public static class RemoteInterfaceComparator implements Comparator<Class>
    {
        @Override
        public int compare(final Class a, final Class b) {
            final boolean aIsRmote = Remote.class.isAssignableFrom(a);
            final boolean bIsRmote = Remote.class.isAssignableFrom(b);
            if (aIsRmote == bIsRmote) {
                return 0;
            }
            return aIsRmote ? 1 : -1;
        }
    }
    
    public static class ContextualEjbLookup extends Reference
    {
        private final Map<BeanContext, Object> potentials;
        private final Object defaultValue;
        
        public ContextualEjbLookup(final Map<BeanContext, Object> potentials, final Object defaultValue) {
            this.potentials = potentials;
            this.defaultValue = defaultValue;
        }
        
        @Override
        public Object getObject() throws NamingException {
            if (this.potentials.size() == 1) {
                return this.unwrap(this.defaultValue);
            }
            final ClassLoader loader = Thread.currentThread().getContextClassLoader();
            if (loader != null) {
                for (final Map.Entry<BeanContext, Object> o : this.potentials.entrySet()) {
                    if (loader.equals(o.getKey().getClassLoader())) {
                        return this.unwrap(o.getValue());
                    }
                }
            }
            return this.unwrap(this.defaultValue);
        }
        
        private Object unwrap(final Object value) throws NamingException {
            if (Reference.class.isInstance(value)) {
                return Reference.class.cast(value).getObject();
            }
            return value;
        }
    }
    
    public interface JndiNameStrategy
    {
        void begin(final BeanContext p0);
        
        String getName(final Class p0, final String p1, final Interface p2);
        
        Map<String, String> getNames(final Class p0, final Interface p1);
        
        void end();
        
        public enum Interface
        {
            REMOTE_HOME(InterfaceType.EJB_HOME, "RemoteHome", "home", ""), 
            LOCAL_HOME(InterfaceType.EJB_LOCAL_HOME, "LocalHome", "local-home", "Local"), 
            BUSINESS_LOCAL(InterfaceType.BUSINESS_LOCAL, "Local", "business-local", "BusinessLocal"), 
            LOCALBEAN(InterfaceType.LOCALBEAN, "LocalBean", "localbean", "LocalBean"), 
            BUSINESS_REMOTE(InterfaceType.BUSINESS_REMOTE, "Remote", "business-remote", "BusinessRemote"), 
            SERVICE_ENDPOINT(InterfaceType.SERVICE_ENDPOINT, "Endpoint", "service-endpoint", "ServiceEndpoint");
            
            private final InterfaceType type;
            private final String annotatedName;
            private final String xmlName;
            private final String xmlNameCc;
            private final String openejbLegacy;
            
            private Interface(final InterfaceType type, final String annotatedName, final String xmlName, final String openejbLegacy) {
                this.type = type;
                this.annotatedName = annotatedName;
                this.xmlName = xmlName;
                this.xmlNameCc = Strings.camelCase(xmlName);
                this.openejbLegacy = openejbLegacy;
            }
            
            public InterfaceType getType() {
                return this.type;
            }
            
            public String getAnnotationName() {
                return this.annotatedName;
            }
            
            public String getXmlName() {
                return this.xmlName;
            }
            
            public String getXmlNameCc() {
                return this.xmlNameCc;
            }
            
            public String getOpenejbLegacy() {
                return this.openejbLegacy;
            }
        }
    }
}
