// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

public interface SafePasswordCipher extends PasswordCipher
{
    char[] decryptAsCharArray(final char[] p0);
}
