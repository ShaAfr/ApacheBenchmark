// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import javax.naming.NamingException;
import javax.validation.Validation;
import org.apache.openejb.bval.ValidatorUtil;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.io.Serializable;
import java.lang.reflect.InvocationHandler;

public class LazyValidator implements InvocationHandler, Serializable
{
    private transient ValidatorFactory factory;
    private transient volatile Validator validator;
    
    public LazyValidator(final ValidatorFactory factory) {
        this.factory = factory;
    }
    
    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        this.ensureDelegate();
        try {
            return method.invoke(this.validator, args);
        }
        catch (InvocationTargetException ite) {
            throw ite.getCause();
        }
    }
    
    private void ensureDelegate() {
        if (this.validator == null) {
            synchronized (this) {
                if (this.validator == null && this.validator == null) {
                    this.validator = ((this.factory == null) ? this.findFactory() : this.factory).usingContext().getValidator();
                }
            }
        }
    }
    
    private ValidatorFactory findFactory() {
        try {
            return ValidatorUtil.lookupFactory();
        }
        catch (NamingException ne) {
            return Validation.buildDefaultValidatorFactory();
        }
    }
    
    public Validator getValidator() {
        this.ensureDelegate();
        return this.validator;
    }
}
