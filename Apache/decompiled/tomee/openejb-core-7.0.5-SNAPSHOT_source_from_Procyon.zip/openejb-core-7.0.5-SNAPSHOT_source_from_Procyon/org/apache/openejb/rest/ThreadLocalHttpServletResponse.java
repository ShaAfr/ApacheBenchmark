// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import java.io.PrintWriter;
import javax.servlet.ServletOutputStream;
import java.util.Locale;
import java.io.IOException;
import java.util.Collection;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

public class ThreadLocalHttpServletResponse extends AbstractRestThreadLocalProxy<HttpServletResponse> implements HttpServletResponse
{
    protected ThreadLocalHttpServletResponse() {
        super(HttpServletResponse.class);
    }
    
    public void addCookie(final Cookie cookie) {
        this.get().addCookie(cookie);
    }
    
    public void addDateHeader(final String name, final long date) {
        this.get().addDateHeader(name, date);
    }
    
    public void addHeader(final String name, final String value) {
        this.get().addHeader(name, value);
    }
    
    public void addIntHeader(final String name, final int value) {
        this.get().addIntHeader(name, value);
    }
    
    public boolean containsHeader(final String name) {
        return this.get().containsHeader(name);
    }
    
    public String encodeURL(final String url) {
        return this.get().encodeURL(url);
    }
    
    public String encodeRedirectURL(final String url) {
        return this.get().encodeRedirectURL(url);
    }
    
    public String encodeUrl(final String url) {
        return this.get().encodeUrl(url);
    }
    
    public String encodeRedirectUrl(final String url) {
        return this.get().encodeRedirectUrl(url);
    }
    
    public String getHeader(final String name) {
        return this.get().getHeader(name);
    }
    
    public Collection<String> getHeaderNames() {
        return (Collection<String>)this.get().getHeaderNames();
    }
    
    public Collection<String> getHeaders(final String headerName) {
        return (Collection<String>)this.get().getHeaders(headerName);
    }
    
    public int getStatus() {
        return this.get().getStatus();
    }
    
    public void sendError(final int sc) throws IOException {
        this.get().sendError(sc);
    }
    
    public void sendError(final int sc, final String msg) throws IOException {
        this.get().sendError(sc, msg);
    }
    
    public void sendRedirect(final String location) throws IOException {
        this.get().sendRedirect(location);
    }
    
    public void setDateHeader(final String name, final long date) {
        this.get().setDateHeader(name, date);
    }
    
    public void setHeader(final String name, final String value) {
        this.get().setHeader(name, value);
    }
    
    public void setIntHeader(final String name, final int value) {
        this.get().setIntHeader(name, value);
    }
    
    public void setStatus(final int sc) {
        this.get().setStatus(sc);
    }
    
    public void setStatus(final int sc, final String sm) {
        this.get().setStatus(sc, sm);
    }
    
    public void flushBuffer() throws IOException {
        this.get().flushBuffer();
    }
    
    public int getBufferSize() {
        return this.get().getBufferSize();
    }
    
    public String getCharacterEncoding() {
        return this.get().getCharacterEncoding();
    }
    
    public String getContentType() {
        return this.get().getContentType();
    }
    
    public Locale getLocale() {
        return this.get().getLocale();
    }
    
    public ServletOutputStream getOutputStream() throws IOException {
        return this.get().getOutputStream();
    }
    
    public PrintWriter getWriter() throws IOException {
        return this.get().getWriter();
    }
    
    public boolean isCommitted() {
        return this.get().isCommitted();
    }
    
    public void reset() {
        this.get().reset();
    }
    
    public void resetBuffer() {
        this.get().resetBuffer();
    }
    
    public void setBufferSize(final int size) {
        this.get().setBufferSize(size);
    }
    
    public void setCharacterEncoding(final String charset) {
        this.get().setCharacterEncoding(charset);
    }
    
    public void setContentLength(final int len) {
        this.get().setContentLength(len);
    }
    
    public void setContentLengthLong(final long length) {
        this.get().setContentLengthLong(length);
    }
    
    public void setContentType(final String type) {
        this.get().setContentType(type);
    }
    
    public void setLocale(final Locale loc) {
        this.get().setLocale(loc);
    }
}
