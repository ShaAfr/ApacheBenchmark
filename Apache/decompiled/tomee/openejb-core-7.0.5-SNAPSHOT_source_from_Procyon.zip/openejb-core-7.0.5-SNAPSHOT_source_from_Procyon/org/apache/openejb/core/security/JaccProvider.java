// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security;

import java.security.Policy;
import javax.security.jacc.PolicyConfigurationFactory;
import java.security.Permission;
import java.security.ProtectionDomain;
import java.security.PermissionCollection;
import java.security.CodeSource;
import javax.security.jacc.PolicyConfiguration;
import java.security.PrivilegedActionException;
import javax.security.jacc.PolicyContextException;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;

public abstract class JaccProvider
{
    private static final String FACTORY_NAME;
    private static JaccProvider jaccProvider;
    
    public static JaccProvider get() {
        return JaccProvider.jaccProvider;
    }
    
    public static void set(final JaccProvider provider) {
        JaccProvider.jaccProvider = provider;
    }
    
    public static void install() throws ClassNotFoundException, PolicyContextException {
        if (JaccProvider.jaccProvider != null) {
            return;
        }
        final String[] factoryClassName = { null };
        try {
            JaccProvider.jaccProvider = AccessController.doPrivileged((PrivilegedExceptionAction<JaccProvider>)new PrivilegedExceptionAction() {
                @Override
                public Object run() throws Exception {
                    factoryClassName[0] = System.getProperty(JaccProvider.FACTORY_NAME);
                    if (factoryClassName[0] == null) {
                        throw new ClassNotFoundException("Property " + JaccProvider.FACTORY_NAME + " not set");
                    }
                    final Thread currentThread = Thread.currentThread();
                    final ClassLoader tccl = currentThread.getContextClassLoader();
                    return Class.forName(factoryClassName[0], true, tccl).newInstance();
                }
            });
        }
        catch (PrivilegedActionException pae) {
            if (pae.getException() instanceof ClassNotFoundException) {
                throw (ClassNotFoundException)pae.getException();
            }
            if (pae.getException() instanceof InstantiationException) {
                throw new ClassNotFoundException(factoryClassName[0] + " could not be instantiated");
            }
            if (pae.getException() instanceof IllegalAccessException) {
                throw new ClassNotFoundException("Illegal access to " + factoryClassName);
            }
            throw new PolicyContextException((Throwable)pae.getException());
        }
    }
    
    public abstract PolicyConfiguration getPolicyConfiguration(final String p0, final boolean p1) throws PolicyContextException;
    
    public abstract boolean inService(final String p0) throws PolicyContextException;
    
    public abstract PermissionCollection getPermissions(final CodeSource p0);
    
    public abstract void refresh();
    
    public abstract boolean implies(final ProtectionDomain p0, final Permission p1);
    
    static {
        FACTORY_NAME = JaccProvider.class.getName();
    }
    
    public static class Factory extends PolicyConfigurationFactory
    {
        public Factory() throws PolicyContextException, ClassNotFoundException {
            JaccProvider.install();
        }
        
        public PolicyConfiguration getPolicyConfiguration(final String contextID, final boolean remove) throws PolicyContextException {
            return JaccProvider.get().getPolicyConfiguration(contextID, remove);
        }
        
        public boolean inService(final String contextID) throws PolicyContextException {
            return JaccProvider.get().inService(contextID);
        }
    }
    
    public static class Policy extends java.security.Policy
    {
        public Policy() throws PolicyContextException, ClassNotFoundException {
            JaccProvider.install();
        }
        
        @Override
        public PermissionCollection getPermissions(final CodeSource codesource) {
            return JaccProvider.get().getPermissions(codesource);
        }
        
        @Override
        public void refresh() {
            JaccProvider.get().refresh();
        }
        
        @Override
        public boolean implies(final ProtectionDomain domain, final Permission permission) {
            return JaccProvider.get().implies(domain, permission);
        }
    }
}
