// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive.moment;

import org.apache.openejb.math.stat.descriptive.UnivariateStatistic;
import org.apache.openejb.math.MathRuntimeException;
import org.apache.openejb.math.stat.descriptive.summary.SumOfLogs;
import org.apache.openejb.math.stat.descriptive.StorelessUnivariateStatistic;
import java.io.Serializable;
import org.apache.openejb.math.stat.descriptive.AbstractStorelessUnivariateStatistic;

public class GeometricMean extends AbstractStorelessUnivariateStatistic implements Serializable
{
    private static final long serialVersionUID = -1238734905303459453L;
    private StorelessUnivariateStatistic sumOfLogs;
    
    public GeometricMean() {
        this.sumOfLogs = new SumOfLogs();
    }
    
    public GeometricMean(final GeometricMean original) {
        copy(original, this);
    }
    
    public GeometricMean(final SumOfLogs sumOfLogs) {
        this.sumOfLogs = sumOfLogs;
    }
    
    @Override
    public GeometricMean copy() {
        final GeometricMean result = new GeometricMean();
        copy(this, result);
        return result;
    }
    
    @Override
    public void increment(final double d) {
        this.sumOfLogs.increment(d);
    }
    
    @Override
    public double getResult() {
        if (this.sumOfLogs.getN() > 0L) {
            return Math.exp(this.sumOfLogs.getResult() / this.sumOfLogs.getN());
        }
        return Double.NaN;
    }
    
    @Override
    public void clear() {
        this.sumOfLogs.clear();
    }
    
    @Override
    public double evaluate(final double[] values, final int begin, final int length) {
        return Math.exp(this.sumOfLogs.evaluate(values, begin, length) / length);
    }
    
    @Override
    public long getN() {
        return this.sumOfLogs.getN();
    }
    
    public void setSumLogImpl(final StorelessUnivariateStatistic sumLogImpl) {
        this.checkEmpty();
        this.sumOfLogs = sumLogImpl;
    }
    
    public StorelessUnivariateStatistic getSumLogImpl() {
        return this.sumOfLogs;
    }
    
    public static void copy(final GeometricMean source, final GeometricMean dest) {
        dest.sumOfLogs = source.sumOfLogs.copy();
    }
    
    private void checkEmpty() {
        if (this.getN() > 0L) {
            throw MathRuntimeException.createIllegalStateException("{0} values have been added before statistic is configured", this.getN());
        }
    }
}
