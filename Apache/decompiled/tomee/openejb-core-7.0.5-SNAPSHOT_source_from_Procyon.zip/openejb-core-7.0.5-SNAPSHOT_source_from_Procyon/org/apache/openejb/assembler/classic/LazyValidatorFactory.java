// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.validation.ValidatorFactory;
import java.util.concurrent.locks.ReentrantLock;
import java.io.Serializable;
import java.lang.reflect.InvocationHandler;

public class LazyValidatorFactory implements InvocationHandler, Serializable
{
    private final transient ReentrantLock lock;
    private final transient ClassLoader loader;
    private final ValidationInfo info;
    private volatile ValidatorFactory factory;
    
    public LazyValidatorFactory(final ClassLoader classLoader, final ValidationInfo validationInfo) {
        this.lock = new ReentrantLock();
        this.loader = classLoader;
        this.info = validationInfo;
    }
    
    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        this.ensureDelegate();
        try {
            return method.invoke(this.factory, args);
        }
        catch (InvocationTargetException ite) {
            throw ite.getCause();
        }
    }
    
    private void ensureDelegate() {
        if (this.factory == null) {
            final ReentrantLock l = this.lock;
            l.lock();
            try {
                if (this.factory == null) {
                    this.factory = ValidatorBuilder.buildFactory((this.loader == null) ? Thread.currentThread().getContextClassLoader() : this.loader, (this.info == null) ? new ValidationInfo() : this.info);
                }
            }
            finally {
                l.unlock();
            }
        }
    }
    
    public ValidatorFactory getFactory() {
        this.ensureDelegate();
        return this.factory;
    }
}
