// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import javax.ejb.RemoveException;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import org.apache.openejb.core.ivm.BaseEjbProxyHandler;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.core.ivm.EjbObjectProxyHandler;
import java.util.List;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ivm.EjbHomeProxyHandler;

public class StatefulEjbHomeHandler extends EjbHomeProxyHandler
{
    public StatefulEjbHomeHandler(final BeanContext beanContext, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        super(beanContext, interfaceType, interfaces, mainInterface);
    }
    
    @Override
    public Object createProxy(final Object primaryKey, final Class mainInterface) {
        final Object proxy = super.createProxy(primaryKey, mainInterface);
        EjbObjectProxyHandler handler = null;
        try {
            handler = (EjbObjectProxyHandler)ProxyManager.getInvocationHandler(proxy);
        }
        catch (Exception e) {
            try {
                final Field field = proxy.getClass().getDeclaredField("invocationHandler");
                field.setAccessible(true);
                handler = (EjbObjectProxyHandler)field.get(proxy);
            }
            catch (Exception ex) {}
        }
        this.registerHandler(handler.getRegistryId(), handler);
        return proxy;
    }
    
    @Override
    protected Object findX(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        throw new UnsupportedOperationException("Stateful beans may not have find methods");
    }
    
    @Override
    protected Object removeByPrimaryKey(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        throw new RemoveException("Session objects are private resources and do not have primary keys");
    }
    
    @Override
    protected EjbObjectProxyHandler newEjbObjectHandler(final BeanContext beanContext, final Object pk, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        return new StatefulEjbObjectHandler(this.getBeanContext(), pk, interfaceType, interfaces, mainInterface);
    }
}
