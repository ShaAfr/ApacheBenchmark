// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import org.apache.xbean.asm5.Type;

public class CmrField
{
    private final String name;
    private final CmrStyle cmrStyle;
    private final Type type;
    private final Type proxyType;
    private final String relatedName;
    private final boolean synthetic;
    
    public CmrField(final String fieldName, final String fieldType, final String cmpImplClass, final String local, final String relatedName, final boolean synthetic) {
        this.synthetic = synthetic;
        this.name = fieldName;
        if (fieldType == null) {
            this.cmrStyle = CmrStyle.SINGLE;
        }
        else if ("java.util.Collection".equals(fieldType)) {
            this.cmrStyle = CmrStyle.COLLECTION;
        }
        else {
            if (!"java.util.Set".equals(fieldType)) {
                throw new IllegalArgumentException("Unsupported fieldType " + fieldType);
            }
            this.cmrStyle = CmrStyle.SET;
        }
        this.type = Type.getType("L" + cmpImplClass.replace('.', '/') + ";");
        if (local != null) {
            this.proxyType = Type.getType("L" + local.replace('.', '/') + ";");
        }
        else {
            this.proxyType = null;
        }
        this.relatedName = relatedName;
    }
    
    public String getName() {
        return this.name;
    }
    
    public boolean isSynthetic() {
        return this.synthetic;
    }
    
    public CmrStyle getCmrStyle() {
        return this.cmrStyle;
    }
    
    public Type getType() {
        return this.type;
    }
    
    public Type getProxyType() {
        return this.proxyType;
    }
    
    public Type getInitialValueType() {
        return this.cmrStyle.getIntiCollectionType();
    }
    
    public String getRelatedName() {
        return this.relatedName;
    }
    
    public String getDescriptor() {
        final Type collectionType = this.cmrStyle.getCollectionType();
        if (collectionType == null) {
            return this.type.getDescriptor();
        }
        return collectionType.getDescriptor();
    }
    
    public String getGenericSignature() {
        final Type collectionType = this.cmrStyle.getCollectionType();
        if (collectionType == null) {
            return null;
        }
        return createSignature(collectionType, this.type);
    }
    
    public String getProxyDescriptor() {
        final Type collectionType = this.cmrStyle.getCollectionType();
        if (collectionType == null) {
            return this.proxyType.getDescriptor();
        }
        return collectionType.getDescriptor();
    }
    
    public String getAccessorInternalName() {
        return this.cmrStyle.getAccessorType().getInternalName();
    }
    
    public String getAccessorDescriptor() {
        return this.cmrStyle.getAccessorType().getDescriptor();
    }
    
    public String getAccessorGenericSignature() {
        final Type collectionType = this.cmrStyle.getCollectionType();
        if (collectionType == null) {
            return null;
        }
        return createSignature(this.cmrStyle.getAccessorType(), this.type, this.proxyType);
    }
    
    private static String createSignature(final Type type, final Type... genericTypes) {
        final StringBuilder builder = new StringBuilder();
        builder.append("L").append(type.getInternalName());
        if (genericTypes.length > 0) {
            builder.append("<");
            for (final Type genericType : genericTypes) {
                builder.append(genericType.getDescriptor());
            }
            builder.append(">");
        }
        builder.append(";");
        return builder.toString();
    }
}
