// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.io.Serializable;
import org.apache.openejb.core.transaction.TransactionPolicy.TransactionSynchronization;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.util.LogCategory;
import javax.persistence.EntityManager;
import javax.persistence.SynchronizationType;
import java.util.Collection;
import org.apache.openejb.core.ExceptionType;
import javax.ejb.EJBAccessException;
import org.apache.openejb.core.transaction.JtaTransactionPolicy;
import javax.transaction.Transaction;
import java.rmi.RemoteException;
import javax.ejb.ConcurrentAccessTimeoutException;
import java.rmi.NoSuchObjectException;
import org.apache.openejb.SystemException;
import org.apache.openejb.cdi.CurrentCreationalContext;
import org.apache.openejb.InvalidateReferenceException;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.core.transaction.BeanTransactionPolicy;
import org.apache.openejb.ApplicationException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.enterprise.context.Dependent;
import org.apache.openejb.cdi.CdiEjbBean;
import java.rmi.dgc.VMID;
import org.apache.openejb.core.InstanceContext;
import org.apache.openejb.core.transaction.TransactionPolicy;
import javax.security.auth.login.LoginException;
import org.apache.openejb.core.interceptor.InterceptorStack;
import org.apache.openejb.core.interceptor.InterceptorData;
import java.util.ArrayList;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import org.apache.openejb.core.BaseContext;
import org.apache.openejb.core.Operation;
import org.apache.openejb.persistence.EntityManagerAlreadyRegisteredException;
import javax.ejb.EJBException;
import org.apache.openejb.core.security.AbstractSecurityService;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.ProxyInfo;
import javax.persistence.EntityManagerFactory;
import org.apache.openejb.InterfaceType;
import javax.naming.Context;
import javax.ejb.EJBContext;
import javax.naming.NamingException;
import org.apache.openejb.monitoring.ManagedMBean;
import org.apache.openejb.monitoring.ObjectNameBuilder;
import org.apache.openejb.monitoring.StatsInterceptor;
import org.apache.openejb.util.Index;
import javax.management.MBeanServer;
import org.apache.openejb.Container;
import javax.management.ObjectName;
import org.apache.openejb.monitoring.LocalMBeanServer;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.ContainerType;
import java.util.Iterator;
import java.util.List;
import java.lang.reflect.Method;
import javax.transaction.UserTransaction;
import org.apache.openejb.core.transaction.EjbUserTransaction;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;
import org.apache.openejb.loader.SystemInstance;
import java.util.concurrent.TimeUnit;
import javax.ejb.SessionContext;
import java.util.concurrent.ConcurrentMap;
import org.apache.openejb.BeanContext;
import java.util.Map;
import org.apache.openejb.persistence.JtaEntityManagerRegistry;
import org.apache.openejb.util.Duration;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.Logger;
import org.apache.openejb.RpcContainer;

public class StatefulContainer implements RpcContainer
{
    private static final Logger logger;
    private final Object containerID;
    private final SecurityService securityService;
    private final Duration accessTimeout;
    protected final JtaEntityManagerRegistry entityManagerRegistry;
    protected final Map<Object, BeanContext> deploymentsById;
    protected final Cache<Object, Instance> cache;
    protected final LockFactory lockFactory;
    private final ConcurrentMap<Object, Instance> checkedOutInstances;
    private final SessionContext sessionContext;
    private final boolean preventExtendedEntityManagerSerialization;
    
    public StatefulContainer(final Object id, final SecurityService securityService, final Cache<Object, Instance> cache) {
        this(id, securityService, cache, new Duration(-1L, TimeUnit.MILLISECONDS), true, new DefaultLockFactory());
    }
    
    public StatefulContainer(final Object id, final SecurityService securityService, final Cache<Object, Instance> cache, final Duration accessTimeout, final boolean preventExtendedEntityManagerSerialization, final LockFactory lockFactory) {
        this.entityManagerRegistry = (JtaEntityManagerRegistry)SystemInstance.get().getComponent((Class)JtaEntityManagerRegistry.class);
        this.deploymentsById = new HashMap<Object, BeanContext>();
        this.checkedOutInstances = new ConcurrentHashMap<Object, Instance>();
        this.containerID = id;
        this.securityService = securityService;
        (this.cache = cache).setListener(new StatefulCacheListener());
        this.accessTimeout = accessTimeout;
        this.sessionContext = (SessionContext)new StatefulContext(this.securityService, (UserTransaction)new StatefulUserTransaction((UserTransaction)new EjbUserTransaction(), this.entityManagerRegistry));
        this.preventExtendedEntityManagerSerialization = preventExtendedEntityManagerSerialization;
        (this.lockFactory = lockFactory).setContainer(this);
    }
    
    private Map<Method, MethodType> getLifecycleMethodsOfInterface(final BeanContext beanContext) {
        final Map<Method, MethodType> methods = new HashMap<Method, MethodType>();
        try {
            methods.put(BeanContext.Removable.class.getDeclaredMethod("$$remove", (Class<?>[])new Class[0]), MethodType.REMOVE);
        }
        catch (NoSuchMethodException e) {
            throw new IllegalStateException("Internal code change: BeanContext.Removable.$$remove() method was deleted", e);
        }
        final List<Method> removeMethods = beanContext.getRemoveMethods();
        for (final Method removeMethod : removeMethods) {
            methods.put(removeMethod, MethodType.REMOVE);
            for (final Class businessLocal : beanContext.getBusinessLocalInterfaces()) {
                try {
                    final Method method = businessLocal.getMethod(removeMethod.getName(), (Class[])removeMethod.getParameterTypes());
                    methods.put(method, MethodType.REMOVE);
                }
                catch (NoSuchMethodException ex) {}
            }
            for (final Class businessRemote : beanContext.getBusinessRemoteInterfaces()) {
                try {
                    final Method method = businessRemote.getMethod(removeMethod.getName(), (Class[])removeMethod.getParameterTypes());
                    methods.put(method, MethodType.REMOVE);
                }
                catch (NoSuchMethodException ex2) {}
            }
        }
        final Class legacyRemote = beanContext.getRemoteInterface();
        if (legacyRemote != null) {
            try {
                final Method method2 = legacyRemote.getMethod("remove", (Class[])new Class[0]);
                methods.put(method2, MethodType.REMOVE);
            }
            catch (NoSuchMethodException ex3) {}
        }
        final Class legacyLocal = beanContext.getLocalInterface();
        if (legacyLocal != null) {
            try {
                final Method method3 = legacyLocal.getMethod("remove", (Class[])new Class[0]);
                methods.put(method3, MethodType.REMOVE);
            }
            catch (NoSuchMethodException ex4) {}
        }
        final Class businessLocalHomeInterface = beanContext.getBusinessLocalInterface();
        if (businessLocalHomeInterface != null) {
            for (final Method method4 : BeanContext.BusinessLocalHome.class.getMethods()) {
                if (method4.getName().startsWith("create")) {
                    methods.put(method4, MethodType.CREATE);
                }
                else if (method4.getName().equals("remove")) {
                    methods.put(method4, MethodType.REMOVE);
                }
            }
        }
        final Class businessLocalBeanHomeInterface = beanContext.getBusinessLocalBeanInterface();
        if (businessLocalBeanHomeInterface != null) {
            for (final Method method5 : BeanContext.BusinessLocalBeanHome.class.getMethods()) {
                if (method5.getName().startsWith("create")) {
                    methods.put(method5, MethodType.CREATE);
                }
                else if (method5.getName().equals("remove")) {
                    methods.put(method5, MethodType.REMOVE);
                }
            }
        }
        final Class businessRemoteHomeInterface = beanContext.getBusinessRemoteInterface();
        if (businessRemoteHomeInterface != null) {
            for (final Method method6 : BeanContext.BusinessRemoteHome.class.getMethods()) {
                if (method6.getName().startsWith("create")) {
                    methods.put(method6, MethodType.CREATE);
                }
                else if (method6.getName().equals("remove")) {
                    methods.put(method6, MethodType.REMOVE);
                }
            }
        }
        final Class homeInterface = beanContext.getHomeInterface();
        if (homeInterface != null) {
            for (final Method method7 : homeInterface.getMethods()) {
                if (method7.getName().startsWith("create")) {
                    methods.put(method7, MethodType.CREATE);
                }
                else if (method7.getName().equals("remove")) {
                    methods.put(method7, MethodType.REMOVE);
                }
            }
        }
        final Class localHomeInterface = beanContext.getLocalHomeInterface();
        if (localHomeInterface != null) {
            for (final Method method8 : localHomeInterface.getMethods()) {
                if (method8.getName().startsWith("create")) {
                    methods.put(method8, MethodType.CREATE);
                }
                else if (method8.getName().equals("remove")) {
                    methods.put(method8, MethodType.REMOVE);
                }
            }
        }
        return methods;
    }
    
    public LockFactory getLockFactory() {
        return this.lockFactory;
    }
    
    public Cache<Object, Instance> getCache() {
        return this.cache;
    }
    
    @Override
    public ContainerType getContainerType() {
        return ContainerType.STATEFUL;
    }
    
    @Override
    public Object getContainerID() {
        return this.containerID;
    }
    
    @Override
    public synchronized BeanContext[] getBeanContexts() {
        return this.deploymentsById.values().toArray(new BeanContext[this.deploymentsById.size()]);
    }
    
    @Override
    public synchronized BeanContext getBeanContext(final Object deploymentID) {
        return this.deploymentsById.get(deploymentID);
    }
    
    @Override
    public void start(final BeanContext beanContext) throws OpenEJBException {
    }
    
    @Override
    public void stop(final BeanContext beanContext) throws OpenEJBException {
        beanContext.stop();
    }
    
    @Override
    public synchronized void undeploy(final BeanContext beanContext) throws OpenEJBException {
        final Data data = (Data)beanContext.getContainerData();
        final MBeanServer server = LocalMBeanServer.get();
        for (final ObjectName objectName : data.jmxNames) {
            try {
                server.unregisterMBean(objectName);
            }
            catch (Exception e) {
                StatefulContainer.logger.error("Unable to unregister MBean " + objectName);
            }
        }
        this.deploymentsById.remove(beanContext.getDeploymentID());
        beanContext.setContainer(null);
        beanContext.setContainerData(null);
        if (this.isPassivable(beanContext)) {
            this.cache.removeAll(new BeanContextFilter(beanContext.getId()));
        }
    }
    
    @Override
    public synchronized void deploy(final BeanContext beanContext) throws OpenEJBException {
        final Map<Method, MethodType> methods = this.getLifecycleMethodsOfInterface(beanContext);
        this.deploymentsById.put(beanContext.getDeploymentID(), beanContext);
        beanContext.setContainer(this);
        final Data data = new Data(new Index((Map<K, V>)methods));
        beanContext.setContainerData(data);
        if (StatsInterceptor.isStatsActivated()) {
            final StatsInterceptor stats = new StatsInterceptor(beanContext.getBeanClass());
            beanContext.addFirstSystemInterceptor(stats);
            final MBeanServer server = LocalMBeanServer.get();
            final ObjectNameBuilder jmxName = new ObjectNameBuilder("openejb.management");
            jmxName.set("J2EEServer", "openejb");
            jmxName.set("J2EEApplication", null);
            jmxName.set("EJBModule", beanContext.getModuleID());
            jmxName.set("StatefulSessionBean", beanContext.getEjbName());
            jmxName.set("j2eeType", "");
            jmxName.set("name", beanContext.getEjbName());
            try {
                final ObjectName objectName = jmxName.set("j2eeType", "Invocations").build();
                if (server.isRegistered(objectName)) {
                    server.unregisterMBean(objectName);
                }
                server.registerMBean(new ManagedMBean(stats), objectName);
                data.jmxNames.add(objectName);
            }
            catch (Exception e) {
                StatefulContainer.logger.error("Unable to register MBean ", e);
            }
        }
        try {
            final Context context = beanContext.getJndiEnc();
            context.bind("comp/EJBContext", this.sessionContext);
        }
        catch (NamingException e2) {
            throw new OpenEJBException("Failed to bind EJBContext", e2);
        }
        beanContext.set((Class<Object>)EJBContext.class, this.sessionContext);
    }
    
    @Override
    public Object invoke(final Object deployID, InterfaceType type, final Class callInterface, final Method callMethod, final Object[] args, final Object primKey) throws OpenEJBException {
        final BeanContext beanContext = this.getBeanContext(deployID);
        if (beanContext == null) {
            throw new OpenEJBException("Deployment does not exist in this container. Deployment(id='" + deployID + "'), Container(id='" + this.containerID + "')");
        }
        if (type == null) {
            type = beanContext.getInterfaceType(callInterface);
        }
        final Data data = (Data)beanContext.getContainerData();
        MethodType methodType = data.getMethodIndex().get(callMethod);
        methodType = ((methodType != null) ? methodType : MethodType.BUSINESS);
        switch (methodType) {
            case CREATE: {
                return this.createEJBObject(beanContext, callMethod, args, type);
            }
            case REMOVE: {
                return this.removeEJBObject(beanContext, primKey, callInterface, callMethod, args, type);
            }
            default: {
                return this.businessMethod(beanContext, primKey, callInterface, callMethod, args, type);
            }
        }
    }
    
    private boolean isPassivable(final BeanContext beanContext) {
        if (this.preventExtendedEntityManagerSerialization) {
            return true;
        }
        final Index<EntityManagerFactory, BeanContext.EntityManagerConfiguration> factories = beanContext.getExtendedEntityManagerFactories();
        return (factories == null || factories.size() <= 0) && beanContext.isPassivable();
    }
    
    protected ProxyInfo createEJBObject(final BeanContext beanContext, final Method callMethod, final Object[] args, final InterfaceType interfaceType) throws OpenEJBException {
        final Object primaryKey = this.newPrimaryKey();
        final ThreadContext createContext = new ThreadContext(beanContext, primaryKey);
        final ThreadContext oldCallContext = ThreadContext.enter(createContext);
        Object runAs = null;
        try {
            if (oldCallContext != null) {
                final BeanContext oldBc = oldCallContext.getBeanContext();
                if (oldBc.getRunAsUser() != null || oldBc.getRunAs() != null) {
                    runAs = AbstractSecurityService.class.cast(this.securityService).overrideWithRunAsContext(createContext, beanContext, oldBc);
                }
            }
            this.checkAuthorization(callMethod, interfaceType);
            final Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> entityManagers = this.createEntityManagers(beanContext);
            if (entityManagers != null) {
                try {
                    this.entityManagerRegistry.addEntityManagers((String)beanContext.getDeploymentID(), primaryKey, entityManagers);
                }
                catch (EntityManagerAlreadyRegisteredException e) {
                    throw new EJBException((Exception)e);
                }
            }
            createContext.setCurrentOperation(Operation.CREATE);
            createContext.setCurrentAllowedStates(null);
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(createContext.getBeanContext().getTransactionType(callMethod, interfaceType), createContext);
            Instance instance = null;
            try {
                try {
                    final InstanceContext context = beanContext.newInstance();
                    instance = new Instance(beanContext, primaryKey, this.containerID, context.getBean(), context.getCreationalContext(), context.getInterceptors(), entityManagers, this.lockFactory.newLock(primaryKey.toString()));
                }
                catch (Throwable throwable) {
                    final ThreadContext callContext = ThreadContext.getThreadContext();
                    EjbTransactionUtil.handleSystemException(callContext.getTransactionPolicy(), throwable, callContext);
                    throw new IllegalStateException(throwable);
                }
                if (this.isPassivable(beanContext)) {
                    this.cache.add(primaryKey, instance);
                }
                this.checkedOutInstances.put(primaryKey, instance);
                this.registerSessionSynchronization(instance, createContext);
                if (!callMethod.getDeclaringClass().equals(BeanContext.BusinessLocalHome.class) && !callMethod.getDeclaringClass().equals(BeanContext.BusinessRemoteHome.class) && !callMethod.getDeclaringClass().equals(BeanContext.BusinessLocalBeanHome.class)) {
                    final Method createOrInit = beanContext.getMatchingBeanMethod(callMethod);
                    createContext.set(Method.class, createOrInit);
                    final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, createOrInit, Operation.CREATE, new ArrayList<InterceptorData>(), new HashMap<String, Object>());
                    if (args == null) {
                        interceptorStack.invoke(new Object[0]);
                    }
                    else {
                        interceptorStack.invoke(args);
                    }
                }
            }
            catch (Throwable e2) {
                this.handleException(createContext, txPolicy, e2);
            }
            finally {
                this.unregisterEntityManagers(instance, createContext);
                this.afterInvoke(createContext, txPolicy, instance);
            }
            return new ProxyInfo(beanContext, primaryKey);
        }
        finally {
            if (runAs != null) {
                try {
                    this.securityService.associate(runAs);
                }
                catch (LoginException ex) {}
            }
            ThreadContext.exit(oldCallContext);
        }
    }
    
    protected Object newPrimaryKey() {
        return new VMID();
    }
    
    protected Object removeEJBObject(final BeanContext beanContext, final Object primKey, final Class callInterface, final Method callMethod, Object[] args, final InterfaceType interfaceType) throws OpenEJBException {
        if (primKey == null) {
            throw new NullPointerException("primKey is null");
        }
        final CdiEjbBean cdiEjbBean = beanContext.get(CdiEjbBean.class);
        if (cdiEjbBean != null) {
            final Class scope = cdiEjbBean.getScope();
            if (callMethod.getDeclaringClass() != BeanContext.Removable.class && scope != Dependent.class) {
                throw new UnsupportedOperationException("Can not call EJB Stateful Bean Remove Method without scoped @Dependent.  Found scope: @" + scope.getSimpleName());
            }
        }
        final boolean internalRemove = BeanContext.Removable.class == callMethod.getDeclaringClass();
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        Object runAs = null;
        try {
            if (oldCallContext != null) {
                final BeanContext oldBc = oldCallContext.getBeanContext();
                if (oldBc.getRunAsUser() != null || oldBc.getRunAs() != null) {
                    runAs = AbstractSecurityService.class.cast(this.securityService).overrideWithRunAsContext(callContext, beanContext, oldBc);
                }
            }
            if (!internalRemove) {
                this.checkAuthorization(callMethod, interfaceType);
            }
            if (interfaceType.isComponent()) {
                final Instance instance = this.checkedOutInstances.get(primKey);
                if (instance != null && instance.bean instanceof SessionBean) {
                    throw new ApplicationException((Exception)new RemoveException("A stateful EJB enrolled in a transaction can not be removed"));
                }
            }
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(callContext.getBeanContext().getTransactionType(callMethod, interfaceType), callContext);
            Object returnValue = null;
            boolean retain = false;
            Instance instance2 = null;
            Method runMethod = null;
            try {
                instance2 = this.obtainInstance(primKey, callContext, callMethod, beanContext.isPassivatingScope());
                if (txPolicy instanceof BeanTransactionPolicy) {
                    final BeanTransactionPolicy.SuspendedTransaction suspendedTransaction = instance2.getBeanTransaction();
                    if (suspendedTransaction != null) {
                        instance2.setBeanTransaction(null);
                        final BeanTransactionPolicy beanTxEnv = (BeanTransactionPolicy)txPolicy;
                        beanTxEnv.resumeUserTransaction(suspendedTransaction);
                    }
                }
                if (!internalRemove) {
                    this.registerEntityManagers(instance2, callContext);
                    this.registerSessionSynchronization(instance2, callContext);
                    callContext.setCurrentOperation(Operation.REMOVE);
                    callContext.setCurrentAllowedStates(null);
                    callContext.setInvokedInterface(callInterface);
                    runMethod = beanContext.getMatchingBeanMethod(callMethod);
                    callContext.set(Method.class, runMethod);
                    final Class<?> declaringClass = callMethod.getDeclaringClass();
                    if (declaringClass.equals(EJBHome.class) || declaringClass.equals(EJBLocalHome.class)) {
                        args = new Object[0];
                    }
                    final List<InterceptorData> interceptors = beanContext.getMethodInterceptors(runMethod);
                    final InterceptorStack interceptorStack = new InterceptorStack(instance2.bean, runMethod, Operation.REMOVE, interceptors, instance2.interceptors);
                    final CdiEjbBean<Object> bean = beanContext.get((Class<CdiEjbBean<Object>>)CdiEjbBean.class);
                    if (bean != null) {
                        bean.getInjectionTarget().preDestroy(instance2.bean);
                    }
                    if (args == null) {
                        returnValue = interceptorStack.invoke(new Object[0]);
                    }
                    else {
                        returnValue = interceptorStack.invoke(args);
                    }
                }
            }
            catch (InvalidateReferenceException e) {
                throw new ApplicationException(e.getRootCause());
            }
            catch (Throwable e2) {
                if (interfaceType.isBusiness()) {
                    retain = beanContext.retainIfExeption(runMethod);
                    this.handleException(callContext, txPolicy, e2);
                }
                else {
                    try {
                        this.handleException(callContext, txPolicy, e2);
                    }
                    catch (ApplicationException ex) {}
                }
            }
            finally {
                if (runAs != null) {
                    try {
                        this.securityService.associate(runAs);
                    }
                    catch (LoginException ex2) {}
                }
                if (!retain) {
                    try {
                        callContext.setCurrentOperation(Operation.PRE_DESTROY);
                        final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                        if (instance2 != null) {
                            final InterceptorStack interceptorStack2 = new InterceptorStack(instance2.bean, null, Operation.PRE_DESTROY, callbackInterceptors, instance2.interceptors);
                            interceptorStack2.invoke(new Object[0]);
                        }
                    }
                    catch (Throwable t) {
                        final String logMessage = "An unexpected exception occured while invoking the preDestroy method on the Stateful SessionBean instance: " + ((null != instance2) ? instance2.bean.getClass().getName() : beanContext.getBeanClass().getName());
                        StatefulContainer.logger.error(logMessage, t);
                        callContext.setCurrentOperation(Operation.REMOVE);
                    }
                    finally {
                        callContext.setCurrentOperation(Operation.REMOVE);
                    }
                    this.discardInstance(primKey, instance2);
                }
                final Map<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> unregisteredEntityManagers = this.unregisterEntityManagers(instance2, callContext);
                this.afterInvoke(callContext, txPolicy, instance2);
                this.closeEntityManagers(unregisteredEntityManagers);
            }
            return returnValue;
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    protected Object businessMethod(final BeanContext beanContext, final Object primKey, final Class callInterface, final Method callMethod, final Object[] args, final InterfaceType interfaceType) throws OpenEJBException {
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        final CurrentCreationalContext currentCreationalContext = beanContext.get(CurrentCreationalContext.class);
        Object runAs = null;
        try {
            if (oldCallContext != null) {
                final BeanContext oldBc = oldCallContext.getBeanContext();
                if (oldBc.getRunAsUser() != null || oldBc.getRunAs() != null) {
                    runAs = AbstractSecurityService.class.cast(this.securityService).overrideWithRunAsContext(callContext, beanContext, oldBc);
                }
            }
            this.checkAuthorization(callMethod, interfaceType);
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(callContext.getBeanContext().getTransactionType(callMethod, interfaceType), callContext);
            Object returnValue = null;
            Instance instance = null;
            try {
                instance = this.obtainInstance(primKey, callContext, callMethod, true);
                if (txPolicy instanceof BeanTransactionPolicy) {
                    final BeanTransactionPolicy.SuspendedTransaction suspendedTransaction = instance.getBeanTransaction();
                    if (suspendedTransaction != null) {
                        instance.setBeanTransaction(null);
                        final BeanTransactionPolicy beanTxEnv = (BeanTransactionPolicy)txPolicy;
                        beanTxEnv.resumeUserTransaction(suspendedTransaction);
                    }
                }
                this.registerEntityManagers(instance, callContext);
                this.registerSessionSynchronization(instance, callContext);
                callContext.setCurrentOperation(Operation.BUSINESS);
                callContext.setCurrentAllowedStates(null);
                callContext.setInvokedInterface(callInterface);
                final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
                callContext.set(Method.class, runMethod);
                if (currentCreationalContext != null) {
                    currentCreationalContext.set(instance.creationalContext);
                }
                final List<InterceptorData> interceptors = beanContext.getMethodInterceptors(runMethod);
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, runMethod, Operation.BUSINESS, interceptors, instance.interceptors);
                returnValue = interceptorStack.invoke(args);
            }
            catch (Throwable e) {
                this.handleException(callContext, txPolicy, e);
            }
            finally {
                this.unregisterEntityManagers(instance, callContext);
                this.afterInvoke(callContext, txPolicy, instance);
            }
            return returnValue;
        }
        finally {
            if (runAs != null) {
                try {
                    this.securityService.associate(runAs);
                }
                catch (LoginException ex) {}
            }
            ThreadContext.exit(oldCallContext);
            if (currentCreationalContext != null) {
                currentCreationalContext.remove();
            }
        }
    }
    
    private Instance obtainInstance(final Object primaryKey, final ThreadContext callContext, final Method callMethod, final boolean checkOutIfNecessary) throws OpenEJBException {
        if (primaryKey == null) {
            throw new SystemException(new NullPointerException("Cannot obtain an instance of the stateful session bean with a null session id"));
        }
        final Transaction currentTransaction = this.getTransaction(callContext);
        Instance instance;
        synchronized (this) {
            instance = this.checkedOutInstances.get(primaryKey);
            if (instance == null) {
                try {
                    instance = this.cache.checkOut(primaryKey, checkOutIfNecessary);
                }
                catch (OpenEJBException e) {
                    throw e;
                }
                catch (Exception e2) {
                    throw new SystemException("Unexpected load exception", e2);
                }
                if (instance == null) {
                    throw new InvalidateReferenceException(new NoSuchObjectException("Not Found"));
                }
                this.checkedOutInstances.put(primaryKey, instance);
            }
        }
        final Duration accessTimeout = this.getAccessTimeout(instance.beanContext, callMethod);
        final LockFactory.StatefulLock currLock = instance.getLock();
        boolean lockAcquired;
        if (accessTimeout == null || accessTimeout.getTime() < 0L) {
            currLock.lock();
            lockAcquired = true;
        }
        else if (accessTimeout.getTime() == 0L) {
            lockAcquired = currLock.tryLock();
        }
        else {
            try {
                lockAcquired = currLock.tryLock(accessTimeout.getTime(), accessTimeout.getUnit());
            }
            catch (InterruptedException e3) {
                throw new ApplicationException("Unable to get lock.", e3);
            }
        }
        if (!lockAcquired) {
            throw new ApplicationException((Exception)new ConcurrentAccessTimeoutException("Unable to get lock."));
        }
        if (instance.getTransaction() != null) {
            if (!instance.getTransaction().equals(currentTransaction) && !instance.getLock().tryLock()) {
                throw new ApplicationException(new RemoteException("Instance is in a transaction and cannot be invoked outside that transaction.  See EJB 3.0 Section 4.4.4"));
            }
        }
        else {
            instance.setTransaction(currentTransaction);
        }
        instance.setInUse(true);
        return instance;
    }
    
    private Duration getAccessTimeout(final BeanContext beanContext, Method callMethod) {
        callMethod = beanContext.getMatchingBeanMethod(callMethod);
        Duration accessTimeout = beanContext.getAccessTimeout(callMethod);
        if (accessTimeout == null) {
            accessTimeout = beanContext.getAccessTimeout();
            if (accessTimeout == null) {
                accessTimeout = this.accessTimeout;
            }
        }
        return accessTimeout;
    }
    
    private Transaction getTransaction(final ThreadContext callContext) {
        final TransactionPolicy policy = callContext.getTransactionPolicy();
        Transaction currentTransaction = null;
        if (policy instanceof JtaTransactionPolicy) {
            final JtaTransactionPolicy jtaPolicy = (JtaTransactionPolicy)policy;
            currentTransaction = jtaPolicy.getCurrentTransaction();
        }
        return currentTransaction;
    }
    
    private void releaseInstance(final Instance instance) {
        if (instance.beanContext.isDestroyed()) {
            return;
        }
        instance.setInUse(false);
        if (instance.getTransaction() == null && this.isPassivable(instance.beanContext) && null == instance.getBeanTransaction()) {
            synchronized (instance.primaryKey) {
                this.cache.checkIn(instance.primaryKey);
                this.checkedOutInstances.remove(instance.primaryKey);
            }
        }
    }
    
    private void discardInstance(final Object primaryKey, final Instance instance) {
        if (primaryKey == null) {
            return;
        }
        Instance i;
        if (instance == null) {
            i = this.checkedOutInstances.remove(primaryKey);
        }
        else {
            this.checkedOutInstances.remove(primaryKey);
            i = instance;
        }
        if (i != null) {
            if (this.isPassivable(i.beanContext)) {
                this.cache.remove(primaryKey);
            }
            if (null != i.creationalContext) {
                i.creationalContext.release();
            }
        }
    }
    
    private void checkAuthorization(final Method callMethod, final InterfaceType interfaceType) throws ApplicationException {
        final boolean authorized = this.securityService.isCallerAuthorized(callMethod, interfaceType);
        if (!authorized) {
            throw new ApplicationException((Exception)new EJBAccessException("Unauthorized Access by Principal Denied"));
        }
    }
    
    private void handleException(final ThreadContext callContext, final TransactionPolicy txPolicy, final Throwable e) throws ApplicationException {
        if (e instanceof ApplicationException) {
            throw (ApplicationException)e;
        }
        final ExceptionType type = callContext.getBeanContext().getExceptionType(e);
        if (type == ExceptionType.SYSTEM) {
            this.discardInstance(callContext.getPrimaryKey(), null);
            EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
        }
        else {
            EjbTransactionUtil.handleApplicationException(txPolicy, e, type == ExceptionType.APPLICATION_ROLLBACK);
        }
    }
    
    private void afterInvoke(final ThreadContext callContext, final TransactionPolicy txPolicy, final Instance instance) throws OpenEJBException {
        try {
            if (instance != null && txPolicy instanceof BeanTransactionPolicy) {
                BeanTransactionPolicy.SuspendedTransaction suspendedTransaction = null;
                try {
                    final BeanTransactionPolicy beanTxEnv = (BeanTransactionPolicy)txPolicy;
                    suspendedTransaction = beanTxEnv.suspendUserTransaction();
                }
                catch (SystemException e) {
                    EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
                }
                finally {
                    instance.setBeanTransaction(suspendedTransaction);
                }
            }
        }
        finally {
            if (instance != null) {
                instance.setInUse(false);
            }
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
            if (instance != null) {
                instance.releaseLock();
            }
        }
    }
    
    private Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> createEntityManagers(final BeanContext beanContext) {
        final Index<EntityManagerFactory, BeanContext.EntityManagerConfiguration> factories = beanContext.getExtendedEntityManagerFactories();
        Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> entityManagers = null;
        if (factories != null && factories.size() > 0) {
            entityManagers = new Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker>(new ArrayList<EntityManagerFactory>((Collection<? extends EntityManagerFactory>)factories.keySet()));
            for (final Map.Entry<EntityManagerFactory, BeanContext.EntityManagerConfiguration> entry : factories.entrySet()) {
                final EntityManagerFactory entityManagerFactory = entry.getKey();
                JtaEntityManagerRegistry.EntityManagerTracker entityManagerTracker = this.entityManagerRegistry.getInheritedEntityManager(entityManagerFactory);
                if (entityManagerTracker == null) {
                    final Map properties = entry.getValue().getProperties();
                    final SynchronizationType synchronizationType = entry.getValue().getSynchronizationType();
                    EntityManager entityManager;
                    if (synchronizationType != null) {
                        if (properties != null) {
                            entityManager = entityManagerFactory.createEntityManager(synchronizationType, properties);
                        }
                        else {
                            entityManager = entityManagerFactory.createEntityManager(synchronizationType);
                        }
                    }
                    else if (properties != null) {
                        entityManager = entityManagerFactory.createEntityManager(properties);
                    }
                    else {
                        entityManager = entityManagerFactory.createEntityManager();
                    }
                    entityManagerTracker = new JtaEntityManagerRegistry.EntityManagerTracker(entityManager, synchronizationType != SynchronizationType.UNSYNCHRONIZED);
                }
                else {
                    entityManagerTracker.incCounter();
                }
                entityManagers.put(entityManagerFactory, entityManagerTracker);
            }
        }
        return entityManagers;
    }
    
    private void registerEntityManagers(final Instance instance, final ThreadContext callContext) throws OpenEJBException {
        if (this.entityManagerRegistry == null) {
            return;
        }
        final BeanContext beanContext = callContext.getBeanContext();
        final Index<EntityManagerFactory, BeanContext.EntityManagerConfiguration> factories = beanContext.getExtendedEntityManagerFactories();
        if (factories == null) {
            return;
        }
        final Map<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> entityManagers = instance.getEntityManagers(factories);
        if (entityManagers == null) {
            return;
        }
        try {
            this.entityManagerRegistry.addEntityManagers((String)beanContext.getDeploymentID(), instance.primaryKey, entityManagers);
        }
        catch (EntityManagerAlreadyRegisteredException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    private Map<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> unregisterEntityManagers(final Instance instance, final ThreadContext callContext) {
        if (this.entityManagerRegistry == null) {
            return null;
        }
        if (instance == null) {
            return null;
        }
        final BeanContext beanContext = callContext.getBeanContext();
        return this.entityManagerRegistry.removeEntityManagers((String)beanContext.getDeploymentID(), instance.primaryKey);
    }
    
    private void closeEntityManagers(final Map<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> unregisteredEntityManagers) {
        if (unregisteredEntityManagers == null) {
            return;
        }
        for (final JtaEntityManagerRegistry.EntityManagerTracker entityManagerTracker : unregisteredEntityManagers.values()) {
            if (entityManagerTracker.decCounter() == 0) {
                entityManagerTracker.getEntityManager().close();
            }
        }
    }
    
    private void registerSessionSynchronization(final Instance instance, final ThreadContext callContext) {
        final TransactionPolicy txPolicy = callContext.getTransactionPolicy();
        if (txPolicy == null) {
            throw new IllegalStateException("ThreadContext does not contain a TransactionEnvironment");
        }
        SessionSynchronizationCoordinator coordinator = (SessionSynchronizationCoordinator)txPolicy.getResource(SessionSynchronizationCoordinator.class);
        if (coordinator == null) {
            coordinator = new SessionSynchronizationCoordinator(txPolicy);
            txPolicy.registerSynchronization(coordinator);
            txPolicy.putResource(SessionSynchronizationCoordinator.class, coordinator);
        }
        final boolean synchronize = callContext.getCurrentOperation() != Operation.CREATE && callContext.getBeanContext().isSessionSynchronized() && txPolicy.isTransactionActive();
        coordinator.registerSessionSynchronization(instance, callContext.getBeanContext(), callContext.getPrimaryKey(), synchronize);
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
    
    public enum MethodType
    {
        CREATE, 
        REMOVE, 
        BUSINESS;
    }
    
    private final class SessionSynchronizationCoordinator implements TransactionPolicy.TransactionSynchronization
    {
        private final Map<Object, Synchronization> registry;
        private final TransactionPolicy txPolicy;
        
        private SessionSynchronizationCoordinator(final TransactionPolicy txPolicy) {
            this.registry = new HashMap<Object, Synchronization>();
            this.txPolicy = txPolicy;
        }
        
        private void registerSessionSynchronization(final Instance instance, final BeanContext beanContext, final Object primaryKey, final boolean synchronize) {
            Synchronization synchronization = this.registry.get(primaryKey);
            if (synchronization == null) {
                synchronization = new Synchronization(instance);
                this.registry.put(primaryKey, synchronization);
            }
            final boolean wasSynchronized = synchronization.setCallSessionSynchronization(synchronize);
            if (wasSynchronized || !synchronize) {
                return;
            }
            final ThreadContext callContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.AFTER_BEGIN);
            callContext.setCurrentAllowedStates(null);
            final ThreadContext oldCallContext = ThreadContext.enter(callContext);
            try {
                final List<InterceptorData> interceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, null, Operation.AFTER_BEGIN, interceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Exception e) {
                final String message = "An unexpected system exception occured while invoking the afterBegin method on the SessionSynchronization object";
                StatefulContainer.logger.error("An unexpected system exception occured while invoking the afterBegin method on the SessionSynchronization object", e);
                throw new OpenEJBRuntimeException("An unexpected system exception occured while invoking the afterBegin method on the SessionSynchronization object", e);
            }
            finally {
                ThreadContext.exit(oldCallContext);
            }
        }
        
        @Override
        public void beforeCompletion() {
            for (final Synchronization synchronization : this.registry.values()) {
                final Instance instance = synchronization.instance;
                if (this.txPolicy.isRollbackOnly()) {
                    return;
                }
                if (!synchronization.isCallSessionSynchronization()) {
                    continue;
                }
                final ThreadContext callContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.BEFORE_COMPLETION);
                callContext.setCurrentAllowedStates(null);
                final ThreadContext oldCallContext = ThreadContext.enter(callContext);
                try {
                    instance.setInUse(true);
                    final BeanContext beanContext = instance.beanContext;
                    final List<InterceptorData> interceptors = beanContext.getCallbackInterceptors();
                    final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, null, Operation.BEFORE_COMPLETION, interceptors, instance.interceptors);
                    interceptorStack.invoke(new Object[0]);
                    instance.setInUse(false);
                }
                catch (InvalidateReferenceException ex) {}
                catch (Exception e) {
                    final String message = "An unexpected system exception occured while invoking the beforeCompletion method on the SessionSynchronization object";
                    StatefulContainer.logger.error("An unexpected system exception occured while invoking the beforeCompletion method on the SessionSynchronization object", e);
                    this.txPolicy.setRollbackOnly(e);
                    StatefulContainer.this.discardInstance(callContext.getPrimaryKey(), instance);
                    throw new OpenEJBRuntimeException("An unexpected system exception occured while invoking the beforeCompletion method on the SessionSynchronization object", e);
                }
                finally {
                    ThreadContext.exit(oldCallContext);
                }
            }
        }
        
        @Override
        public void afterCompletion(final Status status) {
            Throwable firstException = null;
            for (final Synchronization synchronization : this.registry.values()) {
                final Instance instance = synchronization.instance;
                final ThreadContext callContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.AFTER_COMPLETION);
                callContext.setCurrentAllowedStates(null);
                final ThreadContext oldCallContext = ThreadContext.enter(callContext);
                try {
                    instance.setInUse(true);
                    if (synchronization.isCallSessionSynchronization()) {
                        final BeanContext beanContext = instance.beanContext;
                        final List<InterceptorData> interceptors = beanContext.getCallbackInterceptors();
                        final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, null, Operation.AFTER_COMPLETION, interceptors, instance.interceptors);
                        interceptorStack.invoke(status == Status.COMMITTED);
                    }
                    instance.setTransaction(null);
                    StatefulContainer.this.releaseInstance(instance);
                }
                catch (InvalidateReferenceException ex) {}
                catch (Throwable e) {
                    final String message = "An unexpected system exception occured while invoking the afterCompletion method on the SessionSynchronization object";
                    StatefulContainer.logger.error("An unexpected system exception occured while invoking the afterCompletion method on the SessionSynchronization object", e);
                    StatefulContainer.this.discardInstance(callContext.getPrimaryKey(), instance);
                    if (firstException == null) {
                        firstException = e;
                    }
                }
                finally {
                    ThreadContext.exit(oldCallContext);
                }
            }
            if (firstException != null) {
                throw new OpenEJBRuntimeException("An unexpected system exception occured while invoking the afterCompletion method on the SessionSynchronization object", firstException);
            }
        }
        
        public class Synchronization
        {
            private final Instance instance;
            private boolean callSessionSynchronization;
            
            public Synchronization(final Instance instance) {
                this.instance = instance;
            }
            
            public synchronized boolean isCallSessionSynchronization() {
                return this.callSessionSynchronization;
            }
            
            public synchronized boolean setCallSessionSynchronization(final boolean synchronize) {
                final boolean oldValue = this.callSessionSynchronization;
                this.callSessionSynchronization = synchronize;
                return oldValue;
            }
        }
    }
    
    public class StatefulCacheListener implements Cache.CacheListener<Instance>
    {
        @Override
        public void afterLoad(final Instance instance) throws SystemException, ApplicationException {
            final BeanContext beanContext = instance.beanContext;
            final ThreadContext threadContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.ACTIVATE);
            final ThreadContext oldContext = ThreadContext.enter(threadContext);
            try {
                final Method remove = (instance.bean instanceof SessionBean) ? SessionBean.class.getMethod("ejbActivate", (Class<?>[])new Class[0]) : null;
                final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, remove, Operation.ACTIVATE, callbackInterceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Throwable callbackException) {
                StatefulContainer.this.discardInstance(threadContext.getPrimaryKey(), instance);
                EjbTransactionUtil.handleSystemException(threadContext.getTransactionPolicy(), callbackException, threadContext);
            }
            finally {
                ThreadContext.exit(oldContext);
            }
        }
        
        @Override
        public void beforeStore(final Instance instance) {
            final BeanContext beanContext = instance.beanContext;
            final ThreadContext threadContext = new ThreadContext(beanContext, instance.primaryKey, Operation.PASSIVATE);
            final ThreadContext oldContext = ThreadContext.enter(threadContext);
            try {
                final Method passivate = (instance.bean instanceof SessionBean) ? SessionBean.class.getMethod("ejbPassivate", (Class<?>[])new Class[0]) : null;
                final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, passivate, Operation.PASSIVATE, callbackInterceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Throwable e) {
                StatefulContainer.logger.error("An unexpected exception occured while invoking the ejbPassivate method on the Stateful SessionBean instance", e);
            }
            finally {
                ThreadContext.exit(oldContext);
            }
        }
        
        @Override
        public void timedOut(final Instance instance) {
            final BeanContext beanContext = instance.beanContext;
            final ThreadContext threadContext = new ThreadContext(beanContext, instance.primaryKey, Operation.PRE_DESTROY);
            threadContext.setCurrentAllowedStates(null);
            final ThreadContext oldContext = ThreadContext.enter(threadContext);
            try {
                final Method remove = (instance.bean instanceof SessionBean) ? SessionBean.class.getMethod("ejbRemove", (Class<?>[])new Class[0]) : null;
                final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, remove, Operation.PRE_DESTROY, callbackInterceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Throwable e) {
                StatefulContainer.logger.error("An unexpected exception occured while invoking the ejbRemove method on the timed-out Stateful SessionBean instance", e);
            }
            finally {
                StatefulContainer.logger.info("Removing the timed-out stateful session bean instance " + instance.primaryKey);
                ThreadContext.exit(oldContext);
            }
        }
    }
    
    private static final class Data
    {
        private final Index<Method, MethodType> methodIndex;
        private final List<ObjectName> jmxNames;
        
        private Data(final Index<Method, MethodType> methodIndex) {
            this.jmxNames = new ArrayList<ObjectName>();
            this.methodIndex = methodIndex;
        }
        
        public Index<Method, MethodType> getMethodIndex() {
            return this.methodIndex;
        }
    }
    
    public static class BeanContextFilter implements Cache.CacheFilter<Instance>, Serializable
    {
        private final String id;
        
        public BeanContextFilter(final String id) {
            this.id = id;
        }
        
        @Override
        public boolean matches(final Instance instance) {
            return instance.beanContext.getId().equals(this.id);
        }
    }
}
