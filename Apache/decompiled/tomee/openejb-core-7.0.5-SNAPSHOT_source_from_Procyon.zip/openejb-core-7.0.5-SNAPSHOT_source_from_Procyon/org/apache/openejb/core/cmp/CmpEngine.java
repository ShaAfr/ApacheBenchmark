// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import org.apache.openejb.OpenEJBException;
import org.apache.openejb.BeanContext;
import javax.ejb.FinderException;
import java.util.List;
import java.lang.reflect.Method;
import javax.ejb.CreateException;
import org.apache.openejb.core.ThreadContext;
import javax.ejb.EntityBean;

public interface CmpEngine
{
    Object createBean(final EntityBean p0, final ThreadContext p1) throws CreateException;
    
    Object loadBean(final ThreadContext p0, final Object p1);
    
    void storeBeanIfNoTx(final ThreadContext p0, final Object p1);
    
    void removeBean(final ThreadContext p0);
    
    List<Object> queryBeans(final ThreadContext p0, final Method p1, final Object[] p2) throws FinderException;
    
    List<Object> queryBeans(final BeanContext p0, final String p1, final Object[] p2) throws FinderException;
    
    int executeUpdateQuery(final BeanContext p0, final String p1, final Object[] p2) throws FinderException;
    
    void deploy(final BeanContext p0) throws OpenEJBException;
    
    void undeploy(final BeanContext p0) throws OpenEJBException;
}
