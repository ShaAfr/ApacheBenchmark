// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import org.apache.openejb.BeanContext;

public class BusinessLocalBeanReference extends Reference
{
    private final BeanContext.BusinessLocalBeanHome businessHome;
    
    public BusinessLocalBeanReference(final BeanContext.BusinessLocalBeanHome localBeanHome) {
        this.businessHome = localBeanHome;
    }
    
    @Override
    public Object getObject() throws NamingException {
        return this.businessHome.create();
    }
}
