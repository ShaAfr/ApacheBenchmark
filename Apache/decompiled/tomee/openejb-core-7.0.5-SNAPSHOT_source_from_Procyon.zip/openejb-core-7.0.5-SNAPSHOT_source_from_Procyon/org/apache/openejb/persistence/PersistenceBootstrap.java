// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import java.io.PrintWriter;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLException;
import java.sql.Connection;
import javax.sql.DataSource;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import org.apache.openejb.core.TempClassLoader;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.ClassFileTransformer;
import org.apache.openejb.loader.JarLocation;
import java.net.MalformedURLException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import org.apache.openejb.util.Saxs;
import org.xml.sax.InputSource;
import org.apache.openejb.javaagent.Agent;
import org.apache.openejb.util.JavaSecurityManagers;
import org.apache.openejb.loader.SystemInstance;
import java.io.IOException;
import java.util.HashSet;
import org.apache.openejb.config.NewLoaderLogic;
import org.apache.xbean.finder.UrlSet;
import org.apache.xbean.finder.ClassLoaders;
import java.util.Set;
import javax.persistence.EntityManagerFactory;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import javax.persistence.spi.PersistenceUnitInfo;
import javax.persistence.spi.PersistenceProvider;
import javax.sql.CommonDataSource;
import java.util.Properties;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.ArrayList;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.openejb.loader.IO;

public class PersistenceBootstrap
{
    public static final String DEFAULT_PROVIDER;
    private static volatile boolean systemDone;
    private static boolean debug;
    
    private static String getDefaultProvider() {
        final Class<PersistenceBootstrap> clzz = PersistenceBootstrap.class;
        final String name = "/META-INF/" + clzz.getName() + ".provider";
        try {
            final URL provider = clzz.getResource(name);
            if (provider != null) {
                final String trim = IO.slurp(provider).trim();
                Logger.getLogger(PersistenceBootstrap.class.getName()).info("Default JPA Provider changed to " + trim + " specified by " + provider.toExternalForm());
                return trim;
            }
        }
        catch (Exception e) {
            Logger.getLogger(PersistenceBootstrap.class.getName()).log(Level.WARNING, "Could not read " + name, e);
        }
        return "org.apache.openjpa.persistence.PersistenceProviderImpl";
    }
    
    public static void bootstrap(final ClassLoader classLoader) {
        if (classLoader == PersistenceBootstrap.class.getClassLoader()) {
            if (PersistenceBootstrap.systemDone) {
                return;
            }
            PersistenceBootstrap.systemDone = true;
        }
        final Properties args = getAgentArgs(classLoader);
        PersistenceBootstrap.debug = args.getProperty("debug", "false").equalsIgnoreCase("true");
        final boolean enabled = args.getProperty("enabled", "true").equalsIgnoreCase("true");
        if (!enabled) {
            debug("disabled");
            return;
        }
        try {
            debug("searching for persistence.xml files");
            final Collection<String> pXmlNames = new ArrayList<String>();
            final String altDD = getAltDD();
            if (altDD != null) {
                for (final String p : altDD.split(",")) {
                    pXmlNames.add(p + ".persistence.xml");
                    pXmlNames.add(p + "-persistence.xml");
                }
            }
            else {
                pXmlNames.add("persistence.xml");
            }
            final List<URL> urls = new LinkedList<URL>();
            for (final String pXmlName : pXmlNames) {
                urls.addAll(Collections.list(classLoader.getResources("META-INF/" + pXmlName)));
                if ("true".equals(args.getProperty("web-scan", "false"))) {
                    try {
                        final Collection<URL> loaderUrls = findUrls(classLoader, args);
                        for (final URL url : loaderUrls) {
                            final File file = toFile(url);
                            if ("classes".equals(file.getName()) && "WEB-INF".equals(file.getParentFile().getName())) {
                                final File pXml = new File(file.getParentFile(), pXmlName);
                                if (pXml.exists()) {
                                    urls.add(pXml.toURI().toURL());
                                    break;
                                }
                                break;
                            }
                            else {
                                if (!file.getName().endsWith(".jar") || !file.getParentFile().getName().equals("lib") || !"WEB-INF".equals(file.getParentFile().getParentFile().getName())) {
                                    continue;
                                }
                                final File pXml = new File(file.getParentFile().getParentFile(), pXmlName);
                                if (pXml.exists()) {
                                    urls.add(pXml.toURI().toURL());
                                    break;
                                }
                                break;
                            }
                        }
                    }
                    catch (Throwable t2) {}
                }
            }
            if (urls.size() == 0) {
                debug("no persistence.xml files found");
                return;
            }
            final Map<String, Unit> units = new HashMap<String, Unit>();
            for (final URL url2 : urls) {
                final String urlPath = url2.toExternalForm();
                debug("found " + urlPath);
                try {
                    final InputStream in = IO.read(url2);
                    try {
                        collectUnits(in, units, args);
                    }
                    catch (Throwable e) {
                        debug("failed to read " + urlPath, e);
                        in.close();
                    }
                }
                catch (Throwable e2) {
                    debug("failed to read " + urlPath, e2);
                }
            }
            for (final Unit unit : units.values()) {
                final String provider = unit.provider;
                final String extraClassesKey = provider + "@classes";
                final String unitNameKey = provider + "@unitName";
                final String unitName = args.getProperty(unitNameKey, "classpath-bootstrap");
                final String classes = args.getProperty(extraClassesKey);
                if (classes != null) {
                    debug("parsing value of " + extraClassesKey);
                    try {
                        final List<String> list = Arrays.asList(classes.split("[ \n\r\t,]"));
                        unit.classes.addAll(list);
                    }
                    catch (Exception e3) {
                        debug("cannot parse: " + classes, e3);
                    }
                }
                try {
                    if (provider.startsWith("org.hibernate")) {
                        debug("skipping: " + provider);
                    }
                    else {
                        debug("starting: " + provider);
                        final PersistenceUnitInfoImpl info = new PersistenceUnitInfoImpl(new Handler());
                        info.setManagedClassNames(new ArrayList<String>(unit.classes));
                        info.setPersistenceProviderClassName(unit.provider);
                        info.setProperties(new Properties());
                        info.setId(unitName);
                        info.setPersistenceUnitName(unitName);
                        info.setRootUrlAndJarUrls("", Collections.EMPTY_LIST);
                        info.setJtaDataSource(new NullDataSource());
                        info.setNonJtaDataSource(new NullDataSource());
                        info.setExcludeUnlistedClasses(true);
                        info.setClassLoader(classLoader);
                        for (final String name : unit.classes) {
                            debug("class " + name);
                        }
                        final Class clazz = classLoader.loadClass(unit.provider);
                        final PersistenceProvider persistenceProvider = clazz.newInstance();
                        final EntityManagerFactory emf = persistenceProvider.createContainerEntityManagerFactory((PersistenceUnitInfo)info, (Map)new HashMap());
                        emf.close();
                        debug("success: " + provider);
                    }
                }
                catch (Throwable e4) {
                    debug("failed: " + provider, e4);
                }
            }
        }
        catch (Throwable t) {
            debug("error: ", t);
        }
    }
    
    private static Set<URL> findUrls(final ClassLoader classLoader, final Properties args) throws IOException {
        if ("true".equals(args.getProperty("fast-scan", "true"))) {
            try {
                return new HashSet<URL>(NewLoaderLogic.applyBuiltinExcludes(new UrlSet((Collection)ClassLoaders.findUrls(classLoader)).excludeJvm()).getUrls());
            }
            catch (Throwable t) {}
        }
        return (Set<URL>)ClassLoaders.findUrls(classLoader);
    }
    
    private static String getAltDD() {
        final String property = "openejb.altdd.prefix";
        if (SystemInstance.isInitialized()) {
            return SystemInstance.get().getOptions().get("openejb.altdd.prefix", (String)null);
        }
        return JavaSecurityManagers.getSystemProperty("openejb.altdd.prefix");
    }
    
    private static void debug(final String x) {
        if (PersistenceBootstrap.debug) {
            System.out.println("[PersistenceBootstrap] " + x);
        }
    }
    
    private static void debug(final String x, final Throwable t) {
        if (PersistenceBootstrap.debug) {
            System.out.println(x);
            t.printStackTrace();
        }
    }
    
    private static Properties getAgentArgs(final ClassLoader classLoader) {
        final Properties properties = new Properties();
        final String args = Agent.getAgentArgs();
        if (args != null && args.length() != 0) {
            for (final String string : args.split("[ ,:&]")) {
                final String[] strings = string.split("=");
                if (strings.length == 2) {
                    properties.put(strings[0], strings[1]);
                }
            }
            PersistenceBootstrap.debug = properties.getProperty("debug", "false").equalsIgnoreCase("true");
        }
        try {
            final URL resource = classLoader.getResource("PersistenceBootstrap.properties");
            if (resource != null) {
                debug("found PersistenceBootstrap.properties file");
                IO.readProperties(resource, properties);
            }
        }
        catch (Throwable e) {
            debug("can't read PersistenceBootstrap.properties file", e);
        }
        return properties;
    }
    
    private static void collectUnits(final InputStream in, final Map<String, Unit> units, final Properties args) throws ParserConfigurationException, SAXException, IOException {
        final InputSource inputSource = new InputSource(in);
        final SAXParser parser = Saxs.namespaceAwareFactory().newSAXParser();
        parser.parse(inputSource, new DefaultHandler() {
            private final StringBuilder characters = new StringBuilder(100);
            private Unit unit;
            
            @Override
            public void startElement(final String uri, final String localName, final String qName, final Attributes attributes) {
                this.characters.setLength(0);
                if (localName.equals("persistence-unit")) {
                    this.startPersistenceUnit(uri, localName, qName, attributes);
                }
            }
            
            public void startPersistenceUnit(final String uri, final String localName, final String qName, final Attributes attributes) {
                final String unitName = attributes.getValue("name");
                this.unit = new Unit(unitName);
            }
            
            @Override
            public void characters(final char[] ch, final int start, final int length) {
                final String text = new String(ch, start, length);
                this.characters.append(text.trim());
            }
            
            @Override
            public void endElement(final String uri, final String localName, final String qName) {
                if (localName.equals("persistence-unit")) {
                    this.endPersistenceUnit(uri, localName, qName);
                }
                else if (localName.equals("provider")) {
                    this.endProvider(uri, localName, qName);
                }
                else if (localName.equals("class")) {
                    this.endClass(uri, localName, qName);
                }
            }
            
            public void endPersistenceUnit(final String uri, final String localName, final String qName) {
                if (args.getProperty(this.unit.name + "@skip", "false").equalsIgnoreCase("true")) {
                    debug("skipping unit " + this.unit.name);
                }
                else {
                    debug("adding unit " + this.unit.name);
                    if (this.unit.provider == null) {
                        this.unit.provider = PersistenceBootstrap.DEFAULT_PROVIDER;
                    }
                    final Unit u = units.get(this.unit.provider);
                    if (u == null) {
                        units.put(this.unit.provider, this.unit);
                    }
                    else {
                        u.classes.addAll(this.unit.classes);
                    }
                }
                this.unit = null;
            }
            
            public void endProvider(final String uri, final String localName, final String qName) {
                this.unit.provider = this.characters.toString();
            }
            
            public void endClass(final String uri, final String localName, final String qName) {
                this.unit.classes.add(this.characters.toString());
            }
        });
    }
    
    public static File toFile(final URL url) {
        if ("jar".equals(url.getProtocol())) {
            try {
                final String spec = url.getFile();
                int separator = spec.indexOf(33);
                if (separator == -1) {
                    throw new MalformedURLException("no ! found in jar url spec:" + spec);
                }
                return toFile(new URL(spec.substring(0, separator++)));
            }
            catch (MalformedURLException e) {
                throw new IllegalStateException(e);
            }
        }
        if ("file".equals(url.getProtocol())) {
            String path = JarLocation.decode(url.getFile());
            if (path.endsWith("!")) {
                path = path.substring(0, path.length() - 1);
            }
            return new File(path);
        }
        throw new IllegalArgumentException("Unsupported URL scheme: " + url.toExternalForm());
    }
    
    static {
        DEFAULT_PROVIDER = getDefaultProvider();
    }
    
    private static class Unit
    {
        private String provider;
        private final Set<String> classes;
        private final String name;
        
        public Unit(final String name) {
            this.classes = new HashSet<String>();
            this.name = name;
        }
        
        public String getProvider() {
            return this.provider;
        }
        
        public void setProvider(final String provider) {
            this.provider = provider;
        }
    }
    
    private static class Handler implements PersistenceClassLoaderHandler
    {
        @Override
        public void addTransformer(final String unitId, final ClassLoader classLoader, final ClassFileTransformer classFileTransformer) {
            final Instrumentation instrumentation = Agent.getInstrumentation();
            if (instrumentation != null) {
                instrumentation.addTransformer(new Transformer(classFileTransformer));
            }
        }
        
        @Override
        public void destroy(final String unitId) {
        }
        
        @Override
        public ClassLoader getNewTempClassLoader(final ClassLoader classLoader) {
            return new TempClassLoader(classLoader);
        }
    }
    
    public static class Transformer implements ClassFileTransformer
    {
        private final ClassFileTransformer transformer;
        
        public Transformer(final ClassFileTransformer transformer) {
            this.transformer = transformer;
        }
        
        @Override
        public byte[] transform(final ClassLoader loader, final String className, final Class<?> classBeingRedefined, final ProtectionDomain protectionDomain, final byte[] classfileBuffer) throws IllegalClassFormatException {
            try {
                final byte[] bytes = this.transformer.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
                if (bytes != null) {
                    debug("enhanced " + className);
                }
                return bytes;
            }
            catch (Throwable e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    private static class NullDataSource implements DataSource
    {
        @Override
        public Connection getConnection() throws SQLException {
            return null;
        }
        
        @Override
        public Logger getParentLogger() throws SQLFeatureNotSupportedException {
            return null;
        }
        
        @Override
        public Connection getConnection(final String username, final String password) throws SQLException {
            return null;
        }
        
        @Override
        public int getLoginTimeout() throws SQLException {
            return 0;
        }
        
        @Override
        public PrintWriter getLogWriter() throws SQLException {
            return null;
        }
        
        @Override
        public void setLoginTimeout(final int seconds) throws SQLException {
        }
        
        @Override
        public void setLogWriter(final PrintWriter out) throws SQLException {
        }
        
        @Override
        public boolean isWrapperFor(final Class<?> iface) throws SQLException {
            return false;
        }
        
        @Override
        public <T> T unwrap(final Class<T> iface) throws SQLException {
            throw new SQLException();
        }
    }
}
