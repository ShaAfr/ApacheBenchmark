// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

public class ClientInfo extends CommonInfoObject
{
    public String path;
    public String description;
    public String displayName;
    public String smallIcon;
    public String largeIcon;
    public String moduleId;
    public String mainClass;
    public final List<String> localClients;
    public final List<String> remoteClients;
    public String callbackHandler;
    public final Set<String> watchedResources;
    public final JndiEncInfo jndiEnc;
    public final List<CallbackInfo> postConstruct;
    public final List<CallbackInfo> preDestroy;
    
    public ClientInfo() {
        this.localClients = new ArrayList<String>();
        this.remoteClients = new ArrayList<String>();
        this.watchedResources = new TreeSet<String>();
        this.jndiEnc = new JndiEncInfo();
        this.postConstruct = new ArrayList<CallbackInfo>();
        this.preDestroy = new ArrayList<CallbackInfo>();
    }
}
