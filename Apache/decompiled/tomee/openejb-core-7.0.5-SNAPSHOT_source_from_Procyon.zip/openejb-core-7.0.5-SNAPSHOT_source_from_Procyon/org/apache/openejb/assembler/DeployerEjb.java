// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler;

import org.apache.openejb.util.JavaSecurityManagers;
import java.util.Random;
import java.math.BigInteger;
import java.security.SecureRandom;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.UndeployException;
import org.apache.openejb.NoSuchApplicationException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Closeable;
import org.apache.openejb.config.sys.JaxbOpenejb;
import org.apache.openejb.config.sys.AdditionalDeployments;
import org.apache.openejb.config.sys.Deployments;
import java.io.IOException;
import org.apache.openejb.loader.IO;
import org.apache.openejb.loader.Files;
import org.apache.openejb.loader.provisining.ProvisioningResolver;
import java.util.Iterator;
import org.apache.openejb.config.AppModule;
import org.apache.openejb.assembler.classic.DeploymentExceptionManager;
import javax.validation.ValidationException;
import org.apache.openejb.ClassLoaderUtil;
import java.util.Map;
import org.apache.openejb.config.ConnectorModule;
import org.apache.openejb.config.WebModule;
import org.apache.openejb.config.ClientModule;
import org.apache.openejb.config.EjbModule;
import org.apache.openejb.config.DeploymentModule;
import java.util.TreeMap;
import org.apache.openejb.loader.ProvisioningUtil;
import org.apache.openejb.OpenEJBException;
import java.util.Properties;
import org.apache.openejb.assembler.classic.AppInfo;
import java.util.Collection;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.assembler.classic.Assembler;
import org.apache.openejb.config.ConfigurationFactory;
import org.apache.openejb.config.DeploymentLoader;
import java.io.File;
import org.apache.openejb.util.Logger;
import javax.enterprise.inject.Alternative;
import javax.ejb.TransactionManagementType;
import javax.ejb.TransactionManagement;
import javax.ejb.Remote;
import javax.ejb.LockType;
import javax.ejb.Lock;
import javax.ejb.Singleton;

@Singleton(name = "openejb/Deployer")
@Lock(LockType.READ)
@Remote({ Deployer.class })
@TransactionManagement(TransactionManagementType.BEAN)
@Alternative
public class DeployerEjb implements Deployer
{
    private static final Logger LOGGER;
    public static final String OPENEJB_DEPLOYER_FORCED_APP_ID_PROP = "openejb.deployer.forced.appId";
    public static final String OPENEJB_DEPLOYER_HOST = "openejb.deployer.host";
    public static final String OPENEJB_USE_BINARIES = "openejb.deployer.binaries.use";
    public static final String OPENEJB_PATH_BINARIES = "openejb.deployer.binaries.path";
    public static final String OPENEJB_VALUE_BINARIES = "openejb.deployer.binaries.value";
    public static final String OPENEJB_APP_AUTODEPLOY = "openejb.app.autodeploy";
    public static final ThreadLocal<Boolean> AUTO_DEPLOY;
    private static final File uniqueFile;
    private static final boolean oldWarDeployer;
    private static final String OPENEJB_DEPLOYER_SAVE_DEPLOYMENTS = "openejb.deployer.save-deployments";
    private static final boolean SAVE_DEPLOYMENTS;
    private final DeploymentLoader deploymentLoader;
    private final ConfigurationFactory configurationFactory;
    private final Assembler assembler;
    
    public DeployerEjb() {
        this.deploymentLoader = new DeploymentLoader();
        final ConfigurationFactory component = (ConfigurationFactory)SystemInstance.get().getComponent((Class)ConfigurationFactory.class);
        this.configurationFactory = ((component == null) ? new ConfigurationFactory() : component);
        this.assembler = (Assembler)SystemInstance.get().getComponent((Class)org.apache.openejb.spi.Assembler.class);
    }
    
    @Override
    public String getUniqueFile() {
        return DeployerEjb.uniqueFile.getAbsolutePath();
    }
    
    @Override
    public Collection<AppInfo> getDeployedApps() {
        return this.assembler.getDeployedApplications();
    }
    
    @Override
    public AppInfo deploy(final String location) throws OpenEJBException {
        return this.deploy(location, null);
    }
    
    @Override
    public AppInfo deploy(final Properties properties) throws OpenEJBException {
        return this.deploy(null, properties);
    }
    
    @Override
    public AppInfo deploy(final String inLocation, Properties properties) throws OpenEJBException {
        String rawLocation = inLocation;
        if (rawLocation == null && properties == null) {
            throw new NullPointerException("location and properties are null");
        }
        if (rawLocation == null) {
            rawLocation = properties.getProperty("filename");
        }
        if (properties == null) {
            properties = new Properties();
        }
        AppModule appModule = null;
        File file;
        if ("true".equalsIgnoreCase(properties.getProperty("openejb.deployer.binaries.use", "false"))) {
            file = this.copyBinaries(properties);
        }
        else {
            file = new File(ProvisioningUtil.realLocation(rawLocation).iterator().next());
        }
        final boolean autoDeploy = Boolean.parseBoolean(properties.getProperty("openejb.app.autodeploy", "false"));
        final String host = properties.getProperty("openejb.deployer.host", null);
        if (WebAppDeployer.Helper.isWebApp(file) && !DeployerEjb.oldWarDeployer) {
            DeployerEjb.AUTO_DEPLOY.set(autoDeploy);
            try {
                final AppInfo appInfo = ((WebAppDeployer)SystemInstance.get().getComponent((Class)WebAppDeployer.class)).deploy(host, this.contextRoot(properties, file.getAbsolutePath()), file);
                if (appInfo != null) {
                    this.saveIfNeeded(properties, file, appInfo);
                    return appInfo;
                }
                throw new OpenEJBException("can't deploy " + file.getAbsolutePath());
            }
            finally {
                DeployerEjb.AUTO_DEPLOY.remove();
            }
        }
        AppInfo appInfo = null;
        try {
            appModule = this.deploymentLoader.load(file, null);
            final Map<String, DeploymentModule> modules = new TreeMap<String, DeploymentModule>();
            for (final DeploymentModule module : appModule.getEjbModules()) {
                modules.put(module.getModuleId(), module);
            }
            for (final DeploymentModule module : appModule.getClientModules()) {
                modules.put(module.getModuleId(), module);
            }
            for (final WebModule module2 : appModule.getWebModules()) {
                final String contextRoot = this.contextRoot(properties, module2.getJarLocation());
                if (contextRoot != null) {
                    module2.setContextRoot(contextRoot);
                    module2.setHost(host);
                }
                modules.put(module2.getModuleId(), module2);
            }
            for (final DeploymentModule module : appModule.getConnectorModules()) {
                modules.put(module.getModuleId(), module);
            }
            for (final Map.Entry<Object, Object> entry : properties.entrySet()) {
                String name = entry.getKey();
                if (name.startsWith("altDD/")) {
                    name = name.substring("altDD".length() + 1);
                    final int slash = name.indexOf(47);
                    DeploymentModule module3;
                    if (slash > 0) {
                        final String moduleId = name.substring(0, slash);
                        name = name.substring(slash + 1);
                        module3 = modules.get(moduleId);
                    }
                    else {
                        module3 = appModule;
                    }
                    if (module3 == null) {
                        continue;
                    }
                    final String value = entry.getValue();
                    final File dd = new File(value);
                    if (dd.canRead()) {
                        module3.getAltDDs().put(name, dd.toURI().toURL());
                    }
                    else {
                        module3.getAltDDs().put(name, value);
                    }
                }
            }
            appInfo = this.configurationFactory.configureApplication(appModule);
            appInfo.autoDeploy = autoDeploy;
            if (properties != null && properties.containsKey("openejb.deployer.forced.appId")) {
                appInfo.appId = properties.getProperty("openejb.deployer.forced.appId");
            }
            if (!appInfo.webApps.isEmpty()) {
                appInfo.properties.setProperty("tomcat.unpackWar", "false");
            }
            this.assembler.createApplication(appInfo);
            this.saveIfNeeded(properties, file, appInfo);
            return appInfo;
        }
        catch (Throwable e) {
            if (appModule != null) {
                ClassLoaderUtil.destroyClassLoader(appModule.getJarLocation());
            }
            if (null != appInfo) {
                ClassLoaderUtil.destroyClassLoader(appInfo.appId, appInfo.path);
            }
            DeployerEjb.LOGGER.error("Can't deploy " + inLocation, e);
            if (e instanceof ValidationException) {
                throw (ValidationException)e;
            }
            final DeploymentExceptionManager dem = (DeploymentExceptionManager)SystemInstance.get().getComponent((Class)DeploymentExceptionManager.class);
            Throwable ex;
            if (dem != null) {
                if (dem.hasDeploymentFailed()) {
                    ex = dem.getLastException();
                }
                else {
                    ex = e;
                }
                if (appInfo != null) {
                    dem.clearLastException(appInfo);
                }
            }
            else {
                ex = e;
            }
            if (!(ex instanceof OpenEJBException)) {
                throw new OpenEJBException(ex);
            }
            if (ex.getCause() instanceof ValidationException) {
                throw (ValidationException)ex.getCause();
            }
            throw (OpenEJBException)ex;
        }
    }
    
    private void saveIfNeeded(final Properties properties, final File file, final AppInfo appInfo) {
        if ((DeployerEjb.SAVE_DEPLOYMENTS && null == properties.getProperty("openejb.deployer.save-deployments")) || "true".equalsIgnoreCase(properties.getProperty("openejb.deployer.save-deployments", "false"))) {
            appInfo.properties.setProperty("save-deployment", "true");
            this.saveDeployment(file, true);
        }
    }
    
    private synchronized File copyBinaries(final Properties props) throws OpenEJBException {
        final File dump = ProvisioningResolver.cacheFile(props.getProperty("openejb.deployer.binaries.path", "dump.war"));
        if (dump.exists()) {
            Files.delete(dump);
            final String name = dump.getName();
            if (name.endsWith("ar") && name.length() > 4) {
                final File exploded = new File(dump.getParentFile(), name.substring(0, name.length() - 4));
                if (exploded.exists()) {
                    Files.delete(exploded);
                }
            }
        }
        try {
            IO.copy((byte[])byte[].class.cast(props.get("openejb.deployer.binaries.value")), dump);
        }
        catch (IOException e) {
            throw new OpenEJBException(e);
        }
        return dump;
    }
    
    private synchronized void saveDeployment(final File file, final boolean add) {
        final Deployments deps = new Deployments();
        if (file.isDirectory()) {
            deps.setDir(file.getAbsolutePath());
        }
        else {
            deps.setFile(file.getAbsolutePath());
        }
        File config;
        try {
            config = SystemInstance.get().getBase().getFile("conf/deployments.xml", false);
        }
        catch (IOException e2) {
            config = null;
        }
        if (config == null || !config.getParentFile().exists()) {
            DeployerEjb.LOGGER.info("Cannot save the added app because the conf folder does not exist, it will not be present on a restart");
            return;
        }
        OutputStream os = null;
        try {
            AdditionalDeployments additionalDeployments;
            if (config.exists() && config.length() > 0L) {
                final InputStream fis = IO.read(config);
                try {
                    additionalDeployments = JaxbOpenejb.unmarshal(AdditionalDeployments.class, fis);
                }
                finally {
                    IO.close((Closeable)fis);
                }
            }
            else {
                additionalDeployments = new AdditionalDeployments();
            }
            if (add) {
                if (!additionalDeployments.getDeployments().contains(deps)) {
                    additionalDeployments.getDeployments().add(deps);
                }
            }
            else {
                final Iterator<Deployments> it = additionalDeployments.getDeployments().iterator();
                while (it.hasNext()) {
                    final Deployments current = it.next();
                    if (deps.getDir() != null && deps.getDir().equals(current.getDir())) {
                        it.remove();
                        break;
                    }
                    if (deps.getFile() != null && deps.getFile().equals(current.getFile())) {
                        it.remove();
                        break;
                    }
                    final String jar = deps.getFile();
                    if (jar != null && jar.length() > 3) {
                        final String substring = jar.substring(0, jar.length() - 4);
                        if (substring.equals(current.getDir()) || substring.equals(current.getFile())) {
                            it.remove();
                            break;
                        }
                        continue;
                    }
                    else {
                        final String jarC = current.getFile();
                        if (jarC == null || jarC.length() <= 3) {
                            continue;
                        }
                        final String substring2 = jarC.substring(0, jarC.length() - 4);
                        if (substring2.equals(deps.getDir()) || substring2.equals(deps.getFile())) {
                            it.remove();
                            break;
                        }
                        continue;
                    }
                }
            }
            os = IO.write(config);
            JaxbOpenejb.marshal(AdditionalDeployments.class, additionalDeployments, os);
        }
        catch (Exception e) {
            DeployerEjb.LOGGER.error("cannot save the added app, will not be present next time you'll start", e);
        }
        finally {
            IO.close((Closeable)os);
        }
    }
    
    @Override
    public void undeploy(final String moduleId) throws UndeployException, NoSuchApplicationException {
        AppInfo appInfo = this.assembler.getAppInfo(moduleId);
        if (appInfo == null) {
            appInfo = this.assembler.getAppInfo(ProvisioningUtil.realLocation(moduleId).iterator().next());
            if (appInfo == null) {
                appInfo = this.assembler.getAppInfo(new File(moduleId).getAbsolutePath());
                if (appInfo == null) {
                    appInfo = this.assembler.getAppInfo(new File(ProvisioningUtil.realLocation(moduleId).iterator().next()).getAbsolutePath());
                }
            }
        }
        if (appInfo != null) {
            try {
                this.assembler.destroyApplication(appInfo);
            }
            finally {
                if (appInfo.properties.containsKey("save-deployment")) {
                    this.saveDeployment(new File(moduleId), false);
                }
            }
            return;
        }
        throw new NoSuchApplicationException(moduleId);
    }
    
    private String contextRoot(final Properties properties, final String jarPath) {
        return properties.getProperty("webapp." + jarPath + ".context-root");
    }
    
    @Override
    public void reload(final String moduleId) {
        for (final AppInfo info : this.assembler.getDeployedApplications()) {
            if (info.path.equals(moduleId)) {
                this.reload(info);
                break;
            }
        }
    }
    
    private void reload(final AppInfo info) {
        if (info.webAppAlone) {
            final WebAppDeployer component = (WebAppDeployer)SystemInstance.get().getComponent((Class)WebAppDeployer.class);
            if (null != component) {
                component.reload(info.path);
                return;
            }
        }
        try {
            this.assembler.destroyApplication(info);
            this.assembler.createApplication(info);
        }
        catch (Exception e) {
            throw new OpenEJBRuntimeException(e);
        }
    }
    
    static {
        LOGGER = Logger.getInstance(LogCategory.OPENEJB, DeployerEjb.class);
        AUTO_DEPLOY = new ThreadLocal<Boolean>();
        oldWarDeployer = "old".equalsIgnoreCase(SystemInstance.get().getOptions().get("openejb.deployer.war", "new"));
        SAVE_DEPLOYMENTS = SystemInstance.get().getOptions().get("openejb.deployer.save-deployments", false);
        final String uniqueName = "OpenEJB-" + new BigInteger(128, new SecureRandom()).toString(36);
        final String tempDir = JavaSecurityManagers.getSystemProperty("java.io.tmpdir");
        File unique = null;
        Label_0253: {
            try {
                unique = new File(tempDir, uniqueName).getCanonicalFile();
                if (!unique.createNewFile()) {
                    throw new IOException("Failed to create file in temp: " + unique);
                }
            }
            catch (IOException e) {
                unique = new File(SystemInstance.get().getBase().getDirectory(), "work");
                if (unique.exists()) {
                    try {
                        unique = new File(unique, uniqueName).getCanonicalFile();
                        if (!unique.createNewFile()) {
                            throw new IOException("Failed to create file in work: " + unique);
                        }
                        break Label_0253;
                    }
                    catch (IOException e2) {
                        throw new OpenEJBRuntimeException(e);
                    }
                }
                throw new OpenEJBRuntimeException("cannot create unique file, please set java.io.tmpdir to a writable folder or create work folder", e);
            }
        }
        (uniqueFile = unique).deleteOnExit();
    }
}
