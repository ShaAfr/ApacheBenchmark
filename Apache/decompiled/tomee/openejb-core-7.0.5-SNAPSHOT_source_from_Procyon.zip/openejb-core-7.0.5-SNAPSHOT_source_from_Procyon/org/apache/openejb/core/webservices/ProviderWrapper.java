// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.io.OutputStream;
import org.apache.openejb.OpenEJBRuntimeException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Map;
import javax.xml.ws.soap.SOAPBinding;
import java.util.concurrent.Executor;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.Dispatch;
import java.lang.annotation.Annotation;
import javax.jws.WebService;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.bind.JAXBContext;
import org.apache.openejb.util.LogCategory;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import javax.xml.ws.WebServiceException;
import org.apache.openejb.loader.IO;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Collections;
import javax.xml.ws.WebServiceFeature;
import javax.xml.ws.EndpointReference;
import javax.xml.transform.Source;
import javax.xml.ws.wsaddressing.W3CEndpointReference;
import org.w3c.dom.Element;
import javax.xml.ws.Endpoint;
import javax.xml.ws.spi.ServiceDelegate;
import javax.xml.namespace.QName;
import java.net.URL;
import org.apache.openejb.util.JavaSecurityManagers;
import java.util.Properties;
import org.apache.openejb.core.ivm.naming.JaxWsServiceReference;
import java.lang.reflect.Method;
import java.util.List;
import org.apache.openejb.util.Logger;
import javax.xml.ws.spi.Provider;

public class ProviderWrapper extends Provider
{
    public static final Logger logger;
    private static final String JAXWSPROVIDER_PROPERTY;
    private static final ThreadLocal<ProviderWrapperData> threadPortRefs;
    private final Provider delegate;
    private final List<PortRefData> portRefs;
    private static final Method createW3CEndpointReference;
    private static final Method providerGetPort;
    private static final Method readEndpointReference;
    private static final Method createDispatchReferenceJaxB;
    private static final Method createDispatchReferenceClass;
    private static final Method createDispatchInterface;
    private static final Method createDispatchJaxBContext;
    private static final Method serviceGetPortByEndpointReference;
    private static final Method serviceGetPortByQName;
    private static final Method serviceGetPortByInterface;
    
    public static void beforeCreate(final List<PortRefData> portRefData, final JaxWsServiceReference.WebServiceClientCustomizer customizer, final Properties properties) {
        final String oldProperty = JavaSecurityManagers.getSystemProperty(ProviderWrapper.JAXWSPROVIDER_PROPERTY);
        if (oldProperty != null && !oldProperty.equals(ProviderWrapper.class.getName())) {
            JavaSecurityManagers.setSystemProperty("openejb." + ProviderWrapper.JAXWSPROVIDER_PROPERTY, oldProperty);
            JavaSecurityManagers.setSystemProperty(ProviderWrapper.JAXWSPROVIDER_PROPERTY, ProviderWrapper.class.getName());
        }
        if (oldProperty == null || !oldProperty.equals(ProviderWrapper.class.getName())) {
            JavaSecurityManagers.setSystemProperty(ProviderWrapper.JAXWSPROVIDER_PROPERTY, ProviderWrapper.class.getName());
        }
        final ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
        if (oldClassLoader != null) {
            Thread.currentThread().setContextClassLoader(new ProviderClassLoader(oldClassLoader));
        }
        else {
            Thread.currentThread().setContextClassLoader(new ProviderClassLoader());
        }
        ProviderWrapper.threadPortRefs.set(new ProviderWrapperData(portRefData, oldClassLoader, customizer, properties));
    }
    
    public static void afterCreate() {
        Thread.currentThread().setContextClassLoader(ProviderWrapper.threadPortRefs.get().callerClassLoader);
        ProviderWrapper.threadPortRefs.set(null);
    }
    
    public ProviderWrapper() {
        this.delegate = findProvider();
        this.portRefs = ((ProviderWrapper.threadPortRefs.get() == null) ? null : ProviderWrapper.threadPortRefs.get().portRefData);
    }
    
    public Provider getDelegate() {
        return this.delegate;
    }
    
    public ServiceDelegate createServiceDelegate(final URL wsdlDocumentLocation, final QName serviceName, final Class serviceClass) {
        ServiceDelegate serviceDelegate = this.delegate.createServiceDelegate(wsdlDocumentLocation, serviceName, serviceClass);
        if (ProviderWrapper.threadPortRefs.get() != null) {
            serviceDelegate = new ServiceDelegateWrapper(serviceDelegate);
        }
        return serviceDelegate;
    }
    
    public Endpoint createEndpoint(final String bindingId, final Object implementor) {
        return this.delegate.createEndpoint(bindingId, implementor);
    }
    
    public Endpoint createAndPublishEndpoint(final String address, final Object implementor) {
        return this.delegate.createAndPublishEndpoint(address, implementor);
    }
    
    public W3CEndpointReference createW3CEndpointReference(final String address, final QName serviceName, final QName portName, final List<Element> metadata, final String wsdlDocumentLocation, final List<Element> referenceParameters) {
        return (W3CEndpointReference)invoke21Delegate(this.delegate, ProviderWrapper.createW3CEndpointReference, address, serviceName, portName, metadata, wsdlDocumentLocation, referenceParameters);
    }
    
    public EndpointReference readEndpointReference(final Source source) {
        return (EndpointReference)invoke21Delegate(this.delegate, ProviderWrapper.readEndpointReference, source);
    }
    
    public <T> T getPort(final EndpointReference endpointReference, final Class<T> serviceEndpointInterface, final WebServiceFeature... features) {
        return (T)invoke21Delegate(this.delegate, ProviderWrapper.providerGetPort, endpointReference, serviceEndpointInterface, features);
    }
    
    private static Provider findProvider() {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        if (classLoader == null) {
            classLoader = ClassLoader.getSystemClassLoader();
        }
        String providerClass = JavaSecurityManagers.getSystemProperty("openejb." + ProviderWrapper.JAXWSPROVIDER_PROPERTY);
        Provider provider = createProviderInstance(providerClass, classLoader);
        if (provider != null) {
            return provider;
        }
        try {
            for (final URL url : Collections.list(classLoader.getResources("META-INF/services/" + ProviderWrapper.JAXWSPROVIDER_PROPERTY))) {
                BufferedReader in = null;
                try {
                    in = new BufferedReader(new InputStreamReader(url.openStream()));
                    providerClass = in.readLine();
                    provider = createProviderInstance(providerClass, classLoader);
                    if (provider != null) {
                        return provider;
                    }
                }
                catch (Exception ex) {}
                finally {
                    if (in != null) {
                        try {
                            in.close();
                        }
                        catch (IOException ex2) {}
                    }
                }
            }
        }
        catch (Exception ex3) {}
        final String javaHome = JavaSecurityManagers.getSystemProperty("java.home");
        final File jaxrpcPropertiesFile = new File(new File(javaHome, "lib"), "jaxrpc.properties");
        if (jaxrpcPropertiesFile.exists()) {
            try {
                final Properties properties = IO.readProperties(jaxrpcPropertiesFile);
                providerClass = properties.getProperty(ProviderWrapper.JAXWSPROVIDER_PROPERTY);
                provider = createProviderInstance(providerClass, classLoader);
                if (provider != null) {
                    return provider;
                }
            }
            catch (Exception ex4) {}
        }
        providerClass = JavaSecurityManagers.getSystemProperty(ProviderWrapper.JAXWSPROVIDER_PROPERTY);
        provider = createProviderInstance(providerClass, classLoader);
        if (provider != null) {
            return provider;
        }
        try {
            JavaSecurityManagers.removeSystemProperty(ProviderWrapper.JAXWSPROVIDER_PROPERTY);
            provider = Provider.provider();
            if (provider != null && !provider.getClass().getName().equals(ProviderWrapper.class.getName())) {
                return provider;
            }
        }
        finally {
            JavaSecurityManagers.setSystemProperty(ProviderWrapper.JAXWSPROVIDER_PROPERTY, providerClass);
        }
        throw new WebServiceException("No " + ProviderWrapper.JAXWSPROVIDER_PROPERTY + " implementation found");
    }
    
    private static Provider createProviderInstance(final String providerClass, final ClassLoader classLoader) {
        if (providerClass != null && providerClass.length() > 0 && !providerClass.equals(ProviderWrapper.class.getName())) {
            try {
                final Class<? extends Provider> clazz = classLoader.loadClass(providerClass).asSubclass(Provider.class);
                return (Provider)clazz.newInstance();
            }
            catch (Throwable e) {
                ProviderWrapper.logger.warning("Unable to construct provider implementation " + providerClass, e);
            }
        }
        return null;
    }
    
    private static Object invoke21Delegate(final Object delegate, final Method method, final Object... args) {
        if (method == null) {
            throw new UnsupportedOperationException("JaxWS 2.1 APIs are not supported");
        }
        try {
            return method.invoke(delegate, args);
        }
        catch (IllegalAccessException e) {
            throw new WebServiceException((Throwable)e);
        }
        catch (InvocationTargetException e2) {
            if (e2.getCause() != null) {
                throw new WebServiceException(e2.getCause());
            }
            throw new WebServiceException((Throwable)e2);
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_WS, ProviderWrapper.class);
        JAXWSPROVIDER_PROPERTY = Provider.class.getName();
        threadPortRefs = new ThreadLocal<ProviderWrapperData>();
        Method method = null;
        try {
            method = Provider.class.getMethod("createW3CEndpointReference", String.class, QName.class, QName.class, List.class, String.class, List.class);
        }
        catch (NoSuchMethodException ex) {}
        createW3CEndpointReference = method;
        method = null;
        try {
            method = Provider.class.getMethod("getPort", EndpointReference.class, Class.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex2) {}
        providerGetPort = method;
        method = null;
        try {
            method = Provider.class.getMethod("readEndpointReference", Source.class);
        }
        catch (NoSuchMethodException ex3) {}
        readEndpointReference = method;
        method = null;
        try {
            method = ServiceDelegate.class.getMethod("createDispatch", EndpointReference.class, JAXBContext.class, Service.Mode.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex4) {}
        createDispatchReferenceJaxB = method;
        method = null;
        try {
            method = ServiceDelegate.class.getMethod("createDispatch", EndpointReference.class, Class.class, Service.Mode.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex5) {}
        createDispatchReferenceClass = method;
        method = null;
        try {
            method = ServiceDelegate.class.getMethod("createDispatch", QName.class, JAXBContext.class, Service.Mode.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex6) {}
        createDispatchJaxBContext = method;
        method = null;
        try {
            method = ServiceDelegate.class.getMethod("createDispatch", QName.class, Class.class, Service.Mode.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex7) {}
        createDispatchInterface = method;
        method = null;
        try {
            method = ServiceDelegate.class.getMethod("getPort", EndpointReference.class, Class.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex8) {}
        serviceGetPortByEndpointReference = method;
        method = null;
        try {
            method = ServiceDelegate.class.getMethod("getPort", QName.class, Class.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex9) {}
        serviceGetPortByQName = method;
        method = null;
        try {
            method = ServiceDelegate.class.getMethod("getPort", Class.class, WebServiceFeature[].class);
        }
        catch (NoSuchMethodException ex10) {}
        serviceGetPortByInterface = method;
    }
    
    private static class ProviderWrapperData
    {
        private final List<PortRefData> portRefData;
        private final ClassLoader callerClassLoader;
        private final JaxWsServiceReference.WebServiceClientCustomizer customizer;
        private final Properties properties;
        
        public ProviderWrapperData(final List<PortRefData> portRefData, final ClassLoader callerClassLoader, final JaxWsServiceReference.WebServiceClientCustomizer customizer, final Properties properties) {
            this.portRefData = portRefData;
            this.callerClassLoader = callerClassLoader;
            this.customizer = customizer;
            this.properties = properties;
        }
    }
    
    private class ServiceDelegateWrapper extends ServiceDelegate
    {
        private final ServiceDelegate serviceDelegate;
        private final JaxWsServiceReference.WebServiceClientCustomizer customizer;
        private final Properties configuration;
        
        public ServiceDelegateWrapper(final ServiceDelegate serviceDelegate) {
            this.serviceDelegate = serviceDelegate;
            final ProviderWrapperData providerWrapperData = ProviderWrapper.threadPortRefs.get();
            if (providerWrapperData != null) {
                this.customizer = providerWrapperData.customizer;
                this.configuration = providerWrapperData.properties;
            }
            else {
                this.customizer = null;
                this.configuration = null;
            }
        }
        
        private <T> T customizePort(final T port) {
            if (this.customizer != null && this.configuration != null) {
                this.customizer.customize(port, this.configuration);
            }
            return port;
        }
        
        public <T> T getPort(final QName portName, final Class<T> serviceEndpointInterface) {
            final T t = (T)this.serviceDelegate.getPort(portName, (Class)serviceEndpointInterface);
            this.setProperties((BindingProvider)t, portName);
            return this.customizePort(t);
        }
        
        public <T> T getPort(final Class<T> serviceEndpointInterface) {
            final T t = (T)this.serviceDelegate.getPort((Class)serviceEndpointInterface);
            QName qname = null;
            if (serviceEndpointInterface.isAnnotationPresent((Class<? extends Annotation>)WebService.class)) {
                final WebService webService = serviceEndpointInterface.getAnnotation(WebService.class);
                final String targetNamespace = webService.targetNamespace();
                final String name = webService.name();
                if (targetNamespace != null && targetNamespace.length() > 0 && name != null && name.length() > 0) {
                    qname = new QName(targetNamespace, name);
                }
            }
            this.setProperties((BindingProvider)t, qname);
            return this.customizePort(t);
        }
        
        public void addPort(final QName portName, final String bindingId, final String endpointAddress) {
            this.serviceDelegate.addPort(portName, bindingId, endpointAddress);
        }
        
        public <T> Dispatch<T> createDispatch(final QName portName, final Class<T> type, final Service.Mode mode) {
            final Dispatch<T> dispatch = (Dispatch<T>)this.serviceDelegate.createDispatch(portName, (Class)type, mode);
            this.setProperties((BindingProvider)dispatch, portName);
            return dispatch;
        }
        
        public Dispatch<Object> createDispatch(final QName portName, final JAXBContext context, final Service.Mode mode) {
            final Dispatch<Object> dispatch = (Dispatch<Object>)this.serviceDelegate.createDispatch(portName, context, mode);
            this.setProperties((BindingProvider)dispatch, portName);
            return dispatch;
        }
        
        public <T> Dispatch<T> createDispatch(final QName portName, final Class<T> type, final Service.Mode mode, final WebServiceFeature... features) {
            return (Dispatch<T>)invoke21Delegate(this.serviceDelegate, ProviderWrapper.createDispatchInterface, new Object[] { portName, type, mode, features });
        }
        
        public Dispatch<Object> createDispatch(final QName portName, final JAXBContext context, final Service.Mode mode, final WebServiceFeature... features) {
            return (Dispatch<Object>)invoke21Delegate(this.serviceDelegate, ProviderWrapper.createDispatchJaxBContext, new Object[] { portName, context, mode, features });
        }
        
        public Dispatch<Object> createDispatch(final EndpointReference endpointReference, final JAXBContext context, final Service.Mode mode, final WebServiceFeature... features) {
            return (Dispatch<Object>)invoke21Delegate(this.serviceDelegate, ProviderWrapper.createDispatchReferenceJaxB, new Object[] { endpointReference, context, mode, features });
        }
        
        public <T> Dispatch<T> createDispatch(final EndpointReference endpointReference, final Class<T> type, final Service.Mode mode, final WebServiceFeature... features) {
            return (Dispatch<T>)invoke21Delegate(this.serviceDelegate, ProviderWrapper.createDispatchReferenceClass, new Object[] { endpointReference, type, mode, features });
        }
        
        public <T> T getPort(final QName portName, final Class<T> serviceEndpointInterface, final WebServiceFeature... features) {
            return this.customizePort(invoke21Delegate(this.serviceDelegate, ProviderWrapper.serviceGetPortByQName, new Object[] { portName, serviceEndpointInterface, features }));
        }
        
        public <T> T getPort(final EndpointReference endpointReference, final Class<T> serviceEndpointInterface, final WebServiceFeature... features) {
            return this.customizePort(invoke21Delegate(this.serviceDelegate, ProviderWrapper.serviceGetPortByEndpointReference, new Object[] { endpointReference, serviceEndpointInterface, features }));
        }
        
        public <T> T getPort(final Class<T> serviceEndpointInterface, final WebServiceFeature... features) {
            return this.customizePort(invoke21Delegate(this.serviceDelegate, ProviderWrapper.serviceGetPortByInterface, new Object[] { serviceEndpointInterface, features }));
        }
        
        public QName getServiceName() {
            return this.serviceDelegate.getServiceName();
        }
        
        public Iterator<QName> getPorts() {
            return (Iterator<QName>)this.serviceDelegate.getPorts();
        }
        
        public URL getWSDLDocumentLocation() {
            return this.serviceDelegate.getWSDLDocumentLocation();
        }
        
        public HandlerResolver getHandlerResolver() {
            return this.serviceDelegate.getHandlerResolver();
        }
        
        public void setHandlerResolver(final HandlerResolver handlerResolver) {
            this.serviceDelegate.setHandlerResolver(handlerResolver);
        }
        
        public Executor getExecutor() {
            return this.serviceDelegate.getExecutor();
        }
        
        public void setExecutor(final Executor executor) {
            this.serviceDelegate.setExecutor(executor);
        }
        
        private void setProperties(final BindingProvider proxy, final QName qname) {
            for (final PortRefData portRef : ProviderWrapper.this.portRefs) {
                Class intf = null;
                if (portRef.getServiceEndpointInterface() != null) {
                    try {
                        intf = proxy.getClass().getClassLoader().loadClass(portRef.getServiceEndpointInterface());
                    }
                    catch (Exception ex) {}
                }
                if ((qname != null && qname.equals(portRef.getQName())) || (intf != null && intf.isInstance(proxy))) {
                    if (!portRef.getAddresses().isEmpty()) {
                        proxy.getRequestContext().put("javax.xml.ws.service.endpoint.address", portRef.getAddresses().get(0));
                    }
                    final boolean enableMTOM = portRef.isEnableMtom();
                    if (enableMTOM && proxy.getBinding() instanceof SOAPBinding) {
                        ((SOAPBinding)proxy.getBinding()).setMTOMEnabled(enableMTOM);
                    }
                    for (final Map.Entry<Object, Object> entry : portRef.getProperties().entrySet()) {
                        final String name = entry.getKey();
                        final String value = entry.getValue();
                        proxy.getRequestContext().put(name, value);
                    }
                }
            }
        }
    }
    
    private static class ProviderClassLoader extends ClassLoader
    {
        private static final String PROVIDER_RESOURCE;
        private static final URL PROVIDER_URL;
        
        public ProviderClassLoader() {
        }
        
        public ProviderClassLoader(final ClassLoader parent) {
            super(parent);
        }
        
        @Override
        public Enumeration<URL> getResources(final String name) throws IOException {
            Enumeration<URL> resources = super.getResources(name);
            if (ProviderClassLoader.PROVIDER_RESOURCE.equals(name)) {
                final ArrayList<URL> list = new ArrayList<URL>();
                list.add(ProviderClassLoader.PROVIDER_URL);
                list.addAll(Collections.list(resources));
                resources = Collections.enumeration(list);
            }
            return resources;
        }
        
        @Override
        public URL getResource(final String name) {
            if (ProviderClassLoader.PROVIDER_RESOURCE.equals(name)) {
                return ProviderClassLoader.PROVIDER_URL;
            }
            return super.getResource(name);
        }
        
        static {
            PROVIDER_RESOURCE = "META-INF/services/" + ProviderWrapper.JAXWSPROVIDER_PROPERTY;
            try {
                File tempFile = null;
                try {
                    tempFile = File.createTempFile("openejb-jaxws-provider", "tmp");
                }
                catch (Throwable e) {
                    final File tmp = new File("tmp");
                    if (!tmp.exists() && !tmp.mkdirs()) {
                        throw new IOException("Failed to create local tmp directory: " + tmp.getAbsolutePath());
                    }
                    tempFile = File.createTempFile("openejb-jaxws-provider", "tmp", tmp);
                }
                tempFile.deleteOnExit();
                try (final OutputStream out = IO.write(tempFile)) {
                    out.write(ProviderWrapper.class.getName().getBytes());
                }
                PROVIDER_URL = tempFile.toURI().toURL();
            }
            catch (IOException e2) {
                throw new OpenEJBRuntimeException("Cound not create openejb-jaxws-provider file");
            }
        }
    }
}
