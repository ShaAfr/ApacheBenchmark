// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import java.util.Collections;
import java.util.HashSet;
import javax.ejb.EJBException;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Set;
import javax.transaction.Synchronization;
import org.apache.openejb.loader.SystemInstance;
import javax.transaction.TransactionSynchronizationRegistry;
import java.util.Collection;
import org.apache.openejb.BeanContext;
import java.util.AbstractSet;
import javax.ejb.EJBLocalObject;
import javax.ejb.EntityBean;

public class CmrSet<Bean extends EntityBean, Proxy extends EJBLocalObject> extends AbstractSet
{
    private final EntityBean source;
    private final String sourceProperty;
    private final BeanContext relatedInfo;
    private final String relatedProperty;
    private final Class relatedLocal;
    private boolean mutable;
    private Collection<Bean> relatedBeans;
    
    public CmrSet(final EntityBean source, final String sourceProperty, final BeanContext relatedInfo, final String relatedProperty, final Collection<Bean> relatedBeans) {
        this.mutable = true;
        this.source = source;
        this.sourceProperty = sourceProperty;
        this.relatedInfo = relatedInfo;
        this.relatedProperty = relatedProperty;
        this.relatedBeans = relatedBeans;
        this.relatedLocal = relatedInfo.getLocalInterface();
        final TransactionSynchronizationRegistry transactionRegistry = (TransactionSynchronizationRegistry)SystemInstance.get().getComponent((Class)TransactionSynchronizationRegistry.class);
        try {
            transactionRegistry.registerInterposedSynchronization((Synchronization)new Synchronization() {
                public void beforeCompletion() {
                }
                
                public void afterCompletion(final int i) {
                    CmrSet.this.mutable = false;
                }
            });
        }
        catch (IllegalStateException ignored) {
            this.mutable = false;
        }
    }
    
    protected void entityDeleted() {
        this.relatedBeans = null;
        this.mutable = false;
    }
    
    @Override
    public boolean isEmpty() {
        return this.getRelatedBeans(false, false).isEmpty();
    }
    
    @Override
    public int size() {
        return this.getRelatedBeans(false, false).size();
    }
    
    @Override
    public boolean contains(final Object o) {
        if (this.relatedLocal.isInstance(o)) {
            final Bean entity = this.getEntityBean((EJBLocalObject)o);
            return entity != null && this.getRelatedBeans(false, false).contains(entity);
        }
        return false;
    }
    
    @Override
    public boolean addAll(final Collection c) {
        final Set<Bean> entityBeans = getEntityBeans(c, this.relatedLocal);
        boolean changed = false;
        for (final Bean bean : entityBeans) {
            changed = (this.add(bean) || changed);
        }
        return changed;
    }
    
    @Override
    public boolean add(final Object proxy) {
        if (!this.relatedLocal.isInstance(proxy)) {
            throw new IllegalArgumentException("Object is not an instance of " + this.relatedLocal.getName() + ": " + ((proxy == null) ? "null" : proxy.getClass().getName()));
        }
        final Bean newEntity = this.getEntityBean((EJBLocalObject)proxy);
        if (newEntity == null) {
            throw new IllegalArgumentException("Ejb has been deleted");
        }
        return this.add(newEntity);
    }
    
    private boolean add(final Bean newEntity) {
        final boolean changed = this.getRelatedBeans(true, true).add(newEntity);
        if (changed && this.relatedProperty != null) {
            if (this.source == null) {
                throw new IllegalStateException("source is null");
            }
            final Object oldBackRef = this.toCmp2Entity(newEntity).OpenEJB_addCmr(this.relatedProperty, this.source);
            if (oldBackRef != null) {
                this.toCmp2Entity(oldBackRef).OpenEJB_removeCmr(this.sourceProperty, newEntity);
            }
        }
        return changed;
    }
    
    @Override
    public boolean remove(final Object o) {
        if (!this.relatedLocal.isInstance(o)) {
            return false;
        }
        final Bean entity = this.getEntityBean((EJBLocalObject)o);
        final boolean changed = entity != null && this.getRelatedBeans(false, true).remove(entity);
        if (changed && this.relatedProperty != null) {
            this.toCmp2Entity(entity).OpenEJB_removeCmr(this.relatedProperty, this.source);
        }
        return changed;
    }
    
    @Override
    public boolean retainAll(final Collection c) {
        final Set entityBeans = getEntityBeans(c, null);
        boolean changed = false;
        final Iterator<Bean> iterator = this.getRelatedBeans(false, true).iterator();
        while (iterator.hasNext()) {
            final Bean entity = iterator.next();
            if (!entityBeans.contains(entity)) {
                iterator.remove();
                if (this.relatedProperty != null) {
                    this.toCmp2Entity(entity).OpenEJB_removeCmr(this.relatedProperty, this.source);
                }
                changed = true;
            }
        }
        return changed;
    }
    
    @Override
    public Iterator<Proxy> iterator() {
        return new Iterator<Proxy>() {
            private Bean currentEntity;
            private final Iterator<Bean> iterator = CmrSet.this.getRelatedBeans(true, false).iterator();
            
            @Override
            public boolean hasNext() {
                return this.iterator.hasNext();
            }
            
            @Override
            public Proxy next() {
                if (CmrSet.this.relatedBeans == null) {
                    throw new ConcurrentModificationException("Entity has been deleted therefore this iterator can no longer be used");
                }
                this.currentEntity = this.iterator.next();
                return (Proxy)CmrSet.this.getEjbProxy(this.currentEntity);
            }
            
            @Override
            public void remove() {
                if (CmrSet.this.relatedBeans == null) {
                    throw new ConcurrentModificationException("Entity has been deleted therefore this iterator can no longer be used");
                }
                if (!CmrSet.this.mutable) {
                    throw new ConcurrentModificationException("Transaction has completed therefore this cmr collection can no longer be modified");
                }
                this.iterator.remove();
                if (CmrSet.this.relatedProperty != null) {
                    CmrSet.this.toCmp2Entity(this.currentEntity).OpenEJB_removeCmr(CmrSet.this.relatedProperty, CmrSet.this.source);
                }
            }
        };
    }
    
    private Proxy getEjbProxy(final Bean entity) throws EJBException {
        if (entity == null) {
            return null;
        }
        final Proxy ejbProxy = Cmp2Util.getEjbProxy(this.relatedInfo, entity);
        return ejbProxy;
    }
    
    private Bean getEntityBean(final EJBLocalObject proxy) {
        if (proxy == null) {
            return null;
        }
        final Bean bean = Cmp2Util.getEntityBean(proxy);
        return bean;
    }
    
    private static <Bean extends EntityBean> Set<Bean> getEntityBeans(final Collection<?> proxies, final Class type) {
        if (proxies == null) {
            return null;
        }
        final Set<Bean> entities = new HashSet<Bean>();
        for (final Object value : proxies) {
            if (type != null && !type.isInstance(value)) {
                throw new IllegalArgumentException("Object is not an instance of " + type.getName() + ": " + ((value == null) ? "null" : value.getClass().getName()));
            }
            final Bean entity = Cmp2Util.getEntityBean((EJBLocalObject)value);
            if (entity == null) {
                throw new IllegalArgumentException("Entity has been deleted");
            }
            entities.add(entity);
        }
        return entities;
    }
    
    private Cmp2Entity toCmp2Entity(final Object object) {
        return (Cmp2Entity)object;
    }
    
    private Collection<Bean> getRelatedBeans(final boolean mustExist, final boolean mutateOpation) {
        if (this.relatedBeans == null) {
            if (mustExist) {
                throw new IllegalStateException("Entity has been deleted therefore this cmr collection can no longer be modified");
            }
            return (Collection<Bean>)Collections.emptySet();
        }
        else {
            if (mutateOpation && !this.mutable) {
                throw new IllegalStateException("Transaction has completed therefore this cmr collection can no longer be modified");
            }
            return this.relatedBeans;
        }
    }
}
