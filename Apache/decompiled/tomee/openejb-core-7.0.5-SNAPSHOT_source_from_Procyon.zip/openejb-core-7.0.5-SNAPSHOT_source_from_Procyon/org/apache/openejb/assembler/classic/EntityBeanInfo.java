// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class EntityBeanInfo extends EnterpriseBeanInfo
{
    public String abstractSchemaName;
    public String primKeyClass;
    public String primKeyField;
    public String persistenceType;
    public String reentrant;
    public final List<String> cmpFieldNames;
    public final List<CmrFieldInfo> cmrFields;
    public int cmpVersion;
    public final List<QueryInfo> queries;
    
    public EntityBeanInfo() {
        this.cmpFieldNames = new ArrayList<String>();
        this.cmrFields = new ArrayList<CmrFieldInfo>();
        this.queries = new ArrayList<QueryInfo>();
        this.type = 0;
    }
}
