// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.util.Collection;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.xml.namespace.QName;

public class PortRefData
{
    private QName qname;
    private String serviceEndpointInterface;
    private boolean enableMtom;
    private final Properties properties;
    private final List<String> addresses;
    
    public PortRefData() {
        this.properties = new Properties();
        this.addresses = new ArrayList<String>(1);
    }
    
    public PortRefData(final PortRefData src) {
        this.properties = new Properties();
        this.addresses = new ArrayList<String>(1);
        this.qname = src.qname;
        this.serviceEndpointInterface = src.serviceEndpointInterface;
        this.enableMtom = src.enableMtom;
        this.properties.putAll(src.properties);
        this.addresses.addAll(src.addresses);
    }
    
    public QName getQName() {
        return this.qname;
    }
    
    public void setQName(final QName qname) {
        this.qname = qname;
    }
    
    public String getServiceEndpointInterface() {
        return this.serviceEndpointInterface;
    }
    
    public void setServiceEndpointInterface(final String serviceEndpointInterface) {
        this.serviceEndpointInterface = serviceEndpointInterface;
    }
    
    public boolean isEnableMtom() {
        return this.enableMtom;
    }
    
    public void setEnableMtom(final boolean value) {
        this.enableMtom = value;
    }
    
    public Properties getProperties() {
        return this.properties;
    }
    
    public List<String> getAddresses() {
        return this.addresses;
    }
}
