// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import org.apache.openejb.OpenEJBRuntimeException;
import javax.xml.ws.WebServiceFeature;
import javax.xml.ws.handler.HandlerResolver;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.openejb.core.webservices.ServiceRefData;
import javax.naming.Context;
import org.apache.openejb.core.webservices.HandlerResolverImpl;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.apache.openejb.core.webservices.ProviderWrapper;
import org.apache.openejb.loader.SystemInstance;
import java.util.HashMap;
import java.net.MalformedURLException;
import org.apache.openejb.core.webservices.PortAddress;
import java.util.ArrayList;
import org.apache.openejb.core.webservices.PortRefData;
import org.apache.openejb.core.webservices.PortAddressRegistry;
import java.util.Properties;
import org.apache.openejb.Injection;
import java.util.Collection;
import org.apache.openejb.core.webservices.HandlerChainData;
import java.util.List;
import java.net.URL;
import javax.xml.ws.Service;
import javax.xml.namespace.QName;

public class JaxWsServiceReference extends Reference
{
    private final String id;
    private final QName serviceQName;
    private final QName portQName;
    private final Class<? extends Service> serviceClass;
    private final Class<?> referenceClass;
    private final URL wsdlUrl;
    private final List<HandlerChainData> handlerChains;
    private final Collection<Injection> injections;
    private final Properties properties;
    private PortAddressRegistry portAddressRegistry;
    private final List<PortRefData> portRefs;
    
    public JaxWsServiceReference(final String id, final QName serviceQName, final Class<? extends Service> serviceClass, final QName portQName, final Class<?> referenceClass, final URL wsdlUrl, final List<PortRefData> portRefs, final List<HandlerChainData> handlerChains, final Collection<Injection> injections, final Properties properties) {
        this.handlerChains = new ArrayList<HandlerChainData>();
        this.portRefs = new ArrayList<PortRefData>();
        this.id = id;
        this.properties = properties;
        this.serviceQName = serviceQName;
        this.serviceClass = serviceClass;
        this.portQName = portQName;
        this.referenceClass = referenceClass;
        this.wsdlUrl = wsdlUrl;
        if (portRefs != null) {
            this.portRefs.addAll(portRefs);
        }
        if (handlerChains != null) {
            this.handlerChains.addAll(handlerChains);
        }
        this.injections = injections;
    }
    
    @Override
    public Object getObject() throws NamingException {
        final String referenceClassName = (this.referenceClass != null) ? this.referenceClass.getName() : null;
        final Set<PortAddress> portAddresses = this.getPortAddressRegistry().getPorts(this.id, this.serviceQName, referenceClassName);
        URL wsdlUrl = this.wsdlUrl;
        QName serviceQName = this.serviceQName;
        if (portAddresses.size() == 1) {
            final PortAddress portAddress = portAddresses.iterator().next();
            try {
                wsdlUrl = new URL(portAddress.getAddress() + "?wsdl");
            }
            catch (MalformedURLException ex) {}
            serviceQName = portAddress.getServiceQName();
        }
        final Map<QName, PortRefData> portsByQName = new HashMap<QName, PortRefData>();
        final List<PortRefData> ports = new ArrayList<PortRefData>(this.portRefs.size() + portAddresses.size());
        for (final PortRefData portRef : this.portRefs) {
            final PortRefData port = new PortRefData(portRef);
            if (port.getQName() != null) {
                portsByQName.put(port.getQName(), port);
            }
            ports.add(port);
        }
        for (final PortAddress portAddress2 : portAddresses) {
            PortRefData port = portsByQName.get(portAddress2.getPortQName());
            if (port == null) {
                port = new PortRefData();
                port.setQName(portAddress2.getPortQName());
                port.setServiceEndpointInterface(portAddress2.getServiceEndpointInterface());
                port.getAddresses().add(portAddress2.getAddress());
                ports.add(port);
            }
            else {
                port.getAddresses().add(portAddress2.getAddress());
                if (port.getServiceEndpointInterface() != null) {
                    continue;
                }
                port.setServiceEndpointInterface(portAddress2.getServiceEndpointInterface());
            }
        }
        final WebServiceClientCustomizer customizer = (WebServiceClientCustomizer)SystemInstance.get().getComponent((Class)WebServiceClientCustomizer.class);
        final Properties configuration = (this.properties == null) ? new Properties() : this.properties;
        ProviderWrapper.beforeCreate(ports, customizer, this.properties);
        Service instance;
        try {
            instance = null;
            if (Service.class.equals(this.serviceClass)) {
                instance = Service.create(wsdlUrl, serviceQName);
            }
            else {
                try {
                    instance = (Service)this.serviceClass.getConstructor(URL.class, QName.class).newInstance(wsdlUrl, serviceQName);
                }
                catch (Throwable e) {
                    throw (NamingException)new NamingException("Could not instantiate jax-ws service class " + this.serviceClass.getName()).initCause(e);
                }
            }
        }
        finally {
            ProviderWrapper.afterCreate();
        }
        if (!this.handlerChains.isEmpty()) {
            final HandlerResolver handlerResolver = (HandlerResolver)new HandlerResolverImpl(this.handlerChains, this.injections, new InitialContext());
            instance.setHandlerResolver(handlerResolver);
        }
        Object port2;
        if (this.referenceClass != null && !Service.class.isAssignableFrom(this.referenceClass)) {
            final WebServiceFeature[] features = (WebServiceFeature[])((customizer == null) ? null : customizer.features(serviceQName, configuration));
            if (features == null || features.length == 0) {
                port2 = instance.getPort((Class)this.referenceClass);
            }
            else {
                port2 = instance.getPort((Class)this.referenceClass, features);
            }
        }
        else {
            port2 = instance;
        }
        final ServiceRefData serviceRefData = new ServiceRefData(this.id, serviceQName, this.serviceClass, this.portQName, this.referenceClass, wsdlUrl, this.handlerChains, this.portRefs);
        ServiceRefData.putServiceRefData(port2, serviceRefData);
        return port2;
    }
    
    private PortAddressRegistry getPortAddressRegistry() {
        if (this.portAddressRegistry == null) {
            this.portAddressRegistry = (PortAddressRegistry)SystemInstance.get().getComponent((Class)PortAddressRegistry.class);
            if (this.portAddressRegistry == null) {
                throw new OpenEJBRuntimeException("No port address registry, it generally means you either didn't activate cxf or don't use tomee+");
            }
        }
        return this.portAddressRegistry;
    }
    
    public interface WebServiceClientCustomizer
    {
        WebServiceFeature[] features(final QName p0, final Properties p1);
        
        void customize(final Object p0, final Properties p1);
    }
}
