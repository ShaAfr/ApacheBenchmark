// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import java.io.PrintWriter;
import java.io.PrintStream;
import org.apache.openejb.OpenEJBException;

public class NamingException extends javax.naming.NamingException
{
    private final OpenEJBException delegate;
    
    public NamingException(final String message, final OpenEJBException delegateArg) {
        super(message);
        this.delegate = delegateArg;
    }
    
    public NamingException(final String message, final Throwable rootCause) {
        this.delegate = new OpenEJBException(message, rootCause);
    }
    
    @Override
    public String getMessage() {
        return this.delegate.getMessage();
    }
    
    @Override
    public void printStackTrace() {
        this.delegate.printStackTrace();
    }
    
    @Override
    public void printStackTrace(final PrintStream stream) {
        this.delegate.printStackTrace(stream);
    }
    
    @Override
    public void printStackTrace(final PrintWriter writer) {
        this.delegate.printStackTrace(writer);
    }
}
