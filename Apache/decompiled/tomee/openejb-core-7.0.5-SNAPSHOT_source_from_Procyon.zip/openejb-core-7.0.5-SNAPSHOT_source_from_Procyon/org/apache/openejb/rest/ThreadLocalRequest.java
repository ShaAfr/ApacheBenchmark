// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.ws.rs.core.Variant;
import java.util.List;
import java.util.Date;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.Request;

public class ThreadLocalRequest extends AbstractRestThreadLocalProxy<Request> implements Request
{
    protected ThreadLocalRequest() {
        super(Request.class);
    }
    
    public Response.ResponseBuilder evaluatePreconditions(final EntityTag eTag) {
        return this.get().evaluatePreconditions(eTag);
    }
    
    public Response.ResponseBuilder evaluatePreconditions(final Date lastModified) {
        return this.get().evaluatePreconditions(lastModified);
    }
    
    public Response.ResponseBuilder evaluatePreconditions(final Date lastModified, final EntityTag eTag) {
        return this.get().evaluatePreconditions(lastModified, eTag);
    }
    
    public Variant selectVariant(final List<Variant> vars) throws IllegalArgumentException {
        return this.get().selectVariant((List)vars);
    }
    
    public String getMethod() {
        return this.get().getMethod();
    }
    
    public Response.ResponseBuilder evaluatePreconditions() {
        return this.get().evaluatePreconditions();
    }
}
