// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import javax.transaction.Synchronization;
import org.apache.openejb.loader.SystemInstance;
import javax.transaction.TransactionSynchronizationRegistry;

public class TransactionSynchronizationRegistryWrapper implements TransactionSynchronizationRegistry
{
    private SystemInstance system;
    private TransactionSynchronizationRegistry registry;
    
    public TransactionSynchronizationRegistryWrapper() {
        final SystemInstance system = SystemInstance.get();
        this.registry = (TransactionSynchronizationRegistry)system.getComponent((Class)TransactionSynchronizationRegistry.class);
        this.system = system;
    }
    
    public TransactionSynchronizationRegistry getRegistry() {
        final SystemInstance system = SystemInstance.get();
        if (system != this.system) {
            this.registry = (TransactionSynchronizationRegistry)system.getComponent((Class)TransactionSynchronizationRegistry.class);
            this.system = system;
        }
        return this.registry;
    }
    
    public Object getResource(final Object o) {
        return this.getRegistry().getResource(o);
    }
    
    public boolean getRollbackOnly() {
        return this.getRegistry().getRollbackOnly();
    }
    
    public Object getTransactionKey() {
        return this.getRegistry().getTransactionKey();
    }
    
    public int getTransactionStatus() {
        return this.getRegistry().getTransactionStatus();
    }
    
    public void putResource(final Object o, final Object o1) {
        this.getRegistry().putResource(o, o1);
    }
    
    public void registerInterposedSynchronization(final Synchronization synchronization) {
        this.getRegistry().registerInterposedSynchronization(synchronization);
    }
    
    public void setRollbackOnly() {
        this.getRegistry().setRollbackOnly();
    }
}
