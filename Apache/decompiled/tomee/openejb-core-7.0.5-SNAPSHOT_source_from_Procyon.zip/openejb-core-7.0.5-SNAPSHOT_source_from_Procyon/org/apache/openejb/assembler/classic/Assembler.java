// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.io.ObjectStreamException;
import java.io.InvalidObjectException;
import org.apache.openejb.observer.Observes;
import java.lang.instrument.Instrumentation;
import org.apache.openejb.javaagent.Agent;
import java.util.TreeMap;
import java.lang.instrument.ClassFileTransformer;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.webbeans.logger.JULLoggerFactory;
import org.apache.openejb.assembler.classic.util.ServiceInfos;
import org.apache.openejb.core.TransactionSynchronizationRegistryWrapper;
import org.apache.openejb.core.SimpleTransactionSynchronizationRegistry;
import org.apache.openejb.core.CoreUserTransaction;
import javax.resource.cci.Connection;
import javax.resource.spi.BootstrapContext;
import javax.resource.spi.work.WorkManager;
import java.util.concurrent.Executor;
import java.io.InputStream;
import org.apache.openejb.assembler.classic.event.ResourceCreated;
import javax.resource.cci.ConnectionFactory;
import org.apache.xbean.recipe.Option;
import org.apache.openejb.resource.GeronimoConnectionManagerFactory;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ResourceAdapterInternalException;
import org.apache.openejb.core.transaction.SimpleBootstrapContext;
import javax.resource.spi.XATerminator;
import org.apache.geronimo.connector.GeronimoBootstrapContext;
import org.apache.openejb.core.transaction.SimpleWorkManager;
import org.apache.geronimo.connector.work.GeronimoWorkManager;
import org.apache.geronimo.connector.work.WorkContextHandler;
import org.apache.geronimo.connector.work.HintsContextHandler;
import org.apache.openejb.core.security.SecurityContextHandler;
import org.apache.geronimo.transaction.manager.XAWork;
import org.apache.geronimo.connector.work.TransactionContextHandler;
import org.apache.geronimo.transaction.manager.GeronimoTransactionManager;
import org.apache.openejb.util.ExecutorBuilder;
import org.apache.openejb.util.classloader.ClassLoaderAwareHandler;
import java.io.Externalizable;
import java.net.MalformedURLException;
import org.apache.openejb.util.classloader.URLClassLoaderFirst;
import org.apache.openejb.util.PropertiesHelper;
import org.apache.openejb.loader.IO;
import java.io.ByteArrayInputStream;
import org.apache.openejb.util.PropertyPlaceHolderHelper;
import org.apache.xbean.recipe.ConstructionException;
import org.apache.openejb.util.SuperProperties;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.openejb.resource.PropertiesFactory;
import java.util.concurrent.Callable;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.util.proxy.ProxyFactory;
import org.apache.xbean.recipe.ObjectRecipe;
import org.apache.openejb.assembler.monitoring.JMXContainer;
import org.apache.xbean.recipe.UnsetPropertiesRecipe;
import java.util.Hashtable;
import javax.naming.InitialContext;
import org.apache.openejb.util.URLs;
import org.apache.xbean.finder.ClassLoaders;
import org.apache.openejb.classloader.CompositeClassLoaderConfigurer;
import org.apache.openejb.classloader.ClassLoaderConfigurer;
import org.apache.openejb.config.QuickJarsTxtParser;
import org.apache.openejb.component.ClassLoaderEnricher;
import org.apache.openejb.loader.JarLocation;
import org.apache.openejb.jpa.integration.MakeTxLookup;
import org.apache.openejb.core.ivm.naming.LazyObjectReference;
import javax.servlet.ServletContext;
import org.apache.openejb.core.ivm.naming.ContextualJndiReference;
import javax.management.MalformedObjectNameException;
import javax.management.MBeanRegistrationException;
import javax.management.InstanceNotFoundException;
import org.apache.openejb.config.TldScanner;
import org.apache.webbeans.spi.ContainerLifecycle;
import org.apache.openejb.assembler.classic.event.AssemblerBeforeApplicationDestroyed;
import javax.resource.spi.ConnectionManager;
import javax.sql.DataSource;
import org.apache.geronimo.connector.outbound.AbstractConnectionManager;
import org.apache.openejb.core.ConnectorReference;
import org.apache.openejb.resource.jdbc.DataSourceFactory;
import org.apache.openejb.assembler.classic.event.ResourceBeforeDestroyed;
import java.lang.management.ThreadInfo;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeoutException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import java.lang.management.ManagementFactory;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.Executors;
import org.apache.openejb.util.DaemonThreadFactory;
import org.apache.openejb.util.Duration;
import javax.resource.spi.ResourceAdapter;
import java.util.LinkedList;
import javax.naming.Binding;
import javax.naming.NamingEnumeration;
import org.apache.openejb.api.resource.DestroyableResource;
import org.apache.openejb.assembler.classic.event.AssemblerDestroyed;
import org.apache.openejb.persistence.JtaEntityManagerRegistry;
import org.apache.openejb.NoSuchApplicationException;
import org.apache.openejb.UndeployException;
import org.apache.openejb.assembler.classic.event.ContainerSystemPreDestroy;
import org.apache.openejb.util.References;
import java.util.Comparator;
import org.apache.openejb.core.transaction.JtaTransactionPolicyFactory;
import org.apache.xbean.finder.ResourceFinder;
import org.apache.openejb.cdi.OpenEJBTransactionService;
import org.apache.webbeans.spi.TransactionService;
import org.apache.openejb.cdi.CdiResourceInjectionService;
import org.apache.webbeans.spi.ResourceInjectionService;
import org.apache.openejb.cdi.CdiAppContextsService;
import org.apache.webbeans.spi.ContextsService;
import org.apache.openejb.cdi.ManagedSecurityService;
import org.apache.openejb.cdi.OptimizedLoaderService;
import org.apache.webbeans.spi.LoaderService;
import org.apache.openejb.cdi.CustomELAdapter;
import org.apache.webbeans.spi.adaptor.ELAdaptor;
import org.apache.openejb.cdi.OpenEJBBeanInfoService;
import org.apache.webbeans.spi.BeanArchiveService;
import org.apache.openejb.cdi.CdiScanner;
import org.apache.webbeans.spi.ScannerService;
import org.apache.openejb.cdi.OpenEJBJndiService;
import org.apache.webbeans.spi.JNDIService;
import javax.management.MBeanServer;
import javax.enterprise.context.Dependent;
import org.apache.openejb.monitoring.DynamicMBeanWrapper;
import org.apache.openejb.monitoring.ObjectNameBuilder;
import org.apache.openejb.api.jmx.MBean;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.monitoring.LocalMBeanServer;
import org.apache.webbeans.config.WebBeansContext;
import org.apache.openejb.Container;
import org.apache.openejb.assembler.classic.event.BeforeStartEjbs;
import java.lang.reflect.Constructor;
import org.apache.openejb.core.timer.MemoryTimerStore;
import java.util.Arrays;
import org.apache.openejb.DeploymentContext;
import org.apache.openejb.core.timer.TimerStore;
import org.apache.openejb.core.transaction.TransactionPolicyFactory;
import org.apache.openejb.core.ivm.IntraVmProxy;
import java.io.Serializable;
import org.apache.openejb.core.timer.NullEjbTimerServiceImpl;
import org.apache.openejb.core.timer.EjbTimerService;
import org.apache.openejb.core.timer.ScheduleData;
import org.apache.openejb.core.timer.EjbTimerServiceImpl;
import org.apache.openejb.MethodContext;
import org.apache.openejb.core.transaction.TransactionType;
import org.apache.openejb.BeanType;
import org.apache.openejb.quartz.Scheduler;
import org.apache.openejb.util.Contexts;
import org.apache.openejb.util.URISupport;
import org.apache.openejb.util.Join;
import org.apache.webbeans.container.BeanManagerImpl;
import java.lang.reflect.Method;
import org.apache.openejb.util.SetAccessible;
import org.apache.webbeans.inject.OWBInjector;
import javax.enterprise.context.spi.Contextual;
import javax.annotation.PreDestroy;
import javax.annotation.PostConstruct;
import java.util.Collections;
import org.apache.xbean.finder.archive.ClassesArchive;
import org.apache.openejb.util.Classes;
import org.apache.xbean.finder.archive.Archive;
import org.apache.xbean.finder.AnnotationFinder;
import javax.transaction.TransactionSynchronizationRegistry;
import javax.enterprise.inject.spi.BeanManager;
import org.apache.webbeans.spi.api.ResourceReference;
import javax.annotation.Resource;
import org.apache.openejb.core.ivm.naming.JndiUrlReference;
import org.apache.openejb.core.ivm.naming.Reference;
import javax.enterprise.inject.spi.DefinitionException;
import org.apache.openejb.cdi.CdiPlugin;
import javax.ejb.EJB;
import org.apache.webbeans.component.ResourceBean;
import javax.enterprise.inject.spi.Bean;
import org.apache.openejb.core.WebContext;
import org.apache.openejb.core.ivm.ContextHandler;
import org.apache.openejb.core.ivm.naming.IvmContext;
import java.io.File;
import javax.naming.Context;
import javax.enterprise.inject.spi.DeploymentException;
import org.apache.openejb.assembler.classic.event.AssemblerAfterApplicationCreated;
import org.apache.openejb.cdi.CdiBuilder;
import java.util.List;
import org.apache.openejb.BeanContext;
import javax.naming.NameAlreadyBoundException;
import javax.validation.Validator;
import javax.validation.ValidationException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import javax.validation.ValidatorFactory;
import org.apache.openejb.async.AsynchronousPool;
import org.apache.openejb.ClassLoaderUtil;
import java.net.URI;
import org.apache.openejb.Injection;
import java.net.URISyntaxException;
import java.util.ArrayList;
import org.apache.openejb.loader.ProvisioningUtil;
import javax.naming.NamingException;
import java.util.Iterator;
import org.apache.openejb.assembler.classic.event.ContainerSystemPostCreate;
import org.apache.openejb.DuplicateDeploymentIdException;
import org.apache.openejb.AppContext;
import org.apache.openejb.batchee.BatchEEServiceManager;
import org.apache.openejb.util.OpenEJBErrorHandler;
import org.apache.openejb.util.JavaSecurityManagers;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.config.ConfigurationFactory;
import org.apache.openejb.loader.Options;
import java.util.Properties;
import java.util.Collection;
import java.io.IOException;
import org.apache.openejb.Extensions;
import java.net.URL;
import org.apache.openejb.config.NewLoaderLogic;
import org.apache.xbean.finder.UrlSet;
import org.apache.openejb.core.ParentClassLoaderFinder;
import org.apache.openejb.assembler.classic.event.AssemblerCreated;
import org.apache.openejb.core.ServerFederation;
import org.apache.openejb.spi.ApplicationServer;
import org.apache.openejb.util.LogCategory;
import java.util.HashSet;
import java.util.HashMap;
import org.apache.openejb.core.JndiFactory;
import org.apache.openejb.core.ivm.naming.IvmJndiFactory;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import org.apache.openejb.util.SafeToolkit;
import org.apache.openejb.monitoring.remote.RemoteResourceMonitor;
import java.util.Set;
import javax.enterprise.context.spi.CreationalContext;
import javax.management.ObjectName;
import java.util.Map;
import org.apache.openejb.spi.SecurityService;
import javax.transaction.TransactionManager;
import org.apache.openejb.persistence.PersistenceClassLoaderHandler;
import org.apache.openejb.core.CoreContainerSystem;
import org.apache.openejb.util.Logger;
import org.apache.openejb.util.Messages;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.openejb.JndiConstants;

public class Assembler extends AssemblerTool implements org.apache.openejb.spi.Assembler, JndiConstants
{
    public static final String OPENEJB_URL_PKG_PREFIX;
    public static final String OPENEJB_JPA_DEPLOY_TIME_ENHANCEMENT_PROP = "openejb.jpa.deploy-time-enhancement";
    public static final String PROPAGATE_APPLICATION_EXCEPTIONS = "openejb.propagate.application-exceptions";
    private static final String GLOBAL_UNIQUE_ID = "global";
    public static final String TIMER_STORE_CLASS = "timerStore.class";
    private static final ReentrantLock lock;
    public static final String OPENEJB_TIMERS_ON = "openejb.timers.on";
    static final String FORCE_READ_ONLY_APP_NAMING = "openejb.forceReadOnlyAppNamingContext";
    public static final Class<?>[] VALIDATOR_FACTORY_INTERFACES;
    public static final Class<?>[] VALIDATOR_INTERFACES;
    private final boolean skipLoaderIfPossible;
    Messages messages;
    public final Logger logger;
    public final String resourceDestroyTimeout;
    public final boolean threadStackOnTimeout;
    private final CoreContainerSystem containerSystem;
    private final PersistenceClassLoaderHandler persistenceClassLoaderHandler;
    private final JndiBuilder jndiBuilder;
    private TransactionManager transactionManager;
    private SecurityService securityService;
    protected OpenEjbConfigurationFactory configFactory;
    private final Map<String, AppInfo> deployedApplications;
    private final Map<ObjectName, CreationalContext> creationalContextForAppMbeans;
    private final Set<ObjectName> containerObjectNames;
    private final RemoteResourceMonitor remoteResourceMonitor;
    protected SafeToolkit toolkit;
    protected OpenEjbConfiguration config;
    private static final ThreadLocal<Map<String, Object>> context;
    
    @Override
    public ContainerSystem getContainerSystem() {
        return this.containerSystem;
    }
    
    @Override
    public TransactionManager getTransactionManager() {
        return this.transactionManager;
    }
    
    @Override
    public SecurityService getSecurityService() {
        return this.securityService;
    }
    
    public void addDeploymentListener(final DeploymentListener deploymentListener) {
        final ReentrantLock l = Assembler.lock;
        l.lock();
        try {
            this.logger.warning("DeploymentListener API is replaced by @Observes event");
            SystemInstance.get().addObserver((Object)new DeploymentListenerObserver(deploymentListener));
        }
        finally {
            l.unlock();
        }
    }
    
    public void removeDeploymentListener(final DeploymentListener deploymentListener) {
        final ReentrantLock l = Assembler.lock;
        l.lock();
        try {
            SystemInstance.get().removeObserver((Object)new DeploymentListenerObserver(deploymentListener));
        }
        finally {
            l.unlock();
        }
    }
    
    public Assembler() {
        this(new IvmJndiFactory());
    }
    
    public Assembler(final JndiFactory jndiFactory) {
        this.messages = new Messages(Assembler.class.getPackage().getName());
        this.deployedApplications = new HashMap<String, AppInfo>();
        this.creationalContextForAppMbeans = new HashMap<ObjectName, CreationalContext>();
        this.containerObjectNames = new HashSet<ObjectName>();
        this.remoteResourceMonitor = new RemoteResourceMonitor();
        this.toolkit = SafeToolkit.getToolkit("Assembler");
        this.logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, Assembler.class);
        this.skipLoaderIfPossible = "true".equalsIgnoreCase(SystemInstance.get().getProperty("openejb.classloader.skip-app-loader-if-possible", "true"));
        this.resourceDestroyTimeout = SystemInstance.get().getProperty("openejb.resources.destroy.timeout");
        this.threadStackOnTimeout = "true".equals(SystemInstance.get().getProperty("openejb.resources.destroy.stack-on-timeout", "false"));
        this.persistenceClassLoaderHandler = new PersistenceClassLoaderHandlerImpl();
        installNaming();
        final SystemInstance system = SystemInstance.get();
        system.setComponent((Class)org.apache.openejb.spi.Assembler.class, (Object)this);
        system.setComponent((Class)Assembler.class, (Object)this);
        system.setComponent((Class)ContainerSystem.class, (Object)(this.containerSystem = new CoreContainerSystem(jndiFactory)));
        this.jndiBuilder = new JndiBuilder(this.containerSystem.getJNDIContext());
        this.setConfiguration(new OpenEjbConfiguration());
        final ApplicationServer appServer = (ApplicationServer)system.getComponent((Class)ApplicationServer.class);
        if (appServer == null) {
            system.setComponent((Class)ApplicationServer.class, (Object)new ServerFederation());
        }
        system.setComponent((Class)EjbResolver.class, (Object)new EjbResolver(null, EjbResolver.Scope.GLOBAL, new EjbJarInfo[0]));
        this.installExtensions();
        system.fireEvent((Object)new AssemblerCreated());
        this.initBValFiltering();
    }
    
    private void initBValFiltering() {
        if ("true".equals(SystemInstance.get().getProperty("openejb.cdi.bval.filter", "true"))) {
            try {
                final ClassLoader loader = ParentClassLoaderFinder.Helper.get();
                final Object filter = loader.loadClass("org.apache.openejb.bval.BValCdiFilter").newInstance();
                loader.loadClass("org.apache.bval.cdi.BValExtension").getMethod("setAnnotatedTypeFilter", loader.loadClass("org.apache.bval.cdi.BValExtension$AnnotatedTypeFilter")).invoke(null, filter);
            }
            catch (Throwable t) {}
        }
    }
    
    private void installExtensions() {
        try {
            final Collection<URL> urls = (Collection<URL>)NewLoaderLogic.applyBuiltinExcludes(new UrlSet(Assembler.class.getClassLoader()).excludeJvm()).getUrls();
            Extensions.installExtensions(new Extensions.Finder("META-INF", false, (URL[])urls.toArray(new URL[urls.size()])));
        }
        catch (IOException ex) {
            Extensions.installExtensions(new Extensions.Finder("META-INF", true, new URL[0]));
        }
    }
    
    private void setConfiguration(final OpenEjbConfiguration config) {
        this.config = config;
        if (config.containerSystem == null) {
            config.containerSystem = new ContainerSystemInfo();
        }
        if (config.facilities == null) {
            config.facilities = new FacilitiesInfo();
        }
        SystemInstance.get().setComponent((Class)OpenEjbConfiguration.class, (Object)this.config);
    }
    
    @Override
    public void init(final Properties props) throws OpenEJBException {
        this.props = new Properties(props);
        final Options options = new Options(props, SystemInstance.get().getOptions());
        final String className = options.get("openejb.configurator", "org.apache.openejb.config.ConfigurationFactory");
        if ("org.apache.openejb.config.ConfigurationFactory".equals(className)) {
            this.configFactory = new ConfigurationFactory();
        }
        else {
            this.configFactory = (OpenEjbConfigurationFactory)this.toolkit.newInstance(className);
        }
        this.configFactory.init(props);
        SystemInstance.get().setComponent((Class)OpenEjbConfigurationFactory.class, (Object)this.configFactory);
    }
    
    public static void installNaming() {
        if (SystemInstance.get().hasProperty("openejb.geronimo")) {
            return;
        }
        installNaming(Assembler.OPENEJB_URL_PKG_PREFIX);
    }
    
    public static void installNaming(final String prefix) {
        installNaming(prefix, false);
    }
    
    public static void installNaming(final String prefix, final boolean clean) {
        final ReentrantLock l = Assembler.lock;
        l.lock();
        try {
            final Properties systemProperties = JavaSecurityManagers.getSystemProperties();
            String str = systemProperties.getProperty("java.naming.factory.url.pkgs");
            if (str == null || clean) {
                str = prefix;
            }
            else if (!str.contains(prefix)) {
                str = str + ":" + prefix;
            }
            systemProperties.setProperty("java.naming.factory.url.pkgs", str);
        }
        finally {
            l.unlock();
        }
    }
    
    public static void setContext(final Map<String, Object> map) {
        Assembler.context.set(map);
    }
    
    public static Map<String, Object> getContext() {
        Map<String, Object> map = Assembler.context.get();
        if (map == null) {
            map = new HashMap<String, Object>();
            Assembler.context.set(map);
        }
        return map;
    }
    
    @Override
    public void build() throws OpenEJBException {
        setContext(new HashMap<String, Object>());
        try {
            final OpenEjbConfiguration config = this.getOpenEjbConfiguration();
            this.buildContainerSystem(config);
        }
        catch (OpenEJBException ae) {
            throw ae;
        }
        catch (Exception e) {
            OpenEJBErrorHandler.handleUnknownError(e, "Assembler");
            throw new OpenEJBException(e);
        }
        finally {
            Assembler.context.set(null);
        }
    }
    
    protected OpenEjbConfiguration getOpenEjbConfiguration() throws OpenEJBException {
        return this.configFactory.getOpenEjbConfiguration();
    }
    
    public void buildContainerSystem(final OpenEjbConfiguration configInfo) throws Exception {
        final SystemInstance systemInstance = SystemInstance.get();
        if (systemInstance.getOptions().get("openejb.jpa.deploy-time-enhancement", false)) {
            systemInstance.addObserver((Object)new DeployTimeEnhancer());
        }
        if (hasBatchEE()) {
            systemInstance.addObserver((Object)new BatchEEServiceManager());
        }
        for (final ServiceInfo serviceInfo : configInfo.facilities.services) {
            this.createService(serviceInfo);
        }
        final ContainerSystemInfo containerSystemInfo = configInfo.containerSystem;
        if (configInfo.facilities.intraVmServer != null) {
            this.createProxyFactory(configInfo.facilities.intraVmServer);
        }
        for (final JndiContextInfo contextInfo : configInfo.facilities.remoteJndiContexts) {
            this.createExternalContext(contextInfo);
        }
        this.createTransactionManager(configInfo.facilities.transactionService);
        this.createSecurityService(configInfo.facilities.securityService);
        final Set<String> reservedResourceIds = new HashSet<String>(configInfo.facilities.resources.size());
        for (final AppInfo appInfo : containerSystemInfo.applications) {
            reservedResourceIds.addAll(appInfo.resourceIds);
        }
        final Set<String> rIds = new HashSet<String>(configInfo.facilities.resources.size());
        for (final ResourceInfo resourceInfo : configInfo.facilities.resources) {
            this.createResource(configInfo.facilities.services, resourceInfo);
            rIds.add(resourceInfo.id);
        }
        rIds.removeAll(reservedResourceIds);
        final ContainerSystem component = (ContainerSystem)systemInstance.getComponent((Class)ContainerSystem.class);
        if (component != null) {
            this.postConstructResources(rIds, ParentClassLoaderFinder.Helper.get(), component.getJNDIContext(), null);
            for (final ContainerInfo serviceInfo2 : containerSystemInfo.containers) {
                this.createContainer(serviceInfo2);
            }
            this.createJavaGlobal();
            for (final AppInfo appInfo2 : containerSystemInfo.applications) {
                try {
                    this.createApplication(appInfo2, this.createAppClassLoader(appInfo2));
                }
                catch (DuplicateDeploymentIdException ex) {}
                catch (Throwable e) {
                    this.logger.error("appNotDeployed", e, appInfo2.path);
                    final DeploymentExceptionManager exceptionManager = (DeploymentExceptionManager)systemInstance.getComponent((Class)DeploymentExceptionManager.class);
                    if (exceptionManager == null || !(e instanceof Exception)) {
                        continue;
                    }
                    exceptionManager.saveDeploymentException(appInfo2, (Exception)e);
                }
            }
            systemInstance.fireEvent((Object)new ContainerSystemPostCreate());
            return;
        }
        throw new RuntimeException("ContainerSystem has not been initialzed");
    }
    
    private static boolean hasBatchEE() {
        try {
            Class.forName("org.apache.batchee.container.services.ServicesManager", true, Assembler.class.getClassLoader());
            return true;
        }
        catch (Throwable e) {
            return false;
        }
    }
    
    private void createJavaGlobal() {
        try {
            this.containerSystem.getJNDIContext().createSubcontext("global");
        }
        catch (NamingException ex) {}
    }
    
    public AppInfo getAppInfo(final String path) {
        return this.deployedApplications.get(ProvisioningUtil.realLocation(path).iterator().next());
    }
    
    public boolean isDeployed(final String path) {
        return this.deployedApplications.containsKey(ProvisioningUtil.realLocation(path).iterator().next());
    }
    
    public Collection<AppInfo> getDeployedApplications() {
        return new ArrayList<AppInfo>(this.deployedApplications.values());
    }
    
    public AppContext createApplication(final EjbJarInfo ejbJar) throws NamingException, IOException, OpenEJBException {
        return this.createEjbJar(ejbJar);
    }
    
    public AppContext createEjbJar(final EjbJarInfo ejbJar) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = ejbJar.path;
        appInfo.appId = ejbJar.moduleName;
        appInfo.ejbJars.add(ejbJar);
        return this.createApplication(appInfo);
    }
    
    public AppContext createApplication(final EjbJarInfo ejbJar, final ClassLoader classLoader) throws NamingException, IOException, OpenEJBException {
        return this.createEjbJar(ejbJar, classLoader);
    }
    
    public AppContext createEjbJar(final EjbJarInfo ejbJar, final ClassLoader classLoader) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = ejbJar.path;
        appInfo.appId = ejbJar.moduleName;
        appInfo.ejbJars.add(ejbJar);
        return this.createApplication(appInfo, classLoader);
    }
    
    public AppContext createClient(final ClientInfo clientInfo) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = clientInfo.path;
        appInfo.appId = clientInfo.moduleId;
        appInfo.clients.add(clientInfo);
        return this.createApplication(appInfo);
    }
    
    public AppContext createClient(final ClientInfo clientInfo, final ClassLoader classLoader) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = clientInfo.path;
        appInfo.appId = clientInfo.moduleId;
        appInfo.clients.add(clientInfo);
        return this.createApplication(appInfo, classLoader);
    }
    
    public AppContext createConnector(final ConnectorInfo connectorInfo) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = connectorInfo.path;
        appInfo.appId = connectorInfo.moduleId;
        appInfo.connectors.add(connectorInfo);
        return this.createApplication(appInfo);
    }
    
    public AppContext createConnector(final ConnectorInfo connectorInfo, final ClassLoader classLoader) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = connectorInfo.path;
        appInfo.appId = connectorInfo.moduleId;
        appInfo.connectors.add(connectorInfo);
        return this.createApplication(appInfo, classLoader);
    }
    
    public AppContext createWebApp(final WebAppInfo webAppInfo) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = webAppInfo.path;
        appInfo.appId = webAppInfo.moduleId;
        appInfo.webApps.add(webAppInfo);
        return this.createApplication(appInfo);
    }
    
    public AppContext createWebApp(final WebAppInfo webAppInfo, final ClassLoader classLoader) throws NamingException, IOException, OpenEJBException {
        final AppInfo appInfo = new AppInfo();
        appInfo.path = webAppInfo.path;
        appInfo.appId = webAppInfo.moduleId;
        appInfo.webApps.add(webAppInfo);
        return this.createApplication(appInfo, classLoader);
    }
    
    public AppContext createApplication(final AppInfo appInfo) throws OpenEJBException, IOException, NamingException {
        return this.createApplication(appInfo, this.createAppClassLoader(appInfo));
    }
    
    public AppContext createApplication(final AppInfo appInfo, final ClassLoader classLoader) throws OpenEJBException, IOException, NamingException {
        return this.createApplication(appInfo, classLoader, true);
    }
    
    private AppContext createApplication(final AppInfo appInfo, ClassLoader classLoader, final boolean start) throws OpenEJBException, IOException, NamingException {
        try {
            try {
                mergeServices(appInfo);
            }
            catch (URISyntaxException e8) {
                this.logger.info("Can't merge resources.xml services and appInfo.properties");
            }
            if (appInfo.appId == null) {
                throw new IllegalArgumentException("AppInfo.appId cannot be null");
            }
            if (appInfo.path == null) {
                appInfo.path = appInfo.appId;
            }
            Extensions.addExtensions(classLoader, appInfo.eventClassesNeedingAppClassloader);
            this.logger.info("createApplication.start", appInfo.path);
            final Context containerSystemContext = this.containerSystem.getJNDIContext();
            final List<String> used = this.getDuplicates(appInfo);
            if (used.size() > 0) {
                String message = this.logger.error("createApplication.appFailedDuplicateIds", appInfo.path);
                for (final String id : used) {
                    this.logger.error("createApplication.deploymentIdInUse", id);
                    message = message + "\n    " + id;
                }
                throw new DuplicateDeploymentIdException(message);
            }
            final InjectionBuilder injectionBuilder = new InjectionBuilder(classLoader);
            final Set<Injection> injections = new HashSet<Injection>();
            injections.addAll(injectionBuilder.buildInjections(appInfo.globalJndiEnc));
            injections.addAll(injectionBuilder.buildInjections(appInfo.appJndiEnc));
            final JndiEncBuilder globalBuilder = new JndiEncBuilder(appInfo.globalJndiEnc, injections, appInfo.appId, null, "global", classLoader, appInfo.properties);
            final Map<String, Object> globalBindings = globalBuilder.buildBindings(JndiEncBuilder.JndiScope.global);
            final Context globalJndiContext = globalBuilder.build(globalBindings);
            final JndiEncBuilder appBuilder = new JndiEncBuilder(appInfo.appJndiEnc, injections, appInfo.appId, null, appInfo.appId, classLoader, appInfo.properties);
            final Map<String, Object> appBindings = appBuilder.buildBindings(JndiEncBuilder.JndiScope.app);
            final Context appJndiContext = appBuilder.build(appBindings);
            final boolean cdiActive = this.shouldStartCdi(appInfo);
            try {
                final CmpJarBuilder cmpJarBuilder = new CmpJarBuilder(appInfo, classLoader);
                final File generatedJar = cmpJarBuilder.getJarFile();
                if (generatedJar != null) {
                    classLoader = ClassLoaderUtil.createClassLoader(appInfo.path, new URL[] { generatedJar.toURI().toURL() }, classLoader);
                }
                final AppContext appContext = new AppContext(appInfo.appId, SystemInstance.get(), classLoader, globalJndiContext, appJndiContext, appInfo.standaloneModule);
                appContext.getProperties().putAll(appInfo.properties);
                appContext.getInjections().addAll(injections);
                appContext.getBindings().putAll(globalBindings);
                appContext.getBindings().putAll(appBindings);
                this.containerSystem.addAppContext(appContext);
                appContext.set(AsynchronousPool.class, AsynchronousPool.create(appContext));
                final Map<String, LazyValidatorFactory> lazyValidatorFactories = new HashMap<String, LazyValidatorFactory>();
                final Map<String, LazyValidator> lazyValidators = new HashMap<String, LazyValidator>();
                final boolean isGeronimo = SystemInstance.get().hasProperty("openejb.geronimo");
                final Map<ComparableValidationConfig, ValidatorFactory> validatorFactoriesByConfig = new HashMap<ComparableValidationConfig, ValidatorFactory>();
                if (!isGeronimo) {
                    final List<CommonInfoObject> vfs = listCommonInfoObjectsForAppInfo(appInfo);
                    final Map<String, ValidatorFactory> validatorFactories = new HashMap<String, ValidatorFactory>();
                    for (final CommonInfoObject info : vfs) {
                        if (info.validationInfo == null) {
                            continue;
                        }
                        final ComparableValidationConfig conf = new ComparableValidationConfig(info.validationInfo.providerClassName, info.validationInfo.messageInterpolatorClass, info.validationInfo.traversableResolverClass, info.validationInfo.constraintFactoryClass, info.validationInfo.parameterNameProviderClass, info.validationInfo.version, info.validationInfo.propertyTypes, info.validationInfo.constraintMappings, info.validationInfo.executableValidationEnabled, info.validationInfo.validatedTypes);
                        ValidatorFactory factory = validatorFactoriesByConfig.get(conf);
                        if (factory == null) {
                            try {
                                final LazyValidatorFactory handler = new LazyValidatorFactory(classLoader, info.validationInfo);
                                factory = (ValidatorFactory)Proxy.newProxyInstance(appContext.getClassLoader(), Assembler.VALIDATOR_FACTORY_INTERFACES, handler);
                                lazyValidatorFactories.put(info.uniqueId, handler);
                            }
                            catch (ValidationException ve) {
                                this.logger.warning("can't build the validation factory for module " + info.uniqueId, (Throwable)ve);
                                continue;
                            }
                            validatorFactoriesByConfig.put(conf, factory);
                        }
                        else {
                            lazyValidatorFactories.put(info.uniqueId, LazyValidatorFactory.class.cast(Proxy.getInvocationHandler(factory)));
                        }
                        validatorFactories.put(info.uniqueId, factory);
                    }
                    for (final Map.Entry<String, ValidatorFactory> validatorFactory : validatorFactories.entrySet()) {
                        final String id2 = validatorFactory.getKey();
                        final ValidatorFactory factory = validatorFactory.getValue();
                        try {
                            containerSystemContext.bind("openejb/ValidatorFactory/" + id2, factory);
                            Validator validator;
                            try {
                                final LazyValidator lazyValidator = new LazyValidator(factory);
                                validator = (Validator)Proxy.newProxyInstance(appContext.getClassLoader(), Assembler.VALIDATOR_INTERFACES, lazyValidator);
                                lazyValidators.put(id2, lazyValidator);
                            }
                            catch (Exception e) {
                                this.logger.error(e.getMessage(), e);
                                continue;
                            }
                            containerSystemContext.bind("openejb/Validator/" + id2, validator);
                        }
                        catch (NameAlreadyBoundException e2) {
                            throw new OpenEJBException("ValidatorFactory already exists for module " + id2, e2);
                        }
                        catch (Exception e3) {
                            throw new OpenEJBException(e3);
                        }
                    }
                    validatorFactories.clear();
                }
                final Map<String, String> units = new HashMap<String, String>();
                final PersistenceBuilder persistenceBuilder = new PersistenceBuilder(this.persistenceClassLoaderHandler);
                for (final PersistenceUnitInfo info2 : appInfo.persistenceUnits) {
                    ReloadableEntityManagerFactory factory2;
                    try {
                        factory2 = persistenceBuilder.createEntityManagerFactory(info2, classLoader, validatorFactoriesByConfig, cdiActive);
                        this.containerSystem.getJNDIContext().bind("openejb/PersistenceUnit/" + info2.id, factory2);
                        units.put(info2.name, "openejb/PersistenceUnit/" + info2.id);
                    }
                    catch (NameAlreadyBoundException e9) {
                        throw new OpenEJBException("PersistenceUnit already deployed: " + info2.persistenceUnitRootUrl);
                    }
                    catch (Exception e4) {
                        throw new OpenEJBException(e4);
                    }
                    factory2.register();
                }
                this.logger.debug("Loaded peristence units: " + units);
                for (final ConnectorInfo connector : appInfo.connectors) {
                    final ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
                    Thread.currentThread().setContextClassLoader(classLoader);
                    try {
                        if (connector.resourceAdapter != null) {
                            this.createResource(null, connector.resourceAdapter);
                        }
                        for (final ResourceInfo outbound : connector.outbound) {
                            this.createResource(null, outbound);
                            outbound.properties.setProperty("openejb.connector", "true");
                        }
                        for (final MdbContainerInfo inbound : connector.inbound) {
                            this.createContainer(inbound);
                        }
                        for (final ResourceInfo adminObject : connector.adminObject) {
                            this.createResource(null, adminObject);
                        }
                    }
                    finally {
                        Thread.currentThread().setContextClassLoader(oldClassLoader);
                    }
                }
                final List<BeanContext> allDeployments = this.initEjbs(classLoader, appInfo, appContext, injections, new ArrayList<BeanContext>(), null);
                if ("true".equalsIgnoreCase(SystemInstance.get().getProperty("openejb.propagate.application-exceptions", appInfo.properties.getProperty("openejb.propagate.application-exceptions", "false")))) {
                    this.propagateApplicationExceptions(appInfo, classLoader, allDeployments);
                }
                if (cdiActive) {
                    new CdiBuilder().build(appInfo, appContext, allDeployments);
                    this.ensureWebBeansContext(appContext);
                    appJndiContext.bind("app/BeanManager", appContext.getBeanManager());
                    appContext.getBindings().put("app/BeanManager", appContext.getBeanManager());
                }
                else {
                    appInfo.properties.setProperty("openejb.cdi.activated", "false");
                }
                if (!isGeronimo) {
                    for (final Map.Entry<String, LazyValidator> lazyValidator2 : lazyValidators.entrySet()) {
                        final String id3 = lazyValidator2.getKey();
                        final ValidatorFactory factory3 = lazyValidatorFactories.get(lazyValidator2.getKey()).getFactory();
                        try {
                            final String factoryName = "openejb/ValidatorFactory/" + id3;
                            containerSystemContext.unbind(factoryName);
                            containerSystemContext.bind(factoryName, factory3);
                            final String validatoryName = "openejb/Validator/" + id3;
                            try {
                                final Validator val = lazyValidator2.getValue().getValidator();
                                containerSystemContext.unbind(validatoryName);
                                containerSystemContext.bind(validatoryName, val);
                            }
                            catch (Exception e5) {
                                this.logger.error(e5.getMessage(), e5);
                            }
                        }
                        catch (NameAlreadyBoundException e6) {
                            throw new OpenEJBException("ValidatorFactory already exists for module " + id3, e6);
                        }
                        catch (Exception e) {
                            throw new OpenEJBException(e);
                        }
                    }
                }
                this.startEjbs(start, allDeployments);
                for (final ClientInfo clientInfo : appInfo.clients) {
                    final List<Injection> clientInjections = injectionBuilder.buildInjections(clientInfo.jndiEnc);
                    final JndiEncBuilder jndiEncBuilder = new JndiEncBuilder(clientInfo.jndiEnc, clientInjections, "Bean", clientInfo.moduleId, null, clientInfo.uniqueId, classLoader, new Properties());
                    if (clientInfo.remoteClients.size() > 0 || clientInfo.localClients.size() == 0) {
                        jndiEncBuilder.setClient(true);
                    }
                    jndiEncBuilder.setUseCrossClassLoaderRef(false);
                    final Context context = jndiEncBuilder.build(JndiEncBuilder.JndiScope.comp);
                    containerSystemContext.bind("openejb/client/" + clientInfo.moduleId, context);
                    if (clientInfo.path != null) {
                        context.bind("info/path", clientInfo.path);
                    }
                    if (clientInfo.mainClass != null) {
                        context.bind("info/mainClass", clientInfo.mainClass);
                    }
                    if (clientInfo.callbackHandler != null) {
                        context.bind("info/callbackHandler", clientInfo.callbackHandler);
                    }
                    context.bind("info/injections", clientInjections);
                    for (final String clientClassName : clientInfo.remoteClients) {
                        containerSystemContext.bind("openejb/client/" + clientClassName, clientInfo.moduleId);
                    }
                    for (final String clientClassName : clientInfo.localClients) {
                        containerSystemContext.bind("openejb/client/" + clientClassName, clientInfo.moduleId);
                        this.logger.getChildLogger("client").info("createApplication.createLocalClient", clientClassName, clientInfo.moduleId);
                    }
                }
                final SystemInstance systemInstance = SystemInstance.get();
                final WebAppBuilder webAppBuilder = (WebAppBuilder)systemInstance.getComponent((Class)WebAppBuilder.class);
                if (webAppBuilder != null) {
                    webAppBuilder.deployWebApps(appInfo, classLoader);
                }
                if (start) {
                    final EjbResolver globalEjbResolver = (EjbResolver)systemInstance.getComponent((Class)EjbResolver.class);
                    globalEjbResolver.addAll(appInfo.ejbJars);
                }
                this.bindGlobals(appContext.getBindings());
                this.validateCdiResourceProducers(appContext, appInfo);
                for (final String mbean : appInfo.mbeans) {
                    this.deployMBean(appContext.getWebBeansContext(), classLoader, mbean, appInfo.jmx, appInfo.appId);
                }
                for (final EjbJarInfo ejbJarInfo : appInfo.ejbJars) {
                    for (final String mbean2 : ejbJarInfo.mbeans) {
                        this.deployMBean(appContext.getWebBeansContext(), classLoader, mbean2, appInfo.jmx, ejbJarInfo.moduleName);
                    }
                }
                for (final ConnectorInfo connectorInfo : appInfo.connectors) {
                    for (final String mbean2 : connectorInfo.mbeans) {
                        this.deployMBean(appContext.getWebBeansContext(), classLoader, mbean2, appInfo.jmx, appInfo.appId + ".add-lib");
                    }
                }
                this.postConstructResources(appInfo.resourceIds, classLoader, containerSystemContext, appContext);
                this.deployedApplications.put(appInfo.path, appInfo);
                this.resumePersistentSchedulers(appContext);
                systemInstance.fireEvent((Object)new AssemblerAfterApplicationCreated(appInfo, appContext, allDeployments));
                this.logger.info("createApplication.success", appInfo.path);
                if (this.setAppNamingContextReadOnly(allDeployments)) {
                    this.logger.info("createApplication.naming", appInfo.path);
                }
                return appContext;
            }
            catch (ValidationException | DeploymentException ex2) {
                final RuntimeException ex;
                final RuntimeException ve2 = ex;
                throw ve2;
            }
            catch (Throwable t) {
                try {
                    this.destroyApplication(appInfo);
                }
                catch (Exception e7) {
                    this.logger.debug("createApplication.undeployFailed", e7, appInfo.path);
                }
                throw new OpenEJBException(this.messages.format("createApplication.failed", appInfo.path), t);
            }
        }
        finally {
            for (final WebAppInfo webApp : appInfo.webApps) {
                appInfo.properties.remove(webApp);
            }
        }
    }
    
    boolean setAppNamingContextReadOnly(final List<BeanContext> allDeployments) {
        if ("true".equals(SystemInstance.get().getProperty("openejb.forceReadOnlyAppNamingContext", "false"))) {
            for (final BeanContext beanContext : allDeployments) {
                final Context ctx = beanContext.getJndiContext();
                if (IvmContext.class.isInstance(ctx)) {
                    IvmContext.class.cast(ctx).setReadOnly(true);
                }
                else {
                    if (!ContextHandler.class.isInstance(ctx)) {
                        continue;
                    }
                    ContextHandler.class.cast(ctx).setReadOnly();
                }
            }
            return true;
        }
        return false;
    }
    
    private List<String> getDuplicates(final AppInfo appInfo) {
        final List<String> used = new ArrayList<String>();
        for (final EjbJarInfo ejbJarInfo : appInfo.ejbJars) {
            for (final EnterpriseBeanInfo beanInfo : ejbJarInfo.enterpriseBeans) {
                if (this.containerSystem.getBeanContext(beanInfo.ejbDeploymentId) != null) {
                    used.add(beanInfo.ejbDeploymentId);
                }
            }
        }
        return used;
    }
    
    private boolean shouldStartCdi(final AppInfo appInfo) {
        if (!"true".equalsIgnoreCase(appInfo.properties.getProperty("openejb.cdi.activated", "true"))) {
            return false;
        }
        for (final EjbJarInfo ejbJarInfo : appInfo.ejbJars) {
            if (ejbJarInfo.beans != null && (!ejbJarInfo.beans.bdas.isEmpty() || !ejbJarInfo.beans.noDescriptorBdas.isEmpty())) {
                return true;
            }
        }
        return false;
    }
    
    private void validateCdiResourceProducers(final AppContext appContext, final AppInfo info) {
        if (appContext.getWebBeansContext() == null) {
            return;
        }
        if (appContext.isStandaloneModule() && !appContext.getProperties().containsKey("openejb.cdi.skip-resource-validation")) {
            final Map<String, Object> bindings = appContext.getWebContexts().isEmpty() ? appContext.getBindings() : appContext.getWebContexts().iterator().next().getBindings();
            if (bindings != null && appContext.getWebBeansContext() != null && appContext.getWebBeansContext().getBeanManagerImpl().isInUse()) {
                for (final Bean<?> bean : appContext.getWebBeansContext().getBeanManagerImpl().getBeans()) {
                    if (ResourceBean.class.isInstance(bean)) {
                        final ResourceReference reference = ResourceBean.class.cast(bean).getReference();
                        String jndi = reference.getJndiName().replace("java:", "");
                        if (reference.getJndiName().startsWith("java:/")) {
                            jndi = jndi.substring(1);
                        }
                        Object lookup = bindings.get(jndi);
                        if (lookup == null && reference.getAnnotation((Class)EJB.class) != null) {
                            final CdiPlugin plugin = CdiPlugin.class.cast(appContext.getWebBeansContext().getPluginLoader().getEjbPlugin());
                            if (!plugin.isSessionBean(reference.getResourceType())) {
                                boolean ok = false;
                                for (final BeanContext bc : appContext.getBeanContexts()) {
                                    if (bc.getBusinessLocalInterfaces().contains(reference.getResourceType()) || bc.getBusinessRemoteInterfaces().contains(reference.getResourceType())) {
                                        ok = true;
                                        break;
                                    }
                                }
                                if (!ok) {
                                    throw new DefinitionException("EJB " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast to " + reference.getResourceType());
                                }
                            }
                        }
                        Label_0760: {
                            if (Reference.class.isInstance(lookup)) {
                                try {
                                    lookup = Reference.class.cast(lookup).getContent();
                                    break Label_0760;
                                }
                                catch (Exception e2) {
                                    if (!JndiUrlReference.class.isInstance(lookup)) {
                                        continue;
                                    }
                                    this.checkBuiltInResourceTypes(reference, JndiUrlReference.class.cast(lookup).getJndiName());
                                    continue;
                                }
                            }
                            if (lookup == null) {
                                final Resource r = Resource.class.cast(reference.getAnnotation((Class)Resource.class));
                                if (r != null) {
                                    if (!r.lookup().isEmpty()) {
                                        this.checkBuiltInResourceTypes(reference, r.lookup());
                                    }
                                    else if (!r.name().isEmpty()) {
                                        final String name = "comp/env/" + r.name();
                                        boolean done = false;
                                        for (final WebAppInfo w : info.webApps) {
                                            for (final EnvEntryInfo e : w.jndiEnc.envEntries) {
                                                if (name.equals(e.referenceName)) {
                                                    if (e.type != null && !reference.getResourceType().getName().equals(e.type)) {
                                                        throw new DefinitionException("Env Entry " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast to " + reference.getResourceType());
                                                    }
                                                    done = true;
                                                    break;
                                                }
                                            }
                                            if (done) {
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (lookup != null && !reference.getResourceType().isInstance(lookup)) {
                            throw new DefinitionException("Resource " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast, instance is " + lookup);
                        }
                        continue;
                    }
                }
            }
        }
    }
    
    private void checkBuiltInResourceTypes(final ResourceReference reference, final String jndi) {
        final Class<?> resourceType = (Class<?>)reference.getResourceType();
        if ("java:comp/BeanManager".equals(jndi) && resourceType != BeanManager.class) {
            throw new DefinitionException("Resource " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast to a BeanManager");
        }
        if ("java:comp/TransactionSynchronizationRegistry".equals(jndi) && resourceType != TransactionSynchronizationRegistry.class) {
            throw new DefinitionException("Resource " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast to a TransactionSynchronizationRegistry");
        }
        if ("java:comp/TransactionManager".equals(jndi) && resourceType != TransactionManager.class) {
            throw new DefinitionException("Resource " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast to a TransactionManager");
        }
        if ("java:comp/ValidatorFactory".equals(jndi) && resourceType != ValidatorFactory.class) {
            throw new DefinitionException("Resource " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast to a ValidatorFactory");
        }
        if ("java:comp/Validator".equals(jndi) && resourceType != Validator.class) {
            throw new DefinitionException("Resource " + reference.getJndiName() + " in " + reference.getOwnerClass() + " can't be cast to a Validator");
        }
    }
    
    private void postConstructResources(final Set<String> resourceIds, final ClassLoader classLoader, final Context containerSystemContext, final AppContext appContext) throws NamingException, OpenEJBException {
        final Thread thread = Thread.currentThread();
        final ClassLoader oldCl = thread.getContextClassLoader();
        try {
            thread.setContextClassLoader(classLoader);
            final List<ResourceInfo> resourceList = this.config.facilities.resources;
            for (final ResourceInfo resourceInfo : resourceList) {
                if (!resourceIds.contains(resourceInfo.id)) {
                    continue;
                }
                if (isTemplatizedResource(resourceInfo)) {
                    continue;
                }
                try {
                    Class<?> clazz;
                    try {
                        clazz = classLoader.loadClass(resourceInfo.className);
                    }
                    catch (ClassNotFoundException cnfe) {
                        clazz = containerSystemContext.lookup("openejb/Resource/" + resourceInfo.id).getClass();
                    }
                    final boolean initialize = "true".equalsIgnoreCase(String.valueOf(resourceInfo.properties.remove("InitializeAfterDeployment")));
                    AnnotationFinder annotationFinder;
                    if (Proxy.isProxyClass(clazz)) {
                        annotationFinder = null;
                    }
                    else {
                        final ClassesArchive classesArchive;
                        annotationFinder = new AnnotationFinder((Archive)classesArchive);
                        classesArchive = new ClassesArchive((Iterable)Classes.ancestors(clazz));
                    }
                    final AnnotationFinder finder = annotationFinder;
                    final List<Method> postConstructs = (finder == null) ? Collections.emptyList() : finder.findAnnotatedMethods((Class)PostConstruct.class);
                    final List<Method> preDestroys = (finder == null) ? Collections.emptyList() : finder.findAnnotatedMethods((Class)PreDestroy.class);
                    resourceInfo.postConstructMethods = new ArrayList<String>();
                    resourceInfo.preDestroyMethods = new ArrayList<String>();
                    this.addMethodsToResourceInfo(resourceInfo.postConstructMethods, PostConstruct.class, postConstructs);
                    this.addMethodsToResourceInfo(resourceInfo.preDestroyMethods, PreDestroy.class, preDestroys);
                    CreationalContext<?> creationalContext = null;
                    Object originalResource = null;
                    if (!postConstructs.isEmpty() || initialize) {
                        Object resource;
                        originalResource = (resource = containerSystemContext.lookup("openejb/Resource/" + resourceInfo.id));
                        if (resource instanceof Reference) {
                            resource = unwrapReference(resource);
                            this.bindResource(resourceInfo.id, resource, true);
                        }
                        try {
                            if (appContext != null && appContext.getWebBeansContext() != null) {
                                final BeanManagerImpl beanManager = appContext.getWebBeansContext().getBeanManagerImpl();
                                if (beanManager.isInUse()) {
                                    creationalContext = (CreationalContext<?>)beanManager.createCreationalContext((Contextual)null);
                                    OWBInjector.inject((BeanManager)beanManager, resource, (CreationalContext)creationalContext);
                                }
                            }
                            if (!"none".equals(resourceInfo.postConstruct)) {
                                if (resourceInfo.postConstruct != null) {
                                    final Method p = clazz.getDeclaredMethod(resourceInfo.postConstruct, (Class<?>[])new Class[0]);
                                    if (!p.isAccessible()) {
                                        SetAccessible.on(p);
                                    }
                                    p.invoke(resource, new Object[0]);
                                }
                                for (final Method m : postConstructs) {
                                    if (!m.isAccessible()) {
                                        SetAccessible.on(m);
                                    }
                                    m.invoke(resource, new Object[0]);
                                }
                            }
                        }
                        catch (Exception e) {
                            this.logger.fatal("Error calling @PostConstruct method on " + resource.getClass().getName());
                            throw new OpenEJBException(e);
                        }
                    }
                    if (!"none".equals(resourceInfo.preDestroy)) {
                        if (resourceInfo.preDestroy != null) {
                            final Method p2 = clazz.getDeclaredMethod(resourceInfo.preDestroy, (Class<?>[])new Class[0]);
                            if (!p2.isAccessible()) {
                                SetAccessible.on(p2);
                            }
                            preDestroys.add(p2);
                        }
                        if (!preDestroys.isEmpty() || creationalContext != null) {
                            final String name = "openejb/Resource/" + resourceInfo.id;
                            if (originalResource == null) {
                                originalResource = containerSystemContext.lookup(name);
                            }
                            this.bindResource(resourceInfo.id, new ResourceInstance(name, originalResource, preDestroys, creationalContext), true);
                        }
                    }
                    if (resourceInfo.unsetProperties == null || isPassthroughType(resourceInfo)) {
                        continue;
                    }
                    final Set<String> unsetKeys = resourceInfo.unsetProperties.stringPropertyNames();
                    for (final String key : unsetKeys) {
                        unusedProperty(resourceInfo.id, this.logger, key);
                    }
                }
                catch (Exception e2) {
                    this.logger.fatal("Error calling PostConstruct method on " + resourceInfo.id);
                    this.logger.fatal("Resource " + resourceInfo.id + " could not be initialized. Application will be undeployed.");
                    throw new OpenEJBException(e2);
                }
            }
        }
        finally {
            thread.setContextClassLoader(oldCl);
        }
    }
    
    private void addMethodsToResourceInfo(final List<String> list, final Class type, final List<Method> methodList) throws OpenEJBException {
        for (final Method method : methodList) {
            if (method.getParameterTypes().length > 0) {
                throw new OpenEJBException(type.getSimpleName() + " method " + method.getDeclaringClass().getName() + "." + method.getName() + " should have zero arguments");
            }
            list.add(method.getName());
        }
    }
    
    private static boolean isTemplatizedResource(final ResourceInfo resourceInfo) {
        return resourceInfo.className == null || resourceInfo.className.isEmpty();
    }
    
    public static void mergeServices(final AppInfo appInfo) throws URISyntaxException {
        for (final ServiceInfo si : appInfo.services) {
            if (!appInfo.properties.containsKey(si.id)) {
                final Map<String, String> query = new HashMap<String, String>();
                if (si.types != null && !si.types.isEmpty()) {
                    query.put("type", si.types.iterator().next());
                }
                if (si.className != null) {
                    query.put("class-name", si.className);
                }
                if (si.factoryMethod != null) {
                    query.put("factory-name", si.factoryMethod);
                }
                if (si.constructorArgs != null && !si.constructorArgs.isEmpty()) {
                    query.put("constructor", Join.join(",", si.constructorArgs));
                }
                appInfo.properties.put(si.id, "new://Service?" + URISupport.createQueryString(query));
                if (si.properties == null) {
                    continue;
                }
                for (final String k : si.properties.stringPropertyNames()) {
                    appInfo.properties.setProperty(si.id + "." + k, si.properties.getProperty(k));
                }
            }
        }
    }
    
    private static List<CommonInfoObject> listCommonInfoObjectsForAppInfo(final AppInfo appInfo) {
        final List<CommonInfoObject> vfs = new ArrayList<CommonInfoObject>(appInfo.clients.size() + appInfo.connectors.size() + appInfo.ejbJars.size() + appInfo.webApps.size());
        for (final ClientInfo clientInfo : appInfo.clients) {
            vfs.add(clientInfo);
        }
        for (final ConnectorInfo connectorInfo : appInfo.connectors) {
            vfs.add(connectorInfo);
        }
        for (final EjbJarInfo ejbJarInfo : appInfo.ejbJars) {
            vfs.add(ejbJarInfo);
        }
        for (final WebAppInfo webAppInfo : appInfo.webApps) {
            vfs.add(webAppInfo);
        }
        return vfs;
    }
    
    public void bindGlobals(final Map<String, Object> bindings) throws NamingException {
        final Context containerSystemContext = this.containerSystem.getJNDIContext();
        for (final Map.Entry<String, Object> value : bindings.entrySet()) {
            final String path = value.getKey();
            if (!path.startsWith("module/") && !path.startsWith("app/") && !path.startsWith("comp/")) {
                if (path.equalsIgnoreCase("global/dummy")) {
                    continue;
                }
                final Context lastContext = Contexts.createSubcontexts(containerSystemContext, path);
                try {
                    lastContext.rebind(path.substring(path.lastIndexOf("/") + 1, path.length()), value.getValue());
                }
                catch (NameAlreadyBoundException nabe) {
                    nabe.printStackTrace();
                }
                containerSystemContext.rebind(path, value.getValue());
            }
        }
    }
    
    private void propagateApplicationExceptions(final AppInfo appInfo, final ClassLoader classLoader, final List<BeanContext> allDeployments) {
        for (final BeanContext context : allDeployments) {
            if (BeanContext.Comp.class.equals(context.getBeanClass())) {
                continue;
            }
            for (final EjbJarInfo jar : appInfo.ejbJars) {
                for (final ApplicationExceptionInfo exception : jar.applicationException) {
                    try {
                        final Class<?> exceptionClass = classLoader.loadClass(exception.exceptionClass);
                        context.addApplicationException(exceptionClass, exception.rollback, exception.inherited);
                    }
                    catch (Exception ex) {}
                }
            }
        }
    }
    
    private void resumePersistentSchedulers(final AppContext appContext) {
        try {
            final Scheduler globalScheduler = (Scheduler)SystemInstance.get().getComponent((Class)Scheduler.class);
            final Collection<Scheduler> schedulers = new ArrayList<Scheduler>();
            for (final BeanContext ejb : appContext.getBeanContexts()) {
                final Scheduler scheduler = ejb.get(Scheduler.class);
                if (scheduler != null && scheduler != globalScheduler) {
                    if (schedulers.contains(scheduler)) {
                        continue;
                    }
                    schedulers.add(scheduler);
                    try {
                        scheduler.resumeAll();
                    }
                    catch (Exception e) {
                        this.logger.warning("Can't resume scheduler for " + ejb.getEjbName(), e);
                    }
                }
            }
        }
        catch (NoClassDefFoundError noClassDefFoundError) {}
    }
    
    public List<BeanContext> initEjbs(final ClassLoader classLoader, final AppInfo appInfo, final AppContext appContext, final Set<Injection> injections, final List<BeanContext> allDeployments, final String webappId) throws OpenEJBException {
        final String globalTimersOn = SystemInstance.get().getProperty("openejb.timers.on", "true");
        final EjbJarBuilder ejbJarBuilder = new EjbJarBuilder(this.props, appContext);
        for (final EjbJarInfo ejbJar : appInfo.ejbJars) {
            if (this.isSkip(appInfo, webappId, ejbJar)) {
                continue;
            }
            final HashMap<String, BeanContext> deployments = ejbJarBuilder.build(ejbJar, injections, classLoader);
            final JaccPermissionsBuilder jaccPermissionsBuilder = new JaccPermissionsBuilder();
            final PolicyContext policyContext = jaccPermissionsBuilder.build(ejbJar, deployments);
            jaccPermissionsBuilder.install(policyContext);
            final TransactionPolicyFactory transactionPolicyFactory = this.createTransactionPolicyFactory(ejbJar, classLoader);
            for (final BeanContext beanContext : deployments.values()) {
                beanContext.setTransactionPolicyFactory(transactionPolicyFactory);
            }
            final MethodTransactionBuilder methodTransactionBuilder = new MethodTransactionBuilder();
            methodTransactionBuilder.build(deployments, ejbJar.methodTransactions);
            final MethodConcurrencyBuilder methodConcurrencyBuilder = new MethodConcurrencyBuilder();
            methodConcurrencyBuilder.build(deployments, ejbJar.methodConcurrency);
            for (final BeanContext beanContext2 : deployments.values()) {
                this.containerSystem.addDeployment(beanContext2);
            }
            this.jndiBuilder.build(ejbJar, deployments);
            for (final BeanContext beanContext2 : deployments.values()) {
                if (beanContext2.getComponentType() != BeanType.STATEFUL) {
                    final Method ejbTimeout = beanContext2.getEjbTimeout();
                    boolean timerServiceRequired = false;
                    if (ejbTimeout != null) {
                        if (beanContext2.getTransactionType(ejbTimeout) == TransactionType.RequiresNew) {
                            beanContext2.setMethodTransactionAttribute(ejbTimeout, TransactionType.Required);
                        }
                        timerServiceRequired = true;
                    }
                    final Iterator<Map.Entry<Method, MethodContext>> it = beanContext2.iteratorMethodContext();
                    while (it.hasNext()) {
                        final Map.Entry<Method, MethodContext> entry = it.next();
                        final MethodContext methodContext = entry.getValue();
                        if (methodContext.getSchedules().size() > 0) {
                            timerServiceRequired = true;
                            final Method method = entry.getKey();
                            if (beanContext2.getTransactionType(method) != TransactionType.RequiresNew) {
                                continue;
                            }
                            beanContext2.setMethodTransactionAttribute(method, TransactionType.Required);
                        }
                    }
                    if (timerServiceRequired && "true".equalsIgnoreCase(appInfo.properties.getProperty("openejb.timers.on", globalTimersOn))) {
                        final EjbTimerServiceImpl timerService = new EjbTimerServiceImpl(beanContext2, this.newTimerStore(beanContext2));
                        final TimerStore timerStore = timerService.getTimerStore();
                        final Iterator<Map.Entry<Method, MethodContext>> it2 = beanContext2.iteratorMethodContext();
                        while (it2.hasNext()) {
                            final Map.Entry<Method, MethodContext> entry2 = it2.next();
                            final MethodContext methodContext2 = entry2.getValue();
                            for (final ScheduleData scheduleData : methodContext2.getSchedules()) {
                                timerStore.createCalendarTimer(timerService, (String)beanContext2.getDeploymentID(), null, entry2.getKey(), scheduleData.getExpression(), scheduleData.getConfig(), true);
                            }
                        }
                        beanContext2.setEjbTimerService(timerService);
                    }
                    else {
                        beanContext2.setEjbTimerService(new NullEjbTimerServiceImpl());
                    }
                }
                final Iterator<Map.Entry<Method, MethodContext>> it3 = beanContext2.iteratorMethodContext();
                while (it3.hasNext()) {
                    final Map.Entry<Method, MethodContext> entry3 = it3.next();
                    if (entry3.getValue().isAsynchronous() && beanContext2.getTransactionType(entry3.getKey()) == TransactionType.RequiresNew) {
                        beanContext2.setMethodTransactionAttribute(entry3.getKey(), TransactionType.Required);
                    }
                }
                if (beanContext2.isLocalbean() && !beanContext2.getComponentType().isMessageDriven() && !beanContext2.isDynamicallyImplemented()) {
                    final List<Class> interfaces = new ArrayList<Class>(3);
                    interfaces.add(Serializable.class);
                    interfaces.add(IntraVmProxy.class);
                    final BeanType type = beanContext2.getComponentType();
                    if (BeanType.STATEFUL.equals(type) || BeanType.MANAGED.equals(type)) {
                        interfaces.add(BeanContext.Removable.class);
                    }
                    beanContext2.set(BeanContext.ProxyClass.class, new BeanContext.ProxyClass(beanContext2, interfaces.toArray(new Class[interfaces.size()])));
                }
            }
            for (final ApplicationExceptionInfo exceptionInfo : ejbJar.applicationException) {
                try {
                    final Class exceptionClass = classLoader.loadClass(exceptionInfo.exceptionClass);
                    for (final BeanContext beanContext3 : deployments.values()) {
                        beanContext3.addApplicationException(exceptionClass, exceptionInfo.rollback, exceptionInfo.inherited);
                    }
                }
                catch (ClassNotFoundException e) {
                    this.logger.error("createApplication.invalidClass", e, exceptionInfo.exceptionClass, e.getMessage());
                }
            }
            allDeployments.addAll(deployments.values());
        }
        final List<BeanContext> ejbs = sort(allDeployments);
        for (final BeanContext b : ejbs) {
            if (appContext.getBeanContexts().contains(b)) {
                continue;
            }
            appContext.getBeanContexts().add(b);
        }
        return ejbs;
    }
    
    private boolean isSkip(final AppInfo appInfo, final String webappId, final EjbJarInfo ejbJar) {
        boolean skip = false;
        if (!appInfo.webAppAlone) {
            if (webappId == null) {
                skip = ejbJar.webapp;
            }
            else if (!ejbJar.webapp || (!ejbJar.moduleId.equals(webappId) && !ejbJar.properties.getProperty("openejb.ejbmodule.webappId", "-").equals(webappId))) {
                skip = true;
            }
        }
        return skip;
    }
    
    private TimerStore newTimerStore(final BeanContext beanContext) {
        for (final DeploymentContext context : Arrays.asList(beanContext, beanContext.getModuleContext(), beanContext.getModuleContext().getAppContext())) {
            final String timerStoreClass = context.getProperties().getProperty("timerStore.class");
            if (timerStoreClass != null) {
                this.logger.info("Found timer class: " + timerStoreClass);
                try {
                    final Class<?> clazz = beanContext.getClassLoader().loadClass(timerStoreClass);
                    try {
                        final Constructor<?> constructor = clazz.getConstructor(TransactionManager.class);
                        return TimerStore.class.cast(constructor.newInstance(EjbTimerServiceImpl.getDefaultTransactionManager()));
                    }
                    catch (Exception ignored) {
                        return TimerStore.class.cast(clazz.newInstance());
                    }
                }
                catch (Exception e) {
                    this.logger.error("Can't instantiate " + timerStoreClass + ", using default memory timer store");
                }
            }
        }
        return new MemoryTimerStore(EjbTimerServiceImpl.getDefaultTransactionManager());
    }
    
    public void startEjbs(final boolean start, final List<BeanContext> allDeployments) throws OpenEJBException {
        if (start) {
            SystemInstance.get().fireEvent((Object)new BeforeStartEjbs(allDeployments));
            final Collection<BeanContext> toStart = new ArrayList<BeanContext>();
            for (final BeanContext deployment : allDeployments) {
                try {
                    final Container container = deployment.getContainer();
                    if (container.getBeanContext(deployment.getDeploymentID()) != null) {
                        continue;
                    }
                    container.deploy(deployment);
                    if (!((String)deployment.getDeploymentID()).endsWith(".Comp") && !deployment.isHidden()) {
                        this.logger.info("createApplication.createdEjb", deployment.getDeploymentID(), deployment.getEjbName(), container.getContainerID());
                    }
                    if (this.logger.isDebugEnabled()) {
                        for (final Map.Entry<Object, Object> entry : deployment.getProperties().entrySet()) {
                            this.logger.info("createApplication.createdEjb.property", deployment.getEjbName(), entry.getKey(), entry.getValue());
                        }
                    }
                    toStart.add(deployment);
                }
                catch (Throwable t) {
                    throw new OpenEJBException("Error deploying '" + deployment.getEjbName() + "'.  Exception: " + t.getClass() + ": " + t.getMessage(), t);
                }
            }
            for (final BeanContext deployment : toStart) {
                try {
                    final Container container = deployment.getContainer();
                    container.start(deployment);
                    if (((String)deployment.getDeploymentID()).endsWith(".Comp") || deployment.isHidden()) {
                        continue;
                    }
                    this.logger.info("createApplication.startedEjb", deployment.getDeploymentID(), deployment.getEjbName(), container.getContainerID());
                }
                catch (Throwable t) {
                    throw new OpenEJBException("Error starting '" + deployment.getEjbName() + "'.  Exception: " + t.getClass() + ": " + t.getMessage(), t);
                }
            }
        }
    }
    
    private void deployMBean(final WebBeansContext wc, final ClassLoader cl, final String mbeanClass, final Properties appMbeans, final String id) {
        if (LocalMBeanServer.isJMXActive()) {
            Class<?> clazz;
            try {
                clazz = cl.loadClass(mbeanClass);
            }
            catch (ClassNotFoundException e) {
                throw new OpenEJBRuntimeException(e);
            }
            BeanManager bm;
            Bean<?> bean;
            if (wc == null) {
                bm = null;
                bean = null;
            }
            else {
                bm = (BeanManager)wc.getBeanManagerImpl();
                final Set<Bean<?>> beans = (Set<Bean<?>>)bm.getBeans((Type)clazz, new Annotation[0]);
                bean = (Bean<?>)bm.resolve((Set)beans);
            }
            Object instance;
            CreationalContext creationalContext;
            if (bean == null) {
                try {
                    instance = clazz.newInstance();
                }
                catch (InstantiationException e2) {
                    this.logger.error("the mbean " + mbeanClass + " can't be registered because it can't be instantiated", e2);
                    return;
                }
                catch (IllegalAccessException e3) {
                    this.logger.error("the mbean " + mbeanClass + " can't be registered because it can't be accessed", e3);
                    return;
                }
                creationalContext = null;
            }
            else {
                creationalContext = bm.createCreationalContext((Contextual)bean);
                instance = bm.getReference((Bean)bean, (Type)clazz, creationalContext);
            }
            final MBeanServer server = LocalMBeanServer.get();
            try {
                final MBean annotation = clazz.getAnnotation(MBean.class);
                final ObjectName leaf = (annotation == null || annotation.objectName().isEmpty()) ? new ObjectNameBuilder("openejb.user.mbeans").set("application", id).set("group", clazz.getPackage().getName()).set("name", clazz.getSimpleName()).build() : new ObjectName(annotation.objectName());
                server.registerMBean(new DynamicMBeanWrapper(wc, instance), leaf);
                appMbeans.put(mbeanClass, leaf.getCanonicalName());
                if (creationalContext != null && (bean.getScope() == null || Dependent.class.equals(bean.getScope()))) {
                    this.creationalContextForAppMbeans.put(leaf, creationalContext);
                }
                this.logger.info("Deployed MBean(" + leaf.getCanonicalName() + ")");
            }
            catch (Exception e4) {
                this.logger.error("the mbean " + mbeanClass + " can't be registered", e4);
            }
        }
    }
    
    private void ensureWebBeansContext(final AppContext appContext) {
        WebBeansContext webBeansContext = appContext.get(WebBeansContext.class);
        if (webBeansContext == null) {
            webBeansContext = appContext.getWebBeansContext();
            if (webBeansContext == null) {
                final Map<Class<?>, Object> services = new HashMap<Class<?>, Object>();
                services.put(JNDIService.class, new OpenEJBJndiService());
                services.put(AppContext.class, appContext);
                services.put(ScannerService.class, new CdiScanner());
                services.put(BeanArchiveService.class, new OpenEJBBeanInfoService());
                services.put(ELAdaptor.class, new CustomELAdapter(appContext));
                services.put(LoaderService.class, new OptimizedLoaderService(appContext.getProperties()));
                final Properties properties = new Properties();
                properties.setProperty(org.apache.webbeans.spi.SecurityService.class.getName(), ManagedSecurityService.class.getName());
                properties.setProperty(ContextsService.class.getName(), CdiAppContextsService.class.getName());
                properties.setProperty(ResourceInjectionService.class.getName(), CdiResourceInjectionService.class.getName());
                properties.setProperty(TransactionService.class.getName(), OpenEJBTransactionService.class.getName());
                webBeansContext = new WebBeansContext((Map)services, properties);
                appContext.setCdiEnabled(false);
                appContext.set(WebBeansContext.class, webBeansContext);
                appContext.setWebBeansContext(webBeansContext);
            }
            return;
        }
        if (null == appContext.getWebBeansContext()) {
            appContext.setWebBeansContext(webBeansContext);
        }
    }
    
    private TransactionPolicyFactory createTransactionPolicyFactory(final EjbJarInfo ejbJar, final ClassLoader classLoader) {
        TransactionPolicyFactory factory = null;
        final Object value = ejbJar.properties.get(TransactionPolicyFactory.class.getName());
        if (value instanceof TransactionPolicyFactory) {
            factory = (TransactionPolicyFactory)value;
        }
        else if (value instanceof String) {
            try {
                final String[] parts = ((String)value).split(":", 2);
                final ResourceFinder finder = new ResourceFinder("META-INF", classLoader);
                final Map<String, Class<? extends TransactionPolicyFactory>> plugins = (Map<String, Class<? extends TransactionPolicyFactory>>)finder.mapAvailableImplementations((Class)TransactionPolicyFactory.class);
                final Class<? extends TransactionPolicyFactory> clazz = plugins.get(parts[0]);
                if (clazz != null) {
                    if (parts.length == 1) {
                        factory = (TransactionPolicyFactory)clazz.getConstructor(String.class).newInstance(parts[1]);
                    }
                    else {
                        factory = (TransactionPolicyFactory)clazz.newInstance();
                    }
                }
            }
            catch (Exception ex) {}
        }
        if (factory == null) {
            factory = new JtaTransactionPolicyFactory(this.transactionManager);
        }
        return factory;
    }
    
    private static List<BeanContext> sort(List<BeanContext> deployments) {
        Collections.sort(deployments, new Comparator<BeanContext>() {
            @Override
            public int compare(final BeanContext a, final BeanContext b) {
                final int aa = (a.getComponentType() == BeanType.SINGLETON) ? 1 : 0;
                final int bb = (b.getComponentType() == BeanType.SINGLETON) ? 1 : 0;
                return aa - bb;
            }
        });
        deployments = References.sort(deployments, new References.Visitor<BeanContext>() {
            @Override
            public String getName(final BeanContext t) {
                return (String)t.getDeploymentID();
            }
            
            @Override
            public Set<String> getReferences(final BeanContext t) {
                return t.getDependsOn();
            }
        });
        Collections.sort(deployments, new Comparator<BeanContext>() {
            @Override
            public int compare(final BeanContext a, final BeanContext b) {
                final int aa = (a.getComponentType() == BeanType.MESSAGE_DRIVEN) ? 1 : 0;
                final int bb = (b.getComponentType() == BeanType.MESSAGE_DRIVEN) ? 1 : 0;
                return aa - bb;
            }
        });
        return deployments;
    }
    
    @Override
    public void destroy() {
        final ReentrantLock l = Assembler.lock;
        l.lock();
        try {
            final SystemInstance systemInstance = SystemInstance.get();
            systemInstance.fireEvent((Object)new ContainerSystemPreDestroy());
            try {
                EjbTimerServiceImpl.shutdown();
            }
            catch (Exception e) {
                this.logger.warning("Unable to shutdown scheduler", e);
            }
            catch (NoClassDefFoundError noClassDefFoundError) {}
            this.logger.debug("Undeploying Applications");
            final Assembler assembler = this;
            final List<AppInfo> deployedApps = new ArrayList<AppInfo>(assembler.getDeployedApplications());
            Collections.reverse(deployedApps);
            for (final AppInfo appInfo : deployedApps) {
                try {
                    assembler.destroyApplication(appInfo.path);
                }
                catch (UndeployException e2) {
                    this.logger.error("Undeployment failed: " + appInfo.path, e2);
                }
                catch (NoSuchApplicationException ex) {}
            }
            final Iterator<ObjectName> it = this.containerObjectNames.iterator();
            final MBeanServer server = LocalMBeanServer.get();
            while (it.hasNext()) {
                try {
                    server.unregisterMBean(it.next());
                }
                catch (Exception ex2) {}
                it.remove();
            }
            try {
                this.remoteResourceMonitor.unregister();
            }
            catch (Exception ex3) {}
            NamingEnumeration<Binding> namingEnumeration = null;
            try {
                namingEnumeration = this.containerSystem.getJNDIContext().listBindings("openejb/Resource");
            }
            catch (NamingException ex4) {}
            this.destroyResourceTree("", namingEnumeration);
            try {
                this.containerSystem.getJNDIContext().unbind("java:global");
            }
            catch (NamingException ex5) {}
            systemInstance.removeComponent((Class)OpenEjbConfiguration.class);
            systemInstance.removeComponent((Class)JtaEntityManagerRegistry.class);
            systemInstance.removeComponent((Class)TransactionSynchronizationRegistry.class);
            systemInstance.removeComponent((Class)EjbResolver.class);
            systemInstance.fireEvent((Object)new AssemblerDestroyed());
            systemInstance.removeObservers();
            if (DestroyableResource.class.isInstance(this.securityService)) {
                DestroyableResource.class.cast(this.securityService).destroyResource();
            }
            if (DestroyableResource.class.isInstance(this.transactionManager)) {
                DestroyableResource.class.cast(this.transactionManager).destroyResource();
            }
            for (final Container c : this.containerSystem.containers()) {
                if (DestroyableResource.class.isInstance(c)) {
                    DestroyableResource.class.cast(c).destroyResource();
                }
            }
            SystemInstance.reset();
        }
        finally {
            l.unlock();
        }
    }
    
    private Collection<DestroyingResource> destroyResourceTree(final String base, final NamingEnumeration<Binding> namingEnumeration) {
        final List<DestroyingResource> resources = new LinkedList<DestroyingResource>();
        while (namingEnumeration != null && namingEnumeration.hasMoreElements()) {
            final Binding binding = namingEnumeration.nextElement();
            final Object object = binding.getObject();
            if (Context.class.isInstance(object)) {
                try {
                    resources.addAll(this.destroyResourceTree(IvmContext.class.isInstance(object) ? IvmContext.class.cast(object).mynode.getAtomicName() : "", Context.class.cast(object).listBindings("")));
                }
                catch (Exception ex) {}
            }
            else {
                resources.add(new DestroyingResource(((base == null || base.isEmpty()) ? "" : (base + '/')) + binding.getName(), binding.getClassName(), object));
            }
        }
        Collections.sort(resources, new Comparator<DestroyingResource>() {
            @Override
            public int compare(final DestroyingResource o1, final DestroyingResource o2) {
                final boolean ra1 = this.isRa(o1.instance);
                final boolean ra2 = this.isRa(o2.instance);
                if (ra2 && !ra1) {
                    return -1;
                }
                if (ra1 && !ra2) {
                    return 1;
                }
                return o1.name.compareTo(o2.name);
            }
            
            private boolean isRa(final Object instance) {
                return ResourceAdapter.class.isInstance(instance) || ResourceAdapterReference.class.isInstance(instance);
            }
        });
        for (final DestroyingResource resource : resources) {
            try {
                this.destroyResource(resource.name, resource.clazz, resource.instance);
            }
            catch (Throwable th) {
                this.logger.debug(th.getMessage(), th);
            }
        }
        return resources;
    }
    
    private void destroyResource(final String name, final String className, final Object inObject) {
        Object object;
        try {
            object = ((LazyResource.class.isInstance(inObject) && LazyResource.class.cast(inObject).isInitialized()) ? LazyResource.class.cast(inObject).getObject() : inObject);
        }
        catch (NamingException e3) {
            object = inObject;
        }
        final Collection<Method> preDestroy = null;
        if (this.resourceDestroyTimeout != null) {
            final Duration d = new Duration(this.resourceDestroyTimeout);
            final ExecutorService es = Executors.newSingleThreadExecutor(new DaemonThreadFactory(new Object[] { "openejb-resource-destruction-" + name }));
            final Object o = object;
            try {
                es.submit(new Runnable() {
                    @Override
                    public void run() {
                        Assembler.this.doResourceDestruction(name, className, o);
                    }
                }).get(d.getTime(), d.getUnit());
            }
            catch (InterruptedException e4) {
                Thread.interrupted();
            }
            catch (ExecutionException e) {
                throw RuntimeException.class.cast(e.getCause());
            }
            catch (TimeoutException e2) {
                this.logger.error("Can't destroy " + name + " in " + this.resourceDestroyTimeout + ", giving up.", e2);
                if (this.threadStackOnTimeout) {
                    final ThreadInfo[] dump = ManagementFactory.getThreadMXBean().dumpAllThreads(false, false);
                    final ByteArrayOutputStream writer = new ByteArrayOutputStream();
                    final PrintStream stream = new PrintStream(writer);
                    for (final ThreadInfo info : dump) {
                        stream.println('\"' + info.getThreadName() + "\" suspended=" + info.isSuspended() + " state=" + info.getThreadState());
                        for (final StackTraceElement traceElement : info.getStackTrace()) {
                            stream.println("\tat " + traceElement);
                        }
                    }
                    this.logger.info("Dump on " + name + " destruction timeout:\n" + new String(writer.toByteArray()));
                }
            }
        }
        else {
            this.doResourceDestruction(name, className, object);
        }
        this.callPreDestroy(name, object);
        this.removeResourceInfo(name);
    }
    
    private void callPreDestroy(final String name, final Object object) {
        if (object == null) {
            return;
        }
        if (ResourceInstance.class.isInstance(object)) {
            ResourceInstance.class.cast(object).destroyResource();
            return;
        }
        final Class<?> objectClass = object.getClass();
        final ResourceInfo ri = this.findResourceInfo(name);
        if (ri == null) {
            return;
        }
        final Set<String> destroyMethods = new HashSet<String>();
        if (ri.preDestroy != null) {
            destroyMethods.add(ri.preDestroy);
        }
        if (ri.preDestroyMethods != null && ri.preDestroyMethods.size() > 0) {
            destroyMethods.addAll(ri.preDestroyMethods);
        }
        for (final String destroyMethod : destroyMethods) {
            try {
                final Method p = objectClass.getDeclaredMethod(destroyMethod, (Class<?>[])new Class[0]);
                if (!p.isAccessible()) {
                    SetAccessible.on(p);
                }
                p.invoke(object, new Object[0]);
            }
            catch (Exception e) {
                this.logger.error("Unable to call pre destroy method " + destroyMethod + " on " + objectClass.getName() + ". Continuing with resource destruction.", e);
            }
        }
    }
    
    private ResourceInfo findResourceInfo(final String name) {
        final List<ResourceInfo> resourceInfos = this.config.facilities.resources;
        for (final ResourceInfo resourceInfo : resourceInfos) {
            if (resourceInfo.id.equals(name)) {
                return resourceInfo;
            }
        }
        return null;
    }
    
    private void doResourceDestruction(final String name, final String className, final Object jndiObject) {
        final ResourceBeforeDestroyed event = new ResourceBeforeDestroyed(jndiObject, name);
        SystemInstance.get().fireEvent((Object)event);
        final Object object = (event.getReplacement() == null) ? jndiObject : event.getReplacement();
        if (object instanceof ResourceAdapterReference) {
            final ResourceAdapterReference resourceAdapter = (ResourceAdapterReference)object;
            try {
                this.logger.info("Stopping ResourceAdapter: " + name);
                if (this.logger.isDebugEnabled()) {
                    this.logger.debug("Stopping ResourceAdapter: " + className);
                }
                if (resourceAdapter.pool != null && ExecutorService.class.isInstance(resourceAdapter.pool)) {
                    ExecutorService.class.cast(resourceAdapter.pool).shutdownNow();
                }
                resourceAdapter.ra.stop();
            }
            catch (Throwable t) {
                this.logger.fatal("ResourceAdapter Shutdown Failed: " + name, t);
            }
        }
        else if (object instanceof ResourceAdapter) {
            final ResourceAdapter resourceAdapter2 = (ResourceAdapter)object;
            try {
                this.logger.info("Stopping ResourceAdapter: " + name);
                if (this.logger.isDebugEnabled()) {
                    this.logger.debug("Stopping ResourceAdapter: " + className);
                }
                resourceAdapter2.stop();
            }
            catch (Throwable t) {
                this.logger.fatal("ResourceAdapter Shutdown Failed: " + name, t);
            }
        }
        else if (DataSourceFactory.knows(object)) {
            this.logger.info("Closing DataSource: " + name);
            try {
                DataSourceFactory.destroy(object);
            }
            catch (Throwable t2) {}
        }
        else if (object instanceof ConnectorReference) {
            final ConnectorReference cr = (ConnectorReference)object;
            try {
                final ConnectionManager cm = cr.getConnectionManager();
                if (cm != null && cm instanceof AbstractConnectionManager) {
                    ((AbstractConnectionManager)cm).doStop();
                }
            }
            catch (Exception e) {
                this.logger.debug("Not processing resource on destroy: " + className, e);
            }
        }
        else if (DestroyableResource.class.isInstance(object)) {
            try {
                DestroyableResource.class.cast(object).destroyResource();
            }
            catch (RuntimeException e2) {
                this.logger.error(e2.getMessage(), e2);
            }
        }
        else if (this.logger.isDebugEnabled() && !DataSource.class.isInstance(object)) {
            this.logger.debug("Not processing resource on destroy: " + className);
        }
    }
    
    public ResourceInfo removeResourceInfo(final String name) {
        try {
            final OpenEjbConfiguration configuration = (OpenEjbConfiguration)SystemInstance.get().getComponent((Class)OpenEjbConfiguration.class);
            if (configuration == null) {
                throw new Exception("OpenEjbConfiguration has not been initialized");
            }
            final Iterator<ResourceInfo> iterator = configuration.facilities.resources.iterator();
            while (iterator.hasNext()) {
                final ResourceInfo info = iterator.next();
                if (name.equals(info.id)) {
                    iterator.remove();
                    return info;
                }
            }
        }
        catch (Exception e) {
            this.logger.debug("Failed to purge resource on destroy: " + e.getMessage());
        }
        return null;
    }
    
    private static Object unwrapReference(final Object object) {
        Object o = object;
        while (o != null && Reference.class.isInstance(o)) {
            try {
                o = Reference.class.cast(o).getObject();
            }
            catch (NamingException ex) {}
        }
        if (o == null) {
            o = object;
        }
        return o;
    }
    
    public void destroyApplication(final String filePath) throws UndeployException, NoSuchApplicationException {
        final ReentrantLock l = Assembler.lock;
        l.lock();
        try {
            final AppInfo appInfo = this.deployedApplications.remove(filePath);
            if (appInfo == null) {
                throw new NoSuchApplicationException(filePath);
            }
            this.destroyApplication(appInfo);
        }
        finally {
            l.unlock();
        }
    }
    
    public void destroyApplication(final AppContext appContext) throws UndeployException {
        final ReentrantLock l = Assembler.lock;
        l.lock();
        try {
            final AppInfo appInfo = this.deployedApplications.remove(appContext.getId());
            if (appInfo == null) {
                throw new IllegalStateException(String.format("Cannot find AppInfo for app: %s", appContext.getId()));
            }
            this.destroyApplication(appInfo);
        }
        finally {
            l.unlock();
        }
    }
    
    public void destroyApplication(final AppInfo appInfo) throws UndeployException {
        final ReentrantLock l = Assembler.lock;
        l.lock();
        try {
            this.deployedApplications.remove(appInfo.path);
            this.logger.info("destroyApplication.start", appInfo.path);
            final Context globalContext = this.containerSystem.getJNDIContext();
            final AppContext appContext = this.containerSystem.getAppContext(appInfo.appId);
            final ClassLoader classLoader = appContext.getClassLoader();
            SystemInstance.get().fireEvent((Object)new AssemblerBeforeApplicationDestroyed(appInfo, appContext));
            if (null == appContext) {
                this.logger.warning("Application id '" + appInfo.appId + "' not found in: " + Arrays.toString(this.containerSystem.getAppContextKeys()));
                return;
            }
            final WebBeansContext webBeansContext = appContext.getWebBeansContext();
            if (webBeansContext != null) {
                final ClassLoader old = Thread.currentThread().getContextClassLoader();
                Thread.currentThread().setContextClassLoader(classLoader);
                try {
                    final ServletContext context = (appContext.isStandaloneModule() && appContext.getWebContexts().iterator().hasNext()) ? appContext.getWebContexts().iterator().next().getServletContext() : null;
                    ((ContainerLifecycle)webBeansContext.getService((Class)ContainerLifecycle.class)).stopApplication((Object)context);
                }
                finally {
                    Thread.currentThread().setContextClassLoader(old);
                }
            }
            final Map<String, Object> cb = appContext.getBindings();
            for (final Map.Entry<String, Object> value : cb.entrySet()) {
                String path = value.getKey();
                if (path.startsWith("global")) {
                    path = "java:" + path;
                }
                if (!path.startsWith("java:global")) {
                    continue;
                }
                if (IvmContext.class.isInstance(globalContext)) {
                    IvmContext.class.cast(globalContext).setReadOnly(false);
                }
                this.unbind(globalContext, path);
                this.unbind(globalContext, "openejb/global/" + path.substring("java:".length()));
                this.unbind(globalContext, path.substring("java:global".length()));
            }
            if (appInfo.appId != null && !appInfo.appId.isEmpty() && !"openejb".equals(appInfo.appId)) {
                this.unbind(globalContext, "global/" + appInfo.appId);
                this.unbind(globalContext, appInfo.appId);
            }
            final EjbResolver globalResolver = new EjbResolver(null, EjbResolver.Scope.GLOBAL, new EjbJarInfo[0]);
            for (final AppInfo info : this.deployedApplications.values()) {
                globalResolver.addAll(info.ejbJars);
            }
            SystemInstance.get().setComponent((Class)EjbResolver.class, (Object)globalResolver);
            final UndeployException undeployException = new UndeployException(this.messages.format("destroyApplication.failed", appInfo.path));
            final WebAppBuilder webAppBuilder = (WebAppBuilder)SystemInstance.get().getComponent((Class)WebAppBuilder.class);
            if (webAppBuilder != null && !appInfo.webAppAlone) {
                try {
                    webAppBuilder.undeployWebApps(appInfo);
                }
                catch (Exception e) {
                    undeployException.getCauses().add(new Exception("App: " + appInfo.path + ": " + e.getMessage(), e));
                }
            }
            List<BeanContext> deployments = new ArrayList<BeanContext>();
            for (final EjbJarInfo ejbJarInfo : appInfo.ejbJars) {
                for (final EnterpriseBeanInfo beanInfo : ejbJarInfo.enterpriseBeans) {
                    final String deploymentId = beanInfo.ejbDeploymentId;
                    final BeanContext beanContext = this.containerSystem.getBeanContext(deploymentId);
                    if (beanContext == null) {
                        undeployException.getCauses().add(new Exception("deployment not found: " + deploymentId));
                    }
                    else {
                        deployments.add(beanContext);
                    }
                }
            }
            deployments = sort(deployments);
            Collections.reverse(deployments);
            for (final BeanContext deployment : deployments) {
                final String deploymentID = String.valueOf(deployment.getDeploymentID());
                try {
                    final Container container = deployment.getContainer();
                    container.stop(deployment);
                }
                catch (Throwable t) {
                    undeployException.getCauses().add(new Exception("bean: " + deploymentID + ": " + t.getMessage(), t));
                }
            }
            for (final BeanContext bean : deployments) {
                final String deploymentID = String.valueOf(bean.getDeploymentID());
                try {
                    final Container container = bean.getContainer();
                    container.undeploy(bean);
                    bean.setContainer(null);
                }
                catch (Throwable t) {
                    undeployException.getCauses().add(new Exception("bean: " + deploymentID + ": " + t.getMessage(), t));
                }
                finally {
                    bean.setDestroyed(true);
                }
            }
            if (webAppBuilder != null && appInfo.webAppAlone) {
                try {
                    webAppBuilder.undeployWebApps(appInfo);
                }
                catch (Exception e2) {
                    undeployException.getCauses().add(new Exception("App: " + appInfo.path + ": " + e2.getMessage(), e2));
                }
            }
            final List<String> clientIds = new ArrayList<String>();
            for (final ClientInfo clientInfo : appInfo.clients) {
                clientIds.add(clientInfo.moduleId);
                for (final String className : clientInfo.localClients) {
                    clientIds.add(className);
                }
                for (final String className : clientInfo.remoteClients) {
                    clientIds.add(className);
                }
            }
            for (final WebContext webContext : appContext.getWebContexts()) {
                this.containerSystem.removeWebContext(webContext);
            }
            TldScanner.forceCompleteClean(classLoader);
            for (final BeanContext deployment2 : deployments) {
                final String deploymentID2 = String.valueOf(deployment2.getDeploymentID());
                try {
                    this.containerSystem.removeBeanContext(deployment2);
                }
                catch (Throwable t2) {
                    undeployException.getCauses().add(new Exception(deploymentID2, t2));
                }
                final JndiBuilder.Bindings bindings = deployment2.get(JndiBuilder.Bindings.class);
                if (bindings != null) {
                    for (final String name : bindings.getBindings()) {
                        try {
                            globalContext.unbind(name);
                        }
                        catch (Throwable t3) {
                            undeployException.getCauses().add(new Exception("bean: " + deploymentID2 + ": " + t3.getMessage(), t3));
                        }
                    }
                }
            }
            final AsynchronousPool pool = appContext.get(AsynchronousPool.class);
            if (pool != null) {
                pool.stop();
            }
            for (final CommonInfoObject jar : listCommonInfoObjectsForAppInfo(appInfo)) {
                try {
                    globalContext.unbind("openejb/ValidatorFactory/" + jar.uniqueId);
                    globalContext.unbind("openejb/Validator/" + jar.uniqueId);
                }
                catch (NamingException e3) {
                    if (!EjbJarInfo.class.isInstance(jar)) {
                        continue;
                    }
                    undeployException.getCauses().add(new Exception("validator: " + jar.uniqueId + ": " + e3.getMessage(), e3));
                }
            }
            try {
                if (globalContext instanceof IvmContext) {
                    final IvmContext ivmContext = (IvmContext)globalContext;
                    ivmContext.prune("openejb/Deployment");
                    ivmContext.prune("openejb/local");
                    ivmContext.prune("openejb/remote");
                    ivmContext.prune("openejb/global");
                }
            }
            catch (NamingException e4) {
                undeployException.getCauses().add(new Exception("Unable to prune openejb/Deployments and openejb/local namespaces, this could cause future deployments to fail.", e4));
            }
            deployments.clear();
            for (final String clientId : clientIds) {
                try {
                    globalContext.unbind("/openejb/client/" + clientId);
                }
                catch (Throwable t2) {
                    undeployException.getCauses().add(new Exception("client: " + clientId + ": " + t2.getMessage(), t2));
                }
            }
            final MBeanServer server = LocalMBeanServer.get();
            for (final Object objectName : appInfo.jmx.values()) {
                try {
                    final ObjectName on = new ObjectName((String)objectName);
                    if (server.isRegistered(on)) {
                        server.unregisterMBean(on);
                    }
                    final CreationalContext cc = this.creationalContextForAppMbeans.remove(on);
                    if (cc == null) {
                        continue;
                    }
                    cc.release();
                }
                catch (InstanceNotFoundException e5) {
                    this.logger.warning("can't unregister " + objectName + " because the mbean was not found", e5);
                }
                catch (MBeanRegistrationException e6) {
                    this.logger.warning("can't unregister " + objectName, e6);
                }
                catch (MalformedObjectNameException mone) {
                    this.logger.warning("can't unregister because the ObjectName is malformed: " + objectName, mone);
                }
            }
            for (final PersistenceUnitInfo unitInfo : appInfo.persistenceUnits) {
                try {
                    final Object object = globalContext.lookup("openejb/PersistenceUnit/" + unitInfo.id);
                    globalContext.unbind("openejb/PersistenceUnit/" + unitInfo.id);
                    final ReloadableEntityManagerFactory remf = (ReloadableEntityManagerFactory)object;
                    remf.close();
                    this.persistenceClassLoaderHandler.destroy(unitInfo.id);
                    remf.unregister();
                }
                catch (Throwable t4) {
                    undeployException.getCauses().add(new Exception("persistence-unit: " + unitInfo.id + ": " + t4.getMessage(), t4));
                }
            }
            for (final String id : appInfo.resourceAliases) {
                final String name2 = "openejb/Resource/" + id;
                ContextualJndiReference.followReference.set(false);
                try {
                    Object object2;
                    try {
                        object2 = globalContext.lookup(name2);
                    }
                    finally {
                        ContextualJndiReference.followReference.remove();
                    }
                    if (object2 instanceof ContextualJndiReference) {
                        final ContextualJndiReference contextualJndiReference = ContextualJndiReference.class.cast(object2);
                        contextualJndiReference.removePrefix(appContext.getId());
                        if (!contextualJndiReference.hasNoMorePrefix()) {
                            continue;
                        }
                        globalContext.unbind(name2);
                    }
                    else {
                        globalContext.unbind(name2);
                    }
                }
                catch (NamingException e8) {
                    this.logger.warning("can't unbind resource '{0}'", id);
                }
            }
            for (final String id : appInfo.resourceIds) {
                final String name2 = "openejb/Resource/" + id;
                try {
                    this.destroyLookedUpResource(globalContext, id, name2);
                }
                catch (NamingException e8) {
                    this.logger.warning("can't unbind resource '{0}'", id);
                }
            }
            for (final ConnectorInfo connector : appInfo.connectors) {
                if (connector.resourceAdapter != null) {
                    if (connector.resourceAdapter.id == null) {
                        continue;
                    }
                    final String name2 = "openejb/Resource/" + connector.resourceAdapter.id;
                    try {
                        this.destroyLookedUpResource(globalContext, connector.resourceAdapter.id, name2);
                    }
                    catch (NamingException e8) {
                        this.logger.warning("can't unbind resource '{0}'", connector);
                    }
                    for (final ResourceInfo outbound : connector.outbound) {
                        try {
                            this.destroyLookedUpResource(globalContext, outbound.id, "openejb/Resource/" + outbound.id);
                        }
                        catch (Exception ex) {}
                    }
                    for (final ResourceInfo outbound : connector.adminObject) {
                        try {
                            this.destroyLookedUpResource(globalContext, outbound.id, "openejb/Resource/" + outbound.id);
                        }
                        catch (Exception ex2) {}
                    }
                    for (final MdbContainerInfo container2 : connector.inbound) {
                        try {
                            this.containerSystem.removeContainer(container2.id);
                            this.config.containerSystem.containers.remove(container2);
                            this.containerSystem.getJNDIContext().unbind("openejb/" + container2.service + "/" + container2.id);
                        }
                        catch (Exception ex3) {}
                    }
                }
            }
            for (final String id : appInfo.containerIds) {
                this.removeContainer(id);
            }
            this.containerSystem.removeAppContext(appInfo.appId);
            if (!appInfo.properties.containsKey("tomee.destroying")) {
                try {
                    final Method m = classLoader.getClass().getMethod("internalStop", (Class<?>[])new Class[0]);
                    m.invoke(classLoader, new Object[0]);
                }
                catch (NoSuchMethodException ex4) {}
                catch (Exception e7) {
                    this.logger.error("error stopping classloader of webapp " + appInfo.appId, e7);
                }
                ClassLoaderUtil.cleanOpenJPACache(classLoader);
            }
            ClassLoaderUtil.destroyClassLoader(appInfo.appId, appInfo.path);
            if (undeployException.getCauses().size() > 0) {
                throw undeployException;
            }
            this.logger.debug("destroyApplication.success", appInfo.path);
        }
        finally {
            l.unlock();
        }
    }
    
    private void destroyLookedUpResource(final Context globalContext, final String id, final String name) throws NamingException {
        Object object;
        try {
            object = globalContext.lookup(name);
        }
        catch (NamingException e) {
            final String ctx = name.substring(0, name.lastIndexOf("/"));
            final String objName = name.substring(ctx.length() + 1);
            final NamingEnumeration<Binding> bindings = globalContext.listBindings(ctx);
            while (bindings.hasMoreElements()) {
                final Binding binding = bindings.nextElement();
                if (!binding.getName().equals(objName)) {
                    continue;
                }
                if (!LazyObjectReference.class.isInstance(binding.getObject())) {
                    continue;
                }
                final LazyObjectReference<?> ref = LazyObjectReference.class.cast(binding.getObject());
                if (!ref.isInitialized()) {
                    globalContext.unbind(name);
                    this.removeResourceInfo(name);
                    return;
                }
            }
            throw e;
        }
        String clazz;
        if (object == null) {
            clazz = "?";
        }
        else {
            clazz = object.getClass().getName();
        }
        this.destroyResource(id, clazz, object);
        globalContext.unbind(name);
    }
    
    private void unbind(final Context context, final String name) {
        try {
            context.unbind(name);
        }
        catch (NamingException ex) {}
    }
    
    public ClassLoader createAppClassLoader(final AppInfo appInfo) throws OpenEJBException, IOException {
        if ("openejb".equals(appInfo.appId)) {
            return ParentClassLoaderFinder.Helper.get();
        }
        final Set<URL> jars = new HashSet<URL>();
        for (final EjbJarInfo info : appInfo.ejbJars) {
            if (info.path != null) {
                jars.add(this.toUrl(info.path));
            }
        }
        for (final ClientInfo info2 : appInfo.clients) {
            if (info2.path != null) {
                jars.add(this.toUrl(info2.path));
            }
        }
        for (final ConnectorInfo info3 : appInfo.connectors) {
            for (final String jarPath : info3.libs) {
                jars.add(this.toUrl(jarPath));
            }
        }
        for (final String jarPath2 : appInfo.libs) {
            jars.add(this.toUrl(jarPath2));
        }
        if (appInfo.libs.size() > 0) {
            try {
                final File jpaIntegrationFile = JarLocation.jarLocation((Class)MakeTxLookup.class);
                final URL url = jpaIntegrationFile.toURI().toURL();
                if (!jars.contains(url)) {
                    jars.add(url);
                }
            }
            catch (RuntimeException re) {
                this.logger.warning("Unable to find the open-jpa-integration jar");
            }
        }
        final ClassLoaderEnricher component = (ClassLoaderEnricher)SystemInstance.get().getComponent((Class)ClassLoaderEnricher.class);
        if (component != null) {
            jars.addAll(Arrays.asList(component.applicationEnrichment()));
        }
        else {
            this.logger.warning("Unable to find open-jpa-integration jar");
        }
        final ClassLoader parent = ParentClassLoaderFinder.Helper.get();
        String prefix;
        if (appInfo.webAppAlone) {
            prefix = "WEB-INF/";
        }
        else {
            prefix = "META-INF/";
        }
        final ClassLoaderConfigurer configurer1 = QuickJarsTxtParser.parse(new File(appInfo.path, prefix + "jars.txt"));
        final ClassLoaderConfigurer configurer2 = ClassLoaderUtil.configurer(appInfo.appId);
        if (configurer1 != null || configurer2 != null) {
            final ClassLoaderConfigurer configurer3 = new CompositeClassLoaderConfigurer(new ClassLoaderConfigurer[] { configurer1, configurer2 });
            ClassLoaderConfigurer.Helper.configure(jars, configurer3);
        }
        final URL[] filtered = jars.toArray(new URL[jars.size()]);
        if (this.skipLoaderIfPossible) {
            if ("classpath.ear".equals(appInfo.appId)) {
                return parent;
            }
            final Collection<File> urls = new HashSet<File>();
            for (final URL url2 : ClassLoaders.findUrls(parent)) {
                try {
                    urls.add(URLs.toFile(url2).getCanonicalFile());
                }
                catch (Exception error) {
                    if (!this.logger.isDebugEnabled()) {
                        continue;
                    }
                    this.logger.debug("Can't determine url for: " + url2.toExternalForm(), error);
                }
            }
            boolean allIsIntheClasspath = true;
            for (final URL url3 : filtered) {
                try {
                    if (!urls.contains(URLs.toFile(url3).getCanonicalFile())) {
                        allIsIntheClasspath = false;
                        if (this.logger.isDebugEnabled()) {
                            this.logger.debug(url3.toExternalForm() + " (" + URLs.toFile(url3) + ") is not in the classloader so we'll create a dedicated classloader for this app");
                        }
                        break;
                    }
                }
                catch (Exception ignored) {
                    allIsIntheClasspath = false;
                    if (this.logger.isDebugEnabled()) {
                        this.logger.debug(url3.toExternalForm() + " (" + URLs.toFile(url3) + ") is not in the classloader", ignored);
                    }
                    break;
                }
            }
            if (allIsIntheClasspath) {
                this.logger.info("Not creating another application classloader for " + appInfo.appId);
                return parent;
            }
            if (this.logger.isDebugEnabled()) {
                this.logger.debug("Logging all urls from the app since we don't skip the app classloader creation:");
                for (final URL url3 : filtered) {
                    this.logger.debug(" -> " + url3.toExternalForm());
                }
                this.logger.debug("Logging all urls from the classloader since we don't skip the app classloader creation:");
                for (final File url4 : urls) {
                    this.logger.debug(" -> " + url4.getAbsolutePath());
                }
            }
        }
        this.logger.info("Creating dedicated application classloader for " + appInfo.appId);
        if (!appInfo.delegateFirst) {
            return ClassLoaderUtil.createClassLoader(appInfo.path, filtered, parent);
        }
        return ClassLoaderUtil.createClassLoaderFirst(appInfo.path, filtered, parent);
    }
    
    public void createExternalContext(final JndiContextInfo contextInfo) throws OpenEJBException {
        this.logger.getChildLogger("service").info("createService", contextInfo.service, contextInfo.id, contextInfo.className);
        InitialContext initialContext;
        try {
            initialContext = new InitialContext(contextInfo.properties);
        }
        catch (NamingException ne) {
            throw new OpenEJBException(String.format("JndiProvider(id=\"%s\") could not be created.  Failed to create the InitialContext using the supplied properties", contextInfo.id), ne);
        }
        try {
            this.containerSystem.getJNDIContext().bind("openejb/remote_jndi_contexts/" + contextInfo.id, initialContext);
        }
        catch (NamingException e) {
            throw new OpenEJBException("Cannot bind " + contextInfo.service + " with id " + contextInfo.id, e);
        }
        this.config.facilities.remoteJndiContexts.add(contextInfo);
        this.logger.getChildLogger("service").debug("createService.success", contextInfo.service, contextInfo.id, contextInfo.className);
    }
    
    public void createContainer(final ContainerInfo serviceInfo) throws OpenEJBException {
        final ObjectRecipe serviceRecipe = this.createRecipe((Collection<ServiceInfo>)Collections.emptyList(), serviceInfo);
        serviceRecipe.setProperty("id", (Object)serviceInfo.id);
        serviceRecipe.setProperty("transactionManager", this.props.get(TransactionManager.class.getName()));
        serviceRecipe.setProperty("securityService", this.props.get(SecurityService.class.getName()));
        serviceRecipe.setProperty("properties", (Object)new UnsetPropertiesRecipe());
        this.replaceResourceAdapterProperty(serviceRecipe);
        final Object service = serviceRecipe.create();
        serviceRecipe.getUnsetProperties().remove("id");
        serviceRecipe.getUnsetProperties().remove("securityService");
        logUnusedProperties(serviceRecipe, serviceInfo);
        final Class interfce = Assembler.serviceInterfaces.get(serviceInfo.service);
        AssemblerTool.checkImplementation(interfce, service.getClass(), serviceInfo.service, serviceInfo.id);
        this.bindService(serviceInfo, service);
        this.setSystemInstanceComponent(interfce, service);
        this.props.put(interfce.getName(), service);
        this.props.put(serviceInfo.service, service);
        this.props.put(serviceInfo.id, service);
        this.containerSystem.addContainer(serviceInfo.id, (Container)service);
        this.config.containerSystem.containers.add(serviceInfo);
        this.logger.getChildLogger("service").debug("createService.success", serviceInfo.service, serviceInfo.id, serviceInfo.className);
        if (Container.class.isInstance(service) && LocalMBeanServer.isJMXActive()) {
            final ObjectName objectName = ObjectNameBuilder.uniqueName("containers", serviceInfo.id, service);
            try {
                LocalMBeanServer.get().registerMBean(new DynamicMBeanWrapper(new JMXContainer(serviceInfo, (Container)service)), objectName);
                this.containerObjectNames.add(objectName);
            }
            catch (Exception ex) {}
            catch (NoClassDefFoundError noClassDefFoundError) {}
        }
    }
    
    private void bindService(final ServiceInfo serviceInfo, final Object service) throws OpenEJBException {
        try {
            this.containerSystem.getJNDIContext().bind("openejb/" + serviceInfo.service + "/" + serviceInfo.id, service);
        }
        catch (NamingException e) {
            throw new OpenEJBException(this.messages.format("assembler.cannotBindServiceWithId", serviceInfo.service, serviceInfo.id), e);
        }
    }
    
    public void removeContainer(final String containerId) {
        this.containerSystem.removeContainer(containerId);
        final Iterator<ContainerInfo> iterator = this.config.containerSystem.containers.iterator();
        while (iterator.hasNext()) {
            final ContainerInfo containerInfo = iterator.next();
            if (containerInfo.id.equals(containerId)) {
                iterator.remove();
                try {
                    this.containerSystem.getJNDIContext().unbind("openejb/" + containerInfo.service + "/" + containerInfo.id);
                }
                catch (Exception e) {
                    this.logger.error("removeContainer.unbindFailed", containerId);
                }
            }
        }
    }
    
    public void createService(final ServiceInfo serviceInfo) throws OpenEJBException {
        final ObjectRecipe serviceRecipe = this.createRecipe((Collection<ServiceInfo>)Collections.emptyList(), serviceInfo);
        serviceRecipe.setProperty("properties", (Object)new UnsetPropertiesRecipe());
        final Object service = serviceRecipe.create();
        SystemInstance.get().addObserver(service);
        logUnusedProperties(serviceRecipe, serviceInfo);
        final Class<?> serviceClass = service.getClass();
        getContext().put(serviceClass.getName(), service);
        this.props.put(serviceClass.getName(), service);
        this.props.put(serviceInfo.service, service);
        this.props.put(serviceInfo.id, service);
        this.config.facilities.services.add(serviceInfo);
        this.logger.getChildLogger("service").debug("createService.success", serviceInfo.service, serviceInfo.id, serviceInfo.className);
    }
    
    public void createProxyFactory(final ProxyFactoryInfo serviceInfo) throws OpenEJBException {
        final ObjectRecipe serviceRecipe = this.createRecipe((Collection<ServiceInfo>)Collections.emptyList(), serviceInfo);
        final Object service = serviceRecipe.create();
        logUnusedProperties(serviceRecipe, serviceInfo);
        final Class interfce = Assembler.serviceInterfaces.get(serviceInfo.service);
        AssemblerTool.checkImplementation(interfce, service.getClass(), serviceInfo.service, serviceInfo.id);
        ProxyManager.registerFactory(serviceInfo.id, (ProxyFactory)service);
        ProxyManager.setDefaultFactory(serviceInfo.id);
        this.bindService(serviceInfo, service);
        this.setSystemInstanceComponent(interfce, service);
        getContext().put(interfce.getName(), service);
        this.props.put(interfce.getName(), service);
        this.props.put(serviceInfo.service, service);
        this.props.put(serviceInfo.id, service);
        this.config.facilities.intraVmServer = serviceInfo;
        this.logger.getChildLogger("service").debug("createService.success", serviceInfo.service, serviceInfo.id, serviceInfo.className);
    }
    
    private void replaceResourceAdapterProperty(final ObjectRecipe serviceRecipe) throws OpenEJBException {
        final Object resourceAdapterId = serviceRecipe.getProperty("ResourceAdapter");
        if (resourceAdapterId instanceof String) {
            String id = (String)resourceAdapterId;
            id = id.trim();
            Object resourceAdapter = null;
            try {
                resourceAdapter = this.containerSystem.getJNDIContext().lookup("openejb/Resource/" + id);
            }
            catch (NamingException ex) {}
            if (Reference.class.isInstance(resourceAdapter)) {
                try {
                    resourceAdapter = Reference.class.cast(resourceAdapter).getContent();
                }
                catch (NamingException ex2) {}
            }
            if (resourceAdapter == null) {
                throw new OpenEJBException("No existing resource adapter defined with id '" + id + "'.");
            }
            if (!(resourceAdapter instanceof ResourceAdapter)) {
                throw new OpenEJBException(this.messages.format("assembler.resourceAdapterNotResourceAdapter", id, resourceAdapter.getClass()));
            }
            serviceRecipe.setProperty("ResourceAdapter", resourceAdapter);
        }
    }
    
    @Deprecated
    public void createResource(final ResourceInfo serviceInfo) throws OpenEJBException {
        this.createResource(null, serviceInfo);
    }
    
    public void createResource(final Collection<ServiceInfo> infos, final ResourceInfo serviceInfo) throws OpenEJBException {
        final boolean usesCdiPwdCipher = this.usesCdiPwdCipher(serviceInfo);
        final Object service = ("true".equalsIgnoreCase(String.valueOf(serviceInfo.properties.remove("Lazy"))) || usesCdiPwdCipher) ? this.newLazyResource(infos, serviceInfo) : this.doCreateResource(infos, serviceInfo);
        if (usesCdiPwdCipher && !serviceInfo.properties.contains("InitializeAfterDeployment")) {
            serviceInfo.properties.put("InitializeAfterDeployment", "true");
        }
        this.bindResource(serviceInfo.id, service, false);
        for (final String alias : serviceInfo.aliases) {
            this.bindResource(alias, service, false);
        }
        if (serviceInfo.originAppName != null && !serviceInfo.originAppName.isEmpty() && !"/".equals(serviceInfo.originAppName) && !serviceInfo.id.startsWith("global")) {
            final String baseJndiName = serviceInfo.id.substring(serviceInfo.originAppName.length() + 1);
            serviceInfo.aliases.add(baseJndiName);
            final ContextualJndiReference ref = new ContextualJndiReference(baseJndiName);
            ref.addPrefix(serviceInfo.originAppName);
            this.bindResource(baseJndiName, ref, false);
        }
        this.config.facilities.resources.add(serviceInfo);
        if (this.logger.isDebugEnabled()) {
            this.logger.getChildLogger("service").debug("createService.success", serviceInfo.service, serviceInfo.id, serviceInfo.className);
        }
    }
    
    private boolean usesCdiPwdCipher(final ResourceInfo serviceInfo) {
        for (final Object val : serviceInfo.properties.values()) {
            if (String.valueOf(val).startsWith("cipher:cdi:")) {
                return true;
            }
        }
        return false;
    }
    
    private LazyResource newLazyResource(final Collection<ServiceInfo> infos, final ResourceInfo serviceInfo) {
        return new LazyResource(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                final boolean appClassLoader = "true".equals(serviceInfo.properties.remove("UseAppClassLoader")) || serviceInfo.originAppName != null;
                final Thread thread = Thread.currentThread();
                final ClassLoader old = thread.getContextClassLoader();
                if (!appClassLoader) {
                    final ClassLoader classLoader = Assembler.class.getClassLoader();
                    thread.setContextClassLoader((classLoader == null) ? ClassLoader.getSystemClassLoader() : classLoader);
                }
                try {
                    return Assembler.this.doCreateResource(infos, serviceInfo);
                }
                finally {
                    thread.setContextClassLoader(old);
                }
            }
        });
    }
    
    private Object doCreateResource(final Collection<ServiceInfo> infos, final ResourceInfo serviceInfo) throws OpenEJBException {
        final String skipPropertiesFallback = (String)serviceInfo.properties.remove("SkipPropertiesFallback");
        final ObjectRecipe serviceRecipe = this.createRecipe(infos, serviceInfo);
        final boolean properties = PropertiesFactory.class.getName().equals(serviceInfo.className);
        if ("false".equalsIgnoreCase(serviceInfo.properties.getProperty("SkipImplicitAttributes", "false")) && !properties) {
            serviceRecipe.setProperty("transactionManager", (Object)this.transactionManager);
            serviceRecipe.setProperty("ServiceId", (Object)serviceInfo.id);
        }
        serviceInfo.properties.remove("SkipImplicitAttributes");
        final AtomicReference<Properties> injectedProperties = new AtomicReference<Properties>();
        if (!"true".equalsIgnoreCase(skipPropertiesFallback)) {
            serviceRecipe.setProperty("properties", (Object)new UnsetPropertiesRecipe() {
                protected Object internalCreate(final Type expectedType, final boolean lazyRefAllowed) throws ConstructionException {
                    final Map<String, Object> original = (Map<String, Object>)serviceRecipe.getUnsetProperties();
                    final Properties properties = new SuperProperties() {
                        @Override
                        public Object remove(final Object key) {
                            original.remove(key);
                            return super.remove(key);
                        }
                    }.caseInsensitive(true);
                    for (final Map.Entry<String, Object> entry : original.entrySet()) {
                        properties.put(entry.getKey(), entry.getValue());
                    }
                    injectedProperties.set(properties);
                    return properties;
                }
            });
        }
        else {
            final Map<String, Object> unsetProperties = (Map<String, Object>)serviceRecipe.getUnsetProperties();
            injectedProperties.set(new Properties() {
                @Override
                public String getProperty(final String key) {
                    final Object obj = unsetProperties.get(key);
                    return String.class.isInstance(obj) ? String.valueOf(obj) : null;
                }
                
                @Override
                public Set<String> stringPropertyNames() {
                    return unsetProperties.keySet();
                }
                
                @Override
                public Set<Object> keySet() {
                    return Set.class.cast(unsetProperties.keySet());
                }
                
                @Override
                public synchronized boolean containsKey(final Object key) {
                    return this.getProperty(String.valueOf(key)) != null;
                }
            });
        }
        if (serviceInfo.types.contains("DataSource") || serviceInfo.types.contains(DataSource.class.getName())) {
            final Properties props = PropertyPlaceHolderHelper.simpleHolds(serviceInfo.properties);
            if (serviceInfo.properties.containsKey("Definition")) {
                final Object encoding = serviceInfo.properties.remove("DefinitionEncoding");
                try {
                    final InputStream is = new ByteArrayInputStream(serviceInfo.properties.getProperty("Definition").getBytes((encoding != null) ? encoding.toString() : "ISO-8859-1"));
                    final Properties p = new SuperProperties();
                    IO.readProperties(is, p);
                    for (final Map.Entry<Object, Object> entry : p.entrySet()) {
                        final String key = entry.getKey().toString();
                        if (!props.containsKey(key) && (!key.equalsIgnoreCase("url") || !props.containsKey("JdbcUrl"))) {
                            props.put(key, entry.getValue());
                        }
                    }
                }
                catch (Exception ex) {}
            }
            serviceRecipe.setProperty("Definition", (Object)PropertiesHelper.propertiesToString(props));
        }
        this.replaceResourceAdapterProperty(serviceRecipe);
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        boolean customLoader = false;
        try {
            if (serviceInfo.classpath != null && serviceInfo.classpath.length > 0) {
                final URL[] urls = new URL[serviceInfo.classpath.length];
                for (int i = 0; i < serviceInfo.classpath.length; ++i) {
                    urls[i] = serviceInfo.classpath[i].toURL();
                }
                loader = new URLClassLoaderFirst(urls, loader);
                customLoader = true;
                serviceRecipe.setProperty("OpenEJBResourceClasspath", (Object)"true");
            }
        }
        catch (MalformedURLException e) {
            throw new OpenEJBException("Unable to create a classloader for " + serviceInfo.id, e);
        }
        if (!customLoader && serviceInfo.classpathAPI != null) {
            throw new IllegalArgumentException("custom-api provided but not classpath used for " + serviceInfo.id);
        }
        Object service = serviceRecipe.create(loader);
        if (customLoader) {
            Collection<Class<?>> apis;
            if (serviceInfo.classpathAPI == null) {
                apis = new ArrayList<Class<?>>(Arrays.asList(service.getClass().getInterfaces()));
            }
            else {
                final String[] split = serviceInfo.classpathAPI.split(" *, *");
                apis = new ArrayList<Class<?>>(split.length);
                final ClassLoader apiLoader = Thread.currentThread().getContextClassLoader();
                for (final String fqn : split) {
                    try {
                        apis.add(apiLoader.loadClass(fqn));
                    }
                    catch (ClassNotFoundException e2) {
                        throw new IllegalArgumentException(fqn + " not usable as API for " + serviceInfo.id, e2);
                    }
                }
            }
            if (apis.size() - (apis.contains(Serializable.class) ? 1 : 0) - (apis.contains(Externalizable.class) ? 1 : 0) > 0) {
                service = Proxy.newProxyInstance(loader, apis.toArray(new Class[apis.size()]), new ClassLoaderAwareHandler(null, service, loader));
            }
        }
        serviceInfo.unsetProperties = injectedProperties.get();
        if (service instanceof ResourceAdapter) {
            final ResourceAdapter resourceAdapter = (ResourceAdapter)service;
            final int threadPoolSize = this.getIntProperty(serviceInfo.properties, "threadPoolSize", 30);
            Executor threadPool;
            if (threadPoolSize <= 0) {
                this.logger.warning("Thread pool for '" + serviceInfo.id + "' is (unbounded), consider setting a size using: " + serviceInfo.id + ".QueueSize=[size]");
                threadPool = Executors.newCachedThreadPool(new DaemonThreadFactory(new Object[] { serviceInfo.id + "-worker-" }));
            }
            else {
                threadPool = new ExecutorBuilder().size(threadPoolSize).prefix(serviceInfo.id).threadFactory(new DaemonThreadFactory(new Object[] { serviceInfo.id + "-worker-" })).build(new Options(serviceInfo.properties, SystemInstance.get().getOptions()));
                this.logger.info("Thread pool size for '" + serviceInfo.id + "' is (" + threadPoolSize + ")");
            }
            WorkManager workManager;
            if (GeronimoTransactionManager.class.isInstance(this.transactionManager)) {
                final GeronimoTransactionManager geronimoTransactionManager = (GeronimoTransactionManager)this.transactionManager;
                final TransactionContextHandler txWorkContextHandler = new TransactionContextHandler((XAWork)geronimoTransactionManager);
                final String securityRealmName = this.getStringProperty(serviceInfo.properties, "realm", serviceInfo.id);
                final SecurityContextHandler securityContextHandler = new SecurityContextHandler(securityRealmName);
                final HintsContextHandler hintsContextHandler = new HintsContextHandler();
                final Collection<WorkContextHandler> workContextHandlers = new ArrayList<WorkContextHandler>();
                workContextHandlers.add((WorkContextHandler)txWorkContextHandler);
                workContextHandlers.add((WorkContextHandler)securityContextHandler);
                workContextHandlers.add((WorkContextHandler)hintsContextHandler);
                workManager = (WorkManager)new GeronimoWorkManager(threadPool, threadPool, threadPool, (Collection)workContextHandlers);
            }
            else {
                workManager = (WorkManager)new SimpleWorkManager(threadPool);
            }
            BootstrapContext bootstrapContext;
            if (this.transactionManager instanceof GeronimoTransactionManager) {
                bootstrapContext = (BootstrapContext)new GeronimoBootstrapContext((GeronimoWorkManager)GeronimoWorkManager.class.cast(workManager), (XATerminator)this.transactionManager, (TransactionSynchronizationRegistry)this.transactionManager);
            }
            else if (this.transactionManager instanceof XATerminator) {
                bootstrapContext = (BootstrapContext)new SimpleBootstrapContext(workManager, (XATerminator)this.transactionManager);
            }
            else {
                bootstrapContext = (BootstrapContext)new SimpleBootstrapContext(workManager);
            }
            try {
                this.logger.debug("createResource.startingResourceAdapter", serviceInfo.id, service.getClass().getName());
                resourceAdapter.start(bootstrapContext);
            }
            catch (ResourceAdapterInternalException e3) {
                throw new OpenEJBException((Throwable)e3);
            }
            final Map<String, Object> unset = (Map<String, Object>)serviceRecipe.getUnsetProperties();
            unset.remove("threadPoolSize");
            logUnusedProperties(unset, serviceInfo);
            service = new ResourceAdapterReference(resourceAdapter, threadPool, "openejb/Resource/" + serviceInfo.id);
        }
        else if (service instanceof ManagedConnectionFactory) {
            final ManagedConnectionFactory managedConnectionFactory = (ManagedConnectionFactory)service;
            final ObjectRecipe connectionManagerRecipe = new ObjectRecipe((Class)GeronimoConnectionManagerFactory.class, "create");
            connectionManagerRecipe.allow(Option.CASE_INSENSITIVE_PROPERTIES);
            connectionManagerRecipe.allow(Option.IGNORE_MISSING_PROPERTIES);
            connectionManagerRecipe.setAllProperties((Map)serviceInfo.properties);
            connectionManagerRecipe.setProperty("name", (Object)serviceInfo.id);
            connectionManagerRecipe.setProperty("mcf", (Object)managedConnectionFactory);
            connectionManagerRecipe.setProperty("transactionManager", (Object)this.transactionManager);
            ClassLoader classLoader = loader;
            if (classLoader == null) {
                classLoader = this.getClass().getClassLoader();
            }
            if (classLoader == null) {
                classLoader = ClassLoader.getSystemClassLoader();
            }
            connectionManagerRecipe.setProperty("classLoader", (Object)classLoader);
            this.logger.getChildLogger("service").info("createResource.createConnectionManager", serviceInfo.id, service.getClass().getName());
            final ConnectionManager connectionManager = (ConnectionManager)connectionManagerRecipe.create();
            if (connectionManager == null) {
                throw new OpenEJBRuntimeException(this.messages.format("assembler.invalidConnectionManager", serviceInfo.id));
            }
            final Map<String, Object> unsetA = (Map<String, Object>)serviceRecipe.getUnsetProperties();
            final Map<String, Object> unsetB = (Map<String, Object>)connectionManagerRecipe.getUnsetProperties();
            final Map<String, Object> unset2 = new HashMap<String, Object>();
            for (final Map.Entry<String, Object> entry2 : unsetA.entrySet()) {
                if (unsetB.containsKey(entry2.getKey())) {
                    unset2.put(entry2.getKey(), entry2.getValue());
                }
            }
            service = new ConnectorReference(connectionManager, managedConnectionFactory);
            final Object eagerInit = unset2.remove("eagerInit");
            if (eagerInit != null && eagerInit instanceof String && "true".equalsIgnoreCase((String)eagerInit) && connectionManager instanceof AbstractConnectionManager) {
                try {
                    ((AbstractConnectionManager)connectionManager).doStart();
                    try {
                        final Object cf = managedConnectionFactory.createConnectionFactory(connectionManager);
                        if (cf instanceof ConnectionFactory) {
                            final Connection connection = ((ConnectionFactory)cf).getConnection();
                            connection.getMetaData();
                            connection.close();
                        }
                    }
                    catch (Exception ex2) {}
                }
                catch (Exception e4) {
                    this.logger.warning("Can't start connection manager", e4);
                }
            }
            logUnusedProperties(unset2, serviceInfo);
        }
        else if (service instanceof DataSource) {
            ClassLoader classLoader2 = loader;
            if (classLoader2 == null) {
                classLoader2 = this.getClass().getClassLoader();
            }
            final ImportSql importer = new ImportSql(classLoader2, serviceInfo.id, (DataSource)service);
            if (importer.hasSomethingToImport()) {
                importer.doImport();
            }
            final ObjectRecipe recipe = DataSourceFactory.forgetRecipe(service, serviceRecipe);
            if (recipe != serviceRecipe || !serviceInfo.properties.containsKey("XaDataSource")) {
                logUnusedProperties(recipe, serviceInfo);
            }
            final Properties prop = serviceInfo.properties;
            String url = prop.getProperty("JdbcUrl", prop.getProperty("url"));
            if (url == null) {
                url = prop.getProperty("jdbcUrl");
            }
            if (url == null) {
                this.logger.debug("Unable to find url for " + serviceInfo.id + " will not monitor it");
            }
            else {
                final String host = extractHost(url);
                if (host != null) {
                    this.remoteResourceMonitor.addHost(host);
                    this.remoteResourceMonitor.registerIfNot();
                }
            }
        }
        else if (!Properties.class.isInstance(service) && (serviceInfo.unsetProperties == null || isTemplatizedResource(serviceInfo))) {
            logUnusedProperties(serviceRecipe, serviceInfo);
        }
        final ResourceCreated event = new ResourceCreated(service, serviceInfo.id);
        SystemInstance.get().fireEvent((Object)event);
        return (event.getReplacement() == null) ? service : event.getReplacement();
    }
    
    private void bindResource(final String id, final Object service, final boolean canReplace) throws OpenEJBException {
        final String name = "openejb/Resource/" + id;
        final Context jndiContext = this.containerSystem.getJNDIContext();
        Object existing = null;
        try {
            ContextualJndiReference.followReference.set(false);
            existing = jndiContext.lookup(name);
        }
        catch (Exception ex) {}
        finally {
            ContextualJndiReference.followReference.remove();
        }
        boolean rebind = false;
        if (existing != null) {
            final boolean existingIsContextual = ContextualJndiReference.class.isInstance(existing);
            final boolean serviceIsExisting = ContextualJndiReference.class.isInstance(service);
            if (!existingIsContextual && serviceIsExisting) {
                ContextualJndiReference.class.cast(service).setDefaultValue(existing);
                rebind = true;
            }
            else if (existingIsContextual && !serviceIsExisting) {
                ContextualJndiReference.class.cast(existing).setDefaultValue(service);
            }
            else if (existingIsContextual) {
                final ContextualJndiReference contextual = ContextualJndiReference.class.cast(existing);
                if (canReplace && contextual.prefixesSize() == 1) {
                    contextual.removePrefix(contextual.lastPrefix());
                    contextual.setDefaultValue(service);
                }
                else {
                    contextual.addPrefix(ContextualJndiReference.class.cast(service).lastPrefix());
                }
                return;
            }
        }
        try {
            if (canReplace && existing != null) {
                jndiContext.unbind(name);
            }
            if (rebind) {
                jndiContext.rebind(name, service);
            }
            else {
                jndiContext.bind(name, service);
            }
        }
        catch (NameAlreadyBoundException nabe) {
            this.logger.warning("unbounding resource " + name + " can happen because of a redeployment or because of a duplicated id");
            try {
                jndiContext.unbind(name);
                jndiContext.bind(name, service);
            }
            catch (NamingException e) {
                throw new OpenEJBException("Cannot bind resource adapter with id " + id, e);
            }
        }
        catch (NamingException e2) {
            throw new OpenEJBException("Cannot bind resource adapter with id " + id, e2);
        }
    }
    
    private static String extractHost(final String url) {
        if (url == null || !url.contains("://")) {
            return null;
        }
        final int idx = url.indexOf("://");
        final String subUrl = url.substring(idx + 3);
        final int port = subUrl.indexOf(58);
        final int slash = subUrl.indexOf(47);
        int end = port;
        if (end < 0 || (slash > 0 && slash < end)) {
            end = slash;
        }
        if (end > 0) {
            return subUrl.substring(0, end);
        }
        return subUrl;
    }
    
    private int getIntProperty(final Properties properties, final String propertyName, final int defaultValue) {
        final String propertyValue = this.getStringProperty(properties, propertyName, Integer.toString(defaultValue));
        if (propertyValue == null) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(propertyValue);
        }
        catch (NumberFormatException e) {
            throw new IllegalArgumentException(propertyName + " is not an integer " + propertyValue, e);
        }
    }
    
    private String getStringProperty(final Properties properties, final String propertyName, final String defaultValue) {
        final String propertyValue = properties.getProperty(propertyName);
        if (propertyValue == null) {
            return defaultValue;
        }
        return propertyValue;
    }
    
    public void createConnectionManager(final ConnectionManagerInfo serviceInfo) throws OpenEJBException {
        final ObjectRecipe serviceRecipe = this.createRecipe((Collection<ServiceInfo>)Collections.emptyList(), serviceInfo);
        final Object object = this.props.get("TransactionManager");
        serviceRecipe.setProperty("transactionManager", object);
        final Object service = serviceRecipe.create();
        logUnusedProperties(serviceRecipe, serviceInfo);
        final Class interfce = Assembler.serviceInterfaces.get(serviceInfo.service);
        AssemblerTool.checkImplementation(interfce, service.getClass(), serviceInfo.service, serviceInfo.id);
        this.bindService(serviceInfo, service);
        this.setSystemInstanceComponent(interfce, service);
        getContext().put(interfce.getName(), service);
        this.props.put(interfce.getName(), service);
        this.props.put(serviceInfo.service, service);
        this.props.put(serviceInfo.id, service);
        this.config.facilities.connectionManagers.add(serviceInfo);
        this.logger.getChildLogger("service").debug("createService.success", serviceInfo.service, serviceInfo.id, serviceInfo.className);
    }
    
    public void createSecurityService(final SecurityServiceInfo serviceInfo) throws OpenEJBException {
        Object service = SystemInstance.get().getComponent((Class)SecurityService.class);
        if (service == null) {
            final ObjectRecipe serviceRecipe = this.createRecipe((Collection<ServiceInfo>)Collections.emptyList(), serviceInfo);
            service = serviceRecipe.create();
            logUnusedProperties(serviceRecipe, serviceInfo);
        }
        final Class interfce = Assembler.serviceInterfaces.get(serviceInfo.service);
        AssemblerTool.checkImplementation(interfce, service.getClass(), serviceInfo.service, serviceInfo.id);
        try {
            this.containerSystem.getJNDIContext().bind("openejb/" + serviceInfo.service, service);
        }
        catch (NamingException e) {
            throw new OpenEJBException("Cannot bind " + serviceInfo.service + " with id " + serviceInfo.id, e);
        }
        this.setSystemInstanceComponent(interfce, service);
        getContext().put(interfce.getName(), service);
        this.props.put(interfce.getName(), service);
        this.props.put(serviceInfo.service, service);
        this.props.put(serviceInfo.id, service);
        this.securityService = (SecurityService)service;
        this.config.facilities.securityService = serviceInfo;
        this.logger.getChildLogger("service").debug("createService.success", serviceInfo.service, serviceInfo.id, serviceInfo.className);
    }
    
    public void createTransactionManager(final TransactionServiceInfo serviceInfo) throws OpenEJBException {
        Object service = SystemInstance.get().getComponent((Class)TransactionManager.class);
        if (service == null) {
            final ObjectRecipe serviceRecipe = this.createRecipe((Collection<ServiceInfo>)Collections.emptyList(), serviceInfo);
            service = serviceRecipe.create();
            logUnusedProperties(serviceRecipe, serviceInfo);
        }
        else {
            this.logger.info("Reusing provided TransactionManager " + service);
        }
        final Class interfce = Assembler.serviceInterfaces.get(serviceInfo.service);
        AssemblerTool.checkImplementation(interfce, service.getClass(), serviceInfo.service, serviceInfo.id);
        try {
            this.containerSystem.getJNDIContext().bind("openejb/" + serviceInfo.service, service);
            this.containerSystem.getJNDIContext().bind("comp/UserTransaction", new CoreUserTransaction((TransactionManager)service));
            this.containerSystem.getJNDIContext().bind("comp/TransactionManager", service);
        }
        catch (NamingException e) {
            throw new OpenEJBException("Cannot bind " + serviceInfo.service + " with id " + serviceInfo.id, e);
        }
        this.setSystemInstanceComponent(interfce, service);
        getContext().put(interfce.getName(), service);
        this.props.put(interfce.getName(), service);
        this.props.put(serviceInfo.service, service);
        this.props.put(serviceInfo.id, service);
        this.transactionManager = (TransactionManager)service;
        this.config.facilities.transactionService = serviceInfo;
        TransactionSynchronizationRegistry synchronizationRegistry;
        if (this.transactionManager instanceof TransactionSynchronizationRegistry) {
            synchronizationRegistry = (TransactionSynchronizationRegistry)this.transactionManager;
        }
        else {
            synchronizationRegistry = (TransactionSynchronizationRegistry)new SimpleTransactionSynchronizationRegistry(this.transactionManager);
        }
        getContext().put(TransactionSynchronizationRegistry.class.getName(), synchronizationRegistry);
        SystemInstance.get().setComponent((Class)TransactionSynchronizationRegistry.class, (Object)synchronizationRegistry);
        try {
            this.containerSystem.getJNDIContext().bind("comp/TransactionSynchronizationRegistry", new TransactionSynchronizationRegistryWrapper());
        }
        catch (NamingException e2) {
            throw new OpenEJBException("Cannot bind java:comp/TransactionSynchronizationRegistry", e2);
        }
        final JtaEntityManagerRegistry jtaEntityManagerRegistry = new JtaEntityManagerRegistry(synchronizationRegistry);
        getContext().put(JtaEntityManagerRegistry.class.getName(), jtaEntityManagerRegistry);
        SystemInstance.get().setComponent((Class)JtaEntityManagerRegistry.class, (Object)jtaEntityManagerRegistry);
        this.logger.getChildLogger("service").debug("createService.success", serviceInfo.service, serviceInfo.id, serviceInfo.className);
    }
    
    public static void logUnusedProperties(final ObjectRecipe serviceRecipe, final ServiceInfo info) {
        final Map<String, Object> unsetProperties = (Map<String, Object>)serviceRecipe.getUnsetProperties();
        logUnusedProperties(unsetProperties, info);
    }
    
    private static void logUnusedProperties(final Map<String, ?> unsetProperties, final ServiceInfo info) {
        if (isPassthroughType(info)) {
            return;
        }
        final boolean ignoreJdbcDefault = "Annotation".equalsIgnoreCase(info.properties.getProperty("Origin"));
        Logger logger = null;
        for (final String property : unsetProperties.keySet()) {
            if (ignoreJdbcDefault) {
                if ("JdbcUrl".equals(property) || "UserName".equals(property) || "Password".equals(property)) {
                    continue;
                }
                if ("PasswordCipher".equals(property)) {
                    continue;
                }
            }
            if (property.equalsIgnoreCase("Definition")) {
                continue;
            }
            if (property.equalsIgnoreCase("SkipImplicitAttributes")) {
                continue;
            }
            if (property.equalsIgnoreCase("JndiName")) {
                continue;
            }
            if (property.equalsIgnoreCase("Origin")) {
                continue;
            }
            if (property.equalsIgnoreCase("DatabaseName")) {
                continue;
            }
            if (property.equalsIgnoreCase("connectionAttributes")) {
                return;
            }
            if (property.equalsIgnoreCase("properties")) {
                return;
            }
            if (property.equalsIgnoreCase("ApplicationWide")) {
                continue;
            }
            if (property.equalsIgnoreCase("OpenEJBResourceClasspath")) {
                continue;
            }
            if (isInternalProperty(property)) {
                continue;
            }
            if (info.types.isEmpty() && "class".equalsIgnoreCase(property)) {
                continue;
            }
            if ("destination".equalsIgnoreCase(property) && info.id.equals(unsetProperties.get("destination"))) {
                continue;
            }
            if (logger == null) {
                final Assembler assembler = (Assembler)SystemInstance.get().getComponent((Class)Assembler.class);
                if (assembler != null) {
                    logger = assembler.logger;
                }
                else {
                    System.err.println("Assembler has not been initialized");
                }
            }
            unusedProperty(info.id, logger, property);
        }
    }
    
    private static boolean isPassthroughType(final ServiceInfo info) {
        return info.types.contains("javax.mail.Session");
    }
    
    private static void unusedProperty(final String id, final Logger parentLogger, final String property) {
        if (isInternalProperty(property)) {
            return;
        }
        final String msg = "unused property '" + property + "' for resource '" + id + "'";
        if (null != parentLogger) {
            parentLogger.getChildLogger("service").warning(msg);
        }
        else {
            System.out.println(msg);
        }
    }
    
    private static boolean isInternalProperty(final String property) {
        return property.equalsIgnoreCase("ServiceId") || property.equalsIgnoreCase("transactionManager");
    }
    
    private static void unusedProperty(final String id, final String property) {
        final Assembler component = (Assembler)SystemInstance.get().getComponent((Class)Assembler.class);
        final Logger logger = (component != null) ? component.logger : null;
        unusedProperty(id, logger, property);
    }
    
    public static ObjectRecipe prepareRecipe(final ServiceInfo info) {
        final String[] constructorArgs = info.constructorArgs.toArray(new String[info.constructorArgs.size()]);
        final ObjectRecipe serviceRecipe = new ObjectRecipe(info.className, info.factoryMethod, constructorArgs, (Class[])null);
        serviceRecipe.allow(Option.CASE_INSENSITIVE_PROPERTIES);
        serviceRecipe.allow(Option.IGNORE_MISSING_PROPERTIES);
        serviceRecipe.allow(Option.PRIVATE_PROPERTIES);
        return serviceRecipe;
    }
    
    private ObjectRecipe createRecipe(final Collection<ServiceInfo> services, final ServiceInfo info) {
        final Logger serviceLogger = this.logger.getChildLogger("service");
        if (info instanceof ResourceInfo) {
            final List<String> aliasesList = ((ResourceInfo)info).aliases;
            if (!aliasesList.isEmpty()) {
                final String aliases = Join.join(", ", aliasesList);
                serviceLogger.info("createServiceWithAliases", info.service, info.id, aliases);
            }
            else {
                serviceLogger.info("createService", info.service, info.id);
            }
        }
        else {
            serviceLogger.info("createService", info.service, info.id);
        }
        final ObjectRecipe serviceRecipe = prepareRecipe(info);
        final Object value = info.properties.remove("SkipImplicitAttributes");
        final Properties allProperties = PropertyPlaceHolderHelper.simpleHolds(info.properties);
        allProperties.remove("SkipPropertiesFallback");
        if (services == null) {
            serviceRecipe.setAllProperties((Map)allProperties);
        }
        else {
            info.properties = allProperties;
            ServiceInfos.setProperties(services, info, serviceRecipe);
        }
        if (value != null) {
            info.properties.put("SkipImplicitAttributes", value);
        }
        if (serviceLogger.isDebugEnabled()) {
            for (final Map.Entry<String, Object> entry : serviceRecipe.getProperties().entrySet()) {
                serviceLogger.debug("createService.props", entry.getKey(), entry.getValue());
            }
        }
        return serviceRecipe;
    }
    
    private void setSystemInstanceComponent(final Class interfce, final Object service) {
        SystemInstance.get().setComponent(interfce, service);
    }
    
    private URL toUrl(final String jarPath) throws OpenEJBException {
        try {
            return new File(jarPath).toURI().toURL();
        }
        catch (MalformedURLException e) {
            throw new OpenEJBException(this.messages.format("cl0001", jarPath, e.getMessage()), e);
        }
    }
    
    static {
        JULLoggerFactory.class.getName();
        OPENEJB_URL_PKG_PREFIX = IvmContext.class.getPackage().getName();
        lock = new ReentrantLock(true);
        VALIDATOR_FACTORY_INTERFACES = new Class[] { ValidatorFactory.class, Serializable.class };
        VALIDATOR_INTERFACES = new Class[] { Validator.class };
        context = new ThreadLocal<Map<String, Object>>();
    }
    
    private static class PersistenceClassLoaderHandlerImpl implements PersistenceClassLoaderHandler
    {
        private static final AtomicBoolean logged;
        private final Map<String, List<ClassFileTransformer>> transformers;
        
        private PersistenceClassLoaderHandlerImpl() {
            this.transformers = new TreeMap<String, List<ClassFileTransformer>>();
        }
        
        @Override
        public void addTransformer(final String unitId, final ClassLoader classLoader, final ClassFileTransformer classFileTransformer) {
            final Instrumentation instrumentation = Agent.getInstrumentation();
            if (instrumentation != null) {
                instrumentation.addTransformer(classFileTransformer);
                if (unitId != null) {
                    List<ClassFileTransformer> transformers = this.transformers.get(unitId);
                    if (transformers == null) {
                        transformers = new ArrayList<ClassFileTransformer>(1);
                        this.transformers.put(unitId, transformers);
                    }
                    transformers.add(classFileTransformer);
                }
            }
            else if (!PersistenceClassLoaderHandlerImpl.logged.getAndSet(true)) {
                final Assembler assembler = (Assembler)SystemInstance.get().getComponent((Class)Assembler.class);
                if (assembler != null) {
                    assembler.logger.info("assembler.noAgent");
                }
                else {
                    System.err.println("addTransformer: Assembler not initialized: JAVA AGENT NOT INSTALLED");
                }
            }
        }
        
        @Override
        public void destroy(final String unitId) {
            final List<ClassFileTransformer> transformers = this.transformers.remove(unitId);
            if (transformers != null) {
                final Instrumentation instrumentation = Agent.getInstrumentation();
                if (instrumentation != null) {
                    for (final ClassFileTransformer transformer : transformers) {
                        instrumentation.removeTransformer(transformer);
                    }
                }
                else {
                    final Assembler assembler = (Assembler)SystemInstance.get().getComponent((Class)Assembler.class);
                    if (assembler != null) {
                        assembler.logger.info("assembler.noAgent");
                    }
                    else {
                        System.err.println("destroy: Assembler not initialized: JAVA AGENT NOT INSTALLED");
                    }
                }
            }
        }
        
        @Override
        public ClassLoader getNewTempClassLoader(final ClassLoader classLoader) {
            return ClassLoaderUtil.createTempClassLoader(classLoader);
        }
        
        static {
            logged = new AtomicBoolean(false);
        }
    }
    
    public static class DeploymentListenerObserver
    {
        private final DeploymentListener delegate;
        
        public DeploymentListenerObserver(final DeploymentListener deploymentListener) {
            this.delegate = deploymentListener;
        }
        
        public void afterApplicationCreated(@Observes final AssemblerAfterApplicationCreated event) {
            this.delegate.afterApplicationCreated(event.getApp());
        }
        
        public void beforeApplicationDestroyed(@Observes final AssemblerBeforeApplicationDestroyed event) {
            this.delegate.beforeApplicationDestroyed(event.getApp());
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof DeploymentListenerObserver)) {
                return false;
            }
            final DeploymentListenerObserver that = (DeploymentListenerObserver)o;
            if (this.delegate != null) {
                if (!this.delegate.equals(that.delegate)) {
                    return false;
                }
            }
            else if (that.delegate != null) {
                return false;
            }
            return true;
            b = false;
            return b;
        }
        
        @Override
        public int hashCode() {
            return (this.delegate != null) ? this.delegate.hashCode() : 0;
        }
    }
    
    private static final class DestroyingResource
    {
        private final String name;
        private final String clazz;
        private final Object instance;
        
        private DestroyingResource(final String name, final String clazz, final Object instance) {
            this.name = name;
            this.clazz = clazz;
            this.instance = instance;
        }
    }
    
    public static final class ResourceAdapterReference extends Reference
    {
        private final transient ResourceAdapter ra;
        private final transient Executor pool;
        private final String jndi;
        
        public ResourceAdapterReference(final ResourceAdapter ra, final Executor pool, final String jndi) {
            this.ra = ra;
            this.pool = pool;
            this.jndi = jndi;
        }
        
        public Executor getPool() {
            return this.pool;
        }
        
        public ResourceAdapter getRa() {
            return this.ra;
        }
        
        public String getJndi() {
            return this.jndi;
        }
        
        @Override
        public Object getObject() throws NamingException {
            return this.ra;
        }
        
        protected Object readResolve() throws ObjectStreamException {
            try {
                final ContainerSystem component = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
                if (component != null) {
                    return component.getJNDIContext().lookup(this.jndi);
                }
                throw new NamingException("ContainerSystem has not been initialized");
            }
            catch (NamingException e) {
                final InvalidObjectException objectException = new InvalidObjectException("name not found: " + this.jndi);
                objectException.initCause(e);
                throw objectException;
            }
        }
    }
    
    public static class LazyResource extends LazyObjectReference<Object>
    {
        public LazyResource(final Callable<Object> creator) {
            super(creator);
        }
        
        Object writeReplace() throws ObjectStreamException {
            try {
                return this.getObject();
            }
            catch (NamingException e) {
                return null;
            }
        }
    }
    
    public static class ResourceInstance extends Reference implements Serializable, DestroyableResource
    {
        private final String name;
        private final Object delegate;
        private final transient Collection<Method> preDestroys;
        private final transient CreationalContext<?> context;
        private volatile boolean destroyed;
        
        public ResourceInstance(final String name, final Object delegate, final Collection<Method> preDestroys, final CreationalContext<?> context) {
            this.destroyed = false;
            this.name = name;
            this.delegate = delegate;
            this.preDestroys = preDestroys;
            this.context = context;
        }
        
        @Override
        public Object getObject() throws NamingException {
            return this.delegate;
        }
        
        public synchronized void destroyResource() {
            if (this.destroyed) {
                return;
            }
            final Object o = unwrapReference(this.delegate);
            for (final Method m : this.preDestroys) {
                try {
                    if (!m.isAccessible()) {
                        SetAccessible.on(m);
                    }
                    m.invoke(o, new Object[0]);
                }
                catch (Exception e) {
                    final Assembler component = (Assembler)SystemInstance.get().getComponent((Class)Assembler.class);
                    if (component != null) {
                        component.logger.error(e.getMessage(), e);
                    }
                    else {
                        System.err.println("" + e.getMessage());
                    }
                }
            }
            try {
                if (this.context != null) {
                    this.context.release();
                }
            }
            catch (Exception ex) {}
            this.destroyed = true;
        }
        
        Object readResolve() throws ObjectStreamException {
            try {
                final ContainerSystem component = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
                if (component != null) {
                    return component.getJNDIContext().lookup(this.name);
                }
                throw new Exception("ContainerSystem is not initialized");
            }
            catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }
    }
}
