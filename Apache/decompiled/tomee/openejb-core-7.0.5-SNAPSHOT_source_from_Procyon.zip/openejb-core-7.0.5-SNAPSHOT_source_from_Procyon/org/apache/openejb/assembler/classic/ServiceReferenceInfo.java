// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;

public class ServiceReferenceInfo extends InjectableInfo
{
    public String id;
    public QName serviceQName;
    public String serviceType;
    public QName portQName;
    public String referenceType;
    public String wsdlFile;
    public String jaxrpcMappingFile;
    public final List<HandlerChainInfo> handlerChains;
    public final List<PortRefInfo> portRefs;
    
    public ServiceReferenceInfo() {
        this.handlerChains = new ArrayList<HandlerChainInfo>();
        this.portRefs = new ArrayList<PortRefInfo>();
    }
}
