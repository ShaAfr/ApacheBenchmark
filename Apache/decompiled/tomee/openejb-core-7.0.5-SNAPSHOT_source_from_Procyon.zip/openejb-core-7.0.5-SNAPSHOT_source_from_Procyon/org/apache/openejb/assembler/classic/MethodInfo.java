// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.List;

public class MethodInfo extends InfoObject
{
    public String description;
    public String ejbDeploymentId;
    public String ejbName;
    public String methodIntf;
    public String methodName;
    public List<String> methodParams;
    public String className;
}
