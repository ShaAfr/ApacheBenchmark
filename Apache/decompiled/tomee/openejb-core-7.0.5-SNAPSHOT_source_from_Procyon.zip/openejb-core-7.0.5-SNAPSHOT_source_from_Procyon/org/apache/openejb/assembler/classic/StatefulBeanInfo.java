// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class StatefulBeanInfo extends EnterpriseBeanInfo
{
    public final List<CallbackInfo> postActivate;
    public final List<CallbackInfo> prePassivate;
    public final List<InitMethodInfo> initMethods;
    public final List<RemoveMethodInfo> removeMethods;
    public final List<CallbackInfo> afterBegin;
    public final List<CallbackInfo> beforeCompletion;
    public final List<CallbackInfo> afterCompletion;
    
    public StatefulBeanInfo() {
        this.postActivate = new ArrayList<CallbackInfo>();
        this.prePassivate = new ArrayList<CallbackInfo>();
        this.initMethods = new ArrayList<InitMethodInfo>();
        this.removeMethods = new ArrayList<RemoveMethodInfo>();
        this.afterBegin = new ArrayList<CallbackInfo>();
        this.beforeCompletion = new ArrayList<CallbackInfo>();
        this.afterCompletion = new ArrayList<CallbackInfo>();
        this.type = 1;
    }
}
