// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.InitialContext;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.naming.NamingException;
import java.util.Hashtable;
import javax.naming.Context;

public class JndiReference extends Reference
{
    private Context context;
    private Hashtable envProperties;
    private final String jndiName;
    private String contextJndiName;
    
    public JndiReference(final Context linkedContext, final String jndiName) {
        this.context = linkedContext;
        this.jndiName = jndiName;
    }
    
    public JndiReference(final String contextJndiName, final String jndiName) {
        this.contextJndiName = contextJndiName;
        this.jndiName = jndiName;
    }
    
    public JndiReference(final Hashtable envProperties, final String jndiName) {
        if (envProperties == null || envProperties.size() == 0) {
            this.envProperties = null;
        }
        else {
            this.envProperties = envProperties;
        }
        this.jndiName = jndiName;
    }
    
    @Override
    public Object getObject() throws NamingException {
        final Context externalContext = this.getContext();
        synchronized (externalContext) {
            return externalContext.lookup(this.jndiName);
        }
    }
    
    protected Context getContext() throws NamingException {
        if (this.context == null) {
            if (this.contextJndiName != null) {
                final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
                this.context = (Context)containerSystem.getJNDIContext().lookup(this.contextJndiName);
            }
            else {
                this.context = new InitialContext(this.envProperties);
            }
        }
        return this.context;
    }
}
