// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateless;

import javax.xml.ws.EndpointReference;
import org.w3c.dom.Element;
import org.apache.openejb.core.webservices.AddressingSupport;
import java.security.Principal;
import org.apache.openejb.core.ThreadContext;
import javax.xml.ws.handler.MessageContext;
import javax.ejb.SessionContext;
import javax.xml.ws.WebServiceContext;

public class EjbWsContext implements WebServiceContext
{
    private final SessionContext context;
    
    public EjbWsContext(final SessionContext context) {
        this.context = context;
    }
    
    public MessageContext getMessageContext() {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final MessageContext messageContext = threadContext.get(MessageContext.class);
        if (messageContext == null) {
            throw new IllegalStateException("Only calls on the service-endpoint have a MessageContext.");
        }
        return messageContext;
    }
    
    public Principal getUserPrincipal() {
        return this.context.getCallerPrincipal();
    }
    
    public boolean isUserInRole(final String roleName) {
        return this.context.isCallerInRole(roleName);
    }
    
    private AddressingSupport getAddressingSupport() {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final AddressingSupport wsaSupport = threadContext.get(AddressingSupport.class);
        if (wsaSupport == null) {
            throw new IllegalStateException("Only calls on the service-endpoint can get the EndpointReference.");
        }
        return wsaSupport;
    }
    
    public EndpointReference getEndpointReference(final Element... referenceParameters) {
        return this.getAddressingSupport().getEndpointReference(referenceParameters);
    }
    
    public <T extends EndpointReference> T getEndpointReference(final Class<T> clazz, final Element... referenceParameters) {
        return this.getAddressingSupport().getEndpointReference(clazz, referenceParameters);
    }
}
