// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.core.timer.ScheduleData;
import java.io.Serializable;
import javax.ejb.TimerConfig;
import javax.ejb.ScheduleExpression;
import org.apache.openejb.MethodContext;
import java.lang.reflect.Method;
import java.util.Iterator;
import org.apache.openejb.BeanContext;
import org.apache.openejb.util.Logger;

public class MethodScheduleBuilder
{
    public static final Logger logger;
    
    public void build(final BeanContext beanContext, final EnterpriseBeanInfo beanInfo) {
        final Class<?> clazz = (Class<?>)beanContext.getBeanClass();
        for (final MethodScheduleInfo info : beanInfo.methodScheduleInfos) {
            Method timeoutMethodOfSchedule = null;
            if (info.method.methodParams == null) {
                MethodScheduleBuilder.logger.info("Schedule timeout method with 'null' method parameters is invalid: " + info.method.methodName);
            }
            else {
                try {
                    timeoutMethodOfSchedule = MethodInfoUtil.toMethod(clazz, info.method);
                }
                catch (IllegalStateException e) {
                    MethodScheduleBuilder.logger.warning("Schedule method does not exist: " + info.method.methodName, e);
                    continue;
                }
            }
            MethodContext methodContext = null;
            if (timeoutMethodOfSchedule == null && beanContext.getEjbTimeout() != null) {
                methodContext = beanContext.getMethodContext(beanContext.getEjbTimeout());
            }
            else if (info.method.className == null || timeoutMethodOfSchedule.getDeclaringClass().getName().equals(info.method.className)) {
                methodContext = beanContext.getMethodContext(timeoutMethodOfSchedule);
            }
            this.addSchedulesToMethod(methodContext, info);
        }
    }
    
    private void addSchedulesToMethod(final MethodContext methodContext, final MethodScheduleInfo info) {
        if (methodContext == null) {
            return;
        }
        for (final ScheduleInfo scheduleInfo : info.schedules) {
            final ScheduleExpression expr = new ScheduleExpression();
            expr.second((scheduleInfo.second == null) ? "0" : scheduleInfo.second);
            expr.minute((scheduleInfo.minute == null) ? "0" : scheduleInfo.minute);
            expr.hour((scheduleInfo.hour == null) ? "0" : scheduleInfo.hour);
            expr.dayOfWeek((scheduleInfo.dayOfWeek == null) ? "*" : scheduleInfo.dayOfWeek);
            expr.dayOfMonth((scheduleInfo.dayOfMonth == null) ? "*" : scheduleInfo.dayOfMonth);
            expr.month((scheduleInfo.month == null) ? "*" : scheduleInfo.month);
            expr.year((scheduleInfo.year == null) ? "*" : scheduleInfo.year);
            expr.timezone(scheduleInfo.timezone);
            expr.start(scheduleInfo.start);
            expr.end(scheduleInfo.end);
            final TimerConfig config = new TimerConfig();
            config.setInfo((Serializable)scheduleInfo.info);
            config.setPersistent(scheduleInfo.persistent);
            methodContext.getSchedules().add(new ScheduleData(config, expr));
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, MethodScheduleBuilder.class.getPackage().getName());
    }
}
