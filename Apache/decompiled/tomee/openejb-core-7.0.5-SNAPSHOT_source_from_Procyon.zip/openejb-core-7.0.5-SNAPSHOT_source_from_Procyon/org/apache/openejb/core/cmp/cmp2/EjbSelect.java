// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.Container;
import javax.ejb.FinderException;
import org.apache.openejb.core.cmp.CmpContainer;
import org.apache.openejb.BeanContext;
import java.lang.reflect.Method;
import java.util.HashMap;

public class EjbSelect
{
    private static final HashMap<Class<?>, Method> selectMethods;
    
    public static Method getSelectMethod(final Class<?> returnType) {
        final Method method = EjbSelect.selectMethods.get(returnType);
        if (method == null) {
            return EjbSelect.selectMethods.get(Object.class);
        }
        return method;
    }
    
    public static void execute_void(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        cmpContainer.update(beanContext, methodSignature, args);
    }
    
    public static Object execute_Object(final Object obj, final String methodSignature, final String returnType, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        return cmpContainer.select(beanContext, methodSignature, returnType, args);
    }
    
    public static char execute_char(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Character result = (Character)cmpContainer.select(beanContext, methodSignature, "char", args);
        return result;
    }
    
    public static byte execute_byte(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Number result = (Number)cmpContainer.select(beanContext, methodSignature, "byte", args);
        return result.byteValue();
    }
    
    public static boolean execute_boolean(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Boolean result = (Boolean)cmpContainer.select(beanContext, methodSignature, "byte", args);
        return result;
    }
    
    public static short execute_short(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Number result = (Number)cmpContainer.select(beanContext, methodSignature, "short", args);
        return result.shortValue();
    }
    
    public static int execute_int(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Number result = (Number)cmpContainer.select(beanContext, methodSignature, "int", args);
        return result.intValue();
    }
    
    public static long execute_long(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Number result = (Number)cmpContainer.select(beanContext, methodSignature, "long", args);
        return result.longValue();
    }
    
    public static float execute_float(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Number result = (Number)cmpContainer.select(beanContext, methodSignature, "float", args);
        return result.floatValue();
    }
    
    public static double execute_double(final Object obj, final String methodSignature, final Object... args) throws FinderException {
        final BeanContext beanContext = (BeanContext)obj;
        final Container container = beanContext.getContainer();
        if (!(container instanceof CmpContainer)) {
            throw new FinderException("Deployment is not connected to a CmpContainer " + beanContext.getDeploymentID());
        }
        final CmpContainer cmpContainer = (CmpContainer)container;
        final Number result = (Number)cmpContainer.select(beanContext, methodSignature, "double", args);
        return result.doubleValue();
    }
    
    static {
        selectMethods = new HashMap<Class<?>, Method>();
        try {
            EjbSelect.selectMethods.put(Object.class, EjbSelect.class.getMethod("execute_Object", Object.class, String.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Void.TYPE, EjbSelect.class.getMethod("execute_void", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Boolean.TYPE, EjbSelect.class.getMethod("execute_boolean", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Byte.TYPE, EjbSelect.class.getMethod("execute_byte", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Character.TYPE, EjbSelect.class.getMethod("execute_char", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Short.TYPE, EjbSelect.class.getMethod("execute_short", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Integer.TYPE, EjbSelect.class.getMethod("execute_int", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Long.TYPE, EjbSelect.class.getMethod("execute_long", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Float.TYPE, EjbSelect.class.getMethod("execute_float", Object.class, String.class, Object[].class));
            EjbSelect.selectMethods.put(Double.TYPE, EjbSelect.class.getMethod("execute_double", Object.class, String.class, Object[].class));
        }
        catch (NoSuchMethodException e) {
            throw new OpenEJBRuntimeException(e);
        }
    }
}
