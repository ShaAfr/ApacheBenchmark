// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math;

import org.apache.openejb.OpenEJBRuntimeException;
import java.text.ParseException;
import java.util.NoSuchElementException;
import java.util.ConcurrentModificationException;
import java.io.IOException;
import java.io.EOFException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.PrintStream;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Locale;

public class MathRuntimeException extends RuntimeException
{
    private static final long serialVersionUID = -1238983364075381060L;
    private final String pattern;
    private final Object[] arguments;
    
    public MathRuntimeException(final String pattern, final Object... arguments) {
        this.pattern = pattern;
        this.arguments = ((arguments == null) ? new Object[0] : arguments.clone());
    }
    
    public MathRuntimeException(final Throwable rootCause) {
        super(rootCause);
        this.pattern = this.getMessage();
        this.arguments = new Object[0];
    }
    
    public MathRuntimeException(final Throwable rootCause, final String pattern, final Object... arguments) {
        super(rootCause);
        this.pattern = pattern;
        this.arguments = ((arguments == null) ? new Object[0] : arguments.clone());
    }
    
    private static String translate(final String s, final Locale locale) {
        try {
            final ResourceBundle bundle = ResourceBundle.getBundle("org.apache.commons.math.MessagesResources", locale);
            if (bundle.getLocale().getLanguage().equals(locale.getLanguage())) {
                return bundle.getString(s);
            }
        }
        catch (MissingResourceException ex) {}
        return s;
    }
    
    private static String buildMessage(final Locale locale, final String pattern, final Object... arguments) {
        return (pattern == null) ? "" : new MessageFormat(translate(pattern, locale), locale).format(arguments);
    }
    
    public String getPattern() {
        return this.pattern;
    }
    
    public Object[] getArguments() {
        return this.arguments.clone();
    }
    
    public String getMessage(final Locale locale) {
        return buildMessage(locale, this.pattern, this.arguments);
    }
    
    @Override
    public String getMessage() {
        return this.getMessage(Locale.US);
    }
    
    @Override
    public String getLocalizedMessage() {
        return this.getMessage(Locale.getDefault());
    }
    
    @Override
    public void printStackTrace() {
        this.printStackTrace(System.err);
    }
    
    @Override
    public void printStackTrace(final PrintStream out) {
        synchronized (out) {
            final PrintWriter pw = new PrintWriter(out, false);
            this.printStackTrace(pw);
            pw.flush();
        }
    }
    
    public static ArithmeticException createArithmeticException(final String pattern, final Object... arguments) {
        return new ArithmeticException() {
            private static final long serialVersionUID = 7705628723242533939L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static ArrayIndexOutOfBoundsException createArrayIndexOutOfBoundsException(final String pattern, final Object... arguments) {
        return new ArrayIndexOutOfBoundsException() {
            private static final long serialVersionUID = -3394748305449283486L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static EOFException createEOFException(final String pattern, final Object... arguments) {
        return new EOFException() {
            private static final long serialVersionUID = 279461544586092584L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static IOException createIOException(final Throwable rootCause) {
        final IOException ioe = new IOException(rootCause.getLocalizedMessage());
        ioe.initCause(rootCause);
        return ioe;
    }
    
    public static IllegalArgumentException createIllegalArgumentException(final String pattern, final Object... arguments) {
        return new IllegalArgumentException() {
            private static final long serialVersionUID = -6555453980658317913L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static IllegalArgumentException createIllegalArgumentException(final Throwable rootCause) {
        final IllegalArgumentException iae = new IllegalArgumentException(rootCause.getLocalizedMessage());
        iae.initCause(rootCause);
        return iae;
    }
    
    public static IllegalStateException createIllegalStateException(final String pattern, final Object... arguments) {
        return new IllegalStateException() {
            private static final long serialVersionUID = -95247648156277208L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static ConcurrentModificationException createConcurrentModificationException(final String pattern, final Object... arguments) {
        return new ConcurrentModificationException() {
            private static final long serialVersionUID = 6134247282754009421L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static NoSuchElementException createNoSuchElementException(final String pattern, final Object... arguments) {
        return new NoSuchElementException() {
            private static final long serialVersionUID = 7304273322489425799L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static NullPointerException createNullPointerException(final String pattern, final Object... arguments) {
        return new NullPointerException() {
            private static final long serialVersionUID = -3075660477939965216L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static ParseException createParseException(final int offset, final String pattern, final Object... arguments) {
        return new ParseException(null, offset) {
            private static final long serialVersionUID = -1103502177342465975L;
            
            @Override
            public String getMessage() {
                return buildMessage(Locale.US, pattern, arguments);
            }
            
            @Override
            public String getLocalizedMessage() {
                return buildMessage(Locale.getDefault(), pattern, arguments);
            }
        };
    }
    
    public static RuntimeException createInternalError(final Throwable cause) {
        return new OpenEJBRuntimeException("internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", cause);
    }
}
