// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.MethodContext;
import java.lang.reflect.Method;
import java.util.Map;
import javax.ejb.TimerService;
import java.util.Iterator;
import org.apache.openejb.ModuleContext;
import org.apache.openejb.BeanType;
import org.apache.openejb.BeanContext;
import java.util.HashSet;
import org.apache.openejb.core.ThreadContext;
import javax.ejb.Timer;
import java.util.Collection;
import org.apache.openejb.util.Logger;

public final class Timers
{
    private static final Logger LOGGER;
    
    private Timers() {
    }
    
    public static Collection<Timer> all() {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext beanContext = threadContext.getBeanContext();
        final ModuleContext module = beanContext.getModuleContext();
        final Collection<Timer> timers = new HashSet<Timer>();
        for (final BeanContext c : module.getAppContext().getBeanContexts()) {
            if (c.getModuleContext() == module) {
                if (c.getComponentType() != BeanType.STATEFUL) {
                    final TimerService timerService = getTimerService(null, c, true);
                    if (timerService == null) {
                        continue;
                    }
                    final Collection<Timer> beanTimers = (Collection<Timer>)timerService.getTimers();
                    timers.addAll(beanTimers);
                }
                else {
                    final TimerService timerService = getTimerService(null, c, true);
                    if (timerService == null) {
                        continue;
                    }
                    final Collection<Timer> beanTimers = (Collection<Timer>)timerService.getTimers();
                    timers.addAll(beanTimers);
                }
            }
        }
        return timers;
    }
    
    public static TimerService getTimerService(final Object pk, final BeanContext beanContext, final boolean nullIfNotRelevant) throws IllegalStateException {
        final EjbTimerService timerService = beanContext.getEjbTimerService();
        if (timerService != null) {
            if (beanContext.getEjbTimeout() == null) {
                final HasSchedule hasSchedule = beanContext.get(HasSchedule.class);
                boolean hasSchedules = false;
                if (hasSchedule != null) {
                    hasSchedules = hasSchedule.value;
                }
                else {
                    final Iterator<Map.Entry<Method, MethodContext>> it = beanContext.iteratorMethodContext();
                    while (it.hasNext()) {
                        final Map.Entry<Method, MethodContext> entry = it.next();
                        final MethodContext methodContext = entry.getValue();
                        if (methodContext.getSchedules().size() > 0) {
                            hasSchedules = true;
                        }
                    }
                    synchronized (beanContext) {
                        if (beanContext.get(HasSchedule.class) == null) {
                            beanContext.set(HasSchedule.class, new HasSchedule(hasSchedules));
                        }
                    }
                }
                if (!hasSchedules) {
                    if (nullIfNotRelevant) {
                        return null;
                    }
                    Timers.LOGGER.error("This ejb does not support timers " + beanContext.getDeploymentID() + " due to no timeout method nor schedules in methodContext is configured");
                }
            }
            return (TimerService)new TimerServiceImpl(timerService, pk, beanContext.getEjbTimeout());
        }
        if (nullIfNotRelevant) {
            return null;
        }
        throw new IllegalStateException("This ejb does not support timers " + beanContext.getDeploymentID());
    }
    
    static {
        LOGGER = Logger.getInstance(LogCategory.TIMER, TimerServiceWrapper.class);
    }
    
    private static final class HasSchedule
    {
        private final boolean value;
        
        private HasSchedule(final boolean value) {
            this.value = value;
        }
    }
}
