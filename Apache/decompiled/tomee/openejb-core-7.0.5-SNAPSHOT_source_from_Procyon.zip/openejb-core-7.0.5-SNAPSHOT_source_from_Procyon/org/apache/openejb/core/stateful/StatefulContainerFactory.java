// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.util.Iterator;
import org.apache.xbean.recipe.Option;
import org.apache.xbean.recipe.ObjectRecipe;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.openejb.util.SuperProperties;
import org.apache.openejb.util.Duration;
import java.util.Properties;
import org.apache.openejb.spi.SecurityService;

public class StatefulContainerFactory
{
    private Object id;
    private SecurityService securityService;
    private Cache<Object, Instance> cache;
    private final Properties properties;
    private Duration accessTimeout;
    
    public StatefulContainerFactory() {
        this.properties = new SuperProperties().caseInsensitive(false);
        this.accessTimeout = new Duration(0L, TimeUnit.MILLISECONDS);
    }
    
    public Object getId() {
        return this.id;
    }
    
    public void setId(final Object id) {
        this.id = id;
    }
    
    public SecurityService getSecurityService() {
        return this.securityService;
    }
    
    public void setSecurityService(final SecurityService securityService) {
        this.securityService = securityService;
    }
    
    public Duration getAccessTimeout() {
        return this.accessTimeout;
    }
    
    public void setAccessTimeout(final Duration accessTimeout) {
        this.accessTimeout = accessTimeout;
    }
    
    public Cache<Object, Instance> getCache() {
        return this.cache;
    }
    
    public void setCache(final Cache<Object, Instance> cache) {
        this.cache = cache;
    }
    
    public void setCache(final String s) {
        this.properties.put("Cache", s);
    }
    
    public void setPassivator(final String s) {
        this.properties.put("Passivator", s);
    }
    
    public void setTimeOut(final String s) {
        this.properties.put("TimeOut", s);
    }
    
    public void setCapacity(final String s) {
        this.properties.put("Capacity", s);
    }
    
    public void setBulkPassivate(final String s) {
        this.properties.put("BulkPassivate", s);
    }
    
    public void setFrequency(final String s) {
        this.properties.put("Frequency", s);
    }
    
    public void setPreventExtendedEntityManagerSerialization(final boolean preventExtendedEntityManagerSerialization) {
        this.properties.put("PreventExtendedEntityManagerSerialization", Boolean.toString(preventExtendedEntityManagerSerialization));
    }
    
    public Properties getProperties() {
        return this.properties;
    }
    
    public void setProperties(final Properties properties) {
        this.properties.putAll(properties);
    }
    
    public StatefulContainer create() throws Exception {
        if (this.cache == null) {
            this.buildCache();
        }
        this.cache.init();
        return new StatefulContainer(this.id, this.securityService, this.cache, this.accessTimeout, "true".equalsIgnoreCase(this.properties.getProperty("PreventExtendedEntityManagerSerialization", "false").trim()), this.createLockFactory());
    }
    
    private LockFactory createLockFactory() {
        final Object lockFactory = this.properties.remove("LockFactory");
        if (lockFactory != null) {
            try {
                return LockFactory.class.cast(StatefulContainerFactory.class.getClassLoader().loadClass(lockFactory.toString().trim()).newInstance());
            }
            catch (Exception e) {
                throw new IllegalArgumentException(e);
            }
        }
        return new DefaultLockFactory();
    }
    
    private void buildCache() throws Exception {
        if (this.properties == null) {
            throw new IllegalArgumentException("No cache defined for StatefulContainer " + this.id);
        }
        Object cache = this.getProperty("Cache");
        if (cache == null) {
            throw new IllegalArgumentException("No cache defined for StatefulContainer " + this.id);
        }
        if (cache instanceof Cache) {
            this.cache = (Cache<Object, Instance>)cache;
            return;
        }
        final ObjectRecipe serviceRecipe = new ObjectRecipe((String)cache);
        serviceRecipe.allow(Option.CASE_INSENSITIVE_PROPERTIES);
        serviceRecipe.allow(Option.IGNORE_MISSING_PROPERTIES);
        serviceRecipe.allow(Option.NAMED_PARAMETERS);
        serviceRecipe.setAllProperties((Map)this.properties);
        ClassLoader classLoader = StatefulContainerFactory.class.getClassLoader();
        if (!((String)cache).startsWith("org.apache.tomee")) {
            classLoader = Thread.currentThread().getContextClassLoader();
        }
        cache = serviceRecipe.create(classLoader);
        this.cache = (Cache<Object, Instance>)cache;
    }
    
    private Object getProperty(final String name) {
        for (final Map.Entry<Object, Object> entry : this.properties.entrySet()) {
            final Object key = entry.getKey();
            if (key instanceof String && name.equalsIgnoreCase((String)key)) {
                return entry.getValue();
            }
        }
        return null;
    }
    
    public void setLockFactory(final String lockFactory) {
        this.properties.setProperty("LockFactory", lockFactory);
    }
}
