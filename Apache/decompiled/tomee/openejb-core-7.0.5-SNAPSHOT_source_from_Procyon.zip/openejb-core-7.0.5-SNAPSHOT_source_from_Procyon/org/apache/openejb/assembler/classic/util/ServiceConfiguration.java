// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.util;

import org.apache.openejb.assembler.classic.ServiceInfo;
import java.util.Collection;
import java.util.Properties;

public class ServiceConfiguration
{
    private final Properties properties;
    private final Collection<ServiceInfo> availableServices;
    
    public ServiceConfiguration(final Properties properties, final Collection<ServiceInfo> availableServices) {
        if (properties == null) {
            this.properties = new Properties();
        }
        else {
            this.properties = properties;
        }
        this.availableServices = availableServices;
    }
    
    public Properties getProperties() {
        return this.properties;
    }
    
    public Collection<ServiceInfo> getAvailableServices() {
        return this.availableServices;
    }
}
