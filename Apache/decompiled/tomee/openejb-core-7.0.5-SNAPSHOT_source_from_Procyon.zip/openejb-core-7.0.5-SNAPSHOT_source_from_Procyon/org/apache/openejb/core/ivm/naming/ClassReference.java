// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;

public class ClassReference extends Reference
{
    private final String className;
    
    public ClassReference(final String className) {
        this.className = className;
    }
    
    @Override
    public Object getObject() throws NamingException {
        final ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        try {
            return classLoader.loadClass(this.className);
        }
        catch (ClassNotFoundException e) {
            throw new NamingException("Erorr loading class: " + this.className);
        }
    }
}
