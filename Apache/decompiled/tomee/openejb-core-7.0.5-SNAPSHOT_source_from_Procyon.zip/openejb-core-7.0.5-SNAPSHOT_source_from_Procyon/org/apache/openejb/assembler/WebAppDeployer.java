// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler;

import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.assembler.classic.AppInfo;
import java.io.File;

public interface WebAppDeployer
{
    AppInfo deploy(final String p0, final String p1, final File p2);
    
    void reload(final String p0);
    
    public static final class Helper
    {
        private Helper() {
        }
        
        public static boolean isWebApp(final File file) {
            return (file.getName().endsWith(".war") || new File(file, "WEB-INF").exists()) && SystemInstance.get().getComponent((Class)WebAppDeployer.class) != null;
        }
    }
}
