// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb;

import org.apache.openejb.async.AsynchronousPool;
import javax.enterprise.inject.spi.BeanManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import org.apache.openejb.core.WebContext;
import java.util.List;
import java.util.Map;
import java.util.Collection;
import org.apache.webbeans.config.WebBeansContext;
import javax.naming.Context;
import org.apache.openejb.loader.SystemInstance;

public class AppContext extends DeploymentContext
{
    private final long startTime;
    private final SystemInstance systemInstance;
    private final ClassLoader classLoader;
    private final Context globalJndiContext;
    private final Context appJndiContext;
    private final boolean standaloneModule;
    private boolean cdiEnabled;
    private WebBeansContext webBeansContext;
    private final Collection<Injection> injections;
    private final Map<String, Object> bindings;
    private final List<BeanContext> beanContexts;
    private final List<WebContext> webContexts;
    
    public AppContext(final String id, final SystemInstance systemInstance, final ClassLoader classLoader, final Context globalJndiContext, final Context appJndiContext, final boolean standaloneModule) {
        super(id, systemInstance.getOptions());
        this.startTime = System.currentTimeMillis();
        this.injections = new HashSet<Injection>();
        this.bindings = new HashMap<String, Object>();
        this.beanContexts = new ArrayList<BeanContext>();
        this.webContexts = new ArrayList<WebContext>();
        this.classLoader = classLoader;
        this.systemInstance = systemInstance;
        this.globalJndiContext = globalJndiContext;
        this.appJndiContext = appJndiContext;
        this.standaloneModule = standaloneModule;
    }
    
    public Collection<Injection> getInjections() {
        return this.injections;
    }
    
    public Map<String, Object> getBindings() {
        return this.bindings;
    }
    
    public BeanManager getBeanManager() {
        if (this.webBeansContext == null) {
            return null;
        }
        return (BeanManager)this.webBeansContext.getBeanManagerImpl();
    }
    
    public WebBeansContext getWebBeansContext() {
        return this.webBeansContext;
    }
    
    public void setWebBeansContext(final WebBeansContext webBeansContext) {
        this.webBeansContext = webBeansContext;
    }
    
    public List<WebContext> getWebContexts() {
        return this.webContexts;
    }
    
    public boolean isCdiEnabled() {
        return this.cdiEnabled;
    }
    
    public void setCdiEnabled(final boolean cdiEnabled) {
        this.cdiEnabled = cdiEnabled;
    }
    
    @Override
    public String getId() {
        return super.getId();
    }
    
    public ClassLoader getClassLoader() {
        return this.classLoader;
    }
    
    @Deprecated
    public List<BeanContext> getDeployments() {
        return this.getBeanContexts();
    }
    
    public List<BeanContext> getBeanContexts() {
        return this.beanContexts;
    }
    
    public SystemInstance getSystemInstance() {
        return this.systemInstance;
    }
    
    public Context getAppJndiContext() {
        return this.appJndiContext;
    }
    
    public Context getGlobalJndiContext() {
        return this.globalJndiContext;
    }
    
    public boolean isStandaloneModule() {
        return this.standaloneModule;
    }
    
    public AsynchronousPool getAsynchronousPool() {
        return this.get(AsynchronousPool.class);
    }
    
    public long getStartTime() {
        return this.startTime;
    }
}
