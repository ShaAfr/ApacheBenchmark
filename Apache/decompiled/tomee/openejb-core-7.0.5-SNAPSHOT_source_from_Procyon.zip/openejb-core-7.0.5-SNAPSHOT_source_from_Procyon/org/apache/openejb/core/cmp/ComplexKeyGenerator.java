// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import java.util.Iterator;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import java.lang.reflect.Field;
import java.util.Collections;
import org.apache.openejb.OpenEJBException;
import java.util.ArrayList;
import java.util.List;

public class ComplexKeyGenerator extends AbstractKeyGenerator
{
    protected final List<PkField> fields;
    private final Class pkClass;
    
    public ComplexKeyGenerator(final Class entityBeanClass, final Class pkClass) throws OpenEJBException {
        this.pkClass = pkClass;
        final List<PkField> fields = new ArrayList<PkField>();
        for (final Field pkObjectField : pkClass.getFields()) {
            if (AbstractKeyGenerator.isValidPkField(pkObjectField)) {
                final Field entityBeanField = AbstractKeyGenerator.getField(entityBeanClass, pkObjectField.getName());
                if (!AbstractKeyGenerator.isValidPkField(entityBeanField)) {
                    throw new OpenEJBException("Invalid primray key field: " + entityBeanField);
                }
                final PkField pkField = new PkField(entityBeanField, pkObjectField);
                fields.add(pkField);
            }
        }
        this.fields = Collections.unmodifiableList((List<? extends PkField>)fields);
    }
    
    @Override
    public Object getPrimaryKey(final EntityBean bean) {
        Object pkObject = null;
        try {
            pkObject = this.pkClass.newInstance();
        }
        catch (Exception e) {
            throw new EJBException("Unable to create complex primary key instance: " + this.pkClass.getName(), e);
        }
        for (final PkField pkField : this.fields) {
            pkField.copyToPkObject(bean, pkObject);
        }
        return pkObject;
    }
    
    protected static class PkField
    {
        private final Field entityBeanField;
        private final Field pkObjectField;
        
        public PkField(final Field entityBeanField, final Field pkObjectField) {
            entityBeanField.setAccessible(true);
            pkObjectField.setAccessible(true);
            this.entityBeanField = entityBeanField;
            this.pkObjectField = pkObjectField;
        }
        
        public void copyToPkObject(final EntityBean bean, final Object pkObject) {
            final Object value = AbstractKeyGenerator.getFieldValue(this.entityBeanField, bean);
            AbstractKeyGenerator.setFieldValue(this.pkObjectField, pkObject, value);
        }
        
        public Object getPkFieldValue(final Object pkObject) {
            final Object value = AbstractKeyGenerator.getFieldValue(this.pkObjectField, pkObject);
            return value;
        }
    }
}
