// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.webbeans.container.InjectableBeanManager;
import org.apache.webbeans.config.WebBeansContext;
import java.lang.reflect.InvocationTargetException;
import org.apache.openejb.util.Logger;
import org.apache.openejb.util.LogCategory;
import java.lang.reflect.Method;
import java.io.Serializable;
import javax.transaction.Transaction;
import javax.persistence.spi.PersistenceUnitInfo;
import org.apache.openejb.OpenEJB;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import javax.enterprise.inject.spi.BeanManager;
import org.apache.openejb.loader.SystemInstance;
import javax.persistence.ValidationMode;
import java.util.HashMap;
import javax.persistence.spi.PersistenceProvider;
import javax.validation.ValidatorFactory;
import java.util.Map;
import org.apache.openejb.persistence.PersistenceUnitInfoImpl;
import javax.persistence.EntityManagerFactory;
import java.util.concurrent.Callable;

public class EntityManagerFactoryCallable implements Callable<EntityManagerFactory>
{
    public static final String OPENEJB_JPA_INIT_ENTITYMANAGER = "openejb.jpa.init-entitymanager";
    public static final String OPENJPA_ENTITY_MANAGER_FACTORY_POOL = "openjpa.EntityManagerFactoryPool";
    private final String persistenceProviderClassName;
    private final PersistenceUnitInfoImpl unitInfo;
    private final Map<ComparableValidationConfig, ValidatorFactory> potentialValidators;
    private final boolean cdi;
    private ClassLoader appClassLoader;
    private Class<?> provider;
    
    public EntityManagerFactoryCallable(final String persistenceProviderClassName, final PersistenceUnitInfoImpl unitInfo, final ClassLoader cl, final Map<ComparableValidationConfig, ValidatorFactory> validators, final boolean hasCdi) {
        this.persistenceProviderClassName = persistenceProviderClassName;
        this.unitInfo = unitInfo;
        this.appClassLoader = cl;
        this.potentialValidators = validators;
        this.cdi = hasCdi;
    }
    
    public Class<?> getProvider() {
        if (this.provider != null) {
            return this.provider;
        }
        final ClassLoader old = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(this.appClassLoader);
        try {
            return this.provider = this.appClassLoader.loadClass(this.persistenceProviderClassName);
        }
        catch (ClassNotFoundException e) {
            throw new IllegalArgumentException(e);
        }
        finally {
            Thread.currentThread().setContextClassLoader(old);
        }
    }
    
    @Override
    public EntityManagerFactory call() throws Exception {
        final ClassLoader old = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(this.appClassLoader);
        try {
            final Class<?> clazz = this.appClassLoader.loadClass(this.persistenceProviderClassName);
            final PersistenceProvider persistenceProvider = (PersistenceProvider)clazz.newInstance();
            final Map<String, Object> properties = new HashMap<String, Object>();
            if (!ValidationMode.NONE.equals((Object)this.unitInfo.getValidationMode())) {
                properties.put("javax.persistence.validation.factory", (this.potentialValidators != null && this.potentialValidators.size() == 1) ? this.ensureSerializable(this.potentialValidators.values().iterator().next()) : new ValidatorFactoryWrapper(this.potentialValidators));
            }
            if (this.cdi && "true".equalsIgnoreCase(this.unitInfo.getProperties().getProperty("tomee.jpa.cdi", "true")) && "true".equalsIgnoreCase(SystemInstance.get().getProperty("tomee.jpa.cdi", "true"))) {
                properties.put("javax.persistence.bean.manager", Proxy.newProxyInstance(this.appClassLoader, new Class[] { BeanManager.class }, new BmHandler()));
            }
            this.customizeProperties(properties);
            Transaction transaction;
            if (this.unitInfo.isLazilyInitialized()) {
                transaction = OpenEJB.getTransactionManager().suspend();
            }
            else {
                transaction = null;
            }
            EntityManagerFactory emf;
            try {
                emf = persistenceProvider.createContainerEntityManagerFactory((PersistenceUnitInfo)this.unitInfo, (Map)properties);
            }
            finally {
                if (this.unitInfo.isLazilyInitialized() && transaction != null) {
                    OpenEJB.getTransactionManager().resume(transaction);
                }
            }
            if ((this.unitInfo.getProperties() != null && "true".equalsIgnoreCase(this.unitInfo.getProperties().getProperty("openejb.jpa.init-entitymanager"))) || SystemInstance.get().getOptions().get("openejb.jpa.init-entitymanager", false)) {
                emf.createEntityManager().close();
            }
            if (this.unitInfo.getNonJtaDataSource() != null) {
                final ImportSql importer = new ImportSql(this.appClassLoader, this.unitInfo.getPersistenceUnitName(), this.unitInfo.getNonJtaDataSource());
                if (importer.hasSomethingToImport()) {
                    emf.createEntityManager().close();
                    importer.doImport();
                }
            }
            return emf;
        }
        finally {
            Thread.currentThread().setContextClassLoader(old);
        }
    }
    
    private void customizeProperties(final Map<String, Object> properties) {
        final String pool = SystemInstance.get().getProperty("openjpa.EntityManagerFactoryPool");
        if (pool != null) {
            properties.put("openjpa.EntityManagerFactoryPool", pool);
        }
    }
    
    public PersistenceUnitInfoImpl getUnitInfo() {
        return this.unitInfo;
    }
    
    public void overrideClassLoader(final ClassLoader loader) {
        this.appClassLoader = loader;
    }
    
    private ValidatorFactory ensureSerializable(final ValidatorFactory factory) {
        if (Serializable.class.isInstance(factory)) {
            return factory;
        }
        return (ValidatorFactory)new SingleValidatorFactoryWrapper(factory);
    }
    
    private static class BmHandler implements InvocationHandler, Serializable
    {
        private transient volatile BeanManager bm;
        
        @Override
        public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
            try {
                return method.invoke(this.findBm(), args);
            }
            catch (InvocationTargetException ite) {
                Logger.getInstance(LogCategory.OPENEJB_JPA, EntityManagerFactoryCallable.class).warning("Exception calling CDI, if a lifecycle issue you should maybe set tomee.jpa.factory.lazy=true", ite.getCause());
                throw ite.getCause();
            }
        }
        
        private Object findBm() {
            if (this.bm == null) {
                synchronized (this) {
                    if (this.bm == null) {
                        this.bm = (BeanManager)new InjectableBeanManager(WebBeansContext.currentInstance().getBeanManagerImpl());
                    }
                }
            }
            return this.bm;
        }
    }
}
