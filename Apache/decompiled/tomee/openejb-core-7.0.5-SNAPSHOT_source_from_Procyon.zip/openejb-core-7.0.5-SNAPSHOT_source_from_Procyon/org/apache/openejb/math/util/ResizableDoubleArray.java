// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.util;

import java.util.Arrays;
import org.apache.openejb.math.MathRuntimeException;
import java.io.Serializable;

public class ResizableDoubleArray implements DoubleArray, Serializable
{
    public static final int ADDITIVE_MODE = 1;
    public static final int MULTIPLICATIVE_MODE = 0;
    private static final long serialVersionUID = -1235529955529426875L;
    protected float contractionCriteria;
    protected float expansionFactor;
    protected int expansionMode;
    protected int initialCapacity;
    protected double[] internalArray;
    protected int numElements;
    protected int startIndex;
    
    public ResizableDoubleArray() {
        this.contractionCriteria = 2.5f;
        this.expansionFactor = 2.0f;
        this.expansionMode = 0;
        this.initialCapacity = 16;
        this.internalArray = new double[this.initialCapacity];
    }
    
    public ResizableDoubleArray(final int initialCapacity) {
        this.contractionCriteria = 2.5f;
        this.expansionFactor = 2.0f;
        this.expansionMode = 0;
        this.initialCapacity = 16;
        this.setInitialCapacity(initialCapacity);
        this.internalArray = new double[this.initialCapacity];
    }
    
    public ResizableDoubleArray(final int initialCapacity, final float expansionFactor) {
        this.contractionCriteria = 2.5f;
        this.expansionFactor = 2.0f;
        this.expansionMode = 0;
        this.initialCapacity = 16;
        this.expansionFactor = expansionFactor;
        this.setInitialCapacity(initialCapacity);
        this.internalArray = new double[initialCapacity];
        this.setContractionCriteria(expansionFactor + 0.5f);
    }
    
    public ResizableDoubleArray(final int initialCapacity, final float expansionFactor, final float contractionCriteria) {
        this.contractionCriteria = 2.5f;
        this.expansionFactor = 2.0f;
        this.expansionMode = 0;
        this.initialCapacity = 16;
        this.expansionFactor = expansionFactor;
        this.setContractionCriteria(contractionCriteria);
        this.setInitialCapacity(initialCapacity);
        this.internalArray = new double[initialCapacity];
    }
    
    public ResizableDoubleArray(final int initialCapacity, final float expansionFactor, final float contractionCriteria, final int expansionMode) {
        this.contractionCriteria = 2.5f;
        this.expansionFactor = 2.0f;
        this.expansionMode = 0;
        this.initialCapacity = 16;
        this.expansionFactor = expansionFactor;
        this.setContractionCriteria(contractionCriteria);
        this.setInitialCapacity(initialCapacity);
        this.setExpansionMode(expansionMode);
        this.internalArray = new double[initialCapacity];
    }
    
    public ResizableDoubleArray(final ResizableDoubleArray original) {
        this.contractionCriteria = 2.5f;
        this.expansionFactor = 2.0f;
        this.expansionMode = 0;
        this.initialCapacity = 16;
        copy(original, this);
    }
    
    @Override
    public synchronized void addElement(final double value) {
        ++this.numElements;
        if (this.startIndex + this.numElements > this.internalArray.length) {
            this.expand();
        }
        this.internalArray[this.startIndex + this.numElements - 1] = value;
        if (this.shouldContract()) {
            this.contract();
        }
    }
    
    @Override
    public synchronized double addElementRolling(final double value) {
        final double discarded = this.internalArray[this.startIndex];
        if (this.startIndex + this.numElements + 1 > this.internalArray.length) {
            this.expand();
        }
        ++this.startIndex;
        this.internalArray[this.startIndex + this.numElements - 1] = value;
        if (this.shouldContract()) {
            this.contract();
        }
        return discarded;
    }
    
    public synchronized double substituteMostRecentElement(final double value) {
        if (this.numElements < 1) {
            throw MathRuntimeException.createArrayIndexOutOfBoundsException("cannot substitute an element from an empty array", new Object[0]);
        }
        final double discarded = this.internalArray[this.startIndex + this.numElements - 1];
        this.internalArray[this.startIndex + this.numElements - 1] = value;
        return discarded;
    }
    
    protected void checkContractExpand(final float contraction, final float expansion) {
        if (contraction < expansion) {
            throw MathRuntimeException.createIllegalArgumentException("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction", contraction, expansion);
        }
        if (contraction <= 1.0) {
            throw MathRuntimeException.createIllegalArgumentException("contraction criteria smaller than one ({0}).  This would lead to a never ending loop of expansion and contraction as an internal storage array length equal to the number of elements would satisfy the contraction criteria.", contraction);
        }
        if (expansion <= 1.0) {
            throw MathRuntimeException.createIllegalArgumentException("expansion factor smaller than one ({0})", expansion);
        }
    }
    
    @Override
    public synchronized void clear() {
        this.numElements = 0;
        this.startIndex = 0;
        this.internalArray = new double[this.initialCapacity];
    }
    
    public synchronized void contract() {
        final double[] tempArray = new double[this.numElements + 1];
        System.arraycopy(this.internalArray, this.startIndex, tempArray, 0, this.numElements);
        this.internalArray = tempArray;
        this.startIndex = 0;
    }
    
    public synchronized void discardFrontElements(final int i) {
        this.discardExtremeElements(i, true);
    }
    
    public synchronized void discardMostRecentElements(final int i) {
        this.discardExtremeElements(i, false);
    }
    
    private synchronized void discardExtremeElements(final int i, final boolean front) {
        if (i > this.numElements) {
            throw MathRuntimeException.createIllegalArgumentException("cannot discard {0} elements from a {1} elements array", i, this.numElements);
        }
        if (i < 0) {
            throw MathRuntimeException.createIllegalArgumentException("cannot discard a negative number of elements ({0})", i);
        }
        this.numElements -= i;
        if (front) {
            this.startIndex += i;
        }
        if (this.shouldContract()) {
            this.contract();
        }
    }
    
    protected synchronized void expand() {
        int newSize = 0;
        if (this.expansionMode == 0) {
            newSize = (int)Math.ceil(this.internalArray.length * this.expansionFactor);
        }
        else {
            newSize = this.internalArray.length + Math.round(this.expansionFactor);
        }
        final double[] tempArray = new double[newSize];
        System.arraycopy(this.internalArray, 0, tempArray, 0, this.internalArray.length);
        this.internalArray = tempArray;
    }
    
    private synchronized void expandTo(final int size) {
        final double[] tempArray = new double[size];
        System.arraycopy(this.internalArray, 0, tempArray, 0, this.internalArray.length);
        this.internalArray = tempArray;
    }
    
    public float getContractionCriteria() {
        return this.contractionCriteria;
    }
    
    @Override
    public synchronized double getElement(final int index) {
        if (index >= this.numElements) {
            throw MathRuntimeException.createArrayIndexOutOfBoundsException("the index specified: {0} is larger than the current maximal index {1}", index, this.numElements - 1);
        }
        if (index >= 0) {
            return this.internalArray[this.startIndex + index];
        }
        throw MathRuntimeException.createArrayIndexOutOfBoundsException("elements cannot be retrieved from a negative array index {0}", index);
    }
    
    @Override
    public synchronized double[] getElements() {
        final double[] elementArray = new double[this.numElements];
        System.arraycopy(this.internalArray, this.startIndex, elementArray, 0, this.numElements);
        return elementArray;
    }
    
    public float getExpansionFactor() {
        return this.expansionFactor;
    }
    
    public int getExpansionMode() {
        return this.expansionMode;
    }
    
    synchronized int getInternalLength() {
        return this.internalArray.length;
    }
    
    @Override
    public synchronized int getNumElements() {
        return this.numElements;
    }
    
    @Deprecated
    public synchronized double[] getValues() {
        return this.internalArray;
    }
    
    public synchronized double[] getInternalValues() {
        return this.internalArray;
    }
    
    public void setContractionCriteria(final float contractionCriteria) {
        this.checkContractExpand(contractionCriteria, this.getExpansionFactor());
        synchronized (this) {
            this.contractionCriteria = contractionCriteria;
        }
    }
    
    @Override
    public synchronized void setElement(final int index, final double value) {
        if (index < 0) {
            throw MathRuntimeException.createArrayIndexOutOfBoundsException("cannot set an element at a negative index {0}", index);
        }
        if (index + 1 > this.numElements) {
            this.numElements = index + 1;
        }
        if (this.startIndex + index >= this.internalArray.length) {
            this.expandTo(this.startIndex + index + 1);
        }
        this.internalArray[this.startIndex + index] = value;
    }
    
    public void setExpansionFactor(final float expansionFactor) {
        this.checkContractExpand(this.getContractionCriteria(), expansionFactor);
        synchronized (this) {
            this.expansionFactor = expansionFactor;
        }
    }
    
    public void setExpansionMode(final int expansionMode) {
        if (expansionMode != 0 && expansionMode != 1) {
            throw MathRuntimeException.createIllegalArgumentException("unsupported expansion mode {0}, supported modes are {1} ({2}) and {3} ({4})", expansionMode, 0, "MULTIPLICATIVE_MODE", 1, "ADDITIVE_MODE");
        }
        synchronized (this) {
            this.expansionMode = expansionMode;
        }
    }
    
    protected void setInitialCapacity(final int initialCapacity) {
        if (initialCapacity > 0) {
            synchronized (this) {
                this.initialCapacity = initialCapacity;
            }
            return;
        }
        throw MathRuntimeException.createIllegalArgumentException("initial capacity ({0}) is not positive", initialCapacity);
    }
    
    public synchronized void setNumElements(final int i) {
        if (i < 0) {
            throw MathRuntimeException.createIllegalArgumentException("index ({0}) is not positive", i);
        }
        if (this.startIndex + i > this.internalArray.length) {
            this.expandTo(this.startIndex + i);
        }
        this.numElements = i;
    }
    
    private synchronized boolean shouldContract() {
        if (this.expansionMode == 0) {
            return this.internalArray.length / (float)this.numElements > this.contractionCriteria;
        }
        return this.internalArray.length - this.numElements > this.contractionCriteria;
    }
    
    public synchronized int start() {
        return this.startIndex;
    }
    
    public static void copy(final ResizableDoubleArray source, final ResizableDoubleArray dest) {
        synchronized (source) {
            synchronized (dest) {
                dest.initialCapacity = source.initialCapacity;
                dest.contractionCriteria = source.contractionCriteria;
                dest.expansionFactor = source.expansionFactor;
                dest.expansionMode = source.expansionMode;
                dest.internalArray = new double[source.internalArray.length];
                System.arraycopy(source.internalArray, 0, dest.internalArray, 0, dest.internalArray.length);
                dest.numElements = source.numElements;
                dest.startIndex = source.startIndex;
            }
        }
    }
    
    public synchronized ResizableDoubleArray copy() {
        final ResizableDoubleArray result = new ResizableDoubleArray();
        copy(this, result);
        return result;
    }
    
    @Override
    public boolean equals(final Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof ResizableDoubleArray)) {
            return false;
        }
        synchronized (this) {
            synchronized (object) {
                boolean result = true;
                final ResizableDoubleArray other = (ResizableDoubleArray)object;
                result = (result && other.initialCapacity == this.initialCapacity);
                result = (result && other.contractionCriteria == this.contractionCriteria);
                result = (result && other.expansionFactor == this.expansionFactor);
                result = (result && other.expansionMode == this.expansionMode);
                result = (result && other.numElements == this.numElements);
                result = (result && other.startIndex == this.startIndex);
                return result && Arrays.equals(this.internalArray, other.internalArray);
            }
        }
    }
    
    @Override
    public synchronized int hashCode() {
        final int[] hashData = { new Float(this.expansionFactor).hashCode(), new Float(this.contractionCriteria).hashCode(), this.expansionMode, Arrays.hashCode(this.internalArray), this.initialCapacity, this.numElements, this.startIndex };
        return Arrays.hashCode(hashData);
    }
}
