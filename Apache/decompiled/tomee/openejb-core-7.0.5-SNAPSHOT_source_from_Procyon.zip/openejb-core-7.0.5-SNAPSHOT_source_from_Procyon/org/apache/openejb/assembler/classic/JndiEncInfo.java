// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class JndiEncInfo extends InfoObject
{
    public final List<EnvEntryInfo> envEntries;
    public final List<EjbReferenceInfo> ejbReferences;
    public final List<EjbLocalReferenceInfo> ejbLocalReferences;
    public final List<ResourceReferenceInfo> resourceRefs;
    public final List<PersistenceUnitReferenceInfo> persistenceUnitRefs;
    public final List<PersistenceContextReferenceInfo> persistenceContextRefs;
    public final List<ResourceEnvReferenceInfo> resourceEnvRefs;
    public final List<ServiceReferenceInfo> serviceRefs;
    
    public JndiEncInfo() {
        this.envEntries = new ArrayList<EnvEntryInfo>();
        this.ejbReferences = new ArrayList<EjbReferenceInfo>();
        this.ejbLocalReferences = new ArrayList<EjbLocalReferenceInfo>();
        this.resourceRefs = new ArrayList<ResourceReferenceInfo>();
        this.persistenceUnitRefs = new ArrayList<PersistenceUnitReferenceInfo>();
        this.persistenceContextRefs = new ArrayList<PersistenceContextReferenceInfo>();
        this.resourceEnvRefs = new ArrayList<ResourceEnvReferenceInfo>();
        this.serviceRefs = new ArrayList<ServiceReferenceInfo>();
    }
}
