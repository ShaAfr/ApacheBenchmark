// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.List;

public class NamedMethodInfo extends InfoObject
{
    public String className;
    public String methodName;
    public List<String> methodParams;
    public String id;
}
