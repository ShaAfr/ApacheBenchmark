// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import javax.naming.NameNotFoundException;
import org.apache.openejb.util.Strings;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;

public class IntraVmJndiReference extends Reference
{
    private final String jndiName;
    
    public IntraVmJndiReference(final String jndiName) {
        this.jndiName = jndiName;
    }
    
    public String getJndiName() {
        return this.jndiName;
    }
    
    @Override
    public Object getObject() throws NamingException {
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        try {
            return containerSystem.getJNDIContext().lookup(this.jndiName);
        }
        catch (NameNotFoundException e2) {
            return containerSystem.getJNDIContext().lookup("java:module/" + Strings.lastPart(this.getClassName(), '.'));
        }
        catch (NamingException e) {
            throw (NamingException)new NamingException("could not look up " + this.jndiName).initCause(e);
        }
    }
    
    public String toString() {
        return "IntraVmJndiReference{jndiName='" + this.jndiName + '\'' + '}';
    }
}
