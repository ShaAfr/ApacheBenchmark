// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class JndiNameInfo extends InfoObject
{
    public String name;
    public String intrface;
}
