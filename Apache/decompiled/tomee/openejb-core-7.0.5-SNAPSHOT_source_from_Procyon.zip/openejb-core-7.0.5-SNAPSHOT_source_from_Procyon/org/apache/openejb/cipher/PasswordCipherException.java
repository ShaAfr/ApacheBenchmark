// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

public class PasswordCipherException extends RuntimeException
{
    public PasswordCipherException() {
    }
    
    public PasswordCipherException(final String message) {
        super(message);
    }
    
    public PasswordCipherException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public PasswordCipherException(final Throwable cause) {
        super(cause);
    }
}
