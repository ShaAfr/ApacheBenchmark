// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.util;

import org.apache.openejb.assembler.classic.EjbJarInfo;
import org.apache.openejb.assembler.classic.WebAppInfo;
import org.apache.openejb.assembler.classic.AppInfo;
import java.util.Iterator;
import java.util.Properties;
import org.apache.openejb.assembler.classic.IdPropertiesInfo;
import java.util.Collection;

public final class PojoUtil
{
    private PojoUtil() {
    }
    
    public static Properties findConfiguration(final Collection<IdPropertiesInfo> infos, final String id) {
        for (final IdPropertiesInfo info : infos) {
            if (id.equals(info.id)) {
                return info.properties;
            }
        }
        return null;
    }
    
    public static Collection<IdPropertiesInfo> findPojoConfig(final Collection<IdPropertiesInfo> pojoConfigurations, final AppInfo appInfo, final WebAppInfo webApp) {
        if (pojoConfigurations == null) {
            for (final EjbJarInfo ejbJarInfo : appInfo.ejbJars) {
                if (ejbJarInfo.moduleId.equals(webApp.moduleId)) {
                    return ejbJarInfo.pojoConfigurations;
                }
            }
            for (final EjbJarInfo ejbJarInfo : appInfo.ejbJars) {
                if (ejbJarInfo.moduleName.equals(webApp.moduleId)) {
                    return ejbJarInfo.pojoConfigurations;
                }
            }
        }
        return pojoConfigurations;
    }
}
