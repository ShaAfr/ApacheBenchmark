// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.classloader;

import java.net.URL;

public interface WebAppEnricher
{
    URL[] enrichment(final ClassLoader p0);
}
