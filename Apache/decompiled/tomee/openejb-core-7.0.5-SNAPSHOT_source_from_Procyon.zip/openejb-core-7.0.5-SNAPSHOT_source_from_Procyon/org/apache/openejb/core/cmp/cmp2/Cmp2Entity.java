// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

public interface Cmp2Entity
{
    Object OpenEJB_getPrimaryKey();
    
    Object OpenEJB_addCmr(final String p0, final Object p1);
    
    void OpenEJB_removeCmr(final String p0, final Object p1);
}
