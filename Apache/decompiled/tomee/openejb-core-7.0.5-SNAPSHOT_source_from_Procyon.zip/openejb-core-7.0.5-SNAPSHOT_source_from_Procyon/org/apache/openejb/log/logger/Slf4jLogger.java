// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log.logger;

import java.util.logging.Handler;
import org.slf4j.Marker;
import java.util.logging.LogRecord;
import java.util.logging.Level;
import org.slf4j.LoggerFactory;
import org.slf4j.spi.LocationAwareLogger;
import org.slf4j.Logger;

public class Slf4jLogger extends AbstractDelegatingLogger
{
    private static final String FQCN;
    private final org.slf4j.Logger logger;
    private LocationAwareLogger locationAwareLogger;
    
    public Slf4jLogger(final String name, final String resourceBundleName) {
        super(name, resourceBundleName);
        this.logger = LoggerFactory.getLogger(name);
        if (this.logger instanceof LocationAwareLogger) {
            this.locationAwareLogger = (LocationAwareLogger)this.logger;
        }
    }
    
    @Override
    protected boolean supportsHandlers() {
        return true;
    }
    
    @Override
    public Level getLevel() {
        Level level;
        if (this.logger.isTraceEnabled()) {
            level = Level.FINEST;
        }
        else if (this.logger.isDebugEnabled()) {
            level = Level.FINER;
        }
        else if (this.logger.isInfoEnabled()) {
            level = Level.INFO;
        }
        else if (this.logger.isWarnEnabled()) {
            level = Level.WARNING;
        }
        else if (this.logger.isErrorEnabled()) {
            level = Level.SEVERE;
        }
        else {
            level = Level.OFF;
        }
        return level;
    }
    
    @Override
    public boolean isLoggable(final Level level) {
        final int i = level.intValue();
        if (i == Level.OFF.intValue()) {
            return false;
        }
        if (i >= Level.SEVERE.intValue()) {
            return this.logger.isErrorEnabled();
        }
        if (i >= Level.WARNING.intValue()) {
            return this.logger.isWarnEnabled();
        }
        if (i >= Level.INFO.intValue()) {
            return this.logger.isInfoEnabled();
        }
        if (i >= Level.FINER.intValue()) {
            return this.logger.isDebugEnabled();
        }
        return this.logger.isTraceEnabled();
    }
    
    @Override
    protected void internalLogFormatted(final String msg, final LogRecord record) {
        final Level level = record.getLevel();
        final Throwable t = record.getThrown();
        final Handler[] targets = this.getHandlers();
        if (targets != null) {
            for (final Handler h : targets) {
                h.publish(record);
            }
        }
        if (!this.getUseParentHandlers()) {
            return;
        }
        if (Level.FINE.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.debug(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 10, msg, (Object[])null, t);
            }
        }
        else if (Level.INFO.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.info(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 20, msg, (Object[])null, t);
            }
        }
        else if (Level.WARNING.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.warn(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 30, msg, (Object[])null, t);
            }
        }
        else if (Level.FINER.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.trace(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 10, msg, (Object[])null, t);
            }
        }
        else if (Level.FINEST.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.trace(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 0, msg, (Object[])null, t);
            }
        }
        else if (Level.ALL.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.error(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 40, msg, (Object[])null, t);
            }
        }
        else if (Level.SEVERE.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.error(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 40, msg, (Object[])null, t);
            }
        }
        else if (Level.CONFIG.equals(level)) {
            if (this.locationAwareLogger == null) {
                this.logger.debug(msg, t);
            }
            else {
                this.locationAwareLogger.log((Marker)null, Slf4jLogger.FQCN, 10, msg, (Object[])null, t);
            }
        }
    }
    
    static {
        FQCN = AbstractDelegatingLogger.class.getName();
    }
}
