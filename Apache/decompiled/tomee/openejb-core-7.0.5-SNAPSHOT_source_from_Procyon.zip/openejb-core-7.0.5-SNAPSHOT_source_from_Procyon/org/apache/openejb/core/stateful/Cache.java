// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import org.apache.openejb.util.Duration;

public interface Cache<K, V>
{
    CacheListener<V> getListener();
    
    void setListener(final CacheListener<V> p0);
    
    void add(final K p0, final V p1);
    
    V checkOut(final K p0, final boolean p1) throws Exception;
    
    void checkIn(final K p0);
    
    V remove(final K p0);
    
    void removeAll(final CacheFilter<V> p0);
    
    void init();
    
    void destroy();
    
    public interface TimeOut
    {
        Duration getTimeOut();
    }
    
    public interface CacheFilter<V>
    {
        boolean matches(final V p0);
    }
    
    public interface CacheListener<V>
    {
        void afterLoad(final V p0) throws Exception;
        
        void beforeStore(final V p0) throws Exception;
        
        void timedOut(final V p0);
    }
}
