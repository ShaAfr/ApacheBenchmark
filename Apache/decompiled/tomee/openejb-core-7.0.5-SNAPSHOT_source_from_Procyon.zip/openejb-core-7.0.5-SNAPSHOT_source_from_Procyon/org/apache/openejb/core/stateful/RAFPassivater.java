// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.util.Iterator;
import org.apache.openejb.spi.Serializer;
import java.io.RandomAccessFile;
import org.apache.openejb.util.JavaSecurityManagers;
import java.io.File;
import java.util.Map;
import org.apache.openejb.SystemException;
import java.util.Properties;
import java.util.HashMap;

public class RAFPassivater implements PassivationStrategy
{
    int fileID;
    HashMap masterTable;
    
    public RAFPassivater() {
        this.masterTable = new HashMap();
    }
    
    @Override
    public void init(final Properties props) throws SystemException {
    }
    
    @Override
    public synchronized void passivate(final Map stateTable) throws SystemException {
        try (final RandomAccessFile ras = new RandomAccessFile(JavaSecurityManagers.getSystemProperty("java.io.tmpdir", File.separator + "tmp") + File.separator + "passivation" + this.fileID + ".ser", "rw")) {
            ++this.fileID;
            final Iterator iterator = stateTable.keySet().iterator();
            Pointer lastPointer = null;
            while (iterator.hasNext()) {
                final Object id = iterator.next();
                final Object obj = stateTable.get(id);
                final byte[] bytes = Serializer.serialize(obj);
                final long filepointer = ras.getFilePointer();
                if (lastPointer == null) {
                    lastPointer = new Pointer(this.fileID, filepointer, (int)filepointer);
                }
                else {
                    lastPointer = new Pointer(this.fileID, filepointer, (int)(filepointer - lastPointer.filepointer));
                }
                this.masterTable.put(id, lastPointer);
                ras.write(bytes);
            }
        }
        catch (Exception e) {
            throw new SystemException(e);
        }
    }
    
    @Override
    public synchronized Object activate(final Object primaryKey) throws SystemException {
        final Pointer pointer = this.masterTable.get(primaryKey);
        if (pointer == null) {
            return null;
        }
        try (final RandomAccessFile ras = new RandomAccessFile(JavaSecurityManagers.getSystemProperty("java.io.tmpdir", File.separator + "tmp") + File.separator + "passivation" + pointer.fileid + ".ser", "r")) {
            final byte[] bytes = new byte[pointer.bytesize];
            ras.seek(pointer.filepointer);
            ras.readFully(bytes);
            return Serializer.deserialize(bytes);
        }
        catch (Exception e) {
            throw new SystemException(e);
        }
    }
    
    static class Pointer
    {
        int fileid;
        long filepointer;
        int bytesize;
        
        public Pointer(final int file, final long pointer, final int bytecount) {
            this.fileid = file;
            this.filepointer = pointer;
            this.bytesize = bytecount;
        }
    }
}
