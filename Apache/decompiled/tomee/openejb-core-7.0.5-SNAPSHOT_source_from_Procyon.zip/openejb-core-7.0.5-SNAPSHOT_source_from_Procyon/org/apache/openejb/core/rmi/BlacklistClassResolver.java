// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.rmi;

import org.apache.openejb.util.JavaSecurityManagers;
import java.io.ObjectStreamClass;
import java.util.regex.Pattern;

public class BlacklistClassResolver
{
    public static final BlacklistClassResolver DEFAULT;
    public static final Pattern PRIMITIVE_ARRAY;
    private final String[] blacklist;
    private final String[] whitelist;
    
    protected BlacklistClassResolver(final String[] blacklist, final String[] whitelist) {
        this.whitelist = whitelist;
        this.blacklist = blacklist;
    }
    
    protected boolean isBlacklisted(final String name) {
        if (BlacklistClassResolver.PRIMITIVE_ARRAY.matcher(name).matches()) {
            return false;
        }
        if (name != null && name.startsWith("[L") && name.endsWith(";")) {
            return this.isBlacklisted(name.substring(2, name.length() - 1));
        }
        return (this.whitelist != null && !contains(this.whitelist, name)) || contains(this.blacklist, name);
    }
    
    public final ObjectStreamClass check(final ObjectStreamClass classDesc) {
        this.check(classDesc.getName());
        return classDesc;
    }
    
    public final String check(final String name) {
        if (this.isBlacklisted(name)) {
            throw new SecurityException(name + " is not whitelisted as deserialisable, prevented before loading it, customize tomee.serialization.class.blacklist and tomee.serialization.class.whitelist to add it to not fail there. -Dtomee.serialization.class.blacklist=- -Dtomee.serialization.class.whitelist=" + name + " for instance (or in conf/system.properties).");
        }
        return name;
    }
    
    private static String[] toArray(final String property) {
        return (String[])((property == null) ? null : property.split(" *, *"));
    }
    
    private static boolean contains(final String[] list, final String name) {
        if (list != null) {
            for (final String white : list) {
                if ("*".equals(white) || name.startsWith(white)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    static {
        DEFAULT = new BlacklistClassResolver(toArray(JavaSecurityManagers.getSystemProperty("tomee.serialization.class.blacklist", "org.codehaus.groovy.runtime.,org.apache.commons.collections.functors.,org.apache.xalan,java.lang.Process")), toArray(JavaSecurityManagers.getSystemProperty("tomee.serialization.class.whitelist")));
        PRIMITIVE_ARRAY = Pattern.compile("^\\[+[BCDFIJSVZ]$");
    }
}
