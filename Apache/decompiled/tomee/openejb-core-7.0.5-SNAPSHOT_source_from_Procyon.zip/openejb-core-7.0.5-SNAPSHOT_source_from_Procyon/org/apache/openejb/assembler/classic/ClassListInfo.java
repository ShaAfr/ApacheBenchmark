// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.HashSet;
import java.util.Set;

public class ClassListInfo extends InfoObject
{
    public String name;
    public final Set<String> list;
    
    public ClassListInfo() {
        this.list = new HashSet<String>();
    }
}
