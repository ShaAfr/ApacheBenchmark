// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.ApplicationException;
import java.rmi.RemoteException;
import org.apache.openejb.core.CoreUserTransaction;
import javax.transaction.UserTransaction;
import org.apache.openejb.SystemException;
import javax.transaction.TransactionManager;
import javax.transaction.Transaction;

public class TxBeanManaged extends JtaTransactionPolicy implements BeanTransactionPolicy
{
    private final Transaction clientTx;
    
    public TxBeanManaged(final TransactionManager transactionManager) throws SystemException {
        super(TransactionType.BeanManaged, transactionManager);
        this.clientTx = this.suspendTransaction();
    }
    
    @Override
    public boolean isNewTransaction() {
        return false;
    }
    
    @Override
    public boolean isClientTransaction() {
        return false;
    }
    
    @Override
    public Transaction getCurrentTransaction() {
        try {
            return this.getTransaction();
        }
        catch (SystemException e) {
            throw new IllegalStateException("Exception getting current transaction");
        }
    }
    
    @Override
    public UserTransaction getUserTransaction() {
        return (UserTransaction)new CoreUserTransaction(this.transactionManager);
    }
    
    @Override
    public SuspendedTransaction suspendUserTransaction() throws SystemException {
        final Transaction currentTx = this.suspendTransaction();
        if (currentTx == null) {
            return null;
        }
        return new JtaSuspendedTransaction(currentTx);
    }
    
    @Override
    public void resumeUserTransaction(final SuspendedTransaction suspendedTransaction) throws SystemException {
        if (suspendedTransaction == null) {
            throw new NullPointerException("suspendedTransaction is null");
        }
        final Transaction beanTransaction = ((JtaSuspendedTransaction)suspendedTransaction).transaction;
        if (beanTransaction == null) {
            throw new SystemException("Bean transaction has already been resumed or destroyed");
        }
        try {
            this.resumeTransaction(beanTransaction);
        }
        catch (SystemException e) {
            suspendedTransaction.destroy();
            throw e;
        }
    }
    
    @Override
    public void commit() throws ApplicationException, SystemException {
        try {
            final Transaction currentTx = this.getTransaction();
            if (currentTx != null) {
                final String message = "The EJB started a transaction but did not complete it.";
                TxBeanManaged.logger.error("The EJB started a transaction but did not complete it.");
                try {
                    this.rollbackTransaction(currentTx);
                }
                catch (Throwable t) {}
                throw new ApplicationException(new RemoteException("The EJB started a transaction but did not complete it."));
            }
            this.fireNonTransactionalCompletion();
        }
        finally {
            this.resumeTransaction(this.clientTx);
        }
    }
    
    private static class JtaSuspendedTransaction implements SuspendedTransaction
    {
        private Transaction transaction;
        
        public JtaSuspendedTransaction(final Transaction transaction) {
            if (transaction == null) {
                throw new NullPointerException("transaction is null");
            }
            this.transaction = transaction;
        }
        
        @Override
        public void destroy() {
            final Transaction beanTransaction = this.transaction;
            this.transaction = null;
            if (beanTransaction == null) {
                return;
            }
            try {
                beanTransaction.rollback();
            }
            catch (Exception e) {
                JtaTransactionPolicy.logger.error("Error rolling back suspended transaction for discarded stateful session bean instance");
            }
        }
    }
}
