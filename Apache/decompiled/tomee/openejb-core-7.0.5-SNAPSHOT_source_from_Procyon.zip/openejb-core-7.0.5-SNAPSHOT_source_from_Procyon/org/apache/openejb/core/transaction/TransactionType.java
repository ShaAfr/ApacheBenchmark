// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import javax.ejb.TransactionAttributeType;

public enum TransactionType
{
    Mandatory, 
    Never, 
    NotSupported, 
    Required, 
    RequiresNew, 
    Supports, 
    BeanManaged;
    
    public static TransactionType get(final TransactionAttributeType type) {
        switch (type) {
            case REQUIRED: {
                return TransactionType.Required;
            }
            case REQUIRES_NEW: {
                return TransactionType.RequiresNew;
            }
            case MANDATORY: {
                return TransactionType.Mandatory;
            }
            case NEVER: {
                return TransactionType.Never;
            }
            case NOT_SUPPORTED: {
                return TransactionType.NotSupported;
            }
            case SUPPORTS: {
                return TransactionType.Supports;
            }
            default: {
                throw new IllegalArgumentException("Uknown TransactionAttributeType." + type);
            }
        }
    }
    
    public static TransactionType get(final String name) {
        for (final TransactionType type : values()) {
            if (type.name().equalsIgnoreCase(name)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Uknown TransactionType " + name);
    }
}
