// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

import java.net.URL;
import java.util.Map;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.xbean.finder.ResourceFinder;

public class PasswordCipherFactory
{
    public static PasswordCipher getPasswordCipher(final String passwordCipherClass) {
        PasswordCipher cipher;
        try {
            cipher = doInternalPasswordCipher(PasswordCipher.class, passwordCipherClass);
        }
        catch (PasswordCipherException initial) {
            try {
                return doInternalPasswordCipher(org.apache.openejb.resource.jdbc.cipher.PasswordCipher.class, passwordCipherClass);
            }
            catch (PasswordCipherException ignore) {
                throw initial;
            }
        }
        return cipher;
    }
    
    private static <T extends PasswordCipher> T doInternalPasswordCipher(final Class<T> intf, final String passwordCipherClass) {
        final ResourceFinder finder = new ResourceFinder("META-INF/");
        Map<String, Class<? extends T>> impls;
        try {
            impls = (Map<String, Class<? extends T>>)finder.mapAllImplementations((Class)intf);
        }
        catch (Throwable t) {
            final String message = "Password cipher '" + passwordCipherClass + "' not found in META-INF/org.apache.openejb.cipher.PasswordCipher.";
            throw new PasswordCipherException(message, t);
        }
        Class<? extends T> pwdCipher = impls.get(passwordCipherClass);
        final ClassLoader tccl = Thread.currentThread().getContextClassLoader();
        final URL url = tccl.getResource("META-INF/" + intf.getName() + "/" + passwordCipherClass);
        if (url != null) {
            try {
                final String clazz = new BufferedReader(new InputStreamReader(url.openStream())).readLine().trim();
                pwdCipher = tccl.loadClass(clazz).asSubclass(intf);
            }
            catch (Exception ex) {}
        }
        if (null == pwdCipher) {
            try {
                try {
                    pwdCipher = Class.forName(passwordCipherClass).asSubclass(intf);
                }
                catch (ClassNotFoundException cnfe) {
                    pwdCipher = tccl.loadClass(passwordCipherClass).asSubclass(intf);
                }
            }
            catch (Throwable t2) {
                final String message2 = "Cannot load password cipher class '" + passwordCipherClass + "'";
                throw new PasswordCipherException(message2, t2);
            }
        }
        try {
            return (T)pwdCipher.newInstance();
        }
        catch (Throwable t2) {
            final String message2 = "Cannot create password cipher instance";
            throw new PasswordCipherException("Cannot create password cipher instance", t2);
        }
    }
}
