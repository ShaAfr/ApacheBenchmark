// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.Core;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.ClientInjections;
import org.apache.openejb.spi.ContainerSystem;
import javax.naming.Context;
import org.apache.openejb.OpenEJBRuntimeException;
import javax.security.auth.login.LoginException;
import javax.naming.AuthenticationException;
import org.apache.openejb.core.ivm.ClientSecurity;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.OpenEJB;
import javax.naming.NamingException;
import java.util.Map;
import java.util.Hashtable;
import org.apache.openejb.util.ServiceManagerProxy;
import org.apache.openejb.loader.Options;
import java.util.Properties;
import org.apache.openejb.util.Logger;
import org.apache.openejb.core.ivm.naming.ContextWrapper;

public class LocalInitialContext extends ContextWrapper
{
    public static final String OPENEJB_EMBEDDED_REMOTABLE = "openejb.embedded.remotable";
    static Logger logger;
    private final LocalInitialContextFactory factory;
    private final Properties properties;
    private Object clientIdentity;
    public static final String ON_CLOSE = "openejb.embedded.initialcontext.close";
    private final Close onClose;
    private final Options options;
    private ServiceManagerProxy serviceManager;
    
    public LocalInitialContext(final Hashtable env, final LocalInitialContextFactory factory) throws NamingException {
        super(getContainerSystemEjbContext());
        (this.properties = new Properties()).putAll(env);
        this.options = new Options(this.properties);
        this.onClose = (Close)this.options.get("openejb.embedded.initialcontext.close", (Enum)Close.LOGOUT);
        this.factory = factory;
        this.login();
        this.startNetworkServices();
    }
    
    @Override
    public void close() throws NamingException {
        LocalInitialContext.logger.debug("LocalIntialContext.close()");
        switch (this.onClose) {
            case LOGOUT: {
                this.logout();
                break;
            }
            case DESTROY: {
                this.logout();
                this.destroy();
                break;
            }
        }
    }
    
    private void destroy() throws NamingException {
        if (this.serviceManager != null) {
            this.serviceManager.stop();
        }
        this.tearDownOpenEJB();
    }
    
    private void tearDownOpenEJB() throws NamingException {
        if (this.factory.bootedOpenEJB()) {
            LocalInitialContext.logger.info("Destroying container system");
            this.factory.close();
            this.context.close();
            OpenEJB.destroy();
        }
    }
    
    private void login() throws AuthenticationException {
        final String user = (String)this.properties.get("java.naming.security.principal");
        final String pass = (String)this.properties.get("java.naming.security.credentials");
        final String realmName = (String)this.properties.get("openejb.authentication.realmName");
        if (user != null && pass != null) {
            try {
                if (LocalInitialContext.logger.isDebugEnabled()) {
                    LocalInitialContext.logger.debug("Logging in: " + user);
                }
                final SecurityService securityService = (SecurityService)SystemInstance.get().getComponent((Class)SecurityService.class);
                if (realmName == null) {
                    this.clientIdentity = securityService.login(user, pass);
                }
                else {
                    this.clientIdentity = securityService.login(realmName, user, pass);
                }
                ClientSecurity.setIdentity(this.clientIdentity);
            }
            catch (LoginException e) {
                throw (AuthenticationException)new AuthenticationException("User could not be authenticated: " + user).initCause(e);
            }
        }
    }
    
    private void logout() {
        try {
            final SecurityService securityService = (SecurityService)SystemInstance.get().getComponent((Class)SecurityService.class);
            if (this.clientIdentity != null) {
                if (LocalInitialContext.logger.isDebugEnabled()) {
                    LocalInitialContext.logger.debug("Logging out: " + this.clientIdentity);
                }
                securityService.logout(this.clientIdentity);
                ClientSecurity.setIdentity(null);
            }
        }
        catch (LoginException e) {
            throw new OpenEJBRuntimeException("User could not be logged out.", e);
        }
    }
    
    private void startNetworkServices() {
        if (!this.options.get("openejb.embedded.remotable", false)) {
            return;
        }
        try {
            (this.serviceManager = new ServiceManagerProxy()).start();
        }
        catch (ServiceManagerProxy.AlreadyStartedException e) {
            LocalInitialContext.logger.debug("Network services already started.  Ignoring option openejb.embedded.remotable");
        }
    }
    
    private static Context getContainerSystemEjbContext() throws NamingException {
        Context context = getRoot();
        context = (Context)context.lookup("openejb/local");
        return context;
    }
    
    private static Context getRoot() {
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        return containerSystem.getJNDIContext();
    }
    
    @Override
    public void bind(final String name, final Object obj) throws NamingException {
        if ("inject".equalsIgnoreCase(name)) {
            this.inject(obj);
        }
        else {
            super.bind(name, obj);
        }
    }
    
    private void inject(final Object obj) throws NamingException {
        try {
            ClientInjections.clientInjector(obj).createInstance();
        }
        catch (OpenEJBException e) {
            throw (NamingException)new NamingException("Injection failed").initCause(e);
        }
    }
    
    static {
        Core.warmup();
        LocalInitialContext.logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP.createChild("local"), LocalInitialContext.class);
    }
    
    public enum Close
    {
        LOGOUT, 
        DESTROY;
    }
}
