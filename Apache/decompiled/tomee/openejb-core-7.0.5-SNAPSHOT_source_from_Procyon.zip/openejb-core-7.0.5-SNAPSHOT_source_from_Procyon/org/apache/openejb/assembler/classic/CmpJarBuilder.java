// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.util.UrlCache;
import org.apache.openejb.loader.IO;
import org.apache.openejb.util.Logger;
import org.apache.openejb.util.LogCategory;
import java.util.zip.ZipEntry;
import java.util.jar.JarEntry;
import java.util.StringTokenizer;
import org.apache.openejb.core.cmp.cmp2.CmrField;
import org.apache.openejb.core.cmp.cmp2.Cmp2Generator;
import org.apache.openejb.core.cmp.cmp2.Cmp1Generator;
import org.apache.openejb.core.cmp.CmpUtil;
import java.util.Iterator;
import java.util.Map;
import java.util.jar.JarOutputStream;
import java.util.HashMap;
import java.io.IOException;
import org.apache.openejb.ClassLoaderUtil;
import java.util.TreeSet;
import java.util.Set;
import java.io.File;

public class CmpJarBuilder
{
    private final ClassLoader tempClassLoader;
    private File jarFile;
    private final Set<String> entries;
    private final AppInfo appInfo;
    
    public CmpJarBuilder(final AppInfo appInfo, final ClassLoader classLoader) {
        this.entries = new TreeSet<String>();
        this.appInfo = appInfo;
        this.tempClassLoader = ClassLoaderUtil.createTempClassLoader(classLoader);
    }
    
    public File getJarFile() throws IOException {
        if (this.jarFile == null) {
            this.generate();
        }
        return this.jarFile;
    }
    
    private void generate() throws IOException {
        if (!this.hasCmpBeans()) {
            return;
        }
        JarOutputStream jarOutputStream = null;
        try {
            jarOutputStream = openJarFile(this);
            final Map<String, Entry> classes = new HashMap<String, Entry>();
            for (final EjbJarInfo ejbJar : this.appInfo.ejbJars) {
                for (final EnterpriseBeanInfo beanInfo : ejbJar.enterpriseBeans) {
                    if (beanInfo instanceof EntityBeanInfo) {
                        final EntityBeanInfo entityBeanInfo = (EntityBeanInfo)beanInfo;
                        if (!"CONTAINER".equalsIgnoreCase(entityBeanInfo.persistenceType)) {
                            continue;
                        }
                        final Entry entry = this.generateClass(jarOutputStream, entityBeanInfo);
                        classes.put(entry.clazz, entry);
                    }
                }
            }
            for (final Entry e : classes.values()) {
                this.addJarEntry(jarOutputStream, e.name, e.bytes);
            }
            if (this.appInfo.cmpMappingsXml != null) {
                this.addJarEntry(jarOutputStream, "META-INF/openejb-cmp-generated-orm.xml", this.appInfo.cmpMappingsXml.getBytes());
            }
        }
        catch (Throwable e2) {
            if (null != this.jarFile && !this.jarFile.delete()) {
                this.jarFile.deleteOnExit();
            }
            this.jarFile = null;
            throw new IOException("CmpJarBuilder.generate()", e2);
        }
        finally {
            this.close(jarOutputStream);
        }
    }
    
    private boolean hasCmpBeans() {
        for (final EjbJarInfo ejbJar : this.appInfo.ejbJars) {
            for (final EnterpriseBeanInfo beanInfo : ejbJar.enterpriseBeans) {
                if (beanInfo instanceof EntityBeanInfo) {
                    final EntityBeanInfo entityBeanInfo = (EntityBeanInfo)beanInfo;
                    if ("CONTAINER".equalsIgnoreCase(entityBeanInfo.persistenceType)) {
                        return true;
                    }
                    continue;
                }
            }
        }
        return false;
    }
    
    private Entry generateClass(final JarOutputStream jarOutputStream, final EntityBeanInfo entityBeanInfo) throws IOException {
        final String cmpImplClass = CmpUtil.getCmpImplClassName(entityBeanInfo.abstractSchemaName, entityBeanInfo.ejbClass);
        final String entryName = cmpImplClass.replace(".", "/") + ".class";
        if (this.entries.contains(entryName) || this.tempClassLoader.getResource(entryName) != null) {
            return null;
        }
        Class<?> beanClass = null;
        try {
            beanClass = this.tempClassLoader.loadClass(entityBeanInfo.ejbClass);
        }
        catch (ClassNotFoundException e) {
            throw (IOException)new IOException("Could not find entity bean class " + beanClass).initCause(e);
        }
        Class<?> primKeyClass = null;
        if (entityBeanInfo.primKeyClass != null) {
            try {
                primKeyClass = this.tempClassLoader.loadClass(entityBeanInfo.primKeyClass);
            }
            catch (ClassNotFoundException e2) {
                throw (IOException)new IOException("Could not find entity primary key class " + entityBeanInfo.primKeyClass).initCause(e2);
            }
        }
        byte[] bytes;
        if (entityBeanInfo.cmpVersion != 2) {
            final Cmp1Generator cmp1Generator = new Cmp1Generator(cmpImplClass, beanClass);
            if ("java.lang.Object".equals(entityBeanInfo.primKeyClass)) {
                cmp1Generator.setUnknownPk(true);
            }
            bytes = cmp1Generator.generate();
        }
        else {
            final Cmp2Generator cmp2Generator = new Cmp2Generator(cmpImplClass, beanClass, entityBeanInfo.primKeyField, primKeyClass, entityBeanInfo.cmpFieldNames.toArray(new String[entityBeanInfo.cmpFieldNames.size()]));
            for (final CmrFieldInfo cmrFieldInfo : entityBeanInfo.cmrFields) {
                final EntityBeanInfo roleSource = cmrFieldInfo.mappedBy.roleSource;
                final CmrField cmrField = new CmrField(cmrFieldInfo.fieldName, cmrFieldInfo.fieldType, CmpUtil.getCmpImplClassName(roleSource.abstractSchemaName, roleSource.ejbClass), roleSource.local, cmrFieldInfo.mappedBy.fieldName, cmrFieldInfo.synthetic);
                cmp2Generator.addCmrField(cmrField);
            }
            bytes = cmp2Generator.generate();
        }
        return new Entry(cmpImplClass, entryName, bytes);
    }
    
    private void addJarEntry(final JarOutputStream jarOutputStream, String fileName, final byte[] bytes) throws IOException {
        fileName = fileName.replace('\\', '/');
        String path = "";
        final StringTokenizer tokenizer = new StringTokenizer(fileName, "/");
        while (tokenizer.hasMoreTokens()) {
            final String part = tokenizer.nextToken();
            if (tokenizer.hasMoreTokens()) {
                path = path + part + "/";
                if (this.entries.contains(path)) {
                    continue;
                }
                jarOutputStream.putNextEntry(new JarEntry(path));
                jarOutputStream.closeEntry();
                this.entries.add(path);
            }
        }
        jarOutputStream.putNextEntry(new JarEntry(fileName));
        try {
            jarOutputStream.write(bytes);
        }
        finally {
            jarOutputStream.closeEntry();
            this.entries.add(fileName);
        }
    }
    
    private static synchronized JarOutputStream openJarFile(final CmpJarBuilder instance) throws IOException {
        if (instance.jarFile != null) {
            throw new IllegalStateException("Jar file exists already");
        }
        final File dir = tmpDir();
        try {
            instance.jarFile = File.createTempFile("OpenEJBGenerated.", ".jar", dir).getAbsoluteFile();
        }
        catch (Throwable e) {
            Logger.getInstance(LogCategory.OPENEJB_STARTUP, CmpJarBuilder.class).warning("Failed to create temp jar file in: " + dir, e);
            try {
                Thread.sleep(50L);
            }
            catch (InterruptedException ex) {}
            instance.jarFile = File.createTempFile("OpenEJBGenerated.", ".jar", dir).getAbsoluteFile();
        }
        Thread.yield();
        instance.jarFile.deleteOnExit();
        Logger.getInstance(LogCategory.OPENEJB_STARTUP, CmpJarBuilder.class).debug("Using temp jar file: " + instance.jarFile);
        return new JarOutputStream(IO.write(instance.jarFile));
    }
    
    private static File tmpDir() throws IOException {
        File dir = UrlCache.cacheDir;
        if (null == dir) {
            dir = SystemInstance.get().getBase().getDirectory("tmp", true);
        }
        return dir;
    }
    
    private void close(final JarOutputStream jarOutputStream) {
        if (jarOutputStream != null) {
            try {
                jarOutputStream.close();
            }
            catch (Throwable t) {}
        }
    }
    
    private static final class Entry
    {
        private final String clazz;
        private final String name;
        private final byte[] bytes;
        
        private Entry(final String clazz, final String name, final byte[] bytes) {
            this.clazz = clazz;
            this.name = name;
            this.bytes = bytes;
        }
    }
}
