// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.geronimo.connector.work.GeronimoWorkManager;
import javax.resource.spi.work.WorkContext;
import javax.transaction.TransactionSynchronizationRegistry;
import java.util.Timer;
import javax.resource.spi.XATerminator;
import javax.resource.spi.work.WorkManager;
import javax.resource.spi.BootstrapContext;

public class SimpleBootstrapContext implements BootstrapContext
{
    private final WorkManager workManager;
    private final XATerminator xaTerminator;
    
    public SimpleBootstrapContext(final WorkManager workManager) {
        this.workManager = workManager;
        this.xaTerminator = null;
    }
    
    public SimpleBootstrapContext(final WorkManager workManager, final XATerminator xaTerminator) {
        this.workManager = workManager;
        this.xaTerminator = xaTerminator;
    }
    
    public WorkManager getWorkManager() {
        return this.workManager;
    }
    
    public XATerminator getXATerminator() {
        return this.xaTerminator;
    }
    
    public Timer createTimer() {
        return new Timer(true);
    }
    
    public TransactionSynchronizationRegistry getTransactionSynchronizationRegistry() {
        if (this.xaTerminator != null && this.xaTerminator instanceof TransactionSynchronizationRegistry) {
            return (TransactionSynchronizationRegistry)this.xaTerminator;
        }
        return null;
    }
    
    public boolean isContextSupported(final Class<? extends WorkContext> cls) {
        if (this.workManager instanceof GeronimoWorkManager) {
            final GeronimoWorkManager geronimoWorkManager = (GeronimoWorkManager)this.workManager;
            return geronimoWorkManager.isContextSupported((Class)cls);
        }
        return false;
    }
}
