// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import java.util.Set;
import java.util.HashSet;
import java.util.Collection;
import java.lang.reflect.Method;
import org.apache.xbean.asm5.Type;

public enum CmrStyle
{
    SINGLE((Class)SingleValuedCmr.class, (Class)null, (Class)null), 
    COLLECTION((Class)SetValuedCmr.class, (Class)Collection.class, (Class)HashSet.class), 
    SET((Class)SetValuedCmr.class, (Class)Set.class, (Class)HashSet.class);
    
    private final Type accessorType;
    private final Type collectionType;
    private final Type intiCollectionType;
    private final String getterDescriptor;
    private final String setterDescriptor;
    private final String deletedDescriptor;
    
    private CmrStyle(final Class accessorClass, final Class collectionClass, final Class initCollectionClass) {
        this.accessorType = Type.getType(accessorClass);
        if (collectionClass != null) {
            this.collectionType = Type.getType(collectionClass);
            this.intiCollectionType = Type.getType(initCollectionClass);
        }
        else {
            this.collectionType = null;
            this.intiCollectionType = null;
        }
        String getterDescriptor = null;
        String setterDescriptor = null;
        String deletedDescriptor = null;
        for (final Method method : accessorClass.getMethods()) {
            if ("get".equals(method.getName())) {
                getterDescriptor = Type.getMethodDescriptor(method);
            }
            if ("set".equals(method.getName())) {
                setterDescriptor = Type.getMethodDescriptor(method);
            }
            if ("deleted".equals(method.getName())) {
                deletedDescriptor = Type.getMethodDescriptor(method);
            }
        }
        if (getterDescriptor == null) {
            throw new AssertionError((Object)("No get method found in cmr accessor class " + accessorClass.getName()));
        }
        if (setterDescriptor == null) {
            throw new AssertionError((Object)("No set method found in cmr accessor class " + accessorClass.getName()));
        }
        if (deletedDescriptor == null) {
            throw new AssertionError((Object)("No deleted method found in cmr accessor class " + accessorClass.getName()));
        }
        this.getterDescriptor = getterDescriptor;
        this.setterDescriptor = setterDescriptor;
        this.deletedDescriptor = deletedDescriptor;
    }
    
    public String getCmrFieldDescriptor(final Type relatedType) {
        final String relatedDescriptor = relatedType.getDescriptor();
        if (this.collectionType != null) {
            return this.collectionType.getDescriptor() + "<" + relatedDescriptor + ">";
        }
        return relatedDescriptor;
    }
    
    public Type getAccessorType() {
        return this.accessorType;
    }
    
    public Type getCollectionType() {
        return this.collectionType;
    }
    
    public Type getIntiCollectionType() {
        return this.intiCollectionType;
    }
    
    public String getGetterDescriptor() {
        return this.getterDescriptor;
    }
    
    public String getSetterDescriptor() {
        return this.setterDescriptor;
    }
    
    public String getDeletedDescriptor() {
        return this.deletedDescriptor;
    }
}
