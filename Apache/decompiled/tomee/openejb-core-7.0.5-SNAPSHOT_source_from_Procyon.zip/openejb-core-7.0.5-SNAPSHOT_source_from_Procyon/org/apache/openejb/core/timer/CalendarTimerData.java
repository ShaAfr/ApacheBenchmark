// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import org.apache.openejb.quartz.impl.triggers.AbstractTrigger;
import javax.ejb.TimerConfig;
import java.lang.reflect.Method;
import javax.ejb.ScheduleExpression;

public class CalendarTimerData extends TimerData
{
    private static final long serialVersionUID = 1L;
    private ScheduleExpression scheduleExpression;
    private boolean autoCreated;
    
    public CalendarTimerData(final long id, final EjbTimerServiceImpl timerService, final String deploymentId, final Object primaryKey, final Method timeoutMethod, final TimerConfig timerConfig, final ScheduleExpression scheduleExpression, final boolean auto) {
        super(id, timerService, deploymentId, primaryKey, timeoutMethod, timerConfig);
        this.scheduleExpression = scheduleExpression;
        this.autoCreated = auto;
    }
    
    @Override
    public TimerType getType() {
        return TimerType.Calendar;
    }
    
    public ScheduleExpression getSchedule() {
        return this.scheduleExpression;
    }
    
    public boolean isAutoCreated() {
        return this.autoCreated;
    }
    
    public AbstractTrigger<?> initializeTrigger() {
        try {
            return (AbstractTrigger<?>)new EJBCronTrigger(this.scheduleExpression);
        }
        catch (EJBCronTrigger.ParseException e) {
            throw new IllegalArgumentException("Fail to parse schedule expression " + this.scheduleExpression, e);
        }
    }
    
    private void writeObject(final ObjectOutputStream out) throws IOException {
        super.doWriteObject(out);
        out.writeBoolean(this.autoCreated);
        out.writeObject(this.scheduleExpression);
    }
    
    private void readObject(final ObjectInputStream in) throws IOException {
        super.doReadObject(in);
        this.autoCreated = in.readBoolean();
        try {
            this.scheduleExpression = ScheduleExpression.class.cast(in.readObject());
        }
        catch (ClassNotFoundException e) {
            throw new IOException(e);
        }
    }
    
    @Override
    public String toString() {
        return TimerType.Calendar.name() + " scheduleExpression = [" + this.scheduleExpression + "]";
    }
}
