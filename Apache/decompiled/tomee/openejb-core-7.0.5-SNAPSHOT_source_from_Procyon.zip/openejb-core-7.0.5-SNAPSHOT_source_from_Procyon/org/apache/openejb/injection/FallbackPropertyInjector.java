// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.injection;

import org.apache.openejb.Injection;

public interface FallbackPropertyInjector
{
    Object getValue(final Injection p0);
}
