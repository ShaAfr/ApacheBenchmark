// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import java.lang.instrument.ClassFileTransformer;

public interface PersistenceClassLoaderHandler
{
    void addTransformer(final String p0, final ClassLoader p1, final ClassFileTransformer p2);
    
    void destroy(final String p0);
    
    ClassLoader getNewTempClassLoader(final ClassLoader p0);
}
