// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import java.util.concurrent.ConcurrentHashMap;
import org.apache.openejb.util.LogCategory;
import javax.persistence.Query;
import javax.persistence.LockModeType;
import javax.persistence.FlushModeType;
import java.util.Set;
import java.util.Date;
import javax.persistence.TemporalType;
import java.util.Calendar;
import javax.persistence.Parameter;
import java.util.List;
import java.lang.reflect.Method;
import java.util.Map;
import org.apache.openejb.util.Logger;
import javax.persistence.TypedQuery;

public class CriteriaLogQuery<T> implements TypedQuery<T>
{
    private static final Logger LOGGER;
    private static final Map<Class<?>, Method> methodsCache;
    private static final Map<Class<?>, Class<?>> unwrapCache;
    private static final String GET_QUERY_STRING_MTD = "getQueryString";
    private final TypedQuery<T> delegate;
    private final String logLevel;
    
    public CriteriaLogQuery(final TypedQuery<T> query, final String level) {
        this.delegate = query;
        this.logLevel = level.toLowerCase();
    }
    
    private void logJPQLQuery() {
        final Class<?> clazz = this.delegate.getClass();
        Method mtd = CriteriaLogQuery.methodsCache.get(clazz);
        Class<?> unwrapQuery = CriteriaLogQuery.unwrapCache.get(clazz);
        if (mtd == null) {
            try {
                mtd = clazz.getMethod("getQueryString", (Class<?>[])new Class[0]);
            }
            catch (NoSuchMethodException e) {
                try {
                    unwrapQuery = clazz.getClassLoader().loadClass("org.hibernate.Query");
                    CriteriaLogQuery.unwrapCache.put(clazz, unwrapQuery);
                    mtd = unwrapQuery.getMethod("getQueryString", (Class<?>[])new Class[0]);
                }
                catch (Exception e2) {
                    try {
                        mtd = this.getClass().getMethod("getQueryString", (Class<?>[])new Class[0]);
                    }
                    catch (NoSuchMethodException ex) {}
                }
            }
            CriteriaLogQuery.methodsCache.put(clazz, mtd);
        }
        this.logJPQLQuery(unwrapQuery, mtd);
    }
    
    public String getQueryString() {
        return this.delegate.getClass().getName() + " doesn't support getQueryString() method: '" + this.delegate.toString() + "'";
    }
    
    private void logJPQLQuery(final Class<?> unwrap, final Method mtd) {
        String query = null;
        Object realQuery = this.delegate;
        if (unwrap != null) {
            realQuery = this.delegate.unwrap((Class)unwrap);
        }
        try {
            query = (String)mtd.invoke(realQuery, new Object[0]);
        }
        catch (Exception e) {
            try {
                query = this.getQueryString();
            }
            catch (Exception ex) {}
        }
        final String msg = "executing query '" + query + "'";
        if (this.logLevel.equals("info")) {
            CriteriaLogQuery.LOGGER.info(msg);
        }
        else if (this.logLevel.equals("debug") || this.logLevel.equals("fine") || this.logLevel.equals("finest")) {
            CriteriaLogQuery.LOGGER.debug(msg);
        }
        else if (this.logLevel.equals("error")) {
            CriteriaLogQuery.LOGGER.error(msg);
        }
        else if (this.logLevel.equals("fatal")) {
            CriteriaLogQuery.LOGGER.fatal(msg);
        }
        else if (this.logLevel.equals("warning") || this.logLevel.equals("warn")) {
            CriteriaLogQuery.LOGGER.warning(msg);
        }
        else {
            CriteriaLogQuery.LOGGER.debug(msg);
        }
    }
    
    public List<T> getResultList() {
        this.logJPQLQuery();
        return (List<T>)this.delegate.getResultList();
    }
    
    public T getSingleResult() {
        this.logJPQLQuery();
        return (T)this.delegate.getSingleResult();
    }
    
    public int executeUpdate() {
        this.logJPQLQuery();
        return this.delegate.executeUpdate();
    }
    
    public TypedQuery<T> setMaxResults(final int maxResult) {
        this.delegate.setMaxResults(maxResult);
        return (TypedQuery<T>)this;
    }
    
    public int getMaxResults() {
        return this.delegate.getMaxResults();
    }
    
    public TypedQuery<T> setFirstResult(final int startPosition) {
        this.delegate.setFirstResult(startPosition);
        return (TypedQuery<T>)this;
    }
    
    public int getFirstResult() {
        return this.delegate.getFirstResult();
    }
    
    public TypedQuery<T> setHint(final String hintName, final Object value) {
        this.delegate.setHint(hintName, value);
        return (TypedQuery<T>)this;
    }
    
    public <E> TypedQuery<T> setParameter(final Parameter<E> param, final E value) {
        this.delegate.setParameter((Parameter)param, (Object)value);
        return (TypedQuery<T>)this;
    }
    
    public Map<String, Object> getHints() {
        return (Map<String, Object>)this.delegate.getHints();
    }
    
    public TypedQuery<T> setParameter(final Parameter<Calendar> param, final Calendar value, final TemporalType temporalType) {
        this.delegate.setParameter((Parameter)param, value, temporalType);
        return (TypedQuery<T>)this;
    }
    
    public TypedQuery<T> setParameter(final Parameter<Date> param, final Date value, final TemporalType temporalType) {
        this.delegate.setParameter((Parameter)param, value, temporalType);
        return (TypedQuery<T>)this;
    }
    
    public TypedQuery<T> setParameter(final String name, final Object value) {
        this.delegate.setParameter(name, value);
        return (TypedQuery<T>)this;
    }
    
    public TypedQuery<T> setParameter(final String name, final Calendar value, final TemporalType temporalType) {
        this.delegate.setParameter(name, value, temporalType);
        return (TypedQuery<T>)this;
    }
    
    public TypedQuery<T> setParameter(final String name, final Date value, final TemporalType temporalType) {
        this.delegate.setParameter(name, value, temporalType);
        return (TypedQuery<T>)this;
    }
    
    public TypedQuery<T> setParameter(final int position, final Object value) {
        this.delegate.setParameter(position, value);
        return (TypedQuery<T>)this;
    }
    
    public TypedQuery<T> setParameter(final int position, final Calendar value, final TemporalType temporalType) {
        this.delegate.setParameter(position, value, temporalType);
        return (TypedQuery<T>)this;
    }
    
    public TypedQuery<T> setParameter(final int position, final Date value, final TemporalType temporalType) {
        this.delegate.setParameter(position, value, temporalType);
        return (TypedQuery<T>)this;
    }
    
    public Set<Parameter<?>> getParameters() {
        return (Set<Parameter<?>>)this.delegate.getParameters();
    }
    
    public Parameter<?> getParameter(final String name) {
        return (Parameter<?>)this.delegate.getParameter(name);
    }
    
    public <T> Parameter<T> getParameter(final String name, final Class<T> type) {
        return (Parameter<T>)this.delegate.getParameter(name, (Class)type);
    }
    
    public Parameter<?> getParameter(final int position) {
        return (Parameter<?>)this.delegate.getParameter(position);
    }
    
    public <T> Parameter<T> getParameter(final int position, final Class<T> type) {
        return (Parameter<T>)this.delegate.getParameter(position, (Class)type);
    }
    
    public boolean isBound(final Parameter<?> param) {
        return this.delegate.isBound((Parameter)param);
    }
    
    public <T> T getParameterValue(final Parameter<T> param) {
        return (T)this.delegate.getParameterValue((Parameter)param);
    }
    
    public Object getParameterValue(final String name) {
        return this.delegate.getParameterValue(name);
    }
    
    public Object getParameterValue(final int position) {
        return this.delegate.getParameterValue(position);
    }
    
    public TypedQuery<T> setFlushMode(final FlushModeType flushMode) {
        return (TypedQuery<T>)this.delegate.setFlushMode(flushMode);
    }
    
    public FlushModeType getFlushMode() {
        return this.delegate.getFlushMode();
    }
    
    public TypedQuery<T> setLockMode(final LockModeType lockMode) {
        return (TypedQuery<T>)this.delegate.setLockMode(lockMode);
    }
    
    public LockModeType getLockMode() {
        return this.delegate.getLockMode();
    }
    
    public <T> T unwrap(final Class<T> cls) {
        return (T)this.delegate.unwrap((Class)cls);
    }
    
    static {
        LOGGER = Logger.getInstance(LogCategory.OPENEJB_JPA, CriteriaLogQuery.class);
        methodsCache = new ConcurrentHashMap<Class<?>, Method>();
        unwrapCache = new ConcurrentHashMap<Class<?>, Class<?>>();
    }
}
