// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class InjectableInfo extends InfoObject
{
    public final List<InjectionInfo> targets;
    public String referenceName;
    public ReferenceLocationInfo location;
    
    public InjectableInfo() {
        this.targets = new ArrayList<InjectionInfo>();
    }
}
