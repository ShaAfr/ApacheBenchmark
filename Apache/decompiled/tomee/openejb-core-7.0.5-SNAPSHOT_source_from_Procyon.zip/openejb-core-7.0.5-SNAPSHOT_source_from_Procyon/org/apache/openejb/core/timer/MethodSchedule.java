// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import java.util.List;
import java.lang.reflect.Method;

public class MethodSchedule
{
    private final Method method;
    private final List<ScheduleData> schedules;
    
    public MethodSchedule(final Method method, final List<ScheduleData> schedules) {
        this.method = method;
        this.schedules = schedules;
    }
    
    public Method getMethod() {
        return this.method;
    }
    
    public List<ScheduleData> getSchedules() {
        return this.schedules;
    }
}
