// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.testing.rest;

import java.util.HashMap;
import java.util.Map;
import org.apache.openejb.rest.RESTResourceFinder;

public class ContextProvider implements RESTResourceFinder
{
    private final Map<Class<?>, Object> instances;
    private final RESTResourceFinder defaults;
    
    public ContextProvider() {
        this(null);
    }
    
    public ContextProvider(final RESTResourceFinder fallback) {
        this.instances = new HashMap<Class<?>, Object>();
        this.defaults = fallback;
    }
    
    @Override
    public <T> T find(final Class<T> clazz) {
        final Object obj = this.instances.get(clazz);
        if (obj == null) {
            return (this.defaults != null) ? this.defaults.find(clazz) : null;
        }
        return clazz.cast(obj);
    }
    
    public ContextProvider deregister(final Class<?> contextType) {
        this.instances.remove(contextType);
        return this;
    }
    
    public <T> ContextProvider register(final Class<T> contextType, final T instance) {
        this.instances.put(contextType, instance);
        return this;
    }
}
