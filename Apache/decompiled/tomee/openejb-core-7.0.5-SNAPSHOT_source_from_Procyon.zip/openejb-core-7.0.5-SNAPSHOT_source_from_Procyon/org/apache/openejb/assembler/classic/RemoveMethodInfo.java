// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class RemoveMethodInfo extends InfoObject
{
    public NamedMethodInfo beanMethod;
    public boolean retainIfException;
}
