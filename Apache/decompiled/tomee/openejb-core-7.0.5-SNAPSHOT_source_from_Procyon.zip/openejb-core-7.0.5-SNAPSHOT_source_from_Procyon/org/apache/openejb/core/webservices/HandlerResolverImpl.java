// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import org.apache.openejb.util.LogCategory;
import javax.xml.ws.handler.LogicalHandler;
import javax.xml.namespace.QName;
import org.apache.webbeans.container.BeanManagerImpl;
import javax.xml.ws.WebServiceException;
import javax.enterprise.inject.InjectionException;
import org.apache.webbeans.context.creational.CreationalContextImpl;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.context.spi.Contextual;
import java.util.Set;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import org.apache.openejb.util.AppFinder;
import org.apache.webbeans.config.WebBeansContext;
import java.util.Collections;
import javax.xml.ws.handler.PortInfo;
import java.util.Iterator;
import java.util.ArrayList;
import javax.xml.ws.handler.Handler;
import org.apache.openejb.InjectionProcessor;
import javax.naming.Context;
import org.apache.openejb.Injection;
import java.util.Collection;
import java.util.List;
import org.apache.openejb.util.Logger;
import javax.xml.ws.handler.HandlerResolver;

public class HandlerResolverImpl implements HandlerResolver
{
    private static final Logger LOGGER;
    private final List<HandlerChainData> handlerChains;
    private final Collection<Injection> injections;
    private final Context context;
    private final List<InjectionProcessor<Handler>> handlerInstances;
    
    public HandlerResolverImpl(final List<HandlerChainData> handlerChains, final Collection<Injection> injections, final Context context) {
        this.handlerInstances = new ArrayList<InjectionProcessor<Handler>>();
        this.handlerChains = handlerChains;
        this.injections = injections;
        this.context = context;
    }
    
    public void destroyHandlers() {
        final List<InjectionProcessor<Handler>> handlerInstances = new ArrayList<InjectionProcessor<Handler>>(this.handlerInstances);
        this.handlerInstances.clear();
        for (final InjectionProcessor<Handler> handlerInstance : handlerInstances) {
            handlerInstance.preDestroy();
        }
    }
    
    public List<Handler> getHandlerChain(final PortInfo portInfo) {
        List<Handler> chain = new ArrayList<Handler>();
        for (final HandlerChainData handlerChain : this.handlerChains) {
            List<Handler> handlers = this.buildHandlers(portInfo, handlerChain);
            handlers = this.sortHandlers(handlers);
            chain.addAll(handlers);
        }
        chain = this.sortHandlers(chain);
        return chain;
    }
    
    private List<Handler> buildHandlers(final PortInfo portInfo, final HandlerChainData handlerChain) {
        if (!this.matchServiceName(portInfo, handlerChain.getServiceNamePattern()) || !this.matchPortName(portInfo, handlerChain.getPortNamePattern()) || !this.matchBinding(portInfo, handlerChain.getProtocolBindings())) {
            return Collections.emptyList();
        }
        final List<Handler> handlers = new ArrayList<Handler>(handlerChain.getHandlers().size());
        for (final HandlerData handler : handlerChain.getHandlers()) {
            final WebBeansContext webBeansContext = AppFinder.findAppContextOrWeb(Thread.currentThread().getContextClassLoader(), AppFinder.WebBeansContextTransformer.INSTANCE);
            if (webBeansContext != null) {
                final BeanManagerImpl bm = webBeansContext.getBeanManagerImpl();
                if (bm.isInUse()) {
                    try {
                        final Set<Bean<?>> beans = (Set<Bean<?>>)bm.getBeans((Type)handler.getHandlerClass(), new Annotation[0]);
                        final Bean<?> bean = (Bean<?>)bm.resolve((Set)beans);
                        if (bean != null) {
                            final boolean normalScoped = bm.isNormalScope(bean.getScope());
                            final CreationalContextImpl<?> creationalContext = (CreationalContextImpl<?>)bm.createCreationalContext((Contextual)bean);
                            final Handler instance = Handler.class.cast(bm.getReference((Bean)bean, (Type)bean.getBeanClass(), (CreationalContext)creationalContext));
                            handlers.add(instance);
                            this.handlerInstances.add(new InjectionProcessor<Handler>(instance, Collections.emptySet(), null) {
                                @Override
                                public void preDestroy() {
                                    if (!normalScoped) {
                                        creationalContext.release();
                                    }
                                }
                            });
                            continue;
                        }
                    }
                    catch (InjectionException ie) {
                        HandlerResolverImpl.LOGGER.info(ie.getMessage(), (Throwable)ie);
                    }
                }
            }
            try {
                final Class<? extends Handler> handlerClass = handler.getHandlerClass().asSubclass(Handler.class);
                final InjectionProcessor<Handler> processor = new InjectionProcessor<Handler>(handlerClass, this.injections, handler.getPostConstruct(), handler.getPreDestroy(), InjectionProcessor.unwrap(this.context));
                processor.createInstance();
                processor.postConstruct();
                final Handler handlerInstance = processor.getInstance();
                handlers.add(handlerInstance);
                this.handlerInstances.add(processor);
            }
            catch (Exception e) {
                throw new WebServiceException("Failed to instantiate handler", (Throwable)e);
            }
        }
        return handlers;
    }
    
    private boolean matchServiceName(final PortInfo info, final QName namePattern) {
        return this.match((info == null) ? null : info.getServiceName(), namePattern);
    }
    
    private boolean matchPortName(final PortInfo info, final QName namePattern) {
        return this.match((info == null) ? null : info.getPortName(), namePattern);
    }
    
    private boolean matchBinding(final PortInfo info, final List bindings) {
        return this.match((info == null) ? null : info.getBindingID(), bindings);
    }
    
    private boolean match(final String binding, final List bindings) {
        if (binding == null) {
            return bindings == null || bindings.isEmpty();
        }
        if (bindings == null || bindings.isEmpty()) {
            return true;
        }
        final String actualBindingURI = JaxWsUtils.getBindingURI(binding);
        for (final String bindingToken : bindings) {
            final String bindingURI = JaxWsUtils.getBindingURI(bindingToken);
            if (actualBindingURI.equals(bindingURI)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean match(final QName name, final QName namePattern) {
        if (name == null) {
            return namePattern == null || namePattern.getLocalPart().equals("*");
        }
        if (namePattern == null) {
            return true;
        }
        if (namePattern.getNamespaceURI() != null && !name.getNamespaceURI().equals(namePattern.getNamespaceURI())) {
            return false;
        }
        String localNamePattern = namePattern.getLocalPart();
        if (localNamePattern.equals("*")) {
            return true;
        }
        if (localNamePattern.endsWith("*")) {
            localNamePattern = localNamePattern.substring(0, localNamePattern.length() - 1);
            return name.getLocalPart().startsWith(localNamePattern);
        }
        return name.getLocalPart().equals(localNamePattern);
    }
    
    private List<Handler> sortHandlers(final List<Handler> handlers) {
        final List<LogicalHandler> logicalHandlers = new ArrayList<LogicalHandler>();
        final List<Handler> protocolHandlers = new ArrayList<Handler>();
        for (final Handler handler : handlers) {
            if (handler instanceof LogicalHandler) {
                logicalHandlers.add((LogicalHandler)handler);
            }
            else {
                protocolHandlers.add(handler);
            }
        }
        final List<Handler> sortedHandlers = new ArrayList<Handler>();
        sortedHandlers.addAll((Collection<? extends Handler>)logicalHandlers);
        sortedHandlers.addAll(protocolHandlers);
        return sortedHandlers;
    }
    
    static {
        LOGGER = Logger.getInstance(LogCategory.OPENEJB_WS, HandlerResolverImpl.class);
    }
}
