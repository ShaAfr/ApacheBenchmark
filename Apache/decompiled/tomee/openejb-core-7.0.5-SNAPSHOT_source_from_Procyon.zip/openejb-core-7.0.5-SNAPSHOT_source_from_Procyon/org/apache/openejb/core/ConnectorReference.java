// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import javax.resource.ResourceException;
import javax.naming.NamingException;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ConnectionManager;
import org.apache.openejb.core.ivm.naming.Reference;

public class ConnectorReference extends Reference
{
    private final ConnectionManager conMngr;
    private final ManagedConnectionFactory mngedConFactory;
    
    public ConnectorReference(final ConnectionManager manager, final ManagedConnectionFactory factory) {
        this.conMngr = manager;
        this.mngedConFactory = factory;
    }
    
    @Override
    public Object getObject() throws NamingException {
        try {
            final Object connection = this.mngedConFactory.createConnectionFactory(this.conMngr);
            return connection;
        }
        catch (ResourceException re) {
            throw (NamingException)new NamingException("Could not create ConnectionFactory from " + this.mngedConFactory.getClass()).initCause((Throwable)re);
        }
    }
    
    public ConnectionManager getConnectionManager() {
        return this.conMngr;
    }
}
