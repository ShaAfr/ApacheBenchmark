// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.util.SetAccessible;
import java.lang.reflect.Modifier;
import javax.interceptor.InvocationContext;
import java.util.Set;
import java.util.HashSet;
import java.lang.reflect.Method;
import org.apache.openejb.BeanContext;
import java.util.Iterator;
import org.apache.openejb.OpenEJBException;
import java.util.Comparator;
import java.util.Collections;
import java.util.Collection;
import java.util.HashMap;
import org.apache.openejb.core.interceptor.InterceptorData;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import org.apache.openejb.util.Logger;

public class InterceptorBindingBuilder
{
    public static final Logger logger;
    private final List<InterceptorBindingInfo> packageAndClassBindings;
    private final ArrayList<InterceptorBindingInfo> bindings;
    private final Map<String, InterceptorData> interceptors;
    
    public InterceptorBindingBuilder(final ClassLoader cl, final EjbJarInfo ejbJarInfo) throws OpenEJBException {
        this.interceptors = new HashMap<String, InterceptorData>();
        Collections.sort(this.bindings = new ArrayList<InterceptorBindingInfo>(ejbJarInfo.interceptorBindings), new IntercpetorBindingComparator());
        Collections.reverse(this.bindings);
        this.packageAndClassBindings = new ArrayList<InterceptorBindingInfo>();
        for (final InterceptorBindingInfo binding : this.bindings) {
            final Level level = level(binding);
            if (level == Level.PACKAGE || level == Level.CLASS || level == Level.ANNOTATION_CLASS) {
                this.packageAndClassBindings.add(binding);
            }
        }
        for (final InterceptorInfo info : ejbJarInfo.interceptors) {
            Class<?> clazz = null;
            try {
                clazz = Class.forName(info.clazz, true, cl);
            }
            catch (ClassNotFoundException e) {
                throw new OpenEJBException("Interceptor class cannot be loaded: " + info.clazz);
            }
            final InterceptorData interceptor = new InterceptorData(clazz);
            this.toMethods(clazz, info.aroundInvoke, interceptor.getAroundInvoke());
            this.toMethods(clazz, info.postActivate, interceptor.getPostActivate());
            this.toMethods(clazz, info.prePassivate, interceptor.getPrePassivate());
            this.toMethods(clazz, info.postConstruct, interceptor.getPostConstruct());
            this.toMethods(clazz, info.preDestroy, interceptor.getPreDestroy());
            this.toMethods(clazz, info.afterBegin, interceptor.getAfterBegin());
            this.toMethods(clazz, info.beforeCompletion, interceptor.getBeforeCompletion());
            this.toMethods(clazz, info.afterCompletion, interceptor.getAfterCompletion());
            this.toMethods(clazz, info.aroundTimeout, interceptor.getAroundTimeout());
            this.interceptors.put(info.clazz, interceptor);
        }
    }
    
    public void build(final BeanContext beanContext, final EnterpriseBeanInfo beanInfo) {
        Class<?> clazz = (Class<?>)beanContext.getBeanClass();
        final InterceptorData beanAsInterceptor = new InterceptorData(clazz);
        if (beanInfo instanceof StatelessBeanInfo || beanInfo instanceof MessageDrivenBeanInfo) {
            final NamedMethodInfo info = new NamedMethodInfo();
            info.className = clazz.getName();
            final Method createMethod = beanContext.getCreateMethod();
            info.methodName = ((createMethod != null) ? createMethod.getName() : "ejbCreate");
            info.methodParams = new ArrayList<String>();
            try {
                final Method ejbcreate = MethodInfoUtil.toMethod(clazz, info);
                if (ejbcreate != null) {
                    final CallbackInfo ejbcreateAsPostConstruct = new CallbackInfo();
                    ejbcreateAsPostConstruct.className = ejbcreate.getDeclaringClass().getName();
                    ejbcreateAsPostConstruct.method = ejbcreate.getName();
                    beanInfo.postConstruct.add(ejbcreateAsPostConstruct);
                }
            }
            catch (IllegalStateException ex) {}
        }
        this.toMethods(clazz, beanInfo.aroundInvoke, beanAsInterceptor.getAroundInvoke());
        this.toCallback(clazz, beanInfo.postConstruct, beanAsInterceptor.getPostConstruct(), (Class<?>[])new Class[0]);
        this.toCallback(clazz, beanInfo.preDestroy, beanAsInterceptor.getPreDestroy(), (Class<?>[])new Class[0]);
        if (beanInfo instanceof StatefulBeanInfo) {
            final StatefulBeanInfo stateful = (StatefulBeanInfo)beanInfo;
            this.toCallback(clazz, stateful.postActivate, beanAsInterceptor.getPostActivate(), (Class<?>[])new Class[0]);
            this.toCallback(clazz, stateful.prePassivate, beanAsInterceptor.getPrePassivate(), (Class<?>[])new Class[0]);
            this.toCallback(clazz, stateful.afterBegin, beanAsInterceptor.getAfterBegin(), (Class<?>[])new Class[0]);
            this.toCallback(clazz, stateful.beforeCompletion, beanAsInterceptor.getBeforeCompletion(), (Class<?>[])new Class[0]);
            this.toCallback(clazz, stateful.afterCompletion, beanAsInterceptor.getAfterCompletion(), Boolean.TYPE);
        }
        else {
            this.toMethods(clazz, beanInfo.aroundTimeout, beanAsInterceptor.getAroundTimeout());
        }
        while (clazz != null && clazz != Object.class) {
            for (final Method method : clazz.getDeclaredMethods()) {
                final List<InterceptorData> methodInterceptors = this.createInterceptorDatas(method, beanInfo.ejbName, this.bindings);
                beanContext.setMethodInterceptors(method, methodInterceptors);
                beanContext.getMethodContext(method).setSelfInterception(beanAsInterceptor);
            }
            clazz = clazz.getSuperclass();
        }
        final List<InterceptorData> callbackInterceptorDatas = this.createInterceptorDatas(null, beanInfo.ejbName, this.packageAndClassBindings);
        callbackInterceptorDatas.add(beanAsInterceptor);
        beanContext.setCallbackInterceptors(callbackInterceptorDatas);
    }
    
    private List<InterceptorData> createInterceptorDatas(final Method method, final String ejbName, final List<InterceptorBindingInfo> bindings) {
        final List<InterceptorBindingInfo> methodBindings = this.processBindings(method, ejbName, bindings);
        Collections.reverse(methodBindings);
        final List<InterceptorData> methodInterceptors = new ArrayList<InterceptorData>();
        for (final InterceptorBindingInfo info : methodBindings) {
            final List<String> classes = (info.interceptorOrder.size() > 0) ? info.interceptorOrder : info.interceptors;
            for (final String interceptorClassName : classes) {
                final InterceptorData interceptorData = this.interceptors.get(interceptorClassName);
                if (interceptorData == null) {
                    InterceptorBindingBuilder.logger.warning("InterceptorBinding references non-existent (undeclared) interceptor: " + interceptorClassName);
                }
                else {
                    methodInterceptors.add(interceptorData);
                }
            }
        }
        return methodInterceptors;
    }
    
    private List<InterceptorBindingInfo> processBindings(final Method method, final String ejbName, final List<InterceptorBindingInfo> bindings) {
        final List<InterceptorBindingInfo> methodBindings = new ArrayList<InterceptorBindingInfo>();
        final Set<Level> excludes = new HashSet<Level>();
        for (final InterceptorBindingInfo info : bindings) {
            final Level level = level(info);
            if (!this.implies(method, ejbName, level, info)) {
                continue;
            }
            final Type type = type(level, info);
            if (type == Type.EXPLICIT_ORDERING && !excludes.contains(level)) {
                methodBindings.add(info);
                return methodBindings;
            }
            if (type == Type.SAME_AND_LOWER_EXCLUSION) {
                return methodBindings;
            }
            if (type == Type.SAME_LEVEL_EXCLUSION) {
                excludes.add(level);
            }
            if (!excludes.contains(level)) {
                methodBindings.add(info);
            }
            if (info.excludeClassInterceptors) {
                excludes.add(Level.CLASS);
                excludes.add(Level.ANNOTATION_CLASS);
            }
            if (!info.excludeDefaultInterceptors) {
                continue;
            }
            excludes.add(Level.PACKAGE);
        }
        return methodBindings;
    }
    
    private boolean implies(final Method method, final String ejbName, final Level level, final InterceptorBindingInfo info) {
        if (level == Level.PACKAGE) {
            return true;
        }
        if (!ejbName.equals(info.ejbName)) {
            return false;
        }
        if (level == Level.CLASS || level == Level.ANNOTATION_CLASS) {
            return true;
        }
        final NamedMethodInfo methodInfo = info.method;
        return MethodInfoUtil.matches(method, methodInfo);
    }
    
    private void toMethods(final Class<?> clazz, final List<CallbackInfo> callbackInfos, final Set<Method> callbacks) {
        final List<Method> methods = new ArrayList<Method>();
        for (final CallbackInfo callbackInfo : callbackInfos) {
            try {
                Method method = this.getMethod(clazz, callbackInfo.method, InvocationContext.class);
                if (callbackInfo.className == null && method.getDeclaringClass().equals(clazz) && !methods.contains(method)) {
                    methods.add(method);
                }
                if (method.getDeclaringClass().getName().equals(callbackInfo.className) && !methods.contains(method)) {
                    methods.add(method);
                }
                else {
                    Class<?> c;
                    for (c = clazz; c != null && !c.getName().equals(callbackInfo.className); c = c.getSuperclass()) {}
                    if (c == null) {
                        continue;
                    }
                    try {
                        method = this.getMethod(c, callbackInfo.method, InvocationContext.class);
                        if (!Modifier.isPrivate(method.getModifiers()) || methods.contains(method)) {
                            continue;
                        }
                        SetAccessible.on(method);
                        methods.add(method);
                    }
                    catch (NoSuchMethodException ex) {}
                }
            }
            catch (NoSuchMethodException e) {
                InterceptorBindingBuilder.logger.warning("Interceptor method not found (skipping): public Object " + callbackInfo.method + "(InvocationContext); in class " + clazz.getName());
            }
        }
        Collections.sort(methods, new MethodCallbackComparator());
        callbacks.addAll(methods);
    }
    
    private void toCallback(final Class<?> clazz, final List<CallbackInfo> callbackInfos, final Set<Method> callbacks, final Class<?>... parameterTypes) {
        final List<Method> methods = new ArrayList<Method>();
        for (final CallbackInfo callbackInfo : callbackInfos) {
            Class<?> usedClazz = clazz;
            if (clazz.isInterface() && !callbackInfo.className.equals(clazz.getName())) {
                try {
                    usedClazz = clazz.getClassLoader().loadClass(callbackInfo.className);
                }
                catch (ClassNotFoundException ex) {}
            }
            try {
                Method method = this.getMethod(usedClazz, callbackInfo.method, parameterTypes);
                if (callbackInfo.className == null && !methods.contains(method)) {
                    methods.add(method);
                }
                else if (method.getDeclaringClass().getName().equals(callbackInfo.className) && !methods.contains(method)) {
                    methods.add(method);
                }
                else {
                    Class<?> c;
                    for (c = clazz; c != null && !c.getName().equals(callbackInfo.className); c = c.getSuperclass()) {}
                    if (c == null) {
                        continue;
                    }
                    try {
                        method = c.getDeclaredMethod(callbackInfo.method, (Class<?>[])new Class[0]);
                        if (!Modifier.isPrivate(method.getModifiers()) || methods.contains(method)) {
                            continue;
                        }
                        SetAccessible.on(method);
                        methods.add(method);
                    }
                    catch (NoSuchMethodException ex2) {}
                }
            }
            catch (NoSuchMethodException e) {
                final String message = "Bean Callback method not found (skipping): public void " + callbackInfo.method + "(); in class " + clazz.getName();
                InterceptorBindingBuilder.logger.warning(message);
                throw new IllegalStateException(message, e);
            }
        }
        Collections.sort(methods, new MethodCallbackComparator());
        callbacks.addAll(methods);
    }
    
    private Method getMethod(Class<?> clazz, final String methodName, final Class<?>... parameterTypes) throws NoSuchMethodException {
        NoSuchMethodException original = null;
        while (clazz != null) {
            try {
                final Method method = clazz.getDeclaredMethod(methodName, parameterTypes);
                return SetAccessible.on(method);
            }
            catch (NoSuchMethodException e) {
                if (original == null) {
                    original = e;
                }
                clazz = clazz.getSuperclass();
                continue;
            }
            break;
        }
        throw original;
    }
    
    private static Level level(final InterceptorBindingInfo info) {
        if (info.ejbName.equals("*")) {
            return Level.PACKAGE;
        }
        if (info.method == null) {
            return (info.className == null) ? Level.CLASS : Level.ANNOTATION_CLASS;
        }
        if (info.method.methodParams == null) {
            return Level.OVERLOADED_METHOD;
        }
        return (info.className == null) ? Level.EXACT_METHOD : Level.ANNOTATION_METHOD;
    }
    
    private static Type type(final Level level, final InterceptorBindingInfo info) {
        if (info.interceptorOrder.size() > 0) {
            return Type.EXPLICIT_ORDERING;
        }
        if ((level == Level.CLASS || level == Level.ANNOTATION_CLASS) && info.excludeClassInterceptors && info.excludeDefaultInterceptors) {
            return Type.SAME_AND_LOWER_EXCLUSION;
        }
        if ((level == Level.CLASS || level == Level.ANNOTATION_CLASS) && info.excludeClassInterceptors) {
            return Type.SAME_LEVEL_EXCLUSION;
        }
        return Type.ADDITION_OR_LOWER_EXCLUSION;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, InterceptorBindingBuilder.class.getPackage().getName());
    }
    
    public enum Level
    {
        PACKAGE, 
        ANNOTATION_CLASS, 
        CLASS, 
        ANNOTATION_METHOD, 
        OVERLOADED_METHOD, 
        EXACT_METHOD;
    }
    
    public enum Type
    {
        ADDITION_OR_LOWER_EXCLUSION, 
        SAME_LEVEL_EXCLUSION, 
        SAME_AND_LOWER_EXCLUSION, 
        EXPLICIT_ORDERING;
    }
    
    public static class IntercpetorBindingComparator implements Comparator<InterceptorBindingInfo>
    {
        @Override
        public int compare(final InterceptorBindingInfo a, final InterceptorBindingInfo b) {
            final Level levelA = level(a);
            final Level levelB = level(b);
            if (levelA != levelB) {
                return levelA.ordinal() - levelB.ordinal();
            }
            return type(levelA, a).ordinal() - type(levelB, b).ordinal();
        }
    }
    
    public static class MethodCallbackComparator implements Comparator<Method>
    {
        @Override
        public int compare(final Method m1, final Method m2) {
            final Class<?> c1 = m1.getDeclaringClass();
            final Class<?> c2 = m2.getDeclaringClass();
            if (c1.equals(c2)) {
                return 0;
            }
            if (c1.isAssignableFrom(c2)) {
                return -1;
            }
            return 1;
        }
    }
}
