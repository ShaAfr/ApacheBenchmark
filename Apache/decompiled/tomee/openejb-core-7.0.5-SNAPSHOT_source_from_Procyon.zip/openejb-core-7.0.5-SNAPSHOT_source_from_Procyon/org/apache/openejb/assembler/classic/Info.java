// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.OpenEJBRuntimeException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import java.io.InputStream;
import java.io.Writer;
import javax.xml.bind.JAXBException;
import java.io.OutputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Info
{
    private static final JAXBContext JAXB_CONTEXT;
    public AppInfo appInfo;
    
    public Info(final AppInfo appInfo) {
        this.appInfo = appInfo;
    }
    
    public Info() {
    }
    
    public static void marshal(final AppInfo appInfo) throws JAXBException {
        marshal(appInfo, System.out);
    }
    
    public static void marshal(final AppInfo appInfo, final OutputStream out) throws JAXBException {
        marshaller().marshal((Object)new Info(appInfo), out);
    }
    
    public static void marshal(final AppInfo appInfo, final Writer out) throws JAXBException {
        marshaller().marshal((Object)new Info(appInfo), out);
    }
    
    public static AppInfo unmarshal(final InputStream in) throws JAXBException {
        return ((Info)unmarshaller().unmarshal(in)).appInfo;
    }
    
    private static Marshaller marshaller() throws JAXBException {
        final Marshaller marshaller = Info.JAXB_CONTEXT.createMarshaller();
        marshaller.setProperty("jaxb.formatted.output", (Object)true);
        return marshaller;
    }
    
    private static Unmarshaller unmarshaller() throws JAXBException {
        return Info.JAXB_CONTEXT.createUnmarshaller();
    }
    
    static {
        try {
            JAXB_CONTEXT = JAXBContext.newInstance(new Class[] { Info.class });
        }
        catch (JAXBException e) {
            throw new OpenEJBRuntimeException("can't create jaxbcontext for Info class");
        }
    }
}
