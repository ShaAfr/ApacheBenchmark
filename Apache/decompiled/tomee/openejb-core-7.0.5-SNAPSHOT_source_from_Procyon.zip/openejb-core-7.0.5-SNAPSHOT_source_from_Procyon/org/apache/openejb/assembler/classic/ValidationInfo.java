// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ValidationInfo extends InfoObject
{
    public String providerClassName;
    public String messageInterpolatorClass;
    public String traversableResolverClass;
    public String constraintFactoryClass;
    public String parameterNameProviderClass;
    public String version;
    public final Properties propertyTypes;
    public final List<String> constraintMappings;
    public boolean executableValidationEnabled;
    public final List<String> validatedTypes;
    
    public ValidationInfo() {
        this.propertyTypes = new Properties();
        this.constraintMappings = new ArrayList<String>();
        this.validatedTypes = new ArrayList<String>();
    }
}
