// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

public class EntityManagerAlreadyRegisteredException extends Exception
{
    public EntityManagerAlreadyRegisteredException() {
    }
    
    public EntityManagerAlreadyRegisteredException(final String message) {
        super(message);
    }
    
    public EntityManagerAlreadyRegisteredException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public EntityManagerAlreadyRegisteredException(final Throwable cause) {
        super(cause);
    }
}
