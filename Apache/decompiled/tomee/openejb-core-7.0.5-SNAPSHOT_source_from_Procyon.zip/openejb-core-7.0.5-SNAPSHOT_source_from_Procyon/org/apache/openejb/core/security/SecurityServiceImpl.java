// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security;

import java.util.concurrent.ConcurrentHashMap;
import javax.security.auth.login.LoginException;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import org.apache.openejb.core.security.jaas.UsernamePasswordCallbackHandler;
import java.util.UUID;
import java.net.URL;
import org.apache.openejb.util.JavaSecurityManagers;
import org.apache.xbean.finder.archive.FileArchive;
import org.apache.openejb.util.ConfUtils;
import org.apache.openejb.loader.SystemInstance;
import javax.security.auth.login.LoginContext;
import java.util.Map;

public class SecurityServiceImpl extends AbstractSecurityService
{
    private static final Map<Object, LoginContext> contexts;
    
    public SecurityServiceImpl() {
        this(AbstractSecurityService.autoJaccProvider());
    }
    
    public SecurityServiceImpl(final String jaccProviderClass) {
        super(jaccProviderClass);
        installJaas();
        try {
            this.login("", "");
        }
        catch (Throwable t) {}
    }
    
    protected static void installJaas() {
        final String path = SystemInstance.get().getOptions().get("java.security.auth.login.config", (String)null);
        if (path != null) {
            return;
        }
        final URL loginConfig = ConfUtils.getConfResource("login.config");
        JavaSecurityManagers.setSystemProperty("java.security.auth.login.config", FileArchive.decode(loginConfig.toExternalForm()));
    }
    
    public UUID login(String realmName, final String username, final String password) throws LoginException {
        if (realmName == null) {
            realmName = this.getRealmName();
        }
        final LoginContext context = new LoginContext(realmName, new UsernamePasswordCallbackHandler(username, password));
        context.login();
        final Subject subject = context.getSubject();
        final UUID token = this.registerSubject(subject);
        SecurityServiceImpl.contexts.put(token, context);
        return token;
    }
    
    @Override
    public void logout(final UUID securityIdentity) throws LoginException {
        final LoginContext context = SecurityServiceImpl.contexts.remove(securityIdentity);
        if (null == context) {
            throw new IllegalStateException("Unable to logout. Can not recover LoginContext.");
        }
        context.logout();
        super.logout(securityIdentity);
    }
    
    static {
        contexts = new ConcurrentHashMap<Object, LoginContext>();
    }
}
