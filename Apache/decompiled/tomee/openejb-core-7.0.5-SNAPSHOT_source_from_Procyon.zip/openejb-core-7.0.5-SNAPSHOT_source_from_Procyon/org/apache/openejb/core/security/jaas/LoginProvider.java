// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jaas;

import javax.security.auth.login.FailedLoginException;
import java.util.List;

public interface LoginProvider
{
    List<String> authenticate(final String p0, final String p1) throws FailedLoginException;
}
