// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import org.apache.xbean.naming.reference.SimpleReference;

public abstract class Reference extends SimpleReference
{
    public Object getContent() throws NamingException {
        return this.getObject();
    }
    
    public abstract Object getObject() throws NamingException;
}
