// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.spi;

import javax.transaction.TransactionManager;
import org.apache.openejb.OpenEJBException;
import java.util.Properties;

public interface Assembler
{
    void init(final Properties p0) throws OpenEJBException;
    
    void build() throws OpenEJBException;
    
    ContainerSystem getContainerSystem();
    
    TransactionManager getTransactionManager();
    
    SecurityService getSecurityService();
    
    void destroy();
}
