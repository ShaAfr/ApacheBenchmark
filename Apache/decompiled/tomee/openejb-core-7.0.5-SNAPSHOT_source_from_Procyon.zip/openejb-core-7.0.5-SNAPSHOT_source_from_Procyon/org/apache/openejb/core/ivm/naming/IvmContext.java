// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import java.util.Iterator;
import java.util.Vector;
import java.io.ObjectStreamException;
import java.io.NotSerializableException;
import org.apache.openejb.core.ivm.IntraVmCopyMonitor;
import java.io.PrintStream;
import org.apache.openejb.loader.SystemInstance;
import org.apache.xbean.naming.context.ContextUtil;
import javax.naming.NameParser;
import javax.naming.Binding;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.OperationNotSupportedException;
import javax.naming.NameAlreadyBoundException;
import java.util.Properties;
import java.io.InputStream;
import java.util.Enumeration;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.IOException;
import org.apache.openejb.loader.IO;
import java.net.URL;
import org.apache.openejb.util.JavaSecurityManagers;
import java.util.Set;
import org.apache.openejb.ClassLoaderUtil;
import java.util.StringTokenizer;
import java.util.HashSet;
import javax.naming.Name;
import javax.naming.CompositeName;
import javax.naming.LinkRef;
import org.apache.openejb.core.ivm.IntraVmProxy;
import javax.naming.NameNotFoundException;
import org.apache.openejb.core.ivm.naming.java.javaURLContextFactory;
import org.apache.openejb.core.ivm.naming.openejb.openejbURLContextFactory;
import javax.naming.NamingException;
import java.util.concurrent.ConcurrentHashMap;
import javax.naming.spi.ObjectFactory;
import java.util.Map;
import java.util.Hashtable;
import java.io.Serializable;
import javax.naming.Context;

public class IvmContext implements Context, Serializable
{
    private static final long serialVersionUID = -626353930051783641L;
    Hashtable<String, Object> myEnv;
    boolean readOnly;
    Map<String, Object> fastCache;
    static final String JNDI_EXCEPTION_ON_FAILED_WRITE = "openejb.jndiExceptionOnFailedWrite";
    public NameNode mynode;
    static ObjectFactory[] federatedFactories;
    
    public static IvmContext createRootContext() {
        return new IvmContext();
    }
    
    public IvmContext() {
        this(new NameNode(null, new ParsedName(""), null, null));
    }
    
    public IvmContext(final String nodeName) {
        this(new NameNode(null, new ParsedName(nodeName), null, null));
    }
    
    public IvmContext(final NameNode node) {
        this(node, false);
    }
    
    public IvmContext(final NameNode node, final boolean isReadOnly) {
        this.fastCache = new ConcurrentHashMap<String, Object>();
        this.mynode = node;
        this.readOnly = isReadOnly;
    }
    
    public IvmContext(final Hashtable<String, Object> environment) throws NamingException {
        this();
        if (environment == null) {
            throw new NamingException("Invalid Argument");
        }
        this.myEnv = (Hashtable<String, Object>)environment.clone();
    }
    
    @Override
    public Object lookup(final String compositName) throws NamingException {
        if (compositName.equals("")) {
            return this;
        }
        final int index = compositName.indexOf(":");
        if (index > -1) {
            final String prefix = compositName.substring(0, index);
            String path = compositName.substring(index + 1);
            final ParsedName name = new ParsedName(path);
            if (prefix.equals("openejb")) {
                path = name.path();
                return openejbURLContextFactory.getContext().lookup(path);
            }
            if (!prefix.equals("java")) {
                throw new NamingException("Unknown JNDI name prefix '" + prefix + ":'");
            }
            if (name.getComponent().equals("openejb")) {
                path = name.remaining().path();
                return openejbURLContextFactory.getContext().lookup(path);
            }
            path = name.path();
            return javaURLContextFactory.getContext().lookup(path);
        }
        else {
            final String compoundName = this.mynode.getAtomicName() + '/' + compositName;
            Object obj = this.fastCache.get(compoundName);
            if (obj == null) {
                try {
                    obj = this.mynode.resolve(new ParsedName(compoundName), this.readOnly);
                }
                catch (NameNotFoundException nnfe) {
                    obj = this.federate(compositName);
                }
                if (!(obj instanceof IntraVmProxy) && !(obj instanceof ContextualJndiReference)) {
                    this.fastCache.put(compoundName, obj);
                }
            }
            if (obj == null) {
                throw new NameNotFoundException("Name \"" + compositName + "\" not found.");
            }
            if (obj.getClass() == IvmContext.class) {
                ((IvmContext)obj).myEnv = this.myEnv;
            }
            else if (obj instanceof Reference) {
                obj = ((Reference)obj).getObject();
            }
            else if (obj instanceof LinkRef) {
                obj = this.lookup(((LinkRef)obj).getLinkName());
            }
            return obj;
        }
    }
    
    protected Object federate(final String compositName) throws NamingException {
        final ObjectFactory[] federatedFactories;
        final ObjectFactory[] factories = federatedFactories = getFederatedFactories();
        for (final ObjectFactory factory : federatedFactories) {
            try {
                final CompositeName name = new CompositeName(compositName);
                final Object obj = factory.getObjectInstance(null, name, null, null);
                if (obj instanceof Context) {
                    return ((Context)obj).lookup(compositName);
                }
                if (obj != null) {
                    return obj;
                }
            }
            catch (Exception ex) {}
        }
        throw new NameNotFoundException("Name \"" + compositName + "\" not found.");
    }
    
    public static ObjectFactory[] getFederatedFactories() throws NamingException {
        if (IvmContext.federatedFactories == null) {
            final Set<ObjectFactory> factories = new HashSet<ObjectFactory>();
            final String urlPackagePrefixes = getUrlPackagePrefixes();
            if (urlPackagePrefixes == null) {
                return new ObjectFactory[0];
            }
            final StringTokenizer tokenizer = new StringTokenizer(urlPackagePrefixes, ":");
            while (tokenizer.hasMoreTokens()) {
                final String urlPackagePrefix = tokenizer.nextToken();
                final String className = urlPackagePrefix + ".java.javaURLContextFactory";
                if (className.equals("org.apache.openejb.core.ivm.naming.java.javaURLContextFactory")) {
                    continue;
                }
                try {
                    final ClassLoader cl = ClassLoaderUtil.getContextClassLoader();
                    final Class factoryClass = Class.forName(className, true, cl);
                    final ObjectFactory factoryInstance = factoryClass.newInstance();
                    factories.add(factoryInstance);
                }
                catch (ClassNotFoundException ex) {}
                catch (Throwable e) {
                    final NamingException ne = new NamingException("Federation failed: Cannot instantiate " + className);
                    ne.setRootCause(e);
                    throw ne;
                }
            }
            final Object[] temp = factories.toArray();
            System.arraycopy(temp, 0, IvmContext.federatedFactories = new ObjectFactory[temp.length], 0, IvmContext.federatedFactories.length);
        }
        return IvmContext.federatedFactories;
    }
    
    private static String getUrlPackagePrefixes() {
        String urlPackagePrefixes = JavaSecurityManagers.getSystemProperty("java.naming.factory.url.pkgs");
        if (urlPackagePrefixes == null) {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            if (classLoader == null) {
                classLoader = ClassLoader.getSystemClassLoader();
            }
            try {
                InputStream in;
                for (Enumeration<URL> resources = classLoader.getResources("jndi.properties"); urlPackagePrefixes == null && resources.hasMoreElements(); urlPackagePrefixes = getUrlPackagePrefixes(in)) {
                    final URL resource = resources.nextElement();
                    in = IO.read(resource);
                }
            }
            catch (IOException ex) {}
        }
        if (urlPackagePrefixes == null) {
            final String javahome = JavaSecurityManagers.getSystemProperty("java.home");
            if (javahome != null) {
                InputStream in2 = null;
                try {
                    final File propertiesFile = new File(new File(javahome, "lib"), "jndi.properties");
                    in2 = IO.read(propertiesFile);
                    urlPackagePrefixes = getUrlPackagePrefixes(in2);
                }
                catch (FileNotFoundException ex2) {}
                finally {
                    IO.close((Closeable)in2);
                }
            }
        }
        return urlPackagePrefixes;
    }
    
    private static String getUrlPackagePrefixes(final InputStream in) {
        try {
            final Properties properties = IO.readProperties(in, new Properties());
            return properties.getProperty("java.naming.factory.url.pkgs");
        }
        catch (IOException e) {
            return null;
        }
    }
    
    @Override
    public Object lookup(final Name compositName) throws NamingException {
        return this.lookup(compositName.toString());
    }
    
    @Override
    public void bind(String name, final Object obj) throws NamingException {
        if (this.checkReadOnly()) {
            return;
        }
        final int indx = name.indexOf(":");
        if (indx > -1) {
            name = name.substring(indx + 1);
        }
        if (this.fastCache.containsKey(name)) {
            throw new NameAlreadyBoundException();
        }
        final ParsedName parsedName = this.getParsedNameFor(name);
        this.mynode.bind(parsedName, obj);
    }
    
    private ParsedName getParsedNameFor(final String name) {
        return new ParsedName(this.mynode.getAtomicName() + "/" + name);
    }
    
    @Override
    public void bind(final Name name, final Object obj) throws NamingException {
        this.bind(name.toString(), obj);
    }
    
    @Override
    public void rebind(final String name, final Object obj) throws NamingException {
        try {
            this.unbind(name);
        }
        catch (NameNotFoundException ex) {}
        this.bind(name, obj);
    }
    
    @Override
    public void rebind(final Name name, final Object obj) throws NamingException {
        this.rebind(name.toString(), obj);
    }
    
    @Override
    public void unbind(String name) throws NamingException {
        if (this.checkReadOnly()) {
            return;
        }
        final int indx = name.indexOf(":");
        if (indx > -1) {
            name = name.substring(indx + 1);
        }
        this.fastCache.clear();
        this.mynode.clearCache();
        this.mynode.unbind(this.getParsedNameFor(name));
    }
    
    @Override
    public void unbind(final Name name) throws NamingException {
        this.unbind(name.toString());
    }
    
    public void prune(final String name) throws NamingException {
        final IvmContext ctx = (IvmContext)this.lookup(name);
        ctx.prune();
    }
    
    public void prune() throws NamingException {
        this.mynode.prune();
    }
    
    @Override
    public void rename(final String oldname, final String newname) throws NamingException {
        throw new OperationNotSupportedException();
    }
    
    @Override
    public void rename(final Name oldname, final Name newname) throws NamingException {
        this.rename(oldname.toString(), newname.toString());
    }
    
    @Override
    public NamingEnumeration<NameClassPair> list(final String name) throws NamingException {
        final Object obj = this.lookup(name);
        if (obj.getClass() == IvmContext.class) {
            return (NamingEnumeration<NameClassPair>)new MyListEnumeration(((IvmContext)obj).mynode);
        }
        return null;
    }
    
    @Override
    public NamingEnumeration<NameClassPair> list(final Name name) throws NamingException {
        return this.list(name.toString());
    }
    
    @Override
    public NamingEnumeration<Binding> listBindings(final String name) throws NamingException {
        final Object obj = this.lookup(name);
        if (obj.getClass() == IvmContext.class) {
            return (NamingEnumeration<Binding>)new MyBindingEnumeration(((IvmContext)obj).mynode);
        }
        return null;
    }
    
    @Override
    public NamingEnumeration<Binding> listBindings(final Name name) throws NamingException {
        return this.listBindings(name.toString());
    }
    
    @Override
    public void destroySubcontext(final String name) throws NamingException {
        throw new OperationNotSupportedException();
    }
    
    @Override
    public void destroySubcontext(final Name name) throws NamingException {
        this.destroySubcontext(name.toString());
    }
    
    @Override
    public Context createSubcontext(String name) throws NamingException {
        if (this.checkReadOnly()) {
            return null;
        }
        final int indx = name.indexOf(":");
        if (indx > -1) {
            name = name.substring(indx + 1);
        }
        if (this.fastCache.containsKey(name)) {
            throw new NameAlreadyBoundException();
        }
        return this.mynode.createSubcontext(this.getParsedNameFor(name), this.readOnly);
    }
    
    @Override
    public Context createSubcontext(final Name name) throws NamingException {
        return this.createSubcontext(name.toString());
    }
    
    @Override
    public Object lookupLink(final String name) throws NamingException {
        return this.lookup(name);
    }
    
    @Override
    public Object lookupLink(final Name name) throws NamingException {
        return this.lookupLink(name.toString());
    }
    
    @Override
    public NameParser getNameParser(final String name) throws NamingException {
        return ContextUtil.NAME_PARSER;
    }
    
    @Override
    public NameParser getNameParser(final Name name) throws NamingException {
        return this.getNameParser(name.toString());
    }
    
    @Override
    public String composeName(final String name, final String prefix) throws NamingException {
        final Name result = this.composeName(new CompositeName(name), new CompositeName(prefix));
        return result.toString();
    }
    
    @Override
    public Name composeName(final Name name, final Name prefix) throws NamingException {
        final Name result = (Name)prefix.clone();
        result.addAll(name);
        return result;
    }
    
    @Override
    public Object addToEnvironment(final String propName, final Object propVal) throws NamingException {
        if (this.myEnv == null) {
            this.myEnv = new Hashtable<String, Object>(5);
        }
        return this.myEnv.put(propName, propVal);
    }
    
    @Override
    public Object removeFromEnvironment(final String propName) throws NamingException {
        if (this.myEnv == null) {
            return null;
        }
        return this.myEnv.remove(propName);
    }
    
    @Override
    public Hashtable getEnvironment() throws NamingException {
        if (this.myEnv == null) {
            return new Hashtable(3);
        }
        return (Hashtable)this.myEnv.clone();
    }
    
    @Override
    public String getNameInNamespace() throws NamingException {
        return "";
    }
    
    @Override
    public void close() throws NamingException {
        this.checkReadOnly();
    }
    
    protected boolean checkReadOnly() throws OperationNotSupportedException {
        if (!this.readOnly) {
            return false;
        }
        if ("true".equals(SystemInstance.get().getProperty("openejb.jndiExceptionOnFailedWrite", "true"))) {
            throw new OperationNotSupportedException();
        }
        return true;
    }
    
    public void setReadOnly(final boolean isReadOnly) {
        this.readOnly = isReadOnly;
        if (this.mynode != null) {
            this.mynode.setReadOnly(this.readOnly);
        }
    }
    
    public void tree(final PrintStream out) {
        this.mynode.tree("", out);
    }
    
    @Override
    public String toString() {
        return "IvmContext{mynode=" + this.mynode.getAtomicName() + '}';
    }
    
    protected Object writeReplace() throws ObjectStreamException {
        if (IntraVmCopyMonitor.isStatefulPassivationOperation()) {
            return new JndiEncArtifact(this);
        }
        if (IntraVmCopyMonitor.isCrossClassLoaderOperation()) {
            return new JndiEncArtifact(this);
        }
        throw new NotSerializableException("IntraVM java.naming.Context objects can not be passed as arguments");
    }
    
    protected class MyBindingEnumeration extends MyNamingEnumeration
    {
        public MyBindingEnumeration(final NameNode parentNode) {
            super(parentNode);
        }
        
        @Override
        protected void buildEnumeration(final Vector vect) {
            for (int i = 0; i < vect.size(); ++i) {
                final NameNode node = vect.elementAt(i);
                final String className = node.getBinding().getClass().getName();
                vect.setElementAt(new Binding(node.getAtomicName(), className, node.getBinding()), i);
            }
            this.myEnum = vect.elements();
        }
    }
    
    protected class MyListEnumeration extends MyNamingEnumeration
    {
        public MyListEnumeration(final NameNode parentNode) {
            super(parentNode);
        }
        
        @Override
        protected void buildEnumeration(final Vector vect) {
            for (int i = 0; i < vect.size(); ++i) {
                final NameNode node = vect.elementAt(i);
                final String className = node.getBinding().getClass().getName();
                vect.setElementAt(new NameClassPair(node.getAtomicName(), className), i);
            }
            this.myEnum = vect.elements();
        }
    }
    
    protected abstract class MyNamingEnumeration implements NamingEnumeration
    {
        Enumeration myEnum;
        
        public MyNamingEnumeration(final NameNode parentNode) {
            final Vector vect = new Vector();
            NameNode node = parentNode.getSubTree();
            if (node == null) {
                node = parentNode;
            }
            else {
                vect.addElement(node);
            }
            this.gatherNodes(parentNode, node, vect);
            this.buildEnumeration(vect);
        }
        
        protected abstract void buildEnumeration(final Vector<NameNode> p0);
        
        protected void gatherNodes(final NameNode initiallyRequestedNode, final NameNode node, final Vector vect) {
            this.addInListIfNeeded(initiallyRequestedNode, node.getLessTree(), vect);
            this.addInListIfNeeded(initiallyRequestedNode, node.getGrtrTree(), vect);
            this.addInListIfNeeded(initiallyRequestedNode, node.getSubTree(), vect);
            if (NameNode.Federation.class.isInstance(initiallyRequestedNode.getObject())) {
                for (final Context c : NameNode.Federation.class.cast(initiallyRequestedNode.getObject())) {
                    if (c != IvmContext.this) {
                        if (!IvmContext.class.isInstance(c)) {
                            continue;
                        }
                        final IvmContext ctx = IvmContext.class.cast(c);
                        if (ctx.mynode == node) {
                            continue;
                        }
                        if (vect.contains(ctx.mynode)) {
                            continue;
                        }
                        this.addInListIfNeeded(ctx.mynode, ctx.mynode.getGrtrTree(), vect);
                        this.addInListIfNeeded(ctx.mynode, ctx.mynode.getLessTree(), vect);
                        this.addInListIfNeeded(ctx.mynode, ctx.mynode.getSubTree(), vect);
                    }
                }
            }
        }
        
        private void addInListIfNeeded(final NameNode parent, final NameNode node, final Vector vect) {
            if (node == null || vect.contains(node) || !this.isMyChild(parent, node)) {
                return;
            }
            vect.addElement(node);
            this.gatherNodes(parent, node, vect);
        }
        
        private boolean isMyChild(final NameNode parent, final NameNode node) {
            return node.getParent() == parent || (null == node.getParent() && null == parent.getParentTree());
        }
        
        @Override
        public void close() {
            this.myEnum = null;
        }
        
        @Override
        public boolean hasMore() {
            return this.hasMoreElements();
        }
        
        @Override
        public Object next() {
            return this.nextElement();
        }
        
        @Override
        public boolean hasMoreElements() {
            return this.myEnum.hasMoreElements();
        }
        
        @Override
        public Object nextElement() {
            return this.myEnum.nextElement();
        }
    }
}
