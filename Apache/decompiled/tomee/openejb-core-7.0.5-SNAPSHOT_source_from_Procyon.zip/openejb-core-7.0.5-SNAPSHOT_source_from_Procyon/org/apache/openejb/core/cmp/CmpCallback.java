// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import javax.ejb.RemoveException;
import javax.ejb.EntityBean;

public interface CmpCallback
{
    void setEntityContext(final EntityBean p0);
    
    void unsetEntityContext(final EntityBean p0);
    
    void ejbActivate(final EntityBean p0);
    
    void ejbPassivate(final EntityBean p0);
    
    void ejbLoad(final EntityBean p0);
    
    void ejbStore(final EntityBean p0);
    
    void ejbRemove(final EntityBean p0) throws RemoveException;
}
