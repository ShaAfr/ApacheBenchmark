// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.OpenEJB;

public interface ParentClassLoaderFinder
{
    public static final ClassLoader FALLBACK = OpenEJB.class.getClassLoader();
    
    ClassLoader getParentClassLoader(final ClassLoader p0);
    
    public static class Helper
    {
        public static ClassLoader get() {
            final ParentClassLoaderFinder parentFinder = SystemInstance.isInitialized() ? ((ParentClassLoaderFinder)SystemInstance.get().getComponent((Class)ParentClassLoaderFinder.class)) : null;
            if (parentFinder != null) {
                return parentFinder.getParentClassLoader(ParentClassLoaderFinder.FALLBACK);
            }
            return ParentClassLoaderFinder.FALLBACK;
        }
    }
}
