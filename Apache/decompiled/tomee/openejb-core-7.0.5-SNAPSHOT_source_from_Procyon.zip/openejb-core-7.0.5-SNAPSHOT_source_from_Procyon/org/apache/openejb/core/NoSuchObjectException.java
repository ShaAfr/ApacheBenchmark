// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.io.PrintWriter;
import java.io.PrintStream;

public class NoSuchObjectException extends java.rmi.NoSuchObjectException
{
    private Throwable cause;
    
    public NoSuchObjectException(final String detailMessage) {
        super(detailMessage);
        this.cause = this;
    }
    
    public NoSuchObjectException(final String detailMessage, final Throwable throwable) {
        super(detailMessage);
        this.cause = this;
        this.cause = throwable;
    }
    
    public NoSuchObjectException(final Throwable throwable) {
        super((throwable == null) ? null : throwable.toString());
        this.cause = this;
        this.cause = throwable;
    }
    
    @Override
    public String getLocalizedMessage() {
        return this.getMessage();
    }
    
    @Override
    public void printStackTrace() {
        this.printStackTrace(System.err);
    }
    
    private static int countDuplicates(final StackTraceElement[] currentStack, final StackTraceElement[] parentStack) {
        int duplicates = 0;
        int parentIndex = parentStack.length;
        int i = currentStack.length;
        while (--i >= 0 && --parentIndex >= 0) {
            final StackTraceElement parentFrame = parentStack[parentIndex];
            if (!parentFrame.equals(currentStack[i])) {
                break;
            }
            ++duplicates;
        }
        return duplicates;
    }
    
    @Override
    public void printStackTrace(final PrintStream err) {
        err.println(this.toString());
        final StackTraceElement[] stack = this.getStackTrace();
        for (int i = 0; i < stack.length; ++i) {
            err.println("\tat " + stack[i]);
        }
        StackTraceElement[] parentStack = stack;
        for (Throwable throwable = this.getCause(); throwable != null; throwable = throwable.getCause()) {
            err.print("Caused by: ");
            err.println(throwable);
            final StackTraceElement[] currentStack = throwable.getStackTrace();
            final int duplicates = countDuplicates(currentStack, parentStack);
            for (int j = 0; j < currentStack.length - duplicates; ++j) {
                err.println("\tat " + currentStack[j]);
            }
            if (duplicates > 0) {
                err.println("\t... " + duplicates + " more");
            }
            parentStack = currentStack;
        }
    }
    
    @Override
    public void printStackTrace(final PrintWriter err) {
        err.println(this.toString());
        final StackTraceElement[] stack = this.getStackTrace();
        for (int i = 0; i < stack.length; ++i) {
            err.println("\tat " + stack[i]);
        }
        StackTraceElement[] parentStack = stack;
        for (Throwable throwable = this.getCause(); throwable != null; throwable = throwable.getCause()) {
            err.print("Caused by: ");
            err.println(throwable);
            final StackTraceElement[] currentStack = throwable.getStackTrace();
            final int duplicates = countDuplicates(currentStack, parentStack);
            for (int j = 0; j < currentStack.length - duplicates; ++j) {
                err.println("\tat " + currentStack[j]);
            }
            if (duplicates > 0) {
                err.println("\t... " + duplicates + " more");
            }
            parentStack = currentStack;
        }
    }
    
    @Override
    public String toString() {
        final String msg = this.getLocalizedMessage();
        final String name = this.getClass().getName();
        if (msg == null) {
            return name;
        }
        return new StringBuilder(name.length() + 2 + msg.length()).append(name).append(": ").append(msg).toString();
    }
    
    @Override
    public synchronized NoSuchObjectException initCause(final Throwable throwable) {
        this.cause = throwable;
        return this;
    }
    
    @Override
    public Throwable getCause() {
        if (this.cause == this) {
            return null;
        }
        return this.cause;
    }
}
