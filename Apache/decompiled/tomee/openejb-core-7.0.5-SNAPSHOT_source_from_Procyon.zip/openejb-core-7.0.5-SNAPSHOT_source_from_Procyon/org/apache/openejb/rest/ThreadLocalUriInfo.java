// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.PathSegment;
import java.util.List;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import javax.ws.rs.core.UriInfo;

public class ThreadLocalUriInfo extends AbstractRestThreadLocalProxy<UriInfo> implements UriInfo
{
    protected ThreadLocalUriInfo() {
        super(UriInfo.class);
    }
    
    public URI getAbsolutePath() {
        return this.get().getAbsolutePath();
    }
    
    public UriBuilder getAbsolutePathBuilder() {
        return this.get().getAbsolutePathBuilder();
    }
    
    public URI getBaseUri() {
        return this.get().getBaseUri();
    }
    
    public UriBuilder getBaseUriBuilder() {
        return this.get().getBaseUriBuilder();
    }
    
    public String getPath() {
        return this.get().getPath();
    }
    
    public String getPath(final boolean decode) {
        return this.get().getPath(decode);
    }
    
    public List<PathSegment> getPathSegments() {
        return (List<PathSegment>)this.get().getPathSegments();
    }
    
    public List<PathSegment> getPathSegments(final boolean decode) {
        return (List<PathSegment>)this.get().getPathSegments(decode);
    }
    
    public MultivaluedMap<String, String> getQueryParameters() {
        return (MultivaluedMap<String, String>)this.get().getQueryParameters();
    }
    
    public MultivaluedMap<String, String> getQueryParameters(final boolean decode) {
        return (MultivaluedMap<String, String>)this.get().getQueryParameters(decode);
    }
    
    public URI getRequestUri() {
        return this.get().getRequestUri();
    }
    
    public UriBuilder getRequestUriBuilder() {
        return this.get().getRequestUriBuilder();
    }
    
    public MultivaluedMap<String, String> getPathParameters() {
        return (MultivaluedMap<String, String>)this.get().getPathParameters();
    }
    
    public MultivaluedMap<String, String> getPathParameters(final boolean decode) {
        return (MultivaluedMap<String, String>)this.get().getPathParameters(decode);
    }
    
    public List<Object> getMatchedResources() {
        return (List<Object>)this.get().getMatchedResources();
    }
    
    public URI resolve(final URI uri) {
        return this.get().resolve(uri);
    }
    
    public URI relativize(final URI uri) {
        return this.get().relativize(uri);
    }
    
    public List<String> getMatchedURIs() {
        return (List<String>)this.get().getMatchedURIs();
    }
    
    public List<String> getMatchedURIs(final boolean decode) {
        return (List<String>)this.get().getMatchedURIs(decode);
    }
}
