// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import javax.persistence.EntityManager;

public class PersistenceContextReference extends Reference
{
    private final EntityManager em;
    
    public PersistenceContextReference(final EntityManager em) {
        this.em = em;
    }
    
    @Override
    public Object getObject() throws NamingException {
        return this.em;
    }
}
