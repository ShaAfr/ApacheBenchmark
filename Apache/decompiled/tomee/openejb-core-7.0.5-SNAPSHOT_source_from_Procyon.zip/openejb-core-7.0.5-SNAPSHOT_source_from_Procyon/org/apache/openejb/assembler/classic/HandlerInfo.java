// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import javax.xml.namespace.QName;
import java.util.List;
import java.util.Properties;

public class HandlerInfo extends InfoObject
{
    public String handlerName;
    public String handlerClass;
    public final Properties initParams;
    public final List<QName> soapHeaders;
    public final List<String> soapRoles;
    
    public HandlerInfo() {
        this.initParams = new Properties();
        this.soapHeaders = new ArrayList<QName>();
        this.soapRoles = new ArrayList<String>();
    }
}
