// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class ServletInfo extends InfoObject
{
    public String servletName;
    public String servletClass;
    public String runAs;
    public List<String> mappings;
    public List<ParamValueInfo> initParams;
    
    public ServletInfo() {
        this.mappings = new ArrayList<String>();
        this.initParams = new ArrayList<ParamValueInfo>();
    }
}
