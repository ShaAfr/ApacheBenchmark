// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.classloader;

import java.util.Iterator;
import java.net.MalformedURLException;
import java.util.HashSet;
import org.apache.xbean.finder.filter.Filters;
import java.io.Closeable;
import org.apache.openejb.loader.IO;
import org.apache.openejb.util.Logger;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.loader.Files;
import java.util.Collection;
import java.util.Set;
import org.apache.openejb.loader.ProvisioningUtil;
import org.apache.openejb.util.PropertyPlaceHolderHelper;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.io.File;
import org.apache.openejb.util.URLs;
import org.apache.xbean.finder.filter.Filter;
import java.net.URL;

public class ProvisioningClassLoaderConfigurer implements ClassLoaderConfigurer
{
    private URL[] added;
    private Filter excluded;
    
    public ProvisioningClassLoaderConfigurer() {
        this.added = new URL[0];
        this.excluded = (Filter)FalseFilter.INSTANCE;
    }
    
    @Override
    public URL[] additionalURLs() {
        return this.added;
    }
    
    @Override
    public boolean accept(final URL url) {
        try {
            final File file = URLs.toFile(url);
            return !this.excluded.accept(file.getName());
        }
        catch (IllegalArgumentException iae) {
            return true;
        }
    }
    
    public void setConfiguration(final String configFile) {
        final Collection<URL> toAdd = new ArrayList<URL>();
        final Collection<String> toExclude = new ArrayList<String>();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(configFile));
            String line;
            while ((line = reader.readLine()) != null) {
                line = PropertyPlaceHolderHelper.SUBSTITUTOR.replace(line.trim());
                if (!line.startsWith("#")) {
                    if (line.isEmpty()) {
                        continue;
                    }
                    if (line.startsWith("-")) {
                        toExclude.add(line);
                    }
                    else {
                        if (line.startsWith("+")) {
                            line = line.substring(1);
                        }
                        String location = line;
                        String algo = "MD5";
                        String hash = null;
                        final boolean validJar = line.contains("|");
                        if (validJar) {
                            final String[] segments = line.split("|");
                            location = segments[0];
                            if (segments.length >= 2) {
                                hash = segments[1];
                            }
                            if (segments.length >= 3) {
                                algo = segments[2].trim();
                            }
                        }
                        final Set<URL> repos = toUrls(ProvisioningUtil.realLocation(location));
                        toAdd.addAll(repos);
                        if (!validJar) {
                            continue;
                        }
                        final String computedHash = Files.hash((Set)repos, algo);
                        if (!computedHash.equals(hash)) {
                            throw new IllegalStateException("Hash of " + location + "(" + computedHash + ") doesn't match expected one (" + hash + ")");
                        }
                        continue;
                    }
                }
            }
        }
        catch (Exception e) {
            Logger.getInstance(LogCategory.OPENEJB, ProvisioningClassLoaderConfigurer.class).error("Can't read " + configFile, e);
        }
        finally {
            IO.close((Closeable)reader);
        }
        this.added = toAdd.toArray(new URL[toAdd.size()]);
        if (toExclude.size() > 0) {
            this.excluded = Filters.prefixes((String[])toExclude.toArray(new String[toExclude.size()]));
        }
    }
    
    private static Set<URL> toUrls(final Set<String> strings) {
        final Set<URL> urls = new HashSet<URL>();
        for (final String s : strings) {
            try {
                urls.add(new File(s).toURI().toURL());
            }
            catch (MalformedURLException e) {
                throw new IllegalArgumentException(e);
            }
        }
        return urls;
    }
}
