// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.util.ArrayList;
import java.lang.reflect.Method;
import javax.xml.namespace.QName;
import java.util.List;
import java.util.Properties;

public class HandlerData
{
    private final Class<?> handlerClass;
    private final Properties initParams;
    private final List<QName> soapHeaders;
    private final List<String> soapRoles;
    private final List<Method> postConstruct;
    private final List<Method> preDestroy;
    
    public HandlerData(final Class<?> handlerClass) {
        this.initParams = new Properties();
        this.soapHeaders = new ArrayList<QName>();
        this.soapRoles = new ArrayList<String>();
        this.postConstruct = new ArrayList<Method>();
        this.preDestroy = new ArrayList<Method>();
        if (handlerClass == null) {
            throw new NullPointerException("handlerClass is null");
        }
        this.handlerClass = handlerClass;
    }
    
    public Properties getInitParams() {
        return this.initParams;
    }
    
    public List<QName> getSoapHeaders() {
        return this.soapHeaders;
    }
    
    public List<String> getSoapRoles() {
        return this.soapRoles;
    }
    
    public Class<?> getHandlerClass() {
        return this.handlerClass;
    }
    
    public List<Method> getPostConstruct() {
        return this.postConstruct;
    }
    
    public List<Method> getPreDestroy() {
        return this.preDestroy;
    }
}
