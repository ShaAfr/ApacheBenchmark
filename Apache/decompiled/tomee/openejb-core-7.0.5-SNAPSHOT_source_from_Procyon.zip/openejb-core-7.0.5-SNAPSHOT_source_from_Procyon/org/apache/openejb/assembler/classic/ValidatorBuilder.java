// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import javax.validation.ValidatorContext;
import javax.validation.Validator;
import javax.naming.NamingException;
import org.apache.openejb.bval.ValidatorUtil;
import java.util.LinkedList;
import java.io.Serializable;
import org.apache.openejb.util.LogCategory;
import org.apache.webbeans.container.BeanManagerImpl;
import javax.enterprise.inject.spi.InjectionTarget;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.context.spi.Contextual;
import javax.enterprise.inject.spi.AnnotatedType;
import org.apache.openejb.util.AppFinder;
import org.apache.webbeans.config.WebBeansContext;
import java.io.InputStream;
import javax.validation.ParameterNameProvider;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.TraversableResolver;
import javax.validation.MessageInterpolator;
import javax.validation.BootstrapConfiguration;
import java.util.Set;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import org.apache.openejb.loader.SystemInstance;
import javax.validation.Configuration;
import javax.validation.ValidationException;
import javax.validation.Validation;
import java.util.Iterator;
import org.apache.openejb.jee.bval.DefaultValidatedExecutableTypesType;
import org.apache.openejb.jee.bval.ExecutableValidationType;
import org.apache.openejb.jee.bval.PropertyType;
import javax.validation.executable.ExecutableType;
import org.apache.openejb.jee.bval.ValidationConfigType;
import javax.validation.ValidatorFactory;
import org.apache.openejb.util.Logger;

public final class ValidatorBuilder
{
    public static final Logger logger;
    public static final String VALIDATION_PROVIDER_KEY = "openejb.bean-validation.provider";
    
    private ValidatorBuilder() {
    }
    
    public static ValidatorFactory buildFactory(final ClassLoader classLoader, final ValidationInfo info) {
        return buildFactory(info, classLoader);
    }
    
    public static ValidationInfo getInfo(final ValidationConfigType config) {
        final ValidationInfo info = new ValidationInfo();
        if (config != null) {
            info.version = config.getVersion();
            info.providerClassName = config.getDefaultProvider();
            info.constraintFactoryClass = config.getConstraintValidatorFactory();
            info.traversableResolverClass = config.getTraversableResolver();
            info.messageInterpolatorClass = config.getMessageInterpolator();
            info.parameterNameProviderClass = config.getParameterNameProvider();
            final ExecutableValidationType executableValidation = config.getExecutableValidation();
            if (executableValidation != null) {
                info.executableValidationEnabled = executableValidation.getEnabled();
                final DefaultValidatedExecutableTypesType executableTypes = executableValidation.getDefaultValidatedExecutableTypes();
                if (executableTypes != null) {
                    for (final ExecutableType type : executableTypes.getExecutableType()) {
                        info.validatedTypes.add(type.name());
                    }
                }
            }
            for (final PropertyType p : config.getProperty()) {
                info.propertyTypes.put(p.getName(), p.getValue());
            }
            for (final String element : config.getConstraintMapping()) {
                info.constraintMappings.add(element);
            }
        }
        return info;
    }
    
    public static ValidatorFactory buildFactory(final ValidationInfo config, final ClassLoader classLoader) {
        ValidatorFactory factory = null;
        final Thread thread = Thread.currentThread();
        final ClassLoader oldContextLoader = thread.getContextClassLoader();
        try {
            thread.setContextClassLoader(classLoader);
            if (config == null) {
                factory = Validation.buildDefaultValidatorFactory();
            }
            else {
                final Configuration<?> configuration = getConfig(config);
                try {
                    factory = configuration.buildValidatorFactory();
                }
                catch (ValidationException ve) {
                    thread.setContextClassLoader(ValidatorBuilder.class.getClassLoader());
                    factory = Validation.buildDefaultValidatorFactory();
                    thread.setContextClassLoader(classLoader);
                    ValidatorBuilder.logger.warning("Unable create validator factory with config " + config + " (" + ve.getMessage() + "). Default factory will be used.");
                }
            }
        }
        finally {
            thread.setContextClassLoader(oldContextLoader);
        }
        return factory;
    }
    
    private static Configuration<?> getConfig(final ValidationInfo info) {
        Configuration<?> target = null;
        final Thread thread = Thread.currentThread();
        final ClassLoader classLoader = thread.getContextClassLoader();
        String providerClassName = info.providerClassName;
        if (providerClassName == null) {
            providerClassName = SystemInstance.get().getOptions().get("openejb.bean-validation.provider", (String)null);
        }
        if (providerClassName != null) {
            try {
                final Class clazz = classLoader.loadClass(providerClassName);
                target = (Configuration<?>)Validation.byProvider(clazz).configure();
                ValidatorBuilder.logger.info("Using " + providerClassName + " as validation provider.");
            }
            catch (ClassNotFoundException e) {
                ValidatorBuilder.logger.warning("Unable to load provider class " + providerClassName, e);
            }
            catch (ValidationException ve) {
                ValidatorBuilder.logger.warning("Unable create validator factory with provider " + providerClassName + " (" + ve.getMessage() + "). Default one will be used.");
            }
        }
        if (target == null) {
            thread.setContextClassLoader(ValidatorBuilder.class.getClassLoader());
            target = (Configuration<?>)Validation.byDefaultProvider().configure();
            thread.setContextClassLoader(classLoader);
        }
        final Set<ExecutableType> types = new HashSet<ExecutableType>();
        for (final String type : info.validatedTypes) {
            types.add(ExecutableType.valueOf(type));
        }
        final Map<String, String> props = new HashMap<String, String>();
        for (final Map.Entry<Object, Object> entry : info.propertyTypes.entrySet()) {
            final PropertyType property = new PropertyType();
            property.setName((String)entry.getKey());
            property.setValue((String)entry.getValue());
            props.put(property.getName(), property.getValue());
            if (ValidatorBuilder.logger.isDebugEnabled()) {
                ValidatorBuilder.logger.debug("Found property '" + property.getName() + "' with value '" + property.getValue());
            }
            target.addProperty(property.getName(), property.getValue());
        }
        final OpenEjbBootstrapConfig bootstrapConfig = new OpenEjbBootstrapConfig(providerClassName, info.constraintFactoryClass, info.messageInterpolatorClass, info.traversableResolverClass, info.parameterNameProviderClass, new HashSet<String>(info.constraintMappings), info.executableValidationEnabled, types, props);
        final OpenEjbConfig config = new OpenEjbConfig((BootstrapConfiguration)bootstrapConfig, (Configuration<T>)target);
        target.ignoreXmlConfiguration();
        final String messageInterpolatorClass = info.messageInterpolatorClass;
        if (messageInterpolatorClass != null) {
            try {
                final Class<MessageInterpolator> clazz2 = (Class<MessageInterpolator>)classLoader.loadClass(messageInterpolatorClass);
                target.messageInterpolator((MessageInterpolator)newInstance(config, clazz2));
            }
            catch (Exception e2) {
                ValidatorBuilder.logger.warning("Unable to set " + messageInterpolatorClass + " as message interpolator.", e2);
            }
            ValidatorBuilder.logger.info("Using " + messageInterpolatorClass + " as message interpolator.");
        }
        final String traversableResolverClass = info.traversableResolverClass;
        if (traversableResolverClass != null) {
            try {
                final Class<TraversableResolver> clazz3 = (Class<TraversableResolver>)classLoader.loadClass(traversableResolverClass);
                target.traversableResolver((TraversableResolver)newInstance(config, clazz3));
            }
            catch (Exception e3) {
                ValidatorBuilder.logger.warning("Unable to set " + traversableResolverClass + " as traversable resolver.", e3);
            }
            ValidatorBuilder.logger.info("Using " + traversableResolverClass + " as traversable resolver.");
        }
        final String constraintFactoryClass = info.constraintFactoryClass;
        if (constraintFactoryClass != null) {
            try {
                final Class<ConstraintValidatorFactory> clazz4 = (Class<ConstraintValidatorFactory>)classLoader.loadClass(constraintFactoryClass);
                target.constraintValidatorFactory((ConstraintValidatorFactory)newInstance(config, clazz4));
            }
            catch (Exception e4) {
                ValidatorBuilder.logger.warning("Unable to set " + constraintFactoryClass + " as constraint factory.", e4);
            }
            ValidatorBuilder.logger.info("Using " + constraintFactoryClass + " as constraint factory.");
        }
        for (final String mappingFileName : info.constraintMappings) {
            if (ValidatorBuilder.logger.isDebugEnabled()) {
                ValidatorBuilder.logger.debug("Opening input stream for " + mappingFileName);
            }
            final InputStream in = classLoader.getResourceAsStream(mappingFileName);
            if (in == null) {
                ValidatorBuilder.logger.warning("Unable to open input stream for mapping file " + mappingFileName + ". It will be ignored");
            }
            else {
                target.addMapping(in);
            }
        }
        if (info.parameterNameProviderClass != null) {
            try {
                final Class<ParameterNameProvider> clazz5 = (Class<ParameterNameProvider>)classLoader.loadClass(info.parameterNameProviderClass);
                target.parameterNameProvider((ParameterNameProvider)newInstance(config, clazz5));
            }
            catch (Exception e4) {
                ValidatorBuilder.logger.warning("Unable to set " + info.parameterNameProviderClass + " as parameter name provider.", e4);
            }
            ValidatorBuilder.logger.info("Using " + info.parameterNameProviderClass + " as parameter name provider.");
        }
        return (Configuration<?>)config;
    }
    
    private static <T> T newInstance(final OpenEjbConfig config, final Class<T> clazz) throws Exception {
        final WebBeansContext webBeansContext = AppFinder.findAppContextOrWeb(Thread.currentThread().getContextClassLoader(), AppFinder.WebBeansContextTransformer.INSTANCE);
        if (webBeansContext == null) {
            return clazz.newInstance();
        }
        final BeanManagerImpl beanManager = webBeansContext.getBeanManagerImpl();
        if (!beanManager.isInUse()) {
            return clazz.newInstance();
        }
        final AnnotatedType<T> annotatedType = (AnnotatedType<T>)beanManager.createAnnotatedType((Class)clazz);
        final InjectionTarget<T> it = (InjectionTarget<T>)beanManager.createInjectionTarget((AnnotatedType)annotatedType);
        final CreationalContext<T> context = (CreationalContext<T>)beanManager.createCreationalContext((Contextual)null);
        final T instance = (T)it.produce((CreationalContext)context);
        it.inject((Object)instance, (CreationalContext)context);
        it.postConstruct((Object)instance);
        config.releasables.add(new Releasable((CreationalContext)context, (InjectionTarget)it, (Object)instance));
        return instance;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, ValidatorBuilder.class);
    }
    
    private static final class OpenEjbBootstrapConfig implements BootstrapConfiguration, Serializable
    {
        private final String providerClassName;
        private final String constraintFactoryClass;
        private final String messageInterpolatorClass;
        private final String traversableResolverClass;
        private final String parameterNameProviderClass;
        private final Set<String> constraintMappings;
        private final boolean executableValidationEnabled;
        private final Set<ExecutableType> validatedTypes;
        private final Map<String, String> props;
        
        public OpenEjbBootstrapConfig(final String providerClassName, final String constraintFactoryClass, final String messageInterpolatorClass, final String traversableResolverClass, final String parameterNameProviderClass, final Set<String> constraintMappings, final boolean executableValidationEnabled, final Set<ExecutableType> validatedTypes, final Map<String, String> props) {
            this.providerClassName = providerClassName;
            this.constraintFactoryClass = constraintFactoryClass;
            this.messageInterpolatorClass = messageInterpolatorClass;
            this.traversableResolverClass = traversableResolverClass;
            this.parameterNameProviderClass = parameterNameProviderClass;
            this.constraintMappings = constraintMappings;
            this.executableValidationEnabled = executableValidationEnabled;
            this.validatedTypes = validatedTypes;
            this.props = props;
        }
        
        public String getDefaultProviderClassName() {
            return this.providerClassName;
        }
        
        public String getConstraintValidatorFactoryClassName() {
            return this.constraintFactoryClass;
        }
        
        public String getMessageInterpolatorClassName() {
            return this.messageInterpolatorClass;
        }
        
        public String getTraversableResolverClassName() {
            return this.traversableResolverClass;
        }
        
        public String getParameterNameProviderClassName() {
            return this.parameterNameProviderClass;
        }
        
        public Set<String> getConstraintMappingResourcePaths() {
            return this.constraintMappings;
        }
        
        public boolean isExecutableValidationEnabled() {
            return this.executableValidationEnabled;
        }
        
        public Set<ExecutableType> getDefaultValidatedExecutableTypes() {
            return this.validatedTypes;
        }
        
        public Map<String, String> getProperties() {
            return this.props;
        }
    }
    
    private static final class OpenEjbConfig<T extends Configuration<T>> implements Configuration<T>
    {
        private final Collection<Releasable<?>> releasables;
        private final Configuration<T> delegate;
        private final BootstrapConfiguration bootstrap;
        
        public OpenEjbConfig(final BootstrapConfiguration bootstrapConfig, final Configuration<T> target) {
            this.releasables = new LinkedList<Releasable<?>>();
            this.bootstrap = bootstrapConfig;
            this.delegate = target;
        }
        
        public T ignoreXmlConfiguration() {
            return (T)this.delegate.ignoreXmlConfiguration();
        }
        
        public T messageInterpolator(final MessageInterpolator interpolator) {
            return (T)this.delegate.messageInterpolator(interpolator);
        }
        
        public T traversableResolver(final TraversableResolver resolver) {
            return (T)this.delegate.traversableResolver(resolver);
        }
        
        public T constraintValidatorFactory(final ConstraintValidatorFactory constraintValidatorFactory) {
            return (T)this.delegate.constraintValidatorFactory(constraintValidatorFactory);
        }
        
        public T addMapping(final InputStream stream) {
            return (T)this.delegate.addMapping(stream);
        }
        
        public T addProperty(final String name, final String value) {
            return (T)this.delegate.addProperty(name, value);
        }
        
        public MessageInterpolator getDefaultMessageInterpolator() {
            return this.delegate.getDefaultMessageInterpolator();
        }
        
        public TraversableResolver getDefaultTraversableResolver() {
            return this.delegate.getDefaultTraversableResolver();
        }
        
        public ConstraintValidatorFactory getDefaultConstraintValidatorFactory() {
            return this.delegate.getDefaultConstraintValidatorFactory();
        }
        
        public ValidatorFactory buildValidatorFactory() {
            return (ValidatorFactory)new OpenEJBValidatorFactory(this.delegate.buildValidatorFactory(), this.releasables);
        }
        
        public T parameterNameProvider(final ParameterNameProvider parameterNameProvider) {
            return (T)this.delegate.parameterNameProvider(parameterNameProvider);
        }
        
        public ParameterNameProvider getDefaultParameterNameProvider() {
            return this.delegate.getDefaultParameterNameProvider();
        }
        
        public BootstrapConfiguration getBootstrapConfiguration() {
            return this.bootstrap;
        }
    }
    
    private static final class OpenEJBValidatorFactory implements ValidatorFactory, Serializable
    {
        private transient ValidatorFactory delegate;
        private transient Collection<Releasable<?>> toRelease;
        
        public OpenEJBValidatorFactory(final ValidatorFactory validatorFactory, final Collection<Releasable<?>> releasables) {
            this.delegate = validatorFactory;
            this.toRelease = releasables;
        }
        
        private ValidatorFactory delegate() {
            if (this.delegate != null) {
                return this.delegate;
            }
            try {
                return ValidatorUtil.lookupFactory();
            }
            catch (NamingException e) {
                return Validation.buildDefaultValidatorFactory();
            }
        }
        
        public Validator getValidator() {
            return this.delegate().getValidator();
        }
        
        public ValidatorContext usingContext() {
            return this.delegate().usingContext();
        }
        
        public MessageInterpolator getMessageInterpolator() {
            return this.delegate().getMessageInterpolator();
        }
        
        public TraversableResolver getTraversableResolver() {
            return this.delegate().getTraversableResolver();
        }
        
        public ConstraintValidatorFactory getConstraintValidatorFactory() {
            return this.delegate().getConstraintValidatorFactory();
        }
        
        public <T> T unwrap(final Class<T> type) {
            return (T)this.delegate().unwrap((Class)type);
        }
        
        public ParameterNameProvider getParameterNameProvider() {
            return this.delegate().getParameterNameProvider();
        }
        
        public void close() {
            if (this.delegate != null) {
                this.delegate.close();
            }
            if (this.toRelease != null) {
                for (final Releasable<?> r : this.toRelease) {
                    ((Releasable<Object>)r).release();
                }
            }
        }
    }
    
    private static final class Releasable<T>
    {
        private final CreationalContext<T> context;
        private final InjectionTarget<T> injectionTarget;
        private final T instance;
        
        private Releasable(final CreationalContext<T> context, final InjectionTarget<T> injectionTarget, final T instance) {
            this.context = context;
            this.injectionTarget = injectionTarget;
            this.instance = instance;
        }
        
        private void release() {
            try {
                this.injectionTarget.preDestroy((Object)this.instance);
                this.injectionTarget.dispose((Object)this.instance);
                this.context.release();
            }
            catch (Exception ex) {}
            catch (NoClassDefFoundError noClassDefFoundError) {}
        }
    }
}
