// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import javax.ejb.ScheduleExpression;
import java.util.Collection;
import javax.ejb.EJBException;
import javax.ejb.TimerConfig;
import javax.ejb.Timer;
import java.io.Serializable;
import java.util.Date;
import java.lang.reflect.Method;
import javax.ejb.TimerService;

public class TimerServiceImpl implements TimerService
{
    private final EjbTimerService ejbTimerService;
    private final Object primaryKey;
    private final Method ejbTimeout;
    
    public TimerServiceImpl(final EjbTimerService ejbTimerService, final Object primaryKey, final Method ejbTimeout) {
        this.ejbTimerService = ejbTimerService;
        this.primaryKey = primaryKey;
        this.ejbTimeout = ejbTimeout;
    }
    
    public Timer createTimer(final Date initialExpiration, final long intervalDuration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, initialExpiration, intervalDuration, new TimerConfig(info, true));
    }
    
    public Timer createTimer(final Date expiration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, expiration, new TimerConfig(info, true));
    }
    
    public Timer createTimer(final long initialDuration, final long intervalDuration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, initialDuration, intervalDuration, new TimerConfig(info, true));
    }
    
    public Timer createTimer(final long duration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, duration, new TimerConfig(info, true));
    }
    
    public Collection<Timer> getTimers() throws IllegalStateException, EJBException {
        return this.ejbTimerService.getTimers(this.primaryKey);
    }
    
    public Timer createSingleActionTimer(final long duration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, duration, timerConfig);
    }
    
    public Timer createSingleActionTimer(final Date expiration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, expiration, timerConfig);
    }
    
    public Timer createIntervalTimer(final long initialDuration, final long intervalDuration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, initialDuration, intervalDuration, timerConfig);
    }
    
    public Timer createIntervalTimer(final Date initialExpiration, final long lintervalDuration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, initialExpiration, lintervalDuration, timerConfig);
    }
    
    public Timer createCalendarTimer(final ScheduleExpression scheduleExpression) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, this.copy(scheduleExpression), new TimerConfig((Serializable)null, true));
    }
    
    public Timer createCalendarTimer(final ScheduleExpression scheduleExpression, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.ejbTimerService.createTimer(this.primaryKey, this.ejbTimeout, this.copy(scheduleExpression), timerConfig);
    }
    
    private ScheduleExpression copy(final ScheduleExpression scheduleExpression) {
        final ScheduleExpression scheduleExpressionCopy = new ScheduleExpression();
        scheduleExpressionCopy.year(scheduleExpression.getYear());
        scheduleExpressionCopy.month(scheduleExpression.getMonth());
        scheduleExpressionCopy.dayOfMonth(scheduleExpression.getDayOfMonth());
        scheduleExpressionCopy.dayOfWeek(scheduleExpression.getDayOfWeek());
        scheduleExpressionCopy.hour(scheduleExpression.getHour());
        scheduleExpressionCopy.minute(scheduleExpression.getMinute());
        scheduleExpressionCopy.second(scheduleExpression.getSecond());
        scheduleExpressionCopy.start(scheduleExpression.getStart());
        scheduleExpressionCopy.end(scheduleExpression.getEnd());
        scheduleExpressionCopy.timezone(scheduleExpression.getTimezone());
        return scheduleExpressionCopy;
    }
    
    public Collection<Timer> getAllTimers() throws IllegalStateException, EJBException {
        throw new UnsupportedOperationException("not expecting to call this method from this class, see TimerServiceWrapper");
    }
}
