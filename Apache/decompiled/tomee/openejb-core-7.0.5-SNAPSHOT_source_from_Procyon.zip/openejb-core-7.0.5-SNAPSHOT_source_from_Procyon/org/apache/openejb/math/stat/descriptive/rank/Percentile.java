// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive.rank;

import org.apache.openejb.math.stat.descriptive.UnivariateStatistic;
import java.util.Arrays;
import org.apache.openejb.math.MathRuntimeException;
import java.io.Serializable;
import org.apache.openejb.math.stat.descriptive.AbstractUnivariateStatistic;

public class Percentile extends AbstractUnivariateStatistic implements Serializable
{
    private static final long serialVersionUID = -1231216485095130416L;
    private double quantile;
    
    public Percentile() {
        this(50.0);
    }
    
    public Percentile(final double p) {
        this.setQuantile(p);
    }
    
    public Percentile(final Percentile original) {
        copy(original, this);
    }
    
    public double evaluate(final double[] values, final double p) {
        this.test(values, 0, 0);
        return this.evaluate(values, 0, values.length, p);
    }
    
    @Override
    public double evaluate(final double[] values, final int start, final int length) {
        return this.evaluate(values, start, length, this.quantile);
    }
    
    public double evaluate(final double[] values, final int begin, final int length, final double p) {
        this.test(values, begin, length);
        if (p > 100.0 || p <= 0.0) {
            throw MathRuntimeException.createIllegalArgumentException("out of bounds quantile value: {0}, must be in (0, 100]", p);
        }
        if (length == 0) {
            return Double.NaN;
        }
        if (length == 1) {
            return values[begin];
        }
        final double n = length;
        final double pos = p * (n + 1.0) / 100.0;
        final double fpos = Math.floor(pos);
        final int intPos = (int)fpos;
        final double dif = pos - fpos;
        final double[] sorted = new double[length];
        System.arraycopy(values, begin, sorted, 0, length);
        Arrays.sort(sorted);
        if (pos < 1.0) {
            return sorted[0];
        }
        if (pos >= n) {
            return sorted[length - 1];
        }
        final double lower = sorted[intPos - 1];
        final double upper = sorted[intPos];
        return lower + dif * (upper - lower);
    }
    
    public double getQuantile() {
        return this.quantile;
    }
    
    public void setQuantile(final double p) {
        if (p <= 0.0 || p > 100.0) {
            throw MathRuntimeException.createIllegalArgumentException("out of bounds quantile value: {0}, must be in (0, 100]", p);
        }
        this.quantile = p;
    }
    
    @Override
    public Percentile copy() {
        final Percentile result = new Percentile();
        copy(this, result);
        return result;
    }
    
    public static void copy(final Percentile source, final Percentile dest) {
        dest.quantile = source.quantile;
    }
}
