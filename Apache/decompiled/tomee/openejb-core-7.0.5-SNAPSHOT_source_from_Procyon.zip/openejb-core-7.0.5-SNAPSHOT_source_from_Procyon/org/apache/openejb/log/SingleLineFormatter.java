// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log;

import org.apache.openejb.util.JavaSecurityManagers;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.LogRecord;
import java.util.logging.Formatter;

public class SingleLineFormatter extends Formatter
{
    private static final String SEP;
    
    @Override
    public synchronized String format(final LogRecord record) {
        final boolean exception = record.getThrown() != null;
        final StringBuilder sbuf = new StringBuilder();
        sbuf.append(record.getLevel().getLocalizedName());
        sbuf.append(" - ");
        sbuf.append(this.formatMessage(record));
        sbuf.append(SingleLineFormatter.SEP);
        if (exception) {
            try {
                final StringWriter sw = new StringWriter();
                final PrintWriter pw = new PrintWriter(sw);
                record.getThrown().printStackTrace(pw);
                pw.close();
                sbuf.append(sw.toString());
            }
            catch (Exception ex) {}
        }
        return sbuf.toString();
    }
    
    static {
        SEP = JavaSecurityManagers.getSystemProperty("line.separator", "\n");
    }
}
