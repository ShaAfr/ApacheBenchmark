// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateless;

import org.apache.openejb.util.Pool;
import javax.enterprise.context.spi.CreationalContext;
import java.util.Map;

public class Instance
{
    public final Object bean;
    public final Map<String, Object> interceptors;
    public final CreationalContext creationalContext;
    private Pool.Entry poolEntry;
    
    public Instance(final Object bean, final Map<String, Object> interceptors, final CreationalContext creationalContext) {
        this.bean = bean;
        this.interceptors = interceptors;
        this.creationalContext = creationalContext;
    }
    
    public Pool.Entry getPoolEntry() {
        return this.poolEntry;
    }
    
    public void setPoolEntry(final Pool.Entry poolEntry) {
        this.poolEntry = poolEntry;
    }
}
