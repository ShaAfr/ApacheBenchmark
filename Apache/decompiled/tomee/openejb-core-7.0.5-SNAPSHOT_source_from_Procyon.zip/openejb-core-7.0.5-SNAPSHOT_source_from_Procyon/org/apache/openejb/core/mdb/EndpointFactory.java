// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.mdb;

import org.apache.openejb.core.transaction.TransactionType;
import java.lang.reflect.Method;
import javax.resource.spi.UnavailableException;
import java.lang.reflect.InvocationHandler;
import javax.transaction.xa.XAResource;
import org.apache.openejb.util.proxy.LocalBeanProxyFactory;
import javax.resource.spi.endpoint.MessageEndpoint;
import java.util.ArrayList;
import javax.management.ObjectName;
import java.util.List;
import org.apache.openejb.resource.XAResourceWrapper;
import org.apache.openejb.BeanContext;
import javax.resource.spi.ActivationSpec;
import javax.resource.spi.endpoint.MessageEndpointFactory;

public class EndpointFactory implements MessageEndpointFactory
{
    private final ActivationSpec activationSpec;
    private final MdbContainer container;
    private final BeanContext beanContext;
    private final MdbInstanceFactory instanceFactory;
    private final ClassLoader classLoader;
    private final Class[] interfaces;
    private final XAResourceWrapper xaResourceWrapper;
    protected final List<ObjectName> jmxNames;
    private final Class<?> proxy;
    
    public EndpointFactory(final ActivationSpec activationSpec, final MdbContainer container, final BeanContext beanContext, final MdbInstanceFactory instanceFactory, final XAResourceWrapper xaResourceWrapper) {
        this.jmxNames = new ArrayList<ObjectName>();
        this.activationSpec = activationSpec;
        this.container = container;
        this.beanContext = beanContext;
        this.instanceFactory = instanceFactory;
        this.classLoader = container.getMessageListenerInterface().getClassLoader();
        this.interfaces = new Class[] { container.getMessageListenerInterface(), MessageEndpoint.class };
        this.xaResourceWrapper = xaResourceWrapper;
        final BeanContext.ProxyClass proxyClass = beanContext.get(BeanContext.ProxyClass.class);
        if (proxyClass == null) {
            this.proxy = (Class<?>)LocalBeanProxyFactory.createProxy(beanContext.getBeanClass(), beanContext.getClassLoader(), this.interfaces);
            beanContext.set(BeanContext.ProxyClass.class, new BeanContext.ProxyClass(beanContext, this.interfaces));
        }
        else {
            this.proxy = proxyClass.getProxy();
        }
    }
    
    public ActivationSpec getActivationSpec() {
        return this.activationSpec;
    }
    
    public MdbInstanceFactory getInstanceFactory() {
        return this.instanceFactory;
    }
    
    public MessageEndpoint createEndpoint(XAResource xaResource) throws UnavailableException {
        if (xaResource != null && this.xaResourceWrapper != null) {
            xaResource = this.xaResourceWrapper.wrap(xaResource, this.container.getContainerID().toString());
        }
        final EndpointHandler endpointHandler = new EndpointHandler(this.container, this.beanContext, this.instanceFactory, xaResource);
        try {
            return (MessageEndpoint)LocalBeanProxyFactory.constructProxy(this.proxy, endpointHandler);
        }
        catch (InternalError e) {
            try {
                return MessageEndpoint.class.cast(LocalBeanProxyFactory.newProxyInstance(Thread.currentThread().getContextClassLoader(), endpointHandler, this.beanContext.getBeanClass(), this.interfaces));
            }
            catch (InternalError ie) {
                try {
                    return MessageEndpoint.class.cast(LocalBeanProxyFactory.newProxyInstance(this.classLoader, endpointHandler, this.beanContext.getBeanClass(), this.interfaces));
                }
                catch (InternalError internalError) {
                    throw e;
                }
            }
        }
    }
    
    public MessageEndpoint createEndpoint(final XAResource xaResource, final long timeout) throws UnavailableException {
        if (timeout <= 0L) {
            return this.createEndpoint(xaResource);
        }
        final long end = System.currentTimeMillis() + timeout;
        MessageEndpoint messageEndpoint = null;
        while (System.currentTimeMillis() <= end) {
            try {
                messageEndpoint = this.createEndpoint(xaResource);
            }
            catch (Exception ex) {
                continue;
            }
            break;
        }
        if (messageEndpoint != null) {
            return messageEndpoint;
        }
        throw new UnavailableException("Unable to create end point within the specified timeout " + timeout);
    }
    
    public boolean isDeliveryTransacted(final Method method) throws NoSuchMethodException {
        final TransactionType transactionType = this.beanContext.getTransactionType(method);
        return TransactionType.Required == transactionType;
    }
}
