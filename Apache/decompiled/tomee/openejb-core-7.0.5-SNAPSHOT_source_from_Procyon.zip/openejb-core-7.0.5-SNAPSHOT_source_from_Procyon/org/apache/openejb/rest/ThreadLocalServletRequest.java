// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.servlet.ServletResponse;
import java.io.UnsupportedEncodingException;
import javax.servlet.ServletContext;
import javax.servlet.RequestDispatcher;
import java.io.BufferedReader;
import java.util.Map;
import java.util.Locale;
import java.io.IOException;
import javax.servlet.ServletInputStream;
import javax.servlet.DispatcherType;
import java.util.Enumeration;
import javax.servlet.AsyncContext;
import javax.servlet.ServletRequest;

public class ThreadLocalServletRequest extends AbstractRestThreadLocalProxy<ServletRequest> implements ServletRequest
{
    protected ThreadLocalServletRequest() {
        super(ServletRequest.class);
    }
    
    public AsyncContext getAsyncContext() {
        return this.get().getAsyncContext();
    }
    
    public Object getAttribute(final String string) {
        return this.get().getAttribute(string);
    }
    
    public Enumeration<String> getAttributeNames() {
        return (Enumeration<String>)this.get().getAttributeNames();
    }
    
    public String getCharacterEncoding() {
        return this.get().getCharacterEncoding();
    }
    
    public int getContentLength() {
        return this.get().getContentLength();
    }
    
    public long getContentLengthLong() {
        return this.get().getContentLengthLong();
    }
    
    public String getContentType() {
        return this.get().getContentType();
    }
    
    public DispatcherType getDispatcherType() {
        return this.get().getDispatcherType();
    }
    
    public ServletInputStream getInputStream() throws IOException {
        return this.get().getInputStream();
    }
    
    public String getLocalAddr() {
        return this.get().getLocalAddr();
    }
    
    public Locale getLocale() {
        return this.get().getLocale();
    }
    
    public Enumeration<Locale> getLocales() {
        return (Enumeration<Locale>)this.get().getLocales();
    }
    
    public String getLocalName() {
        return this.get().getLocalName();
    }
    
    public int getLocalPort() {
        return this.get().getLocalPort();
    }
    
    public String getParameter(final String string) {
        return this.get().getParameter(string);
    }
    
    public Map<String, String[]> getParameterMap() {
        return (Map<String, String[]>)this.get().getParameterMap();
    }
    
    public String[] getParameterValues(final String string) {
        return this.get().getParameterValues(string);
    }
    
    public Enumeration<String> getParameterNames() {
        return (Enumeration<String>)this.get().getParameterNames();
    }
    
    public String getProtocol() {
        return this.get().getProtocol();
    }
    
    public BufferedReader getReader() throws IOException {
        return this.get().getReader();
    }
    
    public String getRealPath(final String string) {
        return this.get().getRealPath(string);
    }
    
    public String getRemoteAddr() {
        return this.get().getRemoteAddr();
    }
    
    public String getRemoteHost() {
        return this.get().getRemoteHost();
    }
    
    public int getRemotePort() {
        return this.get().getRemotePort();
    }
    
    public RequestDispatcher getRequestDispatcher(final String string) {
        return this.get().getRequestDispatcher(string);
    }
    
    public String getScheme() {
        return this.get().getScheme();
    }
    
    public String getServerName() {
        return this.get().getServerName();
    }
    
    public int getServerPort() {
        return this.get().getServerPort();
    }
    
    public ServletContext getServletContext() {
        return this.get().getServletContext();
    }
    
    public boolean isAsyncStarted() {
        return this.get().isAsyncStarted();
    }
    
    public boolean isAsyncSupported() {
        return this.get().isAsyncSupported();
    }
    
    public boolean isSecure() {
        return this.get().isSecure();
    }
    
    public void removeAttribute(final String string) {
        this.get().removeAttribute(string);
    }
    
    public void setAttribute(final String string, final Object object) {
        this.get().setAttribute(string, object);
    }
    
    public void setCharacterEncoding(final String string) throws UnsupportedEncodingException {
        this.get().setCharacterEncoding(string);
    }
    
    public AsyncContext startAsync() {
        return this.get().startAsync();
    }
    
    public AsyncContext startAsync(final ServletRequest servletRequest, final ServletResponse servletResponse) {
        return this.get().startAsync(servletRequest, servletResponse);
    }
}
