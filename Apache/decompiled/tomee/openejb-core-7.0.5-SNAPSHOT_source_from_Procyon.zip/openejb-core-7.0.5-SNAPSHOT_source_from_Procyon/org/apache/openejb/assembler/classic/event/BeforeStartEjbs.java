// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.event;

import java.util.Collections;
import org.apache.openejb.BeanContext;
import java.util.List;
import org.apache.openejb.observer.Event;

@Event
public class BeforeStartEjbs
{
    private final List<BeanContext> ejbs;
    
    public BeforeStartEjbs(final List<BeanContext> allDeployments) {
        this.ejbs = allDeployments;
    }
    
    public List<BeanContext> getEjbs() {
        return Collections.unmodifiableList((List<? extends BeanContext>)this.ejbs);
    }
    
    @Override
    public String toString() {
        return "BeforeStartEjbs{#ejbs=" + this.ejbs.size() + '}';
    }
}
