// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log.commonslogging;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.util.Logger;
import java.io.Serializable;
import org.apache.commons.logging.Log;

public class OpenEJBCommonsLog implements Log, Serializable
{
    private transient Logger logger;
    private final String category;
    
    public OpenEJBCommonsLog(final String category) {
        this.category = category;
        this.logger = Logger.getInstance(LogCategory.OPENEJB, category);
    }
    
    public boolean isDebugEnabled() {
        return this.logger.isDebugEnabled();
    }
    
    public boolean isErrorEnabled() {
        return this.logger.isErrorEnabled();
    }
    
    public boolean isFatalEnabled() {
        return this.logger.isFatalEnabled();
    }
    
    public boolean isInfoEnabled() {
        return this.logger.isInfoEnabled();
    }
    
    public boolean isTraceEnabled() {
        return this.logger.isDebugEnabled();
    }
    
    public boolean isWarnEnabled() {
        return this.logger.isWarningEnabled();
    }
    
    public void trace(final Object message) {
        this.logger.debug(String.valueOf(message));
    }
    
    public void trace(final Object message, final Throwable t) {
        this.logger.debug(String.valueOf(message), t);
    }
    
    public void debug(final Object message) {
        this.logger.debug(String.valueOf(message));
    }
    
    public void debug(final Object message, final Throwable t) {
        this.logger.debug(String.valueOf(message), t);
    }
    
    public void info(final Object message) {
        this.logger.info(String.valueOf(message));
    }
    
    public void info(final Object message, final Throwable t) {
        this.logger.info(String.valueOf(message), t);
    }
    
    public void warn(final Object message) {
        this.logger.warning(String.valueOf(message));
    }
    
    public void warn(final Object message, final Throwable t) {
        this.logger.warning(String.valueOf(message), t);
    }
    
    public void error(final Object message) {
        this.logger.error(String.valueOf(message));
    }
    
    public void error(final Object message, final Throwable t) {
        this.logger.error(String.valueOf(message), t);
    }
    
    public void fatal(final Object message) {
        this.logger.fatal(String.valueOf(message));
    }
    
    public void fatal(final Object message, final Throwable t) {
        this.logger.fatal(String.valueOf(message), t);
    }
    
    private void writeObject(final ObjectOutputStream out) throws IOException {
        out.writeUTF(this.category);
    }
    
    private void readObject(final ObjectInputStream in) throws IOException {
        this.logger = Logger.getInstance(LogCategory.OPENEJB, in.readUTF());
    }
}
