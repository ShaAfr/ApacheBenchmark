// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import java.util.Set;
import javax.ws.rs.core.Feature;
import java.util.Collection;
import java.util.Map;
import javax.ws.rs.RuntimeType;
import javax.ws.rs.core.Configuration;

public class ThreadLocalConfiguration extends AbstractRestThreadLocalProxy<Configuration> implements Configuration
{
    protected ThreadLocalConfiguration() {
        super(Configuration.class);
    }
    
    public RuntimeType getRuntimeType() {
        return this.get().getRuntimeType();
    }
    
    public Map<String, Object> getProperties() {
        return (Map<String, Object>)this.get().getProperties();
    }
    
    public Object getProperty(final String name) {
        return this.get().getProperty(name);
    }
    
    public Collection<String> getPropertyNames() {
        return (Collection<String>)this.get().getPropertyNames();
    }
    
    public boolean isEnabled(final Feature feature) {
        return this.get().isEnabled(feature);
    }
    
    public boolean isEnabled(final Class<? extends Feature> featureClass) {
        return this.get().isEnabled((Class)featureClass);
    }
    
    public boolean isRegistered(final Object component) {
        return this.get().isRegistered(component);
    }
    
    public boolean isRegistered(final Class<?> componentClass) {
        return this.get().isRegistered((Class)componentClass);
    }
    
    public Map<Class<?>, Integer> getContracts(final Class<?> componentClass) {
        return (Map<Class<?>, Integer>)this.get().getContracts((Class)componentClass);
    }
    
    public Set<Class<?>> getClasses() {
        return (Set<Class<?>>)this.get().getClasses();
    }
    
    public Set<Object> getInstances() {
        return (Set<Object>)this.get().getInstances();
    }
}
