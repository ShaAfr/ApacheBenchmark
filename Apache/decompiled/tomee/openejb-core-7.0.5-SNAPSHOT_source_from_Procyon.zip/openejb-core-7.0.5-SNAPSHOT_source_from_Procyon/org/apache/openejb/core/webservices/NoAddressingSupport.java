// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import javax.xml.ws.EndpointReference;
import org.w3c.dom.Element;

public class NoAddressingSupport implements AddressingSupport
{
    public static final NoAddressingSupport INSTANCE;
    
    @Override
    public EndpointReference getEndpointReference(final Element... referenceParameters) {
        throw new UnsupportedOperationException("JaxWS 2.1 APIs are not supported.");
    }
    
    @Override
    public <T extends EndpointReference> T getEndpointReference(final Class<T> clazz, final Element... referenceParameters) {
        throw new UnsupportedOperationException("JaxWS 2.1 APIs are not supported.");
    }
    
    static {
        INSTANCE = new NoAddressingSupport();
    }
}
