// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class MethodPermissionInfo extends MethodAttributeInfo
{
    public String description;
    public final List<String> roleNames;
    public boolean excluded;
    public boolean unchecked;
    
    public MethodPermissionInfo() {
        this.roleNames = new ArrayList<String>();
    }
}
