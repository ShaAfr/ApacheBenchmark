// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.apache.openejb.util.OptionsLog;
import org.apache.openejb.loader.SystemInstance;
import java.util.Map;
import java.util.Properties;
import javax.naming.NamingException;
import javax.naming.Context;
import java.util.Hashtable;
import org.apache.openejb.loader.OpenEJBInstance;
import java.util.concurrent.locks.ReentrantLock;
import javax.naming.spi.InitialContextFactory;

@Deprecated
public class LocalInitialContextFactory implements InitialContextFactory
{
    private static final ReentrantLock lock;
    private static OpenEJBInstance openejb;
    private boolean bootedOpenEJB;
    
    @Override
    public Context getInitialContext(final Hashtable env) throws NamingException {
        this.init(env);
        return this.getLocalInitialContext(env);
    }
    
    protected void init(final Hashtable env) throws NamingException {
        final ReentrantLock l = LocalInitialContextFactory.lock;
        l.lock();
        try {
            if (LocalInitialContextFactory.openejb != null && LocalInitialContextFactory.openejb.isInitialized()) {
                return;
            }
            try {
                final Properties properties = new Properties();
                properties.putAll(env);
                this.init(properties);
            }
            catch (Exception e) {
                throw (NamingException)new NamingException("Attempted to load OpenEJB. " + e.getMessage()).initCause(e);
            }
        }
        finally {
            l.unlock();
        }
    }
    
    boolean bootedOpenEJB() {
        final ReentrantLock l = LocalInitialContextFactory.lock;
        l.lock();
        try {
            return this.bootedOpenEJB;
        }
        finally {
            l.unlock();
        }
    }
    
    private void init(final Properties properties) throws Exception {
        if (LocalInitialContextFactory.openejb != null && LocalInitialContextFactory.openejb.isInitialized()) {
            return;
        }
        LocalInitialContextFactory.openejb = new OpenEJBInstance();
        if (LocalInitialContextFactory.openejb.isInitialized()) {
            return;
        }
        this.bootedOpenEJB = true;
        SystemInstance.init(properties);
        OptionsLog.install();
        SystemInstance.get().setProperty("openejb.embedded", "true");
        LocalInitialContextFactory.openejb.init(properties);
    }
    
    public void close() {
        final ReentrantLock l = LocalInitialContextFactory.lock;
        l.lock();
        try {
            LocalInitialContextFactory.openejb = null;
        }
        finally {
            l.unlock();
        }
    }
    
    private Context getLocalInitialContext(final Hashtable env) throws NamingException {
        Context context;
        try {
            final ClassLoader cl = SystemInstance.get().getClassLoader();
            final Class localInitialContext = Class.forName("org.apache.openejb.core.LocalInitialContext", true, cl);
            final Constructor constructor = localInitialContext.getConstructor(Hashtable.class, LocalInitialContextFactory.class);
            context = constructor.newInstance(env, this);
        }
        catch (Throwable e) {
            if (e instanceof InvocationTargetException) {
                final InvocationTargetException ite = (InvocationTargetException)e;
                if (ite.getTargetException() != null) {
                    e = ite.getTargetException();
                }
            }
            if (e instanceof NamingException) {
                throw (NamingException)e;
            }
            throw (NamingException)new NamingException("Cannot instantiate a LocalInitialContext. Exception: " + e.getClass().getName() + " " + e.getMessage()).initCause(e);
        }
        return context;
    }
    
    static {
        lock = new ReentrantLock();
    }
}
