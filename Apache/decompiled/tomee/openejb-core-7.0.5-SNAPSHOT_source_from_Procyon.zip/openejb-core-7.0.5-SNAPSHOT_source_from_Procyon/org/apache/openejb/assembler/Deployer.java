// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler;

import org.apache.openejb.NoSuchApplicationException;
import org.apache.openejb.UndeployException;
import java.util.Properties;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.assembler.classic.AppInfo;
import java.util.Collection;

public interface Deployer
{
    public static final String FILENAME = "filename";
    public static final String ALT_DD = "altDD";
    
    String getUniqueFile();
    
    Collection<AppInfo> getDeployedApps();
    
    AppInfo deploy(final String p0) throws OpenEJBException;
    
    AppInfo deploy(final Properties p0) throws OpenEJBException;
    
    AppInfo deploy(final String p0, final Properties p1) throws OpenEJBException;
    
    void undeploy(final String p0) throws UndeployException, NoSuchApplicationException;
    
    void reload(final String p0);
}
