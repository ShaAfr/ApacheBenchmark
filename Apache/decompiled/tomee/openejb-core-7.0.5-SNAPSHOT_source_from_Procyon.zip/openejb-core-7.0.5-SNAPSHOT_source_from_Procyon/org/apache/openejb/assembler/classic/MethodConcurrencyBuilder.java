// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Comparator;
import java.util.Collections;
import org.apache.openejb.MethodContext;
import org.apache.openejb.util.Duration;
import java.util.concurrent.TimeUnit;
import javax.ejb.LockType;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.ArrayList;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.OpenEJBException;
import java.util.Iterator;
import java.util.List;
import org.apache.openejb.BeanContext;
import java.util.HashMap;
import org.apache.openejb.util.Logger;

public class MethodConcurrencyBuilder
{
    public static final Logger logger;
    
    public void build(final HashMap<String, BeanContext> deployments, final List<MethodConcurrencyInfo> methodConcurrencys) throws OpenEJBException {
        for (final BeanContext beanContext : deployments.values()) {
            applyConcurrencyAttributes(beanContext, methodConcurrencys);
        }
    }
    
    public static void applyConcurrencyAttributes(final BeanContext beanContext, final List<MethodConcurrencyInfo> methodConcurrencyInfos) throws OpenEJBException {
        if (beanContext.isBeanManagedConcurrency()) {
            return;
        }
        final Logger log = Logger.getInstance(LogCategory.OPENEJB_STARTUP.createChild("attributes"), MethodConcurrencyBuilder.class);
        final List<MethodConcurrencyInfo> lockInfos = new ArrayList<MethodConcurrencyInfo>();
        final List<MethodConcurrencyInfo> accessTimeoutInfos = new ArrayList<MethodConcurrencyInfo>();
        normalize(methodConcurrencyInfos, lockInfos, accessTimeoutInfos);
        Map<Method, MethodAttributeInfo> attributes = MethodInfoUtil.resolveAttributes(lockInfos, beanContext);
        if (log.isDebugEnabled()) {
            for (final Map.Entry<Method, MethodAttributeInfo> entry : attributes.entrySet()) {
                final Method method = entry.getKey();
                final MethodConcurrencyInfo value = entry.getValue();
                log.debug("Lock: " + method + " -- " + MethodInfoUtil.toString(value.methods.get(0)) + " " + value.concurrencyAttribute);
            }
        }
        for (final Map.Entry<Method, MethodAttributeInfo> entry : attributes.entrySet()) {
            final MethodConcurrencyInfo value2 = entry.getValue();
            final MethodContext methodContext = beanContext.getMethodContext(entry.getKey());
            final String s = value2.concurrencyAttribute.toUpperCase();
            methodContext.setLockType(LockType.valueOf(s));
        }
        attributes = MethodInfoUtil.resolveAttributes(accessTimeoutInfos, beanContext);
        if (log.isDebugEnabled()) {
            for (final Map.Entry<Method, MethodAttributeInfo> entry : attributes.entrySet()) {
                final Method method = entry.getKey();
                final MethodConcurrencyInfo value = entry.getValue();
                log.debug("AccessTimeout: " + method + " -- " + MethodInfoUtil.toString(value.methods.get(0)) + "  " + value.accessTimeout.time + " " + value.accessTimeout.unit);
            }
        }
        for (final Map.Entry<Method, MethodAttributeInfo> entry : attributes.entrySet()) {
            final MethodConcurrencyInfo value2 = entry.getValue();
            final MethodContext methodContext = beanContext.getMethodContext(entry.getKey());
            final Duration accessTimeout = new Duration(value2.accessTimeout.time, TimeUnit.valueOf(value2.accessTimeout.unit));
            methodContext.setAccessTimeout(accessTimeout);
        }
    }
    
    public static void normalize(final List<MethodConcurrencyInfo> infos, final List<MethodConcurrencyInfo> lockInfos, final List<MethodConcurrencyInfo> accessTimeoutInfos) {
        for (final MethodConcurrencyInfo oldInfo : infos) {
            for (final MethodInfo methodInfo : oldInfo.methods) {
                final MethodConcurrencyInfo newInfo = new MethodConcurrencyInfo();
                newInfo.description = oldInfo.description;
                newInfo.methods.add(methodInfo);
                newInfo.concurrencyAttribute = oldInfo.concurrencyAttribute;
                newInfo.accessTimeout = oldInfo.accessTimeout;
                if (oldInfo.concurrencyAttribute != null) {
                    lockInfos.add(newInfo);
                }
                if (oldInfo.accessTimeout != null) {
                    accessTimeoutInfos.add(newInfo);
                }
            }
        }
        Collections.reverse(lockInfos);
        Collections.sort(lockInfos, new MethodConcurrencyComparator());
        Collections.reverse(accessTimeoutInfos);
        Collections.sort(accessTimeoutInfos, new MethodConcurrencyComparator());
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, MethodConcurrencyBuilder.class);
    }
    
    public static class MethodConcurrencyComparator extends MethodInfoUtil.BaseComparator<MethodConcurrencyInfo>
    {
        @Override
        public int compare(final MethodConcurrencyInfo a, final MethodConcurrencyInfo b) {
            return this.compare(a.methods.get(0), b.methods.get(0));
        }
    }
}
