// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.BeanContext;
import javax.ejb.NoSuchObjectLocalException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.ejb.Timer;
import java.io.Serializable;
import javax.ejb.TimerHandle;

public class TimerHandleImpl implements TimerHandle, Serializable
{
    private static final long serialVersionUID = 9198316188404706377L;
    private final long id;
    private final String deploymentId;
    
    public TimerHandleImpl(final long id, final String deploymentId) {
        this.id = id;
        this.deploymentId = deploymentId;
    }
    
    public Timer getTimer() {
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        if (containerSystem == null) {
            throw new NoSuchObjectLocalException("OpenEJb container system is not running");
        }
        final BeanContext beanContext = containerSystem.getBeanContext(this.deploymentId);
        if (beanContext == null) {
            throw new NoSuchObjectLocalException("Deployment info not found " + this.deploymentId);
        }
        final EjbTimerService timerService = beanContext.getEjbTimerService();
        if (timerService == null) {
            throw new NoSuchObjectLocalException("Deployment no longer supports ejbTimout " + this.deploymentId + ". Has this ejb been redeployed?");
        }
        final Timer timer = timerService.getTimer(this.id);
        if (timer == null) {
            throw new NoSuchObjectLocalException("Timer not found for ejb " + this.deploymentId);
        }
        return timer;
    }
}
