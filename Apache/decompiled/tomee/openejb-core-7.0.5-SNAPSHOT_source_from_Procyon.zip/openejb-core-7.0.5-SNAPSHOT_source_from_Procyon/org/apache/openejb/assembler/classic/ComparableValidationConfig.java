// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.List;
import java.util.Properties;
import java.io.Serializable;

public class ComparableValidationConfig implements Serializable
{
    private final String providerClassName;
    private final String messageInterpolatorClass;
    private final String traversableResolverClass;
    private final String constraintFactoryClass;
    private final String parameterNameProviderClass;
    private final String version;
    private final Properties propertyTypes;
    private final List<String> constraintMappings;
    private final boolean executableValidationEnabled;
    private final List<String> validatedTypes;
    private final int hash;
    
    public ComparableValidationConfig(final String providerClassName, final String messageInterpolatorClass, final String traversableResolverClass, final String constraintFactoryClass, final String parameterNameProviderClass, final String version, final Properties propertyTypes, final List<String> constraintMappings, final boolean executableValidationEnabled, final List<String> validatedTypes) {
        this.providerClassName = providerClassName;
        this.messageInterpolatorClass = messageInterpolatorClass;
        this.traversableResolverClass = traversableResolverClass;
        this.constraintFactoryClass = constraintFactoryClass;
        this.parameterNameProviderClass = parameterNameProviderClass;
        this.version = version;
        this.propertyTypes = propertyTypes;
        this.constraintMappings = constraintMappings;
        this.executableValidationEnabled = executableValidationEnabled;
        this.validatedTypes = validatedTypes;
        int result = (providerClassName != null) ? providerClassName.hashCode() : 0;
        result = 31 * result + ((messageInterpolatorClass != null) ? messageInterpolatorClass.hashCode() : 0);
        result = 31 * result + ((traversableResolverClass != null) ? traversableResolverClass.hashCode() : 0);
        result = 31 * result + ((constraintFactoryClass != null) ? constraintFactoryClass.hashCode() : 0);
        result = 31 * result + ((parameterNameProviderClass != null) ? parameterNameProviderClass.hashCode() : 0);
        result = 31 * result + ((version != null) ? version.hashCode() : 0);
        result = 31 * result + ((propertyTypes != null) ? propertyTypes.hashCode() : 0);
        result = 31 * result + ((constraintMappings != null) ? constraintMappings.hashCode() : 0);
        result = 31 * result + (executableValidationEnabled ? 1 : 0);
        result = 31 * result + ((validatedTypes != null) ? validatedTypes.hashCode() : 0);
        this.hash = result;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ComparableValidationConfig that = (ComparableValidationConfig)o;
        if (this.executableValidationEnabled != that.executableValidationEnabled) {
            return false;
        }
        Label_0075: {
            if (this.constraintFactoryClass != null) {
                if (this.constraintFactoryClass.equals(that.constraintFactoryClass)) {
                    break Label_0075;
                }
            }
            else if (that.constraintFactoryClass == null) {
                break Label_0075;
            }
            return false;
        }
        Label_0110: {
            if (this.constraintMappings != null) {
                if (this.constraintMappings.equals(that.constraintMappings)) {
                    break Label_0110;
                }
            }
            else if (that.constraintMappings == null) {
                break Label_0110;
            }
            return false;
        }
        Label_0143: {
            if (this.messageInterpolatorClass != null) {
                if (this.messageInterpolatorClass.equals(that.messageInterpolatorClass)) {
                    break Label_0143;
                }
            }
            else if (that.messageInterpolatorClass == null) {
                break Label_0143;
            }
            return false;
        }
        Label_0176: {
            if (this.parameterNameProviderClass != null) {
                if (this.parameterNameProviderClass.equals(that.parameterNameProviderClass)) {
                    break Label_0176;
                }
            }
            else if (that.parameterNameProviderClass == null) {
                break Label_0176;
            }
            return false;
        }
        Label_0209: {
            if (this.propertyTypes != null) {
                if (this.propertyTypes.equals(that.propertyTypes)) {
                    break Label_0209;
                }
            }
            else if (that.propertyTypes == null) {
                break Label_0209;
            }
            return false;
        }
        Label_0242: {
            if (this.providerClassName != null) {
                if (this.providerClassName.equals(that.providerClassName)) {
                    break Label_0242;
                }
            }
            else if (that.providerClassName == null) {
                break Label_0242;
            }
            return false;
        }
        Label_0275: {
            if (this.traversableResolverClass != null) {
                if (this.traversableResolverClass.equals(that.traversableResolverClass)) {
                    break Label_0275;
                }
            }
            else if (that.traversableResolverClass == null) {
                break Label_0275;
            }
            return false;
        }
        Label_0310: {
            if (this.validatedTypes != null) {
                if (this.validatedTypes.equals(that.validatedTypes)) {
                    break Label_0310;
                }
            }
            else if (that.validatedTypes == null) {
                break Label_0310;
            }
            return false;
        }
        if (this.version != null) {
            if (this.version.equals(that.version)) {
                return true;
            }
        }
        else if (that.version == null) {
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.hash;
    }
}
