// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

public class CmpUtil
{
    public static String getCmpImplClassName(final String abstractSchemaName, final String ejbClass) {
        final int packageEnd = ejbClass.lastIndexOf(46);
        if (packageEnd != -1) {
            return "openejb." + ejbClass.substring(0, packageEnd + 1) + abstractSchemaName;
        }
        return "openejb." + abstractSchemaName;
    }
}
