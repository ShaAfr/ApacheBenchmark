// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.interceptor;

import java.util.Map;
import java.lang.reflect.Method;
import java.util.List;
import org.apache.openejb.core.Operation;
import javax.xml.ws.handler.MessageContext;

public class JaxWsInvocationContext extends ReflectionInvocationContext
{
    private final MessageContext messageContext;
    
    public JaxWsInvocationContext(final Operation operation, final List<Interceptor> interceptors, final Object target, final Method method, final MessageContext messageContext, final Object... parameters) {
        super(operation, interceptors, target, method, parameters);
        this.messageContext = messageContext;
    }
    
    @Override
    public Map<String, Object> getContextData() {
        return (Map<String, Object>)this.messageContext;
    }
}
