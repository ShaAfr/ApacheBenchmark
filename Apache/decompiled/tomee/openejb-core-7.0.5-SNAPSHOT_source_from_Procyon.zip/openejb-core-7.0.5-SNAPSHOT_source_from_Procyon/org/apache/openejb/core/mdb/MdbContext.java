// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.mdb;

import org.apache.openejb.core.Operation;
import org.apache.openejb.core.ThreadContext;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.spi.SecurityService;
import javax.ejb.MessageDrivenContext;
import org.apache.openejb.core.BaseContext;

public class MdbContext extends BaseContext implements MessageDrivenContext
{
    public MdbContext(final SecurityService securityService) {
        super(securityService);
    }
    
    @Override
    public EJBHome getEJBHome() {
        throw new IllegalStateException();
    }
    
    @Override
    public EJBLocalHome getEJBLocalHome() {
        throw new IllegalStateException();
    }
    
    public void check(final ThreadContext context, final Call call) {
        final Operation operation = context.getCurrentOperation();
        switch (call) {
            case getUserTransaction:
            case getTimerService:
            case getContextData: {
                switch (operation) {
                    case INJECTION: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            case getCallerPrincipal:
            case isCallerInRole:
            case timerMethod:
            case setRollbackOnly:
            case getRollbackOnly: {
                switch (operation) {
                    case INJECTION:
                    case CREATE:
                    case POST_CONSTRUCT:
                    case PRE_DESTROY: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            default: {}
        }
    }
}
