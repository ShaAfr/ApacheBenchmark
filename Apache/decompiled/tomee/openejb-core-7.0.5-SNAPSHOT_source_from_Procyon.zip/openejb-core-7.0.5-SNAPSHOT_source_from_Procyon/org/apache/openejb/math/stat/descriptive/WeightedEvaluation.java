// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive;

public interface WeightedEvaluation
{
    double evaluate(final double[] p0, final double[] p1);
    
    double evaluate(final double[] p0, final double[] p1, final int p2, final int p3);
}
