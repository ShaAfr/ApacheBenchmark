// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;

public class ObjectReference extends Reference
{
    private final Object obj;
    
    public ObjectReference(final Object obj) {
        this.obj = obj;
    }
    
    @Override
    public Object getObject() throws NamingException {
        return this.obj;
    }
}
