// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class ManagedBeanInfo extends EnterpriseBeanInfo
{
    public final List<CallbackInfo> postActivate;
    public final List<CallbackInfo> prePassivate;
    public final List<RemoveMethodInfo> removeMethods;
    public boolean hidden;
    
    public ManagedBeanInfo() {
        this.postActivate = new ArrayList<CallbackInfo>();
        this.prePassivate = new ArrayList<CallbackInfo>();
        this.removeMethods = new ArrayList<RemoveMethodInfo>();
        this.type = 5;
    }
}
