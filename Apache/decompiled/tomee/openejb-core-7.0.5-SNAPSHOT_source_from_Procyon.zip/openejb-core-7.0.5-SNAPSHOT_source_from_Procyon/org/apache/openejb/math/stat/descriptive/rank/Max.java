// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive.rank;

import org.apache.openejb.math.stat.descriptive.UnivariateStatistic;
import org.apache.openejb.math.stat.descriptive.StorelessUnivariateStatistic;
import java.io.Serializable;
import org.apache.openejb.math.stat.descriptive.AbstractStorelessUnivariateStatistic;

public class Max extends AbstractStorelessUnivariateStatistic implements Serializable
{
    private static final long serialVersionUID = -1233383832225844641L;
    private long n;
    private double value;
    
    public Max() {
        this.n = 0L;
        this.value = Double.NaN;
    }
    
    public Max(final Max original) {
        copy(original, this);
    }
    
    @Override
    public void increment(final double d) {
        if (d > this.value || Double.isNaN(this.value)) {
            this.value = d;
        }
        ++this.n;
    }
    
    @Override
    public void clear() {
        this.value = Double.NaN;
        this.n = 0L;
    }
    
    @Override
    public double getResult() {
        return this.value;
    }
    
    @Override
    public long getN() {
        return this.n;
    }
    
    @Override
    public double evaluate(final double[] values, final int begin, final int length) {
        double max = Double.NaN;
        if (this.test(values, begin, length)) {
            max = values[begin];
            for (int i = begin; i < begin + length; ++i) {
                if (!Double.isNaN(values[i])) {
                    max = ((max > values[i]) ? max : values[i]);
                }
            }
        }
        return max;
    }
    
    @Override
    public Max copy() {
        final Max result = new Max();
        copy(this, result);
        return result;
    }
    
    public static void copy(final Max source, final Max dest) {
        dest.n = source.n;
        dest.value = source.value;
    }
}
