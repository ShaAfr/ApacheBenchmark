// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;
import javax.xml.ws.Service;
import javax.xml.namespace.QName;
import java.util.WeakHashMap;

public class ServiceRefData
{
    private static final WeakHashMap<Object, ServiceRefData> registry;
    private final String id;
    private final QName serviceQName;
    private final Class<? extends Service> serviceClass;
    private final QName portQName;
    private final Class<?> referenceClass;
    private final URL wsdlURL;
    private final List<HandlerChainData> handlerChains;
    private final List<PortRefData> portRefs;
    
    public static ServiceRefData getServiceRefData(final Object key) {
        return ServiceRefData.registry.get(key);
    }
    
    public static ServiceRefData putServiceRefData(final Object key, final ServiceRefData value) {
        return ServiceRefData.registry.put(key, value);
    }
    
    public ServiceRefData(final String id, final QName serviceQName, final Class<? extends Service> serviceClass, final QName portQName, final Class<?> referenceClass, final URL wsdlURL, final List<HandlerChainData> handlerChains, final List<PortRefData> portRefs) {
        this.handlerChains = new ArrayList<HandlerChainData>();
        this.portRefs = new ArrayList<PortRefData>();
        this.id = id;
        this.serviceQName = serviceQName;
        this.serviceClass = serviceClass;
        this.portQName = portQName;
        this.referenceClass = referenceClass;
        this.wsdlURL = wsdlURL;
        if (handlerChains != null) {
            this.handlerChains.addAll(handlerChains);
        }
        if (portRefs != null) {
            this.portRefs.addAll(portRefs);
        }
    }
    
    public String getId() {
        return this.id;
    }
    
    public QName getServiceQName() {
        return this.serviceQName;
    }
    
    public Class<? extends Service> getServiceClass() {
        return this.serviceClass;
    }
    
    public QName getPortQName() {
        return this.portQName;
    }
    
    public Class<?> getReferenceClass() {
        return this.referenceClass;
    }
    
    public URL getWsdlURL() {
        return this.wsdlURL;
    }
    
    public List<HandlerChainData> getHandlerChains() {
        return this.handlerChains;
    }
    
    public List<PortRefData> getPortRefs() {
        return this.portRefs;
    }
    
    static {
        registry = new WeakHashMap<Object, ServiceRefData>();
    }
}
