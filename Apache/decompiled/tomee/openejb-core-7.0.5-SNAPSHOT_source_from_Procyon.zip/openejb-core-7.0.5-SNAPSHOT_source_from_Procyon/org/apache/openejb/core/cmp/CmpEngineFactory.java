// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import org.apache.openejb.OpenEJBException;
import javax.transaction.TransactionSynchronizationRegistry;
import javax.transaction.TransactionManager;

public interface CmpEngineFactory
{
    TransactionManager getTransactionManager();
    
    void setTransactionManager(final TransactionManager p0);
    
    void setTransactionSynchronizationRegistry(final TransactionSynchronizationRegistry p0);
    
    void setCmpCallback(final CmpCallback p0);
    
    CmpEngine create() throws OpenEJBException;
}
