// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import javax.naming.InitialContext;

public class JndiUrlReference extends Reference
{
    private final String jndiName;
    
    public JndiUrlReference(final String jndiName) {
        this.jndiName = jndiName;
    }
    
    @Override
    public Object getObject() throws NamingException {
        return new InitialContext().lookup(this.jndiName);
    }
    
    public String getJndiName() {
        return this.jndiName;
    }
}
