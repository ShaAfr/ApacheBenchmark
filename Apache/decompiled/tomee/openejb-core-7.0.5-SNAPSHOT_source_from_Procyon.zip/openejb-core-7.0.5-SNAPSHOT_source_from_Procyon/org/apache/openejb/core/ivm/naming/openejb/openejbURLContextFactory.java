// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming.openejb;

import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.naming.NamingException;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.spi.ObjectFactory;

public class openejbURLContextFactory implements ObjectFactory
{
    @Override
    public Object getObjectInstance(final Object obj, final Name name, final Context nameCtx, final Hashtable env) throws NamingException {
        return getContext();
    }
    
    public static Context getContext() throws NamingException {
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        final Context context = (Context)containerSystem.getJNDIContext().lookup("openejb");
        return context;
    }
}
