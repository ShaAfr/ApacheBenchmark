// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jacc;

import javax.security.jacc.PolicyContext;
import java.security.Permission;
import java.security.ProtectionDomain;
import java.security.PermissionCollection;
import java.security.CodeSource;
import javax.security.jacc.PolicyContextException;
import javax.security.jacc.PolicyConfiguration;
import java.util.HashMap;
import java.security.Policy;
import java.util.Map;
import org.apache.openejb.core.security.JaccProvider;

public class BasicJaccProvider extends JaccProvider
{
    private final Map<String, BasicPolicyConfiguration> configurations;
    private final java.security.Policy systemPolicy;
    
    public BasicJaccProvider() {
        this.configurations = new HashMap<String, BasicPolicyConfiguration>();
        this.systemPolicy = java.security.Policy.getPolicy();
    }
    
    @Override
    public PolicyConfiguration getPolicyConfiguration(final String contextID, final boolean remove) throws PolicyContextException {
        BasicPolicyConfiguration configuration = this.configurations.get(contextID);
        if (configuration == null) {
            configuration = this.createPolicyConfiguration(contextID);
            this.configurations.put(contextID, configuration);
        }
        else {
            configuration.open(remove);
        }
        return (PolicyConfiguration)configuration;
    }
    
    protected BasicPolicyConfiguration createPolicyConfiguration(final String contextID) {
        return new BasicPolicyConfiguration(contextID);
    }
    
    @Override
    public boolean inService(final String contextID) throws PolicyContextException {
        final PolicyConfiguration configuration = this.getPolicyConfiguration(contextID, false);
        return configuration.inService();
    }
    
    @Override
    public PermissionCollection getPermissions(final CodeSource codesource) {
        return (this.systemPolicy == null) ? null : this.systemPolicy.getPermissions(codesource);
    }
    
    @Override
    public void refresh() {
    }
    
    @Override
    public boolean implies(final ProtectionDomain domain, final Permission permission) {
        final String contextID = PolicyContext.getContextID();
        if (contextID != null) {
            try {
                final BasicPolicyConfiguration configuration = this.configurations.get(contextID);
                return configuration != null && configuration.inService() && configuration.implies(domain, permission);
            }
            catch (PolicyContextException ex) {}
        }
        return this.systemPolicy != null && this.systemPolicy.implies(domain, permission);
    }
    
    static {
        try {
            Class.forName(PolicyContext.class.getName());
        }
        catch (ClassNotFoundException ex) {}
    }
}
