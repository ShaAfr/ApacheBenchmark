// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.util.concurrent.locks.ReentrantLock;
import org.apache.openejb.util.LogCategory;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Iterator;
import org.apache.openejb.OpenEJBRuntimeException;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import org.apache.openejb.util.Duration;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.openejb.util.Logger;

public class SimpleCache<K, V> implements Cache<K, V>
{
    public static final Logger logger;
    private final ConcurrentHashMap<K, Entry> cache;
    private final Queue<Entry> lru;
    private CacheListener<V> listener;
    private PassivationStrategy passivator;
    private int capacity;
    private int bulkPassivate;
    private long timeOut;
    private ScheduledExecutorService executor;
    private long frequency;
    private ScheduledFuture future;
    
    public SimpleCache() {
        this.cache = new ConcurrentHashMap<K, Entry>();
        this.lru = new LinkedBlockingQueue<Entry>();
        this.timeOut = -1L;
        this.frequency = 60000L;
    }
    
    public SimpleCache(final CacheListener<V> listener, final PassivationStrategy passivator, final int capacity, final int bulkPassivate, final Duration timeOut) {
        this.cache = new ConcurrentHashMap<K, Entry>();
        this.lru = new LinkedBlockingQueue<Entry>();
        this.timeOut = -1L;
        this.frequency = 60000L;
        this.listener = listener;
        this.passivator = passivator;
        this.capacity = capacity;
        this.bulkPassivate = bulkPassivate;
        this.timeOut = timeOut.getTime(TimeUnit.MILLISECONDS);
    }
    
    @Override
    public synchronized void init() {
        if (this.frequency > 0L && this.future == null) {
            this.initScheduledExecutorService();
            final ClassLoader loader = Thread.currentThread().getContextClassLoader();
            Thread.currentThread().setContextClassLoader(SimpleCache.class.getClassLoader());
            try {
                this.future = this.executor.scheduleWithFixedDelay(new Runnable() {
                    @Override
                    public void run() {
                        SimpleCache.this.processLRU();
                    }
                }, this.frequency, this.frequency, TimeUnit.MILLISECONDS);
            }
            finally {
                Thread.currentThread().setContextClassLoader(loader);
            }
        }
    }
    
    @Override
    public synchronized void destroy() {
        if (this.future != null) {
            this.future.cancel(false);
        }
    }
    
    private synchronized void initScheduledExecutorService() {
        if (this.executor == null) {
            this.executor = Executors.newScheduledThreadPool(1, new ThreadFactory() {
                @Override
                public Thread newThread(final Runnable runable) {
                    final Thread t = new Thread(runable, "Stateful cache");
                    t.setDaemon(true);
                    return t;
                }
            });
        }
    }
    
    @Override
    public synchronized CacheListener<V> getListener() {
        return this.listener;
    }
    
    @Override
    public synchronized void setListener(final CacheListener<V> listener) {
        this.listener = listener;
    }
    
    public synchronized PassivationStrategy getPassivator() {
        return this.passivator;
    }
    
    public synchronized void setPassivator(final PassivationStrategy passivator) {
        this.passivator = passivator;
    }
    
    public synchronized void setPassivator(final Class<? extends PassivationStrategy> passivatorClass) throws Exception {
        this.passivator = (PassivationStrategy)passivatorClass.newInstance();
    }
    
    public synchronized int getCapacity() {
        return this.capacity;
    }
    
    public synchronized void setCapacity(final int capacity) {
        this.capacity = capacity;
    }
    
    public synchronized void setPoolSize(final int capacity) {
        this.capacity = capacity;
    }
    
    public synchronized int getBulkPassivate() {
        return this.bulkPassivate;
    }
    
    public synchronized void setBulkPassivate(final int bulkPassivate) {
        this.bulkPassivate = bulkPassivate;
    }
    
    public synchronized long getTimeOut() {
        return this.timeOut;
    }
    
    private static long ms(final String durationValue, final TimeUnit defaultTU) {
        final Duration duration = new Duration(durationValue.trim());
        if (duration.getUnit() == null) {
            duration.setUnit(defaultTU);
        }
        return duration.getUnit().toMillis(duration.getTime());
    }
    
    public synchronized void setTimeOut(final String timeOut) {
        this.timeOut = ms(timeOut, TimeUnit.MINUTES);
    }
    
    public void setScheduledExecutorService(final ScheduledExecutorService executor) {
        this.executor = executor;
    }
    
    public ScheduledExecutorService getScheduledExecutorService() {
        return this.executor;
    }
    
    public void setFrequency(final String frequency) {
        this.frequency = ms(frequency, TimeUnit.SECONDS);
    }
    
    public long getFrequency() {
        return this.frequency;
    }
    
    @Override
    public void add(final K key, final V value) {
        Entry entry = this.cache.get(key);
        if (entry != null) {
            entry.lock.lock();
            try {
                if (entry.getState() != EntryState.REMOVED) {
                    throw new IllegalStateException("An entry for the key " + key + " already exists");
                }
                this.cache.remove(key);
                this.lru.remove(entry);
            }
            finally {
                entry.lock.unlock();
            }
        }
        entry = new Entry((Object)key, (Object)value, EntryState.CHECKED_OUT);
        this.cache.put(key, entry);
    }
    
    @Override
    public V checkOut(final K key, final boolean loadEntryIfNotFound) throws Exception {
        for (int i = 0; i < 10; ++i) {
            Entry entry = this.cache.get(key);
            if (!loadEntryIfNotFound && entry == null) {
                return null;
            }
            if (entry == null) {
                entry = this.loadEntry(key);
                if (entry == null) {
                    return null;
                }
            }
            entry.lock.lock();
            try {
                switch (entry.getState()) {
                    case CHECKED_OUT: {
                        return (V)entry.getValue();
                    }
                    case PASSIVATED: {
                        this.cache.remove(key, entry);
                        continue;
                    }
                    case REMOVED: {
                        return null;
                    }
                }
                entry.setState(EntryState.CHECKED_OUT);
                this.lru.remove(entry);
                return (V)entry.getValue();
            }
            finally {
                entry.lock.unlock();
            }
        }
        final Entry entry2 = this.cache.remove(key);
        if (entry2 != null) {
            this.lru.remove(entry2);
        }
        throw new OpenEJBRuntimeException("Cache is corrupted: the entry " + key + " in the Map 'cache' is in state PASSIVATED");
    }
    
    @Override
    public void checkIn(final K key) {
        final Entry entry = this.cache.get(key);
        if (entry == null) {
            return;
        }
        entry.lock.lock();
        try {
            switch (entry.getState()) {
                case AVAILABLE: {
                    if (this.lru.contains(entry)) {
                        entry.resetTimeOut();
                        return;
                    }
                    throw new IllegalStateException("The entry " + key + " is not checked-out");
                }
                case PASSIVATED: {
                    throw new IllegalStateException("The entry " + key + " is not checked-out");
                }
                case REMOVED: {
                    return;
                }
                default: {
                    entry.setState(EntryState.AVAILABLE);
                    this.lru.add(entry);
                    entry.resetTimeOut();
                    break;
                }
            }
        }
        finally {
            entry.lock.unlock();
        }
        if (this.frequency == 0L) {
            this.processLRU();
        }
    }
    
    @Override
    public V remove(final K key) {
        final Entry entry = this.cache.get(key);
        if (entry == null) {
            return null;
        }
        entry.lock.lock();
        try {
            this.cache.remove(key);
            this.lru.remove(entry);
            entry.setState(EntryState.REMOVED);
            return (V)entry.getValue();
        }
        finally {
            entry.lock.unlock();
        }
    }
    
    @Override
    public void removeAll(final CacheFilter<V> filter) {
        final Iterator<Entry> iterator = this.cache.values().iterator();
        while (iterator.hasNext()) {
            final Entry entry = iterator.next();
            entry.lock.lock();
            try {
                if (!filter.matches((V)entry.getValue())) {
                    continue;
                }
                iterator.remove();
                this.lru.remove(entry);
                entry.setState(EntryState.REMOVED);
            }
            finally {
                entry.lock.unlock();
            }
        }
    }
    
    public void processLRU() {
        final CacheListener<V> listener = this.getListener();
        final Iterator<Entry> iterator = this.lru.iterator();
        while (iterator.hasNext()) {
            final Entry entry = iterator.next();
            entry.lock.lock();
            try {
                switch (entry.getState()) {
                    case CHECKED_OUT: {
                        continue;
                    }
                    case PASSIVATED: {
                        iterator.remove();
                        continue;
                    }
                    case REMOVED: {
                        iterator.remove();
                        continue;
                    }
                }
                if (!entry.isTimedOut()) {
                    continue;
                }
                iterator.remove();
                this.cache.remove(entry.getKey());
                entry.setState(EntryState.REMOVED);
                if (listener == null) {
                    continue;
                }
                try {
                    listener.timedOut((V)entry.getValue());
                }
                catch (Exception e) {
                    SimpleCache.logger.error("An unexpected exception occured from timedOut callback", e);
                }
            }
            finally {
                entry.lock.unlock();
            }
        }
        if (this.lru.size() >= this.getCapacity()) {
            final Map<K, V> valuesToStore = new LinkedHashMap<K, V>();
            final List<Entry> entries = new ArrayList<Entry>();
            int bulkPassivate = this.getBulkPassivate();
            if (bulkPassivate < 1) {
                bulkPassivate = 1;
            }
            for (int i = 0; i < bulkPassivate; ++i) {
                final Entry entry2 = this.lru.poll();
                if (entry2 == null) {
                    break;
                }
                if (entry2.lock.tryLock()) {
                    try {
                        switch (entry2.getState()) {
                            case CHECKED_OUT: {
                                continue;
                            }
                            case PASSIVATED: {
                                this.lru.remove(entry2);
                                continue;
                            }
                            case REMOVED: {
                                this.lru.remove(entry2);
                                continue;
                            }
                        }
                        this.cache.remove(entry2.getKey());
                        this.lru.remove(entry2);
                        if (entry2.isTimedOut()) {
                            entry2.setState(EntryState.REMOVED);
                            if (listener != null) {
                                try {
                                    listener.timedOut((V)entry2.getValue());
                                }
                                catch (Exception e2) {
                                    SimpleCache.logger.error("An unexpected exception occured from timedOut callback", e2);
                                }
                            }
                        }
                        else {
                            entry2.lock.lock();
                            entries.add(entry2);
                            entry2.setState(EntryState.PASSIVATED);
                            valuesToStore.put((K)entry2.getKey(), (V)entry2.getValue());
                        }
                    }
                    finally {
                        entry2.lock.unlock();
                    }
                }
            }
            if (!valuesToStore.isEmpty()) {
                try {
                    this.storeEntries(valuesToStore);
                }
                finally {
                    for (final Entry entry3 : entries) {
                        entry3.lock.unlock();
                    }
                }
            }
        }
    }
    
    private Entry loadEntry(final K key) throws Exception {
        final PassivationStrategy passivator = this.getPassivator();
        if (passivator == null) {
            return null;
        }
        V value = null;
        try {
            value = (V)passivator.activate(key);
        }
        catch (Exception e) {
            SimpleCache.logger.error("An unexpected exception occured while reading entries from disk", e);
        }
        if (value == null) {
            return null;
        }
        final CacheListener<V> listener = this.getListener();
        if (listener != null) {
            listener.afterLoad(value);
        }
        final Entry entry = new Entry((Object)key, (Object)value, EntryState.AVAILABLE);
        this.cache.put(key, entry);
        return entry;
    }
    
    private void storeEntries(final Map<K, V> entriesToStore) {
        final CacheListener<V> listener = this.getListener();
        final Iterator<Map.Entry<K, V>> iterator = entriesToStore.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry<K, V> entry = iterator.next();
            if (listener != null) {
                try {
                    listener.beforeStore(entry.getValue());
                }
                catch (Exception e) {
                    iterator.remove();
                    SimpleCache.logger.error("An unexpected exception occured from beforeStore callback", e);
                }
            }
        }
        final PassivationStrategy passivator = this.getPassivator();
        if (passivator == null) {
            return;
        }
        try {
            passivator.passivate(entriesToStore);
        }
        catch (Exception e2) {
            SimpleCache.logger.error("An unexpected exception occured while writting the entries to disk", e2);
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
    
    private enum EntryState
    {
        AVAILABLE, 
        CHECKED_OUT, 
        PASSIVATED, 
        REMOVED;
    }
    
    private final class Entry
    {
        private final K key;
        private final V value;
        private final ReentrantLock lock;
        private EntryState state;
        private long lastAccess;
        private final long timeOut;
        
        private Entry(final K key, final V value, final EntryState state) {
            this.lock = new ReentrantLock();
            this.key = key;
            this.value = value;
            this.state = state;
            if (value instanceof TimeOut) {
                final Duration duration = ((TimeOut)value).getTimeOut();
                this.timeOut = ((duration != null) ? duration.getTime(TimeUnit.MILLISECONDS) : SimpleCache.this.getTimeOut());
            }
            else {
                this.timeOut = SimpleCache.this.getTimeOut();
            }
            this.lastAccess = System.currentTimeMillis();
        }
        
        private K getKey() {
            this.assertLockHeld();
            return this.key;
        }
        
        private V getValue() {
            this.assertLockHeld();
            return this.value;
        }
        
        private EntryState getState() {
            this.assertLockHeld();
            return this.state;
        }
        
        private void setState(final EntryState state) {
            this.assertLockHeld();
            this.state = state;
        }
        
        private boolean isTimedOut() {
            this.assertLockHeld();
            if (this.timeOut < 0L) {
                return false;
            }
            if (this.timeOut == 0L) {
                return true;
            }
            final long now = System.currentTimeMillis();
            return now - this.lastAccess > this.timeOut;
        }
        
        private void resetTimeOut() {
            this.assertLockHeld();
            if (this.timeOut > 0L) {
                this.lastAccess = System.currentTimeMillis();
            }
        }
        
        private void assertLockHeld() {
            if (!this.lock.isHeldByCurrentThread()) {
                throw new IllegalStateException("Entry must be locked");
            }
        }
    }
}
