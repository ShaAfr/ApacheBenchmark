// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class TimeoutInfo extends InfoObject
{
    public long time;
    public String unit;
}
