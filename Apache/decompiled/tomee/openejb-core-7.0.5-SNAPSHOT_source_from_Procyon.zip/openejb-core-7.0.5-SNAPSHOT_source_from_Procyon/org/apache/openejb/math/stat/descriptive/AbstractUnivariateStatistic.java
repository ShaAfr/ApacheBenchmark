// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive;

import org.apache.openejb.math.MathRuntimeException;

public abstract class AbstractUnivariateStatistic implements UnivariateStatistic
{
    @Override
    public double evaluate(final double[] values) {
        this.test(values, 0, 0);
        return this.evaluate(values, 0, values.length);
    }
    
    @Override
    public abstract double evaluate(final double[] p0, final int p1, final int p2);
    
    @Override
    public abstract UnivariateStatistic copy();
    
    protected boolean test(final double[] values, final int begin, final int length) {
        if (values == null) {
            throw MathRuntimeException.createIllegalArgumentException("input values array is null", new Object[0]);
        }
        if (begin < 0) {
            throw MathRuntimeException.createIllegalArgumentException("start position cannot be negative ({0})", begin);
        }
        if (length < 0) {
            throw MathRuntimeException.createIllegalArgumentException("length cannot be negative ({0})", length);
        }
        if (begin + length > values.length) {
            throw MathRuntimeException.createIllegalArgumentException("subarray ends after array end", new Object[0]);
        }
        return length != 0;
    }
    
    protected boolean test(final double[] values, final double[] weights, final int begin, final int length) {
        if (weights == null) {
            throw MathRuntimeException.createIllegalArgumentException("input weights array is null", new Object[0]);
        }
        if (weights.length != values.length) {
            throw MathRuntimeException.createIllegalArgumentException("Different number of weights and values", new Object[0]);
        }
        boolean containsPositiveWeight = false;
        for (int i = begin; i < begin + length; ++i) {
            if (Double.isNaN(weights[i])) {
                throw MathRuntimeException.createIllegalArgumentException("NaN weight at index {0}", i);
            }
            if (Double.isInfinite(weights[i])) {
                throw MathRuntimeException.createIllegalArgumentException("Infinite weight at index {0}", i);
            }
            if (weights[i] < 0.0) {
                throw MathRuntimeException.createIllegalArgumentException("negative weight {0} at index {1} ", weights[i], i);
            }
            if (!containsPositiveWeight && weights[i] > 0.0) {
                containsPositiveWeight = true;
            }
        }
        if (!containsPositiveWeight) {
            throw MathRuntimeException.createIllegalArgumentException("weight array must contain at least one non-zero value", new Object[0]);
        }
        return this.test(values, begin, length);
    }
}
