// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Properties;

public class ResourceReferenceInfo extends InjectableInfo
{
    public String referenceType;
    public String referenceAuth;
    public String resourceID;
    public Properties properties;
}
