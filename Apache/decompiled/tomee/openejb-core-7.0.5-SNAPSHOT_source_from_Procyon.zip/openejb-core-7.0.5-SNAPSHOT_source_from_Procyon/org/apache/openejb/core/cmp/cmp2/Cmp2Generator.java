// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import java.util.HashMap;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.xbean.asm5.Label;
import org.apache.xbean.asm5.MethodVisitor;
import java.util.Iterator;
import org.apache.xbean.asm5.FieldVisitor;
import javax.ejb.EntityContext;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Collection;
import java.util.Map;
import org.apache.xbean.asm5.ClassWriter;
import org.apache.xbean.asm5.Type;
import org.apache.xbean.asm5.Opcodes;

public class Cmp2Generator implements Opcodes
{
    private static final String UNKNOWN_PK_NAME = "OpenEJB_pk";
    private static final Type UNKNOWN_PK_TYPE;
    private final String implClassName;
    private final String beanClassName;
    private final ClassWriter cw;
    private final Map<String, CmpField> cmpFields;
    private final Collection<CmrField> cmrFields;
    private final CmpField pkField;
    private final Class primKeyClass;
    private final List<Method> selectMethods;
    private final Class beanClass;
    private final PostCreateGenerator postCreateGenerator;
    private static final String DELETED = "openejb_deleted";
    
    public Cmp2Generator(final String cmpImplClass, final Class beanClass, final String pkField, final Class<?> primKeyClass, final String[] cmpFields) {
        this.cmpFields = new LinkedHashMap<String, CmpField>();
        this.cmrFields = new ArrayList<CmrField>();
        this.selectMethods = new ArrayList<Method>();
        this.beanClass = beanClass;
        this.beanClassName = Type.getInternalName(beanClass);
        this.implClassName = cmpImplClass.replace('.', '/');
        if (pkField == null && primKeyClass == null) {
            throw new NullPointerException("Both pkField and primKeyClass are null for bean " + this.beanClassName);
        }
        this.primKeyClass = primKeyClass;
        for (final String cmpFieldName : cmpFields) {
            final Method getter = this.getterMethod(cmpFieldName);
            if (getter == null) {
                throw new IllegalArgumentException("No such property " + cmpFieldName + " defined on bean class " + this.beanClassName);
            }
            Label_0310: {
                if (!Modifier.isAbstract(getter.getModifiers())) {
                    try {
                        final Field field = getter.getDeclaringClass().getDeclaredField(cmpFieldName);
                        if (Modifier.isPrivate(field.getModifiers())) {
                            break Label_0310;
                        }
                    }
                    catch (NoSuchFieldException ex) {}
                    throw new IllegalArgumentException("No such property " + cmpFieldName + " defined on bean class " + this.beanClassName);
                }
                final Type type = Type.getType((Class)getter.getReturnType());
                final CmpField cmpField = new CmpField(cmpFieldName, type, getter);
                this.cmpFields.put(cmpFieldName, cmpField);
            }
        }
        if (pkField != null) {
            this.pkField = this.cmpFields.get(pkField);
            if (this.pkField == null) {
                throw new IllegalArgumentException("No such property " + pkField + " defined on bean class " + this.beanClassName);
            }
        }
        else {
            this.pkField = null;
        }
        for (final Method method : beanClass.getMethods()) {
            if (Modifier.isAbstract(method.getModifiers()) && method.getName().startsWith("ejbSelect")) {
                this.addSelectMethod(method);
            }
        }
        this.cw = new ClassWriter(1);
        this.postCreateGenerator = new PostCreateGenerator(beanClass, this.cw);
    }
    
    public void addCmrField(final CmrField cmrField) {
        if (this.cmpFields.get(cmrField.getName()) != null) {
            this.cmpFields.remove(cmrField.getName());
        }
        this.cmrFields.add(cmrField);
    }
    
    public void addSelectMethod(final Method selectMethod) {
        this.selectMethods.add(selectMethod);
    }
    
    public byte[] generate() {
        this.cw.visit(49, 33, this.implClassName, (String)null, this.beanClassName, new String[] { "org/apache/openejb/core/cmp/cmp2/Cmp2Entity", "javax/ejb/EntityBean" });
        FieldVisitor fv = this.cw.visitField(9, "deploymentInfo", "Ljava/lang/Object;", (String)null, (Object)null);
        fv.visitEnd();
        fv = this.cw.visitField(194, "openejb_deleted", "Z", (String)null, (Object)null);
        fv.visitEnd();
        if (Object.class.equals(this.primKeyClass)) {
            fv = this.cw.visitField(2, "OpenEJB_pk", Cmp2Generator.UNKNOWN_PK_TYPE.getDescriptor(), (String)null, (Object)null);
            fv.visitEnd();
        }
        for (final CmpField cmpField : this.cmpFields.values()) {
            this.createField(cmpField);
        }
        for (final CmrField cmrField : this.cmrFields) {
            this.createCmrFields(cmrField);
        }
        this.createConstructor();
        for (final CmpField cmpField : this.cmpFields.values()) {
            this.createGetter(cmpField);
            this.createSetter(cmpField);
        }
        for (final CmrField cmrField : this.cmrFields) {
            this.createCmrGetter(cmrField);
            this.createCmrSetter(cmrField);
        }
        this.createSimplePrimaryKeyGetter();
        this.createOpenEJB_isDeleted();
        this.createOpenEJB_deleted();
        this.createOpenEJB_addCmr();
        this.createOpenEJB_removeCmr();
        for (final Method selectMethod : this.selectMethods) {
            this.createSelectMethod(selectMethod);
        }
        if (!this.hasMethod(this.beanClass, "ejbActivate", new Class[0])) {
            this.createEjbActivate();
        }
        if (!this.hasMethod(this.beanClass, "ejbPassivate", new Class[0])) {
            this.createEjbPassivate();
        }
        if (!this.hasMethod(this.beanClass, "ejbLoad", new Class[0])) {
            this.createEjbLoad();
        }
        if (!this.hasMethod(this.beanClass, "ejbStore", new Class[0])) {
            this.createEjbStore();
        }
        if (!this.hasMethod(this.beanClass, "ejbRemove", new Class[0])) {
            this.createEjbRemove();
        }
        if (!this.hasMethod(this.beanClass, "setEntityContext", EntityContext.class)) {
            this.createSetEntityContext();
        }
        if (!this.hasMethod(this.beanClass, "unsetEntityContext", new Class[0])) {
            this.createUnsetEntityContext();
        }
        this.postCreateGenerator.generate();
        this.cw.visitEnd();
        return this.cw.toByteArray();
    }
    
    private boolean hasMethod(final Class beanClass, final String name, final Class... args) {
        try {
            final Method method = beanClass.getMethod(name, (Class[])args);
            return !Modifier.isAbstract(method.getModifiers());
        }
        catch (NoSuchMethodException e) {
            return false;
        }
    }
    
    private void createConstructor() {
        final MethodVisitor mv = this.cw.visitMethod(1, "<init>", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitMethodInsn(183, this.beanClassName, "<init>", "()V", false);
        for (final CmrField cmrField : this.cmrFields) {
            this.initCmrFields(mv, cmrField);
        }
        mv.visitInsn(177);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createOpenEJB_isDeleted() {
        final MethodVisitor mv = this.cw.visitMethod(1, "OpenEJB_isDeleted", "()Z", (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, "openejb_deleted", "Z");
        mv.visitInsn(172);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createOpenEJB_deleted() {
        final MethodVisitor mv = this.cw.visitMethod(1, "OpenEJB_deleted", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, "openejb_deleted", "Z");
        final Label notDeleted = new Label();
        mv.visitJumpInsn(153, notDeleted);
        mv.visitInsn(177);
        mv.visitLabel(notDeleted);
        mv.visitVarInsn(25, 0);
        mv.visitInsn(4);
        mv.visitFieldInsn(181, this.implClassName, "openejb_deleted", "Z");
        for (final CmrField cmrField : this.cmrFields) {
            this.createOpenEJB_deleted(mv, cmrField);
        }
        mv.visitInsn(177);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createOpenEJB_addCmr() {
        final MethodVisitor mv = this.cw.visitMethod(1, "OpenEJB_addCmr", "(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;", (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, "openejb_deleted", "Z");
        final Label notDeleted = new Label();
        mv.visitJumpInsn(153, notDeleted);
        mv.visitInsn(1);
        mv.visitInsn(176);
        mv.visitLabel(notDeleted);
        for (final CmrField cmrField : this.cmrFields) {
            this.createOpenEJB_addCmr(mv, cmrField);
        }
        mv.visitTypeInsn(187, "java/lang/IllegalArgumentException");
        mv.visitInsn(89);
        mv.visitTypeInsn(187, "java/lang/StringBuilder");
        mv.visitInsn(89);
        mv.visitMethodInsn(183, "java/lang/StringBuilder", "<init>", "()V", false);
        mv.visitLdcInsn((Object)"Unknown cmr field ");
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitVarInsn(25, 1);
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitLdcInsn((Object)" on entity bean of type ");
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitVarInsn(25, 0);
        mv.visitMethodInsn(182, "java/lang/Object", "getClass", "()Ljava/lang/Class;", false);
        mv.visitMethodInsn(182, "java/lang/Class", "getName", "()Ljava/lang/String;", false);
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;", false);
        mv.visitMethodInsn(183, "java/lang/IllegalArgumentException", "<init>", "(Ljava/lang/String;)V", false);
        mv.visitInsn(191);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createOpenEJB_removeCmr() {
        final MethodVisitor mv = this.cw.visitMethod(1, "OpenEJB_removeCmr", "(Ljava/lang/String;Ljava/lang/Object;)V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, "openejb_deleted", "Z");
        final Label notDeleted = new Label();
        mv.visitJumpInsn(153, notDeleted);
        mv.visitInsn(177);
        mv.visitLabel(notDeleted);
        for (final CmrField cmrField : this.cmrFields) {
            this.createOpenEJB_removeCmr(mv, cmrField);
        }
        mv.visitTypeInsn(187, "java/lang/IllegalArgumentException");
        mv.visitInsn(89);
        mv.visitTypeInsn(187, "java/lang/StringBuilder");
        mv.visitInsn(89);
        mv.visitMethodInsn(183, "java/lang/StringBuilder", "<init>", "()V", false);
        mv.visitLdcInsn((Object)"Unknown cmr field ");
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitVarInsn(25, 1);
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitLdcInsn((Object)" on entity bean of type ");
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitVarInsn(25, 0);
        mv.visitMethodInsn(182, "java/lang/Object", "getClass", "()Ljava/lang/Class;", false);
        mv.visitMethodInsn(182, "java/lang/Class", "getName", "()Ljava/lang/String;", false);
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false);
        mv.visitMethodInsn(182, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;", false);
        mv.visitMethodInsn(183, "java/lang/IllegalArgumentException", "<init>", "(Ljava/lang/String;)V", false);
        mv.visitInsn(191);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createField(final CmpField cmpField) {
        final FieldVisitor fv = this.cw.visitField(2, cmpField.getName(), cmpField.getDescriptor(), (String)null, (Object)null);
        fv.visitEnd();
    }
    
    private void createGetter(final CmpField cmpField) {
        final String methodName = cmpField.getGetterMethod().getName();
        final MethodVisitor mv = this.cw.visitMethod(1, methodName, "()" + cmpField.getDescriptor(), (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, cmpField.getName(), cmpField.getDescriptor());
        mv.visitInsn(cmpField.getType().getOpcode(172));
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private static String getterName(final String propertyName) {
        return "get" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
    }
    
    private Method getterMethod(final String propertyName) {
        String getterName = "get" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
        try {
            return this.beanClass.getMethod(getterName, (Class[])new Class[0]);
        }
        catch (NoSuchMethodException ex) {
            getterName = "is" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
            try {
                return this.beanClass.getMethod(getterName, (Class[])new Class[0]);
            }
            catch (NoSuchMethodException ex2) {
                return null;
            }
        }
    }
    
    private void createSetter(final CmpField cmpField) {
        final String methodName = this.setterName(cmpField.getName());
        final MethodVisitor mv = this.cw.visitMethod(1, methodName, "(" + cmpField.getDescriptor() + ")V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitVarInsn(cmpField.getType().getOpcode(21), 1);
        mv.visitFieldInsn(181, this.implClassName, cmpField.getName(), cmpField.getDescriptor());
        mv.visitInsn(177);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private String setterName(final String propertyName) {
        return "set" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
    }
    
    private void createSimplePrimaryKeyGetter() {
        final MethodVisitor mv = this.cw.visitMethod(1, "OpenEJB_getPrimaryKey", "()Ljava/lang/Object;", (String)null, (String[])null);
        mv.visitCode();
        if (this.pkField != null) {
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, this.pkField.getName(), this.pkField.getDescriptor());
            mv.visitInsn(this.pkField.getType().getOpcode(172));
        }
        else if (Object.class.equals(this.primKeyClass)) {
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, "OpenEJB_pk", Cmp2Generator.UNKNOWN_PK_TYPE.getDescriptor());
            mv.visitInsn(Cmp2Generator.UNKNOWN_PK_TYPE.getOpcode(172));
        }
        else {
            final String pkImplName = this.primKeyClass.getName().replace('.', '/');
            mv.visitTypeInsn(187, pkImplName);
            mv.visitInsn(89);
            mv.visitMethodInsn(183, pkImplName, "<init>", "()V", false);
            mv.visitVarInsn(58, 1);
            mv.visitVarInsn(25, 1);
            for (final Field field : this.primKeyClass.getFields()) {
                final CmpField cmpField = this.cmpFields.get(field.getName());
                if (cmpField != null) {
                    if (!cmpField.getType().getClassName().equals(field.getType().getName())) {
                        throw new IllegalArgumentException("Primary key " + cmpField.getName() + " is type " + cmpField.getType().getClassName() + " but CMP field is type " + field.getType().getName());
                    }
                    mv.visitVarInsn(25, 0);
                    mv.visitFieldInsn(180, this.implClassName, cmpField.getName(), cmpField.getDescriptor());
                    mv.visitFieldInsn(181, pkImplName, cmpField.getName(), cmpField.getDescriptor());
                    mv.visitVarInsn(25, 1);
                }
            }
            mv.visitInsn(176);
        }
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createCmrFields(final CmrField cmrField) {
        FieldVisitor fv = this.cw.visitField(2, cmrField.getName(), cmrField.getDescriptor(), cmrField.getGenericSignature(), (Object)null);
        fv.visitEnd();
        fv = this.cw.visitField(130, cmrField.getName() + "Cmr", cmrField.getAccessorDescriptor(), cmrField.getAccessorGenericSignature(), (Object)null);
        fv.visitEnd();
    }
    
    private void initCmrFields(final MethodVisitor mv, final CmrField cmrField) {
        final Type initialValueType = cmrField.getInitialValueType();
        if (initialValueType != null) {
            mv.visitVarInsn(25, 0);
            mv.visitTypeInsn(187, initialValueType.getInternalName());
            mv.visitInsn(89);
            mv.visitMethodInsn(183, initialValueType.getInternalName(), "<init>", "()V", false);
            mv.visitFieldInsn(181, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
        }
        mv.visitVarInsn(25, 0);
        mv.visitTypeInsn(187, cmrField.getAccessorInternalName());
        mv.visitInsn(89);
        mv.visitVarInsn(25, 0);
        mv.visitLdcInsn((Object)cmrField.getName());
        mv.visitLdcInsn((Object)cmrField.getType());
        if (cmrField.getRelatedName() != null) {
            mv.visitLdcInsn((Object)cmrField.getRelatedName());
        }
        else {
            mv.visitInsn(1);
        }
        mv.visitMethodInsn(183, cmrField.getAccessorInternalName(), "<init>", "(Ljavax/ejb/EntityBean;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/String;)V", false);
        mv.visitFieldInsn(181, this.implClassName, cmrField.getName() + "Cmr", cmrField.getAccessorDescriptor());
    }
    
    private void createCmrGetter(final CmrField cmrField) {
        if (cmrField.isSynthetic()) {
            return;
        }
        final String methodName = getterName(cmrField.getName());
        final MethodVisitor mv = this.cw.visitMethod(1, methodName, "()" + cmrField.getProxyDescriptor(), (String)null, (String[])null);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, cmrField.getName() + "Cmr", cmrField.getAccessorDescriptor());
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
        mv.visitMethodInsn(182, cmrField.getAccessorInternalName(), "get", cmrField.getCmrStyle().getGetterDescriptor(), false);
        if (cmrField.getCmrStyle() == CmrStyle.SINGLE) {
            mv.visitTypeInsn(192, cmrField.getProxyType().getInternalName());
        }
        mv.visitInsn(176);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createCmrSetter(final CmrField cmrField) {
        if (cmrField.isSynthetic()) {
            return;
        }
        final String methodName = this.setterName(cmrField.getName());
        final MethodVisitor mv = this.cw.visitMethod(1, methodName, "(" + cmrField.getProxyDescriptor() + ")V", (String)null, (String[])null);
        mv.visitCode();
        if (cmrField.getCmrStyle() != CmrStyle.SINGLE) {
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, cmrField.getName() + "Cmr", cmrField.getAccessorDescriptor());
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitVarInsn(25, 1);
            mv.visitMethodInsn(182, cmrField.getAccessorInternalName(), "set", cmrField.getCmrStyle().getSetterDescriptor(), false);
            mv.visitInsn(177);
        }
        else {
            mv.visitVarInsn(25, 0);
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, cmrField.getName() + "Cmr", cmrField.getAccessorDescriptor());
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitVarInsn(25, 1);
            mv.visitMethodInsn(182, cmrField.getAccessorInternalName(), "set", cmrField.getCmrStyle().getSetterDescriptor(), false);
            mv.visitTypeInsn(192, cmrField.getType().getInternalName());
            mv.visitFieldInsn(181, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitInsn(177);
        }
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private void createOpenEJB_deleted(final MethodVisitor mv, final CmrField cmrField) {
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, cmrField.getName() + "Cmr", cmrField.getAccessorDescriptor());
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(180, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
        mv.visitMethodInsn(182, cmrField.getAccessorInternalName(), "deleted", cmrField.getCmrStyle().getDeletedDescriptor(), false);
    }
    
    private void createOpenEJB_addCmr(final MethodVisitor mv, final CmrField cmrField) {
        mv.visitLdcInsn((Object)cmrField.getName());
        mv.visitVarInsn(25, 1);
        mv.visitMethodInsn(182, "java/lang/String", "equals", "(Ljava/lang/Object;)Z", false);
        final Label end = new Label();
        mv.visitJumpInsn(153, end);
        if (cmrField.getCmrStyle() != CmrStyle.SINGLE) {
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitVarInsn(58, 3);
            mv.visitVarInsn(25, 3);
            final Label fieldNotNull = new Label();
            mv.visitJumpInsn(199, fieldNotNull);
            mv.visitTypeInsn(187, cmrField.getInitialValueType().getInternalName());
            mv.visitInsn(89);
            mv.visitMethodInsn(183, cmrField.getInitialValueType().getInternalName(), "<init>", "()V", false);
            mv.visitVarInsn(58, 3);
            mv.visitLabel(fieldNotNull);
            mv.visitVarInsn(25, 3);
            mv.visitVarInsn(25, 2);
            mv.visitMethodInsn(185, cmrField.getCmrStyle().getCollectionType().getInternalName(), "add", "(Ljava/lang/Object;)Z", true);
            mv.visitInsn(87);
            mv.visitVarInsn(25, 0);
            mv.visitVarInsn(25, 3);
            mv.visitFieldInsn(181, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitInsn(1);
            mv.visitInsn(176);
        }
        else {
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitVarInsn(25, 0);
            mv.visitVarInsn(25, 2);
            mv.visitTypeInsn(192, cmrField.getType().getInternalName());
            mv.visitFieldInsn(181, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitInsn(176);
        }
        mv.visitLabel(end);
    }
    
    private void createOpenEJB_removeCmr(final MethodVisitor mv, final CmrField cmrField) {
        mv.visitLdcInsn((Object)cmrField.getName());
        mv.visitVarInsn(25, 1);
        mv.visitMethodInsn(182, "java/lang/String", "equals", "(Ljava/lang/Object;)Z", false);
        final Label end = new Label();
        mv.visitJumpInsn(153, end);
        if (cmrField.getCmrStyle() != CmrStyle.SINGLE) {
            mv.visitVarInsn(25, 0);
            mv.visitFieldInsn(180, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitVarInsn(25, 2);
            mv.visitMethodInsn(185, cmrField.getCmrStyle().getCollectionType().getInternalName(), "remove", "(Ljava/lang/Object;)Z", true);
            mv.visitInsn(87);
            mv.visitInsn(177);
        }
        else {
            mv.visitVarInsn(25, 0);
            mv.visitInsn(1);
            mv.visitFieldInsn(181, this.implClassName, cmrField.getName(), cmrField.getDescriptor());
            mv.visitInsn(177);
        }
        mv.visitLabel(end);
    }
    
    private void createSelectMethod(final Method selectMethod) {
        final Class<?> returnType = selectMethod.getReturnType();
        final Method executeMethod = EjbSelect.getSelectMethod(returnType);
        final MethodVisitor mv = this.cw.visitMethod(1, selectMethod.getName(), Type.getMethodDescriptor(selectMethod), (String)null, getExceptionTypes(selectMethod));
        mv.visitCode();
        mv.visitFieldInsn(178, this.implClassName, "deploymentInfo", "Ljava/lang/Object;");
        mv.visitLdcInsn((Object)this.getSelectMethodSignature(selectMethod));
        if (!returnType.isPrimitive()) {
            mv.visitLdcInsn((Object)returnType.getName());
        }
        mv.visitIntInsn(16, selectMethod.getParameterTypes().length);
        mv.visitTypeInsn(189, "java/lang/Object");
        int i = 0;
        for (final Class<?> parameterType : selectMethod.getParameterTypes()) {
            mv.visitInsn(89);
            bipush(mv, i);
            mv.visitVarInsn(Type.getType((Class)parameterType).getOpcode(21), i + 1);
            Convert.toObjectFrom(mv, parameterType);
            mv.visitInsn(83);
            if (Long.TYPE.equals(parameterType) || Double.TYPE.equals(parameterType)) {
                i += 2;
            }
            else {
                ++i;
            }
        }
        mv.visitMethodInsn(184, Type.getInternalName((Class)executeMethod.getDeclaringClass()), executeMethod.getName(), Type.getMethodDescriptor(executeMethod), false);
        if (!Void.TYPE.equals(returnType)) {
            if (!returnType.isPrimitive()) {
                Convert.fromObjectTo(mv, returnType);
            }
            mv.visitInsn(Type.getReturnType(selectMethod).getOpcode(172));
        }
        else {
            mv.visitInsn(177);
        }
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }
    
    private String getSelectMethodSignature(final Method selectMethod) {
        final StringBuilder signature = new StringBuilder();
        signature.append(selectMethod.getName());
        if (selectMethod.getParameterTypes().length > 0) {
            signature.append('(');
            boolean first = true;
            for (final Class<?> parameterType : selectMethod.getParameterTypes()) {
                if (!first) {
                    signature.append(',');
                }
                signature.append(parameterType.getCanonicalName());
                first = false;
            }
            signature.append(')');
        }
        return signature.toString();
    }
    
    private static String[] getExceptionTypes(final Method method) {
        final List<String> types = new ArrayList<String>(method.getExceptionTypes().length);
        for (final Class<?> exceptionType : method.getExceptionTypes()) {
            types.add(Type.getInternalName((Class)exceptionType));
        }
        return types.toArray(new String[types.size()]);
    }
    
    private static void bipush(final MethodVisitor mv, final int i) {
        switch (i) {
            case -1: {
                mv.visitInsn(2);
                break;
            }
            case 0: {
                mv.visitInsn(3);
                break;
            }
            case 1: {
                mv.visitInsn(4);
                break;
            }
            case 2: {
                mv.visitInsn(5);
                break;
            }
            case 3: {
                mv.visitInsn(6);
                break;
            }
            case 4: {
                mv.visitInsn(7);
                break;
            }
            case 5: {
                mv.visitInsn(8);
                break;
            }
            default: {
                mv.visitIntInsn(16, i);
                break;
            }
        }
    }
    
    public void createEjbActivate() {
        final MethodVisitor mv = this.cw.visitMethod(1, "ejbActivate", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, 1);
        mv.visitEnd();
    }
    
    public void createEjbLoad() {
        final MethodVisitor mv = this.cw.visitMethod(1, "ejbLoad", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, 1);
        mv.visitEnd();
    }
    
    public void createEjbPassivate() {
        final MethodVisitor mv = this.cw.visitMethod(1, "ejbPassivate", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, 1);
        mv.visitEnd();
    }
    
    public void createEjbRemove() {
        final MethodVisitor mv = this.cw.visitMethod(1, "ejbRemove", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, 1);
        mv.visitEnd();
    }
    
    public void createEjbStore() {
        final MethodVisitor mv = this.cw.visitMethod(1, "ejbStore", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, 1);
        mv.visitEnd();
    }
    
    public void createSetEntityContext() {
        final MethodVisitor mv = this.cw.visitMethod(1, "setEntityContext", "(Ljavax/ejb/EntityContext;)V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, 2);
        mv.visitEnd();
    }
    
    public void createUnsetEntityContext() {
        final MethodVisitor mv = this.cw.visitMethod(1, "unsetEntityContext", "()V", (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, 1);
        mv.visitEnd();
    }
    
    static {
        UNKNOWN_PK_TYPE = Type.getType((Class)Long.class);
    }
    
    private static final class Convert
    {
        private static final Map<Class, Convert> conversionsByPrimitive;
        public static final Convert BOOLEAN;
        public static final Convert CHAR;
        public static final Convert BYTE;
        public static final Convert SHORT;
        public static final Convert INT;
        public static final Convert LONG;
        public static final Convert FLOAT;
        public static final Convert DOUBLE;
        private final Type objectType;
        private final Method toPrimitive;
        private final Method toObject;
        
        public static void toObjectFrom(final MethodVisitor mv, final Class from) {
            if (from.isPrimitive()) {
                final Convert conversion = getConversion(from);
                if (conversion == null) {
                    throw new NullPointerException("conversion is null " + from.getName() + " " + from.isPrimitive());
                }
                conversion.primitiveToObject(mv);
            }
        }
        
        public static void fromObjectTo(final MethodVisitor mv, final Class to) {
            if (!to.equals(Object.class)) {
                if (!to.isPrimitive()) {
                    mv.visitTypeInsn(192, Type.getInternalName(to));
                }
                else {
                    final Convert conversion = getConversion(to);
                    if (conversion == null) {
                        throw new NullPointerException("unsupported conversion for EJB select return type " + to.getName());
                    }
                    conversion.objectToPrimitive(mv);
                }
            }
        }
        
        public static Convert getConversion(final Class primitive) {
            if (!primitive.isPrimitive()) {
                throw new IllegalArgumentException(primitive.getName() + " is not a primitive class");
            }
            return Convert.conversionsByPrimitive.get(primitive);
        }
        
        private Convert(final Class primitiveClass, final Class objectClass, final String toPrimitiveMethodName) {
            this.objectType = Type.getType(objectClass);
            try {
                this.toObject = objectClass.getMethod("valueOf", primitiveClass);
                this.toPrimitive = objectClass.getMethod(toPrimitiveMethodName, (Class[])new Class[0]);
            }
            catch (NoSuchMethodException e) {
                throw new OpenEJBRuntimeException(e);
            }
            Convert.conversionsByPrimitive.put(primitiveClass, this);
        }
        
        public void primitiveToObject(final MethodVisitor mv) {
            mv.visitMethodInsn(184, this.objectType.getInternalName(), this.toObject.getName(), Type.getMethodDescriptor(this.toObject), false);
        }
        
        public void objectToPrimitive(final MethodVisitor mv) {
            mv.visitTypeInsn(192, this.objectType.getInternalName());
            mv.visitMethodInsn(182, this.objectType.getInternalName(), this.toPrimitive.getName(), Type.getMethodDescriptor(this.toPrimitive), false);
        }
        
        static {
            conversionsByPrimitive = new HashMap<Class, Convert>();
            BOOLEAN = new Convert(Boolean.TYPE, Boolean.class, "booleanValue");
            CHAR = new Convert(Character.TYPE, Character.class, "charValue");
            BYTE = new Convert(Byte.TYPE, Byte.class, "byteValue");
            SHORT = new Convert(Short.TYPE, Short.class, "shortValue");
            INT = new Convert(Integer.TYPE, Integer.class, "intValue");
            LONG = new Convert(Long.TYPE, Long.class, "longValue");
            FLOAT = new Convert(Float.TYPE, Float.class, "floatValue");
            DOUBLE = new Convert(Double.TYPE, Double.class, "doubleValue");
        }
    }
}
