// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Properties;

public class IdPropertiesInfo extends InfoObject
{
    public String id;
    public final Properties properties;
    
    public IdPropertiesInfo() {
        this.properties = new Properties();
    }
}
