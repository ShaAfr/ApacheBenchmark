// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.openjpa;

import org.apache.openjpa.jdbc.meta.FieldMapping;
import org.apache.openjpa.jdbc.schema.Schema;
import org.apache.openjpa.jdbc.meta.ClassMapping;
import org.apache.openjpa.persistence.jdbc.PersistenceMappingDefaults;
import org.apache.openjpa.lib.conf.Configuration;
import org.apache.openjpa.lib.conf.Configurations;
import org.apache.openjpa.jdbc.meta.MappingDefaults;
import org.apache.openjpa.jdbc.meta.MappingRepository;

public class PrefixMappingRepository extends MappingRepository
{
    private String prefix;
    
    public PrefixMappingRepository() {
        this.setMappingDefaults((MappingDefaults)new PrefixMappingDefaults());
    }
    
    public void setPrefix(final String prefix) {
        this.prefix = prefix;
    }
    
    public void endConfiguration() {
        super.endConfiguration();
        Configurations.configureInstance((Object)this.getMappingDefaults(), (Configuration)this.getConfiguration(), "jdbc.MappingDefaults");
        ((PrefixMappingDefaults)this.getMappingDefaults()).endConfiguration();
    }
    
    private class PrefixMappingDefaults extends PersistenceMappingDefaults
    {
        public String getTableName(final ClassMapping cls, final Schema schema) {
            return PrefixMappingRepository.this.prefix + super.getTableName(cls, schema);
        }
        
        public String getTableName(final FieldMapping fm, final Schema schema) {
            return PrefixMappingRepository.this.prefix + super.getTableName(fm, schema);
        }
    }
}
