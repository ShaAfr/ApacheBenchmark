// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Handler;
import java.util.logging.Level;
import org.apache.openejb.core.ParentClassLoaderFinder;
import java.util.Properties;
import org.apache.openejb.loader.SystemInstance;
import java.util.logging.Logger;
import java.util.concurrent.Callable;

public class LoggerCreator implements Callable<Logger>
{
    private final String name;
    private Logger logger;
    private volatile boolean init;
    
    public LoggerCreator(final String channel) {
        this.name = channel;
        final Properties p = SystemInstance.get().getProperties();
        final String levelName = p.getProperty("logging.level." + channel);
        if (levelName != null) {
            try {
                this.call();
            }
            catch (Exception ex) {}
        }
    }
    
    @Override
    public Logger call() throws Exception {
        if (this.logger == null) {
            synchronized (this) {
                if (this.logger == null) {
                    final Thread thread = Thread.currentThread();
                    final ClassLoader originalLoader = thread.getContextClassLoader();
                    thread.setContextClassLoader(ParentClassLoaderFinder.Helper.get());
                    try {
                        try {
                            this.logger = Logger.getLogger(this.name);
                        }
                        catch (Exception e) {
                            this.logger = Logger.getLogger(this.name);
                        }
                        final Properties p = SystemInstance.get().getProperties();
                        final String levelName = p.getProperty("logging.level." + this.logger.getName());
                        if (levelName != null) {
                            final Level level = Level.parse(levelName);
                            for (final Handler handler : this.logger.getHandlers()) {
                                handler.setLevel(level);
                            }
                        }
                    }
                    finally {
                        thread.setContextClassLoader(originalLoader);
                    }
                }
            }
        }
        return this.logger;
    }
    
    public boolean isInit() {
        return this.init;
    }
    
    public static final class Get
    {
        private Get() {
        }
        
        private static Logger exec(final LoggerCreator creator) {
            final ClassLoader old = Thread.currentThread().getContextClassLoader();
            Thread.currentThread().setContextClassLoader(ParentClassLoaderFinder.Helper.get());
            try {
                return creator.call();
            }
            catch (Exception e) {
                return Logger.getLogger("default");
            }
            finally {
                Thread.currentThread().setContextClassLoader(old);
            }
        }
        
        public static Logger exec(final LoggerCreator logger, final AtomicBoolean debug, final AtomicBoolean info) {
            final Logger l = exec(logger);
            if (!logger.init) {
                levels(logger, debug, info);
            }
            return l;
        }
        
        public static void levels(final LoggerCreator lc, final AtomicBoolean debug, final AtomicBoolean info) {
            if (lc.init) {
                return;
            }
            Logger l;
            try {
                l = lc.call();
            }
            catch (Exception e) {
                return;
            }
            debug.set(l.isLoggable(Level.FINE));
            info.set(l.isLoggable(Level.INFO));
            lc.init = true;
        }
    }
}
