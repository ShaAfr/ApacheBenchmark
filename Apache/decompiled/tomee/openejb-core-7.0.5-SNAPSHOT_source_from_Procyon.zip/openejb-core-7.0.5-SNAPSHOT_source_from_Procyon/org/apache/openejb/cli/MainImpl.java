// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cli;

import java.util.Iterator;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.apache.commons.cli.HelpFormatter;
import java.util.Map;
import java.net.URL;
import java.util.Enumeration;
import org.apache.openejb.util.OptionsLog;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.util.JavaSecurityManagers;
import java.util.ArrayList;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.List;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import java.io.IOException;
import org.apache.openejb.util.OpenEjbVersion;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import java.util.Locale;
import org.apache.xbean.finder.ResourceFinder;

public class MainImpl implements Main
{
    private static final String BASE_PATH = "META-INF/org.apache.openejb.cli/";
    private static final String MAIN_CLASS_PROPERTY_NAME = "main.class";
    private static ResourceFinder finder;
    private static String locale;
    private static final String descriptionBase = "description";
    private static String descriptionI18n;
    
    @Override
    public void main(String[] args) {
        args = this.processSystemProperties(args);
        MainImpl.finder = new ResourceFinder("META-INF/org.apache.openejb.cli/");
        MainImpl.locale = Locale.getDefault().getLanguage();
        MainImpl.descriptionI18n = "description." + MainImpl.locale;
        final CommandLineParser parser = (CommandLineParser)new PosixParser();
        final Options options = new Options();
        options.addOption((String)null, "version", false, "Display version");
        options.addOption("h", "help", false, "Display help");
        options.addOption("e", "errors", false, "Produce execution error messages");
        CommandLine line = null;
        String commandName = null;
        try {
            line = parser.parse(options, args, true);
            final List<String> list = (List<String>)line.getArgList();
            if (list.size() > 0) {
                commandName = list.get(0);
                list.remove(0);
            }
            args = line.getArgs();
        }
        catch (ParseException exp) {
            exp.printStackTrace();
            System.exit(-1);
        }
        if (line.hasOption("version")) {
            OpenEjbVersion.get().print(System.out);
            System.exit(0);
        }
        else if (line.hasOption("help") || commandName == null || commandName.equals("help")) {
            help();
            System.exit(0);
        }
        Properties props = null;
        try {
            props = MainImpl.finder.findProperties(commandName);
        }
        catch (IOException e3) {
            System.out.println("Unavailable command: " + commandName);
            help(false);
            System.exit(1);
        }
        if (props == null) {
            System.out.println("Unavailable command: " + commandName);
            help(false);
            System.exit(1);
        }
        final String mainClass = props.getProperty("main.class");
        if (mainClass == null) {
            throw new NullPointerException("Command " + commandName + " did not specify a " + "main.class" + " property");
        }
        Class<?> clazz = null;
        try {
            clazz = Thread.currentThread().getContextClassLoader().loadClass(mainClass);
        }
        catch (ClassNotFoundException cnfe) {
            throw new IllegalStateException("Main class of command " + commandName + " does not exist: " + mainClass, cnfe);
        }
        Method mainMethod = null;
        try {
            mainMethod = clazz.getMethod("main", String[].class);
        }
        catch (Exception e) {
            throw new IllegalStateException("Main class of command " + commandName + " does not have a static main method: " + mainClass, e);
        }
        try {
            mainMethod.invoke(clazz, args);
        }
        catch (Throwable e2) {
            if (line.hasOption("errors")) {
                e2.printStackTrace();
            }
            System.exit(-10);
        }
    }
    
    private String[] processSystemProperties(String[] args) {
        final ArrayList<String> argsList = new ArrayList<String>();
        for (final String arg : args) {
            if (arg.indexOf("-Dopenejb.base") != -1) {
                final String prop = arg.substring(arg.indexOf("-D") + 2, arg.indexOf("="));
                final String val = arg.substring(arg.indexOf("=") + 1);
                JavaSecurityManagers.setSystemProperty(prop, val);
            }
        }
        SystemInstance systemInstance = null;
        try {
            SystemInstance.init(new Properties());
            OptionsLog.install();
            systemInstance = SystemInstance.get();
        }
        catch (Exception e) {
            e.printStackTrace();
            System.exit(2);
        }
        for (final String arg2 : args) {
            final int idx = arg2.indexOf("-D");
            final int eq = arg2.indexOf("=");
            if (idx >= 0 && eq > idx) {
                final String prop2 = arg2.substring(idx + 2, eq);
                final String val2 = arg2.substring(eq + 1);
                JavaSecurityManagers.setSystemProperty(prop2, val2);
                systemInstance.setProperty(prop2, val2);
            }
            else {
                argsList.add(arg2);
            }
        }
        args = argsList.toArray(new String[argsList.size()]);
        return args;
    }
    
    public static Enumeration<URL> doFindCommands() throws IOException {
        return Thread.currentThread().getContextClassLoader().getResources("META-INF/org.apache.openejb.cli/");
    }
    
    private static void help() {
        help(true);
    }
    
    private static void help(final boolean printHeader) {
        try {
            final Options options = new Options();
            final ResourceFinder commandFinder = new ResourceFinder("META-INF");
            final Map<String, Properties> commands = (Map<String, Properties>)commandFinder.mapAvailableProperties("org.apache.openejb.cli");
            for (final Map.Entry<String, Properties> command : commands.entrySet()) {
                if (command.getKey().contains(".")) {
                    continue;
                }
                final Properties p = command.getValue();
                final String description = p.getProperty(MainImpl.descriptionI18n, p.getProperty("description"));
                options.addOption((String)command.getKey(), false, description);
            }
            final HelpFormatter formatter = new HelpFormatter();
            final StringWriter sw = new StringWriter();
            final PrintWriter pw = new PrintWriter(sw);
            final String syntax = "openejb <command> [options] [args]";
            final String header = "\nAvailable commands:";
            final String footer = "\nTry 'openejb <command> --help' for help on a specific command.\nFor example 'openejb deploy --help'.\nImportant: to display exceptions while running commands, add -e option.\n\nApache OpenEJB -- EJB Container System and Server.\nFor additional information, see http://tomee.apache.org\nBug Reports to <users@tomee.apache.org>";
            if (!printHeader) {
                pw.append("\nAvailable commands:").append("\n\n");
                formatter.printOptions(pw, 74, options, 1, 3);
            }
            else {
                formatter.printHelp(pw, 74, "openejb <command> [options] [args]", "\nAvailable commands:", options, 1, 3, "\nTry 'openejb <command> --help' for help on a specific command.\nFor example 'openejb deploy --help'.\nImportant: to display exceptions while running commands, add -e option.\n\nApache OpenEJB -- EJB Container System and Server.\nFor additional information, see http://tomee.apache.org\nBug Reports to <users@tomee.apache.org>", false);
            }
            pw.flush();
            String text = sw.toString().replaceAll("\n -", "\n  ");
            text = text.replace("\nApache OpenEJB", "\n\nApache OpenEJB");
            System.out.print(text);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    static {
        MainImpl.locale = "";
    }
}
