// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.event;

import org.apache.openejb.api.resource.DestroyableResource;
import org.apache.openejb.observer.Event;

@Event
public class ResourceBeforeDestroyed extends ResourceEvent
{
    public ResourceBeforeDestroyed(final Object resource, final String name) {
        super(name, resource);
    }
    
    @Override
    public void replaceBy(final Object newResource) {
        if (DestroyableResource.class.isInstance(this.resource)) {
            DestroyableResource.class.cast(this.resource).destroyResource();
        }
        super.replaceBy(newResource);
    }
}
