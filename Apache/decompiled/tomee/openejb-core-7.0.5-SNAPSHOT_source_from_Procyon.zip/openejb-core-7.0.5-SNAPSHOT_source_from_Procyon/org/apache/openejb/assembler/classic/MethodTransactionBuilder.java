// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Comparator;
import java.util.Collections;
import java.util.ArrayList;
import java.lang.reflect.Method;
import org.apache.openejb.core.transaction.TransactionType;
import java.util.Map;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.OpenEJBException;
import java.util.Iterator;
import java.util.List;
import org.apache.openejb.BeanContext;
import java.util.HashMap;
import org.apache.openejb.util.Logger;

public class MethodTransactionBuilder
{
    public static final Logger logger;
    
    public void build(final HashMap<String, BeanContext> deployments, final List<MethodTransactionInfo> methodTransactions) throws OpenEJBException {
        for (final BeanContext beanContext : deployments.values()) {
            applyTransactionAttributes(beanContext, methodTransactions);
        }
    }
    
    public static void applyTransactionAttributes(final BeanContext beanContext, List<MethodTransactionInfo> methodTransactionInfos) throws OpenEJBException {
        if (beanContext.isBeanManagedTransaction()) {
            return;
        }
        methodTransactionInfos = normalize(methodTransactionInfos);
        final Map<MethodInfoUtil.ViewMethod, MethodAttributeInfo> attributes = MethodInfoUtil.resolveViewAttributes(methodTransactionInfos, beanContext);
        final Logger log = Logger.getInstance(LogCategory.OPENEJB_STARTUP.createChild("attributes"), MethodTransactionBuilder.class);
        final boolean debug = log.isDebugEnabled();
        for (final Map.Entry<MethodInfoUtil.ViewMethod, MethodAttributeInfo> entry : attributes.entrySet()) {
            final MethodInfoUtil.ViewMethod viewMethod = entry.getKey();
            final Method method = viewMethod.getMethod();
            final String view = viewMethod.getView();
            final MethodTransactionInfo transactionInfo = entry.getValue();
            if (debug) {
                log.debug("Transaction Attribute: " + method + " -- " + MethodInfoUtil.toString(transactionInfo));
            }
            beanContext.setMethodTransactionAttribute(method, TransactionType.get(transactionInfo.transAttribute), view);
        }
    }
    
    public static List<MethodTransactionInfo> normalize(final List<MethodTransactionInfo> infos) {
        final List<MethodTransactionInfo> normalized = new ArrayList<MethodTransactionInfo>();
        for (final MethodTransactionInfo oldInfo : infos) {
            for (final MethodInfo methodInfo : oldInfo.methods) {
                final MethodTransactionInfo newInfo = new MethodTransactionInfo();
                newInfo.description = oldInfo.description;
                newInfo.methods.add(methodInfo);
                newInfo.transAttribute = oldInfo.transAttribute;
                normalized.add(newInfo);
            }
        }
        Collections.reverse(normalized);
        Collections.sort(normalized, new MethodTransactionComparator());
        return normalized;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, MethodTransactionBuilder.class);
    }
    
    public static class MethodTransactionComparator extends MethodInfoUtil.BaseComparator<MethodTransactionInfo>
    {
        @Override
        public int compare(final MethodTransactionInfo a, final MethodTransactionInfo b) {
            return this.compare(a.methods.get(0), b.methods.get(0));
        }
    }
}
