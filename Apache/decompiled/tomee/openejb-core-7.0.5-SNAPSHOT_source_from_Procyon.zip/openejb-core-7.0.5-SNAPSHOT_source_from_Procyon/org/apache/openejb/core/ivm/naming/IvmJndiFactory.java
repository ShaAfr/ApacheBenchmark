// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import java.util.Iterator;
import org.apache.openejb.SystemException;
import java.util.Map;
import javax.naming.NamingException;
import org.apache.openejb.OpenEJBRuntimeException;
import javax.naming.Context;
import org.apache.openejb.core.JndiFactory;

public class IvmJndiFactory implements JndiFactory
{
    private final Context jndiRootContext;
    
    public IvmJndiFactory() {
        this.jndiRootContext = IvmContext.createRootContext();
        try {
            this.jndiRootContext.bind("openejb/local/.", "");
            this.jndiRootContext.bind("openejb/remote/.", "");
            this.jndiRootContext.bind("openejb/client/.", "");
            this.jndiRootContext.bind("openejb/Deployment/.", "");
            this.jndiRootContext.bind("openejb/global/.", "");
        }
        catch (NamingException e) {
            throw new OpenEJBRuntimeException("this should not happen", e);
        }
    }
    
    @Override
    public Context createComponentContext(final Map<String, Object> bindings) throws SystemException {
        final IvmContext context = new IvmContext();
        try {
            context.bind("java:comp/env/dummy", "dummy");
        }
        catch (NamingException e) {
            throw new SystemException("Unable to create subcontext 'java:comp/env'.  Exception:" + e.getMessage(), e);
        }
        for (final Map.Entry<String, Object> entry : bindings.entrySet()) {
            final String name = entry.getKey();
            final Object value = entry.getValue();
            if (value == null) {
                continue;
            }
            try {
                context.bind(name, value);
            }
            catch (NamingException e2) {
                throw new SystemException("Unable to bind '" + name + "' into bean's enc.", e2);
            }
        }
        return context;
    }
    
    @Override
    public Context createRootContext() {
        return this.jndiRootContext;
    }
}
