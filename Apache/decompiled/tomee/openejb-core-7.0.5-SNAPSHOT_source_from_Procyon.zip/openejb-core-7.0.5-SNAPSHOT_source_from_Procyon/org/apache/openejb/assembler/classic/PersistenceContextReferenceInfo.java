// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Properties;

public class PersistenceContextReferenceInfo extends InjectableInfo
{
    public String persistenceUnitName;
    public String unitId;
    public boolean extended;
    public String synchronizationType;
    public final Properties properties;
    
    public PersistenceContextReferenceInfo() {
        this.properties = new Properties();
    }
}
