// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import java.util.concurrent.atomic.AtomicInteger;
import org.apache.openejb.util.LogCategory;
import java.util.concurrent.TimeUnit;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.concurrent.RejectedExecutionException;
import org.apache.openejb.quartz.SchedulerConfigException;
import org.apache.openejb.util.ExecutorBuilder;
import java.util.concurrent.ThreadPoolExecutor;
import org.apache.openejb.loader.SystemInstance;
import java.util.concurrent.Executor;
import org.apache.openejb.util.Logger;
import org.apache.openejb.quartz.spi.ThreadPool;

public class DefaultTimerThreadPoolAdapter implements ThreadPool
{
    private static final Logger logger;
    public static final String OPENEJB_TIMER_POOL_SIZE = "openejb.timer.pool.size";
    public static final String OPENEJB_EJB_TIMER_POOL_AWAIT_SECONDS = "openejb.ejb-timer-pool.shutdown.timeout";
    private Executor executor;
    private String instanceId;
    private String instanceName;
    private int threadCount;
    private int threadPriority;
    private final Object threadAvailableLock;
    private boolean threadPoolExecutorUsed;
    
    public DefaultTimerThreadPoolAdapter() {
        this.threadCount = Integer.parseInt(SystemInstance.get().getProperty("openejb.timer.pool.size", "3"));
        this.threadPriority = 5;
        this.threadAvailableLock = new Object();
    }
    
    public int blockForAvailableThreads() {
        if (this.threadPoolExecutorUsed) {
            final ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor)this.executor;
            synchronized (this.threadAvailableLock) {
                while (threadPoolExecutor.getMaximumPoolSize() - threadPoolExecutor.getActiveCount() < 1 && !threadPoolExecutor.isShutdown()) {
                    try {
                        this.threadAvailableLock.wait(500L);
                    }
                    catch (InterruptedException ex) {}
                }
                return threadPoolExecutor.getMaximumPoolSize() - threadPoolExecutor.getActiveCount();
            }
        }
        return 1;
    }
    
    public void setInstanceId(final String instanceId) {
        this.instanceId = instanceId;
    }
    
    public void setInstanceName(final String instanceName) {
        this.instanceName = instanceName;
    }
    
    public String getInstanceId() {
        return this.instanceId;
    }
    
    public String getInstanceName() {
        return this.instanceName;
    }
    
    public int getPoolSize() {
        if (this.threadPoolExecutorUsed) {
            return ((ThreadPoolExecutor)this.executor).getPoolSize();
        }
        return 1;
    }
    
    public synchronized void initialize() throws SchedulerConfigException {
        final TimerExecutor timerExecutor = (TimerExecutor)SystemInstance.get().getComponent((Class)TimerExecutor.class);
        if (timerExecutor != null) {
            this.executor = timerExecutor.incr().executor;
        }
        else {
            this.executor = new ExecutorBuilder().size(this.threadCount).prefix("EjbTimerPool").build(SystemInstance.get().getOptions());
            final TimerExecutor value = new TimerExecutor(this.executor).incr();
            SystemInstance.get().setComponent((Class)TimerExecutor.class, (Object)value);
        }
        if (!(this.threadPoolExecutorUsed = (this.executor instanceof ThreadPoolExecutor))) {
            DefaultTimerThreadPoolAdapter.logger.warning("Unrecognized ThreadPool implementation [" + this.executor.getClass().getName() + "] is used, EJB Timer service may not work correctly");
        }
    }
    
    public boolean runInThread(final Runnable runnable) {
        try {
            this.executor.execute(runnable);
            return true;
        }
        catch (RejectedExecutionException e) {
            DefaultTimerThreadPoolAdapter.logger.error("Failed to execute timer task", e);
            return false;
        }
    }
    
    public synchronized void shutdown(final boolean waitForJobsToComplete) {
        if (this.threadPoolExecutorUsed) {
            final SystemInstance systemInstance = SystemInstance.get();
            final TimerExecutor te = (TimerExecutor)systemInstance.getComponent((Class)TimerExecutor.class);
            if (te != null) {
                if (te.executor == this.executor) {
                    if (te.decr()) {
                        this.doShutdownExecutor(waitForJobsToComplete);
                        systemInstance.removeComponent((Class)TimerExecutor.class);
                    }
                    else {
                        final ThreadPoolExecutor tpe = ThreadPoolExecutor.class.cast(this.executor);
                        if (waitForJobsToComplete) {
                            final Collection<Runnable> jobs = new ArrayList<Runnable>();
                            tpe.getQueue().drainTo(jobs);
                            for (final Runnable r : jobs) {
                                try {
                                    r.run();
                                }
                                catch (Exception e) {
                                    DefaultTimerThreadPoolAdapter.logger.warning(e.getMessage(), e);
                                }
                            }
                        }
                    }
                }
                else {
                    this.doShutdownExecutor(waitForJobsToComplete);
                }
            }
            else {
                this.doShutdownExecutor(waitForJobsToComplete);
            }
        }
    }
    
    private void doShutdownExecutor(final boolean waitJobs) {
        final ThreadPoolExecutor tpe = (ThreadPoolExecutor)this.executor;
        tpe.shutdown();
        if (waitJobs) {
            final int timeout = SystemInstance.get().getOptions().get("openejb.ejb-timer-pool.shutdown.timeout", 5);
            try {
                tpe.awaitTermination(timeout, TimeUnit.SECONDS);
            }
            catch (InterruptedException e) {
                DefaultTimerThreadPoolAdapter.logger.error(e.getMessage(), e);
            }
        }
    }
    
    public int getThreadCount() {
        return this.threadCount;
    }
    
    public void setThreadCount(final int threadCount) {
        this.threadCount = threadCount;
    }
    
    public int getThreadPriority() {
        return this.threadPriority;
    }
    
    public void setThreadPriority(final int threadPriority) {
        this.threadPriority = threadPriority;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.TIMER, "org.apache.openejb.util.resources");
    }
    
    public static final class TimerExecutor
    {
        private final Executor executor;
        private final AtomicInteger references;
        
        private TimerExecutor(final Executor executor) {
            this.references = new AtomicInteger(0);
            if (executor == null) {
                throw new IllegalArgumentException("executor cannot be null");
            }
            this.executor = executor;
        }
        
        public TimerExecutor incr() {
            this.references.incrementAndGet();
            return this;
        }
        
        public boolean decr() {
            return this.references.decrementAndGet() == 0;
        }
    }
}
