// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import javax.resource.spi.work.WorkAdapter;
import javax.resource.spi.work.WorkCompletedException;
import java.util.concurrent.CountDownLatch;
import org.apache.openejb.util.LogCategory;
import javax.resource.spi.work.WorkEvent;
import javax.resource.spi.work.WorkRejectedException;
import javax.resource.spi.work.WorkException;
import javax.resource.spi.work.WorkListener;
import javax.resource.spi.work.ExecutionContext;
import javax.resource.spi.work.Work;
import java.util.concurrent.Executor;
import org.apache.openejb.util.Logger;
import javax.resource.spi.work.WorkManager;

public class SimpleWorkManager implements WorkManager
{
    private static final Logger logger;
    private final Executor executor;
    
    public SimpleWorkManager(final Executor executor) {
        if (executor == null) {
            throw new NullPointerException("executor is null");
        }
        this.executor = executor;
    }
    
    public void doWork(final Work work) throws WorkException {
        if (work == null) {
            throw new NullPointerException("work is null");
        }
        this.doWork(work, Long.MAX_VALUE, null, null);
    }
    
    public void doWork(final Work work, final long startTimeout, final ExecutionContext executionContext, final WorkListener workListener) throws WorkException {
        if (work == null) {
            throw new NullPointerException("work is null");
        }
        this.executeWork(WorkType.DO, work, startTimeout, executionContext, workListener);
    }
    
    public long startWork(final Work work) throws WorkException {
        if (work == null) {
            throw new NullPointerException("work is null");
        }
        return this.startWork(work, Long.MAX_VALUE, null, null);
    }
    
    public long startWork(final Work work, final long startTimeout, final ExecutionContext executionContext, final WorkListener workListener) throws WorkException {
        if (work == null) {
            throw new NullPointerException("work is null");
        }
        return this.executeWork(WorkType.START, work, startTimeout, executionContext, workListener);
    }
    
    public void scheduleWork(final Work work) throws WorkException {
        if (work == null) {
            throw new NullPointerException("work is null");
        }
        this.scheduleWork(work, Long.MAX_VALUE, null, null);
    }
    
    public void scheduleWork(final Work work, final long startTimeout, final ExecutionContext executionContext, final WorkListener workListener) throws WorkException {
        if (work == null) {
            throw new NullPointerException("work is null");
        }
        this.executeWork(WorkType.SCHEDULE, work, startTimeout, executionContext, workListener);
    }
    
    private long executeWork(final WorkType workType, final Work work, final long startTimeout, final ExecutionContext executionContext, WorkListener workListener) throws WorkException {
        if (workListener == null) {
            workListener = (WorkListener)new LoggingWorkListener(workType);
        }
        if (executionContext != null && executionContext.getXid() != null) {
            final WorkRejectedException workRejectedException = new WorkRejectedException("SimpleWorkManager can not import an XID", "3");
            workListener.workRejected(new WorkEvent((Object)this, 2, work, (WorkException)workRejectedException));
            throw workRejectedException;
        }
        workListener.workAccepted(new WorkEvent((Object)this, 1, work, (WorkException)null));
        final Worker worker = new Worker(work, workListener, startTimeout);
        this.executor.execute(worker);
        if (workType == WorkType.DO) {
            try {
                worker.waitForCompletion();
            }
            catch (InterruptedException e) {
                final WorkException workException = new WorkException("Work submission thread was interrupted", (Throwable)e);
                workException.setErrorCode("-1");
                throw workException;
            }
            final WorkException workCompletedException = worker.getWorkException();
            if (workCompletedException != null) {
                throw workCompletedException;
            }
        }
        else if (workType == WorkType.START) {
            try {
                worker.waitForStart();
            }
            catch (InterruptedException e) {
                final WorkException workException = new WorkException("Work submission thread was interrupted", (Throwable)e);
                workException.setErrorCode("-1");
                throw workException;
            }
            final WorkException workCompletedException = worker.getWorkException();
            if (workCompletedException instanceof WorkRejectedException) {
                throw workCompletedException;
            }
        }
        return worker.getStartDelay();
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, SimpleWorkManager.class);
    }
    
    public enum WorkType
    {
        DO, 
        START, 
        SCHEDULE;
    }
    
    private class Worker implements Runnable
    {
        private final Work work;
        private final WorkListener workListener;
        private final long startTimeout;
        private final long created;
        private final CountDownLatch started;
        private final CountDownLatch completed;
        private long startDelay;
        private WorkException workException;
        
        public Worker(final Work work, final WorkListener workListener, final long startTimeout) {
            this.created = System.currentTimeMillis();
            this.started = new CountDownLatch(1);
            this.completed = new CountDownLatch(1);
            this.startDelay = -1L;
            this.work = work;
            this.workListener = workListener;
            if (startTimeout <= 0L) {
                this.startTimeout = Long.MAX_VALUE;
            }
            else {
                this.startTimeout = startTimeout;
            }
        }
        
        @Override
        public void run() {
            try {
                this.startDelay = System.currentTimeMillis() - this.created;
                if (this.startDelay > this.startTimeout) {
                    this.workException = (WorkException)new WorkRejectedException("Work not started within specified timeout " + this.startTimeout + "ms", "1");
                    this.workListener.workRejected(new WorkEvent((Object)this, 2, this.work, this.workException, this.startTimeout));
                    return;
                }
                this.workListener.workStarted(new WorkEvent((Object)SimpleWorkManager.this, 3, this.work, (WorkException)null));
                this.started.countDown();
                this.workException = null;
                try {
                    this.work.run();
                }
                catch (Throwable e) {
                    this.workException = (WorkException)new WorkCompletedException(e);
                }
                finally {
                    this.workListener.workCompleted(new WorkEvent((Object)SimpleWorkManager.this, 4, this.work, this.workException));
                }
            }
            finally {
                this.started.countDown();
                this.completed.countDown();
            }
        }
        
        public long getStartDelay() {
            return this.startDelay;
        }
        
        public WorkException getWorkException() {
            return this.workException;
        }
        
        public void waitForStart() throws InterruptedException {
            this.started.await();
        }
        
        public void waitForCompletion() throws InterruptedException {
            this.completed.await();
        }
    }
    
    private static final class LoggingWorkListener extends WorkAdapter
    {
        private final WorkType workType;
        
        private LoggingWorkListener(final WorkType workType) {
            this.workType = workType;
        }
        
        public void workRejected(final WorkEvent event) {
            if (this.workType == WorkType.DO || this.workType == WorkType.START) {
                return;
            }
            final WorkException exception = event.getException();
            if (exception != null && "1".equals(exception.getErrorCode())) {
                SimpleWorkManager.logger.error(exception.getMessage());
            }
        }
        
        public void workCompleted(final WorkEvent event) {
            if (this.workType == WorkType.DO) {
                return;
            }
            Throwable cause = (Throwable)event.getException();
            if (cause != null && cause.getCause() != null) {
                cause = cause.getCause();
            }
            if (cause != null) {
                SimpleWorkManager.logger.error(event.getWork().toString(), cause);
            }
        }
    }
}
