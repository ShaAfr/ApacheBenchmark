// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.ApplicationException;
import javax.transaction.SystemException;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.util.SetAccessible;
import org.apache.openejb.RpcContainer;
import javax.ejb.EJBContext;
import org.apache.openejb.core.BaseContext;
import javax.ejb.ScheduleExpression;
import java.util.Date;
import javax.ejb.TimerConfig;
import java.lang.reflect.Method;
import java.util.ArrayList;
import javax.ejb.Timer;
import org.apache.openejb.quartz.JobDataMap;
import org.apache.openejb.quartz.impl.triggers.AbstractTrigger;
import java.util.concurrent.TimeUnit;
import org.apache.openejb.quartz.SchedulerListener;
import org.apache.openejb.quartz.listeners.SchedulerListenerSupport;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.CountDownLatch;
import org.apache.openejb.quartz.TriggerKey;
import org.apache.openejb.quartz.Trigger;
import java.util.Collection;
import javax.ejb.EJBException;
import java.util.Iterator;
import java.util.Map;
import org.apache.openejb.quartz.simpl.RAMJobStore;
import org.apache.openejb.quartz.impl.jdbcjobstore.JobStoreSupport;
import org.apache.openejb.core.timer.quartz.PatchedStdJDBCDelegate;
import org.apache.openejb.quartz.impl.jdbcjobstore.StdJDBCDelegate;
import org.apache.openejb.monitoring.LocalMBeanServer;
import org.apache.openejb.quartz.JobDetail;
import org.apache.openejb.quartz.SchedulerException;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.quartz.JobBuilder;
import org.apache.openejb.quartz.impl.StdSchedulerFactory;
import java.util.Properties;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.apache.openejb.spi.ContainerSystem;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import org.apache.openejb.core.transaction.TransactionType;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.quartz.Scheduler;
import org.apache.openejb.BeanContext;
import javax.transaction.TransactionManager;
import org.apache.openejb.util.Logger;
import java.io.Serializable;

public class EjbTimerServiceImpl implements EjbTimerService, Serializable
{
    private static final long serialVersionUID = 1L;
    private static final Logger log;
    public static final String QUARTZ_JMX = "org.apache.openejb.quartz.scheduler.jmx.export";
    public static final String QUARTZ_MAKE_SCHEDULER_THREAD_DAEMON = "org.apache.openejb.quartz.scheduler.makeSchedulerThreadDaemon";
    public static final String OPENEJB_TIMEOUT_JOB_NAME = "OPENEJB_TIMEOUT_JOB";
    public static final String OPENEJB_TIMEOUT_JOB_GROUP_NAME = "OPENEJB_TIMEOUT_GROUP";
    public static final String EJB_TIMER_RETRY_ATTEMPTS = "EjbTimer.RetryAttempts";
    public static final String OPENEJB_QUARTZ_USE_TCCL = "openejb.quartz.use-TCCL";
    private boolean transacted;
    private int retryAttempts;
    private transient TransactionManager transactionManager;
    private transient BeanContext deployment;
    private transient TimerStore timerStore;
    private transient Scheduler scheduler;
    
    public EjbTimerServiceImpl(final BeanContext deployment, final TimerStore timerStore) {
        this(deployment, getDefaultTransactionManager(), timerStore, -1);
        EjbTimerServiceImpl.log.isDebugEnabled();
    }
    
    public static TransactionManager getDefaultTransactionManager() {
        return (TransactionManager)SystemInstance.get().getComponent((Class)TransactionManager.class);
    }
    
    public EjbTimerServiceImpl(final BeanContext deployment, final TransactionManager transactionManager, final TimerStore timerStore, final int retryAttempts) {
        this.deployment = deployment;
        this.transactionManager = transactionManager;
        this.timerStore = timerStore;
        final TransactionType transactionType = deployment.getTransactionType(deployment.getEjbTimeout());
        this.transacted = (transactionType == TransactionType.Required || transactionType == TransactionType.RequiresNew);
        this.retryAttempts = retryAttempts;
        if (retryAttempts < 0) {
            this.retryAttempts = deployment.getOptions().get("EjbTimer.RetryAttempts", 1);
        }
    }
    
    private void writeObject(final ObjectOutputStream out) throws IOException {
        out.writeUTF(this.deployment.getDeploymentID().toString());
        out.writeBoolean(this.transacted);
        out.writeInt(this.retryAttempts);
    }
    
    private void readObject(final ObjectInputStream in) throws IOException {
        final String dId = in.readUTF();
        this.transacted = in.readBoolean();
        this.retryAttempts = in.readInt();
        this.deployment = ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getBeanContext(dId);
        this.transactionManager = getDefaultTransactionManager();
        this.timerStore = this.deployment.getEjbTimerService().getTimerStore();
        this.scheduler = (Scheduler)Proxy.newProxyInstance(this.deployment.getClassLoader(), new Class[] { Scheduler.class }, new LazyScheduler(this.deployment));
    }
    
    public static synchronized Scheduler getDefaultScheduler(final BeanContext deployment) {
        Scheduler scheduler = deployment.get(Scheduler.class);
        if (scheduler != null) {
            boolean valid;
            try {
                valid = !scheduler.isShutdown();
            }
            catch (Exception ignored) {
                valid = false;
            }
            if (valid) {
                return scheduler;
            }
        }
        Scheduler thisScheduler;
        synchronized (deployment.getId()) {
            scheduler = deployment.get(Scheduler.class);
            if (scheduler != null) {
                return scheduler;
            }
            final Properties properties = new Properties();
            int quartzProps = 0;
            quartzProps += putAll(properties, SystemInstance.get().getProperties());
            quartzProps += putAll(properties, deployment.getModuleContext().getAppContext().getProperties());
            quartzProps += putAll(properties, deployment.getModuleContext().getProperties());
            quartzProps += putAll(properties, deployment.getProperties());
            final boolean newInstance = quartzProps > 0;
            final SystemInstance systemInstance = SystemInstance.get();
            scheduler = (Scheduler)systemInstance.getComponent((Class)Scheduler.class);
            if (scheduler == null || newInstance) {
                final boolean useTccl = "true".equalsIgnoreCase(properties.getProperty("openejb.quartz.use-TCCL", "false"));
                defaultQuartzConfiguration(properties, deployment, newInstance, useTccl);
                try {
                    final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
                    if (useTccl) {
                        Thread.currentThread().setContextClassLoader(deployment.getClassLoader());
                    }
                    else {
                        Thread.currentThread().setContextClassLoader(EjbTimerServiceImpl.class.getClassLoader());
                    }
                    try {
                        thisScheduler = new StdSchedulerFactory(properties).getScheduler();
                        thisScheduler.start();
                    }
                    finally {
                        Thread.currentThread().setContextClassLoader(oldCl);
                    }
                    final JobDetail job = JobBuilder.newJob((Class)EjbTimeoutJob.class).withIdentity("OPENEJB_TIMEOUT_JOB", "OPENEJB_TIMEOUT_GROUP").storeDurably(true).requestRecovery(false).build();
                    thisScheduler.addJob(job, true);
                }
                catch (SchedulerException e) {
                    throw new OpenEJBRuntimeException("Fail to initialize the default scheduler", (Throwable)e);
                }
                if (!newInstance) {
                    systemInstance.setComponent((Class)Scheduler.class, (Object)thisScheduler);
                }
            }
            else {
                thisScheduler = scheduler;
            }
            deployment.set(Scheduler.class, thisScheduler);
        }
        return thisScheduler;
    }
    
    private static void defaultQuartzConfiguration(final Properties properties, final BeanContext deployment, final boolean newInstance, final boolean tccl) {
        final String defaultThreadPool = DefaultTimerThreadPoolAdapter.class.getName();
        if (!properties.containsKey("org.apache.openejb.quartz.threadPool.class")) {
            properties.put("org.apache.openejb.quartz.threadPool.class", defaultThreadPool);
        }
        if (!properties.containsKey("org.apache.openejb.quartz.scheduler.instanceName")) {
            properties.put("org.apache.openejb.quartz.scheduler.instanceName", "OpenEJB-TimerService-Scheduler");
        }
        if (!properties.containsKey("org.apache.openejb.quartz.scheduler.skipUpdateCheck")) {
            properties.put("org.apache.openejb.quartz.scheduler.skipUpdateCheck", "true");
        }
        if (!properties.containsKey("org.terracotta.quartz.skipUpdateCheck")) {
            properties.put("org.terracotta.quartz.skipUpdateCheck", "true");
        }
        if (!properties.containsKey("org.apache.openejb.quartz.scheduler.interruptJobsOnShutdown")) {
            properties.put("org.apache.openejb.quartz.scheduler.interruptJobsOnShutdown", "true");
        }
        if (!properties.containsKey("org.apache.openejb.quartz.scheduler.interruptJobsOnShutdownWithWait")) {
            properties.put("org.apache.openejb.quartz.scheduler.interruptJobsOnShutdownWithWait", "true");
        }
        if (!properties.containsKey("org.apache.openejb.quartz.scheduler.makeSchedulerThreadDaemon")) {
            properties.put("org.apache.openejb.quartz.scheduler.makeSchedulerThreadDaemon", "true");
        }
        if (!properties.containsKey("org.apache.openejb.quartz.scheduler.jmx.export") && LocalMBeanServer.isJMXActive()) {
            properties.put("org.apache.openejb.quartz.scheduler.jmx.export", "true");
        }
        if (!properties.containsKey("org.apache.openejb.quartz.scheduler.instanceId")) {
            if (!newInstance) {
                properties.setProperty("org.apache.openejb.quartz.scheduler.instanceId", "OpenEJB");
            }
            else {
                properties.setProperty("org.apache.openejb.quartz.scheduler.instanceId", deployment.getDeploymentID().toString());
            }
        }
        if (!tccl) {
            final String driverDelegate = properties.getProperty("org.apache.openejb.quartz.jobStore.driverDelegateClass");
            if (driverDelegate != null && StdJDBCDelegate.class.getName().equals(driverDelegate)) {
                properties.put("org.apache.openejb.quartz.jobStore.driverDelegateClass", PatchedStdJDBCDelegate.class.getName());
            }
            else if (driverDelegate != null) {
                EjbTimerServiceImpl.log.info("You use " + driverDelegate + " driver delegate with quartz, ensure it doesn't use ObjectInputStream otherwise your custom TimerData can induce some issues");
            }
            if (properties.containsKey("org.apache.openejb.quartz.jobStore.class") && !properties.containsKey("org.apache.openejb.quartz.jobStore.driverDelegateInitString")) {
                try {
                    final Class<?> clazz = EjbTimerServiceImpl.class.getClassLoader().loadClass(properties.getProperty("org.apache.openejb.quartz.jobStore.class"));
                    if (JobStoreSupport.class.isAssignableFrom(clazz)) {
                        properties.put("org.apache.openejb.quartz.jobStore.driverDelegateInitString", "triggerPersistenceDelegateClasses=" + EJBCronTriggerPersistenceDelegate.class.getName());
                    }
                }
                catch (Throwable t) {}
            }
        }
        if (defaultThreadPool.equals(properties.get("org.apache.openejb.quartz.threadPool.class"))) {
            if (properties.containsKey("org.apache.openejb.quartz.threadPool.threadCount") && !properties.containsKey("openejb.timer.pool.size")) {
                EjbTimerServiceImpl.log.info("Found property 'org.apache.openejb.quartz.threadPool.threadCount' for default thread pool, please use 'openejb.timer.pool.size' instead");
                properties.put("openejb.timer.pool.size", properties.getProperty("org.apache.openejb.quartz.threadPool.threadCount"));
            }
            if (properties.containsKey("org.quartz.threadPool.threadCount") && !properties.containsKey("openejb.timer.pool.size")) {
                EjbTimerServiceImpl.log.info("Found property 'org.quartz.threadPool.threadCount' for default thread pool, please use 'openejb.timer.pool.size' instead");
                properties.put("openejb.timer.pool.size", properties.getProperty("org.quartz.threadPool.threadCount"));
            }
        }
        if (!properties.getProperty("org.apache.openejb.quartz.jobStore.class", RAMJobStore.class.getName()).equals(RAMJobStore.class.getName())) {
            properties.put("org.apache.openejb.quartz.jobStore.makeThreadsDaemons", properties.getProperty("org.apache.openejb.quartz.jobStore.makeThreadsDaemon", "true"));
        }
    }
    
    private static int putAll(final Properties a, final Properties b) {
        int number = 0;
        for (final Map.Entry<Object, Object> entry : b.entrySet()) {
            final String key = entry.getKey().toString();
            if (key.startsWith("org.quartz.") || key.startsWith("org.apache.openejb.quartz.") || key.startsWith("openejb.quartz.") || "openejb.timer.pool.size".equals(key) || "org.terracotta.quartz.skipUpdateCheck".equals(key)) {
                ++number;
            }
            final Object value = entry.getValue();
            if (String.class.isInstance(value)) {
                if (!key.startsWith("org.quartz")) {
                    a.put(key, value);
                }
                else {
                    a.put("org.apache.openejb.quartz" + key.substring("org.quartz".length()), value);
                }
            }
        }
        return number;
    }
    
    @Override
    public void stop() {
        this.cleanTimerData();
        this.shutdownMyScheduler();
    }
    
    private void cleanTimerData() {
        if (this.timerStore == null || this.scheduler == null || this.deployment == null) {
            return;
        }
        final Collection<TimerData> timerDatas = this.timerStore.getTimers(this.deployment.getDeploymentID().toString());
        if (timerDatas == null) {
            return;
        }
        for (final TimerData data : timerDatas) {
            final Trigger trigger = data.getTrigger();
            if (trigger == null) {
                continue;
            }
            final TriggerKey key = trigger.getKey();
            try {
                data.stop();
            }
            catch (EJBException ignored) {
                EjbTimerServiceImpl.log.warning("An error occured deleting trigger '" + key + "' on bean " + this.deployment.getDeploymentID());
            }
        }
    }
    
    private void shutdownMyScheduler() {
        if (this.scheduler == null) {
            return;
        }
        boolean defaultScheduler = false;
        final Scheduler ds = (Scheduler)SystemInstance.get().getComponent((Class)Scheduler.class);
        try {
            defaultScheduler = (ds == this.scheduler || this.scheduler.getSchedulerName().equals(ds.getSchedulerName()));
        }
        catch (Exception ex) {}
        if (!defaultScheduler) {
            shutdown(this.scheduler);
        }
    }
    
    public static void shutdown() {
        shutdown((Scheduler)SystemInstance.get().getComponent((Class)Scheduler.class));
    }
    
    private static void shutdown(final Scheduler s) throws OpenEJBRuntimeException {
        try {
            if (null != s && !s.isShutdown() && s.isStarted()) {
                try {
                    s.pauseAll();
                }
                catch (SchedulerException ex2) {}
                long timeout = SystemInstance.get().getOptions().get("openejb.quartz.timeout", 10000L);
                if (timeout < 1000L) {
                    timeout = 1000L;
                }
                final CountDownLatch shutdownWait = new CountDownLatch(1);
                final AtomicReference<Throwable> ex = new AtomicReference<Throwable>();
                String n = "Unknown";
                try {
                    n = s.getSchedulerName();
                }
                catch (SchedulerException e2) {
                    EjbTimerServiceImpl.log.warning("EjbTimerService scheduler has no name");
                }
                final String name = n;
                Thread stopThread = new Thread(name + " shutdown wait") {
                    @Override
                    public void run() {
                        try {
                            s.getListenerManager().addSchedulerListener((SchedulerListener)new SchedulerListenerSupport() {
                                public void schedulerShutdown() {
                                    shutdownWait.countDown();
                                }
                            });
                            s.shutdown(true);
                        }
                        catch (Throwable e) {
                            ex.set(e);
                            shutdownWait.countDown();
                        }
                    }
                };
                stopThread.setDaemon(true);
                stopThread.start();
                boolean stopped = false;
                try {
                    stopped = shutdownWait.await(timeout, TimeUnit.MILLISECONDS);
                }
                catch (InterruptedException ex3) {}
                try {
                    if (!stopped || !s.isShutdown()) {
                        stopThread = new Thread(name + " shutdown forced") {
                            @Override
                            public void run() {
                                try {
                                    s.shutdown(false);
                                    EjbTimerServiceImpl.log.warning("Forced " + name + " shutdown - Jobs may be incomplete");
                                }
                                catch (Throwable e) {
                                    ex.set(e);
                                }
                            }
                        };
                        stopThread.setDaemon(true);
                        stopThread.start();
                        try {
                            stopThread.join(timeout);
                        }
                        catch (InterruptedException ex4) {}
                    }
                }
                catch (Throwable e) {
                    ex.set(e);
                }
                final Throwable t = ex.get();
                if (null != t) {
                    throw new OpenEJBRuntimeException("Unable to shutdown " + name + " scheduler", t);
                }
            }
        }
        catch (SchedulerException ex5) {}
    }
    
    @Override
    public void start() throws TimerStoreException {
        if (this.isStarted()) {
            return;
        }
        this.scheduler = getDefaultScheduler(this.deployment);
        final Collection<TimerData> timerDatas = this.timerStore.loadTimers(this, (String)this.deployment.getDeploymentID());
        for (final TimerData timerData : timerDatas) {
            this.initializeNewTimer(timerData);
        }
    }
    
    public TransactionManager getTransactionManager() {
        return this.transactionManager;
    }
    
    public void schedule(final TimerData timerData) throws TimerStoreException {
        this.start();
        if (this.scheduler == null) {
            throw new TimerStoreException("Scheduler is not configured properly");
        }
        timerData.setScheduler(this.scheduler);
        final Trigger trigger = timerData.getTrigger();
        if (null == trigger) {
            try {
                if (!this.scheduler.isShutdown()) {
                    EjbTimerServiceImpl.log.warning("Failed to schedule: " + timerData.getInfo());
                }
            }
            catch (SchedulerException ex) {}
        }
        if (trigger instanceof AbstractTrigger) {
            final AbstractTrigger<?> atrigger = (AbstractTrigger<?>)trigger;
            atrigger.setJobName("OPENEJB_TIMEOUT_JOB");
            atrigger.setJobGroup("OPENEJB_TIMEOUT_GROUP");
            final JobDataMap triggerDataMap = trigger.getJobDataMap();
            triggerDataMap.put("EJB_TIMERS_SERVICE", (Object)this);
            triggerDataMap.put("TIMER_DATA", (Object)timerData);
            try {
                final TriggerKey triggerKey = new TriggerKey(atrigger.getName(), atrigger.getGroup());
                if (!this.scheduler.checkExists(triggerKey)) {
                    this.scheduler.scheduleJob(trigger);
                }
                else if (Trigger.TriggerState.PAUSED.equals((Object)this.scheduler.getTriggerState(triggerKey))) {
                    this.scheduler.unscheduleJob(triggerKey);
                    this.scheduler.scheduleJob(trigger);
                }
            }
            catch (Exception e) {
                EjbTimerServiceImpl.log.error("Could not schedule timer " + timerData, e);
            }
            return;
        }
        throw new OpenEJBRuntimeException("the trigger was not an AbstractTrigger - Should not be possible: " + trigger);
    }
    
    public void cancelled(final TimerData timerData) {
        this.timerStore.removeTimer(timerData.getId());
    }
    
    public void addTimerData(final TimerData timerData) {
        try {
            this.timerStore.addTimerData(timerData);
        }
        catch (Exception e) {
            EjbTimerServiceImpl.log.warning("Could not add timer of type " + timerData.getType().name() + " due to " + e.getMessage());
        }
    }
    
    @Override
    public Timer getTimer(final long timerId) {
        final TimerData timerData = this.timerStore.getTimer((String)this.deployment.getDeploymentID(), timerId);
        if (timerData != null) {
            return timerData.getTimer();
        }
        return null;
    }
    
    @Override
    public Collection<Timer> getTimers(final Object primaryKey) throws IllegalStateException {
        this.checkState();
        final Collection<Timer> timers = new ArrayList<Timer>();
        for (final TimerData timerData : this.timerStore.getTimers((String)this.deployment.getDeploymentID())) {
            timers.add(timerData.getTimer());
        }
        return timers;
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final long duration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        if (duration < 0L) {
            throw new IllegalArgumentException("duration is negative: " + duration);
        }
        this.checkState();
        final Date expiration = new Date(System.currentTimeMillis() + duration);
        try {
            final TimerData timerData = this.timerStore.createSingleActionTimer(this, (String)this.deployment.getDeploymentID(), primaryKey, timeoutMethod, expiration, timerConfig);
            this.initializeNewTimer(timerData);
            return timerData.getTimer();
        }
        catch (TimerStoreException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final long initialDuration, final long intervalDuration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        if (initialDuration < 0L) {
            throw new IllegalArgumentException("initialDuration is negative: " + initialDuration);
        }
        if (intervalDuration < 0L) {
            throw new IllegalArgumentException("intervalDuration is negative: " + intervalDuration);
        }
        this.checkState();
        final Date initialExpiration = new Date(System.currentTimeMillis() + initialDuration);
        try {
            final TimerData timerData = this.timerStore.createIntervalTimer(this, (String)this.deployment.getDeploymentID(), primaryKey, timeoutMethod, initialExpiration, intervalDuration, timerConfig);
            this.initializeNewTimer(timerData);
            return timerData.getTimer();
        }
        catch (TimerStoreException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final Date expiration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        if (expiration == null) {
            throw new IllegalArgumentException("expiration is null");
        }
        if (expiration.getTime() < 0L) {
            throw new IllegalArgumentException("expiration is negative: " + expiration.getTime());
        }
        this.checkState();
        try {
            final TimerData timerData = this.timerStore.createSingleActionTimer(this, (String)this.deployment.getDeploymentID(), primaryKey, timeoutMethod, expiration, timerConfig);
            this.initializeNewTimer(timerData);
            return timerData.getTimer();
        }
        catch (TimerStoreException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final Date initialExpiration, final long intervalDuration, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        if (initialExpiration == null) {
            throw new IllegalArgumentException("initialExpiration is null");
        }
        if (initialExpiration.getTime() < 0L) {
            throw new IllegalArgumentException("initialExpiration is negative: " + initialExpiration.getTime());
        }
        if (intervalDuration < 0L) {
            throw new IllegalArgumentException("intervalDuration is negative: " + intervalDuration);
        }
        this.checkState();
        try {
            final TimerData timerData = this.timerStore.createIntervalTimer(this, (String)this.deployment.getDeploymentID(), primaryKey, timeoutMethod, initialExpiration, intervalDuration, timerConfig);
            this.initializeNewTimer(timerData);
            return timerData.getTimer();
        }
        catch (TimerStoreException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final ScheduleExpression scheduleExpression, final TimerConfig timerConfig) {
        if (scheduleExpression == null) {
            throw new IllegalArgumentException("scheduleExpression is null");
        }
        this.checkState();
        try {
            final TimerData timerData = this.timerStore.createCalendarTimer(this, (String)this.deployment.getDeploymentID(), primaryKey, timeoutMethod, scheduleExpression, timerConfig, false);
            this.initializeNewTimer(timerData);
            return timerData.getTimer();
        }
        catch (TimerStoreException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    @Override
    public TimerStore getTimerStore() {
        return this.timerStore;
    }
    
    @Override
    public boolean isStarted() {
        return this.scheduler != null;
    }
    
    public Scheduler getScheduler() {
        return this.scheduler;
    }
    
    private void initializeNewTimer(final TimerData timerData) {
        timerData.newTimer();
    }
    
    private void checkState() throws IllegalStateException {
        final BaseContext context = this.deployment.get((Class<BaseContext>)EJBContext.class);
        context.doCheck(BaseContext.Call.timerMethod);
    }
    
    public void ejbTimeout(final TimerData timerData) {
        final Thread thread = Thread.currentThread();
        final ClassLoader loader = thread.getContextClassLoader();
        try {
            Timer timer = this.getTimer(timerData.getId());
            if (timer == null && this.timerStore instanceof MemoryTimerStore && timerData.getTimer() != null) {
                try {
                    this.timerStore.addTimerData(timerData);
                    timer = timerData.getTimer();
                }
                catch (TimerStoreException ex) {}
            }
            for (int tries = 0; tries < 1 + this.retryAttempts; ++tries) {
                boolean retry = false;
                Label_0197: {
                    if (!this.transacted) {
                        break Label_0197;
                    }
                    try {
                        this.transactionManager.begin();
                    }
                    catch (Exception e) {
                        EjbTimerServiceImpl.log.warning("Exception occured while starting container transaction", e);
                        return;
                    }
                    try {
                        final RpcContainer container = (RpcContainer)this.deployment.getContainer();
                        if (container == null) {
                            return;
                        }
                        final Method ejbTimeout = timerData.getTimeoutMethod();
                        if (ejbTimeout == null) {
                            return;
                        }
                        thread.setContextClassLoader((this.deployment.getClassLoader() != null) ? this.deployment.getClassLoader() : loader);
                        SetAccessible.on(ejbTimeout);
                        container.invoke(this.deployment.getDeploymentID(), InterfaceType.TIMEOUT, ejbTimeout.getDeclaringClass(), ejbTimeout, new Object[] { timer }, timerData.getPrimaryKey());
                    }
                    catch (RuntimeException e2) {
                        retry = true;
                        EjbTimerServiceImpl.log.warning("RuntimeException from ejbTimeout on " + this.deployment.getDeploymentID(), e2);
                        try {
                            this.transactionManager.setRollbackOnly();
                        }
                        catch (SystemException e3) {
                            EjbTimerServiceImpl.log.warning("Exception occured while setting RollbackOnly for container transaction", (Throwable)e3);
                        }
                    }
                    catch (OpenEJBException e4) {
                        retry = true;
                        if (ApplicationException.class.isInstance(e4)) {
                            EjbTimerServiceImpl.log.debug("Exception from ejbTimeout on " + this.deployment.getDeploymentID(), e4);
                        }
                        else {
                            EjbTimerServiceImpl.log.warning("Exception from ejbTimeout on " + this.deployment.getDeploymentID(), e4);
                        }
                        if (this.transacted) {
                            try {
                                this.transactionManager.setRollbackOnly();
                            }
                            catch (SystemException e3) {
                                EjbTimerServiceImpl.log.warning("Exception occured while setting RollbackOnly for container transaction", (Throwable)e3);
                            }
                        }
                    }
                    finally {
                        try {
                            if (!this.transacted) {
                                if (!retry) {
                                    return;
                                }
                            }
                            else {
                                if (this.transactionManager.getStatus() == 0) {
                                    this.transactionManager.commit();
                                    return;
                                }
                                this.transactionManager.rollback();
                            }
                        }
                        catch (Exception e5) {
                            EjbTimerServiceImpl.log.warning("Exception occured while completing container transaction", e5);
                        }
                    }
                }
            }
            EjbTimerServiceImpl.log.warning("Failed to execute ejbTimeout on " + timerData.getDeploymentId() + " successfully within " + this.retryAttempts + " attempts");
        }
        catch (RuntimeException e6) {
            EjbTimerServiceImpl.log.warning("RuntimeException occured while calling ejbTimeout", e6);
            throw e6;
        }
        catch (Error e7) {
            EjbTimerServiceImpl.log.warning("Error occured while calling ejbTimeout", e7);
            throw e7;
        }
        finally {
            thread.setContextClassLoader(loader);
            if (timerData.getType() == TimerType.SingleAction) {
                this.timerStore.removeTimer(timerData.getId());
                timerData.setExpired(true);
            }
            else if (timerData.getType() == TimerType.Calendar && timerData.getNextTimeout() == null) {
                this.timerStore.removeTimer(timerData.getId());
                timerData.setExpired(true);
            }
            else {
                this.timerStore.updateIntervalTimer(timerData);
            }
        }
    }
    
    static {
        log = Logger.getInstance(LogCategory.TIMER, "org.apache.openejb.util.resources");
    }
    
    private static class LazyScheduler implements InvocationHandler
    {
        private final BeanContext ejb;
        
        public LazyScheduler(final BeanContext deployment) {
            this.ejb = deployment;
        }
        
        @Override
        public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
            return method.invoke(EjbTimerServiceImpl.getDefaultScheduler(this.ejb), args);
        }
    }
}
