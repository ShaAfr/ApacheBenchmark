// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.jpa;

import org.apache.openejb.OpenEJBException;
import org.apache.openejb.core.cmp.CmpEngine;
import org.apache.openejb.core.cmp.CmpCallback;
import javax.transaction.TransactionSynchronizationRegistry;
import javax.transaction.TransactionManager;
import org.apache.openejb.core.cmp.CmpEngineFactory;

public class JpaCmpEngineFactory implements CmpEngineFactory
{
    private TransactionManager transactionManager;
    private TransactionSynchronizationRegistry transactionSynchronizationRegistry;
    private CmpCallback cmpCallback;
    
    @Override
    public TransactionManager getTransactionManager() {
        return this.transactionManager;
    }
    
    @Override
    public void setTransactionManager(final TransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }
    
    public TransactionSynchronizationRegistry getTransactionSynchronizationRegistry() {
        return this.transactionSynchronizationRegistry;
    }
    
    @Override
    public void setTransactionSynchronizationRegistry(final TransactionSynchronizationRegistry transactionSynchronizationRegistry) {
        this.transactionSynchronizationRegistry = transactionSynchronizationRegistry;
    }
    
    public CmpCallback getCmpCallback() {
        return this.cmpCallback;
    }
    
    @Override
    public void setCmpCallback(final CmpCallback cmpCallback) {
        this.cmpCallback = cmpCallback;
    }
    
    @Override
    public CmpEngine create() throws OpenEJBException {
        return new JpaCmpEngine(this.cmpCallback);
    }
}
