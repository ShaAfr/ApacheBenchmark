// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import java.io.ObjectStreamException;
import org.apache.openejb.spi.ApplicationServer;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.core.ServerFederation;
import org.apache.openejb.util.proxy.ProxyManager;
import javax.ejb.EJBObject;
import javax.ejb.EJBHome;
import javax.ejb.Handle;
import javax.ejb.HomeHandle;
import java.io.Serializable;

public class IntraVmHandle implements Serializable, HomeHandle, Handle
{
    protected Object theProxy;
    
    public IntraVmHandle(final Object proxy) {
        this.theProxy = proxy;
    }
    
    public EJBHome getEJBHome() {
        return (EJBHome)this.theProxy;
    }
    
    public EJBObject getEJBObject() {
        return (EJBObject)this.theProxy;
    }
    
    public Object getPrimaryKey() {
        return ((BaseEjbProxyHandler)ProxyManager.getInvocationHandler(this.theProxy)).primaryKey;
    }
    
    protected Object writeReplace() throws ObjectStreamException {
        if (IntraVmCopyMonitor.isIntraVmCopyOperation()) {
            return new IntraVmArtifact(this);
        }
        if (IntraVmCopyMonitor.isStatefulPassivationOperation()) {
            return this;
        }
        if (IntraVmCopyMonitor.isCrossClassLoaderOperation()) {
            return this;
        }
        final BaseEjbProxyHandler handler = (BaseEjbProxyHandler)ProxyManager.getInvocationHandler(this.theProxy);
        if (this.theProxy instanceof EJBObject) {
            final ApplicationServer applicationServer = ServerFederation.getApplicationServer();
            return applicationServer.getHandle(handler.getProxyInfo());
        }
        if (this.theProxy instanceof EJBHome) {
            final ApplicationServer applicationServer = ServerFederation.getApplicationServer();
            return applicationServer.getHomeHandle(handler.getProxyInfo());
        }
        throw new OpenEJBRuntimeException("Invalid proxy type. Handles are only supported by EJBObject types in EJB 1.1");
    }
}
