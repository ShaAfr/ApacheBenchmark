// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.Context;
import org.apache.openejb.util.Strings;
import org.apache.openejb.core.WebContext;
import org.apache.openejb.AppContext;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import java.util.Iterator;
import java.util.Collection;
import javax.naming.NameNotFoundException;
import java.util.ArrayList;
import javax.naming.NamingException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.List;

public class ContextualJndiReference extends IntraVmJndiReference
{
    public static final ThreadLocal<Boolean> followReference;
    private Object defaultValue;
    private final List<String> prefixes;
    
    public ContextualJndiReference(final String jndiName) {
        super(jndiName);
        this.prefixes = new CopyOnWriteArrayList<String>();
    }
    
    public void setDefaultValue(final Object defaultValue) {
        this.defaultValue = defaultValue;
    }
    
    public void addPrefix(final String value) {
        if (value != null) {
            this.prefixes.add(value);
        }
    }
    
    public void removePrefix(final String value) {
        if (value != null) {
            this.prefixes.remove(value);
        }
    }
    
    public String lastPrefix() {
        if (this.prefixes.isEmpty()) {
            return null;
        }
        return this.prefixes.get(this.prefixes.size() - 1);
    }
    
    public boolean hasNoMorePrefix() {
        return this.prefixes.isEmpty();
    }
    
    public int prefixesSize() {
        return this.prefixes.size();
    }
    
    @Override
    public Object getObject() throws NamingException {
        final Object delegate = this.findDelegate();
        if (Reference.class.isInstance(delegate)) {
            return Reference.class.cast(delegate).getObject();
        }
        return delegate;
    }
    
    private Object findDelegate() throws NameNotFoundException {
        final Boolean rawValue = !ContextualJndiReference.followReference.get();
        ContextualJndiReference.followReference.remove();
        if (rawValue) {
            return this;
        }
        final String prefix = this.findPrefix();
        final String jndiName = this.getJndiName();
        if (prefix != null && !prefix.isEmpty()) {
            try {
                return this.lookup(prefix + '/' + jndiName);
            }
            catch (NamingException ex) {}
        }
        final Collection<Object> values = new ArrayList<Object>();
        for (final String p : this.prefixes) {
            if (p != null && !p.isEmpty()) {
                try {
                    values.add(this.lookup(p + '/' + jndiName));
                }
                catch (NamingException ex2) {}
            }
        }
        if (1 == values.size()) {
            return values.iterator().next();
        }
        if (!values.isEmpty()) {
            throw new NameNotFoundException("Ambiguous resource '" + this.getJndiName() + "'  for classloader " + Thread.currentThread().getContextClassLoader());
        }
        return this.defaultValue;
    }
    
    private String findPrefix() {
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        for (final AppContext appContext : containerSystem.getAppContexts()) {
            if (appContext.getClassLoader().equals(loader)) {
                return appContext.getId();
            }
            for (final WebContext web : appContext.getWebContexts()) {
                if (web.getClassLoader().equals(loader)) {
                    return appContext.getId();
                }
            }
        }
        if (1 == containerSystem.getAppContexts().size()) {
            return containerSystem.getAppContexts().iterator().next().getId();
        }
        return null;
    }
    
    private Object lookup(final String s) throws NamingException {
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        final Context jndiContext = containerSystem.getJNDIContext();
        try {
            if (s.startsWith("java:") | s.startsWith("openejb:")) {
                return jndiContext.lookup(s);
            }
            return jndiContext.lookup("openejb/Resource/" + s);
        }
        catch (NameNotFoundException e2) {
            return jndiContext.lookup("java:module/" + Strings.lastPart(this.getClassName(), '.'));
        }
        catch (NamingException e) {
            throw (NamingException)new NamingException("could not look up " + s).initCause(e);
        }
    }
    
    @Override
    public String toString() {
        return "ContextualJndiReference{jndiName='" + this.getJndiName() + '\'' + '}';
    }
    
    static {
        followReference = new ThreadLocal<Boolean>() {
            public Boolean initialValue() {
                return true;
            }
        };
    }
}
