// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import javax.transaction.Transaction;
import org.apache.openejb.SystemException;
import org.apache.openejb.ApplicationException;
import java.rmi.RemoteException;
import javax.transaction.TransactionManager;

public class TxNever extends JtaTransactionPolicy
{
    public TxNever(final TransactionManager transactionManager) throws SystemException, ApplicationException {
        super(TransactionType.Never, transactionManager);
        if (this.getTransaction() != null) {
            throw new ApplicationException(new RemoteException("Transactions not supported"));
        }
    }
    
    @Override
    public boolean isNewTransaction() {
        return false;
    }
    
    @Override
    public boolean isClientTransaction() {
        return false;
    }
    
    @Override
    public Transaction getCurrentTransaction() {
        return null;
    }
    
    @Override
    public void commit() {
        this.fireNonTransactionalCompletion();
    }
}
