// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.ws.rs.ext.ContextResolver;

public class ThreadLocalContextResolver extends AbstractRestThreadLocalProxy<ContextResolver> implements ContextResolver
{
    protected ThreadLocalContextResolver() {
        super(ContextResolver.class);
    }
    
    public Object getContext(final Class type) {
        return (this.get() != null) ? this.get().getContext(type) : null;
    }
}
