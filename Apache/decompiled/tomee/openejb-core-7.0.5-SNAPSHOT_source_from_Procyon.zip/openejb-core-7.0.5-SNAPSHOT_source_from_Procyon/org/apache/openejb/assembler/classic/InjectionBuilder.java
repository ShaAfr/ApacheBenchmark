// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.OpenEJBException;
import java.util.Iterator;
import java.util.ArrayList;
import org.apache.openejb.Injection;
import java.util.List;

public class InjectionBuilder
{
    private final ClassLoader classLoader;
    
    public InjectionBuilder(final ClassLoader classLoader) {
        this.classLoader = classLoader;
    }
    
    public List<Injection> buildInjections(final JndiEncInfo jndiEnc) throws OpenEJBException {
        final List<Injection> injections = new ArrayList<Injection>();
        for (final EnvEntryInfo info : jndiEnc.envEntries) {
            for (final InjectionInfo target : info.targets) {
                final Injection injection = this.injection(info.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        for (final EjbReferenceInfo info2 : jndiEnc.ejbReferences) {
            for (final InjectionInfo target : info2.targets) {
                final Injection injection = this.injection(info2.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        for (final EjbReferenceInfo info2 : jndiEnc.ejbLocalReferences) {
            for (final InjectionInfo target : info2.targets) {
                final Injection injection = this.injection(info2.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        for (final PersistenceUnitReferenceInfo info3 : jndiEnc.persistenceUnitRefs) {
            for (final InjectionInfo target : info3.targets) {
                final Injection injection = this.injection(info3.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        for (final PersistenceContextReferenceInfo info4 : jndiEnc.persistenceContextRefs) {
            for (final InjectionInfo target : info4.targets) {
                final Injection injection = this.injection(info4.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        for (final ResourceReferenceInfo info5 : jndiEnc.resourceRefs) {
            for (final InjectionInfo target : info5.targets) {
                final Injection injection = this.injection(info5.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        for (final ResourceEnvReferenceInfo info6 : jndiEnc.resourceEnvRefs) {
            for (final InjectionInfo target : info6.targets) {
                final Injection injection = this.injection(info6.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        for (final ServiceReferenceInfo info7 : jndiEnc.serviceRefs) {
            for (final InjectionInfo target : info7.targets) {
                final Injection injection = this.injection(info7.referenceName, target.propertyName, target.className);
                injections.add(injection);
            }
        }
        return injections;
    }
    
    private Injection injection(final String referenceName, final String propertyName, final String className) {
        Class<?> targetClass;
        try {
            targetClass = (Class<?>)this.loadClass(className);
        }
        catch (OpenEJBException ex) {
            targetClass = null;
        }
        if (targetClass == null) {
            return new Injection(referenceName, propertyName, className);
        }
        return new Injection(referenceName, propertyName, targetClass);
    }
    
    private Class loadClass(final String className) throws OpenEJBException {
        try {
            final Class clazz = Class.forName(className, true, this.classLoader);
            return clazz;
        }
        catch (Throwable e) {
            throw new OpenEJBException("Unable to load class " + className);
        }
    }
}
