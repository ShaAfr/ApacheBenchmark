// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public interface DeploymentListener
{
    void afterApplicationCreated(final AppInfo p0);
    
    void beforeApplicationDestroyed(final AppInfo p0);
}
