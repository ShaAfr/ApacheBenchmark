// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import javax.xml.rpc.handler.MessageContext;
import org.apache.openejb.core.Operation;
import org.apache.openejb.core.BaseContext;
import org.apache.openejb.core.ThreadContext;
import javax.transaction.UserTransaction;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.core.BaseSessionContext;

public class StatefulContext extends BaseSessionContext
{
    public StatefulContext(final SecurityService securityService, final UserTransaction userTransaction) {
        super(securityService, userTransaction);
    }
    
    public void check(final ThreadContext context, final Call call) {
        final Operation operation = context.getCurrentOperation();
        switch (call) {
            case getCallerPrincipal:
            case isCallerInRole:
            case getUserTransaction:
            case getTimerService:
            case getEJBLocalObject:
            case getEJBObject:
            case getBusinessObject:
            case getContextData: {
                switch (operation) {
                    case INJECTION: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            case setRollbackOnly:
            case getRollbackOnly:
            case timerMethod: {
                switch (operation) {
                    case INJECTION:
                    case CREATE:
                    case AFTER_COMPLETION:
                    case PRE_DESTROY:
                    case REMOVE:
                    case POST_CONSTRUCT: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            case getInvokedBusinessInterface: {
                switch (operation) {
                    case INJECTION:
                    case CREATE:
                    case AFTER_COMPLETION:
                    case PRE_DESTROY:
                    case REMOVE:
                    case POST_CONSTRUCT:
                    case AFTER_BEGIN:
                    case BEFORE_COMPLETION:
                    case TIMEOUT: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            case UserTransactionMethod: {
                switch (operation) {
                    case INJECTION:
                    case AFTER_COMPLETION: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            default: {}
        }
    }
    
    @Override
    public MessageContext getMessageContext() throws IllegalStateException {
        throw new IllegalStateException("@Stateful beans do not support Web Service interfaces");
    }
}
