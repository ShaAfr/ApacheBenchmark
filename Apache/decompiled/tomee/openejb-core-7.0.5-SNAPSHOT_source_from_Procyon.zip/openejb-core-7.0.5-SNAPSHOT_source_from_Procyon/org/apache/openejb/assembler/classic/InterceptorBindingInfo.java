// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class InterceptorBindingInfo extends InfoObject
{
    public String ejbName;
    public String className;
    public final List<String> interceptors;
    public final List<String> interceptorOrder;
    public boolean excludeDefaultInterceptors;
    public boolean excludeClassInterceptors;
    public NamedMethodInfo method;
    
    public InterceptorBindingInfo() {
        this.interceptors = new ArrayList<String>();
        this.interceptorOrder = new ArrayList<String>();
    }
}
