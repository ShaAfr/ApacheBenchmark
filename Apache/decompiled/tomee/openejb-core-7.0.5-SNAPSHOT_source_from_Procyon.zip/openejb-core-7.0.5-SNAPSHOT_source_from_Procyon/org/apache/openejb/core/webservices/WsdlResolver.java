// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.net.URLConnection;
import java.io.IOException;
import java.net.URISyntaxException;
import java.io.File;
import java.net.URL;
import org.xml.sax.InputSource;
import javax.wsdl.xml.WSDLLocator;

public class WsdlResolver implements WSDLLocator
{
    private String baseUri;
    private String importedUri;
    private InputSource inputSource;
    
    public WsdlResolver(final String baseURI, final InputSource is) {
        this.baseUri = baseURI;
        this.inputSource = is;
    }
    
    public InputSource getBaseInputSource() {
        return this.inputSource;
    }
    
    public String getBaseURI() {
        return this.baseUri;
    }
    
    public String getLatestImportURI() {
        return this.importedUri;
    }
    
    public InputSource getImportInputSource(final String parent, final String importLocation) {
        this.baseUri = parent;
        try {
            final URL parentUrl = new URL(parent);
            final URL importUrl = new URL(parentUrl, importLocation);
            if (importUrl != null && !importUrl.getProtocol().startsWith("file")) {
                final URLConnection con = importUrl.openConnection();
                con.setUseCaches(false);
                this.inputSource = new InputSource(con.getInputStream());
            }
            else {
                final File file = new File(importUrl.toURI());
                if (file.exists()) {
                    final UriResolver resolver = new UriResolver(parent.toString(), importLocation);
                    this.inputSource = new InputSource(resolver.getInputStream());
                }
                else {
                    final UriResolver resolver = new UriResolver(importLocation);
                    if (resolver.isResolved()) {
                        this.inputSource = new InputSource(resolver.getInputStream());
                    }
                }
            }
            this.importedUri = importUrl.toURI().toString();
        }
        catch (URISyntaxException ex) {}
        catch (IOException ex2) {}
        return this.inputSource;
    }
    
    public void close() {
        if (this.inputSource.getByteStream() != null) {
            try {
                this.inputSource.getByteStream().close();
            }
            catch (IOException ex) {}
        }
    }
}
