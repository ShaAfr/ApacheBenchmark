// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import javax.persistence.Parameter;
import java.util.Date;
import javax.persistence.TemporalType;
import java.util.Calendar;
import javax.persistence.LockModeType;
import javax.persistence.FlushModeType;
import java.util.List;
import javax.persistence.Query;
import java.lang.reflect.Method;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class JtaTypedQuery<X> extends JtaQuery implements TypedQuery<X>
{
    public JtaTypedQuery(final EntityManager entityManager, final JtaEntityManager jtaEm, final Method method, final Object... args) {
        super(entityManager, jtaEm, method, args);
    }
    
    @Override
    protected Class<? extends Query> queryType() {
        return (Class<? extends Query>)TypedQuery.class;
    }
    
    @Override
    public List<X> getResultList() {
        return (List<X>)super.getResultList();
    }
    
    @Override
    public X getSingleResult() {
        return (X)super.getSingleResult();
    }
    
    public TypedQuery<X> setFirstResult(final int i) {
        super.setFirstResult(i);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setFlushMode(final FlushModeType flushModeType) {
        super.setFlushMode(flushModeType);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setHint(final String s, final Object o) {
        super.setHint(s, o);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setLockMode(final LockModeType lockMode) {
        super.setLockMode(lockMode);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setMaxResults(final int i) {
        super.setMaxResults(i);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final int i, final Calendar calendar, final TemporalType temporalType) {
        super.setParameter(i, calendar, temporalType);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final int i, final Date date, final TemporalType temporalType) {
        super.setParameter(i, date, temporalType);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final int i, final Object o) {
        super.setParameter(i, o);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final Parameter<Calendar> param, final Calendar value, final TemporalType temporalType) {
        super.setParameter(param, value, temporalType);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final Parameter<Date> param, final Date value, final TemporalType temporalType) {
        super.setParameter(param, value, temporalType);
        return (TypedQuery<X>)this;
    }
    
    public <T> TypedQuery<X> setParameter(final Parameter<T> param, final T value) {
        super.setParameter(param, value);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final String s, final Calendar calendar, final TemporalType temporalType) {
        super.setParameter(s, calendar, temporalType);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final String s, final Date date, final TemporalType temporalType) {
        super.setParameter(s, date, temporalType);
        return (TypedQuery<X>)this;
    }
    
    public TypedQuery<X> setParameter(final String s, final Object o) {
        super.setParameter(s, o);
        return (TypedQuery<X>)this;
    }
}
