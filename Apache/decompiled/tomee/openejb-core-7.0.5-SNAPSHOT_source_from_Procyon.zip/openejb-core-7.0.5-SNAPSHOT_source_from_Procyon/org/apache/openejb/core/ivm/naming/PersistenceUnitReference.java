// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;

public class PersistenceUnitReference extends Reference
{
    private final EntityManagerFactory emf;
    
    public PersistenceUnitReference(final EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    @Override
    public Object getObject() throws NamingException {
        return this.emf;
    }
}
