// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateless;

import java.io.IOException;
import java.io.Flushable;
import java.util.ArrayList;
import javax.ejb.SessionContext;
import org.apache.openejb.util.LogCategory;
import java.util.concurrent.ExecutorService;
import javax.management.ObjectName;
import java.util.Iterator;
import javax.management.MBeanServer;
import javax.naming.Context;
import org.apache.xbean.recipe.ObjectRecipe;
import java.util.concurrent.Executors;
import org.apache.openejb.monitoring.ManagedMBean;
import org.apache.openejb.core.interceptor.InterceptorInstance;
import org.apache.openejb.monitoring.StatsInterceptor;
import org.apache.openejb.monitoring.LocalMBeanServer;
import org.apache.openejb.monitoring.ObjectNameBuilder;
import javax.naming.NamingException;
import org.apache.openejb.core.timer.TimerServiceWrapper;
import javax.ejb.EJBContext;
import java.util.concurrent.Executor;
import java.util.Map;
import org.apache.xbean.recipe.Option;
import org.apache.openejb.util.PassthroughFactory;
import org.apache.openejb.loader.Options;
import org.apache.openejb.core.interceptor.InterceptorData;
import java.util.List;
import org.apache.openejb.cdi.CdiEjbBean;
import org.apache.openejb.core.interceptor.InterceptorStack;
import javax.ejb.SessionBean;
import org.apache.openejb.core.Operation;
import org.apache.openejb.SystemException;
import org.apache.openejb.core.InstanceContext;
import java.rmi.RemoteException;
import java.lang.reflect.InvocationTargetException;
import org.apache.openejb.BeanContext;
import org.apache.openejb.OpenEJBException;
import java.util.concurrent.TimeoutException;
import org.apache.openejb.ApplicationException;
import javax.ejb.ConcurrentAccessTimeoutException;
import org.apache.openejb.core.ThreadContext;
import java.util.logging.Level;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import org.apache.openejb.util.DaemonThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import org.apache.openejb.util.Pool;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.Duration;
import java.lang.reflect.Method;
import org.apache.openejb.util.Logger;

public class StatelessInstanceManager
{
    private static final Logger logger;
    private static final Method removeSessionBeanMethod;
    private final Duration accessTimeout;
    private final Duration closeTimeout;
    private final SecurityService securityService;
    private final Pool.Builder poolBuilder;
    private final ThreadPoolExecutor executor;
    private final ScheduledExecutorService scheduledExecutor;
    
    public StatelessInstanceManager(final SecurityService securityService, final Duration accessTimeout, final Duration closeTimeout, final Pool.Builder poolBuilder, final int callbackThreads, final ScheduledExecutorService ses) {
        this.securityService = securityService;
        this.accessTimeout = accessTimeout;
        this.closeTimeout = closeTimeout;
        this.poolBuilder = poolBuilder;
        this.scheduledExecutor = ses;
        if (ScheduledThreadPoolExecutor.class.isInstance(ses) && !ScheduledThreadPoolExecutor.class.cast(ses).getRemoveOnCancelPolicy()) {
            ScheduledThreadPoolExecutor.class.cast(ses).setRemoveOnCancelPolicy(true);
        }
        if (accessTimeout.getUnit() == null) {
            accessTimeout.setUnit(TimeUnit.MILLISECONDS);
        }
        final int qsize = (callbackThreads > 1) ? (callbackThreads - 1) : 1;
        final ThreadFactory threadFactory = new DaemonThreadFactory(new Object[] { "StatelessPool.worker." });
        (this.executor = new ThreadPoolExecutor(callbackThreads, callbackThreads * 2, 1L, TimeUnit.MINUTES, new LinkedBlockingQueue<Runnable>(qsize), threadFactory)).setRejectedExecutionHandler(new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(final Runnable r, final ThreadPoolExecutor tpe) {
                if (null == r || null == tpe || tpe.isShutdown() || tpe.isTerminated() || tpe.isTerminating()) {
                    return;
                }
                try {
                    if (!tpe.getQueue().offer(r, 20L, TimeUnit.SECONDS)) {
                        StatelessInstanceManager.logger.warning("Executor failed to run asynchronous process: " + r);
                    }
                }
                catch (InterruptedException ex) {}
            }
        });
    }
    
    public void destroy() {
        if (this.executor != null) {
            this.executor.shutdown();
            try {
                if (!this.executor.awaitTermination(10000L, TimeUnit.MILLISECONDS)) {
                    java.util.logging.Logger.getLogger(this.getClass().getName()).log(Level.WARNING, this.getClass().getSimpleName() + " pool  timeout expired");
                }
            }
            catch (InterruptedException e) {
                Thread.interrupted();
            }
        }
        if (this.scheduledExecutor != null) {
            this.scheduledExecutor.shutdown();
            try {
                if (!this.scheduledExecutor.awaitTermination(10000L, TimeUnit.MILLISECONDS)) {
                    java.util.logging.Logger.getLogger(this.getClass().getName()).log(Level.WARNING, this.getClass().getSimpleName() + " pool  timeout expired");
                }
            }
            catch (InterruptedException e) {
                Thread.interrupted();
            }
        }
    }
    
    public Instance getInstance(final ThreadContext callContext) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final Data data = (Data)beanContext.getContainerData();
        Instance instance = null;
        try {
            final Pool.Entry entry = data.poolPop();
            if (entry != null) {
                instance = entry.get();
                instance.setPoolEntry(entry);
            }
        }
        catch (TimeoutException e2) {
            final String msg = "No instances available in Stateless Session Bean pool.  Waited " + data.accessTimeout.toString();
            final ConcurrentAccessTimeoutException timeoutException = new ConcurrentAccessTimeoutException(msg);
            timeoutException.fillInStackTrace();
            throw new ApplicationException((Exception)timeoutException);
        }
        catch (InterruptedException e) {
            Thread.interrupted();
            throw new OpenEJBException("Unexpected Interruption of current thread: ", e);
        }
        if (null == instance) {
            instance = this.createInstance(callContext, beanContext);
        }
        return instance;
    }
    
    private Instance createInstance(final ThreadContext callContext, final BeanContext beanContext) throws ApplicationException {
        try {
            final InstanceContext context = beanContext.newInstance();
            return new Instance(context.getBean(), context.getInterceptors(), context.getCreationalContext());
        }
        catch (Throwable e) {
            if (e instanceof InvocationTargetException) {
                e = ((InvocationTargetException)e).getTargetException();
            }
            final String t = "The bean instance " + beanContext.getDeploymentID() + " threw a system exception:" + e;
            StatelessInstanceManager.logger.error(t, e);
            throw new ApplicationException(new RemoteException("Cannot obtain a free instance.", e));
        }
    }
    
    public void poolInstance(final ThreadContext callContext, final Object bean) throws OpenEJBException {
        if (bean == null) {
            throw new SystemException("Invalid arguments");
        }
        final Instance instance = Instance.class.cast(bean);
        final BeanContext beanContext = callContext.getBeanContext();
        final Data data = (Data)beanContext.getContainerData();
        final Pool<Instance> pool = data.getPool();
        if (instance.getPoolEntry() != null) {
            pool.push(instance.getPoolEntry());
        }
        else {
            pool.push(instance);
        }
    }
    
    public void discardInstance(final ThreadContext callContext, final Object bean) throws SystemException {
        if (bean == null) {
            throw new SystemException("Invalid arguments");
        }
        final Instance instance = Instance.class.cast(bean);
        final BeanContext beanContext = callContext.getBeanContext();
        final Data data = (Data)beanContext.getContainerData();
        if (null != data) {
            final Pool<Instance> pool = data.getPool();
            pool.discard(instance.getPoolEntry());
        }
    }
    
    private void freeInstance(final ThreadContext callContext, final Instance instance) {
        try {
            callContext.setCurrentOperation(Operation.PRE_DESTROY);
            final BeanContext beanContext = callContext.getBeanContext();
            final Method remove = (instance.bean instanceof SessionBean) ? StatelessInstanceManager.removeSessionBeanMethod : null;
            final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
            final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, remove, Operation.PRE_DESTROY, callbackInterceptors, instance.interceptors);
            final CdiEjbBean<Object> bean = beanContext.get((Class<CdiEjbBean<Object>>)CdiEjbBean.class);
            if (bean != null) {
                bean.getInjectionTarget().preDestroy(instance.bean);
            }
            interceptorStack.invoke(new Object[0]);
            if (instance.creationalContext != null) {
                instance.creationalContext.release();
            }
        }
        catch (Throwable re) {
            StatelessInstanceManager.logger.error("The bean instance " + instance + " threw a system exception:" + re, re);
        }
    }
    
    public void deploy(final BeanContext beanContext) throws OpenEJBException {
        final Options options = new Options(beanContext.getProperties());
        final Duration accessTimeout = this.getDuration(options, "AccessTimeout", this.getDuration(options, "Timeout", this.accessTimeout, TimeUnit.MILLISECONDS), TimeUnit.MILLISECONDS);
        final Duration closeTimeout = this.getDuration(options, "CloseTimeout", this.closeTimeout, TimeUnit.MINUTES);
        final ObjectRecipe recipe = PassthroughFactory.recipe(new Pool.Builder(this.poolBuilder));
        recipe.allow(Option.CASE_INSENSITIVE_FACTORY);
        recipe.allow(Option.CASE_INSENSITIVE_PROPERTIES);
        recipe.allow(Option.IGNORE_MISSING_PROPERTIES);
        recipe.setAllProperties((Map)beanContext.getProperties());
        final Pool.Builder builder = (Pool.Builder)recipe.create();
        this.setDefault(builder.getMaxAge(), TimeUnit.HOURS);
        this.setDefault(builder.getIdleTimeout(), TimeUnit.MINUTES);
        this.setDefault(builder.getInterval(), TimeUnit.MINUTES);
        final StatelessSupplier supplier = new StatelessSupplier(beanContext);
        builder.setSupplier(supplier);
        builder.setExecutor(this.executor);
        builder.setScheduledExecutor(this.scheduledExecutor);
        final Data data = new Data((Pool)builder.build(), accessTimeout, closeTimeout);
        beanContext.setContainerData(data);
        beanContext.set((Class<Object>)EJBContext.class, data.sessionContext);
        try {
            final Context context = beanContext.getJndiEnc();
            context.bind("comp/EJBContext", data.sessionContext);
            context.bind("comp/WebServiceContext", new EjbWsContext(data.sessionContext));
            context.bind("comp/TimerService", new TimerServiceWrapper());
        }
        catch (NamingException e) {
            throw new OpenEJBException("Failed to bind EJBContext/WebServiceContext/TimerService", e);
        }
        final int min = builder.getMin();
        final long maxAge = builder.getMaxAge().getTime(TimeUnit.MILLISECONDS);
        final double maxAgeOffset = builder.getMaxAgeOffset();
        final ObjectNameBuilder jmxName = new ObjectNameBuilder("openejb.management");
        jmxName.set("J2EEServer", "openejb");
        jmxName.set("J2EEApplication", null);
        jmxName.set("EJBModule", beanContext.getModuleID());
        jmxName.set("StatelessSessionBean", beanContext.getEjbName());
        jmxName.set("name", beanContext.getEjbName());
        final MBeanServer server = LocalMBeanServer.get();
        if (StatsInterceptor.isStatsActivated()) {
            StatsInterceptor stats = null;
            for (final InterceptorInstance interceptor : beanContext.getUserAndSystemInterceptors()) {
                if (interceptor.getInterceptor() instanceof StatsInterceptor) {
                    stats = (StatsInterceptor)interceptor.getInterceptor();
                }
            }
            if (stats == null) {
                stats = new StatsInterceptor(beanContext.getBeanClass());
                beanContext.addFirstSystemInterceptor(stats);
            }
            try {
                final ObjectName objectName = jmxName.set("j2eeType", "Invocations").build();
                if (server.isRegistered(objectName)) {
                    server.unregisterMBean(objectName);
                }
                server.registerMBean(new ManagedMBean(stats), objectName);
                data.add(objectName);
            }
            catch (Exception e2) {
                StatelessInstanceManager.logger.error("Unable to register MBean ", e2);
            }
        }
        try {
            final ObjectName objectName2 = jmxName.set("j2eeType", "Pool").build();
            if (server.isRegistered(objectName2)) {
                server.unregisterMBean(objectName2);
            }
            server.registerMBean(new ManagedMBean(data.pool), objectName2);
            data.add(objectName2);
        }
        catch (Exception e3) {
            StatelessInstanceManager.logger.error("Unable to register MBean ", e3);
        }
        if (!options.get("BackgroundStartup", false) && min > 0) {
            final ExecutorService es = Executors.newFixedThreadPool(min);
            for (int i = 0; i < min; ++i) {
                es.submit(new InstanceCreatorRunnable(maxAge, (long)i, (long)min, maxAgeOffset, data, supplier));
            }
            es.shutdown();
            try {
                es.awaitTermination(5L, TimeUnit.MINUTES);
            }
            catch (InterruptedException e4) {
                StatelessInstanceManager.logger.error("can't fill the stateless pool", e4);
            }
        }
        data.getPool().start();
    }
    
    private void setDefault(final Duration duration, final TimeUnit unit) {
        if (duration.getUnit() == null) {
            duration.setUnit(unit);
        }
    }
    
    private Duration getDuration(final Options options, final String property, final Duration defaultValue, final TimeUnit defaultUnit) {
        final String s = options.get(property, defaultValue.toString());
        final Duration duration = new Duration(s);
        if (duration.getUnit() == null) {
            duration.setUnit(defaultUnit);
        }
        return duration;
    }
    
    public void undeploy(final BeanContext beanContext) {
        final Data data = (Data)beanContext.getContainerData();
        if (data == null) {
            return;
        }
        final MBeanServer server = LocalMBeanServer.get();
        for (final ObjectName objectName : data.jmxNames) {
            try {
                server.unregisterMBean(objectName);
            }
            catch (Exception e) {
                StatelessInstanceManager.logger.error("Unable to unregister MBean " + objectName);
            }
        }
        try {
            if (!data.closePool()) {
                StatelessInstanceManager.logger.error("Timed-out waiting for stateless pool to close: for deployment '" + beanContext.getDeploymentID() + "'");
            }
        }
        catch (InterruptedException e2) {
            Thread.interrupted();
        }
        beanContext.setContainerData(null);
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
        Method foundRemoveMethod;
        try {
            foundRemoveMethod = SessionBean.class.getDeclaredMethod("ejbRemove", (Class<?>[])new Class[0]);
        }
        catch (NoSuchMethodException e) {
            foundRemoveMethod = null;
        }
        removeSessionBeanMethod = foundRemoveMethod;
    }
    
    private final class StatelessSupplier implements Pool.Supplier<Instance>
    {
        private final BeanContext beanContext;
        
        private StatelessSupplier(final BeanContext beanContext) {
            this.beanContext = beanContext;
        }
        
        @Override
        public void discard(final Instance instance, final Pool.Event reason) {
            final ThreadContext ctx = new ThreadContext(this.beanContext, null);
            final ThreadContext oldCallContext = ThreadContext.enter(ctx);
            try {
                StatelessInstanceManager.this.freeInstance(ctx, instance);
            }
            finally {
                ThreadContext.exit(oldCallContext);
            }
        }
        
        @Override
        public Instance create() {
            final ThreadContext ctx = new ThreadContext(this.beanContext, null);
            final ThreadContext oldCallContext = ThreadContext.enter(ctx);
            try {
                return StatelessInstanceManager.this.createInstance(ctx, ctx.getBeanContext());
            }
            catch (OpenEJBException e) {
                StatelessInstanceManager.logger.error("Unable to fill pool: for deployment '" + this.beanContext.getDeploymentID() + "'", e);
            }
            finally {
                ThreadContext.exit(oldCallContext);
            }
            return null;
        }
    }
    
    private final class Data
    {
        private final Pool<Instance> pool;
        private final Duration accessTimeout;
        private final Duration closeTimeout;
        private final List<ObjectName> jmxNames;
        private final SessionContext sessionContext;
        
        private Data(final Pool<Instance> pool, final Duration accessTimeout, final Duration closeTimeout) {
            this.jmxNames = new ArrayList<ObjectName>();
            this.pool = pool;
            this.accessTimeout = accessTimeout;
            this.closeTimeout = closeTimeout;
            this.sessionContext = (SessionContext)new StatelessContext(StatelessInstanceManager.this.securityService, new Flushable() {
                @Override
                public void flush() throws IOException {
                    Data.this.getPool().flush();
                }
            });
        }
        
        public Duration getAccessTimeout() {
            return this.accessTimeout;
        }
        
        public Pool.Entry poolPop() throws InterruptedException, TimeoutException {
            return this.pool.pop(this.accessTimeout.getTime(), this.accessTimeout.getUnit());
        }
        
        public Pool<Instance> getPool() {
            return this.pool;
        }
        
        public boolean closePool() throws InterruptedException {
            return this.pool.close(this.closeTimeout.getTime(), this.closeTimeout.getUnit());
        }
        
        public ObjectName add(final ObjectName name) {
            this.jmxNames.add(name);
            return name;
        }
    }
    
    private final class InstanceCreatorRunnable implements Runnable
    {
        private final long maxAge;
        private final long iteration;
        private final double maxAgeOffset;
        private final long min;
        private final Data data;
        private final StatelessSupplier supplier;
        
        private InstanceCreatorRunnable(final long maxAge, final long iteration, final long min, final double maxAgeOffset, final Data data, final StatelessSupplier supplier) {
            this.maxAge = maxAge;
            this.iteration = iteration;
            this.min = min;
            this.maxAgeOffset = maxAgeOffset;
            this.data = data;
            this.supplier = supplier;
        }
        
        @Override
        public void run() {
            final Instance obj = this.supplier.create();
            if (obj != null) {
                final long offset = (this.maxAge > 0L) ? ((long)(this.maxAge / this.maxAgeOffset * this.min * this.iteration) % this.maxAge) : 0L;
                this.data.getPool().add(obj, offset);
            }
        }
    }
}
