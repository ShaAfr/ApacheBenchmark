// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import java.util.Enumeration;
import javax.servlet.ServletContext;
import javax.servlet.ServletConfig;

public class ThreadLocalServletConfig extends AbstractRestThreadLocalProxy<ServletConfig> implements ServletConfig
{
    protected ThreadLocalServletConfig() {
        super(ServletConfig.class);
    }
    
    public String getServletName() {
        return this.get().getServletName();
    }
    
    public ServletContext getServletContext() {
        return this.get().getServletContext();
    }
    
    public String getInitParameter(final String name) {
        return this.get().getInitParameter(name);
    }
    
    public Enumeration<String> getInitParameterNames() {
        return (Enumeration<String>)this.get().getInitParameterNames();
    }
}
