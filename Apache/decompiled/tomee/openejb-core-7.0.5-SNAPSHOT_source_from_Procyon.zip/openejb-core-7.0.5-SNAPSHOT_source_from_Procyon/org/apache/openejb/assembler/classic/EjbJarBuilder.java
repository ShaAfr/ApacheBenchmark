// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Iterator;
import javax.naming.Context;
import java.util.List;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.Container;
import java.util.Map;
import org.apache.openejb.ModuleContext;
import org.apache.openejb.ModuleTestContext;
import org.apache.openejb.BeanContext;
import java.util.HashMap;
import org.apache.openejb.Injection;
import java.util.Collection;
import org.apache.openejb.AppContext;
import java.util.Properties;

public class EjbJarBuilder
{
    private final Properties props;
    private final AppContext context;
    
    public EjbJarBuilder(final Properties props, final AppContext context) {
        this.props = props;
        this.context = context;
    }
    
    public HashMap<String, BeanContext> build(final EjbJarInfo ejbJar, final Collection<Injection> appInjections, final ClassLoader classLoader) throws OpenEJBException {
        final InjectionBuilder injectionBuilder = new InjectionBuilder(classLoader);
        final List<Injection> moduleInjections = injectionBuilder.buildInjections(ejbJar.moduleJndiEnc);
        moduleInjections.addAll(appInjections);
        final Context moduleJndiContext = new JndiEncBuilder(ejbJar.moduleJndiEnc, moduleInjections, null, ejbJar.moduleName, ejbJar.moduleUri, ejbJar.uniqueId, classLoader, this.context.getProperties()).build(JndiEncBuilder.JndiScope.module);
        final HashMap<String, BeanContext> deployments = new HashMap<String, BeanContext>();
        final ModuleContext moduleContext = ejbJar.properties.containsKey("openejb.test.module") ? new ModuleTestContext(ejbJar.moduleName, ejbJar.moduleUri, ejbJar.uniqueId, this.context, moduleJndiContext, classLoader) : new ModuleContext(ejbJar.moduleName, ejbJar.moduleUri, ejbJar.uniqueId, this.context, moduleJndiContext, classLoader);
        moduleContext.getProperties().putAll(ejbJar.properties);
        final InterceptorBindingBuilder interceptorBindingBuilder = new InterceptorBindingBuilder(classLoader, ejbJar);
        final MethodScheduleBuilder methodScheduleBuilder = new MethodScheduleBuilder();
        for (final EnterpriseBeanInfo ejbInfo : ejbJar.enterpriseBeans) {
            final ClassLoader loader = Thread.currentThread().getContextClassLoader();
            Thread.currentThread().setContextClassLoader(moduleContext.getClassLoader());
            try {
                final EnterpriseBeanBuilder deploymentBuilder = new EnterpriseBeanBuilder(ejbInfo, moduleContext, moduleInjections);
                final BeanContext bean = deploymentBuilder.build();
                interceptorBindingBuilder.build(bean, ejbInfo);
                methodScheduleBuilder.build(bean, ejbInfo);
                deployments.put(ejbInfo.ejbDeploymentId, bean);
                final Container container = (Container)this.props.get(ejbInfo.containerId);
                if (container == null) {
                    throw new IllegalStateException("Container does not exist: " + ejbInfo.containerId + ".  Referenced by deployment: " + bean.getDeploymentID());
                }
                bean.setContainer(container);
            }
            catch (Throwable e) {
                throw new OpenEJBException("Error building bean '" + ejbInfo.ejbName + "'.  Exception: " + e.getClass() + ": " + e.getMessage(), e);
            }
            finally {
                Thread.currentThread().setContextClassLoader(loader);
            }
        }
        return deployments;
    }
}
