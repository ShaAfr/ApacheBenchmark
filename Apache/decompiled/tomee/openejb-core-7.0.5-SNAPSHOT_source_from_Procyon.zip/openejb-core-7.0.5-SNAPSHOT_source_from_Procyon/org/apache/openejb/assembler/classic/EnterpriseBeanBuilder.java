// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.Messages;
import javax.ejb.Timer;
import javax.ejb.TimedObject;
import javax.naming.Context;
import java.util.Set;
import java.util.Iterator;
import org.apache.openejb.core.cmp.CmpUtil;
import org.apache.openejb.util.Index;
import javax.naming.NamingException;
import org.apache.openejb.OpenEJBException;
import javax.persistence.SynchronizationType;
import org.apache.openejb.persistence.JtaEntityManager;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.persistence.EntityManagerFactory;
import java.util.HashMap;
import java.util.Arrays;
import java.lang.reflect.Method;
import org.apache.openejb.util.Duration;
import java.util.concurrent.TimeUnit;
import java.util.Map;
import java.net.URI;
import java.util.Collection;
import java.util.HashSet;
import org.apache.openejb.dyni.DynamicSubclass;
import org.apache.openejb.BeanContext;
import java.util.ArrayList;
import org.apache.openejb.Injection;
import org.apache.openejb.ModuleContext;
import java.util.List;
import org.apache.openejb.BeanType;

class EnterpriseBeanBuilder
{
    private final EnterpriseBeanInfo bean;
    private final BeanType ejbType;
    private final List<Exception> warnings;
    private final ModuleContext moduleContext;
    private final List<Injection> moduleInjections;
    
    public EnterpriseBeanBuilder(final EnterpriseBeanInfo bean, final ModuleContext moduleContext, final List<Injection> moduleInjections) {
        this.warnings = new ArrayList<Exception>();
        this.moduleContext = moduleContext;
        this.bean = bean;
        this.moduleInjections = moduleInjections;
        if (bean.type == 1) {
            this.ejbType = BeanType.STATEFUL;
        }
        else if (bean.type == 2) {
            this.ejbType = BeanType.STATELESS;
        }
        else if (bean.type == 4) {
            this.ejbType = BeanType.SINGLETON;
        }
        else if (bean.type == 5) {
            this.ejbType = BeanType.MANAGED;
        }
        else if (bean.type == 3) {
            this.ejbType = BeanType.MESSAGE_DRIVEN;
        }
        else {
            if (bean.type != 0) {
                throw new UnsupportedOperationException("No building support for bean type: " + bean);
            }
            final String persistenceType = ((EntityBeanInfo)bean).persistenceType;
            this.ejbType = (persistenceType.equalsIgnoreCase("Container") ? BeanType.CMP_ENTITY : BeanType.BMP_ENTITY);
        }
    }
    
    public BeanContext build() throws OpenEJBException {
        Class ejbClass = this.loadClass(this.bean.ejbClass, "classNotFound.ejbClass");
        if (DynamicSubclass.isDynamic(ejbClass)) {
            ejbClass = DynamicSubclass.createSubclass(ejbClass, this.moduleContext.getClassLoader());
        }
        Class home = null;
        Class remote = null;
        if (this.bean.home != null) {
            home = this.loadClass(this.bean.home, "classNotFound.home");
            remote = this.loadClass(this.bean.remote, "classNotFound.remote");
        }
        Class<?> proxy = null;
        if (this.bean.proxy != null) {
            proxy = (Class<?>)this.loadClass(this.bean.proxy, "classNotFound.proxy");
        }
        Class<?> localhome = null;
        Class<?> local = null;
        if (this.bean.localHome != null) {
            localhome = (Class<?>)this.loadClass(this.bean.localHome, "classNotFound.localHome");
            local = (Class<?>)this.loadClass(this.bean.local, "classNotFound.local");
        }
        final List<Class> businessLocals = new ArrayList<Class>();
        for (final String businessLocal : this.bean.businessLocal) {
            businessLocals.add(this.loadClass(businessLocal, "classNotFound.businessLocal"));
        }
        final List<Class> businessRemotes = new ArrayList<Class>();
        for (final String businessRemote : this.bean.businessRemote) {
            businessRemotes.add(this.loadClass(businessRemote, "classNotFound.businessRemote"));
        }
        Class serviceEndpoint = null;
        if ((BeanType.STATELESS == this.ejbType || BeanType.SINGLETON == this.ejbType) && this.bean.serviceEndpoint != null) {
            serviceEndpoint = this.loadClass(this.bean.serviceEndpoint, "classNotFound.sei");
        }
        Class primaryKey = null;
        if (this.ejbType.isEntity() && ((EntityBeanInfo)this.bean).primKeyClass != null) {
            final String className = ((EntityBeanInfo)this.bean).primKeyClass;
            primaryKey = this.loadClass(className, "classNotFound.primaryKey");
        }
        final String transactionType = this.bean.transactionType;
        final InjectionBuilder injectionBuilder = new InjectionBuilder(this.moduleContext.getClassLoader());
        final List<Injection> injections = injectionBuilder.buildInjections(this.bean.jndiEnc);
        final Set<Class<?>> relevantClasses = new HashSet<Class<?>>();
        Class c = ejbClass;
        do {
            relevantClasses.add(c);
            c = c.getSuperclass();
        } while (c != null && c != Object.class);
        for (final Injection injection : this.moduleInjections) {
            if (relevantClasses.contains(injection.getTarget())) {
                injections.add(injection);
            }
        }
        final JndiEncBuilder jndiEncBuilder = new JndiEncBuilder(this.bean.jndiEnc, injections, transactionType, this.moduleContext.getId(), null, this.moduleContext.getUniqueId(), this.moduleContext.getClassLoader(), (this.moduleContext.getAppContext() == null) ? this.moduleContext.getProperties() : this.moduleContext.getAppContext().getProperties());
        final Context compJndiContext = jndiEncBuilder.build(JndiEncBuilder.JndiScope.comp);
        this.bind(compJndiContext, "module", this.moduleContext.getModuleJndiContext());
        this.bind(compJndiContext, "app", this.moduleContext.getAppContext().getAppJndiContext());
        this.bind(compJndiContext, "global", this.moduleContext.getAppContext().getGlobalJndiContext());
        BeanContext deployment;
        if (BeanType.MESSAGE_DRIVEN != this.ejbType) {
            deployment = new BeanContext(this.bean.ejbDeploymentId, compJndiContext, this.moduleContext, ejbClass, home, remote, localhome, local, proxy, serviceEndpoint, businessLocals, businessRemotes, primaryKey, this.ejbType, this.bean.localbean && this.ejbType.isSession(), this.bean.passivable);
            if (this.bean instanceof ManagedBeanInfo) {
                deployment.setHidden(((ManagedBeanInfo)this.bean).hidden);
            }
        }
        else {
            final MessageDrivenBeanInfo messageDrivenBeanInfo = (MessageDrivenBeanInfo)this.bean;
            final Class mdbInterface = this.loadClass(messageDrivenBeanInfo.mdbInterface, "classNotFound.mdbInterface");
            deployment = new BeanContext(this.bean.ejbDeploymentId, compJndiContext, this.moduleContext, ejbClass, mdbInterface, messageDrivenBeanInfo.activationProperties);
            deployment.setDestinationId(messageDrivenBeanInfo.destinationId);
        }
        deployment.getProperties().putAll(this.bean.properties);
        deployment.setEjbName(this.bean.ejbName);
        deployment.setRunAs(this.bean.runAs);
        deployment.setRunAsUser(this.bean.runAsUser);
        deployment.getInjections().addAll(injections);
        deployment.setEjbTimeout(this.getTimeout(ejbClass, this.bean.timeoutMethod));
        if (this.bean.statefulTimeout != null) {
            deployment.setStatefulTimeout(new Duration(this.bean.statefulTimeout.time, TimeUnit.valueOf(this.bean.statefulTimeout.unit)));
        }
        if (this.bean instanceof StatefulBeanInfo) {
            final StatefulBeanInfo statefulBeanInfo = (StatefulBeanInfo)this.bean;
            for (final InitMethodInfo init : statefulBeanInfo.initMethods) {
                final Method beanMethod = MethodInfoUtil.toMethod(ejbClass, init.beanMethod);
                final List<Method> methods = new ArrayList<Method>();
                if (home != null) {
                    methods.addAll(Arrays.asList(home.getMethods()));
                }
                if (localhome != null) {
                    methods.addAll(Arrays.asList(localhome.getMethods()));
                }
                for (final Method homeMethod : methods) {
                    if (init.createMethod != null && !init.createMethod.methodName.equals(homeMethod.getName())) {
                        continue;
                    }
                    if (!homeMethod.getName().startsWith("create")) {
                        continue;
                    }
                    if (!paramsMatch(beanMethod, homeMethod)) {
                        continue;
                    }
                    deployment.mapMethods(homeMethod, beanMethod);
                }
            }
            for (final RemoveMethodInfo removeMethod : statefulBeanInfo.removeMethods) {
                if (removeMethod.beanMethod.methodParams == null) {
                    final MethodInfo methodInfo = new MethodInfo();
                    methodInfo.methodName = removeMethod.beanMethod.methodName;
                    methodInfo.methodParams = removeMethod.beanMethod.methodParams;
                    methodInfo.className = removeMethod.beanMethod.className;
                    final List<Method> methods = MethodInfoUtil.matchingMethods(methodInfo, ejbClass);
                    for (final Method method : methods) {
                        deployment.getRemoveMethods().add(method);
                        deployment.setRetainIfExeption(method, removeMethod.retainIfException);
                    }
                }
                else {
                    final Method method2 = MethodInfoUtil.toMethod(ejbClass, removeMethod.beanMethod);
                    deployment.getRemoveMethods().add(method2);
                    deployment.setRetainIfExeption(method2, removeMethod.retainIfException);
                }
            }
            final Map<EntityManagerFactory, BeanContext.EntityManagerConfiguration> extendedEntityManagerFactories = new HashMap<EntityManagerFactory, BeanContext.EntityManagerConfiguration>();
            for (final PersistenceContextReferenceInfo info : statefulBeanInfo.jndiEnc.persistenceContextRefs) {
                if (info.extended) {
                    try {
                        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
                        final Object o = containerSystem.getJNDIContext().lookup(PersistenceBuilder.getOpenEJBJndiName(info.unitId));
                        final EntityManagerFactory emf = EntityManagerFactory.class.cast(o);
                        extendedEntityManagerFactories.put(emf, new BeanContext.EntityManagerConfiguration(info.properties, (JtaEntityManager.isJPA21(emf) && info.synchronizationType != null) ? SynchronizationType.valueOf(info.synchronizationType) : null));
                    }
                    catch (NamingException e) {
                        throw new OpenEJBException("PersistenceUnit '" + info.unitId + "' not found for EXTENDED ref '" + info.referenceName + "'");
                    }
                }
            }
            deployment.setExtendedEntityManagerFactories(new Index<EntityManagerFactory, BeanContext.EntityManagerConfiguration>(extendedEntityManagerFactories));
        }
        if (this.ejbType.isSession() || this.ejbType.isMessageDriven()) {
            deployment.setBeanManagedTransaction("Bean".equalsIgnoreCase(this.bean.transactionType));
        }
        if (this.ejbType.isSession()) {
            deployment.getDependsOn().addAll(this.bean.dependsOn);
        }
        if (this.ejbType == BeanType.SINGLETON) {
            deployment.setBeanManagedConcurrency("Bean".equalsIgnoreCase(this.bean.concurrencyType));
            deployment.setLoadOnStartup(this.bean.loadOnStartup);
        }
        if (this.ejbType.isEntity()) {
            final EntityBeanInfo entity = (EntityBeanInfo)this.bean;
            deployment.setCmp2(entity.cmpVersion == 2);
            deployment.setIsReentrant(entity.reentrant.equalsIgnoreCase("true"));
            if (this.ejbType == BeanType.CMP_ENTITY) {
                Class cmpImplClass = null;
                final String cmpImplClassName = CmpUtil.getCmpImplClassName(entity.abstractSchemaName, entity.ejbClass);
                cmpImplClass = this.loadClass(cmpImplClassName, "classNotFound.cmpImplClass");
                deployment.setCmpImplClass(cmpImplClass);
                deployment.setAbstractSchemaName(entity.abstractSchemaName);
                for (final QueryInfo query : entity.queries) {
                    if (query.remoteResultType) {
                        final StringBuilder methodSignature = new StringBuilder();
                        methodSignature.append(query.method.methodName);
                        if (query.method.methodParams != null && !query.method.methodParams.isEmpty()) {
                            methodSignature.append('(');
                            boolean first = true;
                            for (final String methodParam : query.method.methodParams) {
                                if (!first) {
                                    methodSignature.append(",");
                                }
                                methodSignature.append(methodParam);
                                first = false;
                            }
                            methodSignature.append(')');
                        }
                        deployment.setRemoteQueryResults(methodSignature.toString());
                    }
                }
                if (entity.primKeyField != null) {
                    deployment.setPrimaryKeyField(entity.primKeyField);
                }
            }
        }
        deployment.createMethodMap();
        if (this.ejbType == BeanType.STATELESS || this.ejbType == BeanType.SINGLETON || this.ejbType == BeanType.STATEFUL) {
            for (final NamedMethodInfo methodInfo2 : this.bean.asynchronous) {
                final Method method3 = MethodInfoUtil.toMethod(ejbClass, methodInfo2);
                deployment.getMethodContext(deployment.getMatchingBeanMethod(method3)).setAsynchronous(true);
            }
            for (final String className2 : this.bean.asynchronousClasses) {
                deployment.getAsynchronousClasses().add(this.loadClass(className2, "classNotFound.ejbClass"));
            }
            deployment.createAsynchronousMethodSet();
        }
        for (final SecurityRoleReferenceInfo securityRoleReference : this.bean.securityRoleReferences) {
            deployment.addSecurityRoleReference(securityRoleReference.roleName, securityRoleReference.roleLink);
        }
        return deployment;
    }
    
    private void bind(final Context compJndiContext, final String s, final Context moduleJndiContext) throws OpenEJBException {
        Context c;
        try {
            c = (Context)moduleJndiContext.lookup(s);
        }
        catch (NamingException e) {
            return;
        }
        try {
            compJndiContext.bind(s, c);
        }
        catch (NamingException e) {
            throw new OpenEJBException("Could not bind context at " + s, e);
        }
    }
    
    public static boolean paramsMatch(final Method methodA, final Method methodB) {
        if (methodA.getParameterTypes().length != methodB.getParameterTypes().length) {
            return false;
        }
        for (int i = 0; i < methodA.getParameterTypes().length; ++i) {
            final Class<?> a = methodA.getParameterTypes()[i];
            final Class<?> b = methodB.getParameterTypes()[i];
            if (!a.equals(b)) {
                return false;
            }
        }
        return true;
    }
    
    public List<Exception> getWarnings() {
        return this.warnings;
    }
    
    private Method getTimeout(final Class ejbClass, final NamedMethodInfo info) {
        Method timeout = null;
        try {
            if (TimedObject.class.isAssignableFrom(ejbClass)) {
                timeout = ejbClass.getMethod("ejbTimeout", Timer.class);
            }
            else if (info != null) {
                try {
                    timeout = MethodInfoUtil.toMethod(ejbClass, info);
                }
                catch (IllegalStateException e2) {
                    if (info.methodParams == null) {
                        final NamedMethodInfo candidateInfo = new NamedMethodInfo();
                        candidateInfo.className = info.className;
                        candidateInfo.id = info.id;
                        candidateInfo.methodName = info.methodName;
                        candidateInfo.methodParams = Arrays.asList(Timer.class.getName());
                        timeout = MethodInfoUtil.toMethod(ejbClass, candidateInfo);
                    }
                }
            }
        }
        catch (Exception e) {
            this.warnings.add(e);
        }
        return timeout;
    }
    
    private Class loadClass(final String className, final String messageCode) throws OpenEJBException {
        final Class clazz = this.load(className, messageCode);
        try {
            return clazz;
        }
        catch (NoClassDefFoundError e) {
            if (clazz.getClassLoader() != this.moduleContext.getClassLoader()) {
                final String message = this.messages().format("cl0008", className, clazz.getClassLoader(), this.moduleContext.getClassLoader(), e.getMessage());
                throw new OpenEJBException(this.messages().format(messageCode, className, this.bean.ejbDeploymentId, message), e);
            }
            final String message = this.messages().format("cl0009", className, clazz.getClassLoader(), e.getMessage());
            throw new OpenEJBException(this.messages().format(messageCode, className, this.bean.ejbDeploymentId, message), e);
        }
    }
    
    private Messages messages() {
        return new Messages("org.apache.openejb.util.resources");
    }
    
    private Class load(final String className, final String messageCode) throws OpenEJBException {
        try {
            return Class.forName(className, true, this.moduleContext.getClassLoader());
        }
        catch (ClassNotFoundException e) {
            final String message = this.messages().format("cl0007", className, this.bean.codebase);
            throw new OpenEJBException(this.messages().format(messageCode, className, this.bean.ejbDeploymentId, message));
        }
    }
}
