// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import javax.naming.NamingException;
import java.io.InvalidObjectException;
import org.apache.openejb.spi.ContainerSystem;
import java.io.IOException;
import javax.management.openmbean.TabularData;
import org.apache.openejb.api.jmx.ManagedAttribute;
import javax.xml.bind.Marshaller;
import javax.xml.bind.JAXBContext;
import java.io.Writer;
import org.apache.openejb.jee.JAXBContextFactory;
import java.io.FileWriter;
import org.apache.openejb.jee.PersistenceUnitValidationMode;
import org.apache.openejb.jee.PersistenceUnitCaching;
import java.util.Collection;
import org.apache.openejb.jee.Persistence;
import org.apache.openejb.api.jmx.ManagedOperation;
import org.apache.openejb.api.jmx.Description;
import org.apache.openejb.api.jmx.MBean;
import org.apache.openejb.util.LogCategory;
import java.io.ObjectStreamException;
import javax.persistence.spi.PersistenceUnitInfo;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.File;
import java.util.List;
import javax.persistence.spi.PersistenceUnitTransactionType;
import javax.persistence.ValidationMode;
import javax.persistence.SharedCacheMode;
import org.apache.openejb.monitoring.DynamicMBeanWrapper;
import org.apache.openejb.monitoring.ObjectNameBuilder;
import javax.management.MBeanServer;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.monitoring.LocalMBeanServer;
import javax.persistence.PersistenceUnitUtil;
import javax.persistence.Cache;
import javax.persistence.metamodel.Metamodel;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.EntityGraph;
import javax.persistence.Query;
import javax.persistence.SynchronizationType;
import org.apache.openejb.persistence.QueryLogEntityManager;
import javax.persistence.EntityManager;
import org.apache.openejb.loader.SystemInstance;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.jpa.integration.JPAThreadContext;
import java.util.Properties;
import javax.management.ObjectName;
import org.apache.openejb.persistence.PersistenceUnitInfoImpl;
import org.apache.openejb.util.Logger;
import org.apache.openejb.api.internal.Internal;
import java.io.Serializable;
import javax.persistence.EntityManagerFactory;

@Internal
public class ReloadableEntityManagerFactory implements EntityManagerFactory, Serializable
{
    private static final Logger LOGGER;
    public static final String JAVAX_PERSISTENCE_SHARED_CACHE_MODE = "javax.persistence.sharedCache.mode";
    public static final String JAVAX_PERSISTENCE_VALIDATION_MODE = "javax.persistence.validation.mode";
    public static final String JAVAX_PERSISTENCE_TRANSACTION_TYPE = "javax.persistence.transactionType";
    public static final String OPENEJB_JPA_CRITERIA_LOG_JPQL = "openejb.jpa.criteria.log.jpql";
    public static final String OPENEJB_JPA_CRITERIA_LOG_JPQL_LEVEL = "openejb.jpa.criteria.log.jpql.level";
    private final PersistenceUnitInfoImpl unitInfoImpl;
    private ClassLoader classLoader;
    private volatile EntityManagerFactory delegate;
    private final EntityManagerFactoryCallable entityManagerFactoryCallable;
    private ObjectName objectName;
    private final boolean logCriteriaJpql;
    private final String logCriteriaJpqlLevel;
    
    public ReloadableEntityManagerFactory(final ClassLoader cl, final EntityManagerFactoryCallable callable, final PersistenceUnitInfoImpl unitInfo) {
        this.classLoader = cl;
        this.entityManagerFactoryCallable = callable;
        this.unitInfoImpl = unitInfo;
        final Properties properties = unitInfo.getProperties();
        this.logCriteriaJpql = this.logCriteriaQueryJpql(properties);
        this.logCriteriaJpqlLevel = this.logCriteriaQueryJpqlLevel(properties);
        if (!callable.getUnitInfo().isLazilyInitialized()) {
            this.createDelegate();
        }
    }
    
    public void overrideClassLoader(final ClassLoader loader) {
        this.classLoader = loader;
        this.entityManagerFactoryCallable.overrideClassLoader(loader);
        this.unitInfoImpl.setClassLoader(loader);
    }
    
    public EntityManagerFactoryCallable getEntityManagerFactoryCallable() {
        return this.entityManagerFactoryCallable;
    }
    
    private EntityManagerFactory delegate() {
        if (this.delegate == null) {
            synchronized (this) {
                if (this.delegate == null) {
                    this.createDelegate();
                }
            }
        }
        return this.delegate;
    }
    
    public void createDelegate() {
        JPAThreadContext.infos.put("properties", this.entityManagerFactoryCallable.getUnitInfo().getProperties());
        final long start = System.nanoTime();
        try {
            this.delegate = this.entityManagerFactoryCallable.call();
        }
        catch (Exception e) {
            throw new OpenEJBRuntimeException(e);
        }
        finally {
            final long time = TimeUnit.MILLISECONDS.convert(System.nanoTime() - start, TimeUnit.NANOSECONDS);
            ReloadableEntityManagerFactory.LOGGER.info("assembler.buildingPersistenceUnit", this.unitInfoImpl.getPersistenceUnitName(), this.unitInfoImpl.getPersistenceProviderClassName(), String.valueOf(time));
            if (ReloadableEntityManagerFactory.LOGGER.isDebugEnabled()) {
                for (final Map.Entry<Object, Object> entry : this.unitInfoImpl.getProperties().entrySet()) {
                    ReloadableEntityManagerFactory.LOGGER.debug(entry.getKey() + "=" + entry.getValue());
                }
            }
            JPAThreadContext.infos.clear();
        }
    }
    
    private String logCriteriaQueryJpqlLevel(final Properties props) {
        return SystemInstance.get().getOptions().get("openejb.jpa.criteria.log.jpql.level", props.getProperty("openejb.jpa.criteria.log.jpql.level", "INFO"));
    }
    
    private boolean logCriteriaQueryJpql(final Properties prop) {
        return SystemInstance.get().getOptions().get("openejb.jpa.criteria.log.jpql", Boolean.parseBoolean(prop.getProperty("openejb.jpa.criteria.log.jpql", "false"))) || SystemInstance.get().getOptions().get("openejb.jpa.criteria.log.jpql.level", prop.getProperty("openejb.jpa.criteria.log.jpql.level", null)) != null;
    }
    
    public EntityManager createEntityManager() {
        EntityManager em;
        try {
            em = this.delegate().createEntityManager();
        }
        catch (LinkageError le) {
            em = this.delegate.createEntityManager();
        }
        if (this.logCriteriaJpql) {
            return (EntityManager)new QueryLogEntityManager(em, this.logCriteriaJpqlLevel);
        }
        return em;
    }
    
    public EntityManager createEntityManager(final Map map) {
        EntityManager em;
        try {
            em = this.delegate().createEntityManager(map);
        }
        catch (LinkageError le) {
            em = this.delegate.createEntityManager(map);
        }
        if (this.logCriteriaJpql) {
            return (EntityManager)new QueryLogEntityManager(em, this.logCriteriaJpqlLevel);
        }
        return em;
    }
    
    public EntityManager createEntityManager(final SynchronizationType synchronizationType) {
        EntityManager em;
        try {
            em = this.delegate().createEntityManager(synchronizationType);
        }
        catch (LinkageError le) {
            em = this.delegate.createEntityManager(synchronizationType);
        }
        if (this.logCriteriaJpql) {
            return (EntityManager)new QueryLogEntityManager(em, this.logCriteriaJpqlLevel);
        }
        return em;
    }
    
    public EntityManager createEntityManager(final SynchronizationType synchronizationType, final Map map) {
        EntityManager em;
        try {
            em = this.delegate().createEntityManager(synchronizationType, map);
        }
        catch (LinkageError le) {
            em = this.delegate.createEntityManager(synchronizationType, map);
        }
        if (this.logCriteriaJpql) {
            return (EntityManager)new QueryLogEntityManager(em, this.logCriteriaJpqlLevel);
        }
        return em;
    }
    
    public <T> T unwrap(final Class<T> cls) {
        if (cls.isAssignableFrom(this.getClass())) {
            return cls.cast(this);
        }
        return (T)this.delegate().unwrap((Class)cls);
    }
    
    public void addNamedQuery(final String name, final Query query) {
        this.delegate().addNamedQuery(name, query);
    }
    
    public <T> void addNamedEntityGraph(final String graphName, final EntityGraph<T> entityGraph) {
        this.delegate().addNamedEntityGraph(graphName, (EntityGraph)entityGraph);
    }
    
    public CriteriaBuilder getCriteriaBuilder() {
        return this.delegate().getCriteriaBuilder();
    }
    
    public Metamodel getMetamodel() {
        return this.delegate().getMetamodel();
    }
    
    public boolean isOpen() {
        return this.delegate().isOpen();
    }
    
    public synchronized void close() {
        if (this.delegate != null) {
            this.delegate.close();
        }
    }
    
    public Map<String, Object> getProperties() {
        return (Map<String, Object>)this.delegate().getProperties();
    }
    
    public Cache getCache() {
        return this.delegate().getCache();
    }
    
    public PersistenceUnitUtil getPersistenceUnitUtil() {
        return this.delegate().getPersistenceUnitUtil();
    }
    
    public EntityManagerFactory getDelegate() {
        return this.delegate();
    }
    
    public void register() throws OpenEJBException {
        if (!LocalMBeanServer.isJMXActive()) {
            return;
        }
        final MBeanServer server = LocalMBeanServer.get();
        try {
            this.generateObjectName();
            if (server.isRegistered(this.objectName)) {
                server.unregisterMBean(this.objectName);
            }
            server.registerMBean(this.mBeanify(), this.objectName);
        }
        catch (Exception e) {
            throw new OpenEJBException("can't register the mbean for the entity manager factory " + this.getPUname(), e);
        }
        catch (NoClassDefFoundError ncdfe) {
            this.objectName = null;
            ReloadableEntityManagerFactory.LOGGER.error("can't register the mbean for the entity manager factory {0}", this.getPUname());
        }
    }
    
    private ObjectName generateObjectName() {
        final ObjectNameBuilder jmxName = new ObjectNameBuilder("openejb.management");
        jmxName.set("ObjectType", "persistence-unit");
        jmxName.set("PersistenceUnit", this.getPUname());
        this.objectName = jmxName.build();
        final MBeanServer server = LocalMBeanServer.get();
        if (server.isRegistered(this.objectName)) {
            jmxName.set("PersistenceUnit", this.getPUname() + "(" + this.getId() + ")");
            this.objectName = jmxName.build();
        }
        return this.objectName;
    }
    
    private String getPUname() {
        return this.entityManagerFactoryCallable.getUnitInfo().getPersistenceUnitName();
    }
    
    private String getId() {
        return this.entityManagerFactoryCallable.getUnitInfo().getId();
    }
    
    private Object mBeanify() {
        return new DynamicMBeanWrapper(new JMXReloadableEntityManagerFactory(this));
    }
    
    public void unregister() throws OpenEJBException {
        if (this.objectName != null) {
            final MBeanServer server = LocalMBeanServer.get();
            try {
                server.unregisterMBean(this.objectName);
            }
            catch (Exception e) {
                throw new OpenEJBException("can't unregister the mbean for the entity manager factory " + this.getPUname(), e);
            }
        }
    }
    
    public synchronized void reload() {
        try {
            this.createDelegate();
        }
        catch (Exception e) {
            ReloadableEntityManagerFactory.LOGGER.error("can't replace EntityManagerFactory " + this.delegate, e);
        }
    }
    
    public synchronized void setSharedCacheMode(final SharedCacheMode mode) {
        final PersistenceUnitInfoImpl info = this.entityManagerFactoryCallable.getUnitInfo();
        info.setSharedCacheMode(mode);
        final Properties properties = this.entityManagerFactoryCallable.getUnitInfo().getProperties();
        if (properties.containsKey("javax.persistence.sharedCache.mode")) {
            properties.setProperty("javax.persistence.sharedCache.mode", mode.name());
        }
    }
    
    public synchronized void setValidationMode(final ValidationMode mode) {
        final PersistenceUnitInfoImpl info = this.entityManagerFactoryCallable.getUnitInfo();
        info.setValidationMode(mode);
        final Properties properties = this.entityManagerFactoryCallable.getUnitInfo().getProperties();
        if (properties.containsKey("javax.persistence.validation.mode")) {
            properties.setProperty("javax.persistence.validation.mode", mode.name());
        }
    }
    
    public synchronized void setProvider(final String providerRaw) {
        final String provider = providerRaw.trim();
        String newProvider;
        if ("hibernate".equals(provider)) {
            newProvider = "org.hibernate.ejb.HibernatePersistence";
        }
        else if ("openjpa".equals(provider)) {
            newProvider = "org.apache.openjpa.persistence.PersistenceProviderImpl";
        }
        else if ("eclipselink".equals(provider)) {
            newProvider = "org.eclipse.persistence.jpa.PersistenceProvider";
        }
        else if ("toplink".equals(provider)) {
            newProvider = "oracle.toplink.essentials.PersistenceProvider";
        }
        else {
            newProvider = provider;
        }
        try {
            this.classLoader.loadClass(newProvider);
            this.entityManagerFactoryCallable.getUnitInfo().setPersistenceProviderClassName(newProvider);
        }
        catch (ClassNotFoundException e) {
            ReloadableEntityManagerFactory.LOGGER.error("can't load new provider " + newProvider, e);
        }
    }
    
    public synchronized void setTransactionType(final PersistenceUnitTransactionType type) {
        final PersistenceUnitInfoImpl info = this.entityManagerFactoryCallable.getUnitInfo();
        info.setTransactionType(type);
        final Properties properties = this.entityManagerFactoryCallable.getUnitInfo().getProperties();
        if (properties.containsKey("javax.persistence.transactionType")) {
            properties.setProperty("javax.persistence.transactionType", type.name());
        }
    }
    
    public synchronized void setProperty(final String key, final String value) {
        final PersistenceUnitInfoImpl unitInfo = this.entityManagerFactoryCallable.getUnitInfo();
        if (unitInfo.getProperties() == null) {
            unitInfo.setProperties(new Properties());
        }
        unitInfo.getProperties().setProperty(key, value);
    }
    
    public synchronized void removeProperty(final String key) {
        final PersistenceUnitInfoImpl unitInfo = this.entityManagerFactoryCallable.getUnitInfo();
        if (unitInfo.getProperties() != null) {
            unitInfo.getProperties().remove(key);
        }
    }
    
    public Properties getUnitProperties() {
        final PersistenceUnitInfoImpl unitInfo = this.entityManagerFactoryCallable.getUnitInfo();
        if (unitInfo.getProperties() != null) {
            return unitInfo.getProperties();
        }
        return new Properties();
    }
    
    public List<String> getMappingFiles() {
        return this.entityManagerFactoryCallable.getUnitInfo().getMappingFileNames();
    }
    
    public void addMappingFile(final String file) {
        if (new File(file).exists()) {
            this.entityManagerFactoryCallable.getUnitInfo().addMappingFileName(file);
        }
        else {
            ReloadableEntityManagerFactory.LOGGER.error("file " + file + " doesn't exists");
        }
    }
    
    public void removeMappingFile(final String file) {
        this.entityManagerFactoryCallable.getUnitInfo().getMappingFileNames().remove(file);
    }
    
    public List<URL> getJarFileUrls() {
        return this.entityManagerFactoryCallable.getUnitInfo().getJarFileUrls();
    }
    
    public void addJarFileUrls(final String file) {
        if (new File(file).exists()) {
            try {
                this.entityManagerFactoryCallable.getUnitInfo().getJarFileUrls().add(new URL(file));
            }
            catch (MalformedURLException e) {
                ReloadableEntityManagerFactory.LOGGER.error("url " + file + " is malformed");
            }
        }
        else {
            ReloadableEntityManagerFactory.LOGGER.error("url " + file + " is not correct");
        }
    }
    
    public void removeJarFileUrls(final String file) {
        try {
            this.entityManagerFactoryCallable.getUnitInfo().getJarFileUrls().remove(new URL(file));
        }
        catch (MalformedURLException e) {
            ReloadableEntityManagerFactory.LOGGER.error("url " + file + " is malformed");
        }
    }
    
    public List<String> getManagedClasses() {
        return this.entityManagerFactoryCallable.getUnitInfo().getManagedClassNames();
    }
    
    public void addManagedClasses(final String clazz) {
        this.entityManagerFactoryCallable.getUnitInfo().getManagedClassNames().add(clazz);
    }
    
    public void removeManagedClasses(final String clazz) {
        this.entityManagerFactoryCallable.getUnitInfo().getManagedClassNames().remove(clazz);
    }
    
    public PersistenceUnitInfo info() {
        return (PersistenceUnitInfo)this.entityManagerFactoryCallable.getUnitInfo();
    }
    
    public void setExcludeUnlistedClasses(final boolean excludeUnlistedClasses) {
        this.entityManagerFactoryCallable.getUnitInfo().setExcludeUnlistedClasses(excludeUnlistedClasses);
    }
    
    public boolean getExcludeUnlistedClasses() {
        return this.entityManagerFactoryCallable.getUnitInfo().excludeUnlistedClasses();
    }
    
    Object writeReplace() throws ObjectStreamException {
        return new SerializableEm("java:openejb/PersistenceUnit/" + this.unitInfoImpl.getId());
    }
    
    static {
        LOGGER = Logger.getInstance(LogCategory.OPENEJB, ReloadableEntityManagerFactory.class);
    }
    
    @MBean
    @Internal
    @Description("represents a persistence unit managed by OpenEJB")
    public static class JMXReloadableEntityManagerFactory
    {
        private final ReloadableEntityManagerFactory reloadableEntityManagerFactory;
        
        public JMXReloadableEntityManagerFactory(final ReloadableEntityManagerFactory remf) {
            this.reloadableEntityManagerFactory = remf;
        }
        
        @ManagedOperation
        @Description("recreate the entity manager factory using new properties")
        public void reload() {
            this.reloadableEntityManagerFactory.reload();
        }
        
        @ManagedOperation
        @Description("change the current JPA provider")
        public void setProvider(final String provider) {
            this.reloadableEntityManagerFactory.setProvider(provider);
        }
        
        @ManagedOperation
        @Description("change the current transaction type")
        public void setTransactionType(final String type) {
            try {
                final PersistenceUnitTransactionType tt = PersistenceUnitTransactionType.valueOf(type.toUpperCase());
                this.reloadableEntityManagerFactory.setTransactionType(tt);
            }
            catch (Exception ex) {}
        }
        
        @ManagedOperation
        @Description("create or modify a property of the persistence unit")
        public void setProperty(final String key, final String value) {
            this.reloadableEntityManagerFactory.setProperty(key, value);
        }
        
        @ManagedOperation
        @Description("remove a property of the persistence unit if it exists")
        public void removeProperty(final String key) {
            this.reloadableEntityManagerFactory.removeProperty(key);
        }
        
        @ManagedOperation
        @Description("add a mapping file")
        public void addMappingFile(final String file) {
            this.reloadableEntityManagerFactory.addMappingFile(file);
        }
        
        @ManagedOperation
        @Description("remove a mapping file")
        public void removeMappingFile(final String file) {
            this.reloadableEntityManagerFactory.removeMappingFile(file);
        }
        
        @ManagedOperation
        @Description("add a managed class")
        public void addManagedClass(final String clazz) {
            this.reloadableEntityManagerFactory.addManagedClasses(clazz);
        }
        
        @ManagedOperation
        @Description("remove a managed class")
        public void removeManagedClass(final String clazz) {
            this.reloadableEntityManagerFactory.removeManagedClasses(clazz);
        }
        
        @ManagedOperation
        @Description("add a jar file")
        public void addJarFile(final String file) {
            this.reloadableEntityManagerFactory.addJarFileUrls(file);
        }
        
        @ManagedOperation
        @Description("remove a jar file")
        public void removeJarFile(final String file) {
            this.reloadableEntityManagerFactory.removeJarFileUrls(file);
        }
        
        @ManagedOperation
        @Description("change the shared cache mode if possible (value is ok)")
        public void setSharedCacheMode(final String value) {
            try {
                final String v = value.trim().toUpperCase();
                final SharedCacheMode mode = v.isEmpty() ? SharedCacheMode.UNSPECIFIED : SharedCacheMode.valueOf(v);
                this.reloadableEntityManagerFactory.setSharedCacheMode(mode);
            }
            catch (Exception ex) {}
        }
        
        @ManagedOperation
        @Description("exclude or not unlisted entities")
        public void setExcludeUnlistedClasses(final boolean value) {
            this.reloadableEntityManagerFactory.setExcludeUnlistedClasses(value);
        }
        
        @ManagedOperation
        @Description("change the validation mode if possible (value is ok)")
        public void setValidationMode(final String value) {
            try {
                final ValidationMode mode = ValidationMode.valueOf(value.trim().toUpperCase());
                this.reloadableEntityManagerFactory.setValidationMode(mode);
            }
            catch (Exception iae) {
                ReloadableEntityManagerFactory.LOGGER.warning("Can't set validation mode " + value, iae);
                this.reloadableEntityManagerFactory.setProperty("javax.persistence.validation.mode", value);
            }
        }
        
        @ManagedOperation
        @Description("dump the current configuration for this persistence unit in a file")
        public void dump(final String file) {
            final PersistenceUnitInfoImpl info = this.reloadableEntityManagerFactory.entityManagerFactoryCallable.getUnitInfo();
            final Persistence.PersistenceUnit pu = new Persistence.PersistenceUnit();
            pu.setJtaDataSource(info.getJtaDataSourceName());
            pu.setNonJtaDataSource(info.getNonJtaDataSourceName());
            pu.getClazz().addAll(info.getManagedClassNames());
            pu.getMappingFile().addAll(info.getMappingFileNames());
            pu.setName(info.getPersistenceUnitName());
            pu.setProvider(info.getPersistenceProviderClassName());
            pu.setTransactionType(info.getTransactionType().name());
            pu.setExcludeUnlistedClasses(Boolean.valueOf(info.excludeUnlistedClasses()));
            pu.setSharedCacheMode(PersistenceUnitCaching.fromValue(info.getSharedCacheMode().name()));
            pu.setValidationMode(PersistenceUnitValidationMode.fromValue(info.getValidationMode().name()));
            for (final URL url : info.getJarFileUrls()) {
                pu.getJarFile().add(url.toString());
            }
            for (final String key : info.getProperties().stringPropertyNames()) {
                final Persistence.PersistenceUnit.Properties.Property prop = new Persistence.PersistenceUnit.Properties.Property();
                prop.setName(key);
                prop.setValue(info.getProperties().getProperty(key));
                if (pu.getProperties() == null) {
                    pu.setProperties(new Persistence.PersistenceUnit.Properties());
                }
                pu.getProperties().getProperty().add(prop);
            }
            final Persistence persistence = new Persistence();
            persistence.setVersion(info.getPersistenceXMLSchemaVersion());
            persistence.getPersistenceUnit().add(pu);
            try (final FileWriter writer = new FileWriter(file)) {
                final JAXBContext jc = JAXBContextFactory.newInstance(new Class[] { Persistence.class });
                final Marshaller marshaller = jc.createMarshaller();
                marshaller.setProperty("jaxb.formatted.output", (Object)Boolean.TRUE);
                marshaller.marshal((Object)persistence, (Writer)writer);
            }
            catch (Exception e) {
                ReloadableEntityManagerFactory.LOGGER.error("can't dump pu " + this.reloadableEntityManagerFactory.getPUname() + " in file " + file, e);
            }
        }
        
        @ManagedAttribute
        @Description("get exclude unlisted classes")
        public boolean getExcludeUnlistedClasses() {
            return this.reloadableEntityManagerFactory.getExcludeUnlistedClasses();
        }
        
        @ManagedAttribute
        @Description("get all properties")
        public TabularData getProperties() {
            return LocalMBeanServer.tabularData("properties", "properties type", "Property of " + this.reloadableEntityManagerFactory.getPUname(), this.reloadableEntityManagerFactory.getUnitProperties());
        }
        
        @ManagedAttribute
        @Description("get all mapping files")
        public TabularData getMappingFiles() {
            return this.buildTabularData("mappingfile", "mapping file type", this.reloadableEntityManagerFactory.getMappingFiles(), Info.FILE);
        }
        
        @ManagedAttribute
        @Description("get all jar files")
        public TabularData getJarFiles() {
            return this.buildTabularData("jarfile", "jar file type", this.reloadableEntityManagerFactory.getJarFileUrls(), Info.URL);
        }
        
        @ManagedAttribute
        @Description("get all managed classes")
        public TabularData getManagedClasses() {
            return this.buildTabularData("managedclass", "managed class type", this.reloadableEntityManagerFactory.getManagedClasses(), Info.CLASS);
        }
        
        private TabularData buildTabularData(final String typeName, final String typeDescription, final List<?> list, final Info info) {
            final String[] names = new String[list.size()];
            final Object[] values = new Object[names.length];
            int i = 0;
            for (final Object o : list) {
                names[i] = o.toString();
                values[i++] = info.info(this.reloadableEntityManagerFactory.classLoader, o);
            }
            return LocalMBeanServer.tabularData(typeName, typeDescription, names, values);
        }
        
        private enum Info
        {
            URL, 
            NONE, 
            FILE, 
            CLASS;
            
            public String info(final ClassLoader cl, final Object o) {
                switch (this) {
                    case URL: {
                        try {
                            if (((URL)o).openConnection().getContentLength() > 0) {
                                return "valid";
                            }
                        }
                        catch (IOException ex) {}
                        return "not valid";
                    }
                    case FILE: {
                        File file;
                        if (o instanceof String) {
                            file = new File((String)o);
                        }
                        else {
                            if (!(o instanceof File)) {
                                return "unknown";
                            }
                            file = (File)o;
                        }
                        return "exist? " + file.exists();
                    }
                    case CLASS: {
                        try {
                            cl.loadClass((String)o);
                            return "loaded";
                        }
                        catch (ClassNotFoundException e) {
                            return "unloadable";
                        }
                        break;
                    }
                }
                return "-";
            }
        }
    }
    
    private static final class SerializableEm implements Serializable
    {
        private final String jndiName;
        
        private SerializableEm(final String jndiName) {
            this.jndiName = jndiName;
        }
        
        Object readResolve() throws ObjectStreamException {
            try {
                return ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext().lookup(this.jndiName);
            }
            catch (NamingException e) {
                throw new InvalidObjectException(e.getMessage());
            }
        }
    }
}
