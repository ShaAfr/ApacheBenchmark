// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Iterator;
import javax.naming.NamingException;
import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ivm.naming.IntraVmJndiReference;
import org.apache.openejb.core.ivm.naming.CrossClassLoaderJndiReference;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.spi.ContainerSystem;
import javax.naming.NameNotFoundException;
import org.apache.openejb.loader.SystemInstance;
import java.net.URI;
import org.apache.openejb.util.Messages;
import org.apache.openejb.core.ivm.naming.Reference;

public class LazyEjbReference extends Reference
{
    private static final Messages messages;
    private final EjbResolver.Reference info;
    private Reference reference;
    private final URI moduleUri;
    private final boolean useCrossClassLoaderRef;
    
    public LazyEjbReference(final EjbResolver.Reference info, final URI moduleUri, final boolean useCrossClassLoaderRef) {
        this.info = info;
        this.moduleUri = moduleUri;
        this.useCrossClassLoaderRef = useCrossClassLoaderRef;
    }
    
    @Override
    public Object getObject() throws NamingException {
        if (this.reference != null) {
            return this.reference.getObject();
        }
        final SystemInstance systemInstance = SystemInstance.get();
        final EjbResolver resolver = (EjbResolver)systemInstance.getComponent((Class)EjbResolver.class);
        final String deploymentId = resolver.resolve(this.info, this.moduleUri);
        if (deploymentId == null) {
            String key = "lazyEjbRefNotResolved";
            if (this.info.getHome() != null) {
                key += ".home";
            }
            final String message = LazyEjbReference.messages.format(key, this.info.getName(), this.info.getEjbLink(), this.info.getHome(), this.info.getInterface());
            throw new NameNotFoundException(message);
        }
        final ContainerSystem containerSystem = (ContainerSystem)systemInstance.getComponent((Class)ContainerSystem.class);
        final BeanContext beanContext = containerSystem.getBeanContext(deploymentId);
        if (beanContext == null) {
            final String message2 = LazyEjbReference.messages.format("deploymentNotFound", this.info.getName(), deploymentId);
            throw new NameNotFoundException(message2);
        }
        InterfaceType type = null;
        switch (this.info.getRefType()) {
            case LOCAL: {
                type = InterfaceType.BUSINESS_LOCAL;
                break;
            }
            case REMOTE: {
                type = InterfaceType.BUSINESS_REMOTE;
                break;
            }
        }
        final String jndiName = "openejb/Deployment/" + JndiBuilder.format(deploymentId, this.info.getInterface(), type);
        if (this.useCrossClassLoaderRef && this.isRemote(beanContext)) {
            this.reference = new CrossClassLoaderJndiReference(jndiName);
        }
        else {
            this.reference = new IntraVmJndiReference(jndiName);
        }
        return this.reference.getObject();
    }
    
    private boolean isRemote(final BeanContext beanContext) {
        switch (this.info.getRefType()) {
            case REMOTE: {
                return true;
            }
            case LOCAL: {
                return false;
            }
            case UNKNOWN: {
                for (final Class clazz : beanContext.getInterfaces(InterfaceType.BUSINESS_REMOTE)) {
                    if (clazz.getName().equals(this.info.getInterface())) {
                        return true;
                    }
                }
                break;
            }
        }
        return false;
    }
    
    static {
        messages = new Messages(LazyEjbReference.class);
    }
}
