// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.ws.rs.core.MultivaluedMap;
import java.util.Locale;
import java.util.Date;
import javax.ws.rs.core.Cookie;
import java.util.Map;
import javax.ws.rs.core.MediaType;
import java.util.List;
import javax.ws.rs.core.HttpHeaders;

public class ThreadLocalHttpHeaders extends AbstractRestThreadLocalProxy<HttpHeaders> implements HttpHeaders
{
    protected ThreadLocalHttpHeaders() {
        super(HttpHeaders.class);
    }
    
    public List<MediaType> getAcceptableMediaTypes() {
        return (List<MediaType>)this.get().getAcceptableMediaTypes();
    }
    
    public Map<String, Cookie> getCookies() {
        return (Map<String, Cookie>)this.get().getCookies();
    }
    
    public Date getDate() {
        return this.get().getDate();
    }
    
    public int getLength() {
        return this.get().getLength();
    }
    
    public Locale getLanguage() {
        return this.get().getLanguage();
    }
    
    public MediaType getMediaType() {
        return this.get().getMediaType();
    }
    
    public MultivaluedMap<String, String> getRequestHeaders() {
        return (MultivaluedMap<String, String>)new MultivaluedMapWithCaseInsensitiveKeySet((javax.ws.rs.core.MultivaluedMap<String, Object>)this.get().getRequestHeaders());
    }
    
    public List<Locale> getAcceptableLanguages() {
        return (List<Locale>)this.get().getAcceptableLanguages();
    }
    
    public List<String> getRequestHeader(final String name) {
        return (List<String>)this.get().getRequestHeader(name);
    }
    
    public String getHeaderString(final String name) {
        return this.get().getHeaderString(name);
    }
}
