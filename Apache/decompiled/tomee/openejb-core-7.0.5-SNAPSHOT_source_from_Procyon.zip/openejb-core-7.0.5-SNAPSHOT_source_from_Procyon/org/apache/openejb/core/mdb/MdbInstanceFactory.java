// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.mdb;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.core.InstanceContext;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import org.apache.openejb.core.interceptor.InterceptorData;
import java.util.List;
import java.lang.reflect.Method;
import org.apache.openejb.core.BaseContext;
import org.apache.openejb.core.interceptor.InterceptorStack;
import javax.ejb.MessageDrivenBean;
import org.apache.openejb.core.Operation;
import org.apache.openejb.core.ThreadContext;
import javax.resource.spi.UnavailableException;
import javax.naming.Context;
import javax.ejb.EJBContext;
import javax.naming.NamingException;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.core.timer.TimerServiceWrapper;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.BeanContext;
import org.apache.openejb.util.Logger;

public class MdbInstanceFactory
{
    private static final Logger logger;
    private final BeanContext beanContext;
    private final int instanceLimit;
    private int instanceCount;
    private final MdbContext mdbContext;
    
    public MdbInstanceFactory(final BeanContext beanContext, final SecurityService securityService, final int instanceLimit) throws OpenEJBException {
        this.beanContext = beanContext;
        this.instanceLimit = instanceLimit;
        this.mdbContext = new MdbContext(securityService);
        try {
            final Context context = beanContext.getJndiEnc();
            context.bind("comp/EJBContext", this.mdbContext);
            context.bind("comp/TimerService", new TimerServiceWrapper());
        }
        catch (NamingException e) {
            throw new OpenEJBException("Failed to bind EJBContext/TimerService", e);
        }
        beanContext.set((Class<Object>)EJBContext.class, this.mdbContext);
    }
    
    public int getInstanceLimit() {
        return this.instanceLimit;
    }
    
    public synchronized int getInstanceCount() {
        return this.instanceCount;
    }
    
    public Object createInstance(final boolean ignoreInstanceCount) throws UnavailableException {
        if (!ignoreInstanceCount) {
            synchronized (this) {
                if (this.instanceLimit > 0 && this.instanceCount >= this.instanceLimit) {
                    throw new UnavailableException("Only " + this.instanceLimit + " instances can be created");
                }
                ++this.instanceCount;
            }
        }
        try {
            final Object bean = this.constructBean();
            return bean;
        }
        catch (UnavailableException e) {
            if (!ignoreInstanceCount) {
                synchronized (this) {
                    --this.instanceCount;
                }
            }
            throw e;
        }
    }
    
    public void freeInstance(final Instance instance, final boolean ignoredInstanceCount) {
        if (instance == null) {
            throw new NullPointerException("bean is null");
        }
        if (!ignoredInstanceCount) {
            synchronized (this) {
                --this.instanceCount;
            }
        }
        final ThreadContext callContext = ThreadContext.getThreadContext();
        final Operation originalOperation = (callContext == null) ? null : callContext.getCurrentOperation();
        final BaseContext.State[] originalAllowedStates = (BaseContext.State[])((callContext == null) ? null : callContext.getCurrentAllowedStates());
        try {
            if (callContext != null) {
                callContext.setCurrentOperation(Operation.PRE_DESTROY);
            }
            final Method remove = (instance.bean instanceof MessageDrivenBean) ? MessageDrivenBean.class.getMethod("ejbRemove", (Class<?>[])new Class[0]) : null;
            final List<InterceptorData> callbackInterceptors = this.beanContext.getCallbackInterceptors();
            final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, remove, Operation.PRE_DESTROY, callbackInterceptors, instance.interceptors);
            interceptorStack.invoke(new Object[0]);
            if (instance.creationalContext != null) {
                instance.creationalContext.release();
            }
        }
        catch (Throwable re) {
            MdbInstanceFactory.logger.error("The bean instance " + instance.bean + " threw a system exception:" + re, re);
        }
        finally {
            if (callContext != null) {
                callContext.setCurrentOperation(originalOperation);
                callContext.setCurrentAllowedStates(originalAllowedStates);
            }
        }
    }
    
    public Object recreateInstance(final Object bean) throws UnavailableException {
        if (bean == null) {
            throw new NullPointerException("bean is null");
        }
        final Object newBean = this.constructBean();
        return newBean;
    }
    
    private Object constructBean() throws UnavailableException {
        final BeanContext beanContext = this.beanContext;
        final ThreadContext callContext = new ThreadContext(beanContext, null, Operation.INJECTION);
        final ThreadContext oldContext = ThreadContext.enter(callContext);
        try {
            final InstanceContext context = beanContext.newInstance();
            if (context.getBean() instanceof MessageDrivenBean) {
                callContext.setCurrentOperation(Operation.CREATE);
                final Method create = beanContext.getCreateMethod();
                final InterceptorStack ejbCreate = new InterceptorStack(context.getBean(), create, Operation.CREATE, new ArrayList<InterceptorData>(), new HashMap<String, Object>());
                ejbCreate.invoke(new Object[0]);
            }
            return new Instance(context.getBean(), context.getInterceptors(), context.getCreationalContext());
        }
        catch (Throwable e) {
            if (e instanceof InvocationTargetException) {
                e = ((InvocationTargetException)e).getTargetException();
            }
            final String message = "The bean instance threw a system exception:" + e;
            MdbInstanceFactory.logger.error(message, e);
            throw new UnavailableException(message, e);
        }
        finally {
            ThreadContext.exit(oldContext);
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
}
