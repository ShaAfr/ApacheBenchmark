// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.net.URI;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

public class BeansInfo extends InfoObject
{
    public final List<String> duplicatedInterceptors;
    public final List<String> duplicatedDecorators;
    public final List<String> duplicatedAlternativeClasses;
    public final List<String> duplicatedAlternativeStereotypes;
    public final Set<String> startupClasses;
    public String version;
    public String discoveryMode;
    public final List<ExclusionEntryInfo> excludes;
    public final List<BDAInfo> bdas;
    public final List<BDAInfo> noDescriptorBdas;
    
    public BeansInfo() {
        this.duplicatedInterceptors = new ArrayList<String>();
        this.duplicatedDecorators = new ArrayList<String>();
        this.duplicatedAlternativeClasses = new ArrayList<String>();
        this.duplicatedAlternativeStereotypes = new ArrayList<String>();
        this.startupClasses = new HashSet<String>();
        this.version = "1.1";
        this.excludes = new LinkedList<ExclusionEntryInfo>();
        this.bdas = new LinkedList<BDAInfo>();
        this.noDescriptorBdas = new LinkedList<BDAInfo>();
    }
    
    public static class ExclusionEntryInfo extends InfoObject
    {
        public String name;
        public ExclusionInfo exclusion;
    }
    
    public static class BDAInfo extends InfoObject
    {
        public final Set<String> managedClasses;
        public final List<String> interceptors;
        public final List<String> decorators;
        public final List<String> alternatives;
        public final List<String> stereotypeAlternatives;
        public String discoveryMode;
        public URI uri;
        
        public BDAInfo() {
            this.managedClasses = new HashSet<String>();
            this.interceptors = new LinkedList<String>();
            this.decorators = new LinkedList<String>();
            this.alternatives = new LinkedList<String>();
            this.stereotypeAlternatives = new LinkedList<String>();
        }
    }
}
