// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.Binding;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NameParser;
import java.util.Hashtable;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.Context;

public class ContextWrapper implements Context
{
    protected final Context context;
    
    public ContextWrapper(final Context context) {
        this.context = context;
    }
    
    @Override
    public Object addToEnvironment(final String propName, final Object propVal) throws NamingException {
        return this.context.addToEnvironment(propName, propVal);
    }
    
    @Override
    public void bind(final Name name, final Object obj) throws NamingException {
        this.context.bind(name, obj);
    }
    
    @Override
    public void bind(final String name, final Object obj) throws NamingException {
        this.context.bind(name, obj);
    }
    
    @Override
    public void close() throws NamingException {
        this.context.close();
    }
    
    @Override
    public Name composeName(final Name name, final Name prefix) throws NamingException {
        return this.context.composeName(name, prefix);
    }
    
    @Override
    public String composeName(final String name, final String prefix) throws NamingException {
        return this.context.composeName(name, prefix);
    }
    
    @Override
    public Context createSubcontext(final Name name) throws NamingException {
        return this.context.createSubcontext(name);
    }
    
    @Override
    public Context createSubcontext(final String name) throws NamingException {
        return this.context.createSubcontext(name);
    }
    
    @Override
    public void destroySubcontext(final Name name) throws NamingException {
        this.context.destroySubcontext(name);
    }
    
    @Override
    public void destroySubcontext(final String name) throws NamingException {
        this.context.destroySubcontext(name);
    }
    
    @Override
    public Hashtable<?, ?> getEnvironment() throws NamingException {
        return this.context.getEnvironment();
    }
    
    @Override
    public String getNameInNamespace() throws NamingException {
        return this.context.getNameInNamespace();
    }
    
    @Override
    public NameParser getNameParser(final Name name) throws NamingException {
        return this.context.getNameParser(name);
    }
    
    @Override
    public NameParser getNameParser(final String name) throws NamingException {
        return this.context.getNameParser(name);
    }
    
    @Override
    public NamingEnumeration<NameClassPair> list(final Name name) throws NamingException {
        return this.context.list(name);
    }
    
    @Override
    public NamingEnumeration<NameClassPair> list(final String name) throws NamingException {
        return this.context.list(name);
    }
    
    @Override
    public NamingEnumeration<Binding> listBindings(final Name name) throws NamingException {
        return this.context.listBindings(name);
    }
    
    @Override
    public NamingEnumeration<Binding> listBindings(final String name) throws NamingException {
        return this.context.listBindings(name);
    }
    
    @Override
    public Object lookup(final Name name) throws NamingException {
        return this.context.lookup(name);
    }
    
    @Override
    public Object lookup(final String name) throws NamingException {
        return this.context.lookup(name);
    }
    
    @Override
    public Object lookupLink(final Name name) throws NamingException {
        return this.context.lookupLink(name);
    }
    
    @Override
    public Object lookupLink(final String name) throws NamingException {
        return this.context.lookupLink(name);
    }
    
    @Override
    public void rebind(final Name name, final Object obj) throws NamingException {
        this.context.rebind(name, obj);
    }
    
    @Override
    public void rebind(final String name, final Object obj) throws NamingException {
        this.context.rebind(name, obj);
    }
    
    @Override
    public Object removeFromEnvironment(final String propName) throws NamingException {
        return this.context.removeFromEnvironment(propName);
    }
    
    @Override
    public void rename(final Name oldName, final Name newName) throws NamingException {
        this.context.rename(oldName, newName);
    }
    
    @Override
    public void rename(final String oldName, final String newName) throws NamingException {
        this.context.rename(oldName, newName);
    }
    
    @Override
    public void unbind(final Name name) throws NamingException {
        this.context.unbind(name);
    }
    
    @Override
    public void unbind(final String name) throws NamingException {
        this.context.unbind(name);
    }
}
