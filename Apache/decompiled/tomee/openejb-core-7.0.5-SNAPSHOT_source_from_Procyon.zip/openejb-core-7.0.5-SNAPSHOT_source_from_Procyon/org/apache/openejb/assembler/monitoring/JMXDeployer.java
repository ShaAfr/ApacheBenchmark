// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.monitoring;

import javax.naming.NamingException;
import java.util.Hashtable;
import javax.naming.InitialContext;
import org.apache.openejb.assembler.DeployerEjb;
import org.apache.openejb.core.LocalInitialContextFactory;
import java.util.Properties;
import org.apache.openejb.assembler.Deployer;
import org.apache.openejb.api.jmx.ManagedAttribute;
import java.util.Iterator;
import java.util.Collection;
import org.apache.openejb.assembler.classic.AppInfo;
import org.apache.openejb.api.jmx.ManagedOperation;
import org.apache.openejb.api.jmx.Description;
import org.apache.openejb.api.jmx.MBean;

@MBean
@Description("OpenEJB Deployer")
public class JMXDeployer
{
    @ManagedOperation
    @Description("Deploy the specified application")
    public String deploy(final String location) {
        try {
            deployer().deploy(location);
            return "OK";
        }
        catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }
    
    @ManagedOperation
    @Description("Undeploy the specified application")
    public String undeploy(final String moduleId) {
        try {
            deployer().undeploy(moduleId);
            return "OK";
        }
        catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }
    
    @ManagedAttribute
    @Description("List available applications")
    public String[] getDeployedApplications() {
        try {
            final Collection<AppInfo> apps = deployer().getDeployedApps();
            final String[] appsNames = new String[apps.size()];
            int i = 0;
            for (final AppInfo info : apps) {
                appsNames[i++] = info.path;
            }
            return appsNames;
        }
        catch (Exception e) {
            return new String[] { "ERR:" + e.getMessage() };
        }
    }
    
    @ManagedOperation
    @Description("Reload the specified application")
    public String reload(final String moduleId) {
        try {
            final Collection<AppInfo> apps = deployer().getDeployedApps();
            boolean found = false;
            for (final AppInfo info : apps) {
                if (info.path.equals(moduleId)) {
                    found = true;
                    break;
                }
            }
            if (found) {
                deployer().reload(moduleId);
                return "OK";
            }
            return "NOT FOUND";
        }
        catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }
    
    private static Deployer deployer() throws NamingException {
        final Properties p = new Properties();
        p.setProperty("java.naming.factory.initial", LocalInitialContextFactory.class.getName());
        final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(DeployerEjb.class.getClassLoader());
        try {
            return (Deployer)new InitialContext(p).lookup("openejb/DeployerBusinessRemote");
        }
        finally {
            Thread.currentThread().setContextClassLoader(oldCl);
        }
    }
}
