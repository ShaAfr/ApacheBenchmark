// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

public class ConnectorInfo extends CommonInfoObject
{
    public String path;
    public String description;
    public String displayName;
    public String smallIcon;
    public String largeIcon;
    public String moduleId;
    public final List<String> libs;
    public final Set<String> watchedResources;
    public ResourceInfo resourceAdapter;
    public List<ResourceInfo> outbound;
    public List<MdbContainerInfo> inbound;
    public List<ResourceInfo> adminObject;
    public Set<String> mbeans;
    
    public ConnectorInfo() {
        this.libs = new ArrayList<String>();
        this.watchedResources = new TreeSet<String>();
        this.outbound = new ArrayList<ResourceInfo>();
        this.inbound = new ArrayList<MdbContainerInfo>();
        this.adminObject = new ArrayList<ResourceInfo>();
        this.mbeans = new TreeSet<String>();
    }
}
