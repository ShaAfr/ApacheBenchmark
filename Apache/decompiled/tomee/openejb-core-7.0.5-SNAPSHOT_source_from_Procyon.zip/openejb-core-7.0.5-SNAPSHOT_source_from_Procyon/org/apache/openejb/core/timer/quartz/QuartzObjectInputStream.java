// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer.quartz;

import org.apache.openejb.core.rmi.BlacklistClassResolver;
import java.io.ObjectStreamClass;
import java.io.IOException;
import java.io.InputStream;
import org.apache.openejb.quartz.spi.ClassLoadHelper;
import java.io.ObjectInputStream;

public class QuartzObjectInputStream extends ObjectInputStream
{
    private final ClassLoadHelper loader;
    
    public QuartzObjectInputStream(final InputStream binaryInput, final ClassLoadHelper classLoadHelper) throws IOException {
        super(binaryInput);
        this.loader = classLoadHelper;
    }
    
    @Override
    protected Class<?> resolveClass(final ObjectStreamClass desc) throws ClassNotFoundException, IOException {
        return (Class<?>)this.loader.loadClass(BlacklistClassResolver.DEFAULT.check(desc.getName()));
    }
}
