// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log.commonslogging;

import org.apache.openejb.util.reflection.Reflections;
import org.apache.commons.logging.impl.Jdk14Logger;
import org.apache.openejb.util.classloader.URLClassLoaderFirst;
import java.io.Serializable;
import org.apache.commons.logging.Log;

public class Log4J4AppOpenEJB4ContainerLog implements Log, Serializable
{
    private static final Class<?>[] NO_PARAM;
    private static final Class<?>[] OBJECT_PARAM;
    private static final Class<?>[] OBJECT_THROWABLE_PARAM;
    private static final Object[] NO_ARGS;
    private Object delegate;
    
    public Log4J4AppOpenEJB4ContainerLog(final String category) {
        if (URLClassLoaderFirst.shouldSkip(category)) {
            this.delegate = new OpenEJBCommonsLog(category);
        }
        else {
            final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
            try {
                this.delegate = contextClassLoader.loadClass("org.apache.commons.logging.impl.Log4JLogger").getConstructor(String.class).newInstance(category);
            }
            catch (Exception ex) {
                this.delegate = new Jdk14Logger(category);
            }
        }
    }
    
    public boolean isDebugEnabled() {
        return (boolean)Reflections.invokeByReflection(this.delegate, "isDebugEnabled", Log4J4AppOpenEJB4ContainerLog.NO_PARAM, Log4J4AppOpenEJB4ContainerLog.NO_ARGS);
    }
    
    public boolean isErrorEnabled() {
        return (boolean)Reflections.invokeByReflection(this.delegate, "isErrorEnabled", Log4J4AppOpenEJB4ContainerLog.NO_PARAM, Log4J4AppOpenEJB4ContainerLog.NO_ARGS);
    }
    
    public boolean isFatalEnabled() {
        return (boolean)Reflections.invokeByReflection(this.delegate, "isFatalEnabled", Log4J4AppOpenEJB4ContainerLog.NO_PARAM, Log4J4AppOpenEJB4ContainerLog.NO_ARGS);
    }
    
    public boolean isInfoEnabled() {
        return (boolean)Reflections.invokeByReflection(this.delegate, "isInfoEnabled", Log4J4AppOpenEJB4ContainerLog.NO_PARAM, Log4J4AppOpenEJB4ContainerLog.NO_ARGS);
    }
    
    public boolean isTraceEnabled() {
        return (boolean)Reflections.invokeByReflection(this.delegate, "isTraceEnabled", Log4J4AppOpenEJB4ContainerLog.NO_PARAM, Log4J4AppOpenEJB4ContainerLog.NO_ARGS);
    }
    
    public boolean isWarnEnabled() {
        return (boolean)Reflections.invokeByReflection(this.delegate, "isWarnEnabled", Log4J4AppOpenEJB4ContainerLog.NO_PARAM, Log4J4AppOpenEJB4ContainerLog.NO_ARGS);
    }
    
    public void trace(final Object message) {
        Reflections.invokeByReflection(this.delegate, "trace", Log4J4AppOpenEJB4ContainerLog.OBJECT_PARAM, new Object[] { message });
    }
    
    public void trace(final Object message, final Throwable t) {
        Reflections.invokeByReflection(this.delegate, "trace", Log4J4AppOpenEJB4ContainerLog.OBJECT_THROWABLE_PARAM, new Object[] { message, t });
    }
    
    public void debug(final Object message) {
        Reflections.invokeByReflection(this.delegate, "debug", Log4J4AppOpenEJB4ContainerLog.OBJECT_PARAM, new Object[] { message });
    }
    
    public void debug(final Object message, final Throwable t) {
        Reflections.invokeByReflection(this.delegate, "debug", Log4J4AppOpenEJB4ContainerLog.OBJECT_THROWABLE_PARAM, new Object[] { message, t });
    }
    
    public void info(final Object message) {
        Reflections.invokeByReflection(this.delegate, "info", Log4J4AppOpenEJB4ContainerLog.OBJECT_PARAM, new Object[] { message });
    }
    
    public void info(final Object message, final Throwable t) {
        Reflections.invokeByReflection(this.delegate, "info", Log4J4AppOpenEJB4ContainerLog.OBJECT_THROWABLE_PARAM, new Object[] { message, t });
    }
    
    public void warn(final Object message) {
        Reflections.invokeByReflection(this.delegate, "warn", Log4J4AppOpenEJB4ContainerLog.OBJECT_PARAM, new Object[] { message });
    }
    
    public void warn(final Object message, final Throwable t) {
        Reflections.invokeByReflection(this.delegate, "warn", Log4J4AppOpenEJB4ContainerLog.OBJECT_THROWABLE_PARAM, new Object[] { message, t });
    }
    
    public void error(final Object message) {
        Reflections.invokeByReflection(this.delegate, "error", Log4J4AppOpenEJB4ContainerLog.OBJECT_PARAM, new Object[] { message });
    }
    
    public void error(final Object message, final Throwable t) {
        Reflections.invokeByReflection(this.delegate, "error", Log4J4AppOpenEJB4ContainerLog.OBJECT_THROWABLE_PARAM, new Object[] { message, t });
    }
    
    public void fatal(final Object message) {
        Reflections.invokeByReflection(this.delegate, "fatal", Log4J4AppOpenEJB4ContainerLog.OBJECT_PARAM, new Object[] { message });
    }
    
    public void fatal(final Object message, final Throwable t) {
        Reflections.invokeByReflection(this.delegate, "fatal", Log4J4AppOpenEJB4ContainerLog.OBJECT_THROWABLE_PARAM, new Object[] { message, t });
    }
    
    static {
        NO_PARAM = new Class[0];
        OBJECT_PARAM = new Class[] { Object.class };
        OBJECT_THROWABLE_PARAM = new Class[] { Object.class, Throwable.class };
        NO_ARGS = new Object[0];
    }
}
