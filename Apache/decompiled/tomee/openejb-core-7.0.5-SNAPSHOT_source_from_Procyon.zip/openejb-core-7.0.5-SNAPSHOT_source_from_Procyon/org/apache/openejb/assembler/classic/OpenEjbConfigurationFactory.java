// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.OpenEJBException;
import java.util.Properties;

public interface OpenEjbConfigurationFactory
{
    void init(final Properties p0) throws OpenEJBException;
    
    OpenEjbConfiguration getOpenEjbConfiguration() throws OpenEJBException;
}
