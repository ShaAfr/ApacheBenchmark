// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import java.lang.reflect.Field;
import org.apache.openejb.InterfaceType;
import javax.ejb.EJBObject;
import org.apache.openejb.core.cmp.CmpContainer;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.core.ivm.EjbObjectProxyHandler;
import javax.ejb.EJBLocalObject;
import org.apache.openejb.core.cmp.KeyGenerator;
import javax.ejb.EntityBean;
import org.apache.openejb.BeanContext;

public class Cmp2Util
{
    public static Object getPrimaryKey(final BeanContext beanContext, final EntityBean entity) {
        if (entity == null) {
            return null;
        }
        final KeyGenerator kg = beanContext.getKeyGenerator();
        final Object primaryKey = kg.getPrimaryKey(entity);
        return primaryKey;
    }
    
    public static <Bean extends EntityBean> Bean getEntityBean(final EJBLocalObject proxy) {
        if (proxy == null) {
            return null;
        }
        final EjbObjectProxyHandler handler = (EjbObjectProxyHandler)ProxyManager.getInvocationHandler(proxy);
        if (handler.container == null) {
            return null;
        }
        if (!(handler.container instanceof CmpContainer)) {
            throw new IllegalArgumentException("Proxy is not connected to a CMP container but is conect to " + handler.container.getClass().getName());
        }
        final CmpContainer container = (CmpContainer)handler.container;
        final Bean entity = (Bean)container.getEjbInstance(handler.getBeanContext(), handler.primaryKey);
        return entity;
    }
    
    public static <Bean extends EntityBean> Bean getEntityBean(final EJBObject proxy) {
        if (proxy == null) {
            return null;
        }
        final EjbObjectProxyHandler handler = (EjbObjectProxyHandler)ProxyManager.getInvocationHandler(proxy);
        if (handler.container == null) {
            return null;
        }
        if (!(handler.container instanceof CmpContainer)) {
            throw new IllegalArgumentException("Proxy is not connected to a CMP container but is conect to " + handler.container.getClass().getName());
        }
        final CmpContainer container = (CmpContainer)handler.container;
        final Bean entity = (Bean)container.getEjbInstance(handler.getBeanContext(), handler.primaryKey);
        return entity;
    }
    
    public static <Proxy extends EJBLocalObject> Proxy getEjbProxy(final BeanContext beanContext, final EntityBean entity) {
        if (entity == null) {
            return null;
        }
        final Object primaryKey = getPrimaryKey(beanContext, entity);
        if (!(beanContext.getContainer() instanceof CmpContainer)) {
            throw new IllegalArgumentException("Proxy is not connected to a CMP container but is conect to " + beanContext.getContainer().getClass().getName());
        }
        final Proxy proxy = (Proxy)EjbObjectProxyHandler.createProxy(beanContext, primaryKey, InterfaceType.EJB_LOCAL_HOME, beanContext.getLocalInterface());
        return proxy;
    }
    
    public static BeanContext getBeanContext(final Class type) {
        BeanContext beanContext;
        try {
            final Field deploymentInfoField = type.getField("deploymentInfo");
            beanContext = (BeanContext)deploymentInfoField.get(null);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("EntityBean class " + type.getName() + " does not contain a deploymentInfo field.  Is this a generated CMP 2 entity implementation?", e);
        }
        return beanContext;
    }
}
