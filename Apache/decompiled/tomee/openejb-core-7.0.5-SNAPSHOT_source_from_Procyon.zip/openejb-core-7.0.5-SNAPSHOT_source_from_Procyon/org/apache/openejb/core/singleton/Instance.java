// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.singleton;

import javax.enterprise.context.spi.CreationalContext;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.Map;

public class Instance
{
    public final Object bean;
    public final Map<String, Object> interceptors;
    public final ReadWriteLock lock;
    public final CreationalContext creationalContext;
    
    public Instance(final Object bean, final Map<String, Object> interceptors, final CreationalContext creationalContext, final ReadWriteLock lock) {
        this.bean = bean;
        this.interceptors = interceptors;
        this.lock = lock;
        this.creationalContext = creationalContext;
    }
}
