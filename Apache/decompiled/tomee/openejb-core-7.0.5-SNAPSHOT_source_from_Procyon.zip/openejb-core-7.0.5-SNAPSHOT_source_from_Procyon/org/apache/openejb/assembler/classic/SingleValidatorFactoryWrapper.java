// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.LogCategory;
import javax.validation.ParameterNameProvider;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.TraversableResolver;
import javax.validation.MessageInterpolator;
import javax.validation.ValidatorContext;
import javax.naming.NamingException;
import org.apache.openejb.bval.ValidatorUtil;
import javax.validation.Validator;
import org.apache.openejb.util.Logger;
import java.io.Serializable;
import javax.validation.ValidatorFactory;

public class SingleValidatorFactoryWrapper implements ValidatorFactory, Serializable
{
    public static final Logger logger;
    private transient volatile ValidatorFactory factory;
    
    public SingleValidatorFactoryWrapper(final ValidatorFactory factory) {
        this.factory = factory;
    }
    
    public Validator getValidator() {
        return this.factory().getValidator();
    }
    
    private ValidatorFactory factory() {
        if (this.factory == null) {
            synchronized (this) {
                if (this.factory == null) {
                    try {
                        this.factory = ValidatorUtil.lookupFactory();
                    }
                    catch (NamingException e) {
                        throw new IllegalStateException(e);
                    }
                }
            }
        }
        return this.factory;
    }
    
    public ValidatorContext usingContext() {
        return this.factory().usingContext();
    }
    
    public MessageInterpolator getMessageInterpolator() {
        return this.factory().getMessageInterpolator();
    }
    
    public TraversableResolver getTraversableResolver() {
        return this.factory().getTraversableResolver();
    }
    
    public ConstraintValidatorFactory getConstraintValidatorFactory() {
        return this.factory().getConstraintValidatorFactory();
    }
    
    public <T> T unwrap(final Class<T> tClass) {
        return (T)this.factory().unwrap((Class)tClass);
    }
    
    public ParameterNameProvider getParameterNameProvider() {
        return this.factory().getParameterNameProvider();
    }
    
    public void close() {
        final ValidatorFactory factory = this.factory;
        if (factory != null) {
            factory.close();
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, SingleValidatorFactoryWrapper.class);
    }
}
