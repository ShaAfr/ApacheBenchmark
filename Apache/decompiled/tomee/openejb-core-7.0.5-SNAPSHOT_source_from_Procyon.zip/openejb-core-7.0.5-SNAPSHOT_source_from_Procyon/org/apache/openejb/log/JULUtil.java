// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log;

import org.apache.openejb.loader.SystemInstance;
import java.util.logging.Level;

public final class JULUtil
{
    public static final String DEFAULT_LOG_LEVEL = "INFO";
    public static final String OPENEJB_LOG_LEVEL = "openejb.log.level";
    
    private JULUtil() {
    }
    
    public static Level level() {
        final String propLevel = SystemInstance.get().getProperty("openejb.log.level", "INFO").toUpperCase();
        try {
            return (Level)Level.class.getDeclaredField(propLevel).get(null);
        }
        catch (IllegalAccessException e) {
            return Level.INFO;
        }
        catch (NoSuchFieldException e2) {
            return Level.INFO;
        }
    }
}
