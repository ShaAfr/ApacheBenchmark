// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import org.apache.openejb.util.LogCategory;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.NotSupportedException;
import org.apache.openejb.OpenEJB;
import javax.transaction.TransactionManager;
import org.apache.openejb.util.Logger;
import java.io.Serializable;
import javax.transaction.UserTransaction;

public class CoreUserTransaction implements UserTransaction, Serializable
{
    private static final long serialVersionUID = 9203248912222645965L;
    private static final transient Logger transactionLogger;
    private static final ThreadLocal<RuntimeException> ERROR;
    private transient TransactionManager transactionManager;
    
    public CoreUserTransaction(final TransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }
    
    public static RuntimeException error(final RuntimeException e) {
        final RuntimeException p = CoreUserTransaction.ERROR.get();
        CoreUserTransaction.ERROR.set(e);
        return p;
    }
    
    public static void resetError(final RuntimeException old) {
        CoreUserTransaction.ERROR.set(old);
    }
    
    public static RuntimeException error() {
        return CoreUserTransaction.ERROR.get();
    }
    
    private TransactionManager transactionManager() {
        if (this.transactionManager == null) {
            this.transactionManager = OpenEJB.getTransactionManager();
        }
        return this.transactionManager;
    }
    
    public void begin() throws NotSupportedException, SystemException {
        this.check();
        this.transactionManager().begin();
        if (CoreUserTransaction.transactionLogger.isDebugEnabled()) {
            CoreUserTransaction.transactionLogger.debug("Started user transaction " + this.transactionManager().getTransaction());
        }
    }
    
    private void check() {
        final RuntimeException e = CoreUserTransaction.ERROR.get();
        if (e != null) {
            throw e;
        }
    }
    
    public void commit() throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, IllegalStateException, SystemException {
        this.check();
        if (CoreUserTransaction.transactionLogger.isDebugEnabled()) {
            CoreUserTransaction.transactionLogger.debug("Committing user transaction " + this.transactionManager().getTransaction());
        }
        this.transactionManager().commit();
    }
    
    public int getStatus() throws SystemException {
        this.check();
        final int status = this.transactionManager().getStatus();
        if (CoreUserTransaction.transactionLogger.isDebugEnabled()) {
            CoreUserTransaction.transactionLogger.debug("User transaction " + this.transactionManager().getTransaction() + " has status " + getStatus(status));
        }
        return status;
    }
    
    public void rollback() throws IllegalStateException, SecurityException, SystemException {
        this.check();
        if (CoreUserTransaction.transactionLogger.isDebugEnabled()) {
            CoreUserTransaction.transactionLogger.debug("Rolling back user transaction " + this.transactionManager().getTransaction());
        }
        this.transactionManager().rollback();
    }
    
    public void setRollbackOnly() throws SystemException {
        this.check();
        if (CoreUserTransaction.transactionLogger.isDebugEnabled()) {
            CoreUserTransaction.transactionLogger.debug("Marking user transaction for rollback: " + this.transactionManager().getTransaction());
        }
        this.transactionManager().setRollbackOnly();
    }
    
    public void setTransactionTimeout(final int seconds) throws SystemException {
        this.check();
        this.transactionManager().setTransactionTimeout(seconds);
    }
    
    private static String getStatus(final int status) {
        final StringBuilder buffer = new StringBuilder(100);
        switch (status) {
            case 0: {
                buffer.append("STATUS_ACTIVE: ");
                buffer.append("A transaction is associated with the target object and it is in the active state.");
                break;
            }
            case 3: {
                buffer.append("STATUS_COMMITTED: ");
                buffer.append("A transaction is associated with the target object and it has been committed.");
                break;
            }
            case 8: {
                buffer.append("STATUS_COMMITTING: ");
                buffer.append("A transaction is associated with the target object and it is in the process of committing.");
                break;
            }
            case 1: {
                buffer.append("STATUS_MARKED_ROLLBACK: ");
                buffer.append("A transaction is associated with the target object and it has been marked for rollback, perhaps as a result of a setRollbackOnly operation.");
                break;
            }
            case 6: {
                buffer.append("STATUS_NO_TRANSACTION: ");
                buffer.append("No transaction is currently associated with the target object.");
                break;
            }
            case 2: {
                buffer.append("STATUS_PREPARED: ");
                buffer.append("A transaction is associated with the target object and it has been prepared, i.e.");
                break;
            }
            case 7: {
                buffer.append("STATUS_PREPARING: ");
                buffer.append("A transaction is associated with the target object and it is in the process of preparing.");
                break;
            }
            case 4: {
                buffer.append("STATUS_ROLLEDBACK: ");
                buffer.append("A transaction is associated with the target object and the outcome has been determined as rollback.");
                break;
            }
            case 9: {
                buffer.append("STATUS_ROLLING_BACK: ");
                buffer.append("A transaction is associated with the target object and it is in the process of rolling back.");
                break;
            }
            default: {
                buffer.append("Unknown status ").append(status);
                break;
            }
        }
        return buffer.toString();
    }
    
    static {
        transactionLogger = Logger.getInstance(LogCategory.TRANSACTION, "org.apache.openejb.util.resources");
        ERROR = new ThreadLocal<RuntimeException>();
    }
}
