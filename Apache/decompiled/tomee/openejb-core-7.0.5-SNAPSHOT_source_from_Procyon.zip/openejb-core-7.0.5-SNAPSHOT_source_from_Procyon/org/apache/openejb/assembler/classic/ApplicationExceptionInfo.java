// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class ApplicationExceptionInfo extends InfoObject
{
    public String exceptionClass;
    public boolean rollback;
    public boolean inherited;
}
