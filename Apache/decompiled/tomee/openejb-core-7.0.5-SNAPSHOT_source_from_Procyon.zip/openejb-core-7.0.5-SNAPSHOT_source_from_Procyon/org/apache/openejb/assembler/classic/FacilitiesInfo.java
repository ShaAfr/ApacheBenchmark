// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class FacilitiesInfo extends InfoObject
{
    public ProxyFactoryInfo intraVmServer;
    public final List<JndiContextInfo> remoteJndiContexts;
    public final List<ResourceInfo> resources;
    public final List<ConnectionManagerInfo> connectionManagers;
    public TransactionServiceInfo transactionService;
    public SecurityServiceInfo securityService;
    public final List<ServiceInfo> services;
    public final List<String> serverObservers;
    
    public FacilitiesInfo() {
        this.remoteJndiContexts = new ArrayList<JndiContextInfo>();
        this.resources = new ArrayList<ResourceInfo>();
        this.connectionManagers = new ArrayList<ConnectionManagerInfo>();
        this.services = new ArrayList<ServiceInfo>();
        this.serverObservers = new ArrayList<String>();
    }
}
