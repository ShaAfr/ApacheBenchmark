// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateless;

import org.apache.openejb.core.ivm.EjbObjectProxyHandler;
import javax.ejb.RemoveException;
import java.lang.reflect.Method;
import java.util.List;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ivm.EjbHomeProxyHandler;

public class StatelessEjbHomeHandler extends EjbHomeProxyHandler
{
    public StatelessEjbHomeHandler(final BeanContext beanContext, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        super(beanContext, interfaceType, interfaces, mainInterface);
    }
    
    @Override
    protected Object findX(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        throw new UnsupportedOperationException("Stateful beans may not have find methods");
    }
    
    @Override
    protected Object removeByPrimaryKey(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        throw new RemoveException("Session objects are private resources and do not have primary keys");
    }
    
    @Override
    protected Object removeWithHandle(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        return null;
    }
    
    @Override
    protected EjbObjectProxyHandler newEjbObjectHandler(final BeanContext beanContext, final Object pk, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        return new StatelessEjbObjectHandler(this.getBeanContext(), pk, interfaceType, interfaces, mainInterface);
    }
}
