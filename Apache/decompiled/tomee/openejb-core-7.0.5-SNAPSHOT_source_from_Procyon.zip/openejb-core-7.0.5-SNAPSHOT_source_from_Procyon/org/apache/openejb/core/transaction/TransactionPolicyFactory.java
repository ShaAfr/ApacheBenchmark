// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.ApplicationException;
import org.apache.openejb.SystemException;

public interface TransactionPolicyFactory
{
    TransactionPolicy createTransactionPolicy(final TransactionType p0) throws SystemException, ApplicationException;
}
