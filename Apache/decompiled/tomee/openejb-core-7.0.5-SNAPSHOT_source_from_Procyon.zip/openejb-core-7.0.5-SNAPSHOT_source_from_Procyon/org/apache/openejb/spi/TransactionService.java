// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.spi;

import javax.transaction.TransactionManager;

public interface TransactionService extends Service
{
    TransactionManager getTransactionManager();
}
