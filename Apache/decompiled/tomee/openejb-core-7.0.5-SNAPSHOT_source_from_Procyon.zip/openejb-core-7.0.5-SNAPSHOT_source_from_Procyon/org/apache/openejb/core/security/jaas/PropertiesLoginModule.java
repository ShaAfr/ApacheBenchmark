// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jaas;

import org.apache.openejb.util.LogCategory;
import java.util.Enumeration;
import java.security.Principal;
import java.util.Collection;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.Callback;
import java.io.IOException;
import javax.security.auth.login.LoginException;
import org.apache.openejb.loader.IO;
import org.apache.openejb.util.ConfUtils;
import java.util.Map;
import java.util.LinkedHashSet;
import java.net.URL;
import java.util.Set;
import java.util.Properties;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.Subject;
import org.apache.openejb.util.Logger;
import javax.security.auth.spi.LoginModule;

public class PropertiesLoginModule implements LoginModule
{
    private static final String USER_FILE = "UsersFile";
    private static final String GROUP_FILE = "GroupsFile";
    private static final Logger log;
    private Subject subject;
    private CallbackHandler callbackHandler;
    private boolean debug;
    private Properties users;
    private Properties groups;
    private String user;
    private final Set principals;
    private URL usersUrl;
    private URL groupsUrl;
    
    public PropertiesLoginModule() {
        this.users = new Properties();
        this.groups = new Properties();
        this.principals = new LinkedHashSet();
    }
    
    @Override
    public void initialize(final Subject subject, final CallbackHandler callbackHandler, final Map sharedState, final Map options) {
        this.subject = subject;
        this.callbackHandler = callbackHandler;
        this.debug = (PropertiesLoginModule.log.isDebugEnabled() || "true".equalsIgnoreCase(options.get("Debug")));
        final String usersFile = String.valueOf(options.get("UsersFile"));
        final String groupsFile = String.valueOf(options.get("GroupsFile"));
        this.usersUrl = ConfUtils.getConfResource(usersFile);
        this.groupsUrl = ConfUtils.getConfResource(groupsFile);
        if (this.debug) {
            PropertiesLoginModule.log.debug("Users file: " + this.usersUrl.toExternalForm());
            PropertiesLoginModule.log.debug("Groups file: " + this.groupsUrl.toExternalForm());
        }
    }
    
    @Override
    public boolean login() throws LoginException {
        try {
            this.users = IO.readProperties(this.usersUrl);
        }
        catch (IOException ioe2) {
            throw new LoginException("Unable to load user properties file " + this.usersUrl.getFile());
        }
        try {
            this.groups = IO.readProperties(this.groupsUrl);
        }
        catch (IOException ioe2) {
            throw new LoginException("Unable to load group properties file " + this.groupsUrl.getFile());
        }
        final Callback[] callbacks = { new NameCallback("Username: "), new PasswordCallback("Password: ", false) };
        try {
            this.callbackHandler.handle(callbacks);
        }
        catch (IOException ioe) {
            throw new LoginException(ioe.getMessage());
        }
        catch (UnsupportedCallbackException uce) {
            throw new LoginException(uce.getMessage() + " not available to obtain information from user");
        }
        this.user = ((NameCallback)callbacks[0]).getName();
        char[] tmpPassword = ((PasswordCallback)callbacks[1]).getPassword();
        if (tmpPassword == null) {
            tmpPassword = new char[0];
        }
        final String password = this.users.getProperty(this.user);
        if (password == null) {
            throw new FailedLoginException("User does not exist");
        }
        if (!password.equals(new String(tmpPassword))) {
            throw new FailedLoginException("Password does not match");
        }
        this.users.clear();
        if (this.debug) {
            PropertiesLoginModule.log.debug("Logged in as '" + this.user + "'");
        }
        return true;
    }
    
    @Override
    public boolean commit() throws LoginException {
        this.principals.add(new UserPrincipal(this.user));
        final Enumeration enumeration = this.groups.keys();
        while (enumeration.hasMoreElements()) {
            final String name = enumeration.nextElement();
            final String[] userList = String.valueOf(this.groups.getProperty(name)).split(",");
            for (int i = 0; i < userList.length; ++i) {
                if (this.user.equals(userList[i])) {
                    this.principals.add(new GroupPrincipal(name));
                    break;
                }
            }
        }
        this.subject.getPrincipals().addAll(this.principals);
        this.clear();
        if (this.debug) {
            PropertiesLoginModule.log.debug("commit");
        }
        return true;
    }
    
    @Override
    public boolean abort() throws LoginException {
        this.clear();
        if (this.debug) {
            PropertiesLoginModule.log.debug("abort");
        }
        return true;
    }
    
    @Override
    public boolean logout() throws LoginException {
        this.subject.getPrincipals().removeAll(this.principals);
        this.principals.clear();
        if (this.debug) {
            PropertiesLoginModule.log.debug("logout");
        }
        return true;
    }
    
    private void clear() {
        this.groups.clear();
        this.user = null;
    }
    
    static {
        log = Logger.getInstance(LogCategory.OPENEJB_SECURITY, "org.apache.openejb.util.resources");
    }
}
