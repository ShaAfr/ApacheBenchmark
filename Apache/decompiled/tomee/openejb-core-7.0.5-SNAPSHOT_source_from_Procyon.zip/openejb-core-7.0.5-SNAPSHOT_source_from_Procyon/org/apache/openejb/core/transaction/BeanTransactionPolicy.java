// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.SystemException;
import javax.transaction.UserTransaction;

public interface BeanTransactionPolicy extends TransactionPolicy
{
    UserTransaction getUserTransaction();
    
    SuspendedTransaction suspendUserTransaction() throws SystemException;
    
    void resumeUserTransaction(final SuspendedTransaction p0) throws SystemException;
    
    public interface SuspendedTransaction
    {
        void destroy();
    }
}
