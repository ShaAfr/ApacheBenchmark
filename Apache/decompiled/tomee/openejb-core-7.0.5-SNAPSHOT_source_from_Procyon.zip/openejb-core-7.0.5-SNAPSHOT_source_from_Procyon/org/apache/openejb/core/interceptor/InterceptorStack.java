// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.interceptor;

import javax.xml.ws.handler.MessageContext;
import org.apache.openejb.core.ThreadContext;
import javax.interceptor.InvocationContext;
import java.util.Set;
import java.util.Iterator;
import org.apache.openejb.util.proxy.DynamicProxyImplFactory;
import java.util.ArrayList;
import java.util.Map;
import org.apache.openejb.core.Operation;
import java.lang.reflect.Method;
import java.util.List;

public class InterceptorStack
{
    private final Object beanInstance;
    private final List<Interceptor> interceptors;
    private final Method targetMethod;
    private final Operation operation;
    
    public InterceptorStack(final Object beanInstance, final Method targetMethod, final Operation operation, final List<InterceptorData> interceptorDatas, final Map<String, Object> interceptorInstances) {
        if (interceptorDatas == null) {
            throw new NullPointerException("interceptorDatas is null");
        }
        if (interceptorInstances == null) {
            throw new NullPointerException("interceptorInstances is null");
        }
        this.beanInstance = beanInstance;
        this.targetMethod = targetMethod;
        this.operation = operation;
        this.interceptors = new ArrayList<Interceptor>(interceptorDatas.size());
        for (final InterceptorData interceptorData : interceptorDatas) {
            final Class interceptorClass = interceptorData.getInterceptorClass();
            final Object interceptorInstance = interceptorInstances.get(interceptorClass.getName());
            if (interceptorInstance == null) {
                throw new IllegalArgumentException("No interceptor of type " + interceptorClass.getName());
            }
            final Set<Method> methods = interceptorData.getMethods(operation);
            for (final Method method : methods) {
                final Object handler = DynamicProxyImplFactory.realHandler(interceptorInstance);
                Interceptor interceptor;
                if (handler != null && method.getDeclaringClass().equals(handler.getClass())) {
                    interceptor = new Interceptor(handler, method);
                }
                else {
                    interceptor = new Interceptor(interceptorInstance, method);
                }
                this.interceptors.add(interceptor);
            }
        }
    }
    
    public InvocationContext createInvocationContext(final Object... parameters) {
        return (InvocationContext)new ReflectionInvocationContext(this.operation, this.interceptors, this.beanInstance, this.targetMethod, parameters);
    }
    
    public Object invoke(final Object... parameters) throws Exception {
        try {
            final InvocationContext invocationContext = this.createInvocationContext(parameters);
            if (ThreadContext.getThreadContext() != null) {
                ThreadContext.getThreadContext().set(InvocationContext.class, invocationContext);
            }
            return invocationContext.proceed();
        }
        finally {
            if (ThreadContext.getThreadContext() != null) {
                ThreadContext.getThreadContext().remove(InvocationContext.class);
            }
        }
    }
    
    public Object invoke(final MessageContext messageContext, final Object... parameters) throws Exception {
        try {
            final InvocationContext invocationContext = (InvocationContext)new JaxWsInvocationContext(this.operation, this.interceptors, this.beanInstance, this.targetMethod, messageContext, parameters);
            ThreadContext.getThreadContext().set(InvocationContext.class, invocationContext);
            return invocationContext.proceed();
        }
        finally {
            ThreadContext.getThreadContext().remove(InvocationContext.class);
        }
    }
    
    public Object invoke(final javax.xml.rpc.handler.MessageContext messageContext, final Object... parameters) throws Exception {
        try {
            final InvocationContext invocationContext = (InvocationContext)new JaxRpcInvocationContext(this.operation, this.interceptors, this.beanInstance, this.targetMethod, messageContext, parameters);
            ThreadContext.getThreadContext().set(InvocationContext.class, invocationContext);
            return invocationContext.proceed();
        }
        finally {
            ThreadContext.getThreadContext().remove(InvocationContext.class);
        }
    }
}
