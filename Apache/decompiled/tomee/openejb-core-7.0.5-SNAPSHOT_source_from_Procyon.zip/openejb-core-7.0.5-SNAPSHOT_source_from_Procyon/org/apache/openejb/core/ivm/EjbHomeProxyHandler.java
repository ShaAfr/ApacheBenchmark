// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import org.apache.openejb.util.LogCategory;
import java.io.ObjectStreamException;
import org.apache.openejb.spi.ApplicationServer;
import org.apache.openejb.core.ServerFederation;
import javax.ejb.EJBHome;
import org.apache.openejb.ProxyInfo;
import org.apache.openejb.threads.task.CUCallable;
import java.util.concurrent.Callable;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.SystemException;
import org.apache.openejb.ApplicationException;
import java.rmi.AccessException;
import javax.ejb.AccessLocalException;
import javax.ejb.EJBAccessException;
import org.apache.openejb.InvalidateReferenceException;
import java.rmi.RemoteException;
import javax.ejb.EJBException;
import javax.ejb.Handle;
import java.io.Serializable;
import java.util.Collection;
import org.apache.openejb.util.proxy.LocalBeanProxyFactory;
import org.apache.openejb.OpenEJBRuntimeException;
import java.lang.reflect.InvocationHandler;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.BeanType;
import java.util.ArrayList;
import org.apache.openejb.core.entity.EntityEjbHomeHandler;
import org.apache.openejb.core.managed.ManagedHomeHandler;
import org.apache.openejb.core.singleton.SingletonEjbHomeHandler;
import org.apache.openejb.core.stateless.StatelessEjbHomeHandler;
import org.apache.openejb.core.stateful.StatefulEjbHomeHandler;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.BeanContext;
import java.util.Map;
import org.apache.openejb.util.Logger;

public abstract class EjbHomeProxyHandler extends BaseEjbProxyHandler
{
    public static final Logger logger;
    private final Map<String, MethodType> dispatchTable;
    
    public EjbHomeProxyHandler(final BeanContext beanContext, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        super(beanContext, null, interfaceType, interfaces, mainInterface);
        (this.dispatchTable = new HashMap<String, MethodType>()).put("create", MethodType.CREATE);
        this.dispatchTable.put("getEJBMetaData", MethodType.META_DATA);
        this.dispatchTable.put("getHomeHandle", MethodType.HOME_HANDLE);
        this.dispatchTable.put("remove", MethodType.REMOVE);
        if (interfaceType.isHome()) {
            final Class homeInterface = beanContext.getInterface(interfaceType);
            final Method[] methods2;
            final Method[] methods = methods2 = homeInterface.getMethods();
            for (final Method method : methods2) {
                if (method.getName().startsWith("create")) {
                    this.dispatchTable.put(method.getName(), MethodType.CREATE);
                }
                else if (method.getName().startsWith("find")) {
                    this.dispatchTable.put(method.getName(), MethodType.FIND);
                }
            }
        }
    }
    
    @Override
    public void invalidateReference() {
        throw new IllegalStateException("A home reference must never be invalidated!");
    }
    
    protected static EjbHomeProxyHandler createHomeHandler(final BeanContext beanContext, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        switch (beanContext.getComponentType()) {
            case STATEFUL: {
                return new StatefulEjbHomeHandler(beanContext, interfaceType, interfaces, mainInterface);
            }
            case STATELESS: {
                return new StatelessEjbHomeHandler(beanContext, interfaceType, interfaces, mainInterface);
            }
            case SINGLETON: {
                return new SingletonEjbHomeHandler(beanContext, interfaceType, interfaces, mainInterface);
            }
            case MANAGED: {
                return new ManagedHomeHandler(beanContext, interfaceType, interfaces, mainInterface);
            }
            case CMP_ENTITY:
            case BMP_ENTITY: {
                return new EntityEjbHomeHandler(beanContext, interfaceType, interfaces, mainInterface);
            }
            default: {
                throw new IllegalStateException("Component type does not support rpc interfaces: " + beanContext.getComponentType());
            }
        }
    }
    
    public static Object createHomeProxy(final BeanContext beanContext, final InterfaceType interfaceType) {
        return createHomeProxy(beanContext, interfaceType, null, interfaceType.isRemote() ? beanContext.getRemoteInterface() : beanContext.getLocalInterface());
    }
    
    public static Object createHomeProxy(final BeanContext beanContext, final InterfaceType interfaceType, final List<Class> objectInterfaces, final Class mainInterface) {
        if (!interfaceType.isHome()) {
            throw new IllegalArgumentException("InterfaceType is not a Home type: " + interfaceType);
        }
        try {
            final EjbHomeProxyHandler handler = createHomeHandler(beanContext, interfaceType, objectInterfaces, mainInterface);
            final List<Class> proxyInterfaces = new ArrayList<Class>(2);
            final Class homeInterface = beanContext.getInterface(interfaceType);
            proxyInterfaces.add(homeInterface);
            proxyInterfaces.add(IntraVmProxy.class);
            if (BeanType.STATEFUL.equals(beanContext.getComponentType()) || BeanType.MANAGED.equals(beanContext.getComponentType())) {
                proxyInterfaces.add(BeanContext.Removable.class);
            }
            return ProxyManager.newProxyInstance((Class[])proxyInterfaces.toArray(new Class[proxyInterfaces.size()]), (InvocationHandler)handler);
        }
        catch (Exception e) {
            throw new OpenEJBRuntimeException("Can't create EJBHome stub" + e.getMessage(), e);
        }
    }
    
    public Object createProxy(final Object primaryKey, final Class mainInterface) {
        try {
            final InterfaceType objectInterfaceType = this.interfaceType.getCounterpart();
            final BeanType type = this.getBeanContext().getComponentType();
            final EjbObjectProxyHandler handler = this.newEjbObjectHandler(this.getBeanContext(), primaryKey, objectInterfaceType, this.getInterfaces(), mainInterface);
            if ((InterfaceType.LOCALBEAN.equals(objectInterfaceType) || this.getBeanContext().getComponentType().equals(BeanType.MANAGED)) && !this.getBeanContext().isDynamicallyImplemented()) {
                return LocalBeanProxyFactory.constructProxy(handler.getBeanContext().get(BeanContext.ProxyClass.class).getProxy(), handler);
            }
            final List<Class> proxyInterfaces = new ArrayList<Class>(handler.getInterfaces().size() + 2);
            proxyInterfaces.addAll(handler.getInterfaces());
            proxyInterfaces.add(Serializable.class);
            proxyInterfaces.add(IntraVmProxy.class);
            if (BeanType.STATEFUL.equals(type) || BeanType.MANAGED.equals(type)) {
                proxyInterfaces.add(BeanContext.Removable.class);
            }
            return ProxyManager.newProxyInstance((Class[])proxyInterfaces.toArray(new Class[proxyInterfaces.size()]), (InvocationHandler)handler);
        }
        catch (IllegalAccessException iae) {
            throw new OpenEJBRuntimeException("Could not create IVM proxy for " + this.getInterfaces().get(0), iae);
        }
    }
    
    protected abstract EjbObjectProxyHandler newEjbObjectHandler(final BeanContext p0, final Object p1, final InterfaceType p2, final List<Class> p3, final Class p4);
    
    @Override
    protected Object _invoke(final Object proxy, final Class interfce, final Method method, final Object[] args) throws Throwable {
        final String methodName = method.getName();
        if (EjbHomeProxyHandler.logger.isDebugEnabled()) {
            EjbHomeProxyHandler.logger.debug("EjbHomeProxyHandler: invoking method " + methodName + " on " + this.deploymentID);
        }
        try {
            final MethodType operation = this.dispatchTable.get(methodName);
            Object retValue = null;
            if (operation == null) {
                retValue = this.homeMethod(interfce, method, args, proxy);
            }
            else {
                switch (operation) {
                    case CREATE: {
                        retValue = this.create(interfce, method, args, proxy);
                        break;
                    }
                    case FIND: {
                        retValue = this.findX(interfce, method, args, proxy);
                        break;
                    }
                    case META_DATA: {
                        retValue = this.getEJBMetaData(method, args, proxy);
                        break;
                    }
                    case HOME_HANDLE: {
                        retValue = this.getHomeHandle(method, args, proxy);
                        break;
                    }
                    case REMOVE: {
                        final Class type = method.getParameterTypes()[0];
                        if (Handle.class.isAssignableFrom(type)) {
                            retValue = this.removeWithHandle(interfce, method, args, proxy);
                            break;
                        }
                        retValue = this.removeByPrimaryKey(interfce, method, args, proxy);
                        break;
                    }
                    default: {
                        throw new OpenEJBRuntimeException("Inconsistent internal state: value " + operation + " for operation " + methodName);
                    }
                }
            }
            if (EjbHomeProxyHandler.logger.isDebugEnabled()) {
                EjbHomeProxyHandler.logger.debug("EjbHomeProxyHandler: finished invoking method " + method.getName() + ". Return value:" + retValue);
            }
            return retValue;
        }
        catch (RemoteException re) {
            if (this.interfaceType.isLocal()) {
                throw new EJBException(re.getMessage()).initCause(re.detail);
            }
            throw re;
        }
        catch (InvalidateReferenceException ire) {
            Throwable cause = ire.getRootCause();
            if (cause instanceof RemoteException && this.interfaceType.isLocal()) {
                final RemoteException re2 = (RemoteException)cause;
                final Throwable detail = (re2.detail != null) ? re2.detail : re2;
                cause = new EJBException(re2.getMessage()).initCause(detail);
            }
            throw cause;
        }
        catch (ApplicationException ae) {
            final Throwable exc = (ae.getRootCause() != null) ? ae.getRootCause() : ae;
            if (exc instanceof EJBAccessException) {
                if (this.interfaceType.isBusiness()) {
                    throw exc;
                }
                if (this.interfaceType.isLocal()) {
                    throw (AccessLocalException)new AccessLocalException(exc.getMessage()).initCause(exc);
                }
                try {
                    throw new AccessException(exc.getMessage()).initCause(exc);
                }
                catch (IllegalStateException vmbug) {
                    throw new AccessException(exc.getMessage(), (Exception)exc);
                }
            }
            throw exc;
        }
        catch (SystemException se) {
            if (this.interfaceType.isLocal()) {
                throw new EJBException("Container has suffered a SystemException").initCause(se.getRootCause());
            }
            throw new RemoteException("Container has suffered a SystemException", se.getRootCause());
        }
        catch (OpenEJBException oe) {
            if (this.interfaceType.isLocal()) {
                throw new EJBException("Unknown Container Exception").initCause(oe.getRootCause());
            }
            throw new RemoteException("Unknown Container Exception", oe.getRootCause());
        }
        catch (Throwable t) {
            EjbHomeProxyHandler.logger.debug("EjbHomeProxyHandler: finished invoking method " + method.getName() + " with exception:" + t, t);
            throw t;
        }
    }
    
    protected Object homeMethod(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        final BeanContext beanContext = this.getBeanContext();
        if (beanContext.isAsynchronous(method)) {
            return beanContext.getModuleContext().getAppContext().getAsynchronousPool().invoke(new CUCallable<Object>(new Callable<Object>() {
                @Override
                public Object call() throws Exception {
                    try {
                        return EjbHomeProxyHandler.this.homeMethodInvoke(interfce, method, args);
                    }
                    catch (ApplicationException ae) {
                        EjbHomeProxyHandler.logger.error("EjbHomeProxyHandler: Asynchronous call to '" + interfce.getSimpleName() + "' on '" + method.getName() + "' failed", ae);
                        throw ae;
                    }
                }
            }), method.getReturnType() == Void.TYPE);
        }
        return this.homeMethodInvoke(interfce, method, args);
    }
    
    private Object homeMethodInvoke(final Class interfce, final Method method, final Object[] args) throws OpenEJBException {
        return this.container.invoke(this.deploymentID, this.interfaceType, interfce, method, args, null);
    }
    
    protected Object create(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        if (this.container.getBeanContext(this.deploymentID) == null) {
            final BeanContext bc = this.getBeanContext();
            synchronized (bc.getId()) {
                if (this.container.getBeanContext(this.deploymentID) == null) {
                    this.container.deploy(bc);
                    this.container.start(bc);
                }
            }
        }
        final ProxyInfo proxyInfo = (ProxyInfo)this.container.invoke(this.deploymentID, this.interfaceType, interfce, method, args, null);
        assert proxyInfo != null : "Container returned a null ProxyInfo: ContainerID=" + this.container.getContainerID();
        return this.createProxy(proxyInfo.getPrimaryKey(), this.getMainInterface());
    }
    
    protected abstract Object findX(final Class p0, final Method p1, final Object[] p2, final Object p3) throws Throwable;
    
    protected Object getEJBMetaData(final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        final IntraVmMetaData metaData = new IntraVmMetaData(this.getBeanContext().getHomeInterface(), this.getBeanContext().getRemoteInterface(), this.getBeanContext().getPrimaryKeyClass(), this.getBeanContext().getComponentType());
        metaData.setEJBHome((EJBHome)proxy);
        return metaData;
    }
    
    protected Object getHomeHandle(final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        return new IntraVmHandle(proxy);
    }
    
    @Override
    public ProxyInfo getProxyInfo() {
        if (this.getMainInterface() == null) {
            throw new IllegalStateException("no main interface");
        }
        return new ProxyInfo(this.getBeanContext(), null, this.getBeanContext().getInterfaces(this.interfaceType), this.interfaceType, this.getMainInterface());
    }
    
    @Override
    protected Object _writeReplace(final Object proxy) throws ObjectStreamException {
        if (IntraVmCopyMonitor.isIntraVmCopyOperation()) {
            return new IntraVmArtifact(proxy);
        }
        if (IntraVmCopyMonitor.isStatefulPassivationOperation()) {
            return proxy;
        }
        if (IntraVmCopyMonitor.isCrossClassLoaderOperation()) {
            return proxy;
        }
        if (!this.interfaceType.isRemote()) {
            return proxy;
        }
        final ApplicationServer applicationServer = ServerFederation.getApplicationServer();
        return applicationServer.getEJBHome(this.getProxyInfo());
    }
    
    protected Object removeWithHandle(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        final IntraVmHandle handle = (IntraVmHandle)args[0];
        final Object primKey = handle.getPrimaryKey();
        EjbObjectProxyHandler stub;
        try {
            stub = (EjbObjectProxyHandler)ProxyManager.getInvocationHandler(handle.getEJBObject());
        }
        catch (IllegalArgumentException e) {
            stub = null;
        }
        this.container.invoke(this.deploymentID, this.interfaceType, interfce, method, args, primKey);
        if (stub != null) {
            this.invalidateAllHandlers(stub.getRegistryId());
        }
        return null;
    }
    
    protected abstract Object removeByPrimaryKey(final Class p0, final Method p1, final Object[] p2, final Object p3) throws Throwable;
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
    
    private enum MethodType
    {
        CREATE, 
        FIND, 
        HOME_HANDLE, 
        META_DATA, 
        REMOVE;
    }
}
