// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.managed;

import java.util.concurrent.locks.ReentrantLock;
import org.apache.openejb.util.LogCategory;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Iterator;
import org.apache.openejb.OpenEJBRuntimeException;
import java.util.concurrent.TimeUnit;
import org.apache.openejb.util.Duration;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.openejb.util.Logger;

public class SimpleCache<K, V> implements Cache<K, V>
{
    public static final Logger logger;
    private final ConcurrentHashMap<K, Entry> cache;
    private final Queue<Entry> lru;
    private CacheListener<V> listener;
    private PassivationStrategy passivator;
    private int capacity;
    private int bulkPassivate;
    private long timeOut;
    
    public SimpleCache() {
        this.cache = new ConcurrentHashMap<K, Entry>();
        this.lru = new LinkedBlockingQueue<Entry>();
    }
    
    public SimpleCache(final CacheListener<V> listener, final PassivationStrategy passivator, final int capacity, final int bulkPassivate, final Duration timeOut) {
        this.cache = new ConcurrentHashMap<K, Entry>();
        this.lru = new LinkedBlockingQueue<Entry>();
        this.listener = listener;
        this.passivator = passivator;
        this.capacity = capacity;
        this.bulkPassivate = bulkPassivate;
        this.timeOut = timeOut.getTime(TimeUnit.MILLISECONDS);
    }
    
    @Override
    public synchronized CacheListener<V> getListener() {
        return this.listener;
    }
    
    @Override
    public synchronized void setListener(final CacheListener<V> listener) {
        this.listener = listener;
    }
    
    public synchronized PassivationStrategy getPassivator() {
        return this.passivator;
    }
    
    public synchronized void setPassivator(final PassivationStrategy passivator) {
        this.passivator = passivator;
    }
    
    public synchronized void setPassivator(final Class<? extends PassivationStrategy> passivatorClass) throws Exception {
        this.passivator = (PassivationStrategy)passivatorClass.newInstance();
    }
    
    public synchronized int getCapacity() {
        return this.capacity;
    }
    
    public synchronized void setCapacity(final int capacity) {
        this.capacity = capacity;
    }
    
    public synchronized void setPoolSize(final int capacity) {
        this.capacity = capacity;
    }
    
    public synchronized int getBulkPassivate() {
        return this.bulkPassivate;
    }
    
    public synchronized void setBulkPassivate(final int bulkPassivate) {
        this.bulkPassivate = bulkPassivate;
    }
    
    public synchronized long getTimeOut() {
        return this.timeOut;
    }
    
    public synchronized void setTimeOut(final long timeOut) {
        this.timeOut = timeOut * 60L * 1000L;
    }
    
    @Override
    public void add(final K key, final V value) {
        Entry entry = this.cache.get(key);
        if (entry != null) {
            entry.lock.lock();
            try {
                if (entry.getState() != EntryState.REMOVED) {
                    throw new IllegalStateException("An entry for the key " + key + " already exists");
                }
                this.cache.remove(key);
                this.lru.remove(entry);
            }
            finally {
                entry.lock.unlock();
            }
        }
        entry = new Entry((Object)key, (Object)value, EntryState.CHECKED_OUT);
        this.cache.put(key, entry);
    }
    
    @Override
    public V checkOut(final K key) throws Exception {
        for (int i = 0; i < 10; ++i) {
            Entry entry = this.cache.get(key);
            if (entry == null) {
                entry = this.loadEntry(key);
                if (entry == null) {
                    return null;
                }
            }
            entry.lock.lock();
            try {
                switch (entry.getState()) {
                    case CHECKED_OUT: {
                        return (V)entry.getValue();
                    }
                    case PASSIVATED: {
                        this.cache.remove(key, entry);
                        continue;
                    }
                    case REMOVED: {
                        return null;
                    }
                }
                entry.setState(EntryState.CHECKED_OUT);
                this.lru.remove(entry);
                return (V)entry.getValue();
            }
            finally {
                entry.lock.unlock();
            }
        }
        final Entry entry2 = this.cache.remove(key);
        if (entry2 != null) {
            this.lru.remove(entry2);
        }
        throw new OpenEJBRuntimeException("Cache is corrupted: the entry " + key + " in the Map 'cache' is in state PASSIVATED");
    }
    
    @Override
    public void checkIn(final K key) {
        final Entry entry = this.cache.get(key);
        if (entry == null) {
            return;
        }
        entry.lock.lock();
        try {
            switch (entry.getState()) {
                case AVAILABLE: {
                    if (this.lru.contains(entry)) {
                        entry.resetTimeOut();
                        return;
                    }
                    throw new IllegalStateException("The entry " + key + " is not checked-out");
                }
                case PASSIVATED: {
                    throw new IllegalStateException("The entry " + key + " is not checked-out");
                }
                case REMOVED: {
                    return;
                }
                default: {
                    entry.setState(EntryState.AVAILABLE);
                    this.lru.add(entry);
                    entry.resetTimeOut();
                    break;
                }
            }
        }
        finally {
            entry.lock.unlock();
        }
        this.processLRU();
    }
    
    @Override
    public V remove(final K key) {
        final Entry entry = this.cache.get(key);
        if (entry == null) {
            return null;
        }
        entry.lock.lock();
        try {
            this.cache.remove(key);
            this.lru.remove(entry);
            entry.setState(EntryState.REMOVED);
            return (V)entry.getValue();
        }
        finally {
            entry.lock.unlock();
        }
    }
    
    @Override
    public void removeAll(final CacheFilter<V> filter) {
        final Iterator<Entry> iterator = this.cache.values().iterator();
        while (iterator.hasNext()) {
            final Entry entry = iterator.next();
            entry.lock.lock();
            try {
                if (!filter.matches((V)entry.getValue())) {
                    continue;
                }
                iterator.remove();
                this.lru.remove(entry);
                entry.setState(EntryState.REMOVED);
            }
            finally {
                entry.lock.unlock();
            }
        }
    }
    
    public void processLRU() {
        final CacheListener<V> listener = this.getListener();
        final Iterator<Entry> iterator = this.lru.iterator();
        while (iterator.hasNext()) {
            final Entry entry = iterator.next();
            entry.lock.lock();
            try {
                switch (entry.getState()) {
                    case CHECKED_OUT: {
                        continue;
                    }
                    case PASSIVATED: {
                        iterator.remove();
                        continue;
                    }
                    case REMOVED: {
                        iterator.remove();
                        continue;
                    }
                }
                if (!entry.isTimedOut()) {
                    break;
                }
                iterator.remove();
                this.cache.remove(entry.getKey());
                entry.setState(EntryState.REMOVED);
                if (listener == null) {
                    continue;
                }
                try {
                    listener.timedOut((V)entry.getValue());
                }
                catch (Exception e) {
                    SimpleCache.logger.error("An unexpected exception occured from timedOut callback", e);
                }
            }
            finally {
                entry.lock.unlock();
            }
        }
        if (this.lru.size() >= this.getCapacity()) {
            final Map<K, V> valuesToStore = new LinkedHashMap<K, V>();
            final List<Entry> entries = new ArrayList<Entry>();
            int bulkPassivate = this.getBulkPassivate();
            if (bulkPassivate < 1) {
                bulkPassivate = 1;
            }
            for (int i = 0; i < bulkPassivate; ++i) {
                final Entry entry2 = this.lru.poll();
                if (entry2 == null) {
                    break;
                }
                if (entry2.lock.tryLock()) {
                    try {
                        switch (entry2.getState()) {
                            case CHECKED_OUT: {
                                continue;
                            }
                            case PASSIVATED: {
                                this.lru.remove(entry2);
                                continue;
                            }
                            case REMOVED: {
                                this.lru.remove(entry2);
                                continue;
                            }
                        }
                        this.cache.remove(entry2.getKey());
                        this.lru.remove(entry2);
                        if (entry2.isTimedOut()) {
                            entry2.setState(EntryState.REMOVED);
                            if (listener != null) {
                                try {
                                    listener.timedOut((V)entry2.getValue());
                                }
                                catch (Exception e2) {
                                    SimpleCache.logger.error("An unexpected exception occured from timedOut callback", e2);
                                }
                            }
                        }
                        else {
                            entry2.lock.lock();
                            entries.add(entry2);
                            entry2.setState(EntryState.PASSIVATED);
                            valuesToStore.put((K)entry2.getKey(), (V)entry2.getValue());
                        }
                    }
                    finally {
                        entry2.lock.unlock();
                    }
                }
            }
            if (!valuesToStore.isEmpty()) {
                try {
                    this.storeEntries(valuesToStore);
                }
                finally {
                    for (final Entry entry3 : entries) {
                        entry3.lock.unlock();
                    }
                }
            }
        }
    }
    
    private Entry loadEntry(final K key) throws Exception {
        final PassivationStrategy passivator = this.getPassivator();
        if (passivator == null) {
            return null;
        }
        V value = null;
        try {
            value = (V)passivator.activate(key);
        }
        catch (Exception e) {
            SimpleCache.logger.error("An unexpected exception occured while reading entries from disk", e);
        }
        if (value == null) {
            return null;
        }
        final CacheListener<V> listener = this.getListener();
        if (listener != null) {
            listener.afterLoad(value);
        }
        final Entry entry = new Entry((Object)key, (Object)value, EntryState.AVAILABLE);
        this.cache.put(key, entry);
        return entry;
    }
    
    private void storeEntries(final Map<K, V> entriesToStore) {
        final CacheListener<V> listener = this.getListener();
        final Iterator<Map.Entry<K, V>> iterator = entriesToStore.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry<K, V> entry = iterator.next();
            if (listener != null) {
                try {
                    listener.beforeStore(entry.getValue());
                }
                catch (Exception e) {
                    iterator.remove();
                    SimpleCache.logger.error("An unexpected exception occured from beforeStore callback", e);
                }
            }
        }
        final PassivationStrategy passivator = this.getPassivator();
        if (passivator == null) {
            return;
        }
        try {
            passivator.passivate(entriesToStore);
        }
        catch (Exception e2) {
            SimpleCache.logger.error("An unexpected exception occured while writting the entries to disk", e2);
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
    
    private enum EntryState
    {
        AVAILABLE, 
        CHECKED_OUT, 
        PASSIVATED, 
        REMOVED;
    }
    
    private final class Entry
    {
        private final K key;
        private final V value;
        private final ReentrantLock lock;
        private EntryState state;
        private long lastAccess;
        
        private Entry(final K key, final V value, final EntryState state) {
            this.lock = new ReentrantLock();
            this.key = key;
            this.value = value;
            this.state = state;
            this.lastAccess = System.currentTimeMillis();
        }
        
        private K getKey() {
            this.assertLockHeld();
            return this.key;
        }
        
        private V getValue() {
            this.assertLockHeld();
            return this.value;
        }
        
        private EntryState getState() {
            this.assertLockHeld();
            return this.state;
        }
        
        private void setState(final EntryState state) {
            this.assertLockHeld();
            this.state = state;
        }
        
        private boolean isTimedOut() {
            this.assertLockHeld();
            final long timeOut = SimpleCache.this.getTimeOut();
            if (timeOut == 0L) {
                return false;
            }
            final long now = System.currentTimeMillis();
            return now - this.lastAccess > timeOut;
        }
        
        private void resetTimeOut() {
            this.assertLockHeld();
            if (SimpleCache.this.getTimeOut() > 0L) {
                this.lastAccess = System.currentTimeMillis();
            }
        }
        
        private void assertLockHeld() {
            if (!this.lock.isHeldByCurrentThread()) {
                throw new IllegalStateException("Entry must be locked");
            }
        }
    }
}
