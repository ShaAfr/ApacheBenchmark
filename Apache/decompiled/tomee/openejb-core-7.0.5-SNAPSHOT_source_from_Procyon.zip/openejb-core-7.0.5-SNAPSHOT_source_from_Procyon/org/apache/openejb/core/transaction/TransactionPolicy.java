// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import javax.transaction.xa.XAResource;
import org.apache.openejb.SystemException;
import org.apache.openejb.ApplicationException;

public interface TransactionPolicy
{
    TransactionType getTransactionType();
    
    boolean isNewTransaction();
    
    boolean isClientTransaction();
    
    boolean isTransactionActive();
    
    boolean isRollbackOnly();
    
    void setRollbackOnly();
    
    void setRollbackOnly(final Throwable p0);
    
    void commit() throws ApplicationException, SystemException;
    
    Object getResource(final Object p0);
    
    void putResource(final Object p0, final Object p1);
    
    Object removeResource(final Object p0);
    
    void registerSynchronization(final TransactionSynchronization p0);
    
    void enlistResource(final XAResource p0) throws SystemException;
    
    public interface TransactionSynchronization
    {
        void beforeCompletion();
        
        void afterCompletion(final Status p0);
        
        public enum Status
        {
            COMMITTED, 
            ROLLEDBACK, 
            UNKNOWN;
        }
    }
}
