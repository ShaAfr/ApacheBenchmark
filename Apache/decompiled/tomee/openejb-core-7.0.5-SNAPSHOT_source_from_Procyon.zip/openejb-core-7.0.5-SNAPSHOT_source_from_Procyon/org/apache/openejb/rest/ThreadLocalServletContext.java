// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.servlet.descriptor.JspConfigDescriptor;
import javax.servlet.SessionTrackingMode;
import javax.servlet.SessionCookieConfig;
import java.util.EventListener;
import javax.servlet.Filter;
import javax.servlet.FilterRegistration;
import java.util.Map;
import javax.servlet.ServletRegistration;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.Servlet;
import javax.servlet.RequestDispatcher;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;
import javax.servlet.ServletContext;

public class ThreadLocalServletContext extends AbstractRestThreadLocalProxy<ServletContext> implements ServletContext
{
    protected ThreadLocalServletContext() {
        super(ServletContext.class);
    }
    
    public String getContextPath() {
        return this.get().getContextPath();
    }
    
    public ServletContext getContext(final String uripath) {
        return this.get().getContext(uripath);
    }
    
    public int getMajorVersion() {
        return this.get().getMajorVersion();
    }
    
    public int getMinorVersion() {
        return this.get().getMinorVersion();
    }
    
    public String getMimeType(final String file) {
        return this.get().getMimeType(file);
    }
    
    public Set<String> getResourcePaths(final String path) {
        return (Set<String>)this.get().getResourcePaths(path);
    }
    
    public URL getResource(final String path) throws MalformedURLException {
        return this.get().getResource(path);
    }
    
    public InputStream getResourceAsStream(final String path) {
        return this.get().getResourceAsStream(path);
    }
    
    public RequestDispatcher getRequestDispatcher(final String path) {
        return this.get().getRequestDispatcher(path);
    }
    
    public RequestDispatcher getNamedDispatcher(final String name) {
        return this.get().getNamedDispatcher(name);
    }
    
    public Servlet getServlet(final String name) throws ServletException {
        return this.get().getServlet(name);
    }
    
    public Enumeration<Servlet> getServlets() {
        return (Enumeration<Servlet>)this.get().getServlets();
    }
    
    public Enumeration<String> getServletNames() {
        return (Enumeration<String>)this.get().getServletNames();
    }
    
    public void log(final String msg) {
        this.get().log(msg);
    }
    
    public void log(final Exception exception, final String msg) {
        this.get().log(exception, msg);
    }
    
    public void log(final String message, final Throwable throwable) {
        this.get().log(message, throwable);
    }
    
    public String getRealPath(final String path) {
        return this.get().getRealPath(path);
    }
    
    public String getServerInfo() {
        return this.get().getServerInfo();
    }
    
    public String getInitParameter(final String name) {
        return this.get().getInitParameter(name);
    }
    
    public Enumeration<String> getInitParameterNames() {
        return (Enumeration<String>)this.get().getInitParameterNames();
    }
    
    public boolean setInitParameter(final String name, final String value) {
        return this.get().setInitParameter(name, value);
    }
    
    public Object getAttribute(final String name) {
        return this.get().getAttribute(name);
    }
    
    public Enumeration<String> getAttributeNames() {
        return (Enumeration<String>)this.get().getAttributeNames();
    }
    
    public void setAttribute(final String name, final Object object) {
        this.get().setAttribute(name, object);
    }
    
    public void removeAttribute(final String name) {
        this.get().removeAttribute(name);
    }
    
    public String getServletContextName() {
        return this.get().getServletContextName();
    }
    
    public ServletRegistration.Dynamic addServlet(final String servletName, final String className) throws IllegalArgumentException, IllegalStateException {
        return this.get().addServlet(servletName, className);
    }
    
    public ServletRegistration.Dynamic addServlet(final String servletName, final Servlet servlet) throws IllegalArgumentException, IllegalStateException {
        return this.get().addServlet(servletName, servlet);
    }
    
    public ServletRegistration.Dynamic addServlet(final String servletName, final Class<? extends Servlet> clazz) throws IllegalArgumentException, IllegalStateException {
        return this.get().addServlet(servletName, (Class)clazz);
    }
    
    public <T extends Servlet> T createServlet(final Class<T> clazz) throws ServletException {
        return (T)this.get().createServlet((Class)clazz);
    }
    
    public ServletRegistration getServletRegistration(final String servletName) {
        return this.get().getServletRegistration(servletName);
    }
    
    public Map<String, ? extends ServletRegistration> getServletRegistrations() {
        return (Map<String, ? extends ServletRegistration>)this.get().getServletRegistrations();
    }
    
    public FilterRegistration.Dynamic addFilter(final String filterName, final String className) throws IllegalArgumentException, IllegalStateException {
        return this.get().addFilter(filterName, className);
    }
    
    public FilterRegistration.Dynamic addFilter(final String filterName, final Filter filter) throws IllegalArgumentException, IllegalStateException {
        return this.get().addFilter(filterName, filter);
    }
    
    public FilterRegistration.Dynamic addFilter(final String filterName, final Class<? extends Filter> filterClass) throws IllegalArgumentException, IllegalStateException {
        return this.get().addFilter(filterName, (Class)filterClass);
    }
    
    public <T extends Filter> T createFilter(final Class<T> clazz) throws ServletException {
        return (T)this.get().createFilter((Class)clazz);
    }
    
    public FilterRegistration getFilterRegistration(final String filterName) {
        return this.get().getFilterRegistration(filterName);
    }
    
    public Map<String, ? extends FilterRegistration> getFilterRegistrations() {
        return (Map<String, ? extends FilterRegistration>)this.get().getFilterRegistrations();
    }
    
    public void addListener(final Class<? extends EventListener> listenerClass) {
        this.get().addListener((Class)listenerClass);
    }
    
    public void addListener(final String className) {
        this.get().addListener(className);
    }
    
    public <T extends EventListener> void addListener(final T t) {
        this.get().addListener((EventListener)t);
    }
    
    public <T extends EventListener> T createListener(final Class<T> clazz) throws ServletException {
        return (T)this.get().createListener((Class)clazz);
    }
    
    public void declareRoles(final String... roleNames) {
        this.get().declareRoles(roleNames);
    }
    
    public String getVirtualServerName() {
        return this.get().getVirtualServerName();
    }
    
    public SessionCookieConfig getSessionCookieConfig() {
        return this.get().getSessionCookieConfig();
    }
    
    public void setSessionTrackingModes(final Set<SessionTrackingMode> sessionTrackingModes) {
        this.get().setSessionTrackingModes((Set)sessionTrackingModes);
    }
    
    public Set<SessionTrackingMode> getDefaultSessionTrackingModes() {
        return (Set<SessionTrackingMode>)this.get().getDefaultSessionTrackingModes();
    }
    
    public int getEffectiveMajorVersion() throws UnsupportedOperationException {
        return this.get().getEffectiveMajorVersion();
    }
    
    public int getEffectiveMinorVersion() throws UnsupportedOperationException {
        return this.get().getEffectiveMinorVersion();
    }
    
    public Set<SessionTrackingMode> getEffectiveSessionTrackingModes() {
        return (Set<SessionTrackingMode>)this.get().getEffectiveSessionTrackingModes();
    }
    
    public ClassLoader getClassLoader() {
        return this.get().getClassLoader();
    }
    
    public JspConfigDescriptor getJspConfigDescriptor() {
        return this.get().getJspConfigDescriptor();
    }
}
