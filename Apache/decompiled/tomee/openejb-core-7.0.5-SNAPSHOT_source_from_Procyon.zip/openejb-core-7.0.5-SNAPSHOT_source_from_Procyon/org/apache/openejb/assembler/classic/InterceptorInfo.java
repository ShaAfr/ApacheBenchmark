// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class InterceptorInfo extends InfoObject
{
    public String clazz;
    public final List<CallbackInfo> aroundInvoke;
    public final List<CallbackInfo> postConstruct;
    public final List<CallbackInfo> preDestroy;
    public final List<CallbackInfo> postActivate;
    public final List<CallbackInfo> prePassivate;
    public final List<CallbackInfo> afterBegin;
    public final List<CallbackInfo> beforeCompletion;
    public final List<CallbackInfo> afterCompletion;
    public final List<CallbackInfo> aroundTimeout;
    
    public InterceptorInfo() {
        this.aroundInvoke = new ArrayList<CallbackInfo>();
        this.postConstruct = new ArrayList<CallbackInfo>();
        this.preDestroy = new ArrayList<CallbackInfo>();
        this.postActivate = new ArrayList<CallbackInfo>();
        this.prePassivate = new ArrayList<CallbackInfo>();
        this.afterBegin = new ArrayList<CallbackInfo>();
        this.beforeCompletion = new ArrayList<CallbackInfo>();
        this.afterCompletion = new ArrayList<CallbackInfo>();
        this.aroundTimeout = new ArrayList<CallbackInfo>();
    }
}
