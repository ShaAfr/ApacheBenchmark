// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jaas;

import java.util.HashSet;
import org.apache.openejb.util.LogCategory;
import java.util.Iterator;
import javax.script.Bindings;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import java.util.Collection;
import javax.script.ScriptException;
import java.util.List;
import javax.script.SimpleScriptContext;
import javax.script.ScriptEngineManager;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.net.URI;
import org.apache.openejb.util.URLs;
import org.apache.openejb.util.JavaSecurityManagers;
import java.io.File;
import javax.security.auth.callback.UnsupportedCallbackException;
import java.io.IOException;
import javax.security.auth.login.LoginException;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.Callback;
import java.util.LinkedHashSet;
import java.security.Principal;
import java.util.Set;
import java.util.Map;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.Subject;
import org.apache.openejb.util.Logger;
import javax.security.auth.spi.LoginModule;

public class ScriptLoginModule implements LoginModule
{
    private static final Logger log;
    private Subject subject;
    private CallbackHandler callbackHandler;
    private Map<String, ?> options;
    public Set<Principal> principals;
    private UserData userData;
    
    public ScriptLoginModule() {
        this.principals = new LinkedHashSet<Principal>();
    }
    
    @Override
    public void initialize(final Subject subject, final CallbackHandler callbackHandler, final Map<String, ?> sharedState, final Map<String, ?> options) {
        this.options = options;
        this.subject = subject;
        this.callbackHandler = callbackHandler;
    }
    
    private UserData getUserData() throws LoginException {
        final Callback[] callbacks = { new NameCallback("Username: "), new PasswordCallback("Password: ", false) };
        try {
            this.callbackHandler.handle(callbacks);
        }
        catch (IOException ioe) {
            throw new LoginException(ioe.getMessage());
        }
        catch (UnsupportedCallbackException uce) {
            throw new LoginException(uce.getMessage() + " not available to obtain information from user");
        }
        final String user = ((NameCallback)callbacks[0]).getName();
        char[] tmpPassword = ((PasswordCallback)callbacks[1]).getPassword();
        if (tmpPassword == null) {
            tmpPassword = new char[0];
        }
        final String password = new String(tmpPassword);
        return new UserData(user, password);
    }
    
    private File getScriptFile(final String path) {
        if (path == null || "".equals(path)) {
            final File result = new File(JavaSecurityManagers.getSystemProperty("openejb.home"), "conf/loginscript.js");
            if (result.exists()) {
                return result;
            }
            return null;
        }
        else {
            try {
                final URI uri = URLs.uri(path);
                final File result2 = new File(uri);
                if (result2.exists()) {
                    return result2;
                }
            }
            catch (Exception ex) {}
            final File result = new File(path);
            if (result.exists()) {
                return result;
            }
            final File openEjbConf = new File(JavaSecurityManagers.getSystemProperty("openejb.home"), "conf");
            final File result2 = new File(openEjbConf, path);
            if (result2.exists()) {
                return result2;
            }
            return null;
        }
    }
    
    @Override
    public boolean login() throws LoginException {
        File script = this.getScriptFile((String)this.options.get("scriptURI"));
        if (script == null) {
            script = this.getScriptFile(JavaSecurityManagers.getSystemProperty("openejb.ScriptLoginModule.scriptURI"));
            if (script == null) {
                script = this.getScriptFile(null);
            }
        }
        if (script == null) {
            throw new LoginException("No login script defined");
        }
        String scriptText;
        try {
            scriptText = new Scanner(script).useDelimiter("\\Z").next();
        }
        catch (FileNotFoundException e2) {
            throw new LoginException("Invalid login script URI.");
        }
        this.userData = this.getUserData();
        final ScriptEngineManager manager = new ScriptEngineManager();
        final ScriptEngine engine = manager.getEngineByName((String)this.options.get("engineName"));
        final ScriptContext newContext = new SimpleScriptContext();
        final Bindings bindings = newContext.getBindings(100);
        bindings.put("user", (Object)this.userData.user);
        bindings.put("password", (Object)this.userData.pass);
        List<String> myGroups;
        try {
            myGroups = (List<String>)engine.eval(scriptText, newContext);
        }
        catch (ScriptException e) {
            throw new LoginException("Cannot execute login script. Msg: " + e.getMessage());
        }
        this.userData.groups.addAll(myGroups);
        return true;
    }
    
    @Override
    public boolean commit() throws LoginException {
        this.principals.add(new UserPrincipal(this.userData.user));
        for (final String myGroup : this.userData.groups) {
            this.principals.add(new GroupPrincipal(myGroup));
        }
        this.subject.getPrincipals().addAll(this.principals);
        this.clear();
        ScriptLoginModule.log.debug("commit");
        return true;
    }
    
    @Override
    public boolean abort() throws LoginException {
        this.clear();
        ScriptLoginModule.log.debug("abort");
        return true;
    }
    
    @Override
    public boolean logout() throws LoginException {
        this.subject.getPrincipals().removeAll(this.principals);
        this.principals.clear();
        ScriptLoginModule.log.debug("logout");
        return true;
    }
    
    private void clear() {
        this.userData = null;
    }
    
    static {
        log = Logger.getInstance(LogCategory.OPENEJB_SECURITY, "org.apache.openejb.util.resources");
    }
    
    private final class UserData
    {
        public final String user;
        public final String pass;
        public final Set<String> groups;
        
        private UserData(final String user, final String pass) {
            this.groups = new HashSet<String>();
            this.user = user;
            this.pass = pass;
        }
    }
}
