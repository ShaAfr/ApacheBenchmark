// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.spi;

import org.apache.openejb.AppContext;
import java.util.List;
import javax.naming.Context;
import org.apache.openejb.core.WebContext;
import org.apache.openejb.Container;
import org.apache.openejb.BeanContext;

public interface ContainerSystem
{
    BeanContext getBeanContext(final Object p0);
    
    BeanContext[] deployments();
    
    Container getContainer(final Object p0);
    
    Container[] containers();
    
    WebContext getWebContextByHost(final String p0, final String p1);
    
    @Deprecated
    WebContext getWebContext(final String p0);
    
    Context getJNDIContext();
    
    List<AppContext> getAppContexts();
    
    AppContext getAppContext(final Object p0);
}
