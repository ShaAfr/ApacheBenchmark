// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

public interface PasswordCipher
{
    char[] encrypt(final String p0);
    
    String decrypt(final char[] p0);
}
