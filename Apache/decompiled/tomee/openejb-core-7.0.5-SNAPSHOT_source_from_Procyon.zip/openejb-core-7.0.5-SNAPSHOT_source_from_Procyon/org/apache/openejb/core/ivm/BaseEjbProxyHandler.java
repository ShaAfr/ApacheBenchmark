// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import org.apache.openejb.core.ThreadContextListener;
import org.apache.openejb.spi.ContainerSystem;
import javax.transaction.Transaction;
import javax.transaction.SystemException;
import javax.transaction.RollbackException;
import javax.transaction.Synchronization;
import java.util.concurrent.ConcurrentHashMap;
import javax.transaction.TransactionSynchronizationRegistry;
import javax.transaction.TransactionManager;
import org.apache.openejb.core.Operation;
import java.util.concurrent.ConcurrentMap;
import org.apache.openejb.ProxyInfo;
import java.io.ObjectStreamException;
import java.util.HashSet;
import java.io.ObjectInputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.NotSerializableException;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import org.apache.openejb.util.proxy.LocalBeanProxyFactory;
import java.lang.reflect.Proxy;
import javax.ejb.EJBException;
import java.rmi.RemoteException;
import javax.ejb.AccessLocalException;
import java.rmi.AccessException;
import javax.ejb.TransactionRolledbackLocalException;
import javax.ejb.EJBTransactionRolledbackException;
import javax.transaction.TransactionRolledbackException;
import javax.ejb.TransactionRequiredLocalException;
import javax.ejb.EJBTransactionRequiredException;
import javax.transaction.TransactionRequiredException;
import javax.ejb.NoSuchEJBException;
import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import javax.ejb.NoSuchObjectLocalException;
import java.io.IOException;
import org.apache.openejb.BeanType;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.OpenEJBException;
import java.util.Set;
import java.util.Iterator;
import java.lang.reflect.Method;
import org.apache.openejb.loader.SystemInstance;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import org.apache.openejb.BeanContext;
import java.lang.ref.WeakReference;
import org.apache.openejb.RpcContainer;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.openejb.InterfaceType;
import java.io.Serializable;
import java.lang.reflect.InvocationHandler;

public abstract class BaseEjbProxyHandler implements InvocationHandler, Serializable
{
    private static final String OPENEJB_LOCALCOPY = "openejb.localcopy";
    private static final boolean REMOTE_COPY_ENABLED;
    public final Object deploymentID;
    public final Object primaryKey;
    protected final InterfaceType interfaceType;
    private final ReentrantLock lock;
    public boolean inProxyMap;
    public transient RpcContainer container;
    protected boolean isInvalidReference;
    protected Object clientIdentity;
    private IntraVmCopyMonitor.State strategy;
    private transient WeakReference<BeanContext> beanContextRef;
    private boolean doIntraVmCopy;
    private boolean doCrossClassLoaderCopy;
    private transient WeakHashMap<Class, Object> interfaces;
    private transient WeakReference<Class> mainInterface;
    
    public BaseEjbProxyHandler(final BeanContext beanContext, final Object pk, final InterfaceType interfaceType, List<Class> interfaces, Class mainInterface) {
        this.lock = new ReentrantLock();
        this.strategy = IntraVmCopyMonitor.State.NONE;
        this.container = (RpcContainer)beanContext.getContainer();
        this.deploymentID = beanContext.getDeploymentID();
        this.interfaceType = interfaceType;
        this.primaryKey = pk;
        this.setBeanContext(beanContext);
        if (interfaces == null || interfaces.size() == 0) {
            final InterfaceType objectInterfaceType = interfaceType.isHome() ? interfaceType.getCounterpart() : interfaceType;
            interfaces = new ArrayList<Class>(beanContext.getInterfaces(objectInterfaceType));
        }
        if (mainInterface == null && interfaces.size() == 1) {
            mainInterface = interfaces.get(0);
        }
        this.setInterfaces(interfaces);
        this.setMainInterface(mainInterface);
        if (mainInterface == null) {
            throw new IllegalArgumentException("No mainInterface: otherwise di: " + beanContext + " InterfaceType: " + interfaceType + " interfaces: " + interfaces);
        }
        this.setDoIntraVmCopy(BaseEjbProxyHandler.REMOTE_COPY_ENABLED && !interfaceType.isLocal() && !interfaceType.isLocalBean());
    }
    
    private static boolean parseRemoteCopySetting() {
        return SystemInstance.get().getOptions().get("openejb.localcopy", true);
    }
    
    protected void setDoIntraVmCopy(final boolean doIntraVmCopy) {
        this.doIntraVmCopy = doIntraVmCopy;
        this.setStrategy();
    }
    
    protected void setDoCrossClassLoaderCopy(final boolean doCrossClassLoaderCopy) {
        this.doCrossClassLoaderCopy = doCrossClassLoaderCopy;
        this.setStrategy();
    }
    
    private void setStrategy() {
        if (!this.doIntraVmCopy) {
            this.strategy = IntraVmCopyMonitor.State.NONE;
        }
        else if (this.doCrossClassLoaderCopy) {
            this.strategy = IntraVmCopyMonitor.State.CLASSLOADER_COPY;
        }
        else {
            this.strategy = IntraVmCopyMonitor.State.COPY;
        }
    }
    
    protected Class<?> getInvokedInterface(final Method method) {
        final Class mainInterface = this.getMainInterface();
        if (this.interfaceType.isHome()) {
            return (Class<?>)mainInterface;
        }
        if (this.interfaceType.isLocalBean()) {
            return (Class<?>)mainInterface;
        }
        final Class declaringClass = method.getDeclaringClass();
        if (mainInterface != null && declaringClass.isAssignableFrom(mainInterface)) {
            return (Class<?>)mainInterface;
        }
        for (final Class secondaryInterface : this.interfaces.keySet()) {
            if (declaringClass.isAssignableFrom(secondaryInterface)) {
                return (Class<?>)secondaryInterface;
            }
        }
        throw new IllegalStateException("Received method invocation and cannot determine corresponding business interface: method=" + method);
    }
    
    public Class getMainInterface() {
        return this.mainInterface.get();
    }
    
    private void setMainInterface(final Class referent) {
        this.mainInterface = new WeakReference<Class>(referent);
    }
    
    public List<Class> getInterfaces() {
        final Set<Class> classes = (Set<Class>)this.interfaces.keySet();
        final List<Class> list = new ArrayList<Class>();
        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        for (final Class<?> clazz : classes) {
            if (clazz.isInterface() && this.getBeanContext().getInterfaceType(clazz) == InterfaceType.BUSINESS_REMOTE) {
                try {
                    list.add(contextClassLoader.loadClass(clazz.getName()));
                }
                catch (ClassNotFoundException | NoClassDefFoundError ex) {
                    final Throwable t;
                    final Throwable e = t;
                    list.add(clazz);
                }
            }
            else {
                list.add(clazz);
            }
        }
        return list;
    }
    
    private void setInterfaces(final List<Class> interfaces) {
        this.interfaces = new WeakHashMap<Class, Object>(interfaces.size());
        for (final Class clazz : interfaces) {
            this.interfaces.put(clazz, null);
        }
    }
    
    protected void checkAuthorization(final Method method) throws OpenEJBException {
    }
    
    public void setIntraVmCopyMode(final boolean on) {
        this.setDoIntraVmCopy(on);
    }
    
    @Override
    public Object invoke(final Object proxy, Method method, Object[] args) throws Throwable {
        try {
            this.isValidReference(method);
        }
        catch (IllegalStateException ise) {
            if (method.getName().equals("writeReplace")) {
                final BeanContext beanContext = this.beanContextRef.get();
                if (beanContext != null) {
                    return this._writeReplace(proxy);
                }
            }
            throw ise;
        }
        if (args == null) {
            args = new Object[0];
        }
        if (method.getDeclaringClass() == Object.class) {
            final String methodName = method.getName();
            if (methodName.equals("toString")) {
                return this.toString();
            }
            if (methodName.equals("equals")) {
                return this.equals(args[0]) ? Boolean.TRUE : Boolean.FALSE;
            }
            if (methodName.equals("hashCode")) {
                return this.hashCode();
            }
            throw new UnsupportedOperationException("Unknown method: " + method);
        }
        else if (method.getDeclaringClass() == IntraVmProxy.class) {
            final String methodName = method.getName();
            if (methodName.equals("writeReplace")) {
                return this._writeReplace(proxy);
            }
            throw new UnsupportedOperationException("Unknown method: " + method);
        }
        else {
            if (method.getDeclaringClass() == BeanContext.Removable.class) {
                return this._invoke(proxy, BeanContext.Removable.class, method, args);
            }
            Class interfce = this.getInvokedInterface(method);
            final ThreadContext callContext = ThreadContext.getThreadContext();
            final Object localClientIdentity = ClientSecurity.getIdentity();
            try {
                if (callContext == null && localClientIdentity != null) {
                    final SecurityService securityService = (SecurityService)SystemInstance.get().getComponent((Class)SecurityService.class);
                    securityService.associate(localClientIdentity);
                }
                if (this.strategy == IntraVmCopyMonitor.State.CLASSLOADER_COPY || this.getBeanContext().getInterfaceType(interfce) == InterfaceType.BUSINESS_REMOTE) {
                    IntraVmCopyMonitor.pre(this.strategy);
                    final ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
                    Thread.currentThread().setContextClassLoader(this.getBeanContext().getClassLoader());
                    try {
                        args = this.copyArgs(args);
                        method = this.copyMethod(method);
                        interfce = this.copyObj(interfce);
                    }
                    finally {
                        Thread.currentThread().setContextClassLoader(oldClassLoader);
                        IntraVmCopyMonitor.post();
                    }
                }
                else if (this.strategy == IntraVmCopyMonitor.State.COPY && args != null && args.length > 0) {
                    IntraVmCopyMonitor.pre(this.strategy);
                    try {
                        args = this.copyArgs(args);
                    }
                    finally {
                        IntraVmCopyMonitor.post();
                    }
                }
                final IntraVmCopyMonitor.State oldStrategy = this.strategy;
                if (this.getBeanContext().isAsynchronous(method) || this.getBeanContext().getComponentType().equals(BeanType.MANAGED)) {
                    this.strategy = IntraVmCopyMonitor.State.NONE;
                }
                try {
                    final Object returnValue = this._invoke(proxy, interfce, method, args);
                    return this.copy(this.strategy, returnValue);
                }
                catch (Throwable throwable) {
                    throwable = this.copy(this.strategy, throwable);
                    throw this.convertException(throwable, method, interfce);
                }
                finally {
                    this.strategy = oldStrategy;
                }
            }
            finally {
                if (callContext == null && localClientIdentity != null) {
                    final SecurityService securityService2 = (SecurityService)SystemInstance.get().getComponent((Class)SecurityService.class);
                    securityService2.disassociate();
                }
            }
        }
    }
    
    private <T> T copy(final IntraVmCopyMonitor.State strategy, final T object) throws IOException, ClassNotFoundException {
        if (object == null || !strategy.isCopy()) {
            return object;
        }
        IntraVmCopyMonitor.pre(strategy);
        try {
            return this.copyObj(object);
        }
        finally {
            IntraVmCopyMonitor.post();
        }
    }
    
    public boolean isValid() {
        return !this.isInvalidReference;
    }
    
    private void isValidReference(final Method method) throws NoSuchObjectException {
        if (!this.isInvalidReference) {
            if (!Object.class.equals(method.getDeclaringClass()) || !method.getName().equals("finalize") || method.getExceptionTypes().length != 1 || !Throwable.class.equals(method.getExceptionTypes()[0])) {
                this.getBeanContext();
            }
            return;
        }
        if (this.interfaceType.isComponent() && this.interfaceType.isLocal()) {
            throw new NoSuchObjectLocalException("reference is invalid");
        }
        if (this.interfaceType.isComponent() || Remote.class.isAssignableFrom(method.getDeclaringClass())) {
            throw new NoSuchObjectException("reference is invalid");
        }
        throw new NoSuchEJBException("reference is invalid for " + this.deploymentID);
    }
    
    protected Throwable convertException(Throwable e, final Method method, final Class interfce) {
        final boolean rmiRemote = Remote.class.isAssignableFrom(interfce);
        if (e instanceof TransactionRequiredException) {
            if (!rmiRemote && this.interfaceType.isBusiness()) {
                return new EJBTransactionRequiredException(e.getMessage()).initCause(this.getCause(e));
            }
            if (this.interfaceType.isLocal()) {
                return new TransactionRequiredLocalException(e.getMessage()).initCause(this.getCause(e));
            }
            return e;
        }
        else if (e instanceof TransactionRolledbackException) {
            if (!rmiRemote && this.interfaceType.isBusiness()) {
                return new EJBTransactionRolledbackException(e.getMessage()).initCause(this.getCause(e));
            }
            if (this.interfaceType.isLocal()) {
                return new TransactionRolledbackLocalException(e.getMessage()).initCause(this.getCause(e));
            }
            return e;
        }
        else if (e instanceof NoSuchObjectException) {
            if (!rmiRemote && this.interfaceType.isBusiness()) {
                return new NoSuchEJBException(e.getMessage()).initCause(this.getCause(e));
            }
            if (this.interfaceType.isLocal()) {
                return new NoSuchObjectLocalException(e.getMessage()).initCause(this.getCause(e));
            }
            return e;
        }
        else if (e instanceof AccessException) {
            if (!rmiRemote && this.interfaceType.isBusiness()) {
                return new AccessLocalException(e.getMessage()).initCause(this.getCause(e));
            }
            if (this.interfaceType.isLocal()) {
                return new AccessLocalException(e.getMessage()).initCause(this.getCause(e));
            }
            return e;
        }
        else {
            if (!(e instanceof RemoteException)) {
                for (final Class<?> type : method.getExceptionTypes()) {
                    if (type.isAssignableFrom(e.getClass())) {
                        return e;
                    }
                }
                while (e.getCause() != null && !(e instanceof RuntimeException)) {
                    e = e.getCause();
                }
                return e;
            }
            if (!rmiRemote && this.interfaceType.isBusiness()) {
                return new EJBException(e.getMessage()).initCause(this.getCause(e));
            }
            if (this.interfaceType.isLocal()) {
                return new EJBException(e.getMessage()).initCause(this.getCause(e));
            }
            return e;
        }
    }
    
    private Method copyMethod(final Method method) throws Exception {
        final int parameterCount = method.getParameterTypes().length;
        Class[] types = new Class[1 + parameterCount];
        types[0] = method.getDeclaringClass();
        System.arraycopy(method.getParameterTypes(), 0, types, 1, parameterCount);
        types = (Class[])this.copyArgs(types);
        final Class targetClass = types[0];
        final Class[] targetParameters = new Class[parameterCount];
        System.arraycopy(types, 1, targetParameters, 0, parameterCount);
        return targetClass.getMethod(method.getName(), (Class[])targetParameters);
    }
    
    protected Throwable getCause(final Throwable e) {
        if (e != null && e.getCause() != null) {
            return e.getCause();
        }
        return e;
    }
    
    @Override
    public String toString() {
        String name = null;
        try {
            name = this.getProxyInfo().getInterface().getName();
        }
        catch (Exception ex) {}
        return "proxy=" + name + ";deployment=" + this.deploymentID + ";pk=" + this.primaryKey;
    }
    
    @Override
    public int hashCode() {
        if (this.primaryKey == null) {
            return this.deploymentID.hashCode();
        }
        return this.primaryKey.hashCode();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        if (!BaseEjbProxyHandler.class.isInstance(obj)) {
            final Class<?> aClass = obj.getClass();
            if (Proxy.isProxyClass(aClass)) {
                obj = Proxy.getInvocationHandler(obj);
            }
            else {
                if (!LocalBeanProxyFactory.isProxy(aClass)) {
                    return false;
                }
                obj = LocalBeanProxyFactory.getInvocationHandler(obj);
            }
        }
        return this.equalHandler(BaseEjbProxyHandler.class.cast(obj));
    }
    
    protected boolean equalHandler(final BaseEjbProxyHandler other) {
        if (this.primaryKey == null) {
            if (other.primaryKey != null) {
                return false;
            }
        }
        else if (!this.primaryKey.equals(other.primaryKey)) {
            return false;
        }
        if (this.deploymentID.equals(other.deploymentID) && this.getMainInterface().equals(other.getMainInterface())) {
            return true;
        }
        return false;
    }
    
    protected abstract Object _invoke(final Object p0, final Class p1, final Method p2, final Object[] p3) throws Throwable;
    
    protected Object[] copyArgs(final Object[] objects) throws IOException, ClassNotFoundException {
        if (objects == null) {
            return objects;
        }
        for (int i = 0; i < objects.length; ++i) {
            objects[i] = this.copyObj(objects[i]);
        }
        return objects;
    }
    
    protected <T> T copyObj(final T object) throws IOException, ClassNotFoundException {
        if (object == null) {
            return null;
        }
        final Class ooc = object.getClass();
        if (ooc == Integer.TYPE || ooc == String.class || ooc == Long.TYPE || ooc == Boolean.TYPE || ooc == Byte.TYPE || ooc == Float.TYPE || ooc == Double.TYPE || ooc == Short.TYPE || ooc == Long.class || ooc == Boolean.class || ooc == Byte.class || ooc == Character.class || ooc == Float.class || ooc == Double.class || ooc == Short.class || ooc == BigDecimal.class) {
            return object;
        }
        final ByteArrayOutputStream baos = new ByteArrayOutputStream(128);
        try {
            final ObjectOutputStream out = new ObjectOutputStream(baos);
            out.writeObject(object);
            out.close();
        }
        catch (NotSerializableException e) {
            throw (IOException)new NotSerializableException(e.getMessage() + " : The EJB specification restricts remote interfaces to only serializable data types.  This can be disabled for in-vm use with the " + "openejb.localcopy" + "=false system property.").initCause(e);
        }
        final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        final ObjectInputStream in = new EjbObjectInputStream(bais);
        final Object obj = in.readObject();
        return (T)obj;
    }
    
    public void invalidateReference() {
        this.container = null;
        this.setBeanContext(null);
        this.isInvalidReference = true;
    }
    
    protected void invalidateAllHandlers(final Object key) {
        final HashSet<BaseEjbProxyHandler> set = (HashSet<BaseEjbProxyHandler>)this.getLiveHandleRegistry().remove(key);
        if (set == null) {
            return;
        }
        final ReentrantLock l = this.lock;
        l.lock();
        try {
            for (final BaseEjbProxyHandler handler : set) {
                handler.invalidateReference();
            }
        }
        finally {
            l.unlock();
        }
    }
    
    protected abstract Object _writeReplace(final Object p0) throws ObjectStreamException;
    
    protected void registerHandler(final Object key, final BaseEjbProxyHandler handler) {
        Set set = (Set)this.getLiveHandleRegistry().get(key);
        if (set == null) {
            set = new HashSet();
            final Object existing = this.getLiveHandleRegistry().putIfAbsent(key, set);
            if (existing != null) {
                set = Set.class.cast(existing);
            }
        }
        final ReentrantLock l = this.lock;
        l.lock();
        try {
            set.add(handler);
        }
        finally {
            l.unlock();
        }
    }
    
    public abstract ProxyInfo getProxyInfo();
    
    public BeanContext getBeanContext() {
        final BeanContext beanContext = this.beanContextRef.get();
        if (beanContext == null || beanContext.isDestroyed()) {
            this.invalidateReference();
            throw new IllegalStateException("Bean '" + this.deploymentID + "' has been undeployed.");
        }
        return beanContext;
    }
    
    public void setBeanContext(final BeanContext beanContext) {
        this.beanContextRef = new WeakReference<BeanContext>(beanContext);
    }
    
    public ConcurrentMap getLiveHandleRegistry() {
        final BeanContext beanContext = this.getBeanContext();
        final ThreadContext tc = ThreadContext.getThreadContext();
        if (tc != null && tc.getBeanContext() != beanContext && tc.getCurrentOperation() == Operation.BUSINESS) {
            ProxyRegistry registry = tc.get(ProxyRegistry.class);
            if (registry == null) {
                registry = new ProxyRegistry();
                tc.set(ProxyRegistry.class, registry);
            }
            return registry.liveHandleRegistry;
        }
        final SystemInstance systemInstance = SystemInstance.get();
        final TransactionManager txMgr = (TransactionManager)systemInstance.getComponent((Class)TransactionManager.class);
        try {
            final Transaction tx = txMgr.getTransaction();
            if (tx != null && tx.getStatus() == 0) {
                final TransactionSynchronizationRegistry registry2 = (TransactionSynchronizationRegistry)systemInstance.getComponent((Class)TransactionSynchronizationRegistry.class);
                final String resourceKey = ProxyRegistry.class.getName();
                ConcurrentMap map = ConcurrentMap.class.cast(registry2.getResource((Object)resourceKey));
                if (map == null) {
                    map = new ConcurrentHashMap();
                    registry2.putResource((Object)resourceKey, (Object)map);
                    try {
                        final ConcurrentMap tmp = map;
                        tx.registerSynchronization((Synchronization)new Synchronization() {
                            public void beforeCompletion() {
                            }
                            
                            public void afterCompletion(final int status) {
                                tmp.clear();
                            }
                        });
                    }
                    catch (RollbackException ex) {}
                }
                return map;
            }
        }
        catch (SystemException ex2) {}
        ProxyRegistry proxyRegistry = beanContext.get(ProxyRegistry.class);
        if (proxyRegistry == null) {
            proxyRegistry = new ProxyRegistry();
            beanContext.set(ProxyRegistry.class, proxyRegistry);
        }
        return proxyRegistry.liveHandleRegistry;
    }
    
    private void writeObject(final ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
        out.writeObject(this.getInterfaces());
        out.writeObject(this.getMainInterface());
    }
    
    private void readObject(final ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        this.setBeanContext(containerSystem.getBeanContext(this.deploymentID));
        this.container = (RpcContainer)this.getBeanContext().getContainer();
        if (IntraVmCopyMonitor.isCrossClassLoaderOperation()) {
            this.setDoCrossClassLoaderCopy(true);
        }
        this.setInterfaces((List<Class>)in.readObject());
        this.setMainInterface((Class)in.readObject());
    }
    
    static {
        REMOTE_COPY_ENABLED = parseRemoteCopySetting();
        ThreadContext.addThreadContextListener(new ThreadContextListener() {
            @Override
            public void contextEntered(final ThreadContext oldContext, final ThreadContext newContext) {
            }
            
            @Override
            public void contextExited(final ThreadContext exitedContext, final ThreadContext reenteredContext) {
                if (exitedContext != null) {
                    final ProxyRegistry proxyRegistry = exitedContext.get(ProxyRegistry.class);
                    if (proxyRegistry != null) {
                        proxyRegistry.liveHandleRegistry.clear();
                    }
                }
            }
        });
    }
    
    private static class ProxyRegistry
    {
        protected final ConcurrentMap liveHandleRegistry;
        
        private ProxyRegistry() {
            this.liveHandleRegistry = new ConcurrentHashMap();
        }
    }
}
