// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.util.Base64;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class StaticDESPasswordCipher implements PasswordCipher
{
    private static final byte[] _3desData;
    private static final SecretKeySpec KEY;
    private static final String TRANSFORMATION = "DESede";
    
    @Override
    public char[] encrypt(final String plainPassword) {
        if (null == plainPassword || plainPassword.length() == 0) {
            throw new IllegalArgumentException("plainPassword cannot be null nor empty.");
        }
        final byte[] plaintext = plainPassword.getBytes();
        try {
            final Cipher cipher = Cipher.getInstance("DESede");
            cipher.init(1, StaticDESPasswordCipher.KEY);
            final byte[] cipherText = cipher.doFinal(plaintext);
            return new String(Base64.encodeBase64(cipherText)).toCharArray();
        }
        catch (Exception e) {
            throw new OpenEJBRuntimeException(e);
        }
    }
    
    @Override
    public String decrypt(final char[] encodedPassword) {
        if (null == encodedPassword || encodedPassword.length == 0) {
            throw new IllegalArgumentException("encodedPassword cannot be null nor empty.");
        }
        try {
            final byte[] cipherText = Base64.decodeBase64(String.valueOf(encodedPassword).getBytes());
            final Cipher cipher = Cipher.getInstance("DESede");
            cipher.init(2, StaticDESPasswordCipher.KEY);
            return new String(cipher.doFinal(cipherText));
        }
        catch (Exception e) {
            throw new OpenEJBRuntimeException(e);
        }
    }
    
    static {
        _3desData = new byte[] { 118, 111, -70, 57, 49, 47, 13, 74, -93, -112, 85, -2, 85, 101, 97, 19, 52, -126, 18, 23, -84, 119, 57, 25 };
        KEY = new SecretKeySpec(StaticDESPasswordCipher._3desData, "DESede");
    }
}
