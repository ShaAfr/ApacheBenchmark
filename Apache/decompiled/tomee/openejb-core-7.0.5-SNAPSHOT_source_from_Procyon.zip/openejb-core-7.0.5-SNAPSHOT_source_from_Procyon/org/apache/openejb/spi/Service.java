// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.spi;

import java.util.Properties;

public interface Service
{
    void init(final Properties p0) throws Exception;
}
