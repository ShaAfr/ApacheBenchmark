// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class QueryInfo extends InfoObject
{
    public String description;
    public MethodInfo method;
    public String queryStatement;
    public boolean remoteResultType;
}
