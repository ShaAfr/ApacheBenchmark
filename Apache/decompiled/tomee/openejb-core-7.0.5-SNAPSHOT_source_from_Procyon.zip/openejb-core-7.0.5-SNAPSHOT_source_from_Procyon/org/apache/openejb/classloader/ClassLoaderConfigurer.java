// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.classloader;

import java.util.Iterator;
import java.util.Arrays;
import java.util.Collection;
import java.net.URL;

public interface ClassLoaderConfigurer
{
    URL[] additionalURLs();
    
    boolean accept(final URL p0);
    
    public static final class Helper
    {
        private Helper() {
        }
        
        public static void configure(final Collection<URL> urls, final ClassLoaderConfigurer configurer) {
            final Iterator<URL> it = urls.iterator();
            while (it.hasNext()) {
                if (!configurer.accept(it.next())) {
                    it.remove();
                }
            }
            urls.addAll(Arrays.asList(configurer.additionalURLs()));
        }
    }
}
