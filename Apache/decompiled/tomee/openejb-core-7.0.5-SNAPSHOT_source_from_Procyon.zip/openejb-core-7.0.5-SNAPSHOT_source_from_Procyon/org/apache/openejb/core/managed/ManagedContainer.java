// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.managed;

import org.apache.openejb.core.transaction.TransactionPolicy.TransactionSynchronization;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.util.LogCategory;
import javax.persistence.EntityManager;
import javax.persistence.SynchronizationType;
import java.util.Collection;
import org.apache.openejb.core.ExceptionType;
import javax.ejb.EJBAccessException;
import org.apache.openejb.core.transaction.JtaTransactionPolicy;
import javax.transaction.Transaction;
import java.rmi.RemoteException;
import java.rmi.NoSuchObjectException;
import org.apache.openejb.InvalidateReferenceException;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.core.transaction.BeanTransactionPolicy;
import org.apache.openejb.ApplicationException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import java.rmi.dgc.VMID;
import org.apache.openejb.core.InstanceContext;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.core.interceptor.InterceptorStack;
import org.apache.openejb.core.interceptor.InterceptorData;
import java.util.ArrayList;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import org.apache.openejb.core.BaseContext;
import org.apache.openejb.core.Operation;
import org.apache.openejb.persistence.EntityManagerAlreadyRegisteredException;
import javax.ejb.EJBException;
import javax.persistence.EntityManagerFactory;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.ProxyInfo;
import org.apache.openejb.InterfaceType;
import javax.naming.Context;
import javax.ejb.EJBContext;
import javax.naming.NamingException;
import org.apache.openejb.monitoring.ManagedMBean;
import org.apache.openejb.monitoring.ObjectNameBuilder;
import org.apache.openejb.monitoring.StatsInterceptor;
import org.apache.openejb.util.Index;
import javax.management.MBeanServer;
import org.apache.openejb.Container;
import javax.management.ObjectName;
import org.apache.openejb.monitoring.LocalMBeanServer;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.ContainerType;
import java.util.Iterator;
import java.util.List;
import java.lang.reflect.Method;
import org.apache.openejb.SystemException;
import javax.transaction.UserTransaction;
import org.apache.openejb.core.transaction.EjbUserTransaction;
import org.apache.openejb.util.Duration;
import java.util.HashMap;
import org.apache.openejb.loader.SystemInstance;
import javax.ejb.SessionContext;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.openejb.BeanContext;
import java.util.Map;
import org.apache.openejb.persistence.JtaEntityManagerRegistry;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.Logger;
import org.apache.openejb.RpcContainer;

public class ManagedContainer implements RpcContainer
{
    private static final Logger logger;
    private final Object containerID;
    private final SecurityService securityService;
    protected final JtaEntityManagerRegistry entityManagerRegistry;
    protected final Map<Object, BeanContext> deploymentsById;
    protected final Cache<Object, Instance> cache;
    private final ConcurrentHashMap<Object, Instance> checkedOutInstances;
    private final SessionContext sessionContext;
    
    public ManagedContainer(final Object id, final SecurityService securityService) throws SystemException {
        this.entityManagerRegistry = (JtaEntityManagerRegistry)SystemInstance.get().getComponent((Class)JtaEntityManagerRegistry.class);
        this.deploymentsById = new HashMap<Object, BeanContext>();
        this.checkedOutInstances = new ConcurrentHashMap<Object, Instance>();
        this.cache = new SimpleCache<Object, Instance>(null, new SimplePassivater(), 1000, 50, new Duration("1 hour"));
        this.containerID = id;
        this.securityService = securityService;
        this.cache.setListener(new StatefulCacheListener());
        this.sessionContext = (SessionContext)new ManagedContext(securityService, (UserTransaction)new ManagedUserTransaction((UserTransaction)new EjbUserTransaction(), this.entityManagerRegistry));
    }
    
    private Map<Method, MethodType> getLifecycleMethodsOfInterface(final BeanContext beanContext) {
        final Map<Method, MethodType> methods = new HashMap<Method, MethodType>();
        try {
            methods.put(BeanContext.Removable.class.getDeclaredMethod("$$remove", (Class<?>[])new Class[0]), MethodType.REMOVE);
        }
        catch (NoSuchMethodException e) {
            throw new IllegalStateException("Internal code change: BeanContext.Removable.$$remove() method was deleted", e);
        }
        final List<Method> removeMethods = beanContext.getRemoveMethods();
        for (final Method removeMethod : removeMethods) {
            methods.put(removeMethod, MethodType.REMOVE);
            for (final Class businessLocal : beanContext.getBusinessLocalInterfaces()) {
                try {
                    final Method method = businessLocal.getMethod(removeMethod.getName(), (Class[])new Class[0]);
                    methods.put(method, MethodType.REMOVE);
                }
                catch (NoSuchMethodException ex) {}
            }
            for (final Class businessRemote : beanContext.getBusinessRemoteInterfaces()) {
                try {
                    final Method method = businessRemote.getMethod(removeMethod.getName(), (Class[])new Class[0]);
                    methods.put(method, MethodType.REMOVE);
                }
                catch (NoSuchMethodException ex2) {}
            }
        }
        final Class legacyRemote = beanContext.getRemoteInterface();
        if (legacyRemote != null) {
            try {
                final Method method2 = legacyRemote.getMethod("remove", (Class[])new Class[0]);
                methods.put(method2, MethodType.REMOVE);
            }
            catch (NoSuchMethodException ex3) {}
        }
        final Class legacyLocal = beanContext.getLocalInterface();
        if (legacyLocal != null) {
            try {
                final Method method3 = legacyLocal.getMethod("remove", (Class[])new Class[0]);
                methods.put(method3, MethodType.REMOVE);
            }
            catch (NoSuchMethodException ex4) {}
        }
        final Class businessLocalHomeInterface = beanContext.getBusinessLocalInterface();
        if (businessLocalHomeInterface != null) {
            for (final Method method4 : BeanContext.BusinessLocalHome.class.getMethods()) {
                if (method4.getName().startsWith("create")) {
                    methods.put(method4, MethodType.CREATE);
                }
                else if (method4.getName().equals("remove")) {
                    methods.put(method4, MethodType.REMOVE);
                }
            }
        }
        final Class businessLocalBeanHomeInterface = beanContext.getBusinessLocalBeanInterface();
        if (businessLocalBeanHomeInterface != null) {
            for (final Method method5 : BeanContext.BusinessLocalBeanHome.class.getMethods()) {
                if (method5.getName().startsWith("create")) {
                    methods.put(method5, MethodType.CREATE);
                }
                else if (method5.getName().equals("remove")) {
                    methods.put(method5, MethodType.REMOVE);
                }
            }
        }
        final Class businessRemoteHomeInterface = beanContext.getBusinessRemoteInterface();
        if (businessRemoteHomeInterface != null) {
            for (final Method method6 : BeanContext.BusinessRemoteHome.class.getMethods()) {
                if (method6.getName().startsWith("create")) {
                    methods.put(method6, MethodType.CREATE);
                }
                else if (method6.getName().equals("remove")) {
                    methods.put(method6, MethodType.REMOVE);
                }
            }
        }
        final Class homeInterface = beanContext.getHomeInterface();
        if (homeInterface != null) {
            for (final Method method7 : homeInterface.getMethods()) {
                if (method7.getName().startsWith("create")) {
                    methods.put(method7, MethodType.CREATE);
                }
                else if (method7.getName().equals("remove")) {
                    methods.put(method7, MethodType.REMOVE);
                }
            }
        }
        final Class localHomeInterface = beanContext.getLocalHomeInterface();
        if (localHomeInterface != null) {
            for (final Method method8 : localHomeInterface.getMethods()) {
                if (method8.getName().startsWith("create")) {
                    methods.put(method8, MethodType.CREATE);
                }
                else if (method8.getName().equals("remove")) {
                    methods.put(method8, MethodType.REMOVE);
                }
            }
        }
        return methods;
    }
    
    @Override
    public ContainerType getContainerType() {
        return ContainerType.STATEFUL;
    }
    
    @Override
    public Object getContainerID() {
        return this.containerID;
    }
    
    @Override
    public synchronized BeanContext[] getBeanContexts() {
        return this.deploymentsById.values().toArray(new BeanContext[this.deploymentsById.size()]);
    }
    
    @Override
    public synchronized BeanContext getBeanContext(final Object deploymentID) {
        return this.deploymentsById.get(deploymentID);
    }
    
    @Override
    public void start(final BeanContext beanContext) throws OpenEJBException {
    }
    
    @Override
    public void stop(final BeanContext beanContext) throws OpenEJBException {
        beanContext.stop();
    }
    
    @Override
    public synchronized void undeploy(final BeanContext bean) throws OpenEJBException {
        final Data data = (Data)bean.getContainerData();
        if (data != null) {
            final MBeanServer server = LocalMBeanServer.get();
            for (final ObjectName objectName : data.jmxNames) {
                try {
                    server.unregisterMBean(objectName);
                }
                catch (Exception e) {
                    ManagedContainer.logger.error("Unable to unregister MBean " + objectName);
                }
            }
        }
        this.deploymentsById.remove(bean.getDeploymentID());
        bean.setContainer(null);
        bean.setContainerData(null);
        this.cache.removeAll(new Cache.CacheFilter<Instance>() {
            @Override
            public boolean matches(final Instance instance) {
                return bean == instance.beanContext;
            }
        });
    }
    
    @Override
    public synchronized void deploy(final BeanContext beanContext) throws OpenEJBException {
        final Map<Method, MethodType> methods = this.getLifecycleMethodsOfInterface(beanContext);
        this.deploymentsById.put(beanContext.getDeploymentID(), beanContext);
        beanContext.setContainer(this);
        final Data data = new Data(new Index((Map<K, V>)methods));
        beanContext.setContainerData(data);
        if (StatsInterceptor.isStatsActivated()) {
            final StatsInterceptor stats = new StatsInterceptor(beanContext.getBeanClass());
            beanContext.addFirstSystemInterceptor(stats);
            final MBeanServer server = LocalMBeanServer.get();
            final ObjectNameBuilder jmxName = new ObjectNameBuilder("openejb.management");
            jmxName.set("J2EEServer", "openejb");
            jmxName.set("J2EEApplication", null);
            jmxName.set("EJBModule", beanContext.getModuleID());
            jmxName.set("StatelessSessionBean", beanContext.getEjbName());
            jmxName.set("j2eeType", "");
            jmxName.set("name", beanContext.getEjbName());
            try {
                final ObjectName objectName = jmxName.set("j2eeType", "Invocations").build();
                if (server.isRegistered(objectName)) {
                    server.unregisterMBean(objectName);
                }
                server.registerMBean(new ManagedMBean(stats), objectName);
                data.jmxNames.add(objectName);
            }
            catch (Exception e) {
                ManagedContainer.logger.error("Unable to register MBean ", e);
            }
        }
        try {
            final Context context = beanContext.getJndiEnc();
            context.bind("comp/EJBContext", this.sessionContext);
        }
        catch (NamingException e2) {
            throw new OpenEJBException("Failed to bind EJBContext", e2);
        }
        beanContext.set((Class<Object>)EJBContext.class, this.sessionContext);
    }
    
    @Override
    public Object invoke(final Object deployID, InterfaceType type, final Class callInterface, final Method callMethod, final Object[] args, final Object primKey) throws OpenEJBException {
        final BeanContext beanContext = this.getBeanContext(deployID);
        if (beanContext == null) {
            throw new OpenEJBException("Deployment does not exist in this container. Deployment(id='" + deployID + "'), Container(id='" + this.containerID + "')");
        }
        if (type == null) {
            type = beanContext.getInterfaceType(callInterface);
        }
        final Data data = (Data)beanContext.getContainerData();
        MethodType methodType = data.getMethodIndex().get(callMethod);
        methodType = ((methodType != null) ? methodType : MethodType.BUSINESS);
        switch (methodType) {
            case CREATE: {
                return this.createEJBObject(beanContext, callMethod, args, type);
            }
            case REMOVE: {
                return this.removeEJBObject(beanContext, primKey, callInterface, callMethod, args, type);
            }
            default: {
                return this.businessMethod(beanContext, primKey, callInterface, callMethod, args, type);
            }
        }
    }
    
    protected ProxyInfo createEJBObject(final BeanContext beanContext, final Method callMethod, final Object[] args, final InterfaceType interfaceType) throws OpenEJBException {
        final Object primaryKey = this.newPrimaryKey();
        final ThreadContext createContext = new ThreadContext(beanContext, primaryKey);
        final ThreadContext oldCallContext = ThreadContext.enter(createContext);
        try {
            this.checkAuthorization(callMethod, interfaceType);
            final Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> entityManagers = this.createEntityManagers(beanContext);
            if (entityManagers != null) {
                try {
                    this.entityManagerRegistry.addEntityManagers((String)beanContext.getDeploymentID(), primaryKey, entityManagers);
                }
                catch (EntityManagerAlreadyRegisteredException e) {
                    throw new EJBException((Exception)e);
                }
            }
            createContext.setCurrentOperation(Operation.CREATE);
            createContext.setCurrentAllowedStates(null);
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(createContext.getBeanContext().getTransactionType(callMethod, interfaceType), createContext);
            Instance instance = null;
            try {
                try {
                    final InstanceContext context = beanContext.newInstance();
                    instance = new Instance(beanContext, primaryKey, context.getBean(), context.getInterceptors(), context.getCreationalContext(), entityManagers);
                }
                catch (Throwable throwable) {
                    final ThreadContext callContext = ThreadContext.getThreadContext();
                    EjbTransactionUtil.handleSystemException(callContext.getTransactionPolicy(), throwable, callContext);
                    throw new IllegalStateException(throwable);
                }
                this.cache.add(primaryKey, instance);
                this.checkedOutInstances.put(primaryKey, instance);
                this.registerSessionSynchronization(instance, createContext);
                if (!callMethod.getDeclaringClass().equals(BeanContext.BusinessLocalHome.class) && !callMethod.getDeclaringClass().equals(BeanContext.BusinessRemoteHome.class) && !callMethod.getDeclaringClass().equals(BeanContext.BusinessLocalBeanHome.class)) {
                    final Method createOrInit = beanContext.getMatchingBeanMethod(callMethod);
                    createContext.set(Method.class, createOrInit);
                    final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, createOrInit, Operation.CREATE, new ArrayList<InterceptorData>(), new HashMap<String, Object>());
                    if (args == null) {
                        interceptorStack.invoke(new Object[0]);
                    }
                    else {
                        interceptorStack.invoke(args);
                    }
                }
            }
            catch (Throwable e2) {
                this.handleException(createContext, txPolicy, e2);
            }
            finally {
                this.afterInvoke(createContext, txPolicy, instance);
            }
            return new ProxyInfo(beanContext, primaryKey);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    protected Object newPrimaryKey() {
        return new VMID();
    }
    
    protected Object removeEJBObject(final BeanContext beanContext, final Object primKey, final Class callInterface, final Method callMethod, Object[] args, final InterfaceType interfaceType) throws OpenEJBException {
        if (primKey == null) {
            throw new NullPointerException("primKey is null");
        }
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            final boolean internalRemove = BeanContext.Removable.class == callMethod.getDeclaringClass();
            if (!internalRemove) {
                this.checkAuthorization(callMethod, interfaceType);
            }
            if (interfaceType.isComponent()) {
                final Instance instance = this.checkedOutInstances.get(primKey);
                if (instance != null && instance.bean instanceof SessionBean) {
                    throw new ApplicationException((Exception)new RemoveException("A stateful EJB enrolled in a transaction can not be removed"));
                }
            }
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(callContext.getBeanContext().getTransactionType(callMethod, interfaceType), callContext);
            Object returnValue = null;
            boolean retain = false;
            Instance instance2 = null;
            Method runMethod = null;
            try {
                instance2 = this.obtainInstance(primKey, callContext);
                if (txPolicy instanceof BeanTransactionPolicy) {
                    final BeanTransactionPolicy.SuspendedTransaction suspendedTransaction = instance2.getBeanTransaction();
                    if (suspendedTransaction != null) {
                        instance2.setBeanTransaction(null);
                        final BeanTransactionPolicy beanTxEnv = (BeanTransactionPolicy)txPolicy;
                        beanTxEnv.resumeUserTransaction(suspendedTransaction);
                    }
                }
                if (!internalRemove) {
                    this.registerEntityManagers(instance2, callContext);
                    this.registerSessionSynchronization(instance2, callContext);
                    callContext.setCurrentOperation(Operation.REMOVE);
                    callContext.setCurrentAllowedStates(null);
                    callContext.setInvokedInterface(callInterface);
                    runMethod = beanContext.getMatchingBeanMethod(callMethod);
                    callContext.set(Method.class, runMethod);
                    final Class<?> declaringClass = callMethod.getDeclaringClass();
                    if (declaringClass.equals(EJBHome.class) || declaringClass.equals(EJBLocalHome.class)) {
                        args = new Object[0];
                    }
                    final List<InterceptorData> interceptors = beanContext.getMethodInterceptors(runMethod);
                    final InterceptorStack interceptorStack = new InterceptorStack(instance2.bean, runMethod, Operation.REMOVE, interceptors, instance2.interceptors);
                    if (args == null) {
                        returnValue = interceptorStack.invoke(new Object[0]);
                    }
                    else {
                        returnValue = interceptorStack.invoke(args);
                    }
                }
            }
            catch (InvalidateReferenceException e) {
                throw new ApplicationException(e.getRootCause());
            }
            catch (Throwable e2) {
                if (interfaceType.isBusiness()) {
                    retain = beanContext.retainIfExeption(runMethod);
                    this.handleException(callContext, txPolicy, e2);
                }
                else {
                    try {
                        this.handleException(callContext, txPolicy, e2);
                    }
                    catch (ApplicationException ex) {}
                }
            }
            finally {
                if (!retain) {
                    try {
                        callContext.setCurrentOperation(Operation.PRE_DESTROY);
                        final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                        final InterceptorStack interceptorStack2 = new InterceptorStack(instance2.bean, null, Operation.PRE_DESTROY, callbackInterceptors, instance2.interceptors);
                        interceptorStack2.invoke(new Object[0]);
                    }
                    catch (Throwable callbackException) {
                        final String logMessage = "An unexpected exception occured while invoking the preDestroy method on the removed Stateful SessionBean instance; " + callbackException.getClass().getName() + " " + callbackException.getMessage();
                        ManagedContainer.logger.error(logMessage);
                        callContext.setCurrentOperation(Operation.REMOVE);
                    }
                    finally {
                        callContext.setCurrentOperation(Operation.REMOVE);
                    }
                    this.discardInstance(callContext);
                }
                this.afterInvoke(callContext, txPolicy, instance2);
            }
            return returnValue;
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    protected Object businessMethod(final BeanContext beanContext, final Object primKey, final Class callInterface, final Method callMethod, final Object[] args, final InterfaceType interfaceType) throws OpenEJBException {
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            this.checkAuthorization(callMethod, interfaceType);
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(callContext.getBeanContext().getTransactionType(callMethod, interfaceType), callContext);
            Object returnValue = null;
            Instance instance = null;
            try {
                instance = this.obtainInstance(primKey, callContext);
                if (txPolicy instanceof BeanTransactionPolicy) {
                    final BeanTransactionPolicy.SuspendedTransaction suspendedTransaction = instance.getBeanTransaction();
                    if (suspendedTransaction != null) {
                        instance.setBeanTransaction(null);
                        final BeanTransactionPolicy beanTxEnv = (BeanTransactionPolicy)txPolicy;
                        beanTxEnv.resumeUserTransaction(suspendedTransaction);
                    }
                }
                this.registerEntityManagers(instance, callContext);
                this.registerSessionSynchronization(instance, callContext);
                callContext.setCurrentOperation(Operation.BUSINESS);
                callContext.setCurrentAllowedStates(null);
                callContext.setInvokedInterface(callInterface);
                final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
                callContext.set(Method.class, runMethod);
                final List<InterceptorData> interceptors = beanContext.getMethodInterceptors(runMethod);
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, runMethod, Operation.BUSINESS, interceptors, instance.interceptors);
                returnValue = interceptorStack.invoke(args);
            }
            catch (Throwable e) {
                this.handleException(callContext, txPolicy, e);
            }
            finally {
                this.afterInvoke(callContext, txPolicy, instance);
            }
            return returnValue;
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private Instance obtainInstance(final Object primaryKey, final ThreadContext callContext) throws OpenEJBException {
        if (primaryKey == null) {
            throw new SystemException(new NullPointerException("Cannot obtain an instance of the stateful session bean with a null session id"));
        }
        final Transaction currentTransaction = this.getTransaction(callContext);
        Instance instance = this.checkedOutInstances.get(primaryKey);
        if (instance == null) {
            try {
                instance = this.cache.checkOut(primaryKey);
            }
            catch (OpenEJBException e) {
                throw e;
            }
            catch (Exception e2) {
                throw new SystemException("Unexpected load exception", e2);
            }
            if (instance == null) {
                throw new InvalidateReferenceException(new NoSuchObjectException("Not Found"));
            }
            this.checkedOutInstances.put(primaryKey, instance);
        }
        synchronized (this) {
            if (instance.isInUse()) {
                final Operation currentOperation = callContext.getCurrentOperation();
                if (currentOperation != Operation.AFTER_COMPLETION && currentOperation != Operation.BEFORE_COMPLETION) {
                    throw new ApplicationException(new RemoteException("Concurrent calls not allowed."));
                }
            }
            if (instance.getTransaction() != null) {
                if (!instance.getTransaction().equals(currentTransaction) && !instance.getLock().tryLock()) {
                    throw new ApplicationException(new RemoteException("Instance is in a transaction and cannot be invoked outside that transaction.  See EJB 3.0 Section 4.4.4"));
                }
            }
            else {
                instance.setTransaction(currentTransaction);
            }
            instance.setInUse(true);
            return instance;
        }
    }
    
    private Transaction getTransaction(final ThreadContext callContext) {
        final TransactionPolicy policy = callContext.getTransactionPolicy();
        Transaction currentTransaction = null;
        if (policy instanceof JtaTransactionPolicy) {
            final JtaTransactionPolicy jtaPolicy = (JtaTransactionPolicy)policy;
            currentTransaction = jtaPolicy.getCurrentTransaction();
        }
        return currentTransaction;
    }
    
    private void releaseInstance(final Instance instance) {
        if (instance.beanContext.isDestroyed()) {
            return;
        }
        if (instance.getBeanTransaction() != null) {
            throw new IllegalStateException("Instance has an active bean-managed transaction");
        }
        instance.setInUse(false);
        if (instance.getTransaction() == null) {
            this.cache.checkIn(instance.primaryKey);
            this.checkedOutInstances.remove(instance.primaryKey);
        }
    }
    
    private void discardInstance(final ThreadContext threadContext) {
        final Object primaryKey = threadContext.getPrimaryKey();
        if (primaryKey == null) {
            return;
        }
        final Instance instance = this.checkedOutInstances.remove(primaryKey);
        this.cache.remove(primaryKey);
        if (instance.creationalContext != null) {
            instance.creationalContext.release();
        }
    }
    
    private void checkAuthorization(final Method callMethod, final InterfaceType interfaceType) throws ApplicationException {
        final boolean authorized = this.securityService.isCallerAuthorized(callMethod, interfaceType);
        if (!authorized) {
            throw new ApplicationException((Exception)new EJBAccessException("Unauthorized Access by Principal Denied"));
        }
    }
    
    private void handleException(final ThreadContext callContext, final TransactionPolicy txPolicy, final Throwable e) throws ApplicationException {
        if (e instanceof ApplicationException) {
            throw (ApplicationException)e;
        }
        final ExceptionType type = callContext.getBeanContext().getExceptionType(e);
        if (type == ExceptionType.SYSTEM) {
            this.discardInstance(callContext);
            EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
        }
        else {
            EjbTransactionUtil.handleApplicationException(txPolicy, e, type == ExceptionType.APPLICATION_ROLLBACK);
        }
    }
    
    private void afterInvoke(final ThreadContext callContext, final TransactionPolicy txPolicy, final Instance instance) throws OpenEJBException {
        try {
            this.unregisterEntityManagers(instance, callContext);
            if (instance != null && txPolicy instanceof BeanTransactionPolicy) {
                BeanTransactionPolicy.SuspendedTransaction suspendedTransaction = null;
                try {
                    final BeanTransactionPolicy beanTxEnv = (BeanTransactionPolicy)txPolicy;
                    suspendedTransaction = beanTxEnv.suspendUserTransaction();
                }
                catch (SystemException e) {
                    EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
                }
                finally {
                    instance.setBeanTransaction(suspendedTransaction);
                }
            }
        }
        finally {
            if (instance != null) {
                instance.setInUse(false);
            }
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
    }
    
    private Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> createEntityManagers(final BeanContext beanContext) {
        final Index<EntityManagerFactory, BeanContext.EntityManagerConfiguration> factories = beanContext.getExtendedEntityManagerFactories();
        Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> entityManagers = null;
        if (factories != null && factories.size() > 0) {
            entityManagers = new Index<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker>(new ArrayList<EntityManagerFactory>((Collection<? extends EntityManagerFactory>)factories.keySet()));
            for (final Map.Entry<EntityManagerFactory, BeanContext.EntityManagerConfiguration> entry : factories.entrySet()) {
                final EntityManagerFactory entityManagerFactory = entry.getKey();
                JtaEntityManagerRegistry.EntityManagerTracker entityManagerTracker = this.entityManagerRegistry.getInheritedEntityManager(entityManagerFactory);
                if (entityManagerTracker == null) {
                    final SynchronizationType synchronizationType = entry.getValue().getSynchronizationType();
                    final Map properties = entry.getValue().getProperties();
                    EntityManager entityManager;
                    if (synchronizationType != null) {
                        if (properties != null) {
                            entityManager = entityManagerFactory.createEntityManager(synchronizationType, properties);
                        }
                        else {
                            entityManager = entityManagerFactory.createEntityManager(synchronizationType);
                        }
                    }
                    else if (properties != null) {
                        entityManager = entityManagerFactory.createEntityManager(properties);
                    }
                    else {
                        entityManager = entityManagerFactory.createEntityManager();
                    }
                    entityManagerTracker = new JtaEntityManagerRegistry.EntityManagerTracker(entityManager, synchronizationType != SynchronizationType.UNSYNCHRONIZED);
                }
                else {
                    entityManagerTracker.incCounter();
                }
                entityManagers.put(entityManagerFactory, entityManagerTracker);
            }
        }
        return entityManagers;
    }
    
    private void registerEntityManagers(final Instance instance, final ThreadContext callContext) throws OpenEJBException {
        if (this.entityManagerRegistry == null) {
            return;
        }
        final BeanContext beanContext = callContext.getBeanContext();
        final Index<EntityManagerFactory, BeanContext.EntityManagerConfiguration> factories = beanContext.getExtendedEntityManagerFactories();
        if (factories == null) {
            return;
        }
        final Map<EntityManagerFactory, JtaEntityManagerRegistry.EntityManagerTracker> entityManagers = instance.getEntityManagers(factories);
        if (entityManagers == null) {
            return;
        }
        try {
            this.entityManagerRegistry.addEntityManagers((String)beanContext.getDeploymentID(), instance.primaryKey, entityManagers);
        }
        catch (EntityManagerAlreadyRegisteredException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    private void unregisterEntityManagers(final Instance instance, final ThreadContext callContext) {
        if (this.entityManagerRegistry == null) {
            return;
        }
        if (instance == null) {
            return;
        }
        final BeanContext beanContext = callContext.getBeanContext();
        this.entityManagerRegistry.removeEntityManagers((String)beanContext.getDeploymentID(), instance.primaryKey);
    }
    
    private void registerSessionSynchronization(final Instance instance, final ThreadContext callContext) {
        final TransactionPolicy txPolicy = callContext.getTransactionPolicy();
        if (txPolicy == null) {
            throw new IllegalStateException("ThreadContext does not contain a TransactionEnvironment");
        }
        SessionSynchronizationCoordinator coordinator = (SessionSynchronizationCoordinator)txPolicy.getResource(SessionSynchronizationCoordinator.class);
        if (coordinator == null) {
            coordinator = new SessionSynchronizationCoordinator(txPolicy);
            txPolicy.registerSynchronization(coordinator);
            txPolicy.putResource(SessionSynchronizationCoordinator.class, coordinator);
        }
        final boolean synchronize = callContext.getCurrentOperation() != Operation.CREATE && callContext.getBeanContext().isSessionSynchronized() && txPolicy.isTransactionActive();
        coordinator.registerSessionSynchronization(instance, callContext.getBeanContext(), callContext.getPrimaryKey(), synchronize);
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
    
    public enum MethodType
    {
        CREATE, 
        REMOVE, 
        BUSINESS;
    }
    
    private final class SessionSynchronizationCoordinator implements TransactionPolicy.TransactionSynchronization
    {
        private final Map<Object, Synchronization> registry;
        private final TransactionPolicy txPolicy;
        
        private SessionSynchronizationCoordinator(final TransactionPolicy txPolicy) {
            this.registry = new HashMap<Object, Synchronization>();
            this.txPolicy = txPolicy;
        }
        
        private void registerSessionSynchronization(final Instance instance, final BeanContext beanContext, final Object primaryKey, final boolean synchronize) {
            Synchronization synchronization = this.registry.get(primaryKey);
            if (synchronization == null) {
                synchronization = new Synchronization(instance);
                this.registry.put(primaryKey, synchronization);
            }
            final boolean wasSynchronized = synchronization.setCallSessionSynchronization(synchronize);
            if (wasSynchronized || !synchronize) {
                return;
            }
            final ThreadContext callContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.AFTER_BEGIN);
            callContext.setCurrentAllowedStates(null);
            final ThreadContext oldCallContext = ThreadContext.enter(callContext);
            try {
                final List<InterceptorData> interceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, null, Operation.AFTER_BEGIN, interceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Exception e) {
                final String message = "An unexpected system exception occured while invoking the afterBegin method on the SessionSynchronization object";
                ManagedContainer.logger.error("An unexpected system exception occured while invoking the afterBegin method on the SessionSynchronization object", e);
                throw new OpenEJBRuntimeException("An unexpected system exception occured while invoking the afterBegin method on the SessionSynchronization object", e);
            }
            finally {
                ThreadContext.exit(oldCallContext);
            }
        }
        
        @Override
        public void beforeCompletion() {
            for (final Synchronization synchronization : this.registry.values()) {
                final Instance instance = synchronization.instance;
                if (this.txPolicy.isRollbackOnly()) {
                    return;
                }
                if (!synchronization.isCallSessionSynchronization()) {
                    continue;
                }
                final ThreadContext callContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.BEFORE_COMPLETION);
                callContext.setCurrentAllowedStates(null);
                final ThreadContext oldCallContext = ThreadContext.enter(callContext);
                try {
                    instance.setInUse(true);
                    final BeanContext beanContext = instance.beanContext;
                    final List<InterceptorData> interceptors = beanContext.getCallbackInterceptors();
                    final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, null, Operation.BEFORE_COMPLETION, interceptors, instance.interceptors);
                    interceptorStack.invoke(new Object[0]);
                    instance.setInUse(false);
                }
                catch (InvalidateReferenceException ex) {}
                catch (Exception e) {
                    final String message = "An unexpected system exception occured while invoking the beforeCompletion method on the SessionSynchronization object";
                    ManagedContainer.logger.error("An unexpected system exception occured while invoking the beforeCompletion method on the SessionSynchronization object", e);
                    this.txPolicy.setRollbackOnly(e);
                    ManagedContainer.this.discardInstance(callContext);
                    throw new OpenEJBRuntimeException("An unexpected system exception occured while invoking the beforeCompletion method on the SessionSynchronization object", e);
                }
                finally {
                    ThreadContext.exit(oldCallContext);
                }
            }
        }
        
        @Override
        public void afterCompletion(final Status status) {
            Throwable firstException = null;
            for (final Synchronization synchronization : this.registry.values()) {
                final Instance instance = synchronization.instance;
                final ThreadContext callContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.AFTER_COMPLETION);
                callContext.setCurrentAllowedStates(null);
                final ThreadContext oldCallContext = ThreadContext.enter(callContext);
                try {
                    instance.setInUse(true);
                    if (synchronization.isCallSessionSynchronization()) {
                        final BeanContext beanContext = instance.beanContext;
                        final List<InterceptorData> interceptors = beanContext.getCallbackInterceptors();
                        final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, null, Operation.AFTER_COMPLETION, interceptors, instance.interceptors);
                        interceptorStack.invoke(status == Status.COMMITTED);
                    }
                    instance.setTransaction(null);
                    ManagedContainer.this.releaseInstance(instance);
                }
                catch (InvalidateReferenceException ex) {}
                catch (Throwable e) {
                    final String message = "An unexpected system exception occured while invoking the afterCompletion method on the SessionSynchronization object";
                    ManagedContainer.logger.error("An unexpected system exception occured while invoking the afterCompletion method on the SessionSynchronization object", e);
                    ManagedContainer.this.discardInstance(callContext);
                    if (firstException == null) {
                        firstException = e;
                    }
                }
                finally {
                    ThreadContext.exit(oldCallContext);
                }
            }
            if (firstException != null) {
                throw new OpenEJBRuntimeException("An unexpected system exception occured while invoking the afterCompletion method on the SessionSynchronization object", firstException);
            }
        }
        
        public class Synchronization
        {
            private final Instance instance;
            private boolean callSessionSynchronization;
            
            public Synchronization(final Instance instance) {
                this.instance = instance;
            }
            
            public synchronized boolean isCallSessionSynchronization() {
                return this.callSessionSynchronization;
            }
            
            public synchronized boolean setCallSessionSynchronization(final boolean synchronize) {
                final boolean oldValue = this.callSessionSynchronization;
                this.callSessionSynchronization = synchronize;
                return oldValue;
            }
        }
    }
    
    public class StatefulCacheListener implements Cache.CacheListener<Instance>
    {
        @Override
        public void afterLoad(final Instance instance) throws SystemException, ApplicationException {
            final BeanContext beanContext = instance.beanContext;
            final ThreadContext threadContext = new ThreadContext(instance.beanContext, instance.primaryKey, Operation.ACTIVATE);
            final ThreadContext oldContext = ThreadContext.enter(threadContext);
            try {
                final Method remove = (instance.bean instanceof SessionBean) ? SessionBean.class.getMethod("ejbActivate", (Class<?>[])new Class[0]) : null;
                final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, remove, Operation.ACTIVATE, callbackInterceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Throwable callbackException) {
                ManagedContainer.this.discardInstance(threadContext);
                EjbTransactionUtil.handleSystemException(threadContext.getTransactionPolicy(), callbackException, threadContext);
            }
            finally {
                ThreadContext.exit(oldContext);
            }
        }
        
        @Override
        public void beforeStore(final Instance instance) {
            final BeanContext beanContext = instance.beanContext;
            final ThreadContext threadContext = new ThreadContext(beanContext, instance.primaryKey, Operation.PASSIVATE);
            final ThreadContext oldContext = ThreadContext.enter(threadContext);
            try {
                final Method passivate = (instance.bean instanceof SessionBean) ? SessionBean.class.getMethod("ejbPassivate", (Class<?>[])new Class[0]) : null;
                final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, passivate, Operation.PASSIVATE, callbackInterceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Throwable e) {
                ManagedContainer.logger.error("An unexpected exception occured while invoking the ejbPassivate method on the Stateful SessionBean instance", e);
            }
            finally {
                ThreadContext.exit(oldContext);
            }
        }
        
        @Override
        public void timedOut(final Instance instance) {
            final BeanContext beanContext = instance.beanContext;
            final ThreadContext threadContext = new ThreadContext(beanContext, instance.primaryKey, Operation.PRE_DESTROY);
            threadContext.setCurrentAllowedStates(null);
            final ThreadContext oldContext = ThreadContext.enter(threadContext);
            try {
                final Method remove = (instance.bean instanceof SessionBean) ? SessionBean.class.getMethod("ejbRemove", (Class<?>[])new Class[0]) : null;
                final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, remove, Operation.PRE_DESTROY, callbackInterceptors, instance.interceptors);
                interceptorStack.invoke(new Object[0]);
            }
            catch (Throwable e) {
                ManagedContainer.logger.error("An unexpected exception occured while invoking the ejbRemove method on the timed-out Stateful SessionBean instance", e);
            }
            finally {
                ManagedContainer.logger.info("Removing the timed-out stateful session bean instance " + instance.primaryKey);
                ThreadContext.exit(oldContext);
            }
        }
    }
    
    private static final class Data
    {
        private final Index<Method, MethodType> methodIndex;
        private final List<ObjectName> jmxNames;
        
        private Data(final Index<Method, MethodType> methodIndex) {
            this.jmxNames = new ArrayList<ObjectName>();
            this.methodIndex = methodIndex;
        }
        
        public Index<Method, MethodType> getMethodIndex() {
            return this.methodIndex;
        }
    }
}
