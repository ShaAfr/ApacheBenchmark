// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import java.util.Map;

public class MapObjectReference extends Reference
{
    private final ThreadLocal<Map<String, Object>> obj;
    private final String key;
    
    public MapObjectReference(final ThreadLocal<Map<String, Object>> obj, final String key) {
        this.obj = obj;
        this.key = key;
    }
    
    @Override
    public Object getObject() throws NamingException {
        return this.obj.get().get(this.key);
    }
}
