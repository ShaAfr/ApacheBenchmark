// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.net.URI;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Arrays;
import java.util.List;
import org.apache.openejb.util.LinkResolver;
import java.util.Map;

public class EjbResolver
{
    private final Map<String, EnterpriseBeanInfo> deployments;
    private final LinkResolver<String> resolver;
    private final Map<Interfaces, List<Interfaces>> interfaces;
    private final EjbResolver parent;
    private final Scope scope;
    
    public EjbResolver(final EjbResolver parent, final Scope scope, final EjbJarInfo... ejbJars) {
        this(parent, scope, Arrays.asList(ejbJars));
    }
    
    public EjbResolver(final EjbResolver parent, final Scope scope, final List<EjbJarInfo> ejbJars) {
        this.deployments = new TreeMap<String, EnterpriseBeanInfo>();
        this.resolver = new LinkResolver<String>();
        this.interfaces = new TreeMap<Interfaces, List<Interfaces>>();
        this.scope = scope;
        this.parent = parent;
        for (final EjbJarInfo ejbJarInfo : ejbJars) {
            this.add(ejbJarInfo);
        }
    }
    
    public void addAll(final List<EjbJarInfo> ejbJars) {
        for (final EjbJarInfo ejbJarInfo : ejbJars) {
            this.add(ejbJarInfo);
        }
    }
    
    public void add(final EjbJarInfo ejbJarInfo) {
        for (final EnterpriseBeanInfo bean : ejbJarInfo.enterpriseBeans) {
            this.index(ejbJarInfo.moduleUri, bean);
        }
    }
    
    private void index(final URI moduleURI, final EnterpriseBeanInfo bean) {
        this.deployments.put(bean.ejbDeploymentId, bean);
        this.resolver.add(moduleURI, bean.ejbName, bean.ejbDeploymentId);
        if (bean.remote != null) {
            this.addInterfaces(new Interfaces(bean.home, bean.remote, Type.REMOTE, bean.ejbDeploymentId));
            this.addInterfaces(new Interfaces(bean.remote, Type.REMOTE, bean.ejbDeploymentId));
        }
        for (final String businessRemote : bean.businessRemote) {
            this.addInterfaces(new Interfaces(businessRemote, Type.REMOTE, bean.ejbDeploymentId));
        }
        if (bean.local != null) {
            this.addInterfaces(new Interfaces(bean.localHome, bean.local, Type.LOCAL, bean.ejbDeploymentId));
            this.addInterfaces(new Interfaces(bean.local, Type.LOCAL, bean.ejbDeploymentId));
        }
        for (final String businessLocal : bean.businessLocal) {
            this.addInterfaces(new Interfaces(businessLocal, Type.LOCAL, bean.ejbDeploymentId));
        }
        if (bean.localbean) {
            this.addInterfaces(new Interfaces(bean.ejbClass, Type.LOCAL, bean.ejbDeploymentId));
            for (final String parent : bean.parents) {
                this.addInterfaces(new Interfaces(parent, Type.LOCAL, bean.ejbDeploymentId));
            }
        }
    }
    
    private void addInterfaces(final Interfaces interfaces) {
        List<Interfaces> similar = this.interfaces.get(interfaces);
        if (similar == null) {
            similar = new ArrayList<Interfaces>();
            this.interfaces.put(interfaces, similar);
        }
        similar.add(interfaces);
    }
    
    private String resolveLink(final String link, final URI moduleUri) {
        if (link == null || link.length() == 0) {
            return null;
        }
        String id = this.resolver.resolveLink(link, moduleUri);
        if (id == null && this.parent != null) {
            id = this.parent.resolveLink(link, moduleUri);
        }
        return id;
    }
    
    private String resolveInterface(final Reference ref) {
        String id = null;
        if (ref.getInterface() == null) {
            return null;
        }
        final List<Interfaces> matches = this.interfaces.get(new Interfaces(ref.getHome(), ref.getInterface()));
        if (matches != null && matches.size() > 0) {
            final List<Interfaces> nameMatches = this.filter(matches, ref.getName());
            id = this.first(this.filter(nameMatches, ref.getRefType()));
            if (id == null) {
                id = this.first(nameMatches);
            }
            if (id == null) {
                id = this.first(this.filter(matches, ref.getRefType()));
            }
            if (id == null) {
                id = this.first(matches);
            }
        }
        if (id == null && this.parent != null) {
            id = this.parent.resolveInterface(ref);
        }
        return id;
    }
    
    private String first(final List<Interfaces> list) {
        if (list.size() == 0) {
            return null;
        }
        return list.get(0).getId();
    }
    
    private List<Interfaces> filter(final List<Interfaces> list, final String name) {
        final String shortName = name.replaceAll(".*/", "");
        final List<Interfaces> matches = new ArrayList<Interfaces>();
        for (final Interfaces entry : list) {
            if (name.equalsIgnoreCase(entry.getId())) {
                matches.add(entry);
            }
            else {
                if (!shortName.equalsIgnoreCase(entry.getId())) {
                    continue;
                }
                matches.add(entry);
            }
        }
        return matches;
    }
    
    private List<Interfaces> filter(final List<Interfaces> list, final Type type) {
        final List<Interfaces> matches = new ArrayList<Interfaces>();
        for (final Interfaces entry : list) {
            if (type == Type.UNKNOWN || type == entry.type) {
                matches.add(entry);
            }
        }
        return matches;
    }
    
    public Scope getScope(final String deploymentId) {
        if (this.deployments.containsKey(deploymentId)) {
            return this.scope;
        }
        if (this.parent != null) {
            return this.parent.getScope(deploymentId);
        }
        return null;
    }
    
    public EnterpriseBeanInfo getEnterpriseBeanInfo(final String deploymentId) {
        EnterpriseBeanInfo info = this.deployments.get(deploymentId);
        if (info == null && this.parent != null) {
            info = this.parent.getEnterpriseBeanInfo(deploymentId);
        }
        return info;
    }
    
    public String resolve(final Reference ref, final URI moduleUri) {
        if (ref.getMappedName() != null && !ref.getMappedName().equals("")) {
            return ref.getMappedName();
        }
        String targetId = this.resolveLink(ref.getEjbLink(), moduleUri);
        if (targetId == null && ref.getEjbLink() == null) {
            targetId = this.resolveInterface(ref);
        }
        return targetId;
    }
    
    public enum Type
    {
        UNKNOWN, 
        LOCAL, 
        REMOTE;
    }
    
    public enum Scope
    {
        GLOBAL, 
        EAR, 
        EJBJAR;
    }
    
    private static class Interfaces implements Comparable
    {
        private final String id;
        private final Type type;
        private final String homeInterface;
        private final String objectInterface;
        
        public Interfaces(final String objectInterface, final Type type, final String id) {
            if (objectInterface == null) {
                throw new NullPointerException("objectInterface is null");
            }
            this.homeInterface = "<none>";
            this.objectInterface = objectInterface;
            this.type = type;
            this.id = id;
        }
        
        public Interfaces(String homeInterface, final String objectInterface, final Type type, final String id) {
            if (homeInterface == null) {
                homeInterface = "<none>";
            }
            if (objectInterface == null) {
                throw new NullPointerException("objectInterface is null");
            }
            this.homeInterface = homeInterface;
            this.objectInterface = objectInterface;
            this.type = type;
            this.id = id;
        }
        
        public Interfaces(String homeInterface, final String objectInterface) {
            if (homeInterface == null) {
                homeInterface = "<none>";
            }
            if (objectInterface == null) {
                throw new NullPointerException("objectInterface is null");
            }
            this.homeInterface = homeInterface;
            this.objectInterface = objectInterface;
            this.type = null;
            this.id = null;
        }
        
        public String getId() {
            return this.id;
        }
        
        public Type getType() {
            return this.type;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final Interfaces that = (Interfaces)o;
            return this.homeInterface.equals(that.homeInterface) && this.objectInterface.equals(that.objectInterface);
        }
        
        @Override
        public int hashCode() {
            int result = this.homeInterface.hashCode();
            result = 31 * result + this.objectInterface.hashCode();
            return result;
        }
        
        @Override
        public int compareTo(final Object o) {
            if (this == o) {
                return 0;
            }
            final Interfaces that = (Interfaces)o;
            return this.toString().compareTo(that.toString());
        }
        
        @Override
        public String toString() {
            return this.homeInterface + ":" + this.objectInterface;
        }
    }
    
    public interface Reference
    {
        String getName();
        
        Type getRefType();
        
        String getHome();
        
        String getInterface();
        
        String getMappedName();
        
        String getEjbLink();
    }
}
