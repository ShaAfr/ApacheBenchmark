// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import java.text.DateFormat;
import org.apache.openejb.quartz.impl.triggers.SimpleTriggerImpl;
import org.apache.openejb.quartz.impl.triggers.AbstractTrigger;
import javax.ejb.TimerConfig;
import java.lang.reflect.Method;
import java.util.Date;

public class SingleActionTimerData extends TimerData
{
    private static final long serialVersionUID = 1L;
    private final Date expiration;
    
    public SingleActionTimerData(final long id, final EjbTimerServiceImpl timerService, final String deploymentId, final Object primaryKey, final Method timeoutMethod, final TimerConfig timerConfig, final Date expiration) {
        super(id, timerService, deploymentId, primaryKey, timeoutMethod, timerConfig);
        this.expiration = expiration;
    }
    
    @Override
    public TimerType getType() {
        return TimerType.SingleAction;
    }
    
    public Date getExpiration() {
        return this.expiration;
    }
    
    public AbstractTrigger<?> initializeTrigger() {
        final SimpleTriggerImpl simpleTrigger = new SimpleTriggerImpl();
        simpleTrigger.setStartTime(this.expiration);
        return (AbstractTrigger<?>)simpleTrigger;
    }
    
    @Override
    public String toString() {
        return TimerType.SingleAction.name() + " expiration = [" + DateFormat.getDateTimeInstance().format(this.expiration) + "]";
    }
}
