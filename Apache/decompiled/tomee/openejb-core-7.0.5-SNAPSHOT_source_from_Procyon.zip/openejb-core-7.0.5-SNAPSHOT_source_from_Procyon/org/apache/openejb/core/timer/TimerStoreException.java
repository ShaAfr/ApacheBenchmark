// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.OpenEJBException;

public class TimerStoreException extends OpenEJBException
{
    public TimerStoreException() {
    }
    
    public TimerStoreException(final String message) {
        super(message);
    }
    
    public TimerStoreException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public TimerStoreException(final Throwable cause) {
        super(cause);
    }
}
