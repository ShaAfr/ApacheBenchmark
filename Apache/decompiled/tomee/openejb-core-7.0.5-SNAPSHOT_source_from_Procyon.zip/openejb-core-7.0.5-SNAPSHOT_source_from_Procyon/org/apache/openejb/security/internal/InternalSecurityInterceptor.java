// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.security.internal;

import javax.interceptor.AroundInvoke;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.spi.Assembler;
import org.apache.openejb.loader.SystemInstance;
import javax.interceptor.InvocationContext;

public class InternalSecurityInterceptor
{
    public static final String OPENEJB_INTERNAL_BEANS_SECURITY_ENABLED = "openejb.internal.beans.security.enabled";
    private static final String[] ROLES;
    
    @AroundInvoke
    public Object invoke(final InvocationContext ic) throws Exception {
        if (SystemInstance.get().isDefaultProfile() || !SystemInstance.get().getOptions().get("openejb.internal.beans.security.enabled", true)) {
            return ic.proceed();
        }
        final SecurityService<?> ss = (SecurityService<?>)((Assembler)SystemInstance.get().getComponent((Class)Assembler.class)).getSecurityService();
        for (final String role : InternalSecurityInterceptor.ROLES) {
            if (ss.isCallerInRole(role)) {
                return ic.proceed();
            }
        }
        throw new SecurityException("to invoke this EJB you need to get the right permission");
    }
    
    static {
        ROLES = new String[] { "openejb-admin", "tomee-admin" };
    }
}
