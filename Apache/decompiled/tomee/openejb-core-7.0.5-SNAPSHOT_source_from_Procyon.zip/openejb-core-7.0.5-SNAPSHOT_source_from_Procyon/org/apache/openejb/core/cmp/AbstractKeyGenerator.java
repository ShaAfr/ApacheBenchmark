// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import javax.ejb.EJBException;
import org.apache.openejb.OpenEJBException;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;

public abstract class AbstractKeyGenerator implements KeyGenerator
{
    public static boolean isValidPkField(final Field field) {
        final int modifiers = field.getModifiers();
        return Modifier.isPublic(modifiers) && !Modifier.isStatic(modifiers);
    }
    
    public static Field getField(final Class clazz, final String fieldName) throws OpenEJBException {
        try {
            return clazz.getField(fieldName);
        }
        catch (NoSuchFieldException e) {
            throw new OpenEJBException("Unable to get primary key field from entity bean class: " + clazz.getName(), e);
        }
    }
    
    public static Object getFieldValue(final Field field, final Object object) throws EJBException {
        if (field == null) {
            throw new NullPointerException("field is null");
        }
        if (object == null) {
            throw new NullPointerException("object is null");
        }
        try {
            return field.get(object);
        }
        catch (Exception e) {
            throw new EJBException("Could not get field value for field " + field, e);
        }
    }
    
    public static void setFieldValue(final Field field, final Object object, final Object value) throws EJBException {
        if (field == null) {
            throw new NullPointerException("field is null");
        }
        if (object == null) {
            throw new NullPointerException("object is null");
        }
        try {
            field.set(object, value);
        }
        catch (Exception e) {
            throw new EJBException("Could not set field value for field " + field, e);
        }
    }
}
