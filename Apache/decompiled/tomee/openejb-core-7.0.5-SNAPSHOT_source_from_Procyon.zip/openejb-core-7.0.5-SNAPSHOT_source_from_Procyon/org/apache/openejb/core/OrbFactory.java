// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import org.apache.openejb.loader.SystemInstance;
import org.omg.CORBA.ORB;

public class OrbFactory
{
    public ORB create() {
        ORB orb = (ORB)SystemInstance.get().getComponent((Class)ORB.class);
        if (orb == null) {
            orb = ORB.init();
            SystemInstance.get().setComponent((Class)ORB.class, (Object)orb);
        }
        return orb;
    }
}
