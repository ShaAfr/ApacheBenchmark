// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import javax.ejb.TimerConfig;
import javax.ejb.ScheduleExpression;

public class ScheduleData
{
    private final ScheduleExpression expression;
    private final TimerConfig config;
    
    public ScheduleData(final TimerConfig config, final ScheduleExpression expression) {
        this.config = config;
        this.expression = expression;
    }
    
    public TimerConfig getConfig() {
        return this.config;
    }
    
    public ScheduleExpression getExpression() {
        return this.expression;
    }
}
