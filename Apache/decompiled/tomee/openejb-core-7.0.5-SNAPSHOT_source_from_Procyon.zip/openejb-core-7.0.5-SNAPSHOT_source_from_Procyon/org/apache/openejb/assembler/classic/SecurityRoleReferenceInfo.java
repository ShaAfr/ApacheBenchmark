// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class SecurityRoleReferenceInfo extends InfoObject
{
    public String description;
    public String roleName;
    public String roleLink;
}
