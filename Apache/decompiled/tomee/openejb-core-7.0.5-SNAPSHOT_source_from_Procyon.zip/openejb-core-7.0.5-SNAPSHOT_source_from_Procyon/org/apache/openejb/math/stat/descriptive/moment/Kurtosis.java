// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive.moment;

import org.apache.openejb.math.stat.descriptive.UnivariateStatistic;
import org.apache.openejb.math.stat.descriptive.StorelessUnivariateStatistic;
import org.apache.openejb.math.MathRuntimeException;
import java.io.Serializable;
import org.apache.openejb.math.stat.descriptive.AbstractStorelessUnivariateStatistic;

public class Kurtosis extends AbstractStorelessUnivariateStatistic implements Serializable
{
    private static final long serialVersionUID = 1234465764798260919L;
    protected FourthMoment moment;
    protected boolean incMoment;
    
    public Kurtosis() {
        this.incMoment = true;
        this.moment = new FourthMoment();
    }
    
    public Kurtosis(final FourthMoment m4) {
        this.incMoment = false;
        this.moment = m4;
    }
    
    public Kurtosis(final Kurtosis original) {
        copy(original, this);
    }
    
    @Override
    public void increment(final double d) {
        if (this.incMoment) {
            this.moment.increment(d);
            return;
        }
        throw MathRuntimeException.createIllegalStateException("statistics constructed from external moments cannot be incremented", new Object[0]);
    }
    
    @Override
    public double getResult() {
        double kurtosis = Double.NaN;
        if (this.moment.getN() > 3L) {
            final double variance = this.moment.m2 / (this.moment.n - 1L);
            if (this.moment.n <= 3L || variance < 1.0E-19) {
                kurtosis = 0.0;
            }
            else {
                final double n = (double)this.moment.n;
                kurtosis = (n * (n + 1.0) * this.moment.m4 - 3.0 * this.moment.m2 * this.moment.m2 * (n - 1.0)) / ((n - 1.0) * (n - 2.0) * (n - 3.0) * variance * variance);
            }
        }
        return kurtosis;
    }
    
    @Override
    public void clear() {
        if (this.incMoment) {
            this.moment.clear();
            return;
        }
        throw MathRuntimeException.createIllegalStateException("statistics constructed from external moments cannot be cleared", new Object[0]);
    }
    
    @Override
    public long getN() {
        return this.moment.getN();
    }
    
    @Override
    public double evaluate(final double[] values, final int begin, final int length) {
        double kurt = Double.NaN;
        if (this.test(values, begin, length) && length > 3) {
            final Variance variance = new Variance();
            variance.incrementAll(values, begin, length);
            final double mean = variance.moment.m1;
            final double stdDev = Math.sqrt(variance.getResult());
            double accum3 = 0.0;
            for (int i = begin; i < begin + length; ++i) {
                accum3 += Math.pow(values[i] - mean, 4.0);
            }
            accum3 /= Math.pow(stdDev, 4.0);
            final double n0 = length;
            final double coefficientOne = n0 * (n0 + 1.0) / ((n0 - 1.0) * (n0 - 2.0) * (n0 - 3.0));
            final double termTwo = 3.0 * Math.pow(n0 - 1.0, 2.0) / ((n0 - 2.0) * (n0 - 3.0));
            kurt = coefficientOne * accum3 - termTwo;
        }
        return kurt;
    }
    
    @Override
    public Kurtosis copy() {
        final Kurtosis result = new Kurtosis();
        copy(this, result);
        return result;
    }
    
    public static void copy(final Kurtosis source, final Kurtosis dest) {
        dest.moment = source.moment.copy();
        dest.incMoment = source.incMoment;
    }
}
