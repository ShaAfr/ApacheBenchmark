// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.jpa;

import javax.ejb.RemoveException;
import javax.persistence.PersistenceException;
import org.apache.openjpa.event.LifecycleEvent;
import org.apache.openjpa.event.AbstractLifecycleListener;
import org.apache.openejb.core.cmp.ComplexKeyGenerator;
import org.apache.openejb.core.cmp.SimpleKeyGenerator;
import org.apache.openejb.core.cmp.cmp2.Cmp2KeyGenerator;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import org.apache.openejb.core.transaction.TransactionType;
import java.util.Iterator;
import javax.ejb.EJBLocalObject;
import org.apache.openejb.core.cmp.cmp2.Cmp2Util;
import javax.ejb.EJBObject;
import javax.persistence.Query;
import javax.ejb.FinderException;
import java.util.List;
import java.lang.reflect.Method;
import javax.ejb.CreateException;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.core.ThreadContext;
import org.apache.openjpa.persistence.OpenJPAEntityManagerFactorySPI;
import org.apache.openjpa.persistence.OpenJPAEntityManagerSPI;
import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import org.apache.openejb.core.cmp.KeyGenerator;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.BeanContext;
import java.util.HashSet;
import javax.ejb.EntityBean;
import java.util.Set;
import org.apache.openejb.core.cmp.CmpCallback;
import org.apache.openejb.core.cmp.CmpEngine;

public class JpaCmpEngine implements CmpEngine
{
    private static final Object[] NO_ARGS;
    public static final String CMP_PERSISTENCE_CONTEXT_REF_NAME = "comp/env/openejb/cmp";
    private final CmpCallback cmpCallback;
    private final ThreadLocal<Set<EntityBean>> creating;
    protected Object entityManagerListener;
    
    public JpaCmpEngine(final CmpCallback cmpCallback) {
        this.creating = new ThreadLocal<Set<EntityBean>>() {
            @Override
            protected Set<EntityBean> initialValue() {
                return new HashSet<EntityBean>();
            }
        };
        this.cmpCallback = cmpCallback;
    }
    
    @Override
    public synchronized void deploy(final BeanContext beanContext) throws OpenEJBException {
        this.configureKeyGenerator(beanContext);
    }
    
    @Override
    public synchronized void undeploy(final BeanContext beanContext) throws OpenEJBException {
        beanContext.setKeyGenerator(null);
    }
    
    private EntityManager getEntityManager(final BeanContext beanContext) {
        EntityManager entityManager = null;
        try {
            entityManager = (EntityManager)beanContext.getJndiEnc().lookup("comp/env/openejb/cmp");
        }
        catch (NamingException ignored) {
            try {
                entityManager = (EntityManager)new InitialContext().lookup("java:comp/env/openejb/cmp");
            }
            catch (NamingException ex) {}
        }
        if (entityManager == null) {
            throw new EJBException("Entity manager not found at \"openejb/cmp\" in jndi ejb " + beanContext.getDeploymentID());
        }
        this.registerListener(entityManager);
        return entityManager;
    }
    
    private synchronized void registerListener(final EntityManager entityManager) {
        if (entityManager instanceof OpenJPAEntityManagerSPI) {
            final OpenJPAEntityManagerSPI openjpaEM = (OpenJPAEntityManagerSPI)entityManager;
            final OpenJPAEntityManagerFactorySPI openjpaEMF = (OpenJPAEntityManagerFactorySPI)openjpaEM.getEntityManagerFactory();
            if (this.entityManagerListener == null) {
                this.entityManagerListener = new OpenJPALifecycleListener();
            }
            openjpaEMF.addLifecycleListener(this.entityManagerListener, (Class[])null);
            return;
        }
        final Object delegate = entityManager.getDelegate();
        if (delegate != entityManager && delegate instanceof EntityManager) {
            this.registerListener((EntityManager)delegate);
        }
    }
    
    @Override
    public Object createBean(EntityBean bean, final ThreadContext callContext) throws CreateException {
        final TransactionPolicy txPolicy = this.startTransaction("persist", callContext);
        this.creating.get().add(bean);
        try {
            final BeanContext beanContext = callContext.getBeanContext();
            final EntityManager entityManager = this.getEntityManager(beanContext);
            entityManager.persist((Object)bean);
            entityManager.flush();
            bean = (EntityBean)entityManager.merge((Object)bean);
            final KeyGenerator kg = beanContext.getKeyGenerator();
            final Object primaryKey = kg.getPrimaryKey(bean);
            return primaryKey;
        }
        finally {
            this.creating.get().remove(bean);
            this.commitTransaction("persist", callContext, txPolicy);
        }
    }
    
    @Override
    public Object loadBean(final ThreadContext callContext, final Object primaryKey) {
        final TransactionPolicy txPolicy = this.startTransaction("load", callContext);
        try {
            final BeanContext beanContext = callContext.getBeanContext();
            final Class<?> beanClass = (Class<?>)beanContext.getCmpImplClass();
            final EntityManager entityManager = this.getEntityManager(beanContext);
            return entityManager.find((Class)beanClass, primaryKey);
        }
        finally {
            this.commitTransaction("load", callContext, txPolicy);
        }
    }
    
    @Override
    public void storeBeanIfNoTx(final ThreadContext callContext, final Object bean) {
        final TransactionPolicy callerTxPolicy = callContext.getTransactionPolicy();
        if (callerTxPolicy != null && callerTxPolicy.isTransactionActive()) {
            return;
        }
        final TransactionPolicy txPolicy = this.startTransaction("store", callContext);
        try {
            if (txPolicy.isNewTransaction()) {
                final EntityManager entityManager = this.getEntityManager(callContext.getBeanContext());
                entityManager.merge(bean);
            }
        }
        finally {
            this.commitTransaction("store", callContext, txPolicy);
        }
    }
    
    @Override
    public void removeBean(final ThreadContext callContext) {
        final TransactionPolicy txPolicy = this.startTransaction("remove", callContext);
        try {
            final BeanContext deploymentInfo = callContext.getBeanContext();
            final Class<?> beanClass = (Class<?>)deploymentInfo.getCmpImplClass();
            final EntityManager entityManager = this.getEntityManager(deploymentInfo);
            final Object primaryKey = callContext.getPrimaryKey();
            final Object bean = entityManager.find((Class)beanClass, primaryKey);
            entityManager.remove(bean);
        }
        finally {
            this.commitTransaction("remove", callContext, txPolicy);
        }
    }
    
    @Override
    public List<Object> queryBeans(final ThreadContext callContext, final Method queryMethod, final Object[] args) throws FinderException {
        final BeanContext deploymentInfo = callContext.getBeanContext();
        final EntityManager entityManager = this.getEntityManager(deploymentInfo);
        final StringBuilder queryName = new StringBuilder();
        queryName.append(deploymentInfo.getAbstractSchemaName()).append(".").append(queryMethod.getName());
        final String shortName = queryName.toString();
        if (queryMethod.getParameterTypes().length > 0) {
            queryName.append('(');
            boolean first = true;
            for (final Class<?> parameterType : queryMethod.getParameterTypes()) {
                if (!first) {
                    queryName.append(',');
                }
                queryName.append(parameterType.getCanonicalName());
                first = false;
            }
            queryName.append(')');
        }
        final String fullName = queryName.toString();
        Query query = this.createNamedQuery(entityManager, fullName);
        if (query == null) {
            query = this.createNamedQuery(entityManager, shortName);
            if (query == null) {
                throw new FinderException("No query defined for method " + fullName);
            }
        }
        return this.executeSelectQuery(query, args);
    }
    
    @Override
    public List<Object> queryBeans(final BeanContext beanContext, final String signature, final Object[] args) throws FinderException {
        final EntityManager entityManager = this.getEntityManager(beanContext);
        Query query = this.createNamedQuery(entityManager, signature);
        if (query == null) {
            final int parenIndex = signature.indexOf(40);
            if (parenIndex > 0) {
                final String shortName = signature.substring(0, parenIndex);
                query = this.createNamedQuery(entityManager, shortName);
            }
            if (query == null) {
                throw new FinderException("No query defined for method " + signature);
            }
        }
        return this.executeSelectQuery(query, args);
    }
    
    private List<Object> executeSelectQuery(final Query query, Object[] args) {
        if (args == null) {
            args = JpaCmpEngine.NO_ARGS;
        }
        for (int i = 0; i < args.length; ++i) {
            Object arg = args[i];
            if (arg instanceof EJBObject) {
                arg = Cmp2Util.getEntityBean((EJBObject)arg);
            }
            if (arg instanceof EJBLocalObject) {
                arg = Cmp2Util.getEntityBean((EJBLocalObject)arg);
            }
            try {
                query.getParameter(i + 1);
            }
            catch (IllegalArgumentException e) {
                continue;
            }
            query.setParameter(i + 1, arg);
        }
        final List results = query.getResultList();
        for (final Object value : results) {
            if (value instanceof EntityBean) {
                final EntityBean entity = (EntityBean)value;
                this.cmpCallback.setEntityContext(entity);
                this.cmpCallback.ejbActivate(entity);
            }
        }
        return (List<Object>)results;
    }
    
    @Override
    public int executeUpdateQuery(final BeanContext beanContext, final String signature, Object[] args) throws FinderException {
        final EntityManager entityManager = this.getEntityManager(beanContext);
        Query query = this.createNamedQuery(entityManager, signature);
        if (query == null) {
            final int parenIndex = signature.indexOf(40);
            if (parenIndex > 0) {
                final String shortName = signature.substring(0, parenIndex);
                query = this.createNamedQuery(entityManager, shortName);
            }
            if (query == null) {
                throw new FinderException("No query defined for method " + signature);
            }
        }
        if (args == null) {
            args = JpaCmpEngine.NO_ARGS;
        }
        for (int i = 0; i < args.length; ++i) {
            Object arg = args[i];
            if (arg instanceof EJBObject) {
                arg = Cmp2Util.getEntityBean((EJBObject)arg);
            }
            if (arg instanceof EJBLocalObject) {
                arg = Cmp2Util.getEntityBean((EJBLocalObject)arg);
            }
            query.setParameter(i + 1, arg);
        }
        final int result = query.executeUpdate();
        return result;
    }
    
    private Query createNamedQuery(final EntityManager entityManager, final String name) {
        try {
            return entityManager.createNamedQuery(name);
        }
        catch (IllegalArgumentException ignored) {
            ignored.printStackTrace();
            return null;
        }
    }
    
    private TransactionPolicy startTransaction(final String operation, final ThreadContext callContext) {
        try {
            final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(TransactionType.Required, callContext);
            return txPolicy;
        }
        catch (Exception e) {
            throw new EJBException("Unable to start transaction for " + operation + " operation", e);
        }
    }
    
    private void commitTransaction(final String operation, final ThreadContext callContext, final TransactionPolicy txPolicy) {
        try {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        catch (Exception e) {
            throw new EJBException("Unable to complete transaction for " + operation + " operation", e);
        }
    }
    
    private void configureKeyGenerator(final BeanContext di) throws OpenEJBException {
        if (di.isCmp2()) {
            di.setKeyGenerator(new Cmp2KeyGenerator());
        }
        else {
            final String primaryKeyField = di.getPrimaryKeyField();
            final Class cmpBeanImpl = di.getCmpImplClass();
            if (primaryKeyField != null) {
                di.setKeyGenerator(new SimpleKeyGenerator(cmpBeanImpl, primaryKeyField));
            }
            else if (Object.class.equals(di.getPrimaryKeyClass())) {
                di.setKeyGenerator(new SimpleKeyGenerator(cmpBeanImpl, "OpenEJB_pk"));
            }
            else {
                di.setKeyGenerator(new ComplexKeyGenerator(cmpBeanImpl, di.getPrimaryKeyClass()));
            }
        }
    }
    
    static {
        NO_ARGS = new Object[0];
    }
    
    private class OpenJPALifecycleListener extends AbstractLifecycleListener
    {
        public void afterLoad(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
            final Object bean = lifecycleEvent.getSource();
            JpaCmpEngine.this.cmpCallback.setEntityContext((EntityBean)bean);
            JpaCmpEngine.this.cmpCallback.ejbActivate((EntityBean)bean);
            JpaCmpEngine.this.cmpCallback.ejbLoad((EntityBean)bean);
        }
        
        public void beforeStore(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
            final EntityBean bean = (EntityBean)lifecycleEvent.getSource();
            if (!JpaCmpEngine.this.creating.get().contains(bean)) {
                JpaCmpEngine.this.cmpCallback.ejbStore(bean);
            }
        }
        
        public void afterAttach(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
            final Object bean = lifecycleEvent.getSource();
            JpaCmpEngine.this.cmpCallback.setEntityContext((EntityBean)bean);
        }
        
        public void beforeDelete(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
            try {
                final Object bean = lifecycleEvent.getSource();
                JpaCmpEngine.this.cmpCallback.ejbRemove((EntityBean)bean);
            }
            catch (RemoveException e) {
                throw new PersistenceException((Throwable)e);
            }
        }
        
        public void afterDetach(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
            final Object bean = lifecycleEvent.getSource();
            JpaCmpEngine.this.cmpCallback.ejbPassivate((EntityBean)bean);
            JpaCmpEngine.this.cmpCallback.unsetEntityContext((EntityBean)bean);
        }
        
        public void beforePersist(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
        }
        
        public void afterRefresh(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
        }
        
        public void beforeDetach(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
        }
        
        public void beforeAttach(final LifecycleEvent lifecycleEvent) {
            this.eventOccurred(lifecycleEvent);
        }
    }
}
