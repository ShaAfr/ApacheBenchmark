// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log.logger;

import java.util.Locale;
import java.util.ResourceBundle;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.logging.Filter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public abstract class AbstractDelegatingLogger extends Logger
{
    protected AbstractDelegatingLogger(final String name, final String resourceBundleName) {
        super(name, resourceBundleName);
    }
    
    @Override
    public void log(final LogRecord record) {
        if (this.isLoggable(record.getLevel())) {
            this.doLog(record);
        }
    }
    
    @Override
    public void log(final Level level, final String msg) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void log(final Level level, final String msg, final Object param1) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            final Object[] params = { param1 };
            lr.setParameters(params);
            this.doLog(lr);
        }
    }
    
    @Override
    public void log(final Level level, final String msg, final Object[] params) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setParameters(params);
            this.doLog(lr);
        }
    }
    
    @Override
    public void log(final Level level, final String msg, final Throwable thrown) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setThrown(thrown);
            this.doLog(lr);
        }
    }
    
    @Override
    public void logp(final Level level, final String sourceClass, final String sourceMethod, final String msg) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            this.doLog(lr);
        }
    }
    
    @Override
    public void logp(final Level level, final String sourceClass, final String sourceMethod, final String msg, final Object param1) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            final Object[] params = { param1 };
            lr.setParameters(params);
            this.doLog(lr);
        }
    }
    
    @Override
    public void logp(final Level level, final String sourceClass, final String sourceMethod, final String msg, final Object[] params) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            lr.setParameters(params);
            this.doLog(lr);
        }
    }
    
    @Override
    public void logp(final Level level, final String sourceClass, final String sourceMethod, final String msg, final Throwable thrown) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            lr.setThrown(thrown);
            this.doLog(lr);
        }
    }
    
    @Override
    public void logrb(final Level level, final String sourceClass, final String sourceMethod, final String bundleName, final String msg) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            this.doLog(lr, bundleName);
        }
    }
    
    @Override
    public void logrb(final Level level, final String sourceClass, final String sourceMethod, final String bundleName, final String msg, final Object param1) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            final Object[] params = { param1 };
            lr.setParameters(params);
            this.doLog(lr, bundleName);
        }
    }
    
    @Override
    public void logrb(final Level level, final String sourceClass, final String sourceMethod, final String bundleName, final String msg, final Object[] params) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            lr.setParameters(params);
            this.doLog(lr, bundleName);
        }
    }
    
    @Override
    public void logrb(final Level level, final String sourceClass, final String sourceMethod, final String bundleName, final String msg, final Throwable thrown) {
        if (this.isLoggable(level)) {
            final LogRecord lr = new LogRecord(level, msg);
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            lr.setThrown(thrown);
            this.doLog(lr, bundleName);
        }
    }
    
    @Override
    public void entering(final String sourceClass, final String sourceMethod) {
        if (this.isLoggable(Level.FINER)) {
            this.logp(Level.FINER, sourceClass, sourceMethod, "ENTRY");
        }
    }
    
    @Override
    public void entering(final String sourceClass, final String sourceMethod, final Object param1) {
        if (this.isLoggable(Level.FINER)) {
            final Object[] params = { param1 };
            this.logp(Level.FINER, sourceClass, sourceMethod, "ENTRY {0}", params);
        }
    }
    
    @Override
    public void entering(final String sourceClass, final String sourceMethod, final Object[] params) {
        if (this.isLoggable(Level.FINER)) {
            final String msg = "ENTRY";
            if (params == null) {
                this.logp(Level.FINER, sourceClass, sourceMethod, "ENTRY");
                return;
            }
            final StringBuilder builder = new StringBuilder("ENTRY");
            for (int i = 0; i < params.length; ++i) {
                builder.append(" {");
                builder.append(Integer.toString(i));
                builder.append("}");
            }
            this.logp(Level.FINER, sourceClass, sourceMethod, builder.toString(), params);
        }
    }
    
    @Override
    public void exiting(final String sourceClass, final String sourceMethod) {
        if (this.isLoggable(Level.FINER)) {
            this.logp(Level.FINER, sourceClass, sourceMethod, "RETURN");
        }
    }
    
    @Override
    public void exiting(final String sourceClass, final String sourceMethod, final Object result) {
        if (this.isLoggable(Level.FINER)) {
            final Object[] params = { result };
            this.logp(Level.FINER, sourceClass, sourceMethod, "RETURN {0}", params);
        }
    }
    
    @Override
    public void throwing(final String sourceClass, final String sourceMethod, final Throwable thrown) {
        if (this.isLoggable(Level.FINER)) {
            final LogRecord lr = new LogRecord(Level.FINER, "THROW");
            lr.setSourceClassName(sourceClass);
            lr.setSourceMethodName(sourceMethod);
            lr.setThrown(thrown);
            this.doLog(lr);
        }
    }
    
    @Override
    public void severe(final String msg) {
        if (this.isLoggable(Level.SEVERE)) {
            final LogRecord lr = new LogRecord(Level.SEVERE, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void warning(final String msg) {
        if (this.isLoggable(Level.WARNING)) {
            final LogRecord lr = new LogRecord(Level.WARNING, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void info(final String msg) {
        if (this.isLoggable(Level.INFO)) {
            final LogRecord lr = new LogRecord(Level.INFO, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void config(final String msg) {
        if (this.isLoggable(Level.CONFIG)) {
            final LogRecord lr = new LogRecord(Level.CONFIG, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void fine(final String msg) {
        if (this.isLoggable(Level.FINE)) {
            final LogRecord lr = new LogRecord(Level.FINE, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void finer(final String msg) {
        if (this.isLoggable(Level.FINER)) {
            final LogRecord lr = new LogRecord(Level.FINER, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void finest(final String msg) {
        if (this.isLoggable(Level.FINEST)) {
            final LogRecord lr = new LogRecord(Level.FINEST, msg);
            this.doLog(lr);
        }
    }
    
    @Override
    public void setLevel(final Level newLevel) throws SecurityException {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public abstract Level getLevel();
    
    @Override
    public boolean isLoggable(final Level level) {
        final Level l = this.getLevel();
        return level.intValue() >= l.intValue() && l != Level.OFF;
    }
    
    protected boolean supportsHandlers() {
        return false;
    }
    
    @Override
    public synchronized void addHandler(final Handler handler) throws SecurityException {
        if (this.supportsHandlers()) {
            super.addHandler(handler);
            return;
        }
        throw new UnsupportedOperationException();
    }
    
    @Override
    public synchronized void removeHandler(final Handler handler) throws SecurityException {
        if (this.supportsHandlers()) {
            super.removeHandler(handler);
            return;
        }
        throw new UnsupportedOperationException();
    }
    
    @Override
    public synchronized Handler[] getHandlers() {
        if (this.supportsHandlers()) {
            return super.getHandlers();
        }
        throw new UnsupportedOperationException();
    }
    
    @Override
    public synchronized void setUseParentHandlers(final boolean useParentHandlers) {
        if (this.supportsHandlers()) {
            super.setUseParentHandlers(useParentHandlers);
            return;
        }
        throw new UnsupportedOperationException();
    }
    
    @Override
    public synchronized boolean getUseParentHandlers() {
        if (this.supportsHandlers()) {
            return super.getUseParentHandlers();
        }
        throw new UnsupportedOperationException();
    }
    
    @Override
    public Logger getParent() {
        return null;
    }
    
    @Override
    public void setParent(final Logger parent) {
        throw new UnsupportedOperationException();
    }
    
    protected void doLog(final LogRecord lr) {
        lr.setLoggerName(this.getName());
        final String rbname = this.getResourceBundleName();
        if (rbname != null) {
            lr.setResourceBundleName(rbname);
            lr.setResourceBundle(this.getResourceBundle());
        }
        this.internalLog(lr);
    }
    
    protected void doLog(final LogRecord lr, final String rbname) {
        lr.setLoggerName(this.getName());
        if (rbname != null) {
            lr.setResourceBundleName(rbname);
            lr.setResourceBundle(loadResourceBundle(rbname));
        }
        this.internalLog(lr);
    }
    
    protected void internalLog(final LogRecord record) {
        final Filter filter = this.getFilter();
        if (filter != null && !filter.isLoggable(record)) {
            return;
        }
        final String msg = this.formatMessage(record);
        this.internalLogFormatted(msg, record);
    }
    
    protected abstract void internalLogFormatted(final String p0, final LogRecord p1);
    
    protected String formatMessage(final LogRecord record) {
        String format = record.getMessage();
        final ResourceBundle catalog = record.getResourceBundle();
        if (catalog != null) {
            try {
                format = catalog.getString(record.getMessage());
            }
            catch (MissingResourceException ex) {
                format = record.getMessage();
            }
        }
        try {
            final Object[] parameters = record.getParameters();
            if (parameters == null || parameters.length == 0) {
                return format;
            }
            if (format.indexOf("{0") >= 0 || format.indexOf("{1") >= 0 || format.indexOf("{2") >= 0 || format.indexOf("{3") >= 0) {
                return MessageFormat.format(format, parameters);
            }
            return format;
        }
        catch (Exception ex2) {
            return format;
        }
    }
    
    static ResourceBundle loadResourceBundle(final String resourceBundleName) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        if (null != cl) {
            try {
                return ResourceBundle.getBundle(resourceBundleName, Locale.getDefault(), cl);
            }
            catch (MissingResourceException ex) {}
        }
        cl = ClassLoader.getSystemClassLoader();
        if (null != cl) {
            try {
                return ResourceBundle.getBundle(resourceBundleName, Locale.getDefault(), cl);
            }
            catch (MissingResourceException ex2) {}
        }
        return null;
    }
}
