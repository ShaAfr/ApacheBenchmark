// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import java.util.ArrayList;
import java.util.List;
import java.io.ObjectStreamException;
import java.io.InvalidObjectException;
import java.io.ObjectInput;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.Externalizable;

public class IntraVmArtifact implements Externalizable
{
    private static final Handles staticHandles;
    private static final ThreadLocal<Handles> threadHandles;
    private static final String NO_ARTIFACT_ERROR = "The artifact this object represents could not be found.";
    private int instanceHandle;
    private boolean staticArtifact;
    
    public IntraVmArtifact(final Object obj) {
        this(obj, false);
    }
    
    public IntraVmArtifact(final Object obj, final boolean storeStatically) {
        this.staticArtifact = storeStatically;
        final Handles handles = getHandles(storeStatically);
        this.instanceHandle = handles.add(obj);
    }
    
    private static Handles getHandles(final boolean staticArtifact) {
        return staticArtifact ? IntraVmArtifact.staticHandles : IntraVmArtifact.threadHandles.get();
    }
    
    public IntraVmArtifact() {
    }
    
    @Override
    public void writeExternal(final ObjectOutput out) throws IOException {
        out.writeBoolean(this.staticArtifact);
        out.write(this.instanceHandle);
    }
    
    @Override
    public void readExternal(final ObjectInput in) throws IOException {
        this.staticArtifact = in.readBoolean();
        this.instanceHandle = in.read();
    }
    
    protected Object readResolve() throws ObjectStreamException {
        final Handles handles = getHandles(this.staticArtifact);
        final Object artifact = handles.get(this.instanceHandle);
        if (artifact == null) {
            throw new InvalidObjectException("The artifact this object represents could not be found." + this.instanceHandle);
        }
        return artifact;
    }
    
    static {
        staticHandles = new Handles() {
            @Override
            public synchronized int add(final Object obj) {
                return super.add(obj);
            }
            
            @Override
            public synchronized Object get(final int id) {
                return super.get(id);
            }
        };
        threadHandles = new ThreadLocal<Handles>() {
            @Override
            protected Handles initialValue() {
                return new Handles();
            }
        };
    }
    
    private static class Handles
    {
        private final List<Object> list;
        
        private Handles() {
            this.list = new ArrayList<Object>();
        }
        
        public int add(final Object obj) {
            final int id = this.list.size();
            this.list.add(obj);
            return id;
        }
        
        public Object get(final int id) {
            final Object obj = this.list.get(id);
            if (this.list.size() == id + 1) {
                this.list.clear();
            }
            return obj;
        }
    }
}
