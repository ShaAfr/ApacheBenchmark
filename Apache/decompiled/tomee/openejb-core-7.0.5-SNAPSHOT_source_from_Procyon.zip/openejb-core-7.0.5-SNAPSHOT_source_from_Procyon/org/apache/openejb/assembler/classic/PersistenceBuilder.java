// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.LogCategory;
import javax.naming.Context;
import javax.persistence.spi.PersistenceUnitTransactionType;
import javax.persistence.ValidationMode;
import javax.persistence.SharedCacheMode;
import javax.naming.NamingException;
import org.apache.openejb.OpenEJBException;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import javax.sql.CommonDataSource;
import org.apache.openejb.spi.ContainerSystem;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.persistence.PersistenceUnitInfoImpl;
import javax.validation.ValidatorFactory;
import java.util.Map;
import org.apache.openejb.persistence.PersistenceClassLoaderHandler;
import org.apache.openejb.util.Logger;

public class PersistenceBuilder
{
    public static final Logger logger;
    private final PersistenceClassLoaderHandler persistenceClassLoaderHandler;
    
    public PersistenceBuilder(final PersistenceClassLoaderHandler persistenceClassLoaderHandler) {
        this.persistenceClassLoaderHandler = persistenceClassLoaderHandler;
    }
    
    public ReloadableEntityManagerFactory createEntityManagerFactory(final PersistenceUnitInfo info, final ClassLoader classLoader, final Map<ComparableValidationConfig, ValidatorFactory> validators, final boolean hasCdi) throws Exception {
        final PersistenceUnitInfoImpl unitInfo = new PersistenceUnitInfoImpl(this.persistenceClassLoaderHandler);
        unitInfo.setId(info.id);
        unitInfo.setPersistenceUnitName(info.name);
        unitInfo.setPersistenceProviderClassName(info.provider);
        unitInfo.setClassLoader(classLoader);
        unitInfo.setExcludeUnlistedClasses(info.excludeUnlistedClasses);
        unitInfo.setLazilyInitialized(info.webappName != null || "true".equalsIgnoreCase(info.properties.getProperty("tomee.jpa.factory.lazy", SystemInstance.get().getProperty("tomee.jpa.factory.lazy", "false"))));
        final Context context = ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext();
        String jtaDataSourceId = info.jtaDataSource;
        unitInfo.setJtaDataSourceName(jtaDataSourceId);
        if (jtaDataSourceId != null && !SystemInstance.get().hasProperty("openejb.geronimo")) {
            final String initialJndiName = jtaDataSourceId;
            try {
                if (!jtaDataSourceId.startsWith("java:openejb/Resource/") && !jtaDataSourceId.startsWith("openejb/Resource/")) {
                    jtaDataSourceId = "openejb/Resource/" + jtaDataSourceId;
                }
                final CommonDataSource jtaDataSource = (CommonDataSource)context.lookup(jtaDataSourceId);
                unitInfo.setJtaDataSource(jtaDataSource);
            }
            catch (NamingException e) {
                try {
                    unitInfo.setJtaDataSource((CommonDataSource)new InitialContext().lookup(initialJndiName));
                }
                catch (NamingException ne) {
                    throw new OpenEJBException("Could not lookup <jta-data-source> '" + jtaDataSourceId + "' for unit '" + unitInfo.getPersistenceUnitName() + "'", e);
                }
            }
        }
        unitInfo.setManagedClassNames(info.classes);
        unitInfo.setMappingFileNames(info.mappingFiles);
        unitInfo.setProperties(info.properties);
        unitInfo.setPersistenceXMLSchemaVersion(info.persistenceXMLSchemaVersion);
        final SharedCacheMode sharedCacheMode = Enum.valueOf(SharedCacheMode.class, info.sharedCacheMode);
        unitInfo.setSharedCacheMode(sharedCacheMode);
        final ValidationMode validationMode = Enum.valueOf(ValidationMode.class, info.validationMode);
        unitInfo.setValidationMode(validationMode);
        final PersistenceUnitTransactionType type = Enum.valueOf(PersistenceUnitTransactionType.class, info.transactionType);
        unitInfo.setTransactionType(type);
        String nonJtaDataSourceId = info.nonJtaDataSource;
        unitInfo.setNonJtaDataSourceName(nonJtaDataSourceId);
        if (nonJtaDataSourceId != null && !SystemInstance.get().hasProperty("openejb.geronimo")) {
            final String initialJndiName2 = nonJtaDataSourceId;
            try {
                if (!nonJtaDataSourceId.startsWith("java:openejb/Resource/")) {
                    nonJtaDataSourceId = "java:openejb/Resource/" + nonJtaDataSourceId;
                }
                final CommonDataSource nonJtaDataSource = (CommonDataSource)context.lookup(nonJtaDataSourceId);
                unitInfo.setNonJtaDataSource(nonJtaDataSource);
            }
            catch (NamingException e2) {
                try {
                    unitInfo.setNonJtaDataSource((CommonDataSource)new InitialContext().lookup(initialJndiName2));
                }
                catch (NamingException ne2) {
                    throw new OpenEJBException("Could not lookup <non-jta-data-source> '" + nonJtaDataSourceId + "' for unit '" + unitInfo.getPersistenceUnitName() + "'", e2);
                }
            }
        }
        unitInfo.setRootUrlAndJarUrls(info.persistenceUnitRootUrl, info.jarFiles);
        final String persistenceProviderClassName = unitInfo.getPersistenceProviderClassName();
        unitInfo.setPersistenceProviderClassName(persistenceProviderClassName);
        final EntityManagerFactoryCallable callable = new EntityManagerFactoryCallable(persistenceProviderClassName, unitInfo, classLoader, validators, hasCdi);
        return new ReloadableEntityManagerFactory(classLoader, callable, unitInfo);
    }
    
    public static String getOpenEJBJndiName(final String unit) {
        return "openejb/PersistenceUnit/" + unit;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, PersistenceBuilder.class);
    }
}
