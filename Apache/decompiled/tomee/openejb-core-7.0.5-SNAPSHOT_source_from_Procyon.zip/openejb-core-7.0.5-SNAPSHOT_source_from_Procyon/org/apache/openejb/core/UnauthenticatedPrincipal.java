// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.security.Principal;

public final class UnauthenticatedPrincipal implements Principal
{
    public static final UnauthenticatedPrincipal INSTANCE;
    
    private UnauthenticatedPrincipal() {
    }
    
    @Override
    public String getName() {
        return "Unauthenticated";
    }
    
    static {
        INSTANCE = new UnauthenticatedPrincipal();
    }
}
