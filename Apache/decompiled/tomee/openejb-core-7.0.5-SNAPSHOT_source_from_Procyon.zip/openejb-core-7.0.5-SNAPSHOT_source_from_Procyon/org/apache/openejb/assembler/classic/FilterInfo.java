// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Properties;
import java.util.List;

public class FilterInfo extends InfoObject
{
    public String classname;
    public List<String> mappings;
    public Properties initParams;
    public String name;
    
    public FilterInfo() {
        this.initParams = new Properties();
    }
}
