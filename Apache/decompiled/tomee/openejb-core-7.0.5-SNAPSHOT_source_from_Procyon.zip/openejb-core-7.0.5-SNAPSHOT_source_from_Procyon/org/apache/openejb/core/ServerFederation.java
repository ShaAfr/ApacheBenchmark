// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.HomeHandle;
import javax.ejb.EJBMetaData;
import javax.ejb.Handle;
import org.apache.openejb.ProxyInfo;
import org.apache.openejb.core.ivm.IntraVmServer;
import org.apache.openejb.spi.ApplicationServer;

public class ServerFederation implements ApplicationServer
{
    private static final IntraVmServer localServer;
    private static final ThreadLocal<ApplicationServer> applicationServer;
    
    @Override
    public Handle getHandle(final ProxyInfo proxyInfo) {
        return getApplicationServer().getHandle(proxyInfo);
    }
    
    @Override
    public EJBMetaData getEJBMetaData(final ProxyInfo proxyInfo) {
        return getApplicationServer().getEJBMetaData(proxyInfo);
    }
    
    @Override
    public HomeHandle getHomeHandle(final ProxyInfo proxyInfo) {
        return getApplicationServer().getHomeHandle(proxyInfo);
    }
    
    @Override
    public EJBObject getEJBObject(final ProxyInfo proxyInfo) {
        return getApplicationServer().getEJBObject(proxyInfo);
    }
    
    @Override
    public EJBHome getEJBHome(final ProxyInfo proxyInfo) {
        return getApplicationServer().getEJBHome(proxyInfo);
    }
    
    @Override
    public Object getBusinessObject(final ProxyInfo proxyInfo) {
        return getApplicationServer().getBusinessObject(proxyInfo);
    }
    
    public static void setApplicationServer(final ApplicationServer server) {
        if (server != null) {
            ServerFederation.applicationServer.set(server);
        }
    }
    
    public static ApplicationServer getApplicationServer() {
        final ApplicationServer server = ServerFederation.applicationServer.get();
        if (server == null) {
            return ServerFederation.localServer;
        }
        return server;
    }
    
    static {
        localServer = new IntraVmServer();
        applicationServer = new ThreadLocal<ApplicationServer>();
    }
}
