// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.HashMap;
import java.util.Map;
import java.security.PermissionCollection;

public class PolicyContext
{
    private final PermissionCollection excludedPermissions;
    private final PermissionCollection uncheckedPermissions;
    private final Map<String, PermissionCollection> rolePermissions;
    private final String contextId;
    
    public PolicyContext(final String contextId) {
        this.excludedPermissions = new DelegatePermissionCollection();
        this.uncheckedPermissions = new DelegatePermissionCollection();
        this.rolePermissions = new HashMap<String, PermissionCollection>();
        this.contextId = contextId;
    }
    
    public PermissionCollection getExcludedPermissions() {
        return this.excludedPermissions;
    }
    
    public PermissionCollection getUncheckedPermissions() {
        return this.uncheckedPermissions;
    }
    
    public Map<String, PermissionCollection> getRolePermissions() {
        return this.rolePermissions;
    }
    
    public String getContextID() {
        return this.contextId;
    }
}
