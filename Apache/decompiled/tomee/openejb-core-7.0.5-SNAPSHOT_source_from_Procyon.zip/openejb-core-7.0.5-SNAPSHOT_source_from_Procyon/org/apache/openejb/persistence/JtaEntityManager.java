// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.openejb.util.reflection.Reflections;
import org.apache.openejb.util.LogCategory;
import java.util.List;
import javax.persistence.EntityGraph;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.StoredProcedureQuery;
import java.io.ObjectStreamException;
import org.apache.openejb.core.ivm.IntraVmArtifact;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.metamodel.Metamodel;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.EntityTransaction;
import java.lang.reflect.InvocationTargetException;
import org.apache.openejb.OpenEJBRuntimeException;
import javax.persistence.TypedQuery;
import javax.persistence.Query;
import javax.persistence.LockModeType;
import javax.persistence.FlushModeType;
import javax.persistence.TransactionRequiredException;
import java.lang.reflect.Modifier;
import org.apache.openejb.assembler.classic.ReloadableEntityManagerFactory;
import org.apache.openejb.loader.SystemInstance;
import java.util.Locale;
import javax.persistence.SynchronizationType;
import java.util.Map;
import javax.persistence.EntityManagerFactory;
import java.util.concurrent.ConcurrentMap;
import java.lang.reflect.Method;
import org.apache.openejb.util.Logger;
import java.io.Serializable;
import javax.persistence.EntityManager;

public class JtaEntityManager implements EntityManager, Serializable
{
    private static final Logger baseLogger;
    private static final Method CREATE_NAMED_QUERY_FROM_NAME;
    private static final Method CREATE_QUERY_FROM_NAME;
    private static final Method CREATE_NATIVE_FROM_NAME;
    private static final Method CREATE_NAMED_QUERY_FROM_NAME_CLASS;
    private static final Method CREATE_QUERY_FROM_NAME_CLASS;
    private static final Method CREATE_QUERY_FROM_CRITERIA;
    private static final Method CREATE_NATIVE_FROM_NAME_CLASS;
    private static final Method CREATE_NATIVE_FROM_NAME_MAPPING;
    private static final ConcurrentMap<Class<?>, Boolean> IS_JPA21;
    private final JtaEntityManagerRegistry registry;
    private final EntityManagerFactory entityManagerFactory;
    private final Map properties;
    private final boolean extended;
    private final SynchronizationType synchronizationType;
    private final String unitName;
    private final Logger logger;
    private final boolean wrapNoTxQueries;
    private final boolean timer;
    
    public JtaEntityManager(final JtaEntityManagerRegistry registry, final EntityManagerFactory entityManagerFactory, final Map properties, final String unitName, final String synchronizationType) {
        this(unitName, registry, entityManagerFactory, properties, false, synchronizationType);
    }
    
    public JtaEntityManager(final String unitName, final JtaEntityManagerRegistry registry, final EntityManagerFactory entityManagerFactory, final Map properties, final boolean extended, final String synchronizationType) {
        if (registry == null) {
            throw new NullPointerException("registry is null");
        }
        if (entityManagerFactory == null) {
            throw new NullPointerException("entityManagerFactory is null");
        }
        this.unitName = unitName;
        this.registry = registry;
        this.entityManagerFactory = entityManagerFactory;
        this.properties = properties;
        this.extended = extended;
        this.synchronizationType = ((!isJPA21(entityManagerFactory) || synchronizationType == null) ? null : SynchronizationType.valueOf(synchronizationType.toUpperCase(Locale.ENGLISH)));
        final String globalTimerConfig = SystemInstance.get().getProperty("openejb.jpa.timer");
        final Object localTimerConfig = (properties == null) ? null : properties.get("openejb.jpa.timer");
        this.timer = ((localTimerConfig == null) ? (globalTimerConfig == null || Boolean.parseBoolean(globalTimerConfig)) : Boolean.parseBoolean(localTimerConfig.toString()));
        this.logger = ((unitName == null) ? JtaEntityManager.baseLogger : JtaEntityManager.baseLogger.getChildLogger(unitName));
        final String wrapConfig = ReloadableEntityManagerFactory.class.isInstance(entityManagerFactory) ? ReloadableEntityManagerFactory.class.cast(entityManagerFactory).getUnitProperties().getProperty("openejb.jpa.query.wrap-no-tx", "true") : "true";
        this.wrapNoTxQueries = (wrapConfig == null || "true".equalsIgnoreCase(wrapConfig));
    }
    
    public static boolean isJPA21(final EntityManagerFactory entityManagerFactory) {
        return ReloadableEntityManagerFactory.class.isInstance(entityManagerFactory) ? hasMethod(ReloadableEntityManagerFactory.class.cast(entityManagerFactory).getEntityManagerFactoryCallable().getProvider(), "generateSchema", String.class, Map.class) : hasMethod(entityManagerFactory.getClass(), "createEntityManager", SynchronizationType.class);
    }
    
    private static boolean hasMethod(final Class<?> objectClass, final String name, final Class<?>... params) {
        try {
            Boolean result = JtaEntityManager.IS_JPA21.get(objectClass);
            if (result == null) {
                result = !Modifier.isAbstract(objectClass.getMethod(name, params).getModifiers());
                if (objectClass.getClassLoader() == JtaEntityManager.class.getClassLoader()) {
                    JtaEntityManager.IS_JPA21.putIfAbsent(objectClass, result);
                }
            }
            return result;
        }
        catch (Throwable e) {
            return false;
        }
    }
    
    EntityManager getEntityManager() {
        return this.registry.getEntityManager(this.entityManagerFactory, this.properties, this.extended, this.unitName, this.synchronizationType);
    }
    
    boolean isTransactionActive() {
        return this.registry.isTransactionActive();
    }
    
    private void assertTransactionActive() throws TransactionRequiredException {
        if (!this.extended && !this.isTransactionActive()) {
            throw new TransactionRequiredException();
        }
    }
    
    void closeIfNoTx(final EntityManager entityManager) {
        if (!this.extended && !this.isTransactionActive()) {
            entityManager.close();
            this.logger.debug("Closed EntityManager(unit=" + this.unitName + ", hashCode=" + entityManager.hashCode() + ")");
        }
    }
    
    public EntityManager getDelegate() {
        final Timer timer = Op.getDelegate.start(this.timer, this);
        try {
            final EntityManager em = this.getEntityManager();
            em.getDelegate();
            return em;
        }
        finally {
            timer.stop();
        }
    }
    
    public void persist(final Object entity) {
        this.assertTransactionActive();
        final Timer timer = Op.persist.start(this.timer, this);
        try {
            this.getEntityManager().persist(entity);
        }
        finally {
            timer.stop();
        }
    }
    
    public <T> T merge(final T entity) {
        this.assertTransactionActive();
        final Timer timer = Op.merge.start(this.timer, this);
        try {
            return (T)this.getEntityManager().merge((Object)entity);
        }
        finally {
            timer.stop();
        }
    }
    
    public void remove(final Object entity) {
        this.assertTransactionActive();
        final Timer timer = Op.remove.start(this.timer, this);
        try {
            this.getEntityManager().remove(entity);
        }
        finally {
            timer.stop();
        }
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey) {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.find.start(this.timer, this);
            try {
                return (T)entityManager.find((Class)entityClass, primaryKey);
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public <T> T getReference(final Class<T> entityClass, final Object primaryKey) {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.getReference.start(this.timer, this);
            try {
                return (T)entityManager.getReference((Class)entityClass, primaryKey);
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public void flush() {
        this.assertTransactionActive();
        final Timer timer = Op.flush.start(this.timer, this);
        try {
            this.getEntityManager().flush();
        }
        finally {
            timer.stop();
        }
    }
    
    public void setFlushMode(final FlushModeType flushMode) {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.setFlushMode.start(this.timer, this);
            try {
                entityManager.setFlushMode(flushMode);
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public FlushModeType getFlushMode() {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.getFlushMode.start(this.timer, this);
            try {
                return entityManager.getFlushMode();
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public void lock(final Object entity, final LockModeType lockMode) {
        this.assertTransactionActive();
        final Timer timer = Op.lock.start(this.timer, this);
        try {
            this.getEntityManager().lock(entity, lockMode);
        }
        finally {
            timer.stop();
        }
    }
    
    public void refresh(final Object entity) {
        this.assertTransactionActive();
        final Timer timer = Op.refresh.start(this.timer, this);
        try {
            this.getEntityManager().refresh(entity);
        }
        finally {
            timer.stop();
        }
    }
    
    public void clear() {
        if (!this.extended && !this.isTransactionActive()) {
            return;
        }
        final Timer timer = Op.clear.start(this.timer, this);
        try {
            this.getEntityManager().clear();
        }
        finally {
            timer.stop();
        }
    }
    
    public boolean contains(final Object entity) {
        final Timer timer = Op.contains.start(this.timer, this);
        try {
            return (this.extended || this.isTransactionActive()) && this.getEntityManager().contains(entity);
        }
        finally {
            timer.stop();
        }
    }
    
    public Query createQuery(final String qlString) {
        final Timer timer = Op.createQuery.start(this.timer, this);
        try {
            return this.proxyIfNoTx(JtaEntityManager.CREATE_QUERY_FROM_NAME, qlString);
        }
        finally {
            timer.stop();
        }
    }
    
    public Query createNamedQuery(final String name) {
        final Timer timer = Op.createNamedQuery.start(this.timer, this);
        try {
            return this.proxyIfNoTx(JtaEntityManager.CREATE_NAMED_QUERY_FROM_NAME, name);
        }
        finally {
            timer.stop();
        }
    }
    
    public Query createNativeQuery(final String sqlString) {
        final Timer timer = Op.createNativeQuery.start(this.timer, this);
        try {
            return this.proxyIfNoTx(JtaEntityManager.CREATE_NATIVE_FROM_NAME, sqlString);
        }
        finally {
            timer.stop();
        }
    }
    
    public Query createNativeQuery(final String sqlString, final Class resultClass) {
        final Timer timer = Op.createNativeQuery.start(this.timer, this);
        try {
            return this.proxyIfNoTx(JtaEntityManager.CREATE_NATIVE_FROM_NAME_CLASS, sqlString, resultClass);
        }
        finally {
            timer.stop();
        }
    }
    
    public Query createNativeQuery(final String sqlString, final String resultSetMapping) {
        final Timer timer = Op.createNativeQuery.start(this.timer, this);
        try {
            return this.proxyIfNoTx(JtaEntityManager.CREATE_NATIVE_FROM_NAME_MAPPING, sqlString, resultSetMapping);
        }
        finally {
            timer.stop();
        }
    }
    
    private Query proxyIfNoTx(final Method method, final Object... args) {
        if (this.wrapNoTxQueries && !this.extended && !this.isTransactionActive()) {
            return (Query)new JtaQuery(this.getEntityManager(), this, method, args);
        }
        return this.createQuery(Query.class, this.getEntityManager(), method, args);
    }
    
    private <T> TypedQuery<T> typedProxyIfNoTx(final Method method, final Object... args) {
        if (this.wrapNoTxQueries && !this.extended && !this.isTransactionActive()) {
            return (TypedQuery<T>)new JtaTypedQuery(this.getEntityManager(), this, method, args);
        }
        return (TypedQuery<T>)this.createQuery(TypedQuery.class, this.getEntityManager(), method, args);
    }
    
     <T> T createQuery(final Class<T> expected, final EntityManager entityManager, final Method method, final Object... args) {
        try {
            return expected.cast(method.invoke(entityManager, args));
        }
        catch (IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
        catch (InvocationTargetException e2) {
            final Throwable t = e2.getCause();
            if (RuntimeException.class.isInstance(t)) {
                throw RuntimeException.class.cast(t);
            }
            throw new OpenEJBRuntimeException(t.getMessage(), t);
        }
    }
    
    public void joinTransaction() {
        final Timer timer = Op.joinTransaction.start(this.timer, this);
        try {
            this.getDelegate().joinTransaction();
        }
        finally {
            timer.stop();
        }
    }
    
    public void close() {
        throw new IllegalStateException("PersistenceUnit(name=" + this.unitName + ") - entityManager.close() call - See JPA 2.0 section 7.9.1", new Exception().fillInStackTrace());
    }
    
    public boolean isOpen() {
        return true;
    }
    
    public EntityTransaction getTransaction() {
        throw new IllegalStateException("A JTA EntityManager can not use the EntityTransaction API.  See JPA 1.0 section 5.5");
    }
    
    public <T> TypedQuery<T> createNamedQuery(final String name, final Class<T> resultClass) {
        final Timer timer = Op.createNamedQuery.start(this.timer, this);
        try {
            return this.typedProxyIfNoTx(JtaEntityManager.CREATE_NAMED_QUERY_FROM_NAME_CLASS, name, resultClass);
        }
        finally {
            timer.stop();
        }
    }
    
    public <T> TypedQuery<T> createQuery(final CriteriaQuery<T> criteriaQuery) {
        final Timer timer = Op.createQuery.start(this.timer, this);
        try {
            return this.typedProxyIfNoTx(JtaEntityManager.CREATE_QUERY_FROM_CRITERIA, criteriaQuery);
        }
        finally {
            timer.stop();
        }
    }
    
    public <T> TypedQuery<T> createQuery(final String qlString, final Class<T> resultClass) {
        final Timer timer = Op.createQuery.start(this.timer, this);
        try {
            return this.typedProxyIfNoTx(JtaEntityManager.CREATE_QUERY_FROM_NAME_CLASS, qlString, resultClass);
        }
        finally {
            timer.stop();
        }
    }
    
    public void detach(final Object entity) {
        final Timer timer = Op.detach.start(this.timer, this);
        try {
            if (!this.extended && this.isTransactionActive()) {
                this.getEntityManager().detach(entity);
            }
        }
        finally {
            timer.stop();
        }
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey, final Map<String, Object> properties) {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.find.start(this.timer, this);
            try {
                return (T)entityManager.find((Class)entityClass, primaryKey, (Map)properties);
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey, final LockModeType lockMode) {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.find.start(this.timer, this);
            try {
                return (T)entityManager.find((Class)entityClass, primaryKey, lockMode);
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey, final LockModeType lockMode, final Map<String, Object> properties) {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.find.start(this.timer, this);
            try {
                return (T)entityManager.find((Class)entityClass, primaryKey, lockMode, (Map)properties);
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public EntityManagerFactory getEntityManagerFactory() {
        return this.entityManagerFactory;
    }
    
    public LockModeType getLockMode(final Object entity) {
        this.assertTransactionActive();
        final Timer timer = Op.getLockMode.start(this.timer, this);
        try {
            return this.getEntityManager().getLockMode(entity);
        }
        finally {
            timer.stop();
        }
    }
    
    public Metamodel getMetamodel() {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.getMetamodel.start(this.timer, this);
            try {
                return entityManager.getMetamodel();
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public Map<String, Object> getProperties() {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.getProperties.start(this.timer, this);
            try {
                return (Map<String, Object>)entityManager.getProperties();
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public CriteriaBuilder getCriteriaBuilder() {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.getCriteriaBuilder.start(this.timer, this);
            try {
                return entityManager.getCriteriaBuilder();
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public void lock(final Object entity, final LockModeType lockMode, final Map<String, Object> properties) {
        this.assertTransactionActive();
        final Timer timer = Op.lock.start(this.timer, this);
        try {
            this.getEntityManager().lock(entity, lockMode, (Map)properties);
        }
        finally {
            timer.stop();
        }
    }
    
    public void refresh(final Object entity, final Map<String, Object> properties) {
        this.assertTransactionActive();
        final Timer timer = Op.refresh.start(this.timer, this);
        try {
            this.getEntityManager().refresh(entity, (Map)properties);
        }
        finally {
            timer.stop();
        }
    }
    
    public void refresh(final Object entity, final LockModeType lockMode) {
        this.assertTransactionActive();
        final Timer timer = Op.refresh.start(this.timer, this);
        try {
            this.getEntityManager().refresh(entity, lockMode);
        }
        finally {
            timer.stop();
        }
    }
    
    public void refresh(final Object entity, final LockModeType lockMode, final Map<String, Object> properties) {
        this.assertTransactionActive();
        final Timer timer = Op.refresh.start(this.timer, this);
        try {
            this.getEntityManager().refresh(entity, lockMode, (Map)properties);
        }
        finally {
            timer.stop();
        }
    }
    
    public void setProperty(final String name, final Object value) {
        final EntityManager entityManager = this.getEntityManager();
        try {
            final Timer timer = Op.setProperty.start(this.timer, this);
            try {
                entityManager.setProperty(name, value);
            }
            finally {
                timer.stop();
            }
        }
        finally {
            this.closeIfNoTx(entityManager);
        }
    }
    
    public <T> T unwrap(final Class<T> cls) {
        return (T)this.getEntityManager().unwrap((Class)cls);
    }
    
    protected Object writeReplace() throws ObjectStreamException {
        return new IntraVmArtifact(this, true);
    }
    
    public StoredProcedureQuery createNamedStoredProcedureQuery(final String name) {
        final Timer timer = Op.createNamedStoredProcedureQuery.start(this.timer, this);
        try {
            return this.getEntityManager().createNamedStoredProcedureQuery(name);
        }
        finally {
            timer.stop();
        }
    }
    
    public StoredProcedureQuery createStoredProcedureQuery(final String procedureName) {
        final Timer timer = Op.createNamedStoredProcedureQuery.start(this.timer, this);
        try {
            return this.getEntityManager().createStoredProcedureQuery(procedureName);
        }
        finally {
            timer.stop();
        }
    }
    
    public StoredProcedureQuery createStoredProcedureQuery(final String procedureName, final Class... resultClasses) {
        final Timer timer = Op.createStoredProcedureQuery.start(this.timer, this);
        try {
            return this.getEntityManager().createStoredProcedureQuery(procedureName, resultClasses);
        }
        finally {
            timer.stop();
        }
    }
    
    public StoredProcedureQuery createStoredProcedureQuery(final String procedureName, final String... resultSetMappings) {
        final Timer timer = Op.createStoredProcedureQuery.start(this.timer, this);
        try {
            return this.getEntityManager().createStoredProcedureQuery(procedureName, resultSetMappings);
        }
        finally {
            timer.stop();
        }
    }
    
    public Query createQuery(final CriteriaUpdate updateQuery) {
        final Timer timer = Op.createQuery.start(this.timer, this);
        try {
            return this.getEntityManager().createQuery(updateQuery);
        }
        finally {
            timer.stop();
        }
    }
    
    public Query createQuery(final CriteriaDelete deleteQuery) {
        final Timer timer = Op.createQuery.start(this.timer, this);
        try {
            return this.getEntityManager().createQuery(deleteQuery);
        }
        finally {
            timer.stop();
        }
    }
    
    public <T> EntityGraph<T> createEntityGraph(final Class<T> rootType) {
        final Timer timer = Op.createEntityGraph.start(this.timer, this);
        try {
            return (EntityGraph<T>)this.getEntityManager().createEntityGraph((Class)rootType);
        }
        finally {
            timer.stop();
        }
    }
    
    public EntityGraph<?> createEntityGraph(final String graphName) {
        final Timer timer = Op.createEntityGraph.start(this.timer, this);
        try {
            return (EntityGraph<?>)this.getEntityManager().createEntityGraph(graphName);
        }
        finally {
            timer.stop();
        }
    }
    
    public EntityGraph<?> getEntityGraph(final String graphName) {
        final Timer timer = Op.getEntityGraph.start(this.timer, this);
        try {
            return (EntityGraph<?>)this.getEntityManager().getEntityGraph(graphName);
        }
        finally {
            timer.stop();
        }
    }
    
    public <T> List<EntityGraph<? super T>> getEntityGraphs(final Class<T> entityClass) {
        final Timer timer = Op.getEntityGraphs.start(this.timer, this);
        try {
            return (List<EntityGraph<? super T>>)this.getEntityManager().getEntityGraphs((Class)entityClass);
        }
        finally {
            timer.stop();
        }
    }
    
    public boolean isJoinedToTransaction() {
        final Timer timer = Op.isJoinedToTransaction.start(this.timer, this);
        try {
            return this.synchronizationType == null || this.getEntityManager().isJoinedToTransaction();
        }
        finally {
            timer.stop();
        }
    }
    
    static {
        baseLogger = Logger.getInstance(LogCategory.OPENEJB.createChild("persistence"), JtaEntityManager.class);
        CREATE_NAMED_QUERY_FROM_NAME = Reflections.findMethod("createNamedQuery", EntityManager.class, String.class);
        CREATE_QUERY_FROM_NAME = Reflections.findMethod("createQuery", EntityManager.class, String.class);
        CREATE_NATIVE_FROM_NAME = Reflections.findMethod("createNativeQuery", EntityManager.class, String.class);
        CREATE_NAMED_QUERY_FROM_NAME_CLASS = Reflections.findMethod("createNamedQuery", EntityManager.class, String.class, Class.class);
        CREATE_QUERY_FROM_NAME_CLASS = Reflections.findMethod("createQuery", EntityManager.class, String.class, Class.class);
        CREATE_QUERY_FROM_CRITERIA = Reflections.findMethod("createQuery", EntityManager.class, CriteriaQuery.class);
        CREATE_NATIVE_FROM_NAME_CLASS = Reflections.findMethod("createNativeQuery", EntityManager.class, String.class, Class.class);
        CREATE_NATIVE_FROM_NAME_MAPPING = Reflections.findMethod("createNativeQuery", EntityManager.class, String.class, String.class);
        IS_JPA21 = new ConcurrentHashMap<Class<?>, Boolean>();
    }
    
    public static class Timer
    {
        private final long start;
        private final Op operation;
        private final JtaEntityManager em;
        
        public Timer(final Op operation, final JtaEntityManager em) {
            this.start = System.nanoTime();
            this.operation = operation;
            this.em = em;
        }
        
        public void stop() {
            if (!this.em.logger.isDebugEnabled()) {
                return;
            }
            final long time = TimeUnit.MILLISECONDS.convert(System.nanoTime() - this.start, TimeUnit.NANOSECONDS);
            this.em.logger.debug("PersistenceUnit(name=" + this.em.unitName + ") - entityManager." + this.operation + " - " + time + "ms");
        }
    }
    
    private enum Op
    {
        clear, 
        close, 
        contains, 
        createNamedQuery, 
        createNativeQuery, 
        createQuery, 
        find, 
        flush, 
        getFlushMode, 
        getReference, 
        getTransaction, 
        lock, 
        merge, 
        refresh, 
        remove, 
        setFlushMode, 
        persist, 
        detach, 
        getLockMode, 
        unwrap, 
        setProperty, 
        getCriteriaBuilder, 
        getProperties, 
        getMetamodel, 
        joinTransaction, 
        getDelegate, 
        createNamedStoredProcedureQuery, 
        createStoredProcedureQuery, 
        createEntityGraph, 
        getEntityGraph, 
        getEntityGraphs, 
        isJoinedToTransaction;
        
        private static final Timer NOOP;
        
        public Timer start(final boolean timer, final JtaEntityManager em) {
            return timer ? new Timer(this, em) : Op.NOOP;
        }
        
        static {
            NOOP = new Timer(null, null) {
                @Override
                public void stop() {
                }
            };
        }
    }
}
