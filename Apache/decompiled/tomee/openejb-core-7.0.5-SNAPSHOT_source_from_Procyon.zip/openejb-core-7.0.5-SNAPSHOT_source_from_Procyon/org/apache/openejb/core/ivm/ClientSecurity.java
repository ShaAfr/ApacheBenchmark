// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

public class ClientSecurity
{
    private static Object clientIdentity;
    
    public static Object getIdentity() {
        return ClientSecurity.clientIdentity;
    }
    
    public static void setIdentity(final Object clientIdentity) {
        ClientSecurity.clientIdentity = clientIdentity;
    }
}
