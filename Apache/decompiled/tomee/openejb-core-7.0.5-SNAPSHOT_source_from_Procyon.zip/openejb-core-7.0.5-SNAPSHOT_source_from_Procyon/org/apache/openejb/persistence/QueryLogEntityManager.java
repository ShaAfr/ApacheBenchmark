// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import java.util.List;
import javax.persistence.EntityGraph;
import javax.persistence.metamodel.Metamodel;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.Query;
import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import java.util.Map;
import javax.persistence.EntityManager;

public class QueryLogEntityManager implements EntityManager
{
    private final EntityManager delegate;
    private final String level;
    
    public QueryLogEntityManager(final EntityManager entityManager, final String level) {
        this.delegate = entityManager;
        this.level = level;
    }
    
    public void persist(final Object entity) {
        this.delegate.persist(entity);
    }
    
    public <T> T merge(final T entity) {
        return (T)this.delegate.merge((Object)entity);
    }
    
    public void remove(final Object entity) {
        this.delegate.remove(entity);
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey) {
        return (T)this.delegate.find((Class)entityClass, primaryKey);
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey, final Map<String, Object> properties) {
        return (T)this.delegate.find((Class)entityClass, primaryKey, (Map)properties);
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey, final LockModeType lockMode) {
        return (T)this.delegate.find((Class)entityClass, primaryKey, lockMode);
    }
    
    public <T> T find(final Class<T> entityClass, final Object primaryKey, final LockModeType lockMode, final Map<String, Object> properties) {
        return (T)this.delegate.find((Class)entityClass, primaryKey, lockMode, (Map)properties);
    }
    
    public <T> T getReference(final Class<T> entityClass, final Object primaryKey) {
        return (T)this.delegate.getReference((Class)entityClass, primaryKey);
    }
    
    public void flush() {
        this.delegate.flush();
    }
    
    public void setFlushMode(final FlushModeType flushMode) {
        this.delegate.setFlushMode(flushMode);
    }
    
    public FlushModeType getFlushMode() {
        return this.delegate.getFlushMode();
    }
    
    public void lock(final Object entity, final LockModeType lockMode) {
        this.delegate.lock(entity, lockMode);
    }
    
    public void lock(final Object entity, final LockModeType lockMode, final Map<String, Object> properties) {
        this.delegate.lock(entity, lockMode, (Map)properties);
    }
    
    public void refresh(final Object entity) {
        this.delegate.refresh(entity);
    }
    
    public void refresh(final Object entity, final Map<String, Object> properties) {
        this.delegate.refresh(entity, (Map)properties);
    }
    
    public void refresh(final Object entity, final LockModeType lockMode) {
        this.delegate.refresh(entity, lockMode);
    }
    
    public void refresh(final Object entity, final LockModeType lockMode, final Map<String, Object> properties) {
        this.delegate.refresh(entity, lockMode, (Map)properties);
    }
    
    public void clear() {
        this.delegate.clear();
    }
    
    public void detach(final Object entity) {
        this.delegate.detach(entity);
    }
    
    public boolean contains(final Object entity) {
        return this.delegate.contains(entity);
    }
    
    public LockModeType getLockMode(final Object entity) {
        return this.delegate.getLockMode(entity);
    }
    
    public void setProperty(final String propertyName, final Object value) {
        this.delegate.setProperty(propertyName, value);
    }
    
    public Map<String, Object> getProperties() {
        return (Map<String, Object>)this.delegate.getProperties();
    }
    
    public Query createQuery(final String qlString) {
        return this.delegate.createQuery(qlString);
    }
    
    public <T> TypedQuery<T> createQuery(final CriteriaQuery<T> criteriaQuery) {
        return (TypedQuery<T>)new CriteriaLogQuery((javax.persistence.TypedQuery<Object>)this.delegate.createQuery((CriteriaQuery)criteriaQuery), this.level);
    }
    
    public Query createQuery(final CriteriaUpdate updateQuery) {
        return this.delegate.createQuery(updateQuery);
    }
    
    public Query createQuery(final CriteriaDelete deleteQuery) {
        return this.delegate.createQuery(deleteQuery);
    }
    
    public <T> TypedQuery<T> createQuery(final String qlString, final Class<T> resultClass) {
        return (TypedQuery<T>)this.delegate.createQuery(qlString, (Class)resultClass);
    }
    
    public Query createNamedQuery(final String name) {
        return this.delegate.createNamedQuery(name);
    }
    
    public <T> TypedQuery<T> createNamedQuery(final String name, final Class<T> resultClass) {
        return (TypedQuery<T>)this.delegate.createNamedQuery(name, (Class)resultClass);
    }
    
    public Query createNativeQuery(final String sqlString) {
        return this.delegate.createNativeQuery(sqlString);
    }
    
    public Query createNativeQuery(final String sqlString, final Class resultClass) {
        return this.delegate.createNativeQuery(sqlString, resultClass);
    }
    
    public Query createNativeQuery(final String sqlString, final String resultSetMapping) {
        return this.delegate.createNativeQuery(sqlString, resultSetMapping);
    }
    
    public StoredProcedureQuery createNamedStoredProcedureQuery(final String name) {
        return this.delegate.createNamedStoredProcedureQuery(name);
    }
    
    public StoredProcedureQuery createStoredProcedureQuery(final String procedureName) {
        return this.delegate.createStoredProcedureQuery(procedureName);
    }
    
    public StoredProcedureQuery createStoredProcedureQuery(final String procedureName, final Class... resultClasses) {
        return this.delegate.createStoredProcedureQuery(procedureName, resultClasses);
    }
    
    public StoredProcedureQuery createStoredProcedureQuery(final String procedureName, final String... resultSetMappings) {
        return this.delegate.createStoredProcedureQuery(procedureName, resultSetMappings);
    }
    
    public void joinTransaction() {
        this.delegate.joinTransaction();
    }
    
    public boolean isJoinedToTransaction() {
        return this.delegate.isJoinedToTransaction();
    }
    
    public <T> T unwrap(final Class<T> cls) {
        return (T)this.delegate.unwrap((Class)cls);
    }
    
    public Object getDelegate() {
        return this.delegate.getDelegate();
    }
    
    public void close() {
        this.delegate.close();
    }
    
    public boolean isOpen() {
        return this.delegate.isOpen();
    }
    
    public EntityTransaction getTransaction() {
        return this.delegate.getTransaction();
    }
    
    public EntityManagerFactory getEntityManagerFactory() {
        return this.delegate.getEntityManagerFactory();
    }
    
    public CriteriaBuilder getCriteriaBuilder() {
        return this.delegate.getCriteriaBuilder();
    }
    
    public Metamodel getMetamodel() {
        return this.delegate.getMetamodel();
    }
    
    public <T> EntityGraph<T> createEntityGraph(final Class<T> rootType) {
        return (EntityGraph<T>)this.delegate.createEntityGraph((Class)rootType);
    }
    
    public EntityGraph<?> createEntityGraph(final String graphName) {
        return (EntityGraph<?>)this.delegate.createEntityGraph(graphName);
    }
    
    public EntityGraph<?> getEntityGraph(final String graphName) {
        return (EntityGraph<?>)this.delegate.getEntityGraph(graphName);
    }
    
    public <T> List<EntityGraph<? super T>> getEntityGraphs(final Class<T> entityClass) {
        return (List<EntityGraph<? super T>>)this.delegate.getEntityGraphs((Class)entityClass);
    }
}
