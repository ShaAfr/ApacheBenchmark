// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.testng;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class PropertiesBuilder
{
    private final Properties properties;
    
    public PropertiesBuilder() {
        this.properties = new Properties();
    }
    
    public PropertiesBuilder p(final String key, final String value) {
        return this.property(key, value);
    }
    
    public PropertiesBuilder property(final String key, final String value) {
        this.properties.setProperty(key, value);
        return this;
    }
    
    public Properties build() {
        return this.properties;
    }
    
    public Map<String, String> asMap() {
        final Map<String, String> map = new HashMap<String, String>();
        for (final Map.Entry<Object, Object> entry : this.properties.entrySet()) {
            map.put(String.class.cast(entry.getKey()), String.class.cast(entry.getValue()));
        }
        return map;
    }
}
