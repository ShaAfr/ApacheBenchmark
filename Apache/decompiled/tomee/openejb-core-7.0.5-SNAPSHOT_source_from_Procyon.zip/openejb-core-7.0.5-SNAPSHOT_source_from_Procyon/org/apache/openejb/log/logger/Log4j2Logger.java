// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log.logger;

import java.util.HashMap;
import java.util.logging.LogRecord;
import org.apache.openejb.util.reflection.Reflections;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.logging.Level;
import java.util.Map;

public class Log4j2Logger extends AbstractDelegatingLogger
{
    private static final Map<Level, org.apache.logging.log4j.Level> TO_LOG4J;
    private final org.apache.logging.log4j.Logger log;
    
    public Log4j2Logger(final String name, final String resourceBundleName) {
        super(name, resourceBundleName);
        this.log = LogManager.getLogger(name);
    }
    
    @Override
    public void setLevel(final Level newLevel) throws SecurityException {
        try {
            Reflections.invokeByReflection(this.log, "setLevel", new Class[] { org.apache.logging.log4j.Level.class }, new Object[] { Log4j2Logger.TO_LOG4J.get(newLevel) });
        }
        catch (Throwable t) {}
    }
    
    @Override
    public Level getLevel() {
        final org.apache.logging.log4j.Level l = this.log.getLevel();
        if (l != null) {
            return this.fromL4J(l);
        }
        return null;
    }
    
    @Override
    protected void internalLogFormatted(final String msg, final LogRecord record) {
        this.log.log((org.apache.logging.log4j.Level)Log4j2Logger.TO_LOG4J.get(record.getLevel()), msg, record.getThrown());
    }
    
    private Level fromL4J(final org.apache.logging.log4j.Level l) {
        Level l2 = null;
        switch (l.getStandardLevel()) {
            case ALL: {
                l2 = Level.ALL;
                break;
            }
            case FATAL: {
                l2 = Level.SEVERE;
                break;
            }
            case ERROR: {
                l2 = Level.SEVERE;
                break;
            }
            case WARN: {
                l2 = Level.WARNING;
                break;
            }
            case INFO: {
                l2 = Level.INFO;
                break;
            }
            case DEBUG: {
                l2 = Level.FINE;
                break;
            }
            case OFF: {
                l2 = Level.OFF;
                break;
            }
            case TRACE: {
                l2 = Level.FINEST;
                break;
            }
            default: {
                l2 = Level.FINE;
                break;
            }
        }
        return l2;
    }
    
    static {
        TO_LOG4J = new HashMap<Level, org.apache.logging.log4j.Level>();
        final org.apache.logging.log4j.Level t = org.apache.logging.log4j.Level.DEBUG;
        Log4j2Logger.TO_LOG4J.put(Level.ALL, org.apache.logging.log4j.Level.ALL);
        Log4j2Logger.TO_LOG4J.put(Level.SEVERE, org.apache.logging.log4j.Level.ERROR);
        Log4j2Logger.TO_LOG4J.put(Level.WARNING, org.apache.logging.log4j.Level.WARN);
        Log4j2Logger.TO_LOG4J.put(Level.INFO, org.apache.logging.log4j.Level.INFO);
        Log4j2Logger.TO_LOG4J.put(Level.CONFIG, org.apache.logging.log4j.Level.DEBUG);
        Log4j2Logger.TO_LOG4J.put(Level.FINE, org.apache.logging.log4j.Level.DEBUG);
        Log4j2Logger.TO_LOG4J.put(Level.FINER, org.apache.logging.log4j.Level.TRACE);
        Log4j2Logger.TO_LOG4J.put(Level.FINEST, org.apache.logging.log4j.Level.TRACE);
        Log4j2Logger.TO_LOG4J.put(Level.OFF, org.apache.logging.log4j.Level.OFF);
    }
}
