// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class DefaultLockFactory implements LockFactory
{
    @Override
    public StatefulLock newLock(final String beanId) {
        return new DefaultLock();
    }
    
    @Override
    public void setContainer(final StatefulContainer statefulContainer) {
    }
    
    public static class DefaultLock implements StatefulLock
    {
        private final ReentrantLock lock;
        
        public DefaultLock() {
            this.lock = new ReentrantLock();
        }
        
        @Override
        public void lock() {
            this.lock.lock();
        }
        
        @Override
        public void unlock() {
            this.lock.unlock();
        }
        
        @Override
        public boolean isHeldByCurrentThread() {
            return this.lock.isHeldByCurrentThread();
        }
        
        @Override
        public boolean tryLock() {
            return this.lock.tryLock();
        }
        
        @Override
        public boolean tryLock(final long time, final TimeUnit unit) throws InterruptedException {
            return this.lock.tryLock(time, unit);
        }
    }
}
