// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.entity;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.SystemException;
import org.apache.openejb.core.ExceptionType;
import java.lang.reflect.InvocationTargetException;
import javax.ejb.Timer;
import org.apache.openejb.core.timer.EjbTimerServiceImpl;
import java.util.Iterator;
import org.apache.openejb.util.ArrayEnumeration;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Collection;
import org.apache.openejb.ProxyInfo;
import javax.ejb.NoSuchEntityException;
import java.rmi.NoSuchObjectException;
import org.apache.openejb.core.transaction.TransactionType;
import javax.ejb.EntityBean;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import org.apache.openejb.core.Operation;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.ApplicationException;
import javax.ejb.EJBAccessException;
import org.apache.openejb.core.ThreadContext;
import java.lang.reflect.Method;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.core.timer.EjbTimerService;
import org.apache.openejb.Container;
import org.apache.openejb.ContainerType;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.loader.SystemInstance;
import javax.transaction.TransactionSynchronizationRegistry;
import java.util.HashMap;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.Logger;
import org.apache.openejb.BeanContext;
import java.util.Map;
import org.apache.openejb.RpcContainer;

public class EntityContainer implements RpcContainer
{
    private final EntityInstanceManager instanceManager;
    private final Map<String, BeanContext> deploymentRegistry;
    private final Object containerID;
    public static Logger logger;
    private final SecurityService securityService;
    protected EntrancyTracker entrancyTracker;
    
    public EntityContainer(final Object id, final SecurityService securityService, final int poolSize) throws OpenEJBException {
        this.deploymentRegistry = new HashMap<String, BeanContext>();
        this.containerID = id;
        this.securityService = securityService;
        this.entrancyTracker = new EntrancyTracker((TransactionSynchronizationRegistry)SystemInstance.get().getComponent((Class)TransactionSynchronizationRegistry.class));
        this.instanceManager = new EntityInstanceManager(this, securityService, poolSize);
    }
    
    @Override
    public synchronized BeanContext[] getBeanContexts() {
        return this.deploymentRegistry.values().toArray(new BeanContext[this.deploymentRegistry.size()]);
    }
    
    @Override
    public synchronized BeanContext getBeanContext(final Object deploymentID) {
        final String id = (String)deploymentID;
        return this.deploymentRegistry.get(id);
    }
    
    @Override
    public ContainerType getContainerType() {
        return ContainerType.BMP_ENTITY;
    }
    
    @Override
    public Object getContainerID() {
        return this.containerID;
    }
    
    @Override
    public void deploy(final BeanContext beanContext) throws OpenEJBException {
        synchronized (this) {
            this.deploymentRegistry.put((String)beanContext.getDeploymentID(), beanContext);
            beanContext.setContainer(this);
        }
        this.instanceManager.deploy(beanContext);
    }
    
    @Override
    public void start(final BeanContext info) throws OpenEJBException {
        final EjbTimerService timerService = info.getEjbTimerService();
        if (timerService != null) {
            timerService.start();
        }
    }
    
    @Override
    public void stop(final BeanContext info) throws OpenEJBException {
        info.stop();
    }
    
    @Override
    public void undeploy(final BeanContext info) throws OpenEJBException {
        this.instanceManager.undeploy(info);
        synchronized (this) {
            final String id = (String)info.getDeploymentID();
            this.deploymentRegistry.remove(id);
            info.setContainer(null);
        }
    }
    
    @Override
    public Object invoke(final Object deployID, InterfaceType type, final Class callInterface, final Method callMethod, final Object[] args, final Object primKey) throws OpenEJBException {
        final BeanContext beanContext = this.getBeanContext(deployID);
        if (beanContext == null) {
            throw new OpenEJBException("Deployment does not exist in this container. Deployment(id='" + deployID + "'), Container(id='" + this.containerID + "')");
        }
        if (type == null) {
            type = beanContext.getInterfaceType(callInterface);
        }
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            final boolean authorized = type == InterfaceType.TIMEOUT || this.getSecurityService().isCallerAuthorized(callMethod, type);
            if (!authorized) {
                throw new ApplicationException((Exception)new EJBAccessException("Unauthorized Access by Principal Denied"));
            }
            final Class declaringClass = callMethod.getDeclaringClass();
            final String methodName = callMethod.getName();
            if (EJBHome.class.isAssignableFrom(declaringClass) || EJBLocalHome.class.isAssignableFrom(declaringClass)) {
                if (declaringClass != EJBHome.class && declaringClass != EJBLocalHome.class) {
                    if (methodName.startsWith("create")) {
                        return this.createEJBObject(callMethod, args, callContext, type);
                    }
                    if (methodName.startsWith("find")) {
                        return this.findMethod(callMethod, args, callContext, type);
                    }
                    return this.homeMethod(callMethod, args, callContext, type);
                }
                else if (methodName.equals("remove")) {
                    this.removeEJBObject(callMethod, args, callContext, type);
                    return null;
                }
            }
            else if ((EJBObject.class == declaringClass || EJBLocalObject.class == declaringClass) && methodName.equals("remove")) {
                this.removeEJBObject(callMethod, args, callContext, type);
                return null;
            }
            callContext.setCurrentOperation((type == InterfaceType.TIMEOUT) ? Operation.TIMEOUT : Operation.BUSINESS);
            final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
            callContext.set(Method.class, runMethod);
            return this.invoke(type, callMethod, runMethod, args, callContext);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private SecurityService getSecurityService() {
        return this.securityService;
    }
    
    public EntityInstanceManager getInstanceManager() {
        return this.instanceManager;
    }
    
    protected Object invoke(final InterfaceType type, final Method callMethod, final Method runMethod, final Object[] args, final ThreadContext callContext) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, type), callContext);
        EntityBean bean = null;
        Object returnValue = null;
        this.entrancyTracker.enter(callContext.getBeanContext(), callContext.getPrimaryKey());
        try {
            bean = this.instanceManager.obtainInstance(callContext);
            this.ejbLoad_If_No_Transaction(callContext, bean);
            returnValue = runMethod.invoke(bean, args);
            this.ejbStore_If_No_Transaction(callContext, bean);
            this.instanceManager.poolInstance(callContext, bean, callContext.getPrimaryKey());
        }
        catch (Throwable e) {
            this.handleException(txPolicy, e, callContext, bean);
        }
        finally {
            this.entrancyTracker.exit(callContext.getBeanContext(), callContext.getPrimaryKey());
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        return returnValue;
    }
    
    public void ejbLoad_If_No_Transaction(final ThreadContext callContext, final EntityBean bean) throws Exception {
        final Operation orginalOperation = callContext.getCurrentOperation();
        if (orginalOperation == Operation.BUSINESS || orginalOperation == Operation.REMOVE) {
            final TransactionPolicy callerTxPolicy = callContext.getTransactionPolicy();
            if (callerTxPolicy != null && callerTxPolicy.isTransactionActive()) {
                return;
            }
            final BeanContext beanContext = callContext.getBeanContext();
            final TransactionPolicy txPolicy = beanContext.getTransactionPolicyFactory().createTransactionPolicy(TransactionType.Supports);
            try {
                if (!txPolicy.isTransactionActive()) {
                    callContext.setCurrentOperation(Operation.LOAD);
                    bean.ejbLoad();
                }
            }
            catch (NoSuchEntityException e2) {
                this.instanceManager.discardInstance(callContext, bean);
                throw new ApplicationException(new NoSuchObjectException("Entity not found: " + callContext.getPrimaryKey()));
            }
            catch (Exception e) {
                this.instanceManager.discardInstance(callContext, bean);
                throw e;
            }
            finally {
                callContext.setCurrentOperation(orginalOperation);
                txPolicy.commit();
            }
        }
    }
    
    public void ejbStore_If_No_Transaction(final ThreadContext callContext, final EntityBean bean) throws Exception {
        final Operation currentOp = callContext.getCurrentOperation();
        if (currentOp == Operation.BUSINESS) {
            final TransactionPolicy callerTxPolicy = callContext.getTransactionPolicy();
            if (callerTxPolicy != null && callerTxPolicy.isTransactionActive()) {
                return;
            }
            final BeanContext beanContext = callContext.getBeanContext();
            final TransactionPolicy txPolicy = beanContext.getTransactionPolicyFactory().createTransactionPolicy(TransactionType.Supports);
            try {
                if (!txPolicy.isTransactionActive()) {
                    callContext.setCurrentOperation(Operation.STORE);
                    bean.ejbStore();
                }
            }
            catch (Exception e) {
                this.instanceManager.discardInstance(callContext, bean);
                throw e;
            }
            finally {
                callContext.setCurrentOperation(currentOp);
                txPolicy.commit();
            }
        }
    }
    
    protected void didCreateBean(final ThreadContext callContext, final EntityBean bean) throws OpenEJBException {
    }
    
    protected ProxyInfo createEJBObject(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType type) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        callContext.setCurrentOperation(Operation.CREATE);
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, type), callContext);
        EntityBean bean = null;
        Object primaryKey = null;
        try {
            bean = this.instanceManager.obtainInstance(callContext);
            final Method ejbCreateMethod = beanContext.getMatchingBeanMethod(callMethod);
            primaryKey = ejbCreateMethod.invoke(bean, args);
            this.didCreateBean(callContext, bean);
            final Method ejbPostCreateMethod = beanContext.getMatchingPostCreateMethod(ejbCreateMethod);
            final ThreadContext postCreateContext = new ThreadContext(beanContext, primaryKey);
            postCreateContext.setCurrentOperation(Operation.POST_CREATE);
            final ThreadContext oldContext = ThreadContext.enter(postCreateContext);
            try {
                ejbPostCreateMethod.invoke(bean, args);
            }
            finally {
                ThreadContext.exit(oldContext);
            }
            this.instanceManager.poolInstance(callContext, bean, primaryKey);
        }
        catch (Throwable e) {
            this.handleException(txPolicy, e, callContext, bean);
        }
        finally {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        return new ProxyInfo(beanContext, primaryKey);
    }
    
    protected Object findMethod(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType type) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        callContext.setCurrentOperation(Operation.FIND);
        final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
        Object returnValue = this.invoke(type, callMethod, runMethod, args, callContext);
        if (returnValue instanceof Collection) {
            final Iterator keys = ((Collection)returnValue).iterator();
            final Vector<ProxyInfo> proxies = new Vector<ProxyInfo>();
            while (keys.hasNext()) {
                final Object primaryKey = keys.next();
                proxies.addElement(new ProxyInfo(beanContext, primaryKey));
            }
            returnValue = proxies;
        }
        else if (returnValue instanceof Enumeration) {
            final Enumeration keys2 = (Enumeration)returnValue;
            final Vector<ProxyInfo> proxies = new Vector<ProxyInfo>();
            while (keys2.hasMoreElements()) {
                final Object primaryKey = keys2.nextElement();
                proxies.addElement(new ProxyInfo(beanContext, primaryKey));
            }
            returnValue = new ArrayEnumeration(proxies);
        }
        else {
            returnValue = new ProxyInfo(beanContext, returnValue);
        }
        return returnValue;
    }
    
    protected Object homeMethod(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType type) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        callContext.setCurrentOperation(Operation.HOME);
        final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
        return this.invoke(type, callMethod, runMethod, args, callContext);
    }
    
    protected void didRemove(final EntityBean bean, final ThreadContext threadContext) throws OpenEJBException {
        this.cancelTimers(threadContext);
    }
    
    private void cancelTimers(final ThreadContext threadContext) {
        final BeanContext beanContext = threadContext.getBeanContext();
        final Object primaryKey = threadContext.getPrimaryKey();
        if (primaryKey != null) {
            final EjbTimerService timerService = beanContext.getEjbTimerService();
            if (timerService != null && timerService instanceof EjbTimerServiceImpl) {
                for (final Timer timer : beanContext.getEjbTimerService().getTimers(primaryKey)) {
                    timer.cancel();
                }
            }
        }
    }
    
    protected void removeEJBObject(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType type) throws OpenEJBException {
        callContext.setCurrentOperation(Operation.REMOVE);
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, type), callContext);
        EntityBean bean = null;
        try {
            bean = this.instanceManager.obtainInstance(callContext);
            this.ejbLoad_If_No_Transaction(callContext, bean);
            bean.ejbRemove();
            this.didRemove(bean, callContext);
            this.instanceManager.poolInstance(callContext, bean, callContext.getPrimaryKey());
        }
        catch (Throwable e) {
            this.handleException(txPolicy, e, callContext, bean);
        }
        finally {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
    }
    
    private void handleException(final TransactionPolicy txPolicy, Throwable e, final ThreadContext callContext, final EntityBean bean) throws OpenEJBException {
        ExceptionType type;
        if (e instanceof InvocationTargetException) {
            e = ((InvocationTargetException)e).getTargetException();
            type = callContext.getBeanContext().getExceptionType(e);
        }
        else if (e instanceof ApplicationException) {
            e = ((ApplicationException)e).getRootCause();
            type = ExceptionType.APPLICATION;
        }
        else if (e instanceof SystemException) {
            e = ((SystemException)e).getRootCause();
            type = ExceptionType.SYSTEM;
        }
        else {
            type = ExceptionType.SYSTEM;
        }
        if (type == ExceptionType.SYSTEM) {
            if (bean != null) {
                try {
                    this.instanceManager.discardInstance(callContext, bean);
                }
                catch (SystemException e2) {
                    EntityContainer.logger.error("The instance manager encountered an unkown system exception while trying to discard the entity instance with primary key " + callContext.getPrimaryKey());
                }
            }
            EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
        }
        else {
            this.instanceManager.poolInstance(callContext, bean, callContext.getPrimaryKey());
            EjbTransactionUtil.handleApplicationException(txPolicy, e, type == ExceptionType.APPLICATION_ROLLBACK);
        }
    }
    
    static {
        EntityContainer.logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
}
