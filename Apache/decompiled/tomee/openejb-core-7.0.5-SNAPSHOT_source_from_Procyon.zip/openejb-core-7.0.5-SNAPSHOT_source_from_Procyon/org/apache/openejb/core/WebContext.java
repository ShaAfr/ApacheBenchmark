// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.util.Iterator;
import org.apache.openejb.util.Logger;
import org.apache.openejb.util.LogCategory;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.http.HttpSessionIdListener;
import javax.servlet.http.HttpSessionActivationListener;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionListener;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletRequestListener;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSessionAttributeListener;
import java.util.EventListener;
import javax.servlet.Filter;
import javax.servlet.Servlet;
import javax.enterprise.inject.spi.AnnotatedType;
import java.lang.annotation.Annotation;
import org.apache.webbeans.component.InjectionTargetBean;
import org.apache.openejb.InjectionProcessor;
import javax.enterprise.context.spi.Contextual;
import org.apache.openejb.OpenEJBException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import javax.naming.NamingException;
import javax.naming.InitialContext;
import org.apache.openejb.cdi.ConstructorInjectionBean;
import javax.servlet.ServletContext;
import org.apache.webbeans.config.WebBeansContext;
import javax.enterprise.context.spi.CreationalContext;
import java.util.concurrent.ConcurrentMap;
import java.util.Map;
import org.apache.openejb.AppContext;
import javax.naming.Context;
import org.apache.openejb.Injection;
import java.util.Collection;

public class WebContext
{
    private String id;
    private ClassLoader classLoader;
    private final Collection<Injection> injections;
    private Context jndiEnc;
    private final AppContext appContext;
    private Map<String, Object> bindings;
    private final ConcurrentMap<Object, CreationalContext<?>> creationalContexts;
    private WebBeansContext webbeansContext;
    private String contextRoot;
    private String host;
    private Context initialContext;
    private ServletContext servletContext;
    private final Map<Class<?>, ConstructorInjectionBean<Object>> constructorInjectionBeanCache;
    
    public Context getInitialContext() {
        if (this.initialContext != null) {
            return this.initialContext;
        }
        try {
            this.initialContext = (Context)new InitialContext().lookup("java:");
        }
        catch (NamingException e) {
            throw new IllegalStateException(e);
        }
        return this.initialContext;
    }
    
    public ServletContext getServletContext() {
        return this.servletContext;
    }
    
    public void setServletContext(final ServletContext servletContext) {
        this.servletContext = servletContext;
    }
    
    public void setHost(final String host) {
        this.host = host;
    }
    
    public String getHost() {
        return this.host;
    }
    
    public void setInitialContext(final Context initialContext) {
        this.initialContext = initialContext;
    }
    
    public WebContext(final AppContext appContext) {
        this.injections = new ArrayList<Injection>();
        this.creationalContexts = new ConcurrentHashMap<Object, CreationalContext<?>>();
        this.constructorInjectionBeanCache = new ConcurrentHashMap<Class<?>, ConstructorInjectionBean<Object>>();
        this.appContext = appContext;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public ClassLoader getClassLoader() {
        return this.classLoader;
    }
    
    public void setClassLoader(final ClassLoader classLoader) {
        this.classLoader = classLoader;
    }
    
    public Collection<Injection> getInjections() {
        return this.injections;
    }
    
    public Context getJndiEnc() {
        return this.jndiEnc;
    }
    
    public void setJndiEnc(final Context jndiEnc) {
        this.jndiEnc = jndiEnc;
    }
    
    public AppContext getAppContext() {
        return this.appContext;
    }
    
    public <T> Instance newWeakableInstance(final Class<T> beanClass) throws OpenEJBException {
        final WebBeansContext webBeansContext = this.getWebBeansContext();
        final ConstructorInjectionBean<Object> beanDefinition = this.getConstructorInjectionBean(beanClass, webBeansContext);
        CreationalContext<Object> creationalContext = null;
        Object o = null;
        Label_0058: {
            if (webBeansContext == null) {
                creationalContext = null;
                try {
                    o = beanClass.newInstance();
                    break Label_0058;
                }
                catch (InstantiationException | IllegalAccessException ex2) {
                    final ReflectiveOperationException ex;
                    final ReflectiveOperationException e = ex;
                    throw new OpenEJBException(e);
                }
            }
            creationalContext = (CreationalContext<Object>)webBeansContext.getBeanManagerImpl().createCreationalContext((Contextual)beanDefinition);
            o = beanDefinition.create((CreationalContext)creationalContext);
        }
        final Context unwrap = InjectionProcessor.unwrap(this.getInitialContext());
        final InjectionProcessor injectionProcessor = new InjectionProcessor((T)o, this.injections, unwrap);
        Object beanInstance;
        try {
            beanInstance = injectionProcessor.createInstance();
            if (webBeansContext != null) {
                final InjectionTargetBean<Object> bean = (InjectionTargetBean<Object>)InjectionTargetBean.class.cast(beanDefinition);
                bean.getInjectionTarget().inject(beanInstance, (CreationalContext)creationalContext);
                if (this.shouldBeReleased(bean.getScope())) {
                    this.creationalContexts.put(beanInstance, creationalContext);
                }
            }
        }
        catch (OpenEJBException oejbe) {
            if (creationalContext != null) {
                creationalContext.release();
            }
            throw oejbe;
        }
        return new Instance(beanInstance, creationalContext);
    }
    
    public Object newInstance(final Class beanClass) throws OpenEJBException {
        return this.newWeakableInstance((Class<Object>)beanClass).getValue();
    }
    
    private ConstructorInjectionBean<Object> getConstructorInjectionBean(final Class beanClass, final WebBeansContext webBeansContext) {
        if (webBeansContext == null) {
            return null;
        }
        ConstructorInjectionBean<Object> beanDefinition = this.constructorInjectionBeanCache.get(beanClass);
        if (beanDefinition == null) {
            synchronized (this) {
                beanDefinition = this.constructorInjectionBeanCache.get(beanClass);
                if (beanDefinition == null) {
                    final AnnotatedType annotatedType = webBeansContext.getAnnotatedElementFactory().newAnnotatedType(beanClass);
                    if (isWeb(beanClass)) {
                        beanDefinition = new ConstructorInjectionBean<Object>(webBeansContext, beanClass, (javax.enterprise.inject.spi.AnnotatedType<Object>)annotatedType, false);
                    }
                    else {
                        beanDefinition = new ConstructorInjectionBean<Object>(webBeansContext, beanClass, (javax.enterprise.inject.spi.AnnotatedType<Object>)annotatedType);
                    }
                    this.constructorInjectionBeanCache.put(beanClass, beanDefinition);
                }
            }
        }
        return beanDefinition;
    }
    
    private static boolean isWeb(final Class<?> beanClass) {
        return Servlet.class.isAssignableFrom(beanClass) || Filter.class.isAssignableFrom(beanClass) || (EventListener.class.isAssignableFrom(beanClass) && (HttpSessionAttributeListener.class.isAssignableFrom(beanClass) || ServletContextListener.class.isAssignableFrom(beanClass) || ServletRequestListener.class.isAssignableFrom(beanClass) || ServletContextAttributeListener.class.isAssignableFrom(beanClass) || HttpSessionListener.class.isAssignableFrom(beanClass) || HttpSessionBindingListener.class.isAssignableFrom(beanClass) || HttpSessionActivationListener.class.isAssignableFrom(beanClass) || HttpSessionIdListener.class.isAssignableFrom(beanClass) || ServletRequestAttributeListener.class.isAssignableFrom(beanClass)));
    }
    
    public WebBeansContext getWebBeansContext() {
        if (this.webbeansContext == null) {
            return this.getAppContext().getWebBeansContext();
        }
        return this.webbeansContext;
    }
    
    public Object inject(final Object o) throws OpenEJBException {
        try {
            final WebBeansContext webBeansContext = this.getWebBeansContext();
            final Context initialContext = (Context)new InitialContext().lookup("java:");
            final Context unwrap = InjectionProcessor.unwrap(initialContext);
            final InjectionProcessor injectionProcessor = new InjectionProcessor((T)o, this.injections, unwrap);
            final Object beanInstance = injectionProcessor.createInstance();
            if (webBeansContext != null) {
                final ConstructorInjectionBean<Object> beanDefinition = this.getConstructorInjectionBean(o.getClass(), webBeansContext);
                final CreationalContext<Object> creationalContext = (CreationalContext<Object>)webBeansContext.getBeanManagerImpl().createCreationalContext((Contextual)beanDefinition);
                final InjectionTargetBean<Object> bean = (InjectionTargetBean<Object>)InjectionTargetBean.class.cast(beanDefinition);
                bean.getInjectionTarget().inject(beanInstance, (CreationalContext)creationalContext);
                if (this.shouldBeReleased(beanDefinition.getScope())) {
                    this.creationalContexts.put(beanInstance, creationalContext);
                }
            }
            return beanInstance;
        }
        catch (NamingException | OpenEJBException ex2) {
            final Exception ex;
            final Exception e = ex;
            throw new OpenEJBException(e);
        }
    }
    
    private boolean shouldBeReleased(final Class<? extends Annotation> scope) {
        return scope == null || !this.getWebBeansContext().getBeanManagerImpl().isNormalScope((Class)scope);
    }
    
    public void setBindings(final Map<String, Object> bindings) {
        this.bindings = bindings;
    }
    
    public Map<String, Object> getBindings() {
        return this.bindings;
    }
    
    public void setWebbeansContext(final WebBeansContext webbeansContext) {
        this.webbeansContext = webbeansContext;
    }
    
    public WebBeansContext getWebbeansContext() {
        return this.webbeansContext;
    }
    
    public void setContextRoot(final String contextRoot) {
        this.contextRoot = contextRoot;
    }
    
    public String getContextRoot() {
        return this.contextRoot;
    }
    
    public void destroy(final Object o) {
        final CreationalContext<?> ctx = (CreationalContext<?>)this.creationalContexts.remove(o);
        if (ctx != null) {
            ctx.release();
        }
    }
    
    public void release() {
        for (final CreationalContext<?> cc : this.creationalContexts.values()) {
            try {
                cc.release();
            }
            catch (RuntimeException re) {
                Logger.getInstance(LogCategory.OPENEJB, WebContext.class.getName()).warning("Can't release properly a creational context", re);
            }
        }
        this.creationalContexts.clear();
    }
    
    public static class Instance
    {
        private final Object value;
        private final CreationalContext<?> cc;
        
        public Instance(final Object value, final CreationalContext<?> cc) {
            this.value = value;
            this.cc = cc;
        }
        
        public Object getValue() {
            return this.value;
        }
        
        public CreationalContext<?> getCreationalContext() {
            return this.cc;
        }
    }
}
