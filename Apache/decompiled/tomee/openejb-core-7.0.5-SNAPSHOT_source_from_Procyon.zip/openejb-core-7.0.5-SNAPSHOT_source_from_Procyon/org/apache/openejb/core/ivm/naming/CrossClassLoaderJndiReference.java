// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import java.io.ObjectInputStream;
import java.io.InputStream;
import org.apache.openejb.core.ivm.EjbObjectInputStream;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.openejb.core.ivm.IntraVmCopyMonitor;

public class CrossClassLoaderJndiReference extends IntraVmJndiReference
{
    public CrossClassLoaderJndiReference(final String jndiName) {
        super(jndiName);
    }
    
    @Override
    public Object getObject() throws javax.naming.NamingException {
        Object o = super.getObject();
        try {
            o = copy(o);
        }
        catch (Exception e) {
            throw new NamingException("Error copying object into local class loader", e);
        }
        return o;
    }
    
    private static Object copy(final Object source) throws Exception {
        IntraVmCopyMonitor.preCrossClassLoaderOperation();
        try {
            final ByteArrayOutputStream baos = new ByteArrayOutputStream(4096);
            final ObjectOutputStream out = new ObjectOutputStream(baos);
            out.writeObject(source);
            out.close();
            final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            final ObjectInputStream in = new EjbObjectInputStream(bais);
            return in.readObject();
        }
        finally {
            IntraVmCopyMonitor.postCrossClassLoaderOperation();
        }
    }
}
