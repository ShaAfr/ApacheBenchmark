// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.util.Map;
import org.apache.openejb.SystemException;
import java.util.Properties;

public interface PassivationStrategy
{
    void init(final Properties p0) throws SystemException;
    
    void passivate(final Map p0) throws SystemException;
    
    Object activate(final Object p0) throws SystemException;
}
