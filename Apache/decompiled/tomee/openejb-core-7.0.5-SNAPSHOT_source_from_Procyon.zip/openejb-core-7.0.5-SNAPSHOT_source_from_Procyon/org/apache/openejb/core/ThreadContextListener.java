// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

public interface ThreadContextListener
{
    void contextEntered(final ThreadContext p0, final ThreadContext p1);
    
    void contextExited(final ThreadContext p0, final ThreadContext p1);
}
