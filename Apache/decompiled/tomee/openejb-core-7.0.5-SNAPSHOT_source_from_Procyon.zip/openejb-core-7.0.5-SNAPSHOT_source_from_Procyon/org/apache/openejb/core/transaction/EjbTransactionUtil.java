// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.core.ThreadContextListener;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.core.Operation;
import java.rmi.RemoteException;
import org.apache.openejb.InvalidateReferenceException;
import org.apache.openejb.ApplicationException;
import org.apache.openejb.SystemException;
import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.util.Logger;

public final class EjbTransactionUtil
{
    private static final Logger logger;
    
    public static TransactionPolicy createTransactionPolicy(final TransactionType type, final ThreadContext threadContext) throws SystemException, ApplicationException {
        final BeanContext beanContext = threadContext.getBeanContext();
        final TransactionPolicy txPolicy = beanContext.getTransactionPolicyFactory().createTransactionPolicy(type);
        final TransactionPolicy oldTxPolicy = threadContext.getTransactionPolicy();
        txPolicy.putResource(CallerTransactionEnvironment.class, new CallerTransactionEnvironment(oldTxPolicy));
        threadContext.setTransactionPolicy(txPolicy);
        return txPolicy;
    }
    
    public static void afterInvoke(final TransactionPolicy txPolicy, final ThreadContext threadContext) throws SystemException, ApplicationException {
        if (txPolicy == threadContext.getTransactionPolicy()) {
            try {
                txPolicy.commit();
            }
            finally {
                final CallerTransactionEnvironment oldTxEnv = (CallerTransactionEnvironment)txPolicy.getResource(CallerTransactionEnvironment.class);
                if (oldTxEnv != null) {
                    threadContext.setTransactionPolicy(oldTxEnv.oldTxPolicy);
                }
                else {
                    threadContext.setTransactionPolicy(null);
                }
            }
            return;
        }
        try {
            txPolicy.setRollbackOnly();
            txPolicy.commit();
        }
        catch (Exception e) {
            threadContext.setDiscardInstance(true);
            EjbTransactionUtil.logger.error("Error rolling back transaction", e);
        }
        final TransactionPolicy threadContextTxPolicy = threadContext.getTransactionPolicy();
        if (threadContextTxPolicy != null) {
            try {
                threadContextTxPolicy.setRollbackOnly();
                threadContextTxPolicy.commit();
            }
            catch (Exception e2) {
                threadContext.setDiscardInstance(true);
                EjbTransactionUtil.logger.error("Error rolling back transaction", e2);
            }
        }
        if (threadContextTxPolicy != null) {
            throw new SystemException(new IllegalStateException("ThreadContext is bound to another transaction " + threadContextTxPolicy));
        }
        throw new SystemException(new IllegalStateException("ThreadContext is not bound to specified transaction " + threadContextTxPolicy));
    }
    
    public static void handleApplicationException(final TransactionPolicy txPolicy, final Throwable appException, final boolean rollback) throws ApplicationException {
        if (rollback) {
            txPolicy.setRollbackOnly(appException);
        }
        if (!(appException instanceof ApplicationException)) {
            throw new ApplicationException(appException);
        }
    }
    
    public static void handleSystemException(final TransactionPolicy txPolicy, final Throwable sysException, final ThreadContext callContext) throws InvalidateReferenceException {
        Operation operation = null;
        if (callContext != null) {
            operation = callContext.getCurrentOperation();
        }
        if (operation != null) {
            EjbTransactionUtil.logger.error("EjbTransactionUtil.handleSystemException: " + sysException.getMessage(), sysException);
        }
        else {
            EjbTransactionUtil.logger.debug("EjbTransactionUtil.handleSystemException: " + sysException.getMessage(), sysException);
        }
        txPolicy.setRollbackOnly(sysException);
        if (txPolicy.isClientTransaction()) {
            final String message = "The transaction has been marked rollback only because the bean encountered a non-application exception :" + sysException.getClass().getName() + " : " + sysException.getMessage();
            final TransactionRolledbackException txException = new TransactionRolledbackException(message, sysException);
            throw new InvalidateReferenceException((Exception)txException);
        }
        final RemoteException re = new RemoteException("The bean encountered a non-application exception", sysException);
        throw new InvalidateReferenceException(re);
    }
    
    private EjbTransactionUtil() {
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
        ThreadContext.addThreadContextListener(new ThreadContextListener() {
            @Override
            public void contextEntered(final ThreadContext oldContext, final ThreadContext newContext) {
                if (oldContext != null) {
                    newContext.setTransactionPolicy(oldContext.getTransactionPolicy());
                }
            }
            
            @Override
            public void contextExited(final ThreadContext exitedContext, final ThreadContext reenteredContext) {
            }
        });
    }
    
    private static final class CallerTransactionEnvironment
    {
        private final TransactionPolicy oldTxPolicy;
        
        private CallerTransactionEnvironment(final TransactionPolicy oldTxPolicy) {
            this.oldTxPolicy = oldTxPolicy;
        }
    }
}
