// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Set;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import java.util.List;
import java.net.URI;
import java.util.Properties;

public class EjbJarInfo extends CommonInfoObject
{
    public final Properties properties;
    public String moduleName;
    public String moduleId;
    public URI moduleUri;
    public String path;
    public boolean webapp;
    @XmlElements({ @XmlElement(name = "stateless", type = StatelessBeanInfo.class), @XmlElement(name = "entity", type = EntityBeanInfo.class), @XmlElement(name = "stateful", type = StatefulBeanInfo.class), @XmlElement(name = "singleton", type = SingletonBeanInfo.class), @XmlElement(name = "message-driven", type = MessageDrivenBeanInfo.class), @XmlElement(name = "managed-bean", type = ManagedBeanInfo.class) })
    public final List<EnterpriseBeanInfo> enterpriseBeans;
    public final List<SecurityRoleInfo> securityRoles;
    public final List<MethodPermissionInfo> methodPermissions;
    public final List<MethodTransactionInfo> methodTransactions;
    public final List<MethodConcurrencyInfo> methodConcurrency;
    public final List<InterceptorInfo> interceptors;
    public final List<InterceptorBindingInfo> interceptorBindings;
    public final List<MethodInfo> excludeList;
    public final List<ApplicationExceptionInfo> applicationException;
    public final List<PortInfo> portInfos;
    public final Set<String> watchedResources;
    public final JndiEncInfo moduleJndiEnc;
    public BeansInfo beans;
    public Set<String> mbeans;
    public final List<IdPropertiesInfo> pojoConfigurations;
    
    public EjbJarInfo() {
        this.properties = new Properties();
        this.enterpriseBeans = new ArrayList<EnterpriseBeanInfo>();
        this.securityRoles = new ArrayList<SecurityRoleInfo>();
        this.methodPermissions = new ArrayList<MethodPermissionInfo>();
        this.methodTransactions = new ArrayList<MethodTransactionInfo>();
        this.methodConcurrency = new ArrayList<MethodConcurrencyInfo>();
        this.interceptors = new ArrayList<InterceptorInfo>();
        this.interceptorBindings = new ArrayList<InterceptorBindingInfo>();
        this.excludeList = new ArrayList<MethodInfo>();
        this.applicationException = new ArrayList<ApplicationExceptionInfo>();
        this.portInfos = new ArrayList<PortInfo>();
        this.watchedResources = new TreeSet<String>();
        this.moduleJndiEnc = new JndiEncInfo();
        this.mbeans = new TreeSet<String>();
        this.pojoConfigurations = new ArrayList<IdPropertiesInfo>();
    }
}
