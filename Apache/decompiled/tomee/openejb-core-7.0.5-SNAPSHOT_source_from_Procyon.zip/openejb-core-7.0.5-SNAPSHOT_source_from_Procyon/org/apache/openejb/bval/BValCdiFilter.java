// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.bval;

import javax.enterprise.inject.spi.AnnotatedType;
import org.apache.openejb.util.ContainerClassesFilter;
import org.apache.bval.cdi.BValExtension;

public class BValCdiFilter implements BValExtension.AnnotatedTypeFilter
{
    private final ContainerClassesFilter delegate;
    
    public BValCdiFilter() {
        this.delegate = new ContainerClassesFilter();
    }
    
    public boolean accept(final AnnotatedType<?> annotatedType) {
        final String name = annotatedType.getJavaClass().getName();
        if (name.startsWith("org.apache.openejb.")) {
            final String sub = name.substring("org.apache.openejb.".length());
            return !sub.startsWith("cdi.transactional") && !sub.startsWith("resource.activemq.jms2");
        }
        return this.delegate.accept(name);
    }
}
