// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateless;

import org.apache.openejb.util.Duration;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.Pool;

public class StatelessContainerFactory
{
    private final Pool.Builder pool;
    private Integer max;
    private Object id;
    private SecurityService securityService;
    private Duration accessTimeout;
    private int callbackThreads;
    private Duration closeTimeout;
    private boolean useOneSchedulerThreadByBean;
    private int evictionThreads;
    
    public StatelessContainerFactory() {
        this.pool = new Pool.Builder();
        this.callbackThreads = 5;
        this.useOneSchedulerThreadByBean = false;
        this.evictionThreads = 1;
    }
    
    public void setEvictionThreads(final int evictionThreads) {
        this.evictionThreads = evictionThreads;
    }
    
    public void setUseOneSchedulerThreadByBean(final boolean useOneSchedulerThreadByBean) {
        this.useOneSchedulerThreadByBean = useOneSchedulerThreadByBean;
    }
    
    public void setCallbackThreads(final int callbackThreads) {
        this.callbackThreads = callbackThreads;
    }
    
    public void setId(final Object id) {
        this.id = id;
    }
    
    public void setSecurityService(final SecurityService securityService) {
        this.securityService = securityService;
    }
    
    @Deprecated
    public void setTimeOut(final Duration accessTimeout) {
        this.accessTimeout = accessTimeout;
    }
    
    public void setAccessTimeout(final Duration accessTimeout) {
        if (this.accessTimeout == null) {
            this.setTimeOut(accessTimeout);
        }
    }
    
    public void setMaxSize(final int max) {
        if (this.max == null) {
            this.setPoolSize(max);
        }
    }
    
    @Deprecated
    public void setPoolSize(final int max) {
        this.max = max;
        this.pool.setPoolSize(max);
    }
    
    public void setMinSize(final int min) {
        this.pool.setMinSize(min);
    }
    
    public void setStrictPooling(final boolean strict) {
        this.pool.setStrictPooling(strict);
    }
    
    public void setMaxAge(final Duration maxAge) {
        this.pool.setMaxAge(maxAge);
    }
    
    public void setIdleTimeout(final Duration idleTimeout) {
        this.pool.setIdleTimeout(idleTimeout);
    }
    
    public void setSweepInterval(final Duration interval) {
        this.pool.setSweepInterval(interval);
    }
    
    public void setReplaceAged(final boolean replaceAged) {
        this.pool.setReplaceAged(replaceAged);
    }
    
    public void setReplaceFlushed(final boolean replaceFlushed) {
        this.pool.setReplaceFlushed(replaceFlushed);
    }
    
    public void setGarbageCollection(final boolean garbageCollection) {
        this.pool.setGarbageCollection(garbageCollection);
    }
    
    public void setMaxAgeOffset(final double maxAgeOffset) {
        this.pool.setMaxAgeOffset(maxAgeOffset);
    }
    
    public void setCloseTimeout(final Duration closeTimeout) {
        this.closeTimeout = closeTimeout;
    }
    
    public StatelessContainer create() {
        return new StatelessContainer(this.id, this.securityService, this.accessTimeout, this.closeTimeout, this.pool, this.callbackThreads, this.useOneSchedulerThreadByBean, this.evictionThreads);
    }
}
