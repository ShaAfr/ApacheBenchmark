// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import javax.persistence.TransactionRequiredException;
import java.util.Iterator;
import java.util.HashMap;
import org.apache.openejb.util.LogCategory;
import javax.transaction.Synchronization;
import javax.persistence.EntityManager;
import javax.persistence.SynchronizationType;
import java.util.Map;
import javax.persistence.EntityManagerFactory;
import javax.transaction.TransactionSynchronizationRegistry;
import org.apache.openejb.util.Logger;

public class JtaEntityManagerRegistry
{
    private static final Logger logger;
    private final TransactionSynchronizationRegistry transactionRegistry;
    private final ThreadLocal<ExtendedRegistry> extendedRegistry;
    
    public JtaEntityManagerRegistry(final TransactionSynchronizationRegistry transactionSynchronizationRegistry) {
        this.extendedRegistry = new ThreadLocal<ExtendedRegistry>() {
            @Override
            protected ExtendedRegistry initialValue() {
                return new ExtendedRegistry();
            }
        };
        this.transactionRegistry = transactionSynchronizationRegistry;
    }
    
    public EntityManager getEntityManager(final EntityManagerFactory entityManagerFactory, final Map properties, final boolean extended, final String unitName, final SynchronizationType synchronizationType) throws IllegalStateException {
        if (entityManagerFactory == null) {
            throw new NullPointerException("entityManagerFactory is null");
        }
        final EntityManagerTxKey txKey = new EntityManagerTxKey(entityManagerFactory);
        final boolean transactionActive = this.isTransactionActive();
        if (transactionActive) {
            final EntityManager entityManager = (EntityManager)this.transactionRegistry.getResource((Object)txKey);
            if (entityManager != null) {
                return entityManager;
            }
        }
        if (!extended) {
            EntityManager entityManager;
            if (synchronizationType != null) {
                if (properties != null) {
                    entityManager = entityManagerFactory.createEntityManager(synchronizationType, properties);
                }
                else {
                    entityManager = entityManagerFactory.createEntityManager(synchronizationType);
                }
            }
            else if (properties != null) {
                entityManager = entityManagerFactory.createEntityManager(properties);
            }
            else {
                entityManager = entityManagerFactory.createEntityManager();
            }
            JtaEntityManagerRegistry.logger.debug("Created EntityManager(unit=" + unitName + ", hashCode=" + entityManager.hashCode() + ")");
            if (transactionActive) {
                this.transactionRegistry.registerInterposedSynchronization((Synchronization)new CloseEntityManager(entityManager, unitName));
                this.transactionRegistry.putResource((Object)txKey, (Object)entityManager);
            }
            return entityManager;
        }
        final EntityManagerTracker entityManagerTracker = this.getInheritedEntityManager(entityManagerFactory);
        if (entityManagerTracker == null || entityManagerTracker.getEntityManager() == null) {
            throw new IllegalStateException("InternalError: an entity manager should already be registered for this extended persistence unit");
        }
        final EntityManager entityManager2 = entityManagerTracker.getEntityManager();
        if (transactionActive) {
            if (entityManagerTracker.autoJoinTx) {
                entityManager2.joinTransaction();
            }
            this.transactionRegistry.putResource((Object)txKey, (Object)entityManager2);
        }
        return entityManager2;
    }
    
    public void addEntityManagers(final String deploymentId, final Object primaryKey, final Map<EntityManagerFactory, EntityManagerTracker> entityManagers) throws EntityManagerAlreadyRegisteredException {
        this.extendedRegistry.get().addEntityManagers(new InstanceId(deploymentId, primaryKey), entityManagers);
    }
    
    public Map<EntityManagerFactory, EntityManagerTracker> removeEntityManagers(final String deploymentId, final Object primaryKey) {
        return this.extendedRegistry.get().removeEntityManagers(new InstanceId(deploymentId, primaryKey));
    }
    
    public EntityManagerTracker getInheritedEntityManager(final EntityManagerFactory entityManagerFactory) {
        return this.extendedRegistry.get().getInheritedEntityManager(entityManagerFactory);
    }
    
    public void transactionStarted(final String deploymentId, final Object primaryKey) {
        this.extendedRegistry.get().transactionStarted(new InstanceId(deploymentId, primaryKey));
    }
    
    public boolean isTransactionActive() {
        final int txStatus = this.transactionRegistry.getTransactionStatus();
        final boolean transactionActive = txStatus == 0 || txStatus == 1;
        return transactionActive;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB.createChild("persistence"), JtaEntityManager.class);
    }
    
    private class ExtendedRegistry
    {
        private final Map<InstanceId, Map<EntityManagerFactory, EntityManagerTracker>> entityManagersByDeploymentId;
        
        private ExtendedRegistry() {
            this.entityManagersByDeploymentId = new HashMap<InstanceId, Map<EntityManagerFactory, EntityManagerTracker>>();
        }
        
        private void addEntityManagers(final InstanceId instanceId, final Map<EntityManagerFactory, EntityManagerTracker> entityManagers) throws EntityManagerAlreadyRegisteredException {
            if (instanceId == null) {
                throw new NullPointerException("instanceId is null");
            }
            if (entityManagers == null) {
                throw new NullPointerException("entityManagers is null");
            }
            if (JtaEntityManagerRegistry.this.isTransactionActive()) {
                for (final Map.Entry<EntityManagerFactory, EntityManagerTracker> entry : entityManagers.entrySet()) {
                    final EntityManagerFactory entityManagerFactory = entry.getKey();
                    final EntityManagerTracker tracker = entry.getValue();
                    final EntityManager entityManager = tracker.getEntityManager();
                    final EntityManagerTxKey txKey = new EntityManagerTxKey(entityManagerFactory);
                    final EntityManager oldEntityManager = (EntityManager)JtaEntityManagerRegistry.this.transactionRegistry.getResource((Object)txKey);
                    if (entityManager == oldEntityManager) {
                        break;
                    }
                    if (oldEntityManager != null) {
                        throw new EntityManagerAlreadyRegisteredException("Another entity manager is already registered for this persistence unit");
                    }
                    if (tracker.autoJoinTx) {
                        entityManager.joinTransaction();
                    }
                    JtaEntityManagerRegistry.this.transactionRegistry.putResource((Object)txKey, (Object)entityManager);
                }
            }
            this.entityManagersByDeploymentId.put(instanceId, entityManagers);
        }
        
        private Map<EntityManagerFactory, EntityManagerTracker> removeEntityManagers(final InstanceId instanceId) {
            if (instanceId == null) {
                throw new NullPointerException("InstanceId is null");
            }
            return this.entityManagersByDeploymentId.remove(instanceId);
        }
        
        private EntityManagerTracker getInheritedEntityManager(final EntityManagerFactory entityManagerFactory) {
            if (entityManagerFactory == null) {
                throw new NullPointerException("entityManagerFactory is null");
            }
            for (final Map<EntityManagerFactory, EntityManagerTracker> entityManagers : this.entityManagersByDeploymentId.values()) {
                final EntityManagerTracker entityManagerTracker = entityManagers.get(entityManagerFactory);
                if (entityManagerTracker != null) {
                    return entityManagerTracker;
                }
            }
            return null;
        }
        
        private void transactionStarted(final InstanceId instanceId) {
            if (instanceId == null) {
                throw new NullPointerException("instanceId is null");
            }
            if (!JtaEntityManagerRegistry.this.isTransactionActive()) {
                throw new TransactionRequiredException();
            }
            final Map<EntityManagerFactory, EntityManagerTracker> entityManagers = this.entityManagersByDeploymentId.get(instanceId);
            if (entityManagers == null) {
                return;
            }
            for (final Map.Entry<EntityManagerFactory, EntityManagerTracker> entry : entityManagers.entrySet()) {
                final EntityManagerFactory entityManagerFactory = entry.getKey();
                final EntityManagerTracker value = entry.getValue();
                final EntityManager entityManager = value.getEntityManager();
                if (value.autoJoinTx) {
                    entityManager.joinTransaction();
                }
                final EntityManagerTxKey txKey = new EntityManagerTxKey(entityManagerFactory);
                JtaEntityManagerRegistry.this.transactionRegistry.putResource((Object)txKey, (Object)entityManager);
            }
        }
    }
    
    private static class InstanceId
    {
        private final String deploymentId;
        private final Object primaryKey;
        
        public InstanceId(final String deploymentId, final Object primaryKey) {
            if (deploymentId == null) {
                throw new NullPointerException("deploymentId is null");
            }
            if (primaryKey == null) {
                throw new NullPointerException("primaryKey is null");
            }
            this.deploymentId = deploymentId;
            this.primaryKey = primaryKey;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final InstanceId that = (InstanceId)o;
            return this.deploymentId.equals(that.deploymentId) && this.primaryKey.equals(that.primaryKey);
        }
        
        @Override
        public int hashCode() {
            int result = this.deploymentId.hashCode();
            result = 29 * result + this.primaryKey.hashCode();
            return result;
        }
    }
    
    public static class EntityManagerTracker
    {
        private transient int counter;
        private final EntityManager entityManager;
        private final boolean autoJoinTx;
        
        public EntityManagerTracker(final EntityManager entityManager, final boolean autoJoinTx) {
            if (entityManager == null) {
                throw new NullPointerException("entityManager is null.");
            }
            this.counter = 0;
            this.entityManager = entityManager;
            this.autoJoinTx = autoJoinTx;
        }
        
        public int incCounter() {
            return this.counter++;
        }
        
        public int decCounter() {
            return this.counter--;
        }
        
        public EntityManager getEntityManager() {
            return this.entityManager;
        }
    }
    
    private static class CloseEntityManager implements Synchronization
    {
        private final EntityManager entityManager;
        private final String unitName;
        
        public CloseEntityManager(final EntityManager entityManager, final String unitName) {
            this.entityManager = entityManager;
            this.unitName = unitName;
        }
        
        public void beforeCompletion() {
        }
        
        public void afterCompletion(final int i) {
            this.entityManager.close();
            JtaEntityManagerRegistry.logger.debug("Closed EntityManager(unit=" + this.unitName + ", hashCode=" + this.entityManager.hashCode() + ")");
        }
    }
}
