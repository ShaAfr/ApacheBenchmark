// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.managed;

import org.apache.openejb.util.LogCategory;
import java.io.ObjectInputStream;
import java.io.InputStream;
import org.apache.openejb.core.ObjectInputStreamFiltered;
import java.util.Iterator;
import java.util.Map;
import java.io.OutputStream;
import java.io.NotSerializableException;
import java.io.ObjectOutputStream;
import org.apache.openejb.loader.IO;
import java.io.IOException;
import org.apache.openejb.util.JavaSecurityManagers;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.SystemException;
import java.util.Properties;
import java.io.File;
import org.apache.openejb.util.Logger;

public class SimplePassivater implements PassivationStrategy
{
    private static final Logger logger;
    private File sessionDirectory;
    
    public SimplePassivater() throws SystemException {
        this.init(null);
    }
    
    @Override
    public void init(Properties props) throws SystemException {
        if (props == null) {
            props = new Properties();
        }
        final String dir = props.getProperty("org/openejb/core/InstanceManager/PASSIVATOR_PATH_PREFIX");
        try {
            if (dir != null) {
                this.sessionDirectory = SystemInstance.get().getBase().getDirectory(dir).getAbsoluteFile();
            }
            else {
                this.sessionDirectory = new File(JavaSecurityManagers.getSystemProperty("java.io.tmpdir", File.separator + "tmp")).getAbsoluteFile();
            }
            if (!this.sessionDirectory.exists() && !this.sessionDirectory.mkdirs()) {
                throw new IOException("Failed to create directory: " + this.sessionDirectory.getAbsolutePath());
            }
            SimplePassivater.logger.info("Using directory " + this.sessionDirectory + " for stateful session passivation");
        }
        catch (IOException e) {
            throw new SystemException(this.getClass().getName() + ".init(): can't use directory prefix " + dir + ":" + e, e);
        }
    }
    
    public void passivate(final Object primaryKey, final Object state) throws SystemException {
        try {
            final String filename = primaryKey.toString().replace(':', '=');
            final File sessionFile = new File(this.sessionDirectory, filename);
            if (!sessionFile.exists() && !sessionFile.createNewFile()) {
                throw new Exception("Failed to create passivation file: " + sessionFile.getAbsolutePath());
            }
            SimplePassivater.logger.info("Passivating to file " + sessionFile);
            try (final OutputStream os = IO.write(sessionFile);
                 final ObjectOutputStream oos = new ObjectOutputStream(os)) {
                oos.writeObject(state);
            }
            finally {
                sessionFile.deleteOnExit();
            }
        }
        catch (NotSerializableException nse) {
            SimplePassivater.logger.error("Passivation failed ", nse);
            throw (SystemException)new SystemException("The type " + nse.getMessage() + " is not serializable as mandated by the EJB specification.").initCause(nse);
        }
        catch (Exception t) {
            SimplePassivater.logger.error("Passivation failed ", t);
            throw new SystemException(t);
        }
    }
    
    @Override
    public void passivate(final Map hash) throws SystemException {
        for (final Object id : hash.keySet()) {
            this.passivate(id, hash.get(id));
        }
    }
    
    @Override
    public Object activate(final Object primaryKey) throws SystemException {
        try {
            final String filename = primaryKey.toString().replace(':', '=');
            final File sessionFile = new File(this.sessionDirectory, filename);
            if (sessionFile.exists()) {
                SimplePassivater.logger.info("Activating from file " + sessionFile);
                try (final InputStream source = IO.read(sessionFile);
                     final ObjectInputStream ois = new ObjectInputStreamFiltered(source)) {
                    final Object state = ois.readObject();
                    if (!sessionFile.delete()) {
                        sessionFile.deleteOnExit();
                    }
                    return state;
                }
            }
            SimplePassivater.logger.info("Activation failed: file not found " + sessionFile);
            return null;
        }
        catch (Exception t) {
            SimplePassivater.logger.info("Activation failed ", t);
            throw new SystemException(t);
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
}
