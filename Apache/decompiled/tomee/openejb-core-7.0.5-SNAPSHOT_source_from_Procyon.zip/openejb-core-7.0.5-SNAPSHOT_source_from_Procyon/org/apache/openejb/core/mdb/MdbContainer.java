// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.mdb;

import javax.management.MBeanNotificationInfo;
import javax.management.MBeanParameterInfo;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanConstructorInfo;
import javax.management.MBeanAttributeInfo;
import javax.management.InvalidAttributeValueException;
import javax.management.Attribute;
import javax.management.AttributeNotFoundException;
import javax.management.ReflectionException;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.AttributeList;
import javax.management.DynamicMBean;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.util.LogCategory;
import javax.management.MalformedObjectNameException;
import org.apache.openejb.core.interceptor.InterceptorData;
import java.util.List;
import org.apache.openejb.core.ExceptionType;
import java.lang.reflect.InvocationTargetException;
import org.apache.openejb.core.interceptor.InterceptorStack;
import org.apache.openejb.core.Operation;
import java.util.Arrays;
import org.apache.openejb.ApplicationException;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import org.apache.openejb.core.ThreadContext;
import javax.transaction.xa.XAResource;
import javax.resource.spi.UnavailableException;
import org.apache.openejb.SystemException;
import java.lang.reflect.Method;
import org.apache.openejb.InterfaceType;
import javax.resource.spi.endpoint.MessageEndpointFactory;
import org.apache.openejb.core.timer.EjbTimerService;
import java.util.Set;
import java.util.Iterator;
import javax.naming.NamingException;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import java.util.Collection;
import java.util.TreeSet;
import org.apache.xbean.recipe.Option;
import org.apache.xbean.recipe.ObjectRecipe;
import javax.management.MBeanServer;
import javax.resource.spi.ActivationSpec;
import javax.resource.ResourceException;
import org.apache.openejb.monitoring.ManagedMBean;
import org.apache.openejb.monitoring.ObjectNameBuilder;
import org.apache.openejb.monitoring.LocalMBeanServer;
import org.apache.openejb.monitoring.StatsInterceptor;
import org.apache.openejb.Container;
import org.apache.openejb.loader.Options;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.ContainerType;
import org.apache.openejb.loader.SystemInstance;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Properties;
import org.apache.openejb.resource.XAResourceWrapper;
import java.util.concurrent.ConcurrentMap;
import javax.resource.spi.ResourceAdapter;
import org.apache.openejb.spi.SecurityService;
import javax.management.ObjectName;
import java.util.Map;
import org.apache.openejb.BeanContext;
import org.apache.openejb.util.Logger;
import org.apache.openejb.RpcContainer;

public class MdbContainer implements RpcContainer
{
    private static final Logger logger;
    private static final ThreadLocal<BeanContext> CURRENT;
    private static final Object[] NO_ARGS;
    private final Map<BeanContext, ObjectName> mbeanNames;
    private final Map<BeanContext, MdbActivationContext> activationContexts;
    private final Object containerID;
    private final SecurityService securityService;
    private final ResourceAdapter resourceAdapter;
    private final Class messageListenerInterface;
    private final Class activationSpecClass;
    private final int instanceLimit;
    private final boolean failOnUnknownActivationSpec;
    private final ConcurrentMap<Object, BeanContext> deployments;
    private final XAResourceWrapper xaResourceWrapper;
    private final InboundRecovery inboundRecovery;
    private final Properties properties;
    
    public MdbContainer(final Object containerID, final SecurityService securityService, final ResourceAdapter resourceAdapter, final Class messageListenerInterface, final Class activationSpecClass, final int instanceLimit, final boolean failOnUnknownActivationSpec) {
        this.mbeanNames = new ConcurrentHashMap<BeanContext, ObjectName>();
        this.activationContexts = new ConcurrentHashMap<BeanContext, MdbActivationContext>();
        this.deployments = new ConcurrentHashMap<Object, BeanContext>();
        this.properties = new Properties();
        this.containerID = containerID;
        this.securityService = securityService;
        this.resourceAdapter = resourceAdapter;
        this.messageListenerInterface = messageListenerInterface;
        this.activationSpecClass = activationSpecClass;
        this.instanceLimit = instanceLimit;
        this.failOnUnknownActivationSpec = failOnUnknownActivationSpec;
        this.xaResourceWrapper = (XAResourceWrapper)SystemInstance.get().getComponent((Class)XAResourceWrapper.class);
        this.inboundRecovery = (InboundRecovery)SystemInstance.get().getComponent((Class)InboundRecovery.class);
    }
    
    @Override
    public BeanContext[] getBeanContexts() {
        return this.deployments.values().toArray(new BeanContext[this.deployments.size()]);
    }
    
    @Override
    public BeanContext getBeanContext(final Object deploymentID) {
        return this.deployments.get(deploymentID);
    }
    
    @Override
    public ContainerType getContainerType() {
        return ContainerType.MESSAGE_DRIVEN;
    }
    
    @Override
    public Object getContainerID() {
        return this.containerID;
    }
    
    public ResourceAdapter getResourceAdapter() {
        return this.resourceAdapter;
    }
    
    public Class getMessageListenerInterface() {
        return this.messageListenerInterface;
    }
    
    public Class getActivationSpecClass() {
        return this.activationSpecClass;
    }
    
    public Properties getProperties() {
        return this.properties;
    }
    
    @Override
    public void deploy(final BeanContext beanContext) throws OpenEJBException {
        final Object deploymentId = beanContext.getDeploymentID();
        if (!beanContext.getMdbInterface().equals(this.messageListenerInterface)) {
            throw new OpenEJBException("Deployment '" + deploymentId + "' has message listener interface " + beanContext.getMdbInterface().getName() + " but this MDB container only supports " + this.messageListenerInterface);
        }
        final ActivationSpec activationSpec = this.createActivationSpec(beanContext);
        if (this.inboundRecovery != null) {
            this.inboundRecovery.recover(this.resourceAdapter, activationSpec, this.containerID.toString());
        }
        final Options options = new Options(beanContext.getProperties());
        final int instanceLimit = options.get("InstanceLimit", this.instanceLimit);
        final MdbInstanceFactory instanceFactory = new MdbInstanceFactory(beanContext, this.securityService, instanceLimit);
        final EndpointFactory endpointFactory = new EndpointFactory(activationSpec, this, beanContext, instanceFactory, this.xaResourceWrapper);
        beanContext.setContainer(this);
        beanContext.setContainerData(endpointFactory);
        this.deployments.put(deploymentId, beanContext);
        if (StatsInterceptor.isStatsActivated()) {
            final StatsInterceptor stats = new StatsInterceptor(beanContext.getBeanClass());
            beanContext.addFirstSystemInterceptor(stats);
            final MBeanServer server = LocalMBeanServer.get();
            final ObjectNameBuilder jmxName = new ObjectNameBuilder("openejb.management");
            jmxName.set("J2EEServer", "openejb");
            jmxName.set("J2EEApplication", null);
            jmxName.set("EJBModule", beanContext.getModuleID());
            jmxName.set("StatelessSessionBean", beanContext.getEjbName());
            jmxName.set("j2eeType", "");
            jmxName.set("name", beanContext.getEjbName());
            try {
                final ObjectName objectName = jmxName.set("j2eeType", "Invocations").build();
                if (server.isRegistered(objectName)) {
                    server.unregisterMBean(objectName);
                }
                server.registerMBean(new ManagedMBean(stats), objectName);
                endpointFactory.jmxNames.add(objectName);
            }
            catch (Exception e) {
                MdbContainer.logger.error("Unable to register MBean ", e);
            }
        }
        MdbContainer.CURRENT.set(beanContext);
        try {
            final MdbActivationContext activationContext = new MdbActivationContext(Thread.currentThread().getContextClassLoader(), beanContext, this.resourceAdapter, endpointFactory, activationSpec);
            this.activationContexts.put(beanContext, activationContext);
            boolean activeOnStartup = true;
            String activeOnStartupSetting = beanContext.getActivationProperties().get("MdbActiveOnStartup");
            if (activeOnStartupSetting == null) {
                activeOnStartupSetting = beanContext.getActivationProperties().get("DeliveryActive");
            }
            if (activeOnStartupSetting != null) {
                activeOnStartup = Boolean.parseBoolean(activeOnStartupSetting);
            }
            if (activeOnStartup) {
                activationContext.start();
            }
            else {
                MdbContainer.logger.info("Not auto-activating endpoint for " + beanContext.getDeploymentID());
            }
            String jmxName2 = beanContext.getActivationProperties().get("MdbJMXControl");
            if (jmxName2 == null) {
                jmxName2 = "true";
            }
            this.addJMxControl(beanContext, jmxName2, activationContext);
        }
        catch (ResourceException e2) {
            beanContext.setContainer(null);
            beanContext.setContainerData(null);
            this.deployments.remove(deploymentId);
            throw new OpenEJBException((Throwable)e2);
        }
        finally {
            MdbContainer.CURRENT.remove();
        }
    }
    
    private ActivationSpec createActivationSpec(final BeanContext beanContext) throws OpenEJBException {
        try {
            final ObjectRecipe objectRecipe = new ObjectRecipe(this.activationSpecClass);
            objectRecipe.allow(Option.IGNORE_MISSING_PROPERTIES);
            objectRecipe.disallow(Option.FIELD_INJECTION);
            final Map<String, String> activationProperties = beanContext.getActivationProperties();
            for (final Map.Entry<String, String> entry : activationProperties.entrySet()) {
                objectRecipe.setMethodProperty((String)entry.getKey(), (Object)entry.getValue());
            }
            objectRecipe.setMethodProperty("beanClass", (Object)beanContext.getBeanClass());
            final ActivationSpec activationSpec = (ActivationSpec)objectRecipe.create(this.activationSpecClass.getClassLoader());
            final Set<String> unusedProperties = new TreeSet<String>(objectRecipe.getUnsetProperties().keySet());
            unusedProperties.remove("destination");
            unusedProperties.remove("destinationType");
            unusedProperties.remove("destinationLookup");
            unusedProperties.remove("connectionFactoryLookup");
            unusedProperties.remove("beanClass");
            unusedProperties.remove("MdbActiveOnStartup");
            unusedProperties.remove("MdbJMXControl");
            unusedProperties.remove("DeliveryActive");
            if (!unusedProperties.isEmpty()) {
                final String text = "No setter found for the activation spec properties: " + unusedProperties;
                if (this.failOnUnknownActivationSpec) {
                    throw new IllegalArgumentException(text);
                }
                MdbContainer.logger.warning(text);
            }
            try {
                activationSpec.validate();
            }
            catch (UnsupportedOperationException uoe) {
                MdbContainer.logger.info("ActivationSpec does not support validate. Implementation of validate is optional");
            }
            try {
                final Validator validator = (Validator)beanContext.getJndiContext().lookup("comp/Validator");
                final Set generalSet = validator.validate((Object)activationSpec, new Class[0]);
                if (!generalSet.isEmpty()) {
                    throw new ConstraintViolationException("Constraint violation for ActivationSpec " + this.activationSpecClass.getName(), generalSet);
                }
            }
            catch (NamingException e2) {
                MdbContainer.logger.debug("No Validator bound to JNDI context");
            }
            activationSpec.setResourceAdapter(this.resourceAdapter);
            return activationSpec;
        }
        catch (Exception e) {
            throw new OpenEJBException("Unable to create activation spec", e);
        }
    }
    
    @Override
    public void start(final BeanContext info) throws OpenEJBException {
        final EjbTimerService timerService = info.getEjbTimerService();
        if (timerService != null) {
            timerService.start();
        }
    }
    
    @Override
    public void stop(final BeanContext info) throws OpenEJBException {
        info.stop();
    }
    
    @Override
    public void undeploy(final BeanContext beanContext) throws OpenEJBException {
        if (!(beanContext instanceof BeanContext)) {
            return;
        }
        try {
            final EndpointFactory endpointFactory = (EndpointFactory)beanContext.getContainerData();
            if (endpointFactory != null) {
                MdbContainer.CURRENT.set(beanContext);
                try {
                    final ObjectName jmxBeanToRemove = this.mbeanNames.remove(beanContext);
                    if (jmxBeanToRemove != null) {
                        LocalMBeanServer.unregisterSilently(jmxBeanToRemove);
                        MdbContainer.logger.info("Undeployed MDB control for " + beanContext.getDeploymentID());
                    }
                    final MdbActivationContext activationContext = this.activationContexts.remove(beanContext);
                    if (activationContext != null && activationContext.isStarted()) {
                        this.resourceAdapter.endpointDeactivation((MessageEndpointFactory)endpointFactory, endpointFactory.getActivationSpec());
                    }
                }
                finally {
                    MdbContainer.CURRENT.remove();
                }
                final MBeanServer server = LocalMBeanServer.get();
                for (final ObjectName objectName : endpointFactory.jmxNames) {
                    try {
                        server.unregisterMBean(objectName);
                    }
                    catch (Exception e) {
                        MdbContainer.logger.error("Unable to unregister MBean " + objectName);
                    }
                }
            }
        }
        finally {
            beanContext.setContainer(null);
            beanContext.setContainerData(null);
            this.deployments.remove(beanContext.getDeploymentID());
        }
    }
    
    @Override
    public Object invoke(final Object deploymentId, final InterfaceType type, final Class callInterface, final Method method, final Object[] args, final Object primKey) throws OpenEJBException {
        final BeanContext beanContext = this.getBeanContext(deploymentId);
        final EndpointFactory endpointFactory = (EndpointFactory)beanContext.getContainerData();
        final MdbInstanceFactory instanceFactory = endpointFactory.getInstanceFactory();
        Instance instance;
        try {
            instance = (Instance)instanceFactory.createInstance(true);
        }
        catch (UnavailableException e) {
            throw new SystemException("Unable to create instance for invocation", (Throwable)e);
        }
        try {
            this.beforeDelivery(beanContext, instance, method, null);
            final Object value = this.invoke(instance, method, type, args);
            this.afterDelivery(instance);
            return value;
        }
        finally {
            instanceFactory.freeInstance(instance, true);
        }
    }
    
    public void beforeDelivery(final BeanContext deployInfo, final Object instance, final Method method, final XAResource xaResource) throws SystemException {
        final ThreadContext callContext = new ThreadContext(deployInfo, null);
        final ThreadContext oldContext = ThreadContext.enter(callContext);
        final MdbCallContext mdbCallContext = new MdbCallContext();
        callContext.set(MdbCallContext.class, mdbCallContext);
        mdbCallContext.deliveryMethod = method;
        mdbCallContext.oldCallContext = oldContext;
        try {
            mdbCallContext.txPolicy = EjbTransactionUtil.createTransactionPolicy(deployInfo.getTransactionType(method), callContext);
            if (xaResource != null && mdbCallContext.txPolicy.isNewTransaction()) {
                mdbCallContext.txPolicy.enlistResource(xaResource);
            }
        }
        catch (ApplicationException e) {
            ThreadContext.exit(oldContext);
            throw new SystemException("Should never get an Application exception", e);
        }
        catch (SystemException e2) {
            ThreadContext.exit(oldContext);
            throw e2;
        }
        catch (Exception e3) {
            ThreadContext.exit(oldContext);
            throw new SystemException("Unable to enlist xa resource in the transaction", e3);
        }
    }
    
    public Object invoke(final Object instance, final Method method, final InterfaceType type, Object... args) throws SystemException, ApplicationException {
        if (args == null) {
            args = MdbContainer.NO_ARGS;
        }
        final ThreadContext callContext = ThreadContext.getThreadContext();
        final BeanContext deployInfo = callContext.getBeanContext();
        final MdbCallContext mdbCallContext = callContext.get(MdbCallContext.class);
        if (mdbCallContext == null) {
            throw new IllegalStateException("beforeDelivery was not called");
        }
        if (!mdbCallContext.deliveryMethod.getName().equals(method.getName()) || !Arrays.deepEquals(mdbCallContext.deliveryMethod.getParameterTypes(), method.getParameterTypes())) {
            throw new IllegalStateException("Delivery method specified in beforeDelivery is not the delivery method called");
        }
        Object returnValue = null;
        OpenEJBException openEjbException = null;
        final Operation oldOperation = callContext.getCurrentOperation();
        callContext.setCurrentOperation((type == InterfaceType.TIMEOUT) ? Operation.TIMEOUT : Operation.BUSINESS);
        try {
            if (MdbContainer.logger.isDebugEnabled()) {
                MdbContainer.logger.info("invoking method " + method.getName() + " on " + deployInfo.getDeploymentID());
            }
            final Method targetMethod = deployInfo.getMatchingBeanMethod(method);
            callContext.set(Method.class, targetMethod);
            returnValue = this._invoke(instance, targetMethod, args, deployInfo, type, mdbCallContext);
            return returnValue;
        }
        catch (ApplicationException ex) {}
        catch (SystemException e) {
            openEjbException = e;
            throw e;
        }
        finally {
            callContext.setCurrentOperation(oldOperation);
            if (MdbContainer.logger.isDebugEnabled()) {
                if (openEjbException == null) {
                    MdbContainer.logger.debug("finished invoking method " + method.getName() + ". Return value:" + returnValue);
                }
                else {
                    final Throwable exception = (openEjbException.getRootCause() != null) ? openEjbException.getRootCause() : openEjbException;
                    MdbContainer.logger.debug("finished invoking method " + method.getName() + " with exception " + exception);
                }
            }
        }
    }
    
    private Object _invoke(final Object instance, final Method runMethod, final Object[] args, final BeanContext beanContext, final InterfaceType interfaceType, final MdbCallContext mdbCallContext) throws SystemException, ApplicationException {
        try {
            final List<InterceptorData> interceptors = beanContext.getMethodInterceptors(runMethod);
            final InterceptorStack interceptorStack = new InterceptorStack(((Instance)instance).bean, runMethod, (interfaceType == InterfaceType.TIMEOUT) ? Operation.TIMEOUT : Operation.BUSINESS, interceptors, ((Instance)instance).interceptors);
            final Object returnValue = interceptorStack.invoke(args);
            return returnValue;
        }
        catch (Throwable e) {
            if (e instanceof InvocationTargetException) {
                e = ((InvocationTargetException)e).getTargetException();
            }
            final ExceptionType type = beanContext.getExceptionType(e);
            if (type == ExceptionType.SYSTEM) {
                EjbTransactionUtil.handleSystemException(mdbCallContext.txPolicy, e, ThreadContext.getThreadContext());
            }
            else {
                EjbTransactionUtil.handleApplicationException(mdbCallContext.txPolicy, e, false);
            }
            throw new AssertionError((Object)"Should not get here");
        }
    }
    
    public void afterDelivery(final Object instance) throws SystemException {
        final ThreadContext callContext = ThreadContext.getThreadContext();
        final MdbCallContext mdbCallContext = callContext.get(MdbCallContext.class);
        try {
            EjbTransactionUtil.afterInvoke(mdbCallContext.txPolicy, callContext);
        }
        catch (ApplicationException e) {
            throw new SystemException("Should never get an Application exception", e);
        }
        finally {
            ThreadContext.exit(mdbCallContext.oldCallContext);
        }
    }
    
    public void release(final BeanContext deployInfo, final Object instance) {
        ThreadContext callContext = ThreadContext.getThreadContext();
        boolean contextExitRequired = false;
        if (callContext == null) {
            callContext = new ThreadContext(deployInfo, null);
            ThreadContext.enter(callContext);
            contextExitRequired = true;
        }
        try {
            final MdbCallContext mdbCallContext = callContext.get(MdbCallContext.class);
            if (mdbCallContext != null) {
                try {
                    EjbTransactionUtil.afterInvoke(mdbCallContext.txPolicy, callContext);
                }
                catch (Exception e) {
                    MdbContainer.logger.error("error while releasing message endpoint", e);
                }
                finally {
                    final EndpointFactory endpointFactory = (EndpointFactory)deployInfo.getContainerData();
                    endpointFactory.getInstanceFactory().freeInstance((Instance)instance, false);
                }
            }
        }
        finally {
            if (contextExitRequired) {
                ThreadContext.exit(callContext);
            }
        }
    }
    
    private void addJMxControl(final BeanContext current, final String name, final MdbActivationContext activationContext) throws ResourceException {
        if (name == null || "false".equalsIgnoreCase(name)) {
            MdbContainer.logger.debug("Not adding JMX control for " + current.getDeploymentID());
            return;
        }
        ObjectName jmxName;
        try {
            jmxName = ("true".equalsIgnoreCase(name) ? new ObjectNameBuilder().set("J2EEServer", "openejb").set("J2EEApplication", null).set("EJBModule", current.getModuleID()).set("StatelessSessionBean", current.getEjbName()).set("j2eeType", "control").set("name", current.getEjbName()).build() : new ObjectName(name));
        }
        catch (MalformedObjectNameException e) {
            throw new IllegalArgumentException(e);
        }
        this.mbeanNames.put(current, jmxName);
        LocalMBeanServer.registerSilently(new MdbJmxControl(activationContext), jmxName);
        MdbContainer.logger.info("Deployed MDB control for " + current.getDeploymentID() + " on " + jmxName);
    }
    
    public static BeanContext current() {
        final BeanContext beanContext = MdbContainer.CURRENT.get();
        if (beanContext == null) {
            MdbContainer.CURRENT.remove();
        }
        return beanContext;
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
        CURRENT = new ThreadLocal<BeanContext>();
        NO_ARGS = new Object[0];
    }
    
    private static class MdbCallContext
    {
        private Method deliveryMethod;
        private TransactionPolicy txPolicy;
        private ThreadContext oldCallContext;
    }
    
    private static class MdbActivationContext
    {
        private final ClassLoader classLoader;
        private final BeanContext beanContext;
        private final ResourceAdapter resourceAdapter;
        private final EndpointFactory endpointFactory;
        private final ActivationSpec activationSpec;
        private AtomicBoolean started;
        
        public MdbActivationContext(final ClassLoader classLoader, final BeanContext beanContext, final ResourceAdapter resourceAdapter, final EndpointFactory endpointFactory, final ActivationSpec activationSpec) {
            this.started = new AtomicBoolean(false);
            this.classLoader = classLoader;
            this.beanContext = beanContext;
            this.resourceAdapter = resourceAdapter;
            this.endpointFactory = endpointFactory;
            this.activationSpec = activationSpec;
        }
        
        public ResourceAdapter getResourceAdapter() {
            return this.resourceAdapter;
        }
        
        public EndpointFactory getEndpointFactory() {
            return this.endpointFactory;
        }
        
        public ActivationSpec getActivationSpec() {
            return this.activationSpec;
        }
        
        public boolean isStarted() {
            return this.started.get();
        }
        
        public void start() throws ResourceException {
            if (!this.started.compareAndSet(false, true)) {
                return;
            }
            final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
            try {
                Thread.currentThread().setContextClassLoader(this.classLoader);
                this.resourceAdapter.endpointActivation((MessageEndpointFactory)this.endpointFactory, this.activationSpec);
                MdbContainer.logger.info("Activated endpoint for " + this.beanContext.getDeploymentID());
            }
            finally {
                Thread.currentThread().setContextClassLoader(oldCl);
            }
        }
        
        public void stop() {
            if (!this.started.compareAndSet(true, false)) {
                return;
            }
            final ClassLoader oldCl = Thread.currentThread().getContextClassLoader();
            try {
                Thread.currentThread().setContextClassLoader(this.classLoader);
                this.resourceAdapter.endpointDeactivation((MessageEndpointFactory)this.endpointFactory, this.activationSpec);
                MdbContainer.logger.info("Deactivated endpoint for " + this.beanContext.getDeploymentID());
            }
            finally {
                Thread.currentThread().setContextClassLoader(oldCl);
            }
        }
    }
    
    public static final class MdbJmxControl implements DynamicMBean
    {
        private static final AttributeList ATTRIBUTE_LIST;
        private static final MBeanInfo INFO;
        private final MdbActivationContext activationContext;
        
        private MdbJmxControl(final MdbActivationContext activationContext) {
            this.activationContext = activationContext;
        }
        
        @Override
        public Object invoke(final String actionName, final Object[] params, final String[] signature) throws MBeanException, ReflectionException {
            if (!actionName.equals("stop")) {
                if (actionName.equals("start")) {
                    try {
                        this.activationContext.start();
                        return null;
                    }
                    catch (ResourceException e) {
                        MdbContainer.logger.error("Error invoking " + actionName + ": " + e.getMessage());
                        throw new MBeanException(new IllegalStateException(e.getMessage(), (Throwable)e));
                    }
                }
                throw new MBeanException(new IllegalStateException("unsupported operation: " + actionName));
            }
            this.activationContext.stop();
            return null;
        }
        
        @Override
        public MBeanInfo getMBeanInfo() {
            return MdbJmxControl.INFO;
        }
        
        @Override
        public Object getAttribute(final String attribute) throws AttributeNotFoundException, MBeanException, ReflectionException {
            if ("started".equals(attribute)) {
                return this.activationContext.isStarted();
            }
            throw new AttributeNotFoundException();
        }
        
        @Override
        public void setAttribute(final Attribute attribute) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException {
            throw new AttributeNotFoundException();
        }
        
        @Override
        public AttributeList getAttributes(final String[] attributes) {
            return MdbJmxControl.ATTRIBUTE_LIST;
        }
        
        @Override
        public AttributeList setAttributes(final AttributeList attributes) {
            return MdbJmxControl.ATTRIBUTE_LIST;
        }
        
        static {
            ATTRIBUTE_LIST = new AttributeList();
            INFO = new MBeanInfo("org.apache.openejb.resource.activemq.ActiveMQResourceAdapter.MdbJmxControl", "Allows to control a MDB (start/stop)", new MBeanAttributeInfo[] { new MBeanAttributeInfo("started", "boolean", "started: boolean indicating whether this MDB endpoint has been activated.", true, false, true) }, new MBeanConstructorInfo[0], new MBeanOperationInfo[] { new MBeanOperationInfo("start", "Ensure the listener is active.", new MBeanParameterInfo[0], "void", 1), new MBeanOperationInfo("stop", "Ensure the listener is not active.", new MBeanParameterInfo[0], "void", 1) }, new MBeanNotificationInfo[0]);
        }
    }
}
