// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.cmd;

import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.assembler.classic.OpenEjbConfiguration;
import java.io.File;
import javax.ejb.Remote;
import javax.ejb.LockType;
import javax.ejb.Lock;
import javax.ejb.Singleton;

@Singleton(name = "openejb/ConfigurationInfo")
@Lock(LockType.READ)
@Remote({ ConfigurationInfo.class })
public class ConfigurationInfoEjb implements ConfigurationInfo
{
    @Override
    public OpenEjbConfiguration getOpenEjbConfiguration(final File tmpFile) throws UnauthorizedException {
        if (tmpFile.exists()) {
            return (OpenEjbConfiguration)SystemInstance.get().getComponent((Class)OpenEjbConfiguration.class);
        }
        throw new UnauthorizedException("Machine not authorized to see this server's configuration properties");
    }
}
