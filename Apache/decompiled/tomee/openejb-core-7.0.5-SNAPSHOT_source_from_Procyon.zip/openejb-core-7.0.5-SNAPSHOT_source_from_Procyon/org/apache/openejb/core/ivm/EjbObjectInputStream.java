// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import java.lang.reflect.Proxy;
import org.apache.openejb.core.rmi.BlacklistClassResolver;
import java.io.ObjectStreamClass;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class EjbObjectInputStream extends ObjectInputStream
{
    public EjbObjectInputStream(final InputStream in) throws IOException {
        super(in);
    }
    
    @Override
    protected Class resolveClass(final ObjectStreamClass classDesc) throws IOException, ClassNotFoundException {
        final String checkedName = BlacklistClassResolver.DEFAULT.check(classDesc.getName());
        try {
            return Class.forName(checkedName, false, this.getClassloader());
        }
        catch (ClassNotFoundException e) {
            final String n = classDesc.getName();
            if (n.equals("boolean")) {
                return Boolean.TYPE;
            }
            if (n.equals("byte")) {
                return Byte.TYPE;
            }
            if (n.equals("char")) {
                return Character.TYPE;
            }
            if (n.equals("short")) {
                return Short.TYPE;
            }
            if (n.equals("int")) {
                return Integer.TYPE;
            }
            if (n.equals("long")) {
                return Long.TYPE;
            }
            if (n.equals("float")) {
                return Float.TYPE;
            }
            if (n.equals("double")) {
                return Double.TYPE;
            }
            return this.getClass().getClassLoader().loadClass(checkedName);
        }
    }
    
    @Override
    protected Class resolveProxyClass(final String[] interfaces) throws IOException, ClassNotFoundException {
        final Class[] cinterfaces = new Class[interfaces.length];
        for (int i = 0; i < interfaces.length; ++i) {
            cinterfaces[i] = this.getClassloader().loadClass(interfaces[i]);
        }
        try {
            return Proxy.getProxyClass(this.getClassloader(), (Class<?>[])cinterfaces);
        }
        catch (IllegalArgumentException e) {
            throw new ClassNotFoundException(null, e);
        }
    }
    
    ClassLoader getClassloader() {
        return Thread.currentThread().getContextClassLoader();
    }
}
