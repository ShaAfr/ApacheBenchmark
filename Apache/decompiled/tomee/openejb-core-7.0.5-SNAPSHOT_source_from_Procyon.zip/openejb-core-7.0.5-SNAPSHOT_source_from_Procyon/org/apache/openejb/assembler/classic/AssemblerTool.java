// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.JavaSecurityManagers;
import org.apache.openejb.Container;
import javax.resource.spi.ResourceAdapter;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ConnectionManager;
import javax.transaction.TransactionManager;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.proxy.ProxyFactory;
import java.util.HashMap;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.util.Messages;
import java.util.Properties;
import org.apache.openejb.util.SafeToolkit;
import java.util.Map;

public class AssemblerTool
{
    public static final Map<String, Class> serviceInterfaces;
    protected static final SafeToolkit toolkit;
    protected Properties props;
    
    public AssemblerTool() {
        this.props = new Properties();
    }
    
    protected static void checkImplementation(final Class intrfce, final Class factory, final String serviceType, final String serviceName) throws OpenEJBException {
        if (!intrfce.isAssignableFrom(factory)) {
            throw new OpenEJBException(new Messages("org.apache.openejb.util.resources").format("init.0100", serviceType, serviceName, factory.getName(), intrfce.getName()));
        }
    }
    
    static {
        (serviceInterfaces = new HashMap<String, Class>()).put("ProxyFactory", ProxyFactory.class);
        AssemblerTool.serviceInterfaces.put("SecurityService", SecurityService.class);
        AssemblerTool.serviceInterfaces.put("TransactionManager", TransactionManager.class);
        AssemblerTool.serviceInterfaces.put("ConnectionManager", ConnectionManager.class);
        AssemblerTool.serviceInterfaces.put("Connector", ManagedConnectionFactory.class);
        AssemblerTool.serviceInterfaces.put("Resource", ResourceAdapter.class);
        AssemblerTool.serviceInterfaces.put("Container", Container.class);
        toolkit = SafeToolkit.getToolkit("AssemblerTool");
        JavaSecurityManagers.setSystemProperty("noBanner", "true");
    }
}
