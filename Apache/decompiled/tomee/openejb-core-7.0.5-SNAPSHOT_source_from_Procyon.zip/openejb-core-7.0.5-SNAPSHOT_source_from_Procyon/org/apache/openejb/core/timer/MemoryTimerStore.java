// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import javax.transaction.RollbackException;
import java.util.concurrent.locks.ReentrantLock;
import java.util.TreeSet;
import java.lang.ref.WeakReference;
import java.util.concurrent.locks.Lock;
import java.util.Set;
import javax.transaction.Synchronization;
import java.util.TreeMap;
import org.apache.openejb.util.LogCategory;
import javax.transaction.SystemException;
import java.util.Date;
import javax.ejb.TimerConfig;
import javax.ejb.ScheduleExpression;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import javax.transaction.TransactionManager;
import java.util.concurrent.atomic.AtomicLong;
import javax.transaction.Transaction;
import java.util.Map;
import org.apache.openejb.util.Logger;

public class MemoryTimerStore implements TimerStore
{
    private static final long serialVersionUID = 1L;
    private static final Logger log;
    private final Map<Long, TimerData> taskStore;
    private final Map<Transaction, TimerDataView> tasksByTransaction;
    private final AtomicLong counter;
    private final TransactionManager transactionManager;
    
    public MemoryTimerStore(final TransactionManager transactionManager) {
        this.taskStore = new ConcurrentHashMap<Long, TimerData>();
        this.tasksByTransaction = new ConcurrentHashMap<Transaction, TimerDataView>();
        this.counter = new AtomicLong(0L);
        this.transactionManager = transactionManager;
    }
    
    @Override
    public TimerData getTimer(final String deploymentId, final long timerId) {
        try {
            final TimerDataView tasks = this.getTasks();
            return tasks.getTasks().get(timerId);
        }
        catch (TimerStoreException e) {
            return null;
        }
    }
    
    @Override
    public Collection<TimerData> getTimers(final String deploymentId) {
        try {
            final TimerDataView tasks = this.getTasks();
            return new ArrayList<TimerData>(tasks.getTasks().values());
        }
        catch (TimerStoreException e) {
            return (Collection<TimerData>)Collections.emptySet();
        }
    }
    
    @Override
    public Collection<TimerData> loadTimers(final EjbTimerServiceImpl timerService, final String deploymentId) throws TimerStoreException {
        final TimerDataView tasks = this.getTasks();
        final Collection<TimerData> out = new LinkedList<TimerData>();
        for (final TimerData data : tasks.getTasks().values()) {
            if (deploymentId == null || deploymentId.equals(data.getDeploymentId())) {
                out.add(data);
            }
        }
        return out;
    }
    
    @Override
    public void addTimerData(final TimerData timerData) throws TimerStoreException {
        this.getTasks().addTimerData(timerData);
    }
    
    @Override
    public TimerData createCalendarTimer(final EjbTimerServiceImpl timerService, final String deploymentId, final Object primaryKey, final Method timeoutMethod, final ScheduleExpression scheduleExpression, final TimerConfig timerConfig, final boolean auto) throws TimerStoreException {
        final long id = this.counter.incrementAndGet();
        final TimerData timerData = new CalendarTimerData(id, timerService, deploymentId, primaryKey, timeoutMethod, timerConfig, scheduleExpression, auto);
        this.getTasks().addTimerData(timerData);
        return timerData;
    }
    
    @Override
    public TimerData createIntervalTimer(final EjbTimerServiceImpl timerService, final String deploymentId, final Object primaryKey, final Method timeoutMethod, final Date initialExpiration, final long intervalDuration, final TimerConfig timerConfig) throws TimerStoreException {
        final long id = this.counter.incrementAndGet();
        final TimerData timerData = new IntervalTimerData(id, timerService, deploymentId, primaryKey, timeoutMethod, timerConfig, initialExpiration, intervalDuration);
        this.getTasks().addTimerData(timerData);
        return timerData;
    }
    
    @Override
    public TimerData createSingleActionTimer(final EjbTimerServiceImpl timerService, final String deploymentId, final Object primaryKey, final Method timeoutMethod, final Date expiration, final TimerConfig timerConfig) throws TimerStoreException {
        final long id = this.counter.incrementAndGet();
        final TimerData timerData = new SingleActionTimerData(id, timerService, deploymentId, primaryKey, timeoutMethod, timerConfig, expiration);
        this.getTasks().addTimerData(timerData);
        return timerData;
    }
    
    @Override
    public void removeTimer(final long id) {
        try {
            this.getTasks().removeTimerData(id);
        }
        catch (TimerStoreException e) {
            MemoryTimerStore.log.warning("Unable to remove timer data from memory store", e);
        }
    }
    
    @Override
    public void updateIntervalTimer(final TimerData timerData) {
    }
    
    private TimerDataView getTasks() throws TimerStoreException {
        Transaction transaction = null;
        int status = 6;
        try {
            transaction = this.transactionManager.getTransaction();
            if (transaction != null) {
                status = transaction.getStatus();
            }
        }
        catch (SystemException ex) {}
        if (status != 0 && status != 1) {
            return new LiveTimerDataView();
        }
        TxTimerDataView tasks = this.tasksByTransaction.get(transaction);
        if (tasks == null) {
            tasks = new TxTimerDataView(transaction);
            this.tasksByTransaction.put(transaction, tasks);
        }
        return tasks;
    }
    
    static {
        log = Logger.getInstance(LogCategory.TIMER, "org.apache.openejb.util.resources");
    }
    
    private class LiveTimerDataView implements TimerDataView
    {
        @Override
        public Map<Long, TimerData> getTasks() {
            return new TreeMap<Long, TimerData>(MemoryTimerStore.this.taskStore);
        }
        
        @Override
        public void addTimerData(final TimerData timerData) {
            MemoryTimerStore.this.taskStore.put(timerData.getId(), timerData);
        }
        
        @Override
        public void removeTimerData(final Long timerId) {
            MemoryTimerStore.this.taskStore.remove(timerId);
        }
    }
    
    private class TxTimerDataView implements Synchronization, TimerDataView
    {
        private final Map<Long, TimerData> add;
        private final Set<Long> remove;
        private final Lock lock;
        private final RuntimeException concurentException;
        private final WeakReference<Transaction> tansactionReference;
        
        public TxTimerDataView(final Transaction transaction) throws TimerStoreException {
            this.add = new TreeMap<Long, TimerData>();
            this.remove = new TreeSet<Long>();
            (this.lock = new ReentrantLock()).lock();
            (this.concurentException = new IllegalThreadStateException("Object can only be invoked by Thread[" + Thread.currentThread().getName() + "] in Transaction[" + transaction + "]")).fillInStackTrace();
            try {
                transaction.registerSynchronization((Synchronization)this);
                this.tansactionReference = new WeakReference<Transaction>(transaction);
            }
            catch (RollbackException e) {
                throw new TimerStoreException("Transaction has been rolled back");
            }
            catch (SystemException e2) {
                throw new TimerStoreException("Error registering transaction synchronization callback");
            }
        }
        
        private void checkThread() {
            if (!this.lock.tryLock()) {
                throw new IllegalStateException("Illegal access by Thread[" + Thread.currentThread().getName() + "]", this.concurentException);
            }
        }
        
        public Map<Long, TimerData> getTasks() {
            this.checkThread();
            final TreeMap<Long, TimerData> allTasks = new TreeMap<Long, TimerData>();
            allTasks.putAll(MemoryTimerStore.this.taskStore);
            for (final Long key : this.remove) {
                allTasks.remove(key);
            }
            allTasks.putAll(this.add);
            return Collections.unmodifiableMap((Map<? extends Long, ? extends TimerData>)allTasks);
        }
        
        public void addTimerData(final TimerData timerData) {
            this.checkThread();
            final Long timerId = timerData.getId();
            this.remove.remove(timerId);
            this.add.put(timerId, timerData);
        }
        
        public void removeTimerData(final Long timerId) {
            this.checkThread();
            this.add.remove(timerId);
            this.remove.add(timerId);
        }
        
        public void beforeCompletion() {
            this.checkThread();
        }
        
        public void afterCompletion(final int status) {
            this.checkThread();
            if (status != 3) {
                return;
            }
            MemoryTimerStore.this.taskStore.putAll(this.add);
            MemoryTimerStore.this.taskStore.keySet().removeAll(this.remove);
            MemoryTimerStore.this.tasksByTransaction.remove(this.tansactionReference.get());
        }
    }
    
    private interface TimerDataView
    {
        Map<Long, TimerData> getTasks();
        
        void addTimerData(final TimerData p0);
        
        void removeTimerData(final Long p0);
    }
}
