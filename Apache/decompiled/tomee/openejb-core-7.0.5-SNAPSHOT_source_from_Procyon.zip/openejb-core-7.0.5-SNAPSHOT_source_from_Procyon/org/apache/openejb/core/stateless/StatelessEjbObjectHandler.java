// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateless;

import org.apache.openejb.util.proxy.ProxyManager;
import java.rmi.RemoteException;
import java.lang.reflect.Method;
import org.apache.openejb.Container;
import java.util.List;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ivm.EjbObjectProxyHandler;

public class StatelessEjbObjectHandler extends EjbObjectProxyHandler
{
    public Object registryId;
    
    public StatelessEjbObjectHandler(final BeanContext beanContext, final Object pk, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        super(beanContext, pk, interfaceType, interfaces, mainInterface);
    }
    
    public static Object createRegistryId(final Object primKey, final Object deployId, final Container contnr) {
        return String.valueOf(deployId) + contnr.getContainerID();
    }
    
    @Override
    public Object getRegistryId() {
        if (this.registryId == null) {
            this.registryId = createRegistryId(this.primaryKey, this.deploymentID, this.container);
        }
        return this.registryId;
    }
    
    @Override
    protected Object getPrimaryKey(final Method method, final Object[] args, final Object proxy) throws Throwable {
        throw new RemoteException("Session objects are private resources and do not have primary keys");
    }
    
    @Override
    protected Object isIdentical(final Method method, final Object[] args, final Object proxy) throws Throwable {
        try {
            final EjbObjectProxyHandler handler = (EjbObjectProxyHandler)ProxyManager.getInvocationHandler(args[0]);
            return this.deploymentID.equals(handler.deploymentID);
        }
        catch (Throwable t) {
            return Boolean.FALSE;
        }
    }
    
    @Override
    public void invalidateReference() {
    }
    
    @Override
    protected Object remove(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        return null;
    }
}
