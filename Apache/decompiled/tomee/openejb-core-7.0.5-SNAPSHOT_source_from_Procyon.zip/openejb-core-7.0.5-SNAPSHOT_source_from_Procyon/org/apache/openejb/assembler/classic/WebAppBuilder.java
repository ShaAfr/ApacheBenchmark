// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.Set;
import java.util.Map;

public interface WebAppBuilder
{
    void deployWebApps(final AppInfo p0, final ClassLoader p1) throws Exception;
    
    void undeployWebApps(final AppInfo p0) throws Exception;
    
    Map<ClassLoader, Map<String, Set<String>>> getJsfClasses();
}
