// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.mdb;

import org.apache.openejb.resource.activemq.jms2.JMS2;
import javax.jms.Message;
import org.apache.openejb.resource.activemq.jms2.DelegateMessage;
import org.apache.openejb.ApplicationException;
import org.apache.openejb.InterfaceType;
import javax.ejb.EJBException;
import org.apache.openejb.SystemException;
import javax.resource.spi.ApplicationServerInternalException;
import java.util.Arrays;
import java.lang.reflect.Method;
import javax.resource.spi.UnavailableException;
import javax.transaction.xa.XAResource;
import org.apache.openejb.BeanContext;
import javax.resource.spi.endpoint.MessageEndpoint;
import java.lang.reflect.InvocationHandler;

public class EndpointHandler implements InvocationHandler, MessageEndpoint
{
    private volatile Boolean isAmq;
    private final MdbContainer container;
    private final BeanContext deployment;
    private final MdbInstanceFactory instanceFactory;
    private final XAResource xaResource;
    private State state;
    private Object instance;
    
    public EndpointHandler(final MdbContainer container, final BeanContext deployment, final MdbInstanceFactory instanceFactory, final XAResource xaResource) throws UnavailableException {
        this.state = State.NONE;
        this.container = container;
        this.deployment = deployment;
        this.instanceFactory = instanceFactory;
        this.xaResource = xaResource;
        this.instance = instanceFactory.createInstance(false);
    }
    
    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        final String methodName = method.getName();
        final Class<?>[] parameterTypes = method.getParameterTypes();
        if (method.getDeclaringClass() == Object.class) {
            if ("toString".equals(methodName) && parameterTypes.length == 0) {
                return this.toString();
            }
            if ("equals".equals(methodName) && parameterTypes.length == 1) {
                return this.equals(args[0]);
            }
            if ("hashCode".equals(methodName) && parameterTypes.length == 0) {
                return this.hashCode();
            }
            throw new UnsupportedOperationException("Unkown method: " + method);
        }
        else {
            if ("beforeDelivery".equals(methodName) && Arrays.deepEquals(new Class[] { Method.class }, parameterTypes)) {
                this.beforeDelivery((Method)args[0]);
                return null;
            }
            if ("afterDelivery".equals(methodName) && parameterTypes.length == 0) {
                this.afterDelivery();
                return null;
            }
            if ("release".equals(methodName) && parameterTypes.length == 0) {
                this.release();
                return null;
            }
            final Object value = this.deliverMessage(method, args);
            return value;
        }
    }
    
    public void beforeDelivery(final Method method) throws ApplicationServerInternalException {
        switch (this.state) {
            case RELEASED: {
                throw new IllegalStateException("Message endpoint factory has been released");
            }
            case BEFORE_CALLED: {
                throw new IllegalStateException("beforeDelivery can not be called again until message is delivered and afterDelivery is called");
            }
            case METHOD_CALLED:
            case SYSTEM_EXCEPTION: {
                throw new IllegalStateException("The last message delivery must be completed with an afterDeliver before beforeDeliver can be called again");
            }
            default: {
                try {
                    this.container.beforeDelivery(this.deployment, this.instance, method, this.xaResource);
                }
                catch (SystemException se) {
                    final Throwable throwable = (se.getRootCause() != null) ? se.getRootCause() : se;
                    throw new ApplicationServerInternalException(throwable);
                }
                this.state = State.BEFORE_CALLED;
            }
        }
    }
    
    public Object deliverMessage(final Method method, final Object[] args) throws Throwable {
        boolean callBeforeAfter = false;
        switch (this.state) {
            case NONE: {
                try {
                    this.beforeDelivery(method);
                }
                catch (ApplicationServerInternalException e) {
                    throw (EJBException)new EJBException().initCause(e.getCause());
                }
                callBeforeAfter = true;
                this.state = State.METHOD_CALLED;
                break;
            }
            case BEFORE_CALLED: {
                this.state = State.METHOD_CALLED;
                break;
            }
            case RELEASED: {
                throw new IllegalStateException("Message endpoint factory has been released");
            }
            case METHOD_CALLED:
            case SYSTEM_EXCEPTION: {
                throw new IllegalStateException("The last message delivery must be completed with an afterDeliver before another message can be delivered");
            }
        }
        Throwable throwable = null;
        Object value = null;
        try {
            value = this.container.invoke(this.instance, method, null, this.wrapMessageForAmq5(args));
        }
        catch (SystemException se) {
            throwable = ((se.getRootCause() != null) ? se.getRootCause() : se);
            this.state = State.SYSTEM_EXCEPTION;
        }
        catch (ApplicationException ae) {
            throwable = ((ae.getRootCause() != null) ? ae.getRootCause() : ae);
        }
        finally {
            if (callBeforeAfter) {
                try {
                    this.afterDelivery();
                }
                catch (ApplicationServerInternalException e2) {
                    throwable = ((throwable == null) ? e2.getCause() : throwable);
                }
                catch (UnavailableException e3) {
                    throwable = (Throwable)((throwable == null) ? e3 : throwable);
                }
            }
        }
        if (throwable == null) {
            return value;
        }
        throwable.printStackTrace();
        if (this.isValidException(method, throwable)) {
            throw throwable;
        }
        throw new EJBException().initCause(throwable);
    }
    
    private Object[] wrapMessageForAmq5(final Object[] args) {
        if (args == null || args.length != 1 || DelegateMessage.class.isInstance(args[0])) {
            return args;
        }
        if (this.isAmq == null) {
            synchronized (this) {
                if (this.isAmq == null) {
                    this.isAmq = args[0].getClass().getName().startsWith("org.apache.activemq.");
                }
            }
        }
        if (this.isAmq) {
            args[0] = JMS2.wrap(Message.class.cast(args[0]));
        }
        return args;
    }
    
    public void afterDelivery() throws ApplicationServerInternalException, UnavailableException {
        switch (this.state) {
            case RELEASED: {
                throw new IllegalStateException("Message endpoint factory has been released");
            }
            case BEFORE_CALLED: {
                throw new IllegalStateException("Exactally one message must be delivered between beforeDelivery and afterDelivery");
            }
            case NONE: {
                throw new IllegalStateException("afterDelivery may only be called if message delivery began with a beforeDelivery call");
            }
            default: {
                boolean exceptionThrown = false;
                try {
                    this.container.afterDelivery(this.instance);
                }
                catch (SystemException se) {
                    exceptionThrown = true;
                    final Throwable throwable = (se.getRootCause() != null) ? se.getRootCause() : se;
                    throwable.printStackTrace();
                    throw new ApplicationServerInternalException(throwable);
                }
                finally {
                    if (this.state == State.SYSTEM_EXCEPTION) {
                        this.recreateInstance(exceptionThrown);
                    }
                    this.state = State.NONE;
                }
            }
        }
    }
    
    private void recreateInstance(final boolean exceptionAlreadyThrown) throws UnavailableException {
        try {
            this.instance = this.instanceFactory.recreateInstance(this.instance);
        }
        catch (UnavailableException e) {
            this.state = State.RELEASED;
            if (!exceptionAlreadyThrown) {
                throw e;
            }
        }
    }
    
    public void release() {
        if (this.state == State.RELEASED) {
            return;
        }
        this.state = State.RELEASED;
        try {
            this.container.release(this.deployment, this.instance);
        }
        finally {
            this.instanceFactory.freeInstance((Instance)this.instance, false);
            this.instance = null;
        }
    }
    
    private boolean isValidException(final Method method, final Throwable throwable) {
        if (throwable instanceof RuntimeException || throwable instanceof Error) {
            return true;
        }
        final Class<?>[] exceptionTypes2;
        final Class<?>[] exceptionTypes = exceptionTypes2 = method.getExceptionTypes();
        for (final Class<?> exceptionType : exceptionTypes2) {
            if (exceptionType.isInstance(throwable)) {
                return true;
            }
        }
        return false;
    }
    
    private enum State
    {
        NONE, 
        BEFORE_CALLED, 
        METHOD_CALLED, 
        SYSTEM_EXCEPTION, 
        RELEASED;
    }
}
