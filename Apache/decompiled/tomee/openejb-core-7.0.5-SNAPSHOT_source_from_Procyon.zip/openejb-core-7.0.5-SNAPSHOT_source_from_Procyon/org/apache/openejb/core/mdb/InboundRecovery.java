// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.mdb;

import org.apache.openejb.OpenEJBException;
import javax.resource.spi.ActivationSpec;
import javax.resource.spi.ResourceAdapter;

public interface InboundRecovery
{
    void recover(final ResourceAdapter p0, final ActivationSpec p1, final String p2) throws OpenEJBException;
}
