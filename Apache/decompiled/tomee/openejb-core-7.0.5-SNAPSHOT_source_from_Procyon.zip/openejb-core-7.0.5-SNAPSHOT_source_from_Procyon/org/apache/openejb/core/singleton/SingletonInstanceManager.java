// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.singleton;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import org.apache.openejb.util.LogCategory;
import javax.naming.Context;
import javax.management.ObjectName;
import javax.management.MBeanServer;
import javax.naming.NamingException;
import org.apache.openejb.core.timer.TimerServiceWrapper;
import org.apache.openejb.monitoring.ManagedMBean;
import org.apache.openejb.monitoring.LocalMBeanServer;
import org.apache.openejb.monitoring.ObjectNameBuilder;
import org.apache.openejb.monitoring.StatsInterceptor;
import javax.ejb.EJBContext;
import org.apache.openejb.core.transaction.TransactionPolicy;
import java.util.Set;
import org.apache.openejb.cdi.CdiEjbBean;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import org.apache.openejb.core.transaction.TransactionType;
import org.apache.openejb.BeanType;
import org.apache.openejb.core.BaseContext;
import java.util.concurrent.locks.ReadWriteLock;
import java.lang.reflect.Method;
import org.apache.openejb.core.InstanceContext;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.Map;
import java.util.List;
import org.apache.openejb.core.interceptor.InterceptorStack;
import java.util.HashMap;
import org.apache.openejb.core.interceptor.InterceptorData;
import java.util.ArrayList;
import org.apache.openejb.core.Operation;
import javax.ejb.SessionBean;
import java.util.Iterator;
import org.apache.openejb.spi.ContainerSystem;
import org.apache.openejb.loader.SystemInstance;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.ExecutionException;
import org.apache.openejb.ApplicationException;
import javax.ejb.NoSuchEJBException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.BeanContext;
import javax.ejb.SessionContext;
import javax.xml.ws.WebServiceContext;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.Logger;

public class SingletonInstanceManager
{
    private static final Logger logger;
    private final SecurityService securityService;
    private final SingletonContext sessionContext;
    private final WebServiceContext webServiceContext;
    
    public SingletonInstanceManager(final SecurityService securityService) {
        this.securityService = securityService;
        this.sessionContext = new SingletonContext(this.securityService);
        this.webServiceContext = (WebServiceContext)new EjbWsContext((SessionContext)this.sessionContext);
    }
    
    protected void start(final BeanContext beanContext) throws OpenEJBException {
        if (beanContext.isLoadOnStartup()) {
            this.initialize(beanContext);
        }
    }
    
    private void initialize(final BeanContext beanContext) throws OpenEJBException {
        try {
            final ThreadContext callContext = new ThreadContext(beanContext, null);
            final ThreadContext old = ThreadContext.enter(callContext);
            try {
                this.getInstance(callContext);
            }
            finally {
                ThreadContext.exit(old);
            }
        }
        catch (OpenEJBException e) {
            throw new OpenEJBException("Singleton startup failed: " + beanContext.getDeploymentID(), e);
        }
    }
    
    public Instance getInstance(final ThreadContext callContext) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final Data data = (Data)beanContext.getContainerData();
        final AtomicReference<Future<Instance>> singleton = data.singleton;
        try {
            Future<Instance> singletonFuture = singleton.get();
            if (singletonFuture != null) {
                return singletonFuture.get();
            }
            final FutureTask<Instance> task = new FutureTask<Instance>(new Callable<Instance>() {
                @Override
                public Instance call() throws Exception {
                    return SingletonInstanceManager.this.createInstance(callContext, beanContext);
                }
            });
            do {
                if (singleton.compareAndSet(null, task)) {
                    task.run();
                }
            } while ((singletonFuture = singleton.get()) == null);
            return singletonFuture.get();
        }
        catch (InterruptedException e) {
            Thread.interrupted();
            throw new ApplicationException(new NoSuchEJBException("Singleton initialization interrupted").initCause((Throwable)e));
        }
        catch (ExecutionException e2) {
            final Throwable throwable = e2.getCause();
            if (throwable instanceof ApplicationException) {
                throw (ApplicationException)throwable;
            }
            throw new ApplicationException(new NoSuchEJBException("Singleton initialization failed").initCause(e2.getCause()));
        }
    }
    
    private void initializeDependencies(final BeanContext beanContext) throws OpenEJBException {
        final SystemInstance systemInstance = SystemInstance.get();
        final ContainerSystem containerSystem = (ContainerSystem)systemInstance.getComponent((Class)ContainerSystem.class);
        for (final String dependencyId : beanContext.getDependsOn()) {
            final BeanContext dependencyContext = containerSystem.getBeanContext(dependencyId);
            if (dependencyContext == null) {
                throw new OpenEJBException("Deployment does not exist. Deployment(id='" + dependencyContext + "')");
            }
            final Object containerData = dependencyContext.getContainerData();
            if (!(containerData instanceof Data)) {
                continue;
            }
            final Data data = (Data)containerData;
            data.initialize();
        }
    }
    
    private Instance createInstance(final ThreadContext callContext, final BeanContext beanContext) throws ApplicationException {
        try {
            this.initializeDependencies(beanContext);
            final InstanceContext context = beanContext.newInstance();
            if (context.getBean() instanceof SessionBean) {
                final Operation originalOperation = callContext.getCurrentOperation();
                try {
                    callContext.setCurrentOperation(Operation.CREATE);
                    final Method create = beanContext.getCreateMethod();
                    final InterceptorStack ejbCreate = new InterceptorStack(context.getBean(), create, Operation.CREATE, new ArrayList<InterceptorData>(), new HashMap<String, Object>());
                    ejbCreate.invoke(new Object[0]);
                }
                finally {
                    callContext.setCurrentOperation(originalOperation);
                }
            }
            ReadWriteLock lock;
            if (beanContext.isBeanManagedConcurrency()) {
                lock = new BeanManagedLock();
            }
            else {
                lock = new ReentrantReadWriteLock();
            }
            return new Instance(context.getBean(), context.getInterceptors(), context.getCreationalContext(), lock);
        }
        catch (Throwable e) {
            if (e instanceof InvocationTargetException) {
                e = ((InvocationTargetException)e).getTargetException();
            }
            final String t = "The bean instance " + beanContext.getDeploymentID() + " threw a system exception:" + e;
            SingletonInstanceManager.logger.error(t, e);
            throw new ApplicationException(new NoSuchEJBException("Singleton failed to initialize").initCause(e));
        }
    }
    
    public void freeInstance(final ThreadContext callContext) {
        final BeanContext beanContext = callContext.getBeanContext();
        final Data data = (Data)beanContext.getContainerData();
        final Future<Instance> instanceFuture = data.singleton.get();
        if (instanceFuture == null) {
            return;
        }
        Instance instance;
        try {
            instance = instanceFuture.get();
        }
        catch (InterruptedException e) {
            Thread.interrupted();
            SingletonInstanceManager.logger.error("Singleton shutdown failed because the thread was interrupted: " + beanContext.getDeploymentID(), e);
            return;
        }
        catch (ExecutionException e3) {
            return;
        }
        try {
            callContext.setCurrentOperation(Operation.PRE_DESTROY);
            callContext.setCurrentAllowedStates(null);
            final Method remove = (instance.bean instanceof SessionBean) ? beanContext.getCreateMethod() : null;
            final List<InterceptorData> callbackInterceptors = beanContext.getCallbackInterceptors();
            final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, remove, Operation.PRE_DESTROY, callbackInterceptors, instance.interceptors);
            TransactionType transactionType;
            if (beanContext.getComponentType() == BeanType.SINGLETON) {
                final Set<Method> callbacks = callbackInterceptors.get(callbackInterceptors.size() - 1).getPreDestroy();
                if (callbacks.isEmpty()) {
                    transactionType = TransactionType.RequiresNew;
                }
                else {
                    transactionType = beanContext.getTransactionType(callbacks.iterator().next());
                    if (transactionType == TransactionType.Required) {
                        transactionType = TransactionType.RequiresNew;
                    }
                }
            }
            else {
                transactionType = (beanContext.isBeanManagedTransaction() ? TransactionType.BeanManaged : TransactionType.NotSupported);
            }
            final TransactionPolicy transactionPolicy = EjbTransactionUtil.createTransactionPolicy(transactionType, callContext);
            try {
                final CdiEjbBean<Object> bean = beanContext.get((Class<CdiEjbBean<Object>>)CdiEjbBean.class);
                if (bean != null) {
                    bean.getInjectionTarget().preDestroy(instance.bean);
                }
                interceptorStack.invoke(new Object[0]);
                if (instance.creationalContext != null) {
                    instance.creationalContext.release();
                }
            }
            catch (Throwable e2) {
                EjbTransactionUtil.handleSystemException(transactionPolicy, e2, callContext);
            }
            finally {
                EjbTransactionUtil.afterInvoke(transactionPolicy, callContext);
            }
        }
        catch (Throwable re) {
            SingletonInstanceManager.logger.error("Singleton shutdown failed: " + beanContext.getDeploymentID(), re);
        }
    }
    
    public void discardInstance(final ThreadContext callContext, final Object bean) {
    }
    
    public void deploy(final BeanContext beanContext) throws OpenEJBException {
        final Data data = new Data(beanContext);
        beanContext.setContainerData(data);
        beanContext.set((Class<Object>)EJBContext.class, this.sessionContext);
        if (StatsInterceptor.isStatsActivated()) {
            final StatsInterceptor stats = new StatsInterceptor(beanContext.getBeanClass());
            beanContext.addFirstSystemInterceptor(stats);
            final ObjectNameBuilder jmxName = new ObjectNameBuilder("openejb.management");
            jmxName.set("J2EEServer", "openejb");
            jmxName.set("J2EEApplication", null);
            jmxName.set("EJBModule", beanContext.getModuleID());
            jmxName.set("SingletonSessionBean", beanContext.getEjbName());
            jmxName.set("name", beanContext.getEjbName());
            jmxName.set("j2eeType", "Invocations");
            final MBeanServer server = LocalMBeanServer.get();
            try {
                final ObjectName objectName = jmxName.build();
                if (server.isRegistered(objectName)) {
                    server.unregisterMBean(objectName);
                }
                server.registerMBean(new ManagedMBean(stats), objectName);
                data.add(objectName);
            }
            catch (Exception e) {
                SingletonInstanceManager.logger.error("Unable to register MBean ", e);
            }
        }
        try {
            final Context context = beanContext.getJndiEnc();
            context.bind("comp/EJBContext", this.sessionContext);
            context.bind("comp/WebServiceContext", this.webServiceContext);
            context.bind("comp/TimerService", new TimerServiceWrapper());
        }
        catch (NamingException e2) {
            throw new OpenEJBException("Failed to bind EJBContext/WebServiceContext/TimerService", e2);
        }
    }
    
    public void undeploy(final BeanContext beanContext) {
        final Data data = (Data)beanContext.getContainerData();
        if (data == null) {
            return;
        }
        final MBeanServer server = LocalMBeanServer.get();
        for (final ObjectName objectName : data.jmxNames) {
            try {
                server.unregisterMBean(objectName);
            }
            catch (Exception e) {
                SingletonInstanceManager.logger.error("Unable to unregister MBean " + objectName);
            }
        }
        beanContext.setContainerData(null);
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
    
    private final class Data
    {
        private final AtomicReference<Future<Instance>> singleton;
        private final List<ObjectName> jmxNames;
        private final BeanContext info;
        
        public Data(final BeanContext info) {
            this.singleton = new AtomicReference<Future<Instance>>();
            this.jmxNames = new ArrayList<ObjectName>();
            this.info = info;
        }
        
        public ObjectName add(final ObjectName name) {
            this.jmxNames.add(name);
            return name;
        }
        
        public void initialize() throws OpenEJBException {
            SingletonInstanceManager.this.initialize(this.info);
        }
    }
    
    private static class BeanManagedLock implements ReadWriteLock
    {
        private final Lock lock;
        
        private BeanManagedLock() {
            this.lock = new Lock() {
                @Override
                public void lock() {
                }
                
                @Override
                public void lockInterruptibly() {
                }
                
                @Override
                public Condition newCondition() {
                    throw new UnsupportedOperationException("newCondition()");
                }
                
                @Override
                public boolean tryLock() {
                    return true;
                }
                
                @Override
                public boolean tryLock(final long time, final TimeUnit unit) {
                    return true;
                }
                
                @Override
                public void unlock() {
                }
            };
        }
        
        @Override
        public Lock readLock() {
            return this.lock;
        }
        
        @Override
        public Lock writeLock() {
            return this.lock;
        }
    }
}
