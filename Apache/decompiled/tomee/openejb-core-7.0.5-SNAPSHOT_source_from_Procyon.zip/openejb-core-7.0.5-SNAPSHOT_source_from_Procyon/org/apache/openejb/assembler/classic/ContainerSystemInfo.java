// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class ContainerSystemInfo extends InfoObject
{
    public final List<ContainerInfo> containers;
    public final List<AppInfo> applications;
    public final List<String> autoDeploy;
    
    public ContainerSystemInfo() {
        this.containers = new ArrayList<ContainerInfo>();
        this.applications = new ArrayList<AppInfo>();
        this.autoDeploy = new ArrayList<String>();
    }
}
