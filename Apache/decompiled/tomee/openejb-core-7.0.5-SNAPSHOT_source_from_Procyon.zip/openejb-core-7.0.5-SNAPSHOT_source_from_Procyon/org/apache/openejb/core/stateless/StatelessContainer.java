// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateless;

import java.util.concurrent.CopyOnWriteArrayList;
import javax.interceptor.AroundInvoke;
import org.apache.xbean.finder.ClassFinder;
import org.apache.openejb.core.webservices.AddressingSupport;
import org.apache.openejb.core.webservices.NoAddressingSupport;
import javax.xml.rpc.handler.MessageContext;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.openejb.core.interceptor.InterceptorData;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.SystemException;
import org.apache.openejb.core.ExceptionType;
import org.apache.openejb.core.interceptor.InterceptorStack;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import javax.security.auth.login.LoginException;
import org.apache.openejb.core.Operation;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import org.apache.openejb.ProxyInfo;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.ApplicationException;
import javax.ejb.EJBAccessException;
import org.apache.openejb.core.security.AbstractSecurityService;
import org.apache.openejb.cdi.CurrentCreationalContext;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.core.timer.EjbTimerService;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.monitoring.StatsInterceptor;
import org.apache.openejb.Container;
import org.apache.openejb.ContainerType;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.Executors;
import org.apache.openejb.util.DaemonThreadFactory;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.openejb.util.Pool;
import org.apache.openejb.util.Duration;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.BeanContext;
import java.util.Map;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import org.apache.openejb.api.resource.DestroyableResource;
import org.apache.openejb.RpcContainer;

public class StatelessContainer implements RpcContainer, DestroyableResource
{
    private final ConcurrentMap<Class<?>, List<Method>> interceptorCache;
    private final StatelessInstanceManager instanceManager;
    private final Map<String, BeanContext> deploymentRegistry;
    private final Object containerID;
    private final SecurityService securityService;
    
    public StatelessContainer(final Object id, final SecurityService securityService, final Duration accessTimeout, final Duration closeTimeout, final Pool.Builder poolBuilder, final int callbackThreads, final boolean useOneSchedulerThreadByBean, final int evictionThreads) {
        this.interceptorCache = new ConcurrentHashMap<Class<?>, List<Method>>();
        this.deploymentRegistry = new ConcurrentHashMap<String, BeanContext>();
        this.containerID = id;
        this.securityService = securityService;
        this.instanceManager = new StatelessInstanceManager(securityService, accessTimeout, closeTimeout, poolBuilder, callbackThreads, useOneSchedulerThreadByBean ? null : Executors.newScheduledThreadPool(Math.max(evictionThreads, 1), new DaemonThreadFactory(new Object[] { id })));
    }
    
    public BeanContext[] getBeanContexts() {
        return this.deploymentRegistry.values().toArray(new BeanContext[this.deploymentRegistry.size()]);
    }
    
    public BeanContext getBeanContext(final Object deploymentID) {
        final String id = (String)deploymentID;
        return this.deploymentRegistry.get(id);
    }
    
    public ContainerType getContainerType() {
        return ContainerType.STATELESS;
    }
    
    public Object getContainerID() {
        return this.containerID;
    }
    
    public void deploy(final BeanContext beanContext) throws OpenEJBException {
        final String id = (String)beanContext.getDeploymentID();
        this.deploymentRegistry.put(id, beanContext);
        beanContext.setContainer(this);
        if (StatsInterceptor.isStatsActivated()) {
            final StatsInterceptor stats = new StatsInterceptor(beanContext.getBeanClass());
            beanContext.addFirstSystemInterceptor(stats);
        }
    }
    
    public void start(final BeanContext beanContext) throws OpenEJBException {
        this.instanceManager.deploy(beanContext);
        final EjbTimerService timerService = beanContext.getEjbTimerService();
        if (timerService != null) {
            timerService.start();
        }
    }
    
    public void stop(final BeanContext beanContext) throws OpenEJBException {
        beanContext.stop();
    }
    
    public void undeploy(final BeanContext beanContext) {
        this.instanceManager.undeploy(beanContext);
        final String id = (String)beanContext.getDeploymentID();
        beanContext.setContainer(null);
        beanContext.setContainerData(null);
        this.deploymentRegistry.remove(id);
    }
    
    @Override
    public Object invoke(final Object deployID, InterfaceType type, final Class callInterface, final Method callMethod, final Object[] args, final Object primKey) throws OpenEJBException {
        final BeanContext beanContext = this.getBeanContext(deployID);
        if (beanContext == null) {
            final String msg = "Deployment does not exist in this container. Deployment(id='" + deployID + "'), Container(id='" + this.containerID + "')";
            throw new OpenEJBException(msg);
        }
        if (type == null) {
            type = beanContext.getInterfaceType(callInterface);
        }
        final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        Instance bean = null;
        final CurrentCreationalContext currentCreationalContext = beanContext.get(CurrentCreationalContext.class);
        Object runAs = null;
        try {
            if (oldCallContext != null) {
                final BeanContext oldBc = oldCallContext.getBeanContext();
                if (oldBc.getRunAsUser() != null || oldBc.getRunAs() != null) {
                    runAs = AbstractSecurityService.class.cast(this.securityService).overrideWithRunAsContext(callContext, beanContext, oldBc);
                }
            }
            final boolean authorized = type == InterfaceType.TIMEOUT || this.securityService.isCallerAuthorized(callMethod, type);
            if (!authorized) {
                throw new ApplicationException((Exception)new EJBAccessException("Unauthorized Access by Principal Denied"));
            }
            final Class declaringClass = callMethod.getDeclaringClass();
            if (EJBHome.class.isAssignableFrom(declaringClass) || EJBLocalHome.class.isAssignableFrom(declaringClass)) {
                if (callMethod.getName().startsWith("create")) {
                    return new ProxyInfo(beanContext, null);
                }
                return null;
            }
            else {
                if (EJBObject.class == declaringClass || EJBLocalObject.class == declaringClass) {
                    return null;
                }
                bean = this.instanceManager.getInstance(callContext);
                callContext.setCurrentOperation((type == InterfaceType.TIMEOUT) ? Operation.TIMEOUT : Operation.BUSINESS);
                callContext.set(Method.class, runMethod);
                callContext.setInvokedInterface(callInterface);
                if (currentCreationalContext != null) {
                    currentCreationalContext.set(bean.creationalContext);
                }
                return this._invoke(callMethod, runMethod, args, bean, callContext, type);
            }
        }
        finally {
            if (runAs != null) {
                try {
                    this.securityService.associate(runAs);
                }
                catch (LoginException ex) {}
            }
            if (bean != null) {
                if (callContext.isDiscardInstance()) {
                    this.instanceManager.discardInstance(callContext, bean);
                }
                else {
                    this.instanceManager.poolInstance(callContext, bean);
                }
            }
            ThreadContext.exit(oldCallContext);
            if (currentCreationalContext != null) {
                currentCreationalContext.remove();
            }
        }
    }
    
    private Object _invoke(final Method callMethod, final Method runMethod, final Object[] args, final Instance instance, final ThreadContext callContext, final InterfaceType type) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, type), callContext);
        Object returnValue = null;
        try {
            if (type == InterfaceType.SERVICE_ENDPOINT) {
                callContext.setCurrentOperation(Operation.BUSINESS_WS);
                returnValue = this.invokeWebService(args, beanContext, runMethod, instance);
            }
            else {
                final List<InterceptorData> interceptors = beanContext.getMethodInterceptors(runMethod);
                final Operation operation = (type == InterfaceType.TIMEOUT) ? Operation.TIMEOUT : Operation.BUSINESS;
                final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, runMethod, operation, interceptors, instance.interceptors);
                returnValue = interceptorStack.invoke(args);
            }
        }
        catch (Throwable re) {
            final ExceptionType exceptionType = beanContext.getExceptionType(re);
            if (exceptionType == ExceptionType.SYSTEM) {
                callContext.setDiscardInstance(true);
                EjbTransactionUtil.handleSystemException(txPolicy, re, callContext);
            }
            else {
                EjbTransactionUtil.handleApplicationException(txPolicy, re, exceptionType == ExceptionType.APPLICATION_ROLLBACK);
            }
            try {
                EjbTransactionUtil.afterInvoke(txPolicy, callContext);
            }
            catch (SystemException | RuntimeException ex3) {
                final Exception ex;
                final Exception e = ex;
                callContext.setDiscardInstance(true);
                throw e;
            }
        }
        finally {
            try {
                EjbTransactionUtil.afterInvoke(txPolicy, callContext);
            }
            catch (SystemException | RuntimeException ex4) {
                final Exception ex2;
                final Exception e2 = ex2;
                callContext.setDiscardInstance(true);
                throw e2;
            }
        }
        return returnValue;
    }
    
    private Object invokeWebService(final Object[] args, final BeanContext beanContext, final Method runMethod, final Instance instance) throws Exception {
        if (args.length < 2) {
            throw new IllegalArgumentException("WebService calls must follow format {messageContext, interceptor, [arg...]}.");
        }
        final Object messageContext = args[0];
        final Object interceptor = args[1];
        final Class<?> interceptorClass = interceptor.getClass();
        final Map<String, Object> interceptors = new HashMap<String, Object>(instance.interceptors);
        interceptors.put(interceptor.getClass().getName(), interceptor);
        final List<InterceptorData> interceptorDatas = new ArrayList<InterceptorData>();
        final InterceptorData providerData = new InterceptorData(interceptorClass);
        providerData.getAroundInvoke().addAll(this.retrieveAroundInvokes(interceptorClass));
        interceptorDatas.add(0, providerData);
        interceptorDatas.addAll(beanContext.getMethodInterceptors(runMethod));
        final InterceptorStack interceptorStack = new InterceptorStack(instance.bean, runMethod, Operation.BUSINESS_WS, interceptorDatas, interceptors);
        final Object[] params = new Object[runMethod.getParameterTypes().length];
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        Object returnValue = null;
        if (messageContext instanceof MessageContext) {
            threadContext.set(MessageContext.class, (MessageContext)messageContext);
            returnValue = interceptorStack.invoke((MessageContext)messageContext, params);
        }
        else if (messageContext instanceof javax.xml.ws.handler.MessageContext) {
            AddressingSupport wsaSupport = NoAddressingSupport.INSTANCE;
            for (int i = 2; i < args.length; ++i) {
                if (args[i] instanceof AddressingSupport) {
                    wsaSupport = (AddressingSupport)args[i];
                }
            }
            threadContext.set(AddressingSupport.class, wsaSupport);
            threadContext.set(javax.xml.ws.handler.MessageContext.class, (javax.xml.ws.handler.MessageContext)messageContext);
            returnValue = interceptorStack.invoke((javax.xml.ws.handler.MessageContext)messageContext, params);
        }
        return returnValue;
    }
    
    private List<Method> retrieveAroundInvokes(final Class<?> interceptorClass) {
        final List<Method> cached = this.interceptorCache.get(interceptorClass);
        if (cached != null) {
            return cached;
        }
        final ClassFinder finder = new ClassFinder(new Class[] { interceptorClass });
        List<Method> annotated = (List<Method>)finder.findAnnotatedMethods((Class)AroundInvoke.class);
        if (StatelessContainer.class.getClassLoader() == interceptorClass.getClassLoader()) {
            final List<Method> value = new CopyOnWriteArrayList<Method>(annotated);
            annotated = this.interceptorCache.putIfAbsent(interceptorClass, annotated);
            if (annotated == null) {
                annotated = value;
            }
        }
        return annotated;
    }
    
    public void destroyResource() {
        this.instanceManager.destroy();
    }
}
