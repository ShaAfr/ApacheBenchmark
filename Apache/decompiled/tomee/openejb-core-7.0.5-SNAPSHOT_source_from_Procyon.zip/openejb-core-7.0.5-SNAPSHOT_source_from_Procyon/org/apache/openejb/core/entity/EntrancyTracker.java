// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.entity;

import org.apache.openejb.ApplicationException;
import java.rmi.RemoteException;
import org.apache.openejb.BeanContext;
import java.util.HashSet;
import javax.transaction.TransactionSynchronizationRegistry;
import java.util.Set;

public class EntrancyTracker
{
    private final ThreadLocal<Set<InstanceKey>> inCallThreadLocal;
    private final TransactionSynchronizationRegistry synchronizationRegistry;
    
    public EntrancyTracker(final TransactionSynchronizationRegistry synchronizationRegistry) {
        this.inCallThreadLocal = new ThreadLocal<Set<InstanceKey>>() {
            @Override
            protected Set<InstanceKey> initialValue() {
                return new HashSet<InstanceKey>();
            }
        };
        this.synchronizationRegistry = synchronizationRegistry;
    }
    
    public void enter(final BeanContext beanContext, final Object primaryKey) throws ApplicationException {
        if (primaryKey == null || beanContext.isReentrant()) {
            return;
        }
        final Object deploymentId = beanContext.getDeploymentID();
        final InstanceKey key = new InstanceKey(deploymentId, primaryKey);
        Set<InstanceKey> inCall;
        try {
            inCall = (Set<InstanceKey>)this.synchronizationRegistry.getResource((Object)EntrancyTracker.class);
            if (inCall == null) {
                inCall = new HashSet<InstanceKey>();
                this.synchronizationRegistry.putResource((Object)EntrancyTracker.class, (Object)inCall);
            }
        }
        catch (IllegalStateException e) {
            inCall = this.inCallThreadLocal.get();
        }
        if (!inCall.add(key)) {
            final ApplicationException exception = new ApplicationException(new RemoteException("Attempted reentrant access. Bean " + deploymentId + " is not reentrant and instance " + primaryKey + " has already been entered : " + inCall));
            exception.printStackTrace();
            throw exception;
        }
    }
    
    public void exit(final BeanContext beanContext, final Object primaryKey) throws ApplicationException {
        if (primaryKey == null || beanContext.isReentrant()) {
            return;
        }
        final Object deploymentId = beanContext.getDeploymentID();
        final InstanceKey key = new InstanceKey(deploymentId, primaryKey);
        Set<InstanceKey> inCall = null;
        try {
            inCall = (Set<InstanceKey>)this.synchronizationRegistry.getResource((Object)EntrancyTracker.class);
        }
        catch (IllegalStateException e) {
            inCall = this.inCallThreadLocal.get();
        }
        if (inCall != null) {
            inCall.remove(key);
        }
    }
    
    private static class InstanceKey
    {
        private final Object deploymentId;
        private final Object primaryKey;
        
        public InstanceKey(final Object deploymentId, final Object primaryKey) {
            this.deploymentId = deploymentId;
            this.primaryKey = primaryKey;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final InstanceKey that = (InstanceKey)o;
            return this.deploymentId.equals(that.deploymentId) && this.primaryKey.equals(that.primaryKey);
        }
        
        @Override
        public int hashCode() {
            int result = this.deploymentId.hashCode();
            result = 31 * result + this.primaryKey.hashCode();
            return result;
        }
        
        @Override
        public String toString() {
            return this.deploymentId + ":" + this.primaryKey;
        }
    }
}
