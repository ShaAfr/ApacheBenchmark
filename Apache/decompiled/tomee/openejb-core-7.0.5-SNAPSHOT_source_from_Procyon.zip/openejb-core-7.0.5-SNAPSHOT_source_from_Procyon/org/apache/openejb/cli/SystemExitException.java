// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cli;

public class SystemExitException extends Exception
{
    private final int exitCode;
    
    public SystemExitException(final int exitCode) {
        this.exitCode = exitCode;
    }
    
    public int getExitCode() {
        return this.exitCode;
    }
}
