// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.component;

import java.util.concurrent.CopyOnWriteArrayList;
import java.net.URL;
import java.util.Collection;

public class ClassLoaderEnricher
{
    private final Collection<URL> applicationURLs;
    
    public ClassLoaderEnricher() {
        this.applicationURLs = new CopyOnWriteArrayList<URL>();
    }
    
    public URL[] applicationEnrichment() {
        return this.applicationURLs.toArray(new URL[this.applicationURLs.size()]);
    }
    
    public void addUrl(final URL url) {
        if (!this.applicationURLs.contains(url)) {
            this.applicationURLs.add(url);
        }
    }
    
    public void removeUrl(final URL url) {
        this.applicationURLs.remove(url);
    }
}
