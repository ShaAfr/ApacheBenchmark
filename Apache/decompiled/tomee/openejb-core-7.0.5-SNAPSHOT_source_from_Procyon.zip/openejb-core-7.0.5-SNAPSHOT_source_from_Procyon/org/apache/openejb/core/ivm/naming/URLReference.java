// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import java.net.MalformedURLException;
import javax.naming.NamingException;
import java.net.URL;

public class URLReference extends Reference
{
    private final String url;
    
    public URLReference(final String url) {
        this.url = url;
    }
    
    @Override
    public Object getObject() throws NamingException {
        try {
            return new URL(this.url);
        }
        catch (MalformedURLException e) {
            throw new NamingException("Invalid URL: " + this.url);
        }
    }
}
