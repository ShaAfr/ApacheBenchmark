// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.event;

import org.apache.openejb.observer.Event;

@Event
public class ResourceCreated extends ResourceEvent
{
    public ResourceCreated(final Object resource, final String name) {
        super(name, resource);
    }
}
