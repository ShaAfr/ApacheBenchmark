// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb;

import java.lang.reflect.Method;

public interface RpcContainer extends Container
{
    Object invoke(final Object p0, final InterfaceType p1, final Class p2, final Method p3, final Object[] p4, final Object p5) throws OpenEJBException;
}
