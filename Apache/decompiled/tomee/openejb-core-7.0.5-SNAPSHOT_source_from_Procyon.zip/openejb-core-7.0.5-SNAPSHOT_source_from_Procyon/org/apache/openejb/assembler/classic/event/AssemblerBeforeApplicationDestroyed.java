// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.event;

import org.apache.openejb.AppContext;
import org.apache.openejb.assembler.classic.AppInfo;
import org.apache.openejb.observer.Event;

@Event
public class AssemblerBeforeApplicationDestroyed
{
    private final AppInfo app;
    private final AppContext context;
    
    public AssemblerBeforeApplicationDestroyed(final AppInfo appInfo, final AppContext appContext) {
        this.app = appInfo;
        this.context = appContext;
    }
    
    public AppInfo getApp() {
        return this.app;
    }
    
    public AppContext getContext() {
        return this.context;
    }
    
    @Override
    public String toString() {
        return "AssemblerBeforeApplicationDestroyed{app=" + this.app.appId + "}";
    }
}
