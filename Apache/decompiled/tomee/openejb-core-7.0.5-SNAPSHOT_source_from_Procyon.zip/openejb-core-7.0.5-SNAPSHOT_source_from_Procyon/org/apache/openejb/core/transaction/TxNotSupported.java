// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.SystemException;
import javax.transaction.TransactionManager;
import javax.transaction.Transaction;

public class TxNotSupported extends JtaTransactionPolicy
{
    private final Transaction clientTx;
    
    public TxNotSupported(final TransactionManager transactionManager) throws SystemException {
        super(TransactionType.NotSupported, transactionManager);
        this.clientTx = this.suspendTransaction();
    }
    
    @Override
    public boolean isNewTransaction() {
        return false;
    }
    
    @Override
    public boolean isClientTransaction() {
        return false;
    }
    
    @Override
    public Transaction getCurrentTransaction() {
        return null;
    }
    
    @Override
    public void commit() throws SystemException {
        this.fireNonTransactionalCompletion();
        if (this.clientTx != null) {
            this.resumeTransaction(this.clientTx);
        }
    }
}
