// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.util;

import javax.naming.Context;
import javax.naming.NamingException;
import org.apache.openejb.util.Logger;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.spi.ContainerSystem;
import java.util.Map;
import org.apache.xbean.recipe.Option;
import org.apache.xbean.recipe.UnsetPropertiesRecipe;
import org.apache.xbean.recipe.ObjectRecipe;
import org.apache.openejb.assembler.classic.Assembler;
import java.util.Properties;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.assembler.classic.OpenEjbConfiguration;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.openejb.assembler.classic.ServiceInfo;
import java.util.Collection;

public final class ServiceInfos
{
    private ServiceInfos() {
    }
    
    public static Object resolve(final Collection<ServiceInfo> services, final String id) {
        if (id == null) {
            return null;
        }
        try {
            return build(services, find(services, id));
        }
        catch (OpenEJBException e) {
            throw new OpenEJBRuntimeException(e);
        }
    }
    
    public static ServiceInfo find(final Collection<ServiceInfo> services, final String id) {
        for (final ServiceInfo s : services) {
            if (id.equals(s.id)) {
                return s;
            }
        }
        return null;
    }
    
    public static ServiceInfo findByClass(final Collection<ServiceInfo> services, final String clazz) {
        for (final ServiceInfo s : services) {
            if (clazz.equals(s.className)) {
                return s;
            }
        }
        return null;
    }
    
    public static List<Object> resolve(final Collection<ServiceInfo> serviceInfos, final String[] ids) {
        return resolve(serviceInfos, ids, null);
    }
    
    public static List<Object> resolve(final Collection<ServiceInfo> serviceInfos, final String[] ids, final Factory factory) {
        if (ids == null || ids.length == 0) {
            return null;
        }
        final List<Object> instances = new ArrayList<Object>();
        for (final String id : ids) {
            Object instance = resolve(serviceInfos, id);
            if (instance == null) {
                try {
                    final Class<?> aClass = Thread.currentThread().getContextClassLoader().loadClass(id);
                    if (factory == null) {
                        instance = aClass.newInstance();
                    }
                    else {
                        instance = factory.newInstance(aClass);
                    }
                }
                catch (Exception ex) {}
            }
            if (instance == null) {
                instance = resolve(((OpenEjbConfiguration)SystemInstance.get().getComponent((Class)OpenEjbConfiguration.class)).facilities.services, id);
            }
            if (instance != null) {
                instances.add(instance);
            }
        }
        return instances;
    }
    
    public static Properties serviceProperties(final Collection<ServiceInfo> serviceInfos, final String id) {
        if (id == null) {
            return null;
        }
        final ServiceInfo info = find(serviceInfos, id);
        if (info == null) {
            return null;
        }
        return info.properties;
    }
    
    private static Object build(final Collection<ServiceInfo> services, final ServiceInfo info) throws OpenEJBException {
        if (info == null) {
            return null;
        }
        final ObjectRecipe serviceRecipe = Assembler.prepareRecipe(info);
        return build(services, info, serviceRecipe);
    }
    
    public static Object build(final Collection<ServiceInfo> services, final ServiceInfo info, final ObjectRecipe serviceRecipe) {
        if ("org.apache.openejb.config.sys.MapFactory".equals(info.className)) {
            return info.properties;
        }
        if (!info.properties.containsKey("properties")) {
            info.properties.put("properties", new UnsetPropertiesRecipe());
        }
        serviceRecipe.allow(Option.FIELD_INJECTION);
        serviceRecipe.allow(Option.PRIVATE_PROPERTIES);
        setProperties(services, info, serviceRecipe);
        final Object service = serviceRecipe.create();
        SystemInstance.get().addObserver(service);
        Assembler.logUnusedProperties(serviceRecipe, info);
        return service;
    }
    
    public static void setProperties(final Collection<ServiceInfo> services, final ServiceInfo info, final ObjectRecipe serviceRecipe) {
        for (final Map.Entry<Object, Object> entry : info.properties.entrySet()) {
            final String key = entry.getKey().toString();
            final Object value = entry.getValue();
            if (value instanceof String) {
                String valueStr = value.toString();
                if (valueStr.startsWith("collection:")) {
                    valueStr = valueStr.substring("collection:".length());
                    final String[] elt = valueStr.split(" *, *");
                    final List<Object> val = new ArrayList<Object>(elt.length);
                    for (final String e : elt) {
                        if (!e.trim().isEmpty()) {
                            val.add(e.startsWith("@") ? lookup(e) : resolve(services, e.startsWith("$") ? e.substring(1) : e));
                        }
                    }
                    serviceRecipe.setProperty(key, (Object)val);
                }
                else if (valueStr.startsWith("$")) {
                    serviceRecipe.setProperty(key, resolve(services, valueStr.substring(1)));
                }
                else if (valueStr.startsWith("@")) {
                    serviceRecipe.setProperty(key, lookup(value));
                }
                else {
                    serviceRecipe.setProperty(key, value);
                }
            }
            else {
                serviceRecipe.setProperty(key, entry.getValue());
            }
        }
    }
    
    private static Object lookup(final Object value) {
        final String name = String.valueOf(value).substring(1);
        final Context jndiContext = ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext();
        Object lookup;
        try {
            lookup = jndiContext.lookup("openejb/Resource/" + name);
        }
        catch (NamingException e) {
            try {
                lookup = jndiContext.lookup(name);
            }
            catch (NamingException e2) {
                Logger.getInstance(LogCategory.OPENEJB, ServiceInfos.class).warning("Value " + name + " starting with @ but doesn't point to an existing resource, using raw value");
                lookup = value;
            }
        }
        return lookup;
    }
    
    public interface Factory
    {
        Object newInstance(final Class<?> p0) throws Exception;
    }
}
