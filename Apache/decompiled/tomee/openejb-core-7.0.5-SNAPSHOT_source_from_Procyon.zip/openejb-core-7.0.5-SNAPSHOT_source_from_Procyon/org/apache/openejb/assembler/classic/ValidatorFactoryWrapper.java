// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.LogCategory;
import javax.validation.ParameterNameProvider;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.TraversableResolver;
import javax.validation.MessageInterpolator;
import javax.validation.ValidatorContext;
import javax.validation.Validator;
import javax.naming.NamingException;
import org.apache.openejb.bval.ValidatorUtil;
import java.util.Map;
import org.apache.openejb.util.Logger;
import java.io.Serializable;
import javax.validation.ValidatorFactory;

public class ValidatorFactoryWrapper implements ValidatorFactory, Serializable
{
    public static final Logger logger;
    private transient Map<ComparableValidationConfig, ValidatorFactory> fallbackValidators;
    
    private ValidatorFactory factory() {
        try {
            return ValidatorUtil.lookupFactory();
        }
        catch (NamingException e) {
            if (this.fallbackValidators != null && !this.fallbackValidators.isEmpty()) {
                return this.fallbackValidators.values().iterator().next();
            }
            return ValidatorUtil.tryJndiLaterFactory();
        }
    }
    
    public ValidatorFactoryWrapper(final Map<ComparableValidationConfig, ValidatorFactory> validators) {
        this.fallbackValidators = validators;
    }
    
    public Validator getValidator() {
        return this.factory().getValidator();
    }
    
    public ValidatorContext usingContext() {
        return this.factory().usingContext();
    }
    
    public MessageInterpolator getMessageInterpolator() {
        return this.factory().getMessageInterpolator();
    }
    
    public TraversableResolver getTraversableResolver() {
        return this.factory().getTraversableResolver();
    }
    
    public ConstraintValidatorFactory getConstraintValidatorFactory() {
        return this.factory().getConstraintValidatorFactory();
    }
    
    public <T> T unwrap(final Class<T> tClass) {
        return (T)this.factory().unwrap((Class)tClass);
    }
    
    public ParameterNameProvider getParameterNameProvider() {
        return this.factory().getParameterNameProvider();
    }
    
    public void close() {
        this.factory().close();
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, ValidatorFactoryWrapper.class);
    }
}
