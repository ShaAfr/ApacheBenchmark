// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import javax.naming.NameNotFoundException;
import org.apache.openejb.loader.SystemInstance;

public class SystemComponentReference extends Reference
{
    private final Class<?> type;
    
    public SystemComponentReference(final Class<?> type) {
        if (type == null) {
            throw new NullPointerException("type is null");
        }
        this.type = type;
    }
    
    @Override
    public Object getObject() throws NamingException {
        final Object component = SystemInstance.get().getComponent((Class)this.type);
        if (component == null) {
            throw new NameNotFoundException("No " + this.type.getSimpleName() + " registered with the OpenEJB system");
        }
        return component;
    }
}
