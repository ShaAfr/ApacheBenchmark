// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.spi;

import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.InputStream;
import org.apache.openejb.core.ObjectInputStreamFiltered;
import java.io.ByteArrayInputStream;

public class Serializer
{
    public static Object deserialize(final byte[] bytes) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = null;
        try {
            final ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
            ois = new ObjectInputStreamFiltered(bais);
            return ois.readObject();
        }
        finally {
            if (ois != null) {
                ois.close();
            }
        }
    }
    
    public static byte[] serialize(final Object object) throws IOException {
        ObjectOutputStream oos = null;
        try {
            final ByteArrayOutputStream baos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(baos);
            oos.writeObject(object);
            oos.flush();
            return baos.toByteArray();
        }
        finally {
            if (oos != null) {
                oos.close();
            }
        }
    }
}
