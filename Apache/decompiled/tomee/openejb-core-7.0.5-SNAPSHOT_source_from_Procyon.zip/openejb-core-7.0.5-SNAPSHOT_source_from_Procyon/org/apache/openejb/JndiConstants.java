// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb;

public interface JndiConstants
{
    public static final String JAVA_OPENEJB_NAMING_CONTEXT = "openejb/";
    public static final String OPENEJB_RESOURCE_JNDI_PREFIX = "openejb/Resource/";
    public static final String PERSISTENCE_UNIT_NAMING_CONTEXT = "openejb/PersistenceUnit/";
    public static final String VALIDATOR_FACTORY_NAMING_CONTEXT = "openejb/ValidatorFactory/";
    public static final String VALIDATOR_NAMING_CONTEXT = "openejb/Validator/";
}
