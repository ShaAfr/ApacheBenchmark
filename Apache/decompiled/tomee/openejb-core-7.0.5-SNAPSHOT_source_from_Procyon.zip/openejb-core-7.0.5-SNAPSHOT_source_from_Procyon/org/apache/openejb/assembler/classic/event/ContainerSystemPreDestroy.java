// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.event;

import org.apache.openejb.observer.Event;

@Event
public class ContainerSystemPreDestroy
{
    @Override
    public String toString() {
        return "ContainerSystemPreDestroy{}";
    }
}
