// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.OpenEJBException;
import javax.ejb.ScheduleExpression;
import javax.ejb.TimerConfig;
import java.util.Date;
import java.lang.reflect.Method;
import java.util.Collection;
import javax.ejb.Timer;

public interface EjbTimerService
{
    Timer getTimer(final long p0);
    
    Collection<Timer> getTimers(final Object p0);
    
    Timer createTimer(final Object p0, final Method p1, final Date p2, final long p3, final TimerConfig p4);
    
    Timer createTimer(final Object p0, final Method p1, final Date p2, final TimerConfig p3);
    
    Timer createTimer(final Object p0, final Method p1, final long p2, final long p3, final TimerConfig p4);
    
    Timer createTimer(final Object p0, final Method p1, final long p2, final TimerConfig p3);
    
    Timer createTimer(final Object p0, final Method p1, final ScheduleExpression p2, final TimerConfig p3);
    
    void start() throws OpenEJBException;
    
    void stop();
    
    TimerStore getTimerStore();
    
    boolean isStarted();
}
