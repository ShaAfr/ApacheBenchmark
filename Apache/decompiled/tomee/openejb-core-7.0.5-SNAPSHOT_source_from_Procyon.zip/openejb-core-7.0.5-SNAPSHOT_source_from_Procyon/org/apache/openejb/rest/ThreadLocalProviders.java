// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.MessageBodyReader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.Providers;

public class ThreadLocalProviders extends AbstractRestThreadLocalProxy<Providers> implements Providers
{
    protected ThreadLocalProviders() {
        super(Providers.class);
    }
    
    public <T> ContextResolver<T> getContextResolver(final Class<T> rawType, final MediaType mediaType) {
        return (ContextResolver<T>)this.get().getContextResolver((Class)rawType, mediaType);
    }
    
    public <T extends Throwable> ExceptionMapper<T> getExceptionMapper(final Class<T> rawType) {
        return (ExceptionMapper<T>)this.get().getExceptionMapper((Class)rawType);
    }
    
    public <T> MessageBodyReader<T> getMessageBodyReader(final Class<T> rawType, final Type genericType, final Annotation[] annotations, final MediaType mediaType) {
        return (MessageBodyReader<T>)this.get().getMessageBodyReader((Class)rawType, genericType, annotations, mediaType);
    }
    
    public <T> MessageBodyWriter<T> getMessageBodyWriter(final Class<T> rawType, final Type genericType, final Annotation[] annotations, final MediaType mediaType) {
        return (MessageBodyWriter<T>)this.get().getMessageBodyWriter((Class)rawType, genericType, annotations, mediaType);
    }
}
