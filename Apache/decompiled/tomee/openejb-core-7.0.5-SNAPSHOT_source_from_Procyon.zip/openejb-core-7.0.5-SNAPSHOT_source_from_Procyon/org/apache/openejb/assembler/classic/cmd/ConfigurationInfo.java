// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.cmd;

import org.apache.openejb.assembler.classic.OpenEjbConfiguration;
import java.io.File;

public interface ConfigurationInfo
{
    OpenEjbConfiguration getOpenEjbConfiguration(final File p0) throws UnauthorizedException;
    
    public static class UnauthorizedException extends Exception
    {
        public UnauthorizedException(final String message) {
            super(message);
        }
    }
}
