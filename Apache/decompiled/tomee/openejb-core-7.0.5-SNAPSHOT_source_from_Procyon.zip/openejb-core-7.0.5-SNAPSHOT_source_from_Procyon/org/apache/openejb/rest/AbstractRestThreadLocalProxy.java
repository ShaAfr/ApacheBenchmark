// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import org.apache.openejb.loader.SystemInstance;
import java.io.Serializable;

public class AbstractRestThreadLocalProxy<T> implements Serializable
{
    private final ThreadLocal<T> infos;
    private final Class<T> clazz;
    
    protected AbstractRestThreadLocalProxy(final Class<T> clazz) {
        this.infos = new ThreadLocal<T>();
        this.clazz = clazz;
    }
    
    public T get() {
        T t = this.infos.get();
        if (t == null) {
            t = this.find();
        }
        return t;
    }
    
    public T find() {
        final RESTResourceFinder finder = (RESTResourceFinder)SystemInstance.get().getComponent((Class)RESTResourceFinder.class);
        if (finder != null) {
            return finder.find(this.clazz);
        }
        return null;
    }
    
    public void remove() {
        this.infos.remove();
    }
    
    public void set(final T value) {
        this.infos.set(value);
    }
}
