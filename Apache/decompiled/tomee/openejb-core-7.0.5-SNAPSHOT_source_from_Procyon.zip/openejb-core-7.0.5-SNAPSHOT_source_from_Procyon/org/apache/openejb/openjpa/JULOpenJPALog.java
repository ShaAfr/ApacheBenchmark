// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.openjpa;

import org.apache.openejb.util.JuliLogStream;
import java.util.logging.LogRecord;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.openejb.log.LoggerCreator;
import org.apache.openjpa.lib.log.Log;

public class JULOpenJPALog implements Log
{
    private final LoggerCreator logger;
    private final AtomicBoolean debug;
    private final AtomicBoolean info;
    
    public JULOpenJPALog(final LoggerCreator delegate) {
        this.debug = new AtomicBoolean(false);
        this.info = new AtomicBoolean(true);
        this.logger = delegate;
    }
    
    private Logger logger() {
        return LoggerCreator.Get.exec(this.logger, this.debug, this.info);
    }
    
    public boolean isTraceEnabled() {
        this.logger();
        return this.debug.get();
    }
    
    public boolean isInfoEnabled() {
        this.logger();
        return this.info.get();
    }
    
    public boolean isWarnEnabled() {
        return this.logger().isLoggable(Level.WARNING);
    }
    
    public boolean isErrorEnabled() {
        return this.logger().isLoggable(Level.SEVERE);
    }
    
    public boolean isFatalEnabled() {
        return this.logger().isLoggable(Level.SEVERE);
    }
    
    public void trace(final Object o) {
        if (this.isTraceEnabled()) {
            this.logger().log(this.record(o, Level.FINEST));
        }
    }
    
    public void trace(final Object o, final Throwable t) {
        if (this.isTraceEnabled()) {
            this.logger().log(this.record(o, t, Level.FINEST));
        }
    }
    
    public void info(final Object o) {
        this.logger().log(this.record(o, Level.INFO));
    }
    
    public void info(final Object o, final Throwable t) {
        this.logger().log(this.record(o, t, Level.INFO));
    }
    
    public void warn(final Object o) {
        this.logger().log(this.record(o, Level.WARNING));
    }
    
    public void warn(final Object o, final Throwable t) {
        this.logger().log(this.record(o, t, Level.WARNING));
    }
    
    public void error(final Object o) {
        this.logger().log(this.record(o.toString(), Level.SEVERE));
    }
    
    public void error(final Object o, final Throwable t) {
        this.logger().log(this.record(o, t, Level.SEVERE));
    }
    
    public void fatal(final Object o) {
        this.logger().log(this.record(o, Level.SEVERE));
    }
    
    public void fatal(final Object o, final Throwable t) {
        this.logger().log(this.record(o, t, Level.SEVERE));
    }
    
    private LogRecord record(final Object o, final Throwable t, final Level level) {
        final LogRecord record = this.record(o, level);
        record.setThrown(t);
        return record;
    }
    
    private LogRecord record(final Object o, final Level level) {
        final LogRecord record = new JuliLogStream.OpenEJBLogRecord(level, o.toString());
        record.setSourceMethodName(this.logger().getName());
        return record;
    }
}
