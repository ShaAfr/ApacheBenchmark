// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.util.ArrayList;
import java.util.Properties;
import org.apache.openejb.Injection;
import java.util.List;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.handler.PortInfo;

public class PortData implements PortInfo
{
    private String portId;
    private QName serviceName;
    private QName portName;
    private String bindingId;
    private URL wsdlUrl;
    private final List<HandlerChainData> handlerChains;
    private final List<Injection> injections;
    private boolean mtomEnabled;
    private QName wsdlPort;
    private QName wsdlService;
    private String location;
    private boolean secure;
    private Properties properties;
    
    public PortData() {
        this.handlerChains = new ArrayList<HandlerChainData>();
        this.injections = new ArrayList<Injection>();
    }
    
    public String getPortId() {
        return this.portId;
    }
    
    public void setPortId(final String portId) {
        this.portId = portId;
    }
    
    public QName getServiceName() {
        return this.serviceName;
    }
    
    public void setServiceName(final QName serviceName) {
        this.serviceName = serviceName;
    }
    
    public QName getPortName() {
        return this.portName;
    }
    
    public void setPortName(final QName portName) {
        this.portName = portName;
    }
    
    public String getBindingID() {
        return this.bindingId;
    }
    
    public void setBindingID(final String bindingId) {
        this.bindingId = bindingId;
    }
    
    public URL getWsdlUrl() {
        return this.wsdlUrl;
    }
    
    public void setWsdlUrl(final URL wsdlUrl) {
        this.wsdlUrl = wsdlUrl;
    }
    
    public List<HandlerChainData> getHandlerChains() {
        return this.handlerChains;
    }
    
    public List<Injection> getInjections() {
        return this.injections;
    }
    
    public boolean isMtomEnabled() {
        return this.mtomEnabled;
    }
    
    public void setMtomEnabled(final boolean mtomEnabled) {
        this.mtomEnabled = mtomEnabled;
    }
    
    public QName getWsdlPort() {
        return this.wsdlPort;
    }
    
    public void setWsdlPort(final QName wsdlPort) {
        this.wsdlPort = wsdlPort;
    }
    
    public QName getWsdlService() {
        return this.wsdlService;
    }
    
    public void setWsdlService(final QName wsdlService) {
        this.wsdlService = wsdlService;
    }
    
    public String getLocation() {
        return this.location;
    }
    
    public void setLocation(final String location) {
        this.location = location;
    }
    
    public void setSecure(final boolean secure) {
        this.secure = secure;
    }
    
    public boolean isSecure() {
        return this.secure;
    }
    
    public Properties getProperties() {
        return this.properties;
    }
    
    public void setProperties(final Properties properties) {
        this.properties = properties;
    }
}
