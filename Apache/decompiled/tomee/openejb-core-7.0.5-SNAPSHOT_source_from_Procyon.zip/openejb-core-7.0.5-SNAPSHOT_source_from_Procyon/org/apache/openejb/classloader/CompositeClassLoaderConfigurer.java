// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.classloader;

import java.util.Set;
import java.util.Collection;
import java.util.Arrays;
import java.util.HashSet;
import java.net.URL;

public class CompositeClassLoaderConfigurer implements ClassLoaderConfigurer
{
    private final ClassLoaderConfigurer[] composites;
    private final URL[] urls;
    
    public CompositeClassLoaderConfigurer(final ClassLoaderConfigurer... configurers) {
        this.composites = configurers;
        final Set<URL> urlSet = new HashSet<URL>();
        for (final ClassLoaderConfigurer configurer : configurers) {
            if (configurer != null) {
                urlSet.addAll(Arrays.asList(configurer.additionalURLs()));
            }
        }
        this.urls = urlSet.toArray(new URL[urlSet.size()]);
    }
    
    @Override
    public URL[] additionalURLs() {
        return this.urls;
    }
    
    @Override
    public boolean accept(final URL url) {
        for (final ClassLoaderConfigurer configurer : this.composites) {
            if (configurer != null && !configurer.accept(url)) {
                return false;
            }
        }
        return true;
    }
}
