// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import java.text.DateFormat;
import org.apache.openejb.quartz.impl.triggers.SimpleTriggerImpl;
import org.apache.openejb.quartz.impl.triggers.AbstractTrigger;
import javax.ejb.TimerConfig;
import java.lang.reflect.Method;
import java.util.Date;

public class IntervalTimerData extends TimerData
{
    private static final long serialVersionUID = 1L;
    private final long intervalDuration;
    private final Date initialExpiration;
    
    public IntervalTimerData(final long id, final EjbTimerServiceImpl timerService, final String deploymentId, final Object primaryKey, final Method timeoutMethod, final TimerConfig timerConfig, final Date initialExpiration, final long intervalDuration) {
        super(id, timerService, deploymentId, primaryKey, timeoutMethod, timerConfig);
        this.initialExpiration = initialExpiration;
        this.intervalDuration = intervalDuration;
    }
    
    @Override
    public TimerType getType() {
        return TimerType.Interval;
    }
    
    public long getIntervalDuration() {
        return this.intervalDuration;
    }
    
    public Date getInitialExpiration() {
        return this.initialExpiration;
    }
    
    public AbstractTrigger<?> initializeTrigger() {
        final SimpleTriggerImpl simpleTrigger = new SimpleTriggerImpl();
        final Date startTime = new Date(this.initialExpiration.getTime());
        simpleTrigger.setStartTime(startTime);
        simpleTrigger.setRepeatInterval(this.intervalDuration);
        simpleTrigger.setRepeatCount(-1);
        return (AbstractTrigger<?>)simpleTrigger;
    }
    
    @Override
    public String toString() {
        return TimerType.Interval.name() + " initialExpiration = [" + DateFormat.getDateTimeInstance().format(this.initialExpiration) + "] intervalDuration = [" + this.intervalDuration + "]";
    }
}
