// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.osgi.client;

import javax.naming.NamingException;
import org.apache.openejb.core.LocalInitialContext;
import javax.naming.Context;
import java.util.Hashtable;

public class LocalInitialContextFactory extends org.apache.openejb.core.LocalInitialContextFactory
{
    @Override
    public Context getInitialContext(final Hashtable env) throws NamingException {
        this.init(env);
        return new LocalInitialContext(env, this);
    }
}
