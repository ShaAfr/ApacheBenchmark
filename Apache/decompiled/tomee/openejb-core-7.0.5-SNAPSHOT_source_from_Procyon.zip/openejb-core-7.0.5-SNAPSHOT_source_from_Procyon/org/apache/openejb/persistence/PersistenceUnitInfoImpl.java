// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import org.apache.openejb.util.classloader.URLClassLoaderFirst;
import java.lang.instrument.ClassFileTransformer;
import javax.persistence.spi.ClassTransformer;
import java.net.MalformedURLException;
import java.util.Iterator;
import java.net.URI;
import java.io.IOException;
import java.io.File;
import org.apache.openejb.util.URLs;
import java.util.Collection;
import org.apache.openejb.resource.jdbc.managed.xa.DataSourceXADataSource;
import org.apache.openejb.loader.SystemInstance;
import javax.transaction.TransactionSynchronizationRegistry;
import org.apache.openejb.OpenEJB;
import javax.sql.XADataSource;
import javax.sql.CommonDataSource;
import java.util.ArrayList;
import javax.persistence.ValidationMode;
import javax.persistence.SharedCacheMode;
import java.util.Properties;
import java.net.URL;
import java.util.List;
import javax.sql.DataSource;
import javax.persistence.spi.PersistenceUnitTransactionType;
import javax.persistence.spi.PersistenceUnitInfo;

public class PersistenceUnitInfoImpl implements PersistenceUnitInfo
{
    private final PersistenceClassLoaderHandler persistenceClassLoaderHandler;
    private String id;
    private String persistenceUnitName;
    private String persistenceProviderClassName;
    private PersistenceUnitTransactionType transactionType;
    private DataSource jtaDataSource;
    private DataSource nonJtaDataSource;
    private final List<String> mappingFileNames;
    private final List<URL> jarFileUrls;
    private URL persistenceUnitRootUrl;
    private final List<String> managedClassNames;
    private boolean excludeUnlistedClasses;
    private Properties properties;
    private ClassLoader classLoader;
    private String persistenceXMLSchemaVersion;
    private SharedCacheMode sharedCacheMode;
    private ValidationMode validationMode;
    private String jtaDataSourceName;
    private String nonJtaDataSourceName;
    private boolean lazilyInitialized;
    
    public PersistenceUnitInfoImpl() {
        this.transactionType = PersistenceUnitTransactionType.JTA;
        this.mappingFileNames = new ArrayList<String>();
        this.jarFileUrls = new ArrayList<URL>();
        this.managedClassNames = new ArrayList<String>();
        this.sharedCacheMode = SharedCacheMode.UNSPECIFIED;
        this.persistenceClassLoaderHandler = null;
    }
    
    public PersistenceUnitInfoImpl(final PersistenceClassLoaderHandler persistenceClassLoaderHandler) {
        this.transactionType = PersistenceUnitTransactionType.JTA;
        this.mappingFileNames = new ArrayList<String>();
        this.jarFileUrls = new ArrayList<URL>();
        this.managedClassNames = new ArrayList<String>();
        this.sharedCacheMode = SharedCacheMode.UNSPECIFIED;
        this.persistenceClassLoaderHandler = persistenceClassLoaderHandler;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public String getPersistenceUnitName() {
        return this.persistenceUnitName;
    }
    
    public void setPersistenceUnitName(final String persistenceUnitName) {
        this.persistenceUnitName = persistenceUnitName;
    }
    
    public String getPersistenceProviderClassName() {
        return this.persistenceProviderClassName;
    }
    
    public void setPersistenceProviderClassName(final String persistenceProviderClassName) {
        this.persistenceProviderClassName = persistenceProviderClassName;
    }
    
    public PersistenceUnitTransactionType getTransactionType() {
        return this.transactionType;
    }
    
    public void setTransactionType(final PersistenceUnitTransactionType transactionType) {
        this.transactionType = transactionType;
    }
    
    public DataSource getJtaDataSource() {
        return this.jtaDataSource;
    }
    
    public void setJtaDataSource(final CommonDataSource jtaDataSource) {
        if (XADataSource.class.isInstance(jtaDataSource)) {
            this.jtaDataSource = new DataSourceXADataSource(jtaDataSource, OpenEJB.getTransactionManager(), (TransactionSynchronizationRegistry)SystemInstance.get().getComponent((Class)TransactionSynchronizationRegistry.class));
        }
        else {
            this.jtaDataSource = DataSource.class.cast(jtaDataSource);
        }
    }
    
    public DataSource getNonJtaDataSource() {
        return this.nonJtaDataSource;
    }
    
    public void setNonJtaDataSource(final CommonDataSource nonJtaDataSource) {
        if (XADataSource.class.isInstance(nonJtaDataSource)) {
            this.nonJtaDataSource = new DataSourceXADataSource(nonJtaDataSource, OpenEJB.getTransactionManager(), (TransactionSynchronizationRegistry)SystemInstance.get().getComponent((Class)TransactionSynchronizationRegistry.class));
        }
        else {
            this.nonJtaDataSource = DataSource.class.cast(nonJtaDataSource);
        }
    }
    
    public List<String> getMappingFileNames() {
        return this.mappingFileNames;
    }
    
    public void setMappingFileNames(final List<String> mappingFileNames) {
        if (mappingFileNames == null) {
            throw new NullPointerException("mappingFileNames is null");
        }
        this.mappingFileNames.clear();
        this.mappingFileNames.addAll(mappingFileNames);
    }
    
    public void addMappingFileName(final String mappingFileName) {
        if (mappingFileName == null) {
            throw new NullPointerException("mappingFileName is null");
        }
        this.mappingFileNames.add(mappingFileName);
    }
    
    public List<URL> getJarFileUrls() {
        return this.jarFileUrls;
    }
    
    public URL getPersistenceUnitRootUrl() {
        return this.persistenceUnitRootUrl;
    }
    
    public void setRootUrlAndJarUrls(final String persistenceUnitRootUrl, final List<String> jarFiles) throws MalformedURLException {
        File root;
        try {
            final URI rootUri = URLs.uri(persistenceUnitRootUrl);
            root = new File(rootUri);
        }
        catch (IllegalArgumentException e2) {
            root = new File(persistenceUnitRootUrl);
        }
        this.persistenceUnitRootUrl = this.toUrl(root);
        try {
            if (!jarFiles.isEmpty()) {
                File tmpRoot;
                if (root.getName().endsWith(".jar")) {
                    tmpRoot = root.getParentFile();
                }
                else {
                    tmpRoot = root;
                }
                for (final String path : jarFiles) {
                    this.jarFileUrls.add(this.toUrl(new File(tmpRoot, path).getCanonicalFile()));
                }
            }
        }
        catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
    
    private URL toUrl(final File root) throws MalformedURLException {
        if (!root.isFile() && root.getPath().startsWith("jar:file:")) {
            try {
                final String absolutePath = root.getAbsolutePath();
                final int endIndex = absolutePath.indexOf(33);
                if (endIndex > 0) {
                    final File file = new File(absolutePath.substring(0, endIndex));
                    if (file.isFile() && file.getName().endsWith(".jar")) {
                        return file.toURI().toURL();
                    }
                }
                return new URL(root.getPath());
            }
            catch (MalformedURLException ex) {}
        }
        return root.toURI().toURL();
    }
    
    public List<String> getManagedClassNames() {
        return this.managedClassNames;
    }
    
    public void setManagedClassNames(final List<String> managedClassNames) {
        if (managedClassNames == null) {
            throw new NullPointerException("managedClassNames is null");
        }
        this.managedClassNames.clear();
        this.managedClassNames.addAll(managedClassNames);
    }
    
    public void addManagedClassName(final String className) {
        this.managedClassNames.add(className);
    }
    
    public boolean excludeUnlistedClasses() {
        return this.excludeUnlistedClasses;
    }
    
    public void setExcludeUnlistedClasses(final boolean excludeUnlistedClasses) {
        this.excludeUnlistedClasses = excludeUnlistedClasses;
    }
    
    public Properties getProperties() {
        return this.properties;
    }
    
    public void setProperties(final Properties properties) {
        this.properties = properties;
    }
    
    public ClassLoader getClassLoader() {
        return this.classLoader;
    }
    
    public void setClassLoader(final ClassLoader classLoader) {
        this.classLoader = classLoader;
    }
    
    public void addTransformer(final ClassTransformer classTransformer) {
        if (this.persistenceClassLoaderHandler != null) {
            final PersistenceClassFileTransformer classFileTransformer = new PersistenceClassFileTransformer(classTransformer);
            this.persistenceClassLoaderHandler.addTransformer(this.id, this.classLoader, classFileTransformer);
        }
    }
    
    public ClassLoader getNewTempClassLoader() {
        if (this.persistenceClassLoaderHandler != null) {
            return this.persistenceClassLoaderHandler.getNewTempClassLoader(this.classLoader);
        }
        return null;
    }
    
    public boolean isLazilyInitialized() {
        return this.lazilyInitialized;
    }
    
    public void setLazilyInitialized(final boolean lazilyInitialized) {
        this.lazilyInitialized = lazilyInitialized;
    }
    
    public static boolean isServerClass(final String name) {
        if (name == null) {
            return false;
        }
        for (final String prefix : URLClassLoaderFirst.FORCED_SKIP) {
            if (name.startsWith(prefix)) {
                return true;
            }
        }
        for (final String prefix : URLClassLoaderFirst.FORCED_LOAD) {
            if (name.startsWith(prefix)) {
                return false;
            }
        }
        if (name.startsWith("java.")) {
            return true;
        }
        if (name.startsWith("javax.")) {
            return true;
        }
        if (name.startsWith("sun.")) {
            return true;
        }
        if (name.startsWith("com.sun.")) {
            return true;
        }
        if (!name.startsWith("org.")) {
            return name.startsWith("com.sun.") || name.startsWith("jdk.") || name.startsWith("javassist") || name.startsWith("serp.");
        }
        final String org = name.substring("org.".length());
        if (!org.startsWith("apache.")) {
            return org.startsWith("codehaus.swizzle") || org.startsWith("w3c.dom") || org.startsWith("quartz") || org.startsWith("eclipse.jdt.") || org.startsWith("slf4j") || org.startsWith("openejb") || org.startsWith("hsqldb") || org.startsWith("hibernate");
        }
        final String apache = org.substring("apache.".length());
        if (apache.startsWith("bval.")) {
            return true;
        }
        if (apache.startsWith("openjpa.")) {
            return true;
        }
        if (apache.startsWith("derby.")) {
            return true;
        }
        if (apache.startsWith("xbean.")) {
            return true;
        }
        if (apache.startsWith("geronimo.")) {
            return true;
        }
        if (apache.startsWith("coyote")) {
            return true;
        }
        if (apache.startsWith("webbeans.")) {
            return true;
        }
        if (apache.startsWith("log4j")) {
            return true;
        }
        if (apache.startsWith("catalina")) {
            return true;
        }
        if (apache.startsWith("jasper.")) {
            return true;
        }
        if (apache.startsWith("tomcat.")) {
            return true;
        }
        if (apache.startsWith("el.")) {
            return true;
        }
        if (apache.startsWith("jsp")) {
            return true;
        }
        if (apache.startsWith("naming")) {
            return true;
        }
        if (apache.startsWith("taglibs.")) {
            return true;
        }
        if (apache.startsWith("openejb.")) {
            return true;
        }
        if (apache.startsWith("openjpa.")) {
            return true;
        }
        if (apache.startsWith("myfaces.")) {
            return true;
        }
        if (apache.startsWith("juli.")) {
            return true;
        }
        if (apache.startsWith("webbeans.")) {
            return true;
        }
        if (apache.startsWith("cxf.")) {
            return true;
        }
        if (apache.startsWith("activemq.")) {
            return true;
        }
        if (apache.startsWith("commons.")) {
            final String commons = apache.substring("commons.".length());
            return commons.startsWith("beanutils") || commons.startsWith("cli") || commons.startsWith("codec") || commons.startsWith("collections") || commons.startsWith("dbcp") || commons.startsWith("digester") || commons.startsWith("jocl") || commons.startsWith("lang") || (!commons.startsWith("logging") && (commons.startsWith("pool") || commons.startsWith("net")));
        }
        return false;
    }
    
    public String getPersistenceXMLSchemaVersion() {
        return this.persistenceXMLSchemaVersion;
    }
    
    public void setPersistenceXMLSchemaVersion(final String persistenceXMLSchemaVersion) {
        this.persistenceXMLSchemaVersion = persistenceXMLSchemaVersion;
    }
    
    public SharedCacheMode getSharedCacheMode() {
        return this.sharedCacheMode;
    }
    
    public void setSharedCacheMode(final SharedCacheMode sharedCacheMode) {
        this.sharedCacheMode = ((null != sharedCacheMode) ? sharedCacheMode : SharedCacheMode.UNSPECIFIED);
    }
    
    public ValidationMode getValidationMode() {
        return this.validationMode;
    }
    
    public void setValidationMode(final ValidationMode validationMode) {
        this.validationMode = validationMode;
    }
    
    public String getJtaDataSourceName() {
        return this.jtaDataSourceName;
    }
    
    public void setJtaDataSourceName(final String jtaDataSourceName) {
        this.jtaDataSourceName = jtaDataSourceName;
    }
    
    public String getNonJtaDataSourceName() {
        return this.nonJtaDataSourceName;
    }
    
    public void setNonJtaDataSourceName(final String nonJtaDataSourceName) {
        this.nonJtaDataSourceName = nonJtaDataSourceName;
    }
    
    public static class PersistenceClassFileTransformer implements ClassFileTransformer
    {
        private final ClassTransformer classTransformer;
        
        public PersistenceClassFileTransformer(final ClassTransformer classTransformer) {
            this.classTransformer = classTransformer;
        }
        
        @Override
        public byte[] transform(final ClassLoader classLoader, final String className, final Class<?> classBeingRedefined, final ProtectionDomain protectionDomain, final byte[] classfileBuffer) throws IllegalClassFormatException {
            if (className == null) {
                return classfileBuffer;
            }
            final String replace = className.replace('/', '.');
            if (PersistenceUnitInfoImpl.isServerClass(replace)) {
                return classfileBuffer;
            }
            return this.classTransformer.transform(classLoader, replace, (Class)classBeingRedefined, protectionDomain, classfileBuffer);
        }
    }
}
