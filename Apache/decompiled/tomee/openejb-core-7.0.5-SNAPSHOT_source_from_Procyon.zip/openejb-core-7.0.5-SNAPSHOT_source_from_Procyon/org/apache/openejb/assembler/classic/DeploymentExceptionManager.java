// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.loader.SystemInstance;
import java.util.LinkedHashMap;
import java.util.Map;

public class DeploymentExceptionManager
{
    private static final int MAX_SIZE;
    private final Map<AppInfo, Exception> deploymentException;
    private Exception lastException;
    
    public DeploymentExceptionManager() {
        this.deploymentException = new LinkedHashMap<AppInfo, Exception>() {
            @Override
            protected boolean removeEldestEntry(final Map.Entry<AppInfo, Exception> eldest) {
                return this.size() > DeploymentExceptionManager.MAX_SIZE;
            }
        };
    }
    
    public synchronized boolean hasDeploymentFailed() {
        return this.lastException != null;
    }
    
    public synchronized Exception getDeploymentException(final AppInfo appInfo) {
        return this.deploymentException.get(appInfo);
    }
    
    public synchronized Exception saveDeploymentException(final AppInfo appInfo, final Exception exception) {
        this.lastException = exception;
        return this.deploymentException.put(appInfo, exception);
    }
    
    public synchronized void clearLastException(final AppInfo info) {
        if (info != null && this.deploymentException.get(info) == this.lastException) {
            this.deploymentException.remove(info);
        }
        this.lastException = null;
    }
    
    public Exception getLastException() {
        return this.lastException;
    }
    
    public void pushDelpoymentException(final Exception exception) {
        this.lastException = exception;
    }
    
    static {
        MAX_SIZE = SystemInstance.get().getOptions().get("tomee.deployement-exception-max-size", 10);
    }
}
