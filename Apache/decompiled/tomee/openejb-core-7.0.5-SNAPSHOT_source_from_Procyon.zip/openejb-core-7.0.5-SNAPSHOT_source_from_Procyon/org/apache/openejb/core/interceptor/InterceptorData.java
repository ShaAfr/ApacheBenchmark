// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.interceptor;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.openejb.util.SetAccessible;
import javax.interceptor.AroundTimeout;
import javax.ejb.AfterCompletion;
import javax.ejb.BeforeCompletion;
import javax.ejb.AfterBegin;
import javax.ejb.PrePassivate;
import javax.ejb.PostActivate;
import javax.annotation.PreDestroy;
import javax.annotation.PostConstruct;
import java.lang.annotation.Annotation;
import javax.interceptor.AroundInvoke;
import org.apache.xbean.finder.ClassFinder;
import java.util.Collection;
import java.util.Collections;
import org.apache.openejb.core.Operation;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.Map;

public class InterceptorData
{
    private static final Map<Class<?>, InterceptorData> CACHE;
    private final Class clazz;
    private final Set<Method> aroundInvoke;
    private final Set<Method> postConstruct;
    private final Set<Method> preDestroy;
    private final Set<Method> postActivate;
    private final Set<Method> prePassivate;
    private final Set<Method> afterBegin;
    private final Set<Method> beforeCompletion;
    private final Set<Method> afterCompletion;
    private final Set<Method> aroundTimeout;
    private final Map<Class<?>, Object> data;
    
    public InterceptorData(final Class clazz) {
        this.aroundInvoke = new LinkedHashSet<Method>();
        this.postConstruct = new LinkedHashSet<Method>();
        this.preDestroy = new LinkedHashSet<Method>();
        this.postActivate = new LinkedHashSet<Method>();
        this.prePassivate = new LinkedHashSet<Method>();
        this.afterBegin = new LinkedHashSet<Method>();
        this.beforeCompletion = new LinkedHashSet<Method>();
        this.afterCompletion = new LinkedHashSet<Method>();
        this.aroundTimeout = new LinkedHashSet<Method>();
        this.data = new HashMap<Class<?>, Object>();
        this.clazz = clazz;
    }
    
    public Class getInterceptorClass() {
        return this.clazz;
    }
    
    public Set<Method> getAroundInvoke() {
        return this.aroundInvoke;
    }
    
    public Set<Method> getPostConstruct() {
        return this.postConstruct;
    }
    
    public Set<Method> getPreDestroy() {
        return this.preDestroy;
    }
    
    public Set<Method> getPostActivate() {
        return this.postActivate;
    }
    
    public Set<Method> getPrePassivate() {
        return this.prePassivate;
    }
    
    public Set<Method> getAfterBegin() {
        return this.afterBegin;
    }
    
    public Set<Method> getBeforeCompletion() {
        return this.beforeCompletion;
    }
    
    public Set<Method> getAfterCompletion() {
        return this.afterCompletion;
    }
    
    public Set<Method> getAroundTimeout() {
        return this.aroundTimeout;
    }
    
    public Set<Method> getMethods(final Operation operation) {
        switch (operation) {
            case BUSINESS: {
                return this.getAroundInvoke();
            }
            case BUSINESS_WS: {
                return this.getAroundInvoke();
            }
            case REMOVE: {
                return this.getAroundInvoke();
            }
            case POST_CONSTRUCT: {
                return this.getPostConstruct();
            }
            case PRE_DESTROY: {
                return this.getPreDestroy();
            }
            case ACTIVATE: {
                return this.getPostActivate();
            }
            case PASSIVATE: {
                return this.getPrePassivate();
            }
            case AFTER_BEGIN: {
                return this.getAfterBegin();
            }
            case AFTER_COMPLETION: {
                return this.getAfterCompletion();
            }
            case BEFORE_COMPLETION: {
                return this.getBeforeCompletion();
            }
            case TIMEOUT: {
                return this.getAroundTimeout();
            }
            default: {
                return (Set<Method>)Collections.EMPTY_SET;
            }
        }
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final InterceptorData that = (InterceptorData)o;
        if (this.clazz != null) {
            if (this.clazz.equals(that.clazz)) {
                return true;
            }
        }
        else if (that.clazz == null) {
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return (this.clazz != null) ? this.clazz.hashCode() : 0;
    }
    
    public static void cacheScan(final Class<?> clazz) {
        InterceptorData.CACHE.put(clazz, scan(clazz));
    }
    
    public static InterceptorData scan(final Class<?> clazz) {
        final InterceptorData model = InterceptorData.CACHE.get(clazz);
        if (model != null) {
            final InterceptorData data = new InterceptorData(clazz);
            data.aroundInvoke.addAll(model.getAroundInvoke());
            data.postConstruct.addAll(model.getPostConstruct());
            data.preDestroy.addAll(model.getPreDestroy());
            data.postActivate.addAll(model.getPostActivate());
            data.prePassivate.addAll(model.getPrePassivate());
            data.afterBegin.addAll(model.getAfterBegin());
            data.beforeCompletion.addAll(model.getBeforeCompletion());
            data.afterCompletion.addAll(model.getAfterCompletion());
            data.aroundTimeout.addAll(model.getAroundTimeout());
            return data;
        }
        final ClassFinder finder = new ClassFinder(new Class[] { clazz });
        final InterceptorData data2 = new InterceptorData(clazz);
        add(finder, data2.aroundInvoke, (Class<? extends Annotation>)AroundInvoke.class);
        add(finder, data2.postConstruct, (Class<? extends Annotation>)PostConstruct.class);
        add(finder, data2.preDestroy, (Class<? extends Annotation>)PreDestroy.class);
        add(finder, data2.postActivate, (Class<? extends Annotation>)PostActivate.class);
        add(finder, data2.prePassivate, (Class<? extends Annotation>)PrePassivate.class);
        add(finder, data2.afterBegin, (Class<? extends Annotation>)AfterBegin.class);
        add(finder, data2.beforeCompletion, (Class<? extends Annotation>)BeforeCompletion.class);
        add(finder, data2.afterCompletion, (Class<? extends Annotation>)AfterCompletion.class);
        add(finder, data2.aroundTimeout, (Class<? extends Annotation>)AroundTimeout.class);
        return data2;
    }
    
    private static void add(final ClassFinder finder, final Set<Method> methods, final Class<? extends Annotation> annotation) {
        final List<Method> annotatedMethods = (List<Method>)finder.findAnnotatedMethods((Class)annotation);
        for (final Method method : annotatedMethods) {
            SetAccessible.on(method);
            methods.add(method);
        }
    }
    
    public <T> void set(final Class<T> clazz, final T value) {
        this.data.put(clazz, value);
    }
    
    public <T> T get(final Class<T> clazz) {
        return clazz.cast(this.data.get(clazz));
    }
    
    @Override
    public String toString() {
        return "InterceptorData{clazz=" + this.clazz.getSimpleName() + '}';
    }
    
    static {
        CACHE = new ConcurrentHashMap<Class<?>, InterceptorData>();
    }
}
