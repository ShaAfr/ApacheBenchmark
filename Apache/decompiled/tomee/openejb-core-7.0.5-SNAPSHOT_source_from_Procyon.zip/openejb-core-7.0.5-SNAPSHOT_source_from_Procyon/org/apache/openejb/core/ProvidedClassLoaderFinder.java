// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

public class ProvidedClassLoaderFinder implements ParentClassLoaderFinder
{
    private final ClassLoader loader;
    
    public ProvidedClassLoaderFinder(final ClassLoader tccl) {
        this.loader = tccl;
    }
    
    @Override
    public ClassLoader getParentClassLoader(final ClassLoader fallback) {
        return this.loader;
    }
}
