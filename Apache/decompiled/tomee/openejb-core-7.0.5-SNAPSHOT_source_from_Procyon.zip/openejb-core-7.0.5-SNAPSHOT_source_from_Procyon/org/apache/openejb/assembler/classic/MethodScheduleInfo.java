// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;

public class MethodScheduleInfo extends InfoObject
{
    public String description;
    public final List<ScheduleInfo> schedules;
    public NamedMethodInfo method;
    
    public MethodScheduleInfo() {
        this.schedules = new ArrayList<ScheduleInfo>();
    }
}
