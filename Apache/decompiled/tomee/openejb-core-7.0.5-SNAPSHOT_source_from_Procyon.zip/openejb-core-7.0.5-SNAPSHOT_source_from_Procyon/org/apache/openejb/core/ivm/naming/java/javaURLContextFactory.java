// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming.java;

import javax.naming.NameNotFoundException;
import org.apache.openejb.core.ivm.naming.ContextWrapper;
import org.apache.openejb.BeanContext;
import java.util.Iterator;
import org.apache.openejb.core.ivm.ContextHandler;
import org.apache.openejb.core.WebContext;
import org.apache.openejb.AppContext;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import org.apache.openejb.core.ThreadContext;
import javax.naming.NamingException;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.spi.ObjectFactory;

public class javaURLContextFactory implements ObjectFactory
{
    @Override
    public Object getObjectInstance(final Object obj, final Name name, final Context nameCtx, final Hashtable env) throws NamingException {
        return getContext();
    }
    
    public static Context getContext() {
        final ThreadContext callContext = ThreadContext.getThreadContext();
        if (callContext == null) {
            final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
            final ClassLoader current = Thread.currentThread().getContextClassLoader();
            final Context globalContext = containerSystem.getJNDIContext();
            if (current == null) {
                return globalContext;
            }
            for (final AppContext appContext : containerSystem.getAppContexts()) {
                for (final WebContext web : appContext.getWebContexts()) {
                    if (current.equals(web.getClassLoader())) {
                        return new ContextHandler(web.getJndiEnc());
                    }
                }
                if (current.equals(appContext.getClassLoader())) {
                    return new ContextHandler(appContext.getAppJndiContext());
                }
            }
            return globalContext;
        }
        else {
            final BeanContext di = callContext.getBeanContext();
            if (di != null) {
                return di.getJndiEnc();
            }
            final ContainerSystem containerSystem2 = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
            return containerSystem2.getJNDIContext();
        }
    }
    
    private static class ContextWithglobalFallbackWrapper extends ContextWrapper
    {
        public ContextWithglobalFallbackWrapper(final Context first) {
            super(first);
        }
        
        @Override
        public Object lookup(final Name name) throws NamingException {
            try {
                return super.lookup(name);
            }
            catch (NameNotFoundException nnfe) {
                try {
                    return ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext().lookup(name);
                }
                catch (NameNotFoundException ex) {
                    throw nnfe;
                }
            }
        }
        
        @Override
        public Object lookup(final String name) throws NamingException {
            try {
                return super.lookup(name);
            }
            catch (NameNotFoundException nnfe) {
                try {
                    return ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext().lookup(name);
                }
                catch (NameNotFoundException ex) {
                    throw nnfe;
                }
            }
        }
    }
}
