// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import javax.xml.ws.EndpointReference;
import org.w3c.dom.Element;

public interface AddressingSupport
{
    EndpointReference getEndpointReference(final Element... p0);
    
     <T extends EndpointReference> T getEndpointReference(final Class<T> p0, final Element... p1);
}
