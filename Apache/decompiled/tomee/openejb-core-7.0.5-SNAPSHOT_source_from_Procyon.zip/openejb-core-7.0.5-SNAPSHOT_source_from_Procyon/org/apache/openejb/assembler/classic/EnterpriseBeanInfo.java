// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;
import java.util.Properties;

public abstract class EnterpriseBeanInfo extends InfoObject
{
    public static final int ENTITY = 0;
    public static final int STATEFUL = 1;
    public static final int STATELESS = 2;
    public static final int MESSAGE = 3;
    public static final int SINGLETON = 4;
    public static final int MANAGED = 5;
    public int type;
    public final Properties properties;
    public String codebase;
    public String description;
    public String displayName;
    public String smallIcon;
    public String largeIcon;
    public String ejbDeploymentId;
    public String home;
    public String remote;
    public String localHome;
    public String local;
    public String proxy;
    public final List<String> businessLocal;
    public final List<String> businessRemote;
    public final List<String> parents;
    public boolean localbean;
    public String ejbClass;
    public String ejbName;
    public String transactionType;
    public String concurrencyType;
    public final JndiEncInfo jndiEnc;
    public NamedMethodInfo timeoutMethod;
    public String runAs;
    public String runAsUser;
    public final List<SecurityRoleReferenceInfo> securityRoleReferences;
    public final List<CallbackInfo> aroundInvoke;
    public final List<CallbackInfo> postConstruct;
    public final List<CallbackInfo> preDestroy;
    public final List<CallbackInfo> aroundTimeout;
    public final List<NamedMethodInfo> asynchronous;
    public Set<String> asynchronousClasses;
    public String containerId;
    public String serviceEndpoint;
    public List<JndiNameInfo> jndiNamess;
    public List<String> jndiNames;
    public boolean loadOnStartup;
    public final List<String> dependsOn;
    public TimeoutInfo statefulTimeout;
    public List<MethodScheduleInfo> methodScheduleInfos;
    public boolean restService;
    public boolean passivable;
    
    public EnterpriseBeanInfo() {
        this.properties = new Properties();
        this.businessLocal = new ArrayList<String>();
        this.businessRemote = new ArrayList<String>();
        this.parents = new ArrayList<String>();
        this.jndiEnc = new JndiEncInfo();
        this.securityRoleReferences = new ArrayList<SecurityRoleReferenceInfo>();
        this.aroundInvoke = new ArrayList<CallbackInfo>();
        this.postConstruct = new ArrayList<CallbackInfo>();
        this.preDestroy = new ArrayList<CallbackInfo>();
        this.aroundTimeout = new ArrayList<CallbackInfo>();
        this.asynchronous = new ArrayList<NamedMethodInfo>();
        this.asynchronousClasses = new HashSet<String>();
        this.jndiNamess = new ArrayList<JndiNameInfo>();
        this.jndiNames = new ArrayList<String>();
        this.dependsOn = new ArrayList<String>();
        this.methodScheduleInfos = new ArrayList<MethodScheduleInfo>();
    }
}
