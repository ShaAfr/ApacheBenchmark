// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive.summary;

import org.apache.openejb.math.stat.descriptive.UnivariateStatistic;
import org.apache.openejb.math.stat.descriptive.StorelessUnivariateStatistic;
import java.io.Serializable;
import org.apache.openejb.math.stat.descriptive.AbstractStorelessUnivariateStatistic;

public class SumOfLogs extends AbstractStorelessUnivariateStatistic implements Serializable
{
    private static final long serialVersionUID = -123076995648386763L;
    private int n;
    private double value;
    
    public SumOfLogs() {
        this.value = 0.0;
        this.n = 0;
    }
    
    public SumOfLogs(final SumOfLogs original) {
        copy(original, this);
    }
    
    @Override
    public void increment(final double d) {
        this.value += Math.log(d);
        ++this.n;
    }
    
    @Override
    public double getResult() {
        if (this.n > 0) {
            return this.value;
        }
        return Double.NaN;
    }
    
    @Override
    public long getN() {
        return this.n;
    }
    
    @Override
    public void clear() {
        this.value = 0.0;
        this.n = 0;
    }
    
    @Override
    public double evaluate(final double[] values, final int begin, final int length) {
        double sumLog = Double.NaN;
        if (this.test(values, begin, length)) {
            sumLog = 0.0;
            for (int i = begin; i < begin + length; ++i) {
                sumLog += Math.log(values[i]);
            }
        }
        return sumLog;
    }
    
    @Override
    public SumOfLogs copy() {
        final SumOfLogs result = new SumOfLogs();
        copy(this, result);
        return result;
    }
    
    public static void copy(final SumOfLogs source, final SumOfLogs dest) {
        dest.n = source.n;
        dest.value = source.value;
    }
}
