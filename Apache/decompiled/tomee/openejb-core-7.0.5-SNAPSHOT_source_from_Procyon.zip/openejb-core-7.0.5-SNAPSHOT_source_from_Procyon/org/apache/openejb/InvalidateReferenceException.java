// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb;

public class InvalidateReferenceException extends ApplicationException
{
    public InvalidateReferenceException() {
    }
    
    public InvalidateReferenceException(final String message) {
        super(message);
    }
    
    public InvalidateReferenceException(final Exception e) {
        super(e);
    }
    
    public InvalidateReferenceException(final Throwable t) {
        super(t);
    }
    
    public InvalidateReferenceException(final String message, final Exception e) {
        super(message, e);
    }
}
