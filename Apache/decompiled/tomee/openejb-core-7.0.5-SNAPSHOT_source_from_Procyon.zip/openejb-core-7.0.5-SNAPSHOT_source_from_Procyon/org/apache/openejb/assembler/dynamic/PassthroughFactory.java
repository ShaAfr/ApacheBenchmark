// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.dynamic;

import java.util.Properties;
import org.apache.openejb.assembler.classic.ServiceInfo;

public class PassthroughFactory
{
    public static Object create(final Object object) {
        return object;
    }
    
    public static void add(final ServiceInfo info, final Object object) {
        info.className = PassthroughFactory.class.getName();
        info.constructorArgs.add("object");
        info.factoryMethod = "create";
        (info.properties = new Properties()).put("object", object);
    }
}
