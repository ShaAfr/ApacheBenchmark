// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.util.LogCategory;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.HeuristicMixedException;
import java.rmi.RemoteException;
import javax.transaction.RollbackException;
import org.apache.openejb.ApplicationException;
import javax.transaction.InvalidTransactionException;
import java.lang.reflect.Method;
import javax.transaction.xa.XAResource;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import javax.transaction.Synchronization;
import java.util.LinkedHashMap;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import org.apache.openejb.loader.SystemInstance;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.transaction.TransactionSynchronizationRegistry;
import javax.transaction.TransactionManager;
import org.apache.openejb.util.Logger;

public abstract class JtaTransactionPolicy implements TransactionPolicy
{
    protected static final Logger logger;
    protected static final Logger txLogger;
    protected final TransactionType transactionType;
    protected final TransactionManager transactionManager;
    private final TransactionSynchronizationRegistry synchronizationRegistry;
    private Map<Object, Object> resources;
    private final List<TransactionSynchronization> synchronizations;
    private boolean rollbackOnly;
    
    public JtaTransactionPolicy(final TransactionType transactionType, final TransactionManager transactionManager) {
        this.synchronizations = new LinkedList<TransactionSynchronization>();
        this.transactionType = transactionType;
        this.transactionManager = transactionManager;
        this.synchronizationRegistry = (TransactionSynchronizationRegistry)SystemInstance.get().getComponent((Class)TransactionSynchronizationRegistry.class);
    }
    
    @Override
    public TransactionType getTransactionType() {
        return this.transactionType;
    }
    
    public abstract Transaction getCurrentTransaction();
    
    @Override
    public boolean isTransactionActive() {
        final Transaction trasaction = this.getCurrentTransaction();
        if (trasaction == null) {
            return false;
        }
        try {
            final int status = trasaction.getStatus();
            return status == 0 || status == 1;
        }
        catch (SystemException e) {
            return false;
        }
    }
    
    @Override
    public boolean isRollbackOnly() {
        final Transaction trasaction = this.getCurrentTransaction();
        if (trasaction != null) {
            try {
                final int status = trasaction.getStatus();
                return status == 1;
            }
            catch (SystemException e) {
                return false;
            }
        }
        return this.rollbackOnly;
    }
    
    @Override
    public void setRollbackOnly() {
        this.setRollbackOnly(null);
    }
    
    @Override
    public void setRollbackOnly(final Throwable reason) {
        final Transaction trasaction = this.getCurrentTransaction();
        if (trasaction != null) {
            this.setRollbackOnly(trasaction, reason);
        }
        else {
            this.rollbackOnly = true;
        }
    }
    
    @Override
    public Object getResource(final Object key) {
        if (this.isTransactionActive()) {
            return this.synchronizationRegistry.getResource(key);
        }
        if (this.resources == null) {
            return null;
        }
        return this.resources.get(key);
    }
    
    @Override
    public void putResource(final Object key, final Object value) {
        if (this.isTransactionActive()) {
            this.synchronizationRegistry.putResource(key, value);
        }
        if (this.resources == null) {
            this.resources = new LinkedHashMap<Object, Object>();
        }
        this.resources.put(key, value);
    }
    
    @Override
    public Object removeResource(final Object key) {
        if (this.isTransactionActive()) {
            final Object value = this.synchronizationRegistry.getResource(key);
            this.synchronizationRegistry.putResource(key, (Object)null);
            return value;
        }
        if (this.resources == null) {
            return null;
        }
        return this.resources.remove(key);
    }
    
    @Override
    public void registerSynchronization(final TransactionSynchronization synchronization) {
        if (this.isTransactionActive()) {
            this.synchronizationRegistry.registerInterposedSynchronization((Synchronization)new Synchronization() {
                public void beforeCompletion() {
                    synchronization.beforeCompletion();
                }
                
                public void afterCompletion(final int s) {
                    TransactionSynchronization.Status status;
                    if (s == 3) {
                        status = TransactionSynchronization.Status.COMMITTED;
                    }
                    else if (s == 4) {
                        status = TransactionSynchronization.Status.ROLLEDBACK;
                    }
                    else {
                        status = TransactionSynchronization.Status.UNKNOWN;
                    }
                    synchronization.afterCompletion(status);
                }
            });
        }
        else {
            this.synchronizations.add(synchronization);
        }
    }
    
    protected void fireNonTransactionalCompletion() {
        for (final TransactionSynchronization synchronization : new ArrayList<TransactionSynchronization>(this.synchronizations)) {
            try {
                synchronization.beforeCompletion();
            }
            catch (Throwable e) {
                JtaTransactionPolicy.logger.error("Exception thrown from beforeCompletion() of TransactionSynchronization " + synchronization);
            }
        }
        final TransactionSynchronization.Status status = this.isRollbackOnly() ? TransactionSynchronization.Status.ROLLEDBACK : TransactionSynchronization.Status.COMMITTED;
        for (final TransactionSynchronization synchronization2 : new ArrayList<TransactionSynchronization>(this.synchronizations)) {
            try {
                synchronization2.afterCompletion(status);
            }
            catch (Exception e2) {
                JtaTransactionPolicy.logger.error("Exception thrown from afterCompletion(" + status + ") of TransactionSynchronization " + synchronization2);
            }
        }
    }
    
    @Override
    public void enlistResource(final XAResource xaResource) throws org.apache.openejb.SystemException {
        final Transaction transaction = this.getCurrentTransaction();
        if (transaction != null) {
            try {
                if (transaction.enlistResource(xaResource)) {
                    return;
                }
            }
            catch (Exception e) {
                throw new org.apache.openejb.SystemException("Unable to enlist xa resource in the transaction", e);
            }
        }
        throw new org.apache.openejb.SystemException("Unable to enlist xa resource in the transaction");
    }
    
    @Override
    public String toString() {
        return this.transactionType.toString();
    }
    
    protected Transaction getTransaction() throws org.apache.openejb.SystemException {
        try {
            return this.transactionManager.getTransaction();
        }
        catch (SystemException e) {
            JtaTransactionPolicy.txLogger.error("The Transaction Manager has encountered an unexpected error condition while attempting to obtain current transaction: {0}", e.getMessage());
            throw new org.apache.openejb.SystemException((Throwable)e);
        }
    }
    
    protected void setRollbackOnly(final Transaction tx, final Throwable reason) {
        try {
            if (tx == null || tx.getStatus() != 0) {
                return;
            }
            if (reason == null) {
                tx.setRollbackOnly();
            }
            else {
                final Method setRollbackOnly = this.setRollbackOnlyMethod(tx);
                if (setRollbackOnly != null) {
                    setRollbackOnly.invoke(tx, reason);
                }
                else {
                    tx.setRollbackOnly();
                }
            }
            JtaTransactionPolicy.txLogger.debug("TX {0}: setRollbackOnly() on transaction {1}", this.transactionType, tx);
        }
        catch (Exception e) {
            JtaTransactionPolicy.txLogger.error("Exception during setRollbackOnly()", e);
            throw new IllegalStateException("No transaction active", e);
        }
    }
    
    private Method setRollbackOnlyMethod(final Transaction tx) {
        try {
            return tx.getClass().getMethod("setRollbackOnly", Throwable.class);
        }
        catch (Throwable e) {
            return null;
        }
    }
    
    protected Transaction beginTransaction() throws org.apache.openejb.SystemException {
        Transaction transaction;
        try {
            this.transactionManager.begin();
            transaction = this.transactionManager.getTransaction();
        }
        catch (Exception e) {
            JtaTransactionPolicy.txLogger.error("The Transaction Manager has encountered an unexpected error condition while attempting to begin a new transaction: {0}", e.getMessage());
            throw new org.apache.openejb.SystemException(e);
        }
        if (transaction == null) {
            throw new org.apache.openejb.SystemException("Failed to begin a new transaction");
        }
        JtaTransactionPolicy.txLogger.debug("TX {0}: Started transaction {1}", this.transactionType, transaction);
        return transaction;
    }
    
    protected Transaction suspendTransaction() throws org.apache.openejb.SystemException {
        try {
            final Transaction tx = this.transactionManager.suspend();
            if (tx == null) {
                JtaTransactionPolicy.txLogger.debug("TX {0}: No transaction to suspend", this.transactionType);
            }
            else {
                JtaTransactionPolicy.txLogger.debug("TX {0}: Suspended transaction {1}", this.transactionType, tx);
            }
            return tx;
        }
        catch (SystemException se) {
            JtaTransactionPolicy.txLogger.error("Exception during suspend()", (Throwable)se);
            throw new org.apache.openejb.SystemException((Throwable)se);
        }
    }
    
    protected void resumeTransaction(final Transaction tx) throws org.apache.openejb.SystemException {
        try {
            if (tx == null) {
                JtaTransactionPolicy.txLogger.debug("TX {0}: No transaction to resume", this.transactionType);
            }
            else {
                JtaTransactionPolicy.txLogger.debug("TX {0}: Resuming transaction {1}", this.transactionType, tx);
                this.transactionManager.resume(tx);
            }
        }
        catch (InvalidTransactionException ite) {
            JtaTransactionPolicy.txLogger.error("Could not resume the client's transaction, the transaction is no longer valid: {0}", ite.getMessage());
            throw new org.apache.openejb.SystemException((Throwable)ite);
        }
        catch (IllegalStateException e) {
            JtaTransactionPolicy.txLogger.error("Could not resume the client's transaction: {0}", e.getMessage());
            throw new org.apache.openejb.SystemException(e);
        }
        catch (SystemException e2) {
            JtaTransactionPolicy.txLogger.error("Could not resume the client's transaction: The transaction reported a system exception: {0}", e2.getMessage());
            throw new org.apache.openejb.SystemException((Throwable)e2);
        }
    }
    
    protected void completeTransaction(final Transaction tx) throws org.apache.openejb.SystemException, ApplicationException {
        boolean shouldRollback;
        try {
            shouldRollback = (tx.getStatus() != 0);
        }
        catch (SystemException e) {
            JtaTransactionPolicy.txLogger.error("The Transaction Manager has encountered an unexpected error condition while attempting to obtain transaction status: {0}", e.getMessage());
            throw new org.apache.openejb.SystemException((Throwable)e);
        }
        if (shouldRollback) {
            this.rollbackTransaction(tx);
            return;
        }
        try {
            JtaTransactionPolicy.txLogger.debug("TX {0}: Committing transaction {1}", this.transactionType, tx);
            if (tx.equals(this.transactionManager.getTransaction())) {
                this.transactionManager.commit();
            }
            else {
                tx.commit();
            }
        }
        catch (RollbackException e2) {
            JtaTransactionPolicy.txLogger.debug("The transaction has been rolled back rather than commited: {0}", e2.getMessage());
            final Throwable txe = (Throwable)new TransactionRolledbackException("Transaction was rolled back, presumably because setRollbackOnly was called during a synchronization").initCause((Throwable)e2);
            throw new ApplicationException(txe);
        }
        catch (HeuristicMixedException e3) {
            JtaTransactionPolicy.txLogger.debug("A heuristic decision was made, some relevant updates have been committed while others have been rolled back: {0}", e3.getMessage());
            throw new ApplicationException(new RemoteException("A heuristic decision was made, some relevant updates have been committed while others have been rolled back", (Throwable)e3));
        }
        catch (HeuristicRollbackException e4) {
            JtaTransactionPolicy.txLogger.debug("A heuristic decision was made while commiting the transaction, some relevant updates have been rolled back: {0}", e4.getMessage());
            throw new ApplicationException(new RemoteException("A heuristic decision was made while commiting the transaction, some relevant updates have been rolled back", (Throwable)e4));
        }
        catch (SecurityException e5) {
            JtaTransactionPolicy.txLogger.error("The current thread is not allowed to commit the transaction: {0}", e5.getMessage());
            throw new org.apache.openejb.SystemException(e5);
        }
        catch (IllegalStateException e6) {
            JtaTransactionPolicy.txLogger.error("The current thread is not associated with a transaction: {0}", e6.getMessage());
            throw new org.apache.openejb.SystemException(e6);
        }
        catch (SystemException e) {
            JtaTransactionPolicy.txLogger.error("The Transaction Manager has encountered an unexpected error condition while attempting to commit the transaction: {0}", e.getMessage());
            throw new org.apache.openejb.SystemException((Throwable)e);
        }
    }
    
    protected void rollbackTransaction(final Transaction tx) throws org.apache.openejb.SystemException {
        try {
            JtaTransactionPolicy.txLogger.debug("TX {0}: Rolling back transaction {1}", this.transactionType, tx);
            if (tx.equals(this.transactionManager.getTransaction())) {
                this.transactionManager.rollback();
            }
            else {
                tx.rollback();
            }
        }
        catch (IllegalStateException | SystemException ex2) {
            final Exception ex;
            final Exception e = ex;
            JtaTransactionPolicy.logger.error("The TransactionManager reported an exception while attempting to rollback the transaction: " + e.getMessage());
            throw new org.apache.openejb.SystemException(e);
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
        txLogger = Logger.getInstance(LogCategory.TRANSACTION, "org.apache.openejb.util.resources");
    }
}
