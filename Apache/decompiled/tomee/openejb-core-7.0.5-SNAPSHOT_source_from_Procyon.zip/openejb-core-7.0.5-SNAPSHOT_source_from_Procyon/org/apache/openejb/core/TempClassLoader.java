// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.io.File;
import org.apache.xbean.asm5.shade.commons.EmptyVisitor;
import org.apache.xbean.asm5.ClassVisitor;
import org.apache.xbean.asm5.ClassReader;
import java.io.InputStream;
import java.io.Closeable;
import java.io.OutputStream;
import org.apache.openejb.loader.IO;
import java.io.BufferedInputStream;
import org.apache.openejb.util.classloader.URLClassLoaderFirst;
import java.util.List;
import java.util.Enumeration;
import java.io.IOException;
import java.util.Comparator;
import java.util.Collections;
import java.util.ArrayList;
import org.apache.openejb.loader.SystemInstance;
import java.io.ByteArrayOutputStream;
import java.util.Set;
import java.net.URL;
import java.net.URLClassLoader;

public class TempClassLoader extends URLClassLoader
{
    private static final ClassLoader PARENT_LOADER;
    private static final URL[] EMPTY_URLS;
    private final Set<Skip> skip;
    private final ClassLoader system;
    private final boolean embedded;
    private final boolean parentURLClassLoader;
    private final ByteArrayOutputStream bout;
    
    public TempClassLoader(final ClassLoader parent) {
        super(TempClassLoader.EMPTY_URLS, parent);
        this.bout = new ByteArrayOutputStream(6144);
        this.skip = (Set<Skip>)SystemInstance.get().getOptions().getAll("openejb.tempclassloader.skip", (Enum[])new Skip[] { Skip.NONE });
        this.system = ClassLoader.getSystemClassLoader();
        this.embedded = (this.getClass().getClassLoader() == this.system);
        this.parentURLClassLoader = URLClassLoader.class.isInstance(parent);
    }
    
    public void skip(final Skip s) {
        this.skip.add(s);
    }
    
    @Override
    public Class loadClass(final String name) throws ClassNotFoundException {
        return this.loadClass(name, false);
    }
    
    @Override
    public URL getResource(final String name) {
        final URL url = this.parentURLClassLoader ? URLClassLoader.class.cast(this.getParent()).findResource(name) : null;
        if (url != null) {
            return url;
        }
        return super.getResource(name);
    }
    
    public URL getInternalResource(final String name) {
        if (!name.startsWith("java/") && !name.startsWith("javax/") && name.endsWith(".class")) {
            try {
                final Enumeration<URL> resources = this.getResources(name);
                if (!resources.hasMoreElements()) {
                    return null;
                }
                final URL url = resources.nextElement();
                if (resources.hasMoreElements()) {
                    final List<URL> l = new ArrayList<URL>(2);
                    l.add(url);
                    while (resources.hasMoreElements()) {
                        l.add(resources.nextElement());
                    }
                    Collections.sort(l, new ResourceComparator(this.getParent(), name));
                    return l.iterator().next();
                }
                return url;
            }
            catch (IOException e) {
                return super.getResource(name);
            }
        }
        return super.getResource(name);
    }
    
    @Override
    public Enumeration<URL> getResources(final String name) throws IOException {
        return URLClassLoaderFirst.filterResources(name, super.getResources(name));
    }
    
    @Override
    protected synchronized Class loadClass(final String name, final boolean resolve) throws ClassNotFoundException {
        if (name == null) {
            throw new NullPointerException("name cannot be null");
        }
        Class c = this.findLoadedClass(name);
        if (c != null) {
            return c;
        }
        if (this.skip(name) || (name.startsWith("javax.faces.") && URLClassLoaderFirst.shouldSkipJsf(this.getParent(), name))) {
            return Class.forName(name, resolve, TempClassLoader.PARENT_LOADER);
        }
        if (!this.embedded && URLClassLoaderFirst.canBeLoadedFromSystem(name)) {
            try {
                c = this.system.loadClass(name);
                if (c != null) {
                    return c;
                }
            }
            catch (ClassNotFoundException ex) {}
            catch (NoClassDefFoundError noClassDefFoundError) {}
        }
        final String resourceName = name.replace('.', '/') + ".class";
        this.bout.reset();
        InputStream in = null;
        byte[] bytes;
        try {
            in = this.getResourceAsStream(resourceName);
            if (in != null && !(in instanceof BufferedInputStream)) {
                in = new BufferedInputStream(in);
            }
            if (in == null) {
                throw new ClassNotFoundException(name);
            }
            IO.copy(in, (OutputStream)this.bout);
            bytes = this.bout.toByteArray();
        }
        catch (IOException e) {
            throw new ClassNotFoundException(name, e);
        }
        finally {
            IO.close((Closeable)in);
        }
        if (this.skip.contains(Skip.ANNOTATIONS) && isAnnotationClass(bytes)) {
            return Class.forName(name, resolve, TempClassLoader.PARENT_LOADER);
        }
        if (this.skip.contains(Skip.ENUMS) && isEnum(bytes)) {
            return Class.forName(name, resolve, TempClassLoader.PARENT_LOADER);
        }
        final int packageEndIndex = name.lastIndexOf(46);
        if (packageEndIndex != -1) {
            final String packageName = name.substring(0, packageEndIndex);
            if (this.getPackage(packageName) == null) {
                this.definePackage(packageName, null, null, null, null, null, null, null);
            }
        }
        try {
            return this.defineClass(name, bytes, 0, bytes.length);
        }
        catch (SecurityException e2) {
            return super.loadClass(name, resolve);
        }
        catch (LinkageError le) {
            return super.loadClass(name, resolve);
        }
    }
    
    private boolean skip(final String name) {
        return this.skip.contains(Skip.ALL) || URLClassLoaderFirst.shouldSkip(name);
    }
    
    private static boolean isEnum(final byte[] bytes) {
        final IsEnumVisitor isEnumVisitor = new IsEnumVisitor();
        final ClassReader classReader = new ClassReader(bytes);
        classReader.accept((ClassVisitor)isEnumVisitor, 2);
        return isEnumVisitor.isEnum;
    }
    
    private static boolean isAnnotationClass(final byte[] bytes) {
        final IsAnnotationVisitor isAnnotationVisitor = new IsAnnotationVisitor();
        final ClassReader classReader = new ClassReader(bytes);
        classReader.accept((ClassVisitor)isAnnotationVisitor, 2);
        return isAnnotationVisitor.isAnnotation;
    }
    
    static {
        PARENT_LOADER = ParentClassLoaderFinder.Helper.get();
        EMPTY_URLS = new URL[0];
    }
    
    public enum Skip
    {
        NONE, 
        ANNOTATIONS, 
        ENUMS, 
        ALL;
    }
    
    public static class IsAnnotationVisitor extends EmptyVisitor
    {
        public boolean isAnnotation;
        
        public void visit(final int version, final int access, final String name, final String signature, final String superName, final String[] interfaces) {
            this.isAnnotation = ((access & 0x2000) != 0x0);
        }
    }
    
    public static class IsEnumVisitor extends EmptyVisitor
    {
        public boolean isEnum;
        
        public void visit(final int version, final int access, final String name, final String signature, final String superName, final String[] interfaces) {
            this.isEnum = ((access & 0x4000) != 0x0);
        }
    }
    
    private static final class ResourceComparator implements Comparator<URL>
    {
        private static final boolean FORCE_MAVEN_FIRST;
        private static final ClassLoader STOP_LOADER;
        private final ClassLoader loader;
        private final String name;
        
        private ResourceComparator(final ClassLoader loader, final String name) {
            this.loader = loader;
            this.name = name;
        }
        
        @Override
        public int compare(final URL o1, final URL o2) {
            if (o1.equals(o2)) {
                return 0;
            }
            final int weight1 = this.weight(o1);
            final int weight2 = this.weight(o2);
            if (weight1 != weight2) {
                return weight1 - weight2;
            }
            final String s1 = o1.toExternalForm().replace(File.separatorChar, '/');
            final String s2 = o2.toExternalForm().replace(File.separatorChar, '/');
            if (ResourceComparator.FORCE_MAVEN_FIRST) {
                if (s1.contains("/target/classes/") || s1.contains("/build/classes/main/")) {
                    return -1;
                }
                if (s2.contains("/target/classes/") || s2.contains("/build/classes/main/")) {
                    return 1;
                }
                if (s1.contains("/target/test-classes/") || s1.contains("/build/classes/test/")) {
                    return -1;
                }
                if (s2.contains("/target/test-classes/") || s2.contains("/build/classes/test/")) {
                    return 1;
                }
            }
            if (s1.contains("/WEB-INF/classes/")) {
                return -1;
            }
            if (s2.contains("/WEB-INF/classes/")) {
                return 1;
            }
            return s1.compareTo(s2);
        }
        
        private int weight(final URL url) {
            int w = 0;
            ClassLoader c = this.loader;
            while (c != null) {
                try {
                    if (!Collections.list(c.getResources(this.name)).contains(url)) {
                        break;
                    }
                    ++w;
                }
                catch (IOException e) {
                    break;
                }
                c = c.getParent();
                if (c == ResourceComparator.STOP_LOADER) {
                    break;
                }
            }
            return w;
        }
        
        static {
            FORCE_MAVEN_FIRST = "true".equals(SystemInstance.get().getProperty("openejb.classloader.force-maven", "false"));
            STOP_LOADER = ClassLoader.getSystemClassLoader().getParent();
        }
    }
}
