// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.util.concurrent.TimeUnit;

public interface LockFactory
{
    StatefulLock newLock(final String p0);
    
    void setContainer(final StatefulContainer p0);
    
    public interface StatefulLock
    {
        void lock();
        
        void unlock();
        
        boolean isHeldByCurrentThread();
        
        boolean tryLock();
        
        boolean tryLock(final long p0, final TimeUnit p1) throws InterruptedException;
    }
}
