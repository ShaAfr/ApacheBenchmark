// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

public class AbstractThreadLocalProxy<T>
{
    private final ThreadLocal<T> infos;
    
    protected AbstractThreadLocalProxy() {
        this.infos = new ThreadLocal<T>();
    }
    
    public T get() {
        return this.infos.get();
    }
    
    public void remove() {
        this.infos.remove();
    }
    
    public void set(final T value) {
        this.infos.set(value);
    }
}
