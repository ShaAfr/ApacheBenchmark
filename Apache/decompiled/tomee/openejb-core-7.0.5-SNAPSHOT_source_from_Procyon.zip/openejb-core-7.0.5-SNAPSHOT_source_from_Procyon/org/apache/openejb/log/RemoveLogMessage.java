// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log;

import java.util.logging.LogRecord;
import java.util.logging.Level;
import java.util.logging.Filter;

public class RemoveLogMessage implements Filter
{
    private final Level level;
    private final String message;
    private final Filter wrapped;
    
    public RemoveLogMessage(final Filter filter, final Level lvl, final String msg) {
        this.wrapped = filter;
        this.level = lvl;
        this.message = msg;
    }
    
    @Override
    public boolean isLoggable(final LogRecord record) {
        return (this.wrapped == null || this.wrapped.isLoggable(record)) && (!this.level.equals(record.getLevel()) || !this.message.equals(record.getMessage()));
    }
}
