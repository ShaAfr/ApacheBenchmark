// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.util.Iterator;
import java.util.Map;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import java.util.Properties;

public class MailSessionFactory
{
    private final Properties properties;
    private boolean useDefault;
    
    public MailSessionFactory() {
        this.properties = new Properties();
    }
    
    public Session create() {
        final String password = this.properties.getProperty("password");
        Authenticator auth = null;
        if (password != null) {
            final String protocol = this.properties.getProperty("mail.transport.protocol", "smtp");
            String user = this.properties.getProperty("mail." + protocol + ".user");
            if (user == null) {
                user = this.properties.getProperty("mail.user");
            }
            if (user != null) {
                final PasswordAuthentication pa = new PasswordAuthentication(user, password);
                auth = new Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return pa;
                    }
                };
            }
        }
        if (this.useDefault) {
            if (auth != null) {
                return Session.getDefaultInstance(this.properties, auth);
            }
            return Session.getDefaultInstance(this.properties);
        }
        else {
            if (auth != null) {
                return Session.getInstance(this.properties, auth);
            }
            return Session.getInstance(this.properties);
        }
    }
    
    public Properties getProperties() {
        return this.properties;
    }
    
    public void setProperties(final Properties properties) {
        this.properties.clear();
        for (final Map.Entry<Object, Object> entry : properties.entrySet()) {
            if (entry.getKey() instanceof String && entry.getValue() instanceof String) {
                this.properties.put(entry.getKey(), entry.getValue());
            }
        }
    }
    
    public void setUseDefault(final boolean useDefault) {
        this.useDefault = useDefault;
    }
}
