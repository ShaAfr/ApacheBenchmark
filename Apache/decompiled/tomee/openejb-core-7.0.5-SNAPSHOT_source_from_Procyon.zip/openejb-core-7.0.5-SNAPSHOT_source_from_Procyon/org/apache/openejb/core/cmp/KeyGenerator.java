// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import javax.ejb.EntityBean;

public interface KeyGenerator
{
    Object getPrimaryKey(final EntityBean p0);
}
