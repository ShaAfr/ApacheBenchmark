// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import org.apache.openejb.RpcContainer;
import javax.ejb.EntityBean;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.core.entity.EntityEjbHomeHandler;
import org.apache.openejb.BeanContext;

public class ProxyFactory
{
    private final BeanContext beanContext;
    private final KeyGenerator keyGenerator;
    private final Class remoteInterface;
    private final EntityEjbHomeHandler remoteHandler;
    private final Class localInterface;
    private final EntityEjbHomeHandler localHandler;
    
    public ProxyFactory(final BeanContext beanContext) {
        this.beanContext = beanContext;
        this.keyGenerator = beanContext.getKeyGenerator();
        this.remoteInterface = beanContext.getRemoteInterface();
        if (this.remoteInterface != null) {
            final EJBHome homeProxy = beanContext.getEJBHome();
            this.remoteHandler = (EntityEjbHomeHandler)ProxyManager.getInvocationHandler(homeProxy);
        }
        else {
            this.remoteHandler = null;
        }
        this.localInterface = beanContext.getLocalInterface();
        if (this.localInterface != null) {
            final EJBLocalHome localHomeProxy = beanContext.getEJBLocalHome();
            this.localHandler = (EntityEjbHomeHandler)ProxyManager.getInvocationHandler(localHomeProxy);
        }
        else {
            this.localHandler = null;
        }
    }
    
    public Object createRemoteProxy(final EntityBean bean, final RpcContainer container) {
        final Object primaryKey = this.keyGenerator.getPrimaryKey(bean);
        final Object proxy = this.remoteHandler.createProxy(primaryKey, this.beanContext.getRemoteInterface());
        return proxy;
    }
    
    public Object createLocalProxy(final EntityBean bean, final RpcContainer container) {
        final Object primaryKey = this.keyGenerator.getPrimaryKey(bean);
        final Object proxy = this.localHandler.createProxy(primaryKey, this.beanContext.getLocalInterface());
        return proxy;
    }
}
