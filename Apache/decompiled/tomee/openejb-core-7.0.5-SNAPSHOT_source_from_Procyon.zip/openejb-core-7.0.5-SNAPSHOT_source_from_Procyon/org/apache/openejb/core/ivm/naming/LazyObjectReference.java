// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import java.util.concurrent.Callable;

public class LazyObjectReference<T> extends Reference
{
    private final Callable<T> creator;
    private volatile T instance;
    
    public LazyObjectReference(final Callable<T> creator) {
        this.creator = creator;
    }
    
    @Override
    public Object getObject() throws NamingException {
        if (this.instance == null) {
            synchronized (this) {
                if (this.instance == null) {
                    try {
                        this.instance = this.creator.call();
                    }
                    catch (Exception e) {
                        throw new LazyNamingException(e.getMessage());
                    }
                }
            }
        }
        return this.instance;
    }
    
    public boolean isInitialized() {
        return this.instance != null;
    }
    
    public static final class LazyNamingException extends NamingException
    {
        private LazyNamingException(final String message) {
            super(message);
        }
    }
}
