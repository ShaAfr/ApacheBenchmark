// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import javax.transaction.RollbackException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.SystemException;
import javax.transaction.NotSupportedException;
import java.io.ObjectStreamException;
import org.apache.openejb.core.ivm.IntraVmArtifact;
import javax.naming.NamingException;
import javax.naming.Context;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.EJBException;
import org.apache.openejb.core.timer.Timers;
import javax.ejb.Timer;
import java.util.Collection;
import java.lang.reflect.Method;
import org.apache.openejb.core.timer.EjbTimerService;
import org.apache.openejb.core.timer.TimerServiceImpl;
import org.apache.openejb.OpenEJBException;
import javax.ejb.TimerService;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.core.transaction.TransactionType;
import java.security.Principal;
import javax.ejb.EJBLocalHome;
import org.apache.openejb.BeanContext;
import javax.ejb.EJBHome;
import javax.interceptor.InvocationContext;
import java.util.Map;
import org.apache.openejb.threads.task.CUTask;
import org.apache.openejb.core.transaction.EjbUserTransaction;
import javax.transaction.UserTransaction;
import org.apache.openejb.spi.SecurityService;
import java.io.Serializable;
import javax.ejb.EJBContext;

public abstract class BaseContext implements EJBContext, Serializable
{
    protected final SecurityService securityService;
    protected final UserTransaction userTransaction;
    
    protected BaseContext(final SecurityService securityService) {
        this(securityService, (UserTransaction)new EjbUserTransaction());
    }
    
    protected BaseContext(final SecurityService securityService, final UserTransaction userTransaction) {
        this.securityService = securityService;
        this.userTransaction = (UserTransaction)new UserTransactionWrapper(userTransaction);
    }
    
    private boolean isAsyncOperation(final ThreadContext threadContext) {
        return threadContext.getCurrentOperation() == null && threadContext.get(CUTask.Context.class) != null;
    }
    
    protected abstract void check(final ThreadContext p0, final Call p1);
    
    protected IllegalStateException illegal(final Call call, final Operation operation) {
        return new IllegalStateException(call + " cannot be called in " + operation);
    }
    
    public Map<String, Object> getContextData() {
        this.doCheck(Call.getContextData);
        return (Map<String, Object>)ThreadContext.getThreadContext().get(InvocationContext.class).getContextData();
    }
    
    public void doCheck(final Call call) {
        final ThreadContext context = ThreadContext.getThreadContext();
        if (!this.isAsyncOperation(context)) {
            this.check(context, call);
        }
    }
    
    public EJBHome getEJBHome() {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        return di.getEJBHome();
    }
    
    public EJBLocalHome getEJBLocalHome() {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        return di.getEJBLocalHome();
    }
    
    public Principal getCallerPrincipal() {
        this.doCheck(Call.getCallerPrincipal);
        Principal callerPrincipal = this.getCallerPrincipal(this.securityService);
        if (callerPrincipal == null) {
            callerPrincipal = UnauthenticatedPrincipal.INSTANCE;
        }
        return callerPrincipal;
    }
    
    protected Principal getCallerPrincipal(final SecurityService securityService) {
        return securityService.getCallerPrincipal();
    }
    
    public boolean isCallerInRole(final String s) {
        this.doCheck(Call.isCallerInRole);
        return this.isCallerInRole(this.securityService, s);
    }
    
    protected boolean isCallerInRole(final SecurityService securityService, final String roleName) {
        this.doCheck(Call.isCallerInRole);
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        final String roleLink = di.getSecurityRoleReference(roleName);
        return securityService.isCallerInRole(roleLink);
    }
    
    public UserTransaction getUserTransaction() throws IllegalStateException {
        this.doCheck(Call.getUserTransaction);
        return this.getUserTransaction(this.userTransaction);
    }
    
    public UserTransaction getUserTransaction(final UserTransaction userTransaction) throws IllegalStateException {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        if (di.isBeanManagedTransaction()) {
            return userTransaction;
        }
        throw new IllegalStateException("container-managed transaction beans can not access the UserTransaction");
    }
    
    public void setRollbackOnly() throws IllegalStateException {
        this.doCheck(Call.setRollbackOnly);
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        if (di.isBeanManagedTransaction()) {
            throw new IllegalStateException("bean-managed transaction beans can not access the setRollbackOnly() method");
        }
        final TransactionPolicy txPolicy = threadContext.getTransactionPolicy();
        if (txPolicy == null) {
            throw new IllegalStateException("ThreadContext does not contain a TransactionEnvironment");
        }
        if (txPolicy.getTransactionType() == TransactionType.Never || txPolicy.getTransactionType() == TransactionType.NotSupported || txPolicy.getTransactionType() == TransactionType.Supports) {
            throw new IllegalStateException("setRollbackOnly accessible only from MANDATORY, REQUIRED, or REQUIRES_NEW");
        }
        txPolicy.setRollbackOnly();
    }
    
    public boolean getRollbackOnly() throws IllegalStateException {
        this.doCheck(Call.getRollbackOnly);
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        if (di.isBeanManagedTransaction()) {
            throw new IllegalStateException("bean-managed transaction beans can not access the getRollbackOnly() method: deploymentId=" + di.getDeploymentID());
        }
        final TransactionPolicy txPolicy = threadContext.getTransactionPolicy();
        if (txPolicy == null) {
            throw new IllegalStateException("ThreadContext does not contain a TransactionEnvironment");
        }
        if (txPolicy.getTransactionType() == TransactionType.Never || txPolicy.getTransactionType() == TransactionType.NotSupported || txPolicy.getTransactionType() == TransactionType.Supports) {
            throw new IllegalStateException("getRollbackOnly accessible only from MANDATORY, REQUIRED, or REQUIRES_NEW");
        }
        return txPolicy.isRollbackOnly();
    }
    
    public TimerService getTimerService() throws IllegalStateException {
        this.doCheck(Call.getTimerService);
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext beanContext = threadContext.getBeanContext();
        final EjbTimerService timerService = beanContext.getEjbTimerService();
        if (timerService == null) {
            throw new IllegalStateException("This ejb does not support timers " + beanContext.getDeploymentID());
        }
        if (!timerService.isStarted()) {
            try {
                timerService.start();
            }
            catch (OpenEJBException e) {
                throw new IllegalStateException(e);
            }
        }
        return (TimerService)new TimerServiceImpl(timerService, threadContext.getPrimaryKey(), beanContext.getEjbTimeout()) {
            @Override
            public Collection<Timer> getAllTimers() throws IllegalStateException, EJBException {
                return Timers.all();
            }
        };
    }
    
    public boolean isTimerMethodAllowed() {
        return true;
    }
    
    public boolean isUserTransactionAccessAllowed() {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        this.doCheck(Call.UserTransactionMethod);
        return di.isBeanManagedTransaction();
    }
    
    public final Properties getEnvironment() {
        throw new UnsupportedOperationException();
    }
    
    public final Identity getCallerIdentity() {
        throw new UnsupportedOperationException();
    }
    
    public final boolean isCallerInRole(final Identity identity) {
        throw new UnsupportedOperationException();
    }
    
    public Object lookup(final String name) {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext beanContext = threadContext.getBeanContext();
        Context jndiEnc = beanContext.getJndiEnc();
        try {
            jndiEnc = (Context)jndiEnc.lookup("comp/env");
            return jndiEnc.lookup(name);
        }
        catch (NamingException | RuntimeException ex2) {
            final Exception ex;
            final Exception e = ex;
            throw new IllegalArgumentException(e);
        }
    }
    
    protected Object writeReplace() throws ObjectStreamException {
        return new IntraVmArtifact(this, true);
    }
    
    public enum Call
    {
        getEJBObject, 
        getEJBLocalObject, 
        isCallerInRole, 
        setRollbackOnly, 
        getCallerPrincipal, 
        getRollbackOnly, 
        getTimerService, 
        getUserTransaction, 
        getBusinessObject, 
        timerMethod, 
        getInvokedBusinessInterface, 
        UserTransactionMethod, 
        getMessageContext, 
        getPrimaryKey, 
        getContextData;
    }
    
    public class UserTransactionWrapper implements UserTransaction
    {
        private final UserTransaction userTransaction;
        
        public UserTransactionWrapper(final UserTransaction userTransaction) {
            this.userTransaction = userTransaction;
        }
        
        public void begin() throws NotSupportedException, SystemException {
            if (!BaseContext.this.isUserTransactionAccessAllowed()) {
                throw new IllegalStateException();
            }
            this.userTransaction.begin();
        }
        
        public void commit() throws HeuristicMixedException, HeuristicRollbackException, IllegalStateException, RollbackException, SecurityException, SystemException {
            if (!BaseContext.this.isUserTransactionAccessAllowed()) {
                throw new IllegalStateException();
            }
            this.userTransaction.commit();
        }
        
        public int getStatus() throws SystemException {
            if (!BaseContext.this.isUserTransactionAccessAllowed()) {
                throw new IllegalStateException();
            }
            return this.userTransaction.getStatus();
        }
        
        public void rollback() throws IllegalStateException, SecurityException, SystemException {
            if (!BaseContext.this.isUserTransactionAccessAllowed()) {
                throw new IllegalStateException();
            }
            this.userTransaction.rollback();
        }
        
        public void setRollbackOnly() throws IllegalStateException, SystemException {
            if (!BaseContext.this.isUserTransactionAccessAllowed()) {
                throw new IllegalStateException();
            }
            this.userTransaction.setRollbackOnly();
        }
        
        public void setTransactionTimeout(final int i) throws SystemException {
            if (!BaseContext.this.isUserTransactionAccessAllowed()) {
                throw new IllegalStateException();
            }
            this.userTransaction.setTransactionTimeout(i);
        }
    }
    
    public static class State
    {
    }
}
