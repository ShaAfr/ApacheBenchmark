// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.spi;

import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.HomeHandle;
import javax.ejb.Handle;
import javax.ejb.EJBMetaData;
import org.apache.openejb.ProxyInfo;

public interface ApplicationServer
{
    EJBMetaData getEJBMetaData(final ProxyInfo p0);
    
    Handle getHandle(final ProxyInfo p0);
    
    HomeHandle getHomeHandle(final ProxyInfo p0);
    
    EJBObject getEJBObject(final ProxyInfo p0);
    
    Object getBusinessObject(final ProxyInfo p0);
    
    EJBHome getEJBHome(final ProxyInfo p0);
}
