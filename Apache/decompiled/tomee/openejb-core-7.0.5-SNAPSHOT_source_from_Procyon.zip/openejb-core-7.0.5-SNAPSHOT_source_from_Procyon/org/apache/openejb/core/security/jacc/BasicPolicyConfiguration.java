// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jacc;

import org.apache.openejb.assembler.classic.DelegatePermissionCollection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;
import java.security.Principal;
import org.apache.openejb.loader.SystemInstance;
import java.security.Permission;
import java.security.ProtectionDomain;
import javax.security.jacc.PolicyContextException;
import java.util.LinkedHashMap;
import java.security.PermissionCollection;
import java.util.Map;
import javax.security.jacc.PolicyConfiguration;

public class BasicPolicyConfiguration implements PolicyConfiguration
{
    static final int OPEN = 1;
    static final int IN_SERVICE = 2;
    static final int DELETED = 3;
    private final String contextID;
    private int state;
    protected final Map<String, PermissionCollection> rolePermissionsMap;
    protected PermissionCollection unchecked;
    protected PermissionCollection excluded;
    
    protected BasicPolicyConfiguration(final String contextID) {
        this.rolePermissionsMap = new LinkedHashMap<String, PermissionCollection>();
        this.contextID = contextID;
        this.state = 1;
    }
    
    public String getContextID() throws PolicyContextException {
        return this.contextID;
    }
    
    public boolean implies(final ProtectionDomain domain, final Permission permission) {
        if (this.excluded != null && this.excluded.implies(permission)) {
            return false;
        }
        if (this.unchecked != null && this.unchecked.implies(permission)) {
            return true;
        }
        final Principal[] principals = domain.getPrincipals();
        if (principals.length == 0) {
            return false;
        }
        final RoleResolver roleResolver = (RoleResolver)SystemInstance.get().getComponent((Class)RoleResolver.class);
        final Set<String> roles = roleResolver.getLogicalRoles(principals, this.rolePermissionsMap.keySet());
        for (final String role : roles) {
            final PermissionCollection permissions = this.rolePermissionsMap.get(role);
            if (permissions != null && permissions.implies(permission)) {
                return true;
            }
        }
        return false;
    }
    
    public void addToRole(final String roleName, final PermissionCollection permissions) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        final Enumeration e = permissions.elements();
        while (e.hasMoreElements()) {
            this.addToRole(roleName, e.nextElement());
        }
    }
    
    public void addToRole(final String roleName, final Permission permission) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        PermissionCollection permissions = this.rolePermissionsMap.get(roleName);
        if (permissions == null) {
            permissions = new DelegatePermissionCollection();
            this.rolePermissionsMap.put(roleName, permissions);
        }
        permissions.add(permission);
    }
    
    public void addToUncheckedPolicy(final PermissionCollection permissions) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        final Enumeration e = permissions.elements();
        while (e.hasMoreElements()) {
            this.addToUncheckedPolicy(e.nextElement());
        }
    }
    
    public void addToUncheckedPolicy(final Permission permission) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        if (this.unchecked == null) {
            this.unchecked = new DelegatePermissionCollection();
        }
        this.unchecked.add(permission);
    }
    
    public void addToExcludedPolicy(final PermissionCollection permissions) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        final Enumeration e = permissions.elements();
        while (e.hasMoreElements()) {
            this.addToExcludedPolicy(e.nextElement());
        }
    }
    
    public void addToExcludedPolicy(final Permission permission) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        if (this.excluded == null) {
            this.excluded = new DelegatePermissionCollection();
        }
        this.excluded.add(permission);
    }
    
    public void removeRole(final String roleName) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        this.rolePermissionsMap.remove(roleName);
    }
    
    public void removeUncheckedPolicy() throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        this.unchecked = null;
    }
    
    public void removeExcludedPolicy() throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        this.excluded = null;
    }
    
    public void linkConfiguration(final PolicyConfiguration link) throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
    }
    
    public void delete() throws PolicyContextException {
        this.state = 3;
    }
    
    public void commit() throws PolicyContextException {
        if (this.state != 1) {
            throw new UnsupportedOperationException("Not in an open state");
        }
        this.state = 2;
    }
    
    public boolean inService() throws PolicyContextException {
        return this.state == 2;
    }
    
    public void open(final boolean remove) {
        if (remove) {
            this.rolePermissionsMap.clear();
            this.unchecked = null;
            this.excluded = null;
        }
        this.state = 1;
    }
    
    int getState() {
        return this.state;
    }
    
    public interface RoleResolver
    {
        Set<String> getLogicalRoles(final Principal[] p0, final Set<String> p1);
    }
}
