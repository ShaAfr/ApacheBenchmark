// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.SystemException;
import org.apache.openejb.ApplicationException;
import javax.transaction.TransactionRequiredException;
import javax.transaction.TransactionManager;
import javax.transaction.Transaction;

public class TxMandatory extends JtaTransactionPolicy
{
    private final Transaction clientTx;
    
    public TxMandatory(final TransactionManager transactionManager) throws SystemException, ApplicationException {
        super(TransactionType.Mandatory, transactionManager);
        this.clientTx = this.getTransaction();
        if (this.clientTx == null) {
            throw new ApplicationException((Exception)new TransactionRequiredException());
        }
    }
    
    @Override
    public boolean isNewTransaction() {
        return false;
    }
    
    @Override
    public boolean isClientTransaction() {
        return true;
    }
    
    @Override
    public Transaction getCurrentTransaction() {
        return this.clientTx;
    }
    
    @Override
    public void commit() {
        this.fireNonTransactionalCompletion();
    }
}
