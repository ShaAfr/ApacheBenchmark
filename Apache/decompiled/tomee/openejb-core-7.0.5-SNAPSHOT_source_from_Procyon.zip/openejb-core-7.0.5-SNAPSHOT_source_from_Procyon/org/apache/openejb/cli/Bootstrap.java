// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cli;

import java.lang.reflect.InvocationTargetException;
import org.apache.openejb.loader.ClassPath;
import java.util.StringTokenizer;
import org.apache.openejb.util.PropertyPlaceHolderHelper;
import org.apache.openejb.loader.IO;
import org.apache.openejb.loader.SystemClassPath;
import java.net.URI;
import java.net.URL;
import org.apache.openejb.util.URLs;
import java.io.File;
import org.apache.openejb.util.JavaSecurityManagers;

public class Bootstrap
{
    private static final String OPENEJB_VERSION_PROPERTIES_FILE_NAME = "openejb-version.properties";
    private static final String OPENEJB_HOME_PROPERTY_NAME = "openejb.home";
    private static final String OPENEJB_BASE_PROPERTY_NAME = "openejb.base";
    private static final String OPENEJB_CLI_MAIN_CLASS_NAME = "org.apache.openejb.cli.MainImpl";
    
    private static void setupHome(final String[] args) {
        for (final String arg : args) {
            if (arg.startsWith("-Dopenejb.home")) {
                addProperty(arg);
            }
            else if (arg.startsWith("-Dopenejb.base")) {
                addProperty(arg);
            }
        }
        final String homeProperty = JavaSecurityManagers.getSystemProperty("openejb.home");
        if (homeProperty != null && new File(homeProperty).exists()) {
            return;
        }
        try {
            final URL classURL = Thread.currentThread().getContextClassLoader().getResource("openejb-version.properties");
            if (classURL != null) {
                String propsString = classURL.getFile();
                propsString = propsString.substring(0, propsString.indexOf("!"));
                final URI uri = URLs.uri(propsString);
                final File jarFile = new File(uri.getSchemeSpecificPart());
                if (jarFile.getName().contains("openejb-core")) {
                    final File lib = jarFile.getParentFile();
                    final File home = lib.getParentFile().getCanonicalFile();
                    JavaSecurityManagers.setSystemProperty("openejb.home", home.getAbsolutePath());
                }
            }
        }
        catch (Exception e) {
            System.err.println("Error setting openejb.home property: " + e.getClass() + ": " + e.getMessage());
        }
    }
    
    private static void addProperty(final String arg) {
        final String prop = arg.substring(arg.indexOf("-D") + 2, arg.indexOf("="));
        final String val = arg.substring(arg.indexOf("=") + 1);
        JavaSecurityManagers.setSystemProperty(prop, val);
    }
    
    private static ClassLoader setupClasspath() {
        final String base = JavaSecurityManagers.getSystemProperty("openejb.base", "");
        final String home = JavaSecurityManagers.getSystemProperty("catalina.home", JavaSecurityManagers.getSystemProperty("openejb.home", base));
        try {
            final File lib = new File(home + File.separator + "lib");
            final ClassPath systemCP = (ClassPath)new SystemClassPath();
            systemCP.getClassLoader();
            File config = new File(base, "conf/catalina.properties");
            if (!config.isFile()) {
                config = new File(home, "conf/catalina.properties");
            }
            if (config.isFile()) {
                String val = IO.readProperties(config).getProperty("common.loader", lib.getAbsolutePath());
                val = PropertyPlaceHolderHelper.simpleValue(val.replace("${catalina.", "${openejb."));
                final StringTokenizer tokenizer = new StringTokenizer(val, ",");
                while (tokenizer.hasMoreElements()) {
                    String repository = tokenizer.nextToken().trim();
                    if (repository.isEmpty()) {
                        continue;
                    }
                    if (repository.startsWith("\"") && repository.endsWith("\"")) {
                        repository = repository.substring(1, repository.length() - 1);
                    }
                    if (repository.endsWith("*.jar")) {
                        final File dir = new File(repository.substring(0, repository.length() - "*.jar".length()));
                        if (!dir.isDirectory()) {
                            continue;
                        }
                        systemCP.addJarsToPath(dir);
                    }
                    else if (repository.endsWith(".jar")) {
                        final File file = new File(repository);
                        if (!file.isFile()) {
                            continue;
                        }
                        systemCP.addJarToPath(file.toURI().toURL());
                    }
                    else {
                        final File dir = new File(repository);
                        if (!dir.isDirectory()) {
                            continue;
                        }
                        systemCP.addJarToPath(dir.toURI().toURL());
                    }
                }
            }
            else {
                systemCP.addJarsToPath(lib);
                systemCP.addJarToPath(lib.toURI().toURL());
            }
            return systemCP.getClassLoader();
        }
        catch (Exception e) {
            System.err.println("Error setting up the classpath: " + e.getClass() + ": " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public static void main(final String[] args) throws Exception {
        setupHome(args);
        final ClassLoader loader = setupClasspath();
        if (loader != null) {
            Thread.currentThread().setContextClassLoader(loader);
            if (loader != ClassLoader.getSystemClassLoader()) {
                System.setProperty("openejb.classloader.first.disallow-system-loading", "true");
            }
        }
        final Class<?> clazz = ((loader == null) ? Bootstrap.class.getClassLoader() : loader).loadClass("org.apache.openejb.cli.MainImpl");
        try {
            final Object main = clazz.getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
            main.getClass().getMethod("main", String[].class).invoke(main, args);
        }
        catch (InvocationTargetException e) {
            final Throwable cause = e.getCause();
            if ("org.apache.openejb.cli.SystemExitException".equals(cause.getClass().getName())) {
                System.exit(Number.class.cast(cause.getClass().getMethod("getExitCode", (Class<?>[])new Class[0]).invoke(cause, new Object[0])).intValue());
            }
            if (Exception.class.isInstance(cause)) {
                throw Exception.class.cast(cause);
            }
            if (Error.class.isInstance(cause)) {
                throw Error.class.cast(cause);
            }
            throw new IllegalStateException(cause);
        }
    }
}
