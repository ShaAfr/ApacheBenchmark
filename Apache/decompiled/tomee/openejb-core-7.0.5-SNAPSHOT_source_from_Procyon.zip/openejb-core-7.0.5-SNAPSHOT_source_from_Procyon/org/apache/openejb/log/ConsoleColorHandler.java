// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log;

import org.apache.openejb.loader.SystemInstance;
import org.fusesource.jansi.WindowsAnsiOutputStream;
import java.io.OutputStream;
import org.fusesource.jansi.AnsiConsole;
import java.util.logging.Formatter;
import java.util.logging.ConsoleHandler;

public class ConsoleColorHandler extends ConsoleHandler
{
    private static final boolean wrapped;
    
    public ConsoleColorHandler() {
        this.setFormatter(new ColorFormatter());
        this.setLevel(JULUtil.level());
        if (ConsoleColorHandler.wrapped) {
            this.setOutputStream(AnsiConsole.out);
        }
        else {
            this.setOutputStream(System.out);
        }
    }
    
    static {
        wrapped = (AnsiConsole.wrapOutputStream((OutputStream)System.out) instanceof WindowsAnsiOutputStream);
        if (ConsoleColorHandler.wrapped && "true".equals(SystemInstance.get().getProperty("openejb.log.color.install", "true"))) {
            AnsiConsole.systemInstall();
        }
    }
}
