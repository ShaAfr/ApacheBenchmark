// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import java.io.ObjectStreamException;
import javax.naming.Context;
import org.apache.openejb.BeanContext;
import javax.naming.NamingException;
import java.io.InvalidObjectException;
import org.apache.openejb.core.ThreadContext;
import java.io.Serializable;

public class JndiEncArtifact implements Serializable
{
    String path;
    
    public JndiEncArtifact(final IvmContext context) {
        this.path = new String();
        NameNode node = context.mynode;
        do {
            this.path = node.getAtomicName() + "/" + this.path;
            node = node.getParent();
        } while (node != null);
    }
    
    public Object readResolve() throws ObjectStreamException {
        final ThreadContext thrdCntx = ThreadContext.getThreadContext();
        final BeanContext deployment = thrdCntx.getBeanContext();
        final Context cntx = deployment.getJndiEnc();
        try {
            final Object obj = cntx.lookup(this.path);
            if (obj == null) {
                throw new InvalidObjectException("JNDI ENC context reference could not be properly resolved when bean instance was activated");
            }
            return obj;
        }
        catch (NamingException e) {
            throw (InvalidObjectException)new InvalidObjectException("JNDI ENC context reference could not be properly resolved due to a JNDI exception, when bean instance was activated").initCause(e);
        }
    }
}
