// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;

public class HandlerChainInfo extends InfoObject
{
    public QName serviceNamePattern;
    public QName portNamePattern;
    public final List<String> protocolBindings;
    public final List<HandlerInfo> handlers;
    
    public HandlerChainInfo() {
        this.protocolBindings = new ArrayList<String>();
        this.handlers = new ArrayList<HandlerInfo>();
    }
}
