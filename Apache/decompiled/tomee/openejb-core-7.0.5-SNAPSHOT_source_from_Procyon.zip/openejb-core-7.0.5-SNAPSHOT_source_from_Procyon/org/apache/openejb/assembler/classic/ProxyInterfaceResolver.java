// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Iterator;
import java.rmi.Remote;
import java.util.ArrayList;
import java.util.List;

public class ProxyInterfaceResolver
{
    public static List<Class> getInterfaces(final Class implementation, final Class mainInterface, final List<Class> interfaces) {
        final List<Class> valid = new ArrayList<Class>();
        if (mainInterface != null) {
            valid.add(mainInterface);
        }
        for (final Class interfce : interfaces) {
            if (interfce.isAssignableFrom(implementation)) {
                valid.add(interfce);
            }
        }
        final List<Class> remotes = new ArrayList<Class>();
        final List<Class> nonremotes = new ArrayList<Class>();
        for (final Class interfce2 : valid) {
            if (Remote.class.isAssignableFrom(interfce2)) {
                remotes.add(interfce2);
            }
            else {
                nonremotes.add(interfce2);
            }
        }
        if (remotes.size() == 0) {
            return valid;
        }
        valid.clear();
        remotes.remove(mainInterface);
        nonremotes.remove(mainInterface);
        valid.add(mainInterface);
        final List<Signature> proxySignatures = getSignatures(mainInterface);
        if (Remote.class.isAssignableFrom(mainInterface)) {
            for (final Class interfce3 : remotes) {
                addIfNotConflicting(interfce3, valid, proxySignatures);
            }
            for (final Class interfce3 : nonremotes) {
                addIfNotConflicting(interfce3, valid, proxySignatures);
            }
        }
        else {
            for (final Class interfce3 : nonremotes) {
                addIfNotConflicting(interfce3, valid, proxySignatures);
            }
            for (final Class interfce3 : remotes) {
                addIfNotConflicting(interfce3, valid, proxySignatures);
            }
        }
        return valid;
    }
    
    private static void addIfNotConflicting(final Class interfce, final List<Class> valid, final List<Signature> proxySignatures) {
        final List<Signature> interfaceSigs = getSignatures(interfce);
        for (final Signature sig : interfaceSigs) {
            if (proxySignatures.contains(sig)) {
                return;
            }
        }
        valid.add(interfce);
        proxySignatures.addAll(interfaceSigs);
    }
    
    private static List<Signature> getSignatures(final Class mainInterface) {
        final List<Signature> sigs = new ArrayList<Signature>();
        for (final Method method : mainInterface.getMethods()) {
            sigs.add(new Signature(mainInterface, method));
        }
        return sigs;
    }
    
    public static class Signature
    {
        private final Class clazz;
        private final Method method;
        private final String sig;
        
        public Signature(final Class clazz, final Method method) {
            this.clazz = clazz;
            this.method = method;
            final StringBuilder sb = new StringBuilder();
            sb.append(method.getName());
            sb.append('(');
            for (final Class<?> type : method.getParameterTypes()) {
                sb.append(type.getName());
                sb.append(',');
            }
            sb.append(')');
            this.sig = sb.toString();
        }
        
        public Method getMethod() {
            return this.method;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final Signature signature = (Signature)o;
            if (!this.sig.equals(signature.sig)) {
                return false;
            }
            final boolean aIsRemote = Remote.class.isAssignableFrom(this.clazz);
            final boolean bIsRemote = Remote.class.isAssignableFrom(signature.clazz);
            return aIsRemote != bIsRemote;
        }
        
        @Override
        public int hashCode() {
            return this.sig.hashCode();
        }
        
        @Override
        public String toString() {
            return this.method.toString();
        }
    }
}
