// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ThreadContext;
import javax.ejb.ScheduleExpression;
import javax.ejb.TimerConfig;
import java.util.Collection;
import javax.ejb.EJBException;
import javax.ejb.Timer;
import java.io.Serializable;
import java.util.Date;
import javax.ejb.TimerService;

public class TimerServiceWrapper implements TimerService
{
    public Timer createTimer(final Date initialExpiration, final long intervalDuration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createTimer(initialExpiration, intervalDuration, info);
    }
    
    public Timer createTimer(final Date expiration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createTimer(expiration, info);
    }
    
    public Timer createTimer(final long initialDuration, final long intervalDuration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createTimer(initialDuration, intervalDuration, info);
    }
    
    public Timer createTimer(final long duration, final Serializable info) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createTimer(duration, info);
    }
    
    public Collection<Timer> getTimers() throws IllegalStateException, EJBException {
        return (Collection<Timer>)this.getTimerService().getTimers();
    }
    
    public Collection<Timer> getAllTimers() throws IllegalStateException, EJBException {
        return Timers.all();
    }
    
    public Timer createSingleActionTimer(final long l, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createSingleActionTimer(l, timerConfig);
    }
    
    public Timer createSingleActionTimer(final Date date, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createSingleActionTimer(date, timerConfig);
    }
    
    public Timer createIntervalTimer(final long l, final long l1, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createIntervalTimer(l, l1, timerConfig);
    }
    
    public Timer createIntervalTimer(final Date date, final long l, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createIntervalTimer(date, l, timerConfig);
    }
    
    public Timer createCalendarTimer(final ScheduleExpression scheduleExpression) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createCalendarTimer(scheduleExpression);
    }
    
    public Timer createCalendarTimer(final ScheduleExpression scheduleExpression, final TimerConfig timerConfig) throws IllegalArgumentException, IllegalStateException, EJBException {
        return this.getTimerService().createCalendarTimer(scheduleExpression, timerConfig);
    }
    
    private TimerService getTimerService() throws IllegalStateException {
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext beanContext = threadContext.getBeanContext();
        return Timers.getTimerService(threadContext.getPrimaryKey(), beanContext, false);
    }
}
