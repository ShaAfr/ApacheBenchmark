// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import java.security.Principal;
import javax.servlet.http.HttpSession;
import java.util.Collection;
import javax.servlet.http.HttpUpgradeHandler;
import javax.servlet.http.Part;
import javax.servlet.http.Cookie;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import java.io.UnsupportedEncodingException;
import javax.servlet.ServletContext;
import javax.servlet.RequestDispatcher;
import java.io.BufferedReader;
import java.util.Map;
import java.util.Locale;
import java.io.IOException;
import javax.servlet.ServletInputStream;
import javax.servlet.DispatcherType;
import java.util.Enumeration;
import javax.servlet.AsyncContext;
import javax.servlet.http.HttpServletRequest;

public class ThreadLocalHttpServletRequest extends AbstractRestThreadLocalProxy<HttpServletRequest> implements HttpServletRequest
{
    protected ThreadLocalHttpServletRequest() {
        super(HttpServletRequest.class);
    }
    
    public AsyncContext getAsyncContext() {
        return this.get().getAsyncContext();
    }
    
    public Object getAttribute(final String string) {
        return this.get().getAttribute(string);
    }
    
    public Enumeration<String> getAttributeNames() {
        return (Enumeration<String>)this.get().getAttributeNames();
    }
    
    public String getCharacterEncoding() {
        return this.get().getCharacterEncoding();
    }
    
    public int getContentLength() {
        return this.get().getContentLength();
    }
    
    public long getContentLengthLong() {
        return this.get().getContentLengthLong();
    }
    
    public String getContentType() {
        return this.get().getContentType();
    }
    
    public DispatcherType getDispatcherType() {
        return this.get().getDispatcherType();
    }
    
    public ServletInputStream getInputStream() throws IOException {
        return this.get().getInputStream();
    }
    
    public String getLocalAddr() {
        return this.get().getLocalAddr();
    }
    
    public Locale getLocale() {
        return this.get().getLocale();
    }
    
    public Enumeration<Locale> getLocales() {
        return (Enumeration<Locale>)this.get().getLocales();
    }
    
    public String getLocalName() {
        return this.get().getLocalName();
    }
    
    public int getLocalPort() {
        return this.get().getLocalPort();
    }
    
    public String getParameter(final String string) {
        return this.get().getParameter(string);
    }
    
    public Map<String, String[]> getParameterMap() {
        return (Map<String, String[]>)this.get().getParameterMap();
    }
    
    public String[] getParameterValues(final String string) {
        return this.get().getParameterValues(string);
    }
    
    public Enumeration<String> getParameterNames() {
        return (Enumeration<String>)this.get().getParameterNames();
    }
    
    public String getProtocol() {
        return this.get().getProtocol();
    }
    
    public BufferedReader getReader() throws IOException {
        return this.get().getReader();
    }
    
    public String getRealPath(final String string) {
        return this.get().getRealPath(string);
    }
    
    public String getRemoteAddr() {
        return this.get().getRemoteAddr();
    }
    
    public String getRemoteHost() {
        return this.get().getRemoteHost();
    }
    
    public int getRemotePort() {
        return this.get().getRemotePort();
    }
    
    public RequestDispatcher getRequestDispatcher(final String string) {
        return this.get().getRequestDispatcher(string);
    }
    
    public String getScheme() {
        return this.get().getScheme();
    }
    
    public String getServerName() {
        return this.get().getServerName();
    }
    
    public int getServerPort() {
        return this.get().getServerPort();
    }
    
    public ServletContext getServletContext() {
        return this.get().getServletContext();
    }
    
    public boolean isAsyncStarted() {
        return this.get().isAsyncStarted();
    }
    
    public boolean isAsyncSupported() {
        return this.get().isAsyncSupported();
    }
    
    public boolean isSecure() {
        return this.get().isSecure();
    }
    
    public void removeAttribute(final String string) {
        this.get().removeAttribute(string);
    }
    
    public void setAttribute(final String string, final Object object) {
        this.get().setAttribute(string, object);
    }
    
    public void setCharacterEncoding(final String string) throws UnsupportedEncodingException {
        this.get().setCharacterEncoding(string);
    }
    
    public AsyncContext startAsync() {
        return this.get().startAsync();
    }
    
    public AsyncContext startAsync(final ServletRequest servletRequest, final ServletResponse servletResponse) {
        return this.get().startAsync(servletRequest, servletResponse);
    }
    
    public boolean authenticate(final HttpServletResponse httpServletResponse) throws IOException, ServletException {
        return this.get().authenticate(httpServletResponse);
    }
    
    public String getAuthType() {
        return this.get().getAuthType();
    }
    
    public String getContextPath() {
        return this.get().getContextPath();
    }
    
    public Cookie[] getCookies() {
        return this.get().getCookies();
    }
    
    public long getDateHeader(final String s) {
        return this.get().getDateHeader(s);
    }
    
    public String getHeader(final String s) {
        return this.get().getHeader(s);
    }
    
    public Enumeration<String> getHeaderNames() {
        return (Enumeration<String>)this.get().getHeaderNames();
    }
    
    public Enumeration<String> getHeaders(final String s) {
        return (Enumeration<String>)this.get().getHeaders(s);
    }
    
    public int getIntHeader(final String s) {
        return this.get().getIntHeader(s);
    }
    
    public String getMethod() {
        return this.get().getMethod();
    }
    
    public Part getPart(final String s) throws IOException, ServletException {
        return this.get().getPart(s);
    }
    
    public <T extends HttpUpgradeHandler> T upgrade(final Class<T> httpUpgradeHandlerClass) throws IOException, ServletException {
        return (T)this.get().upgrade((Class)httpUpgradeHandlerClass);
    }
    
    public Collection<Part> getParts() throws IOException, ServletException {
        return (Collection<Part>)this.get().getParts();
    }
    
    public String getPathInfo() {
        return this.get().getPathInfo();
    }
    
    public String getPathTranslated() {
        return this.get().getPathTranslated();
    }
    
    public String getQueryString() {
        return this.get().getQueryString();
    }
    
    public String getRemoteUser() {
        return this.get().getRemoteUser();
    }
    
    public String getRequestedSessionId() {
        return this.get().getRequestedSessionId();
    }
    
    public String getRequestURI() {
        return this.get().getRequestURI();
    }
    
    public StringBuffer getRequestURL() {
        return this.get().getRequestURL();
    }
    
    public String getServletPath() {
        return this.get().getServletPath();
    }
    
    public HttpSession getSession() {
        return this.get().getSession();
    }
    
    public String changeSessionId() {
        return this.get().changeSessionId();
    }
    
    public HttpSession getSession(final boolean b) {
        return this.get().getSession(b);
    }
    
    public Principal getUserPrincipal() {
        return this.get().getUserPrincipal();
    }
    
    public boolean isRequestedSessionIdFromCookie() {
        return this.get().isRequestedSessionIdFromCookie();
    }
    
    public boolean isRequestedSessionIdFromUrl() {
        return this.get().isRequestedSessionIdFromUrl();
    }
    
    public boolean isRequestedSessionIdFromURL() {
        return this.get().isRequestedSessionIdFromURL();
    }
    
    public boolean isRequestedSessionIdValid() {
        return this.get().isRequestedSessionIdValid();
    }
    
    public boolean isUserInRole(final String s) {
        return this.get().isUserInRole(s);
    }
    
    public void login(final String s, final String s1) throws ServletException {
        this.get().login(s, s1);
    }
    
    public void logout() throws ServletException {
        this.get().logout();
    }
}
