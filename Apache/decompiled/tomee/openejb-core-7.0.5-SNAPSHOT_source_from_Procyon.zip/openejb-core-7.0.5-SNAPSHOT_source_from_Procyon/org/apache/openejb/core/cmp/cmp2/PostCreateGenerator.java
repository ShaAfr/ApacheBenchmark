// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import org.apache.xbean.asm5.MethodVisitor;
import org.apache.xbean.asm5.Type;
import java.lang.reflect.Modifier;
import java.lang.reflect.Method;
import org.apache.xbean.asm5.ClassWriter;

public class PostCreateGenerator
{
    private final Class beanClass;
    private final ClassWriter cw;
    
    public PostCreateGenerator(final Class beanClass, final ClassWriter cw) {
        this.beanClass = beanClass;
        this.cw = cw;
    }
    
    public void generate() {
        for (final Method ejbCreate : this.beanClass.getMethods()) {
            if (ejbCreate.getName().startsWith("ejbCreate")) {
                final StringBuilder ejbPostCreateName = new StringBuilder(ejbCreate.getName());
                ejbPostCreateName.replace(0, "ejbC".length(), "ejbPostC");
                if (!this.hasMethod(this.beanClass, ejbPostCreateName.toString(), (Class[])ejbCreate.getParameterTypes())) {
                    this.createEjbPostCreate(ejbPostCreateName.toString(), ejbCreate);
                }
            }
        }
    }
    
    private boolean hasMethod(final Class beanClass, final String name, final Class... args) {
        try {
            final Method method = beanClass.getMethod(name, (Class[])args);
            return !Modifier.isAbstract(method.getModifiers());
        }
        catch (NoSuchMethodException e) {
            return false;
        }
    }
    
    public void createEjbPostCreate(final String ejbPostCreateName, final Method ejbCreate) {
        final String methodDescriptor = Type.getMethodDescriptor(Type.VOID_TYPE, Type.getArgumentTypes(ejbCreate));
        final MethodVisitor mv = this.cw.visitMethod(1, ejbPostCreateName, methodDescriptor, (String)null, (String[])null);
        mv.visitCode();
        mv.visitInsn(177);
        mv.visitMaxs(0, ejbCreate.getParameterTypes().length + 1);
        mv.visitEnd();
    }
}
