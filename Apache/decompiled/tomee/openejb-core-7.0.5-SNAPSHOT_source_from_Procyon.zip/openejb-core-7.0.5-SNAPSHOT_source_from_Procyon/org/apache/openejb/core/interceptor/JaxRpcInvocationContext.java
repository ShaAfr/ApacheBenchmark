// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.interceptor;

import javax.xml.rpc.handler.MessageContext;
import java.lang.reflect.Method;
import java.util.List;
import org.apache.openejb.core.Operation;

public class JaxRpcInvocationContext extends ReflectionInvocationContext
{
    public JaxRpcInvocationContext(final Operation operation, final List<Interceptor> interceptors, final Object target, final Method method, final MessageContext messageContext, final Object... parameters) {
        super(operation, interceptors, target, method, parameters);
        this.getContextData().put(MessageContext.class.getName(), messageContext);
    }
}
