// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class CmrFieldInfo extends InfoObject
{
    public EntityBeanInfo roleSource;
    public String roleName;
    public String fieldName;
    public String fieldType;
    public boolean cascadeDelete;
    public boolean many;
    public CmrFieldInfo mappedBy;
    public boolean synthetic;
}
