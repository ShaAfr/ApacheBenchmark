// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import org.apache.openejb.SystemException;
import javax.naming.Context;
import java.util.Map;

public interface JndiFactory
{
    Context createComponentContext(final Map<String, Object> p0) throws SystemException;
    
    Context createRootContext();
}
