// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import org.apache.openejb.core.rmi.BlacklistClassResolver;
import java.io.ObjectStreamClass;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class ObjectInputStreamFiltered extends ObjectInputStream
{
    public ObjectInputStreamFiltered(final InputStream in) throws IOException {
        super(in);
    }
    
    @Override
    protected Class resolveClass(final ObjectStreamClass classDesc) throws IOException, ClassNotFoundException {
        return super.resolveClass(BlacklistClassResolver.DEFAULT.check(classDesc));
    }
}
