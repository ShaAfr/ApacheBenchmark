// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.log.logger;

import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.AppenderSkeleton;
import java.lang.reflect.Field;
import java.util.HashMap;
import org.apache.log4j.Priority;
import java.util.logging.LogRecord;
import java.util.Enumeration;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Appender;
import java.util.logging.Handler;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import java.util.logging.Level;
import java.util.Map;

public class Log4jLogger extends AbstractDelegatingLogger
{
    private static final Map<Level, org.apache.log4j.Level> TO_LOG4J;
    private static final org.apache.log4j.Level TRACE;
    private final org.apache.log4j.Logger log;
    
    public Log4jLogger(final String name, final String resourceBundleName) {
        super(name, resourceBundleName);
        this.log = LogManager.getLogger(name);
    }
    
    @Override
    public Level getLevel() {
        final org.apache.log4j.Level l = this.log.getEffectiveLevel();
        if (l != null) {
            return this.fromL4J(l);
        }
        return null;
    }
    
    @Override
    public void setLevel(final Level newLevel) throws SecurityException {
        this.log.setLevel((org.apache.log4j.Level)Log4jLogger.TO_LOG4J.get(newLevel));
    }
    
    @Override
    public synchronized void addHandler(final Handler handler) throws SecurityException {
        this.log.addAppender((Appender)new HandlerWrapper(handler));
    }
    
    @Override
    public synchronized void removeHandler(final Handler handler) throws SecurityException {
        this.log.removeAppender("HandlerWrapper-" + handler.hashCode());
    }
    
    @Override
    public synchronized Handler[] getHandlers() {
        final List<Handler> ret = new ArrayList<Handler>();
        final Enumeration<?> en = (Enumeration<?>)this.log.getAllAppenders();
        while (en.hasMoreElements()) {
            final Appender ap = (Appender)en.nextElement();
            if (ap instanceof HandlerWrapper) {
                ret.add(((HandlerWrapper)ap).getHandler());
            }
        }
        return ret.toArray(new Handler[ret.size()]);
    }
    
    @Override
    protected void internalLogFormatted(final String msg, final LogRecord record) {
        this.log.log(AbstractDelegatingLogger.class.getName(), (Priority)Log4jLogger.TO_LOG4J.get(record.getLevel()), (Object)msg, record.getThrown());
    }
    
    private Level fromL4J(final org.apache.log4j.Level l) {
        Level l2 = null;
        switch (l.toInt()) {
            case Integer.MIN_VALUE: {
                l2 = Level.ALL;
                break;
            }
            case 50000: {
                l2 = Level.SEVERE;
                break;
            }
            case 40000: {
                l2 = Level.SEVERE;
                break;
            }
            case 30000: {
                l2 = Level.WARNING;
                break;
            }
            case 20000: {
                l2 = Level.INFO;
                break;
            }
            case 10000: {
                l2 = Level.FINE;
                break;
            }
            case Integer.MAX_VALUE: {
                l2 = Level.OFF;
                break;
            }
            default: {
                if (l.toInt() == Log4jLogger.TRACE.toInt()) {
                    l2 = Level.FINEST;
                    break;
                }
                break;
            }
        }
        return l2;
    }
    
    static {
        TO_LOG4J = new HashMap<Level, org.apache.log4j.Level>();
        org.apache.log4j.Level t = org.apache.log4j.Level.DEBUG;
        try {
            final Field f = org.apache.log4j.Level.class.getField("TRACE");
            t = (org.apache.log4j.Level)f.get(null);
        }
        catch (Throwable t2) {}
        TRACE = t;
        Log4jLogger.TO_LOG4J.put(Level.ALL, org.apache.log4j.Level.ALL);
        Log4jLogger.TO_LOG4J.put(Level.SEVERE, org.apache.log4j.Level.ERROR);
        Log4jLogger.TO_LOG4J.put(Level.WARNING, org.apache.log4j.Level.WARN);
        Log4jLogger.TO_LOG4J.put(Level.INFO, org.apache.log4j.Level.INFO);
        Log4jLogger.TO_LOG4J.put(Level.CONFIG, org.apache.log4j.Level.DEBUG);
        Log4jLogger.TO_LOG4J.put(Level.FINE, org.apache.log4j.Level.DEBUG);
        Log4jLogger.TO_LOG4J.put(Level.FINER, Log4jLogger.TRACE);
        Log4jLogger.TO_LOG4J.put(Level.FINEST, Log4jLogger.TRACE);
        Log4jLogger.TO_LOG4J.put(Level.OFF, org.apache.log4j.Level.OFF);
    }
    
    private class HandlerWrapper extends AppenderSkeleton
    {
        Handler handler;
        
        public HandlerWrapper(final Handler h) {
            this.handler = h;
            this.name = "HandlerWrapper-" + h.hashCode();
        }
        
        public Handler getHandler() {
            return this.handler;
        }
        
        protected void append(final LoggingEvent event) {
            final LogRecord lr = new LogRecord(Log4jLogger.this.fromL4J(event.getLevel()), event.getMessage().toString());
            lr.setLoggerName(event.getLoggerName());
            if (event.getThrowableInformation() != null) {
                lr.setThrown(event.getThrowableInformation().getThrowable());
            }
            final String rbname = Log4jLogger.this.getResourceBundleName();
            if (rbname != null) {
                lr.setResourceBundleName(rbname);
                lr.setResourceBundle(Log4jLogger.this.getResourceBundle());
            }
            this.handler.publish(lr);
        }
        
        public void close() {
            this.handler.close();
            this.closed = true;
        }
        
        public boolean requiresLayout() {
            return false;
        }
        
        public Priority getThreshold() {
            return Log4jLogger.TO_LOG4J.get(this.handler.getLevel());
        }
        
        public boolean isAsSevereAsThreshold(final Priority priority) {
            final Priority p = this.getThreshold();
            return p == null || priority.isGreaterOrEqual(p);
        }
    }
}
