// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.entity;

import org.apache.openejb.core.Operation;
import javax.ejb.EJBObject;
import org.apache.openejb.core.ivm.EjbObjectProxyHandler;
import org.apache.openejb.BeanContext;
import org.apache.openejb.InternalErrorException;
import java.lang.reflect.InvocationHandler;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.core.ivm.IntraVmProxy;
import java.util.List;
import java.util.ArrayList;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.core.ThreadContext;
import javax.ejb.EJBLocalObject;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.core.BaseContext;

public class EntityContext extends BaseContext implements javax.ejb.EntityContext
{
    public EntityContext(final SecurityService securityService) {
        super(securityService);
    }
    
    public EJBLocalObject getEJBLocalObject() throws IllegalStateException {
        this.doCheck(Call.getEJBLocalObject);
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        if (di.getLocalInterface() == null) {
            throw new IllegalStateException("EJB " + di.getDeploymentID() + " does not have a local interface");
        }
        final EjbObjectProxyHandler handler = new EntityEjbObjectHandler(di, threadContext.getPrimaryKey(), InterfaceType.EJB_LOCAL, new ArrayList<Class>(), di.getLocalInterface());
        try {
            final Class[] interfaces = { di.getLocalInterface(), IntraVmProxy.class };
            return (EJBLocalObject)ProxyManager.newProxyInstance(interfaces, (InvocationHandler)handler);
        }
        catch (IllegalAccessException iae) {
            throw new InternalErrorException("Could not create IVM proxy for " + di.getLocalInterface() + " interface", iae);
        }
    }
    
    public EJBObject getEJBObject() throws IllegalStateException {
        this.doCheck(Call.getEJBObject);
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        final BeanContext di = threadContext.getBeanContext();
        if (di.getRemoteInterface() == null) {
            throw new IllegalStateException("EJB " + di.getDeploymentID() + " does not have a remote interface");
        }
        final EjbObjectProxyHandler handler = new EntityEjbObjectHandler(di.getContainer().getBeanContext(di.getDeploymentID()), threadContext.getPrimaryKey(), InterfaceType.EJB_OBJECT, new ArrayList<Class>(), di.getRemoteInterface());
        try {
            final Class[] interfaces = { di.getRemoteInterface(), IntraVmProxy.class };
            return (EJBObject)ProxyManager.newProxyInstance(interfaces, (InvocationHandler)handler);
        }
        catch (IllegalAccessException iae) {
            throw new InternalErrorException("Could not create IVM proxy for " + di.getRemoteInterface() + " interface", iae);
        }
    }
    
    public Object getPrimaryKey() throws IllegalStateException {
        this.doCheck(Call.getPrimaryKey);
        final ThreadContext threadContext = ThreadContext.getThreadContext();
        return threadContext.getPrimaryKey();
    }
    
    public void check(final ThreadContext context, final Call call) {
        final Operation operation = context.getCurrentOperation();
        switch (call) {
            case getUserTransaction:
            case getContextData: {
                throw this.illegal(call, operation);
            }
            case getPrimaryKey:
            case getEJBLocalObject:
            case getEJBObject: {
                switch (operation) {
                    case SET_CONTEXT:
                    case UNSET_CONTEXT:
                    case CREATE:
                    case FIND:
                    case HOME: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            case isCallerInRole:
            case getCallerPrincipal:
            case setRollbackOnly:
            case getRollbackOnly: {
                switch (ThreadContext.getThreadContext().getCurrentOperation()) {
                    case SET_CONTEXT:
                    case UNSET_CONTEXT:
                    case ACTIVATE:
                    case PASSIVATE: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            case getTimerService: {
                switch (operation) {
                    case SET_CONTEXT:
                    case UNSET_CONTEXT:
                    case FIND: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            case timerMethod: {
                switch (operation) {
                    case SET_CONTEXT:
                    case UNSET_CONTEXT:
                    case CREATE:
                    case FIND:
                    case HOME:
                    case ACTIVATE:
                    case PASSIVATE: {
                        throw this.illegal(call, operation);
                    }
                    default: {
                        return;
                    }
                }
                break;
            }
            default: {}
        }
    }
}
