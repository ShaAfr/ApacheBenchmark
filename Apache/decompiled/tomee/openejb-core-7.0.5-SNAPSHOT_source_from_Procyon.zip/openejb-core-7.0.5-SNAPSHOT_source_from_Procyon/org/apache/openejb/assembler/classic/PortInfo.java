// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.Properties;
import java.util.List;
import javax.xml.namespace.QName;

public class PortInfo extends InfoObject
{
    public String serviceId;
    public QName wsdlService;
    public String serviceName;
    public String portId;
    public QName wsdlPort;
    public String portName;
    public String seiInterfaceName;
    public String wsdlFile;
    public String serviceLink;
    public final List<HandlerChainInfo> handlerChains;
    public boolean mtomEnabled;
    public String binding;
    public String location;
    public String authMethod;
    public String realmName;
    public String transportGuarantee;
    public String securityRealmName;
    public Properties properties;
    
    public PortInfo() {
        this.handlerChains = new ArrayList<HandlerChainInfo>();
    }
}
