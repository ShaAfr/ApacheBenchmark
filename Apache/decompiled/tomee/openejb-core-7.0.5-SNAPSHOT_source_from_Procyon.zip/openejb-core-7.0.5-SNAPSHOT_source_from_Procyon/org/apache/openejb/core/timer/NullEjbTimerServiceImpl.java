// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.OpenEJBException;
import java.util.Collection;
import java.util.Date;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.ScheduleExpression;
import java.lang.reflect.Method;
import org.apache.openejb.util.Logger;

public class NullEjbTimerServiceImpl implements EjbTimerService
{
    private static final Logger log;
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final ScheduleExpression schedule, final TimerConfig timerConfig) {
        NullEjbTimerServiceImpl.log.error("Null ! TimerService operation not supported for a bean without an ejbTimeout method or auto-started task");
        return null;
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final Date initialExpiration, final long intervalDuration, final TimerConfig timerConfig) {
        NullEjbTimerServiceImpl.log.error("Null ! TimerService operation not supported for a bean without an ejbTimeout method  or auto-started task");
        return null;
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final Date expiration, final TimerConfig timerConfig) {
        NullEjbTimerServiceImpl.log.error("Null ! TimerService operation not supported for a bean without an ejbTimeout method  or auto-started task");
        return null;
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final long initialDuration, final long intervalDuration, final TimerConfig timerConfig) {
        NullEjbTimerServiceImpl.log.error("Null ! TimerService operation not supported for a bean without an ejbTimeout method  or auto-started task");
        return null;
    }
    
    @Override
    public Timer createTimer(final Object primaryKey, final Method timeoutMethod, final long duration, final TimerConfig timerConfig) {
        NullEjbTimerServiceImpl.log.error("Null ! TimerService operation not supported for a bean without an ejbTimeout method  or auto-started task");
        return null;
    }
    
    @Override
    public Timer getTimer(final long id) {
        NullEjbTimerServiceImpl.log.error("Null ! TimerService operation not supported for a bean without an ejbTimeout method  or auto-started task");
        return null;
    }
    
    @Override
    public Collection<Timer> getTimers(final Object primaryKey) {
        NullEjbTimerServiceImpl.log.error("Null ! TimerService operation not supported for a bean without an ejbTimeout method  or auto-started task");
        return null;
    }
    
    @Override
    public void start() throws OpenEJBException {
    }
    
    @Override
    public void stop() {
    }
    
    @Override
    public TimerStore getTimerStore() {
        return null;
    }
    
    @Override
    public boolean isStarted() {
        return true;
    }
    
    static {
        log = Logger.getInstance(LogCategory.TIMER, NullEjbTimerServiceImpl.class);
    }
}
