// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import org.apache.openejb.core.ivm.naming.IvmContext;
import org.apache.openejb.core.ThreadContext;
import java.lang.reflect.UndeclaredThrowableException;
import java.lang.reflect.InvocationTargetException;
import javax.naming.NamingException;
import javax.naming.NameNotFoundException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.naming.Name;
import javax.naming.Context;
import org.apache.openejb.core.ivm.naming.ContextWrapper;

public class ContextHandler extends ContextWrapper
{
    public ContextHandler(final Context jndiContext) {
        super(jndiContext);
    }
    
    @Override
    public Object lookup(final Name name) throws NamingException {
        try {
            return this.context.lookup(name);
        }
        catch (NameNotFoundException nnfe) {
            try {
                return ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext().lookup(name);
            }
            catch (NameNotFoundException ex) {
                throw nnfe;
            }
        }
    }
    
    @Override
    public Object lookup(final String name) throws NamingException {
        try {
            if ("java:".equals(name)) {
                return this.context;
            }
            return this.context.lookup(name);
        }
        catch (UndeclaredThrowableException ute) {
            Throwable e = ute.getUndeclaredThrowable();
            while (e != null) {
                if (InvocationTargetException.class.isInstance(e)) {
                    final Throwable unwrap = InvocationTargetException.class.cast(e).getCause();
                    if (e == unwrap) {
                        throw new NameNotFoundException(name);
                    }
                    e = unwrap;
                }
                else {
                    if (!UndeclaredThrowableException.class.isInstance(e)) {
                        break;
                    }
                    final Throwable unwrap = UndeclaredThrowableException.class.cast(e).getUndeclaredThrowable();
                    if (e == unwrap) {
                        throw new NameNotFoundException(name);
                    }
                    e = unwrap;
                }
                if (NameNotFoundException.class.isInstance(e)) {
                    throw NameNotFoundException.class.cast(e);
                }
            }
            throw new NameNotFoundException(name);
        }
        catch (NameNotFoundException nnfe) {
            try {
                return ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext().lookup(name);
            }
            catch (NameNotFoundException ex) {
                try {
                    final ThreadContext threadContext = ThreadContext.getThreadContext();
                    if (threadContext != null) {
                        return threadContext.getBeanContext().getModuleContext().getModuleJndiContext().lookup(name);
                    }
                }
                catch (Exception ex2) {}
                throw nnfe;
            }
        }
    }
    
    public void setReadOnly() {
        if (IvmContext.class.isInstance(this.context)) {
            IvmContext.class.cast(this.context).setReadOnly(true);
        }
    }
}
