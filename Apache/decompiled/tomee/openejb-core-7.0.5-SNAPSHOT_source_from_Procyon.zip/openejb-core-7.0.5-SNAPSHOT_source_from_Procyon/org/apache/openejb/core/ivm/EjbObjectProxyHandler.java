// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import java.util.HashMap;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.threads.task.CUCallable;
import java.util.concurrent.Callable;
import java.io.ObjectStreamException;
import org.apache.openejb.spi.ApplicationServer;
import org.apache.openejb.core.ServerFederation;
import org.apache.openejb.ProxyInfo;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.SystemException;
import org.apache.openejb.ApplicationException;
import java.rmi.AccessException;
import javax.ejb.AccessLocalException;
import javax.ejb.EJBAccessException;
import org.apache.openejb.InvalidateReferenceException;
import java.rmi.RemoteException;
import org.apache.openejb.OpenEJBRuntimeException;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import java.lang.reflect.Method;
import java.util.List;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.BeanContext;
import java.util.Map;
import org.apache.openejb.util.Logger;

public abstract class EjbObjectProxyHandler extends BaseEjbProxyHandler
{
    private static final Logger logger;
    static final Map<String, Integer> dispatchTable;
    
    public EjbObjectProxyHandler(final BeanContext beanContext, final Object pk, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        super(beanContext, pk, interfaceType, interfaces, mainInterface);
    }
    
    public abstract Object getRegistryId();
    
    public Object _invoke(final Object p, final Class interfce, final Method m, final Object[] a) throws Throwable {
        Object retValue = null;
        Throwable exc = null;
        final String methodName = m.getName();
        try {
            if (EjbObjectProxyHandler.logger.isDebugEnabled()) {
                EjbObjectProxyHandler.logger.debug("EjbObjectProxyHandler: invoking method " + methodName + " on " + this.deploymentID + " with identity " + this.primaryKey);
            }
            Integer operation = EjbObjectProxyHandler.dispatchTable.get(methodName);
            if (operation != null) {
                if (operation == 3) {
                    if (m.getParameterTypes()[0] != EJBObject.class && m.getParameterTypes()[0] != EJBLocalObject.class) {
                        operation = null;
                    }
                }
                else {
                    operation = ((m.getParameterTypes().length == 0) ? operation : null);
                }
            }
            if (operation == null || !this.interfaceType.isComponent()) {
                retValue = this.businessMethod(interfce, m, a, p);
            }
            else {
                switch (operation) {
                    case 1: {
                        retValue = this.getHandle(m, a, p);
                        break;
                    }
                    case 2: {
                        retValue = this.getPrimaryKey(m, a, p);
                        break;
                    }
                    case 3: {
                        retValue = this.isIdentical(m, a, p);
                        break;
                    }
                    case 4: {
                        retValue = this.remove(interfce, m, a, p);
                        break;
                    }
                    case 5: {
                        retValue = this.getEJBHome(m, a, p);
                        break;
                    }
                    case 6: {
                        retValue = this.getEJBLocalHome(m, a, p);
                        break;
                    }
                    default: {
                        throw new OpenEJBRuntimeException("Inconsistent internal state");
                    }
                }
            }
            return retValue;
        }
        catch (InvalidateReferenceException ire) {
            this.invalidateAllHandlers(this.getRegistryId());
            Throwable rootCause;
            if (ire.getRootCause() != null) {
                rootCause = ire.getRootCause();
            }
            else {
                final StringBuilder sb;
                rootCause = new RemoteException(sb.append("InvalidateReferenceException: ").append(ire).toString());
                sb = new StringBuilder();
            }
            exc = rootCause;
            throw exc;
        }
        catch (ApplicationException ae) {
            exc = ((ae.getRootCause() != null) ? ae.getRootCause() : ae);
            if (!(exc instanceof EJBAccessException)) {
                throw exc;
            }
            if (this.interfaceType.isBusiness()) {
                throw exc;
            }
            if (this.interfaceType.isLocal()) {
                throw new AccessLocalException(exc.getMessage()).initCause(exc.getCause());
            }
            throw new AccessException(exc.getMessage());
        }
        catch (SystemException se) {
            this.invalidateReference();
            exc = ((se.getRootCause() != null) ? se.getRootCause() : se);
            EjbObjectProxyHandler.logger.debug("The container received an unexpected exception: ", exc);
            throw new RemoteException("Container has suffered a SystemException", exc);
        }
        catch (OpenEJBException oe) {
            exc = ((oe.getRootCause() != null) ? oe.getRootCause() : oe);
            EjbObjectProxyHandler.logger.debug("The container received an unexpected exception: ", exc);
            throw new RemoteException("Unknown Container Exception", oe.getRootCause());
        }
        finally {
            if (EjbObjectProxyHandler.logger.isDebugEnabled()) {
                if (exc == null) {
                    String ret = "void";
                    if (null != retValue) {
                        try {
                            ret = retValue.toString();
                        }
                        catch (Exception e) {
                            ret = "toString() failed on (" + e.getMessage() + ")";
                        }
                    }
                    EjbObjectProxyHandler.logger.debug("EjbObjectProxyHandler: finished invoking method " + methodName + ". Return value:" + ret);
                }
                else {
                    EjbObjectProxyHandler.logger.debug("EjbObjectProxyHandler: finished invoking method " + methodName + " with exception " + exc);
                }
            }
        }
    }
    
    protected Object getEJBHome(final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        return this.getBeanContext().getEJBHome();
    }
    
    protected Object getEJBLocalHome(final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        return this.getBeanContext().getEJBLocalHome();
    }
    
    protected Object getHandle(final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        return new IntraVmHandle(proxy);
    }
    
    @Override
    public ProxyInfo getProxyInfo() {
        return new ProxyInfo(this.getBeanContext(), this.primaryKey, this.getInterfaces(), this.interfaceType, this.getMainInterface());
    }
    
    @Override
    protected Object _writeReplace(final Object proxy) throws ObjectStreamException {
        if (IntraVmCopyMonitor.isIntraVmCopyOperation()) {
            return new IntraVmArtifact(proxy);
        }
        if (IntraVmCopyMonitor.isStatefulPassivationOperation()) {
            return proxy;
        }
        if (IntraVmCopyMonitor.isCrossClassLoaderOperation()) {
            return proxy;
        }
        if (!this.interfaceType.isRemote()) {
            return proxy;
        }
        final ApplicationServer applicationServer = ServerFederation.getApplicationServer();
        if (this.interfaceType.isBusiness()) {
            return applicationServer.getBusinessObject(this.getProxyInfo());
        }
        return applicationServer.getEJBObject(this.getProxyInfo());
    }
    
    protected abstract Object getPrimaryKey(final Method p0, final Object[] p1, final Object p2) throws Throwable;
    
    protected abstract Object isIdentical(final Method p0, final Object[] p1, final Object p2) throws Throwable;
    
    protected abstract Object remove(final Class p0, final Method p1, final Object[] p2, final Object p3) throws Throwable;
    
    protected Object businessMethod(final Class<?> interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        final BeanContext beanContext = this.getBeanContext();
        if (beanContext.isAsynchronous(method)) {
            return beanContext.getModuleContext().getAppContext().getAsynchronousPool().invoke(new CUCallable<Object>(new Callable<Object>() {
                @Override
                public Object call() throws Exception {
                    try {
                        return EjbObjectProxyHandler.this.synchronizedBusinessMethod(interfce, method, args);
                    }
                    catch (ApplicationException ae) {
                        EjbObjectProxyHandler.logger.error("EjbObjectProxyHandler: Asynchronous call to '" + interfce.getSimpleName() + "' on '" + method.getName() + "' failed", ae);
                        throw ae;
                    }
                }
            }), method.getReturnType() == Void.TYPE);
        }
        return this.synchronizedBusinessMethod(interfce, method, args);
    }
    
    protected Object synchronizedBusinessMethod(final Class<?> interfce, final Method method, final Object[] args) throws OpenEJBException {
        return this.container.invoke(this.deploymentID, this.interfaceType, interfce, method, args, this.primaryKey);
    }
    
    public static Object createProxy(final BeanContext beanContext, final Object primaryKey, final InterfaceType interfaceType, final Class mainInterface) {
        return createProxy(beanContext, primaryKey, interfaceType, null, mainInterface);
    }
    
    public static Object createProxy(final BeanContext beanContext, final Object primaryKey, InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        if (!interfaceType.isHome()) {
            interfaceType = interfaceType.getCounterpart();
        }
        final EjbHomeProxyHandler homeHandler = EjbHomeProxyHandler.createHomeHandler(beanContext, interfaceType, interfaces, mainInterface);
        return homeHandler.createProxy(primaryKey, mainInterface);
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
        (dispatchTable = new HashMap<String, Integer>()).put("getHandle", 1);
        EjbObjectProxyHandler.dispatchTable.put("getPrimaryKey", 2);
        EjbObjectProxyHandler.dispatchTable.put("isIdentical", 3);
        EjbObjectProxyHandler.dispatchTable.put("remove", 4);
        EjbObjectProxyHandler.dispatchTable.put("getEJBHome", 5);
        EjbObjectProxyHandler.dispatchTable.put("getEJBLocalHome", 6);
    }
}
