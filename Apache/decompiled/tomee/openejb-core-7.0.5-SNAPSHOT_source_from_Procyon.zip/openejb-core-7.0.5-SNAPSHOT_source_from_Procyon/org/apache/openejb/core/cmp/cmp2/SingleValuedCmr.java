// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import javax.ejb.EJBException;
import org.apache.openejb.BeanContext;
import javax.ejb.EJBLocalObject;
import javax.ejb.EntityBean;

public class SingleValuedCmr<Bean extends EntityBean, Proxy extends EJBLocalObject>
{
    private final EntityBean source;
    private final String sourceProperty;
    private final String relatedProperty;
    private final BeanContext relatedInfo;
    
    public SingleValuedCmr(final EntityBean source, final String sourceProperty, final Class<Bean> relatedType, final String relatedProperty) {
        if (source == null) {
            throw new NullPointerException("source is null");
        }
        if (relatedType == null) {
            throw new NullPointerException("relatedType is null");
        }
        this.source = source;
        this.sourceProperty = sourceProperty;
        this.relatedProperty = relatedProperty;
        this.relatedInfo = Cmp2Util.getBeanContext(relatedType);
    }
    
    public Proxy get(final Bean entity) throws EJBException {
        if (this.sourceProperty == null) {
            throw new EJBException("Internal error: this container managed relationship is unidirectional and, this entity does not have a cmr field for the relationship");
        }
        if (entity == null) {
            return null;
        }
        final Proxy ejbProxy = Cmp2Util.getEjbProxy(this.relatedInfo, entity);
        return ejbProxy;
    }
    
    public Bean set(final Bean oldBean, final Proxy newValue) throws EJBException {
        final Bean newBean = Cmp2Util.getEntityBean(newValue);
        if (newValue != null && newBean == null) {
            throw new IllegalArgumentException("A deleted bean can not be assigned to a relationship");
        }
        if (this.relatedProperty != null) {
            if (oldBean != null) {
                this.toCmp2Entity(oldBean).OpenEJB_removeCmr(this.relatedProperty, this.source);
            }
            if (newValue != null) {
                final Object oldBackRef = this.toCmp2Entity(newBean).OpenEJB_addCmr(this.relatedProperty, this.source);
                if (oldBackRef != null) {
                    this.toCmp2Entity(oldBackRef).OpenEJB_removeCmr(this.sourceProperty, newBean);
                }
            }
        }
        return newBean;
    }
    
    public void deleted(final Bean oldBean) throws EJBException {
        this.set(oldBean, null);
    }
    
    private Cmp2Entity toCmp2Entity(final Object object) {
        return (Cmp2Entity)object;
    }
}
