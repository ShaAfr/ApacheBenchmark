// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic.event;

import javax.naming.NamingException;
import org.apache.openejb.assembler.classic.Assembler;

public abstract class ResourceEvent
{
    protected final String name;
    protected final Object resource;
    protected Object replacement;
    
    protected ResourceEvent(final String name, final Object resource) {
        this.name = name;
        this.resource = resource;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Object getRawResource() {
        return this.resource;
    }
    
    public Object getResource() {
        try {
            return Assembler.ResourceInstance.class.isInstance(this.resource) ? Assembler.ResourceInstance.class.cast(this.resource).getObject() : this.resource;
        }
        catch (NamingException e) {
            throw new IllegalStateException(e);
        }
    }
    
    public boolean is(final Class<?> type) {
        try {
            return type.isInstance(this.resource) || (Assembler.ResourceInstance.class.isInstance(this.resource) && type.isInstance(Assembler.ResourceInstance.class.cast(this.resource).getObject()));
        }
        catch (NamingException e) {
            return false;
        }
    }
    
    public void replaceBy(final Object newResource) {
        this.replacement = newResource;
    }
    
    public Object getReplacement() {
        return this.replacement;
    }
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "{" + this.name + "}";
    }
}
