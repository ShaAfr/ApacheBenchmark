// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.math.stat.descriptive;

import org.apache.openejb.math.util.MathUtils;
import org.apache.openejb.math.MathRuntimeException;

public abstract class AbstractStorelessUnivariateStatistic extends AbstractUnivariateStatistic implements StorelessUnivariateStatistic
{
    @Override
    public double evaluate(final double[] values) {
        if (values == null) {
            throw MathRuntimeException.createIllegalArgumentException("input values array is null", new Object[0]);
        }
        return this.evaluate(values, 0, values.length);
    }
    
    @Override
    public double evaluate(final double[] values, final int begin, final int length) {
        if (this.test(values, begin, length)) {
            this.clear();
            this.incrementAll(values, begin, length);
        }
        return this.getResult();
    }
    
    @Override
    public abstract StorelessUnivariateStatistic copy();
    
    @Override
    public abstract void clear();
    
    @Override
    public abstract double getResult();
    
    @Override
    public abstract void increment(final double p0);
    
    @Override
    public void incrementAll(final double[] values) {
        if (values == null) {
            throw MathRuntimeException.createIllegalArgumentException("input values array is null", new Object[0]);
        }
        this.incrementAll(values, 0, values.length);
    }
    
    @Override
    public void incrementAll(final double[] values, final int begin, final int length) {
        if (this.test(values, begin, length)) {
            for (int k = begin + length, i = begin; i < k; ++i) {
                this.increment(values[i]);
            }
        }
    }
    
    @Override
    public boolean equals(final Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof AbstractStorelessUnivariateStatistic)) {
            return false;
        }
        final AbstractStorelessUnivariateStatistic stat = (AbstractStorelessUnivariateStatistic)object;
        return MathUtils.equals(stat.getResult(), this.getResult()) && MathUtils.equals((double)stat.getN(), (double)this.getN());
    }
    
    @Override
    public int hashCode() {
        return 31 * (31 + MathUtils.hash(this.getResult())) + MathUtils.hash((double)this.getN());
    }
}
