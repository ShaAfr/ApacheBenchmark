// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.dyni;

import org.apache.xbean.asm5.AnnotationVisitor;
import org.apache.xbean.asm5.ClassReader;
import java.io.InputStream;
import java.net.URL;
import java.io.Closeable;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.openejb.loader.IO;
import java.io.IOException;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import org.apache.openejb.util.proxy.ProxyGenerationException;
import java.util.Iterator;
import org.apache.xbean.asm5.ClassVisitor;
import java.util.Map;
import java.lang.reflect.Method;
import java.util.List;
import java.lang.reflect.Constructor;
import org.apache.xbean.asm5.Type;
import org.apache.xbean.asm5.ClassWriter;
import org.apache.xbean.asm5.MethodVisitor;
import java.util.HashMap;
import java.lang.reflect.Field;
import org.apache.openejb.util.Debug;
import org.apache.openejb.util.proxy.LocalBeanProxyFactory;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Modifier;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.xbean.asm5.Opcodes;

public class DynamicSubclass implements Opcodes
{
    private static final ReentrantLock LOCK;
    public static final String IMPL_SUFFIX = "$$Impl";
    
    public static boolean isDynamic(final Class beanClass) {
        return Modifier.isAbstract(beanClass.getModifiers()) && InvocationHandler.class.isAssignableFrom(beanClass);
    }
    
    public static Class createSubclass(final Class<?> abstractClass, final ClassLoader cl) {
        return createSubclass(abstractClass, cl, false);
    }
    
    public static Class createSubclass(final Class<?> abstractClass, final ClassLoader cl, final boolean proxyNonAbstractMethods) {
        final String proxyName = getSubclassName(abstractClass);
        try {
            return cl.loadClass(proxyName);
        }
        catch (Exception ex) {
            final ReentrantLock lock = DynamicSubclass.LOCK;
            lock.lock();
            try {
                try {
                    return cl.loadClass(proxyName);
                }
                catch (Exception ex2) {
                    return LocalBeanProxyFactory.Unsafe.defineClass(cl, abstractClass, proxyName, generateBytes(abstractClass, proxyNonAbstractMethods));
                }
            }
            catch (Exception e) {
                throw new InternalError(DynamicSubclass.class.getSimpleName() + ".createSubclass: " + Debug.printStackTrace(e));
            }
            finally {
                lock.unlock();
            }
        }
    }
    
    public static void setHandler(final Object instance, final InvocationHandler handler) {
        try {
            final Field thisHandler = instance.getClass().getDeclaredField("this$handler");
            if (!thisHandler.isAccessible()) {
                thisHandler.setAccessible(true);
            }
            thisHandler.set(instance, handler);
        }
        catch (NoSuchFieldException e) {
            throw new IllegalArgumentException(e);
        }
        catch (IllegalAccessException e2) {
            throw new IllegalArgumentException(e2);
        }
    }
    
    private static byte[] generateBytes(final Class<?> classToProxy, final boolean proxyNonAbstractMethods) throws ProxyGenerationException {
        final Map<String, MethodVisitor> visitors = new HashMap<String, MethodVisitor>();
        final ClassWriter cw = new ClassWriter(2);
        final String proxyClassFileName = getSubclassName(classToProxy).replace('.', '/');
        final String classFileName = classToProxy.getName().replace('.', '/');
        cw.visit(49, 33, proxyClassFileName, (String)null, classFileName, (String[])null);
        cw.visitSource(classFileName + ".java", (String)null);
        cw.visitField(18, "this$handler", "Ljava/lang/reflect/InvocationHandler;", (String)null, (Object)null).visitEnd();
        for (final Constructor<?> constructor : classToProxy.getConstructors()) {
            if (Modifier.isPublic(constructor.getModifiers())) {
                final MethodVisitor mv = visitConstructor(cw, proxyClassFileName, classFileName, constructor);
                visitors.put("<init>" + Type.getConstructorDescriptor((Constructor)constructor), mv);
            }
        }
        final Map<String, List<Method>> methodMap = new HashMap<String, List<Method>>();
        getNonPrivateMethods(classToProxy, methodMap);
        for (final Map.Entry<String, List<Method>> entry : methodMap.entrySet()) {
            for (final Method method : entry.getValue()) {
                if (Modifier.isAbstract(method.getModifiers()) || (proxyNonAbstractMethods && Modifier.isPublic(method.getModifiers()))) {
                    final MethodVisitor visitor = LocalBeanProxyFactory.visit(cw, method, proxyClassFileName, "this$handler");
                    visitors.put(method.getName() + Type.getMethodDescriptor(method), visitor);
                }
            }
        }
        copyClassAnnotations(classToProxy, (ClassVisitor)cw);
        copyMethodAnnotations(classToProxy, visitors);
        for (final MethodVisitor visitor2 : visitors.values()) {
            visitor2.visitEnd();
        }
        return cw.toByteArray();
    }
    
    private static MethodVisitor visitConstructor(final ClassWriter cw, final String proxyClassFileName, final String classFileName, final Constructor<?> constructor) {
        final String descriptor = Type.getConstructorDescriptor((Constructor)constructor);
        final String[] exceptions = new String[constructor.getExceptionTypes().length];
        for (int i = 0; i < exceptions.length; ++i) {
            exceptions[i] = Type.getInternalName((Class)constructor.getExceptionTypes()[i]);
        }
        final MethodVisitor mv = cw.visitMethod(1, "<init>", descriptor, (String)null, exceptions);
        mv.visitCode();
        mv.visitVarInsn(25, 0);
        int index = 1;
        for (final Type type : Type.getArgumentTypes(descriptor)) {
            mv.visitVarInsn(type.getOpcode(21), index);
            index += size(type);
        }
        mv.visitMethodInsn(183, classFileName, "<init>", descriptor, false);
        mv.visitVarInsn(25, 0);
        mv.visitVarInsn(25, 0);
        mv.visitFieldInsn(181, proxyClassFileName, "this$handler", "Ljava/lang/reflect/InvocationHandler;");
        mv.visitInsn(177);
        mv.visitMaxs(2, 1);
        return mv;
    }
    
    private static String getSubclassName(final Class<?> classToProxy) {
        return classToProxy.getName() + "$$Impl";
    }
    
    private static void getNonPrivateMethods(final Class<?> impl, final Map<String, List<Method>> methodMap) {
        final Class<?>[] interfaces = impl.getInterfaces();
        final Collection<Class<?>> api = new ArrayList<Class<?>>(interfaces.length + 1);
        api.add(impl);
        api.addAll(Arrays.asList(interfaces));
        for (Class<?> clazz : api) {
            while (clazz != null && clazz != Object.class) {
                for (final Method method : clazz.getDeclaredMethods()) {
                    final int modifiers = method.getModifiers();
                    if (!Modifier.isFinal(modifiers) && !Modifier.isPrivate(modifiers)) {
                        if (!Modifier.isStatic(modifiers)) {
                            List<Method> methods = methodMap.get(method.getName());
                            if (methods == null) {
                                methods = new ArrayList<Method>();
                                methods.add(method);
                                methodMap.put(method.getName(), methods);
                            }
                            else if (!isOverridden(methods, method)) {
                                methods.add(method);
                            }
                        }
                    }
                }
                clazz = clazz.getSuperclass();
            }
        }
    }
    
    private static boolean isOverridden(final List<Method> methods, final Method method) {
        for (final Method m : methods) {
            if (Arrays.equals(m.getParameterTypes(), method.getParameterTypes())) {
                return true;
            }
        }
        return false;
    }
    
    public static int size(final Type type) {
        if (Type.VOID_TYPE.equals((Object)type)) {
            return 0;
        }
        if (Type.LONG_TYPE.equals((Object)type) || Type.DOUBLE_TYPE.equals((Object)type)) {
            return 2;
        }
        return 1;
    }
    
    public static byte[] readClassFile(final Class clazz) throws IOException {
        return readClassFile(clazz.getClassLoader(), clazz);
    }
    
    public static byte[] readClassFile(final ClassLoader classLoader, final Class clazz) throws IOException {
        final String internalName = clazz.getName().replace('.', '/') + ".class";
        final URL resource = classLoader.getResource(internalName);
        final InputStream in = IO.read(resource);
        ByteArrayOutputStream out;
        try {
            out = new ByteArrayOutputStream();
            IO.copy(in, (OutputStream)out);
        }
        finally {
            IO.close((Closeable)in);
        }
        return out.toByteArray();
    }
    
    private static void copyMethodAnnotations(final Class<?> classToProxy, final Map<String, MethodVisitor> visitors) throws ProxyGenerationException {
        for (Class clazz = classToProxy; clazz != null && !clazz.equals(Object.class); clazz = clazz.getSuperclass()) {
            try {
                final ClassReader classReader = new ClassReader(readClassFile(clazz));
                final ClassVisitor copyMethodAnnotations = new CopyMethodAnnotations(visitors);
                classReader.accept(copyMethodAnnotations, 1);
            }
            catch (IOException e) {
                throw new ProxyGenerationException(e);
            }
        }
    }
    
    private static void copyClassAnnotations(final Class<?> clazz, final ClassVisitor newClass) throws ProxyGenerationException {
        try {
            final ClassReader classReader = new ClassReader(readClassFile(clazz));
            final ClassVisitor visitor = new CopyClassAnnotations(newClass);
            classReader.accept(visitor, 1);
        }
        catch (IOException e) {
            throw new ProxyGenerationException(e);
        }
    }
    
    static {
        LOCK = new ReentrantLock();
    }
    
    public static class MoveAnnotationsVisitor extends MethodVisitor
    {
        private final MethodVisitor newMethod;
        
        public MoveAnnotationsVisitor(final MethodVisitor movedMethod, final MethodVisitor newMethod) {
            super(327680, movedMethod);
            this.newMethod = newMethod;
        }
        
        public AnnotationVisitor visitAnnotation(final String desc, final boolean visible) {
            return this.newMethod.visitAnnotation(desc, visible);
        }
        
        public AnnotationVisitor visitParameterAnnotation(final int parameter, final String desc, final boolean visible) {
            return this.newMethod.visitParameterAnnotation(parameter, desc, visible);
        }
        
        public void visitEnd() {
            this.newMethod.visitEnd();
            super.visitEnd();
        }
    }
    
    private static class CopyClassAnnotations extends ClassVisitor
    {
        private final ClassVisitor newClass;
        
        public CopyClassAnnotations(final ClassVisitor newClass) {
            super(327680);
            this.newClass = newClass;
        }
        
        public AnnotationVisitor visitAnnotation(final String desc, final boolean visible) {
            return this.newClass.visitAnnotation(desc, visible);
        }
    }
    
    private static class CopyMethodAnnotations extends ClassVisitor
    {
        private final Map<String, MethodVisitor> visitors;
        
        public CopyMethodAnnotations(final Map<String, MethodVisitor> visitors) {
            super(327680);
            this.visitors = visitors;
        }
        
        public MethodVisitor visitMethod(final int access, final String name, final String desc, final String signature, final String[] exceptions) {
            final MethodVisitor newMethod = this.visitors.remove(name + desc);
            if (newMethod == null) {
                return null;
            }
            final MethodVisitor oldMethod = super.visitMethod(access, name, desc, signature, exceptions);
            return new MoveAnnotationsVisitor(oldMethod, newMethod);
        }
    }
}
