// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.HomeHandle;
import javax.ejb.Handle;
import org.apache.openejb.BeanContext;
import javax.ejb.EJBMetaData;
import org.apache.openejb.ProxyInfo;
import org.apache.openejb.spi.ApplicationServer;

public class IntraVmServer implements ApplicationServer
{
    @Override
    public EJBMetaData getEJBMetaData(final ProxyInfo pi) {
        final BeanContext beanContext = pi.getBeanContext();
        final IntraVmMetaData metaData = new IntraVmMetaData(beanContext.getHomeInterface(), beanContext.getRemoteInterface(), beanContext.getComponentType());
        metaData.setEJBHome(this.getEJBHome(pi));
        return (EJBMetaData)metaData;
    }
    
    @Override
    public Handle getHandle(final ProxyInfo pi) {
        return (Handle)new IntraVmHandle(this.getEJBObject(pi));
    }
    
    @Override
    public HomeHandle getHomeHandle(final ProxyInfo pi) {
        return (HomeHandle)new IntraVmHandle(this.getEJBHome(pi));
    }
    
    @Override
    public EJBObject getEJBObject(final ProxyInfo pi) {
        return (EJBObject)EjbObjectProxyHandler.createProxy(pi.getBeanContext(), pi.getPrimaryKey(), pi.getInterfaceType(), pi.getInterfaces(), pi.getInterface());
    }
    
    @Override
    public Object getBusinessObject(final ProxyInfo pi) {
        return EjbObjectProxyHandler.createProxy(pi.getBeanContext(), pi.getPrimaryKey(), pi.getInterfaceType(), pi.getInterfaces(), pi.getInterface());
    }
    
    @Override
    public EJBHome getEJBHome(final ProxyInfo pi) {
        return (EJBHome)EjbHomeProxyHandler.createHomeProxy(pi.getBeanContext(), pi.getInterfaceType());
    }
}
