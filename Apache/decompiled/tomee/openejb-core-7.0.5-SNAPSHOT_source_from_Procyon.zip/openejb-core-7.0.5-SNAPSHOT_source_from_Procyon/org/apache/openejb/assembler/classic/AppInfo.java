// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Properties;

public class AppInfo extends InfoObject
{
    public final Properties properties;
    public String appId;
    public String path;
    public Set<String> paths;
    public boolean autoDeploy;
    public boolean delegateFirst;
    public boolean standaloneModule;
    public final List<ClientInfo> clients;
    public final List<EjbJarInfo> ejbJars;
    public final List<IdPropertiesInfo> pojoConfigurations;
    public final List<ConnectorInfo> connectors;
    public final List<WebAppInfo> webApps;
    public final List<PersistenceUnitInfo> persistenceUnits;
    public List<ServiceInfo> services;
    public final List<String> libs;
    public final Set<String> watchedResources;
    public final Set<String> containerIds;
    public final Set<String> resourceIds;
    public final Set<String> resourceAliases;
    public final JndiEncInfo globalJndiEnc;
    public final JndiEncInfo appJndiEnc;
    public String cmpMappingsXml;
    public final Properties jmx;
    public final Set<String> mbeans;
    public final Set<String> jaxRsProviders;
    public final Set<String> jsfClasses;
    public final Set<String> eventClassesNeedingAppClassloader;
    public boolean webAppAlone;
    
    public AppInfo() {
        this.properties = new Properties();
        this.paths = new LinkedHashSet<String>();
        this.autoDeploy = true;
        this.delegateFirst = true;
        this.clients = new ArrayList<ClientInfo>();
        this.ejbJars = new ArrayList<EjbJarInfo>();
        this.pojoConfigurations = new ArrayList<IdPropertiesInfo>();
        this.connectors = new ArrayList<ConnectorInfo>();
        this.webApps = new ArrayList<WebAppInfo>();
        this.persistenceUnits = new ArrayList<PersistenceUnitInfo>();
        this.services = new ArrayList<ServiceInfo>();
        this.libs = new ArrayList<String>();
        this.watchedResources = new TreeSet<String>();
        this.containerIds = new TreeSet<String>();
        this.resourceIds = new TreeSet<String>();
        this.resourceAliases = new TreeSet<String>();
        this.globalJndiEnc = new JndiEncInfo();
        this.appJndiEnc = new JndiEncInfo();
        this.jmx = new Properties();
        this.mbeans = new TreeSet<String>();
        this.jaxRsProviders = new TreeSet<String>();
        this.jsfClasses = new TreeSet<String>();
        this.eventClassesNeedingAppClassloader = new TreeSet<String>();
    }
}
