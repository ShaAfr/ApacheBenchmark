// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

import org.apache.webbeans.container.BeanManagerImpl;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.context.spi.Contextual;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import org.apache.webbeans.config.WebBeansContext;

public final class CdiPasswordCipher implements PasswordCipher
{
    @Override
    public char[] encrypt(final String plainPassword) {
        throw new UnsupportedOperationException("cdi password cipher only supports decryption");
    }
    
    @Override
    public String decrypt(final char[] encryptedPassword) {
        final String string = new String(encryptedPassword);
        BeanManagerImpl mgr;
        try {
            final WebBeansContext wbc = WebBeansContext.currentInstance();
            mgr = wbc.getBeanManagerImpl();
            if (!mgr.isInUse()) {
                return "cipher:cdi:" + string;
            }
        }
        catch (IllegalStateException ise) {
            return "cipher:cdi:" + string;
        }
        final int split = string.indexOf(58);
        final String delegate = string.substring(0, split);
        final String pwdStr = string.substring(split + 1, string.length());
        final char[] pwd = pwdStr.toCharArray();
        try {
            final Class<?> beanType = Thread.currentThread().getContextClassLoader().loadClass(delegate);
            final Bean<?> bean = (Bean<?>)mgr.resolve(mgr.getBeans((Type)beanType, new Annotation[0]));
            if (bean == null) {
                throw new IllegalArgumentException("No bean for " + delegate);
            }
            final CreationalContext<?> cc = (CreationalContext<?>)mgr.createCreationalContext((Contextual)null);
            try {
                return PasswordCipher.class.cast(mgr.getReference((Bean)bean, (Type)PasswordCipher.class, (CreationalContext)cc)).decrypt(pwd);
            }
            finally {
                if (!mgr.isNormalScope(bean.getScope())) {
                    cc.release();
                }
            }
        }
        catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("Can't find " + delegate, e);
        }
    }
}
