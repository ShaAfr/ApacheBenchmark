// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.persistence;

import java.util.Set;
import javax.persistence.Parameter;
import javax.persistence.LockModeType;
import java.util.Map;
import java.util.Calendar;
import javax.persistence.TemporalType;
import java.util.Date;
import javax.persistence.FlushModeType;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collection;
import java.lang.reflect.Method;
import javax.persistence.EntityManager;
import javax.persistence.Query;

public class JtaQuery implements Query
{
    private EntityManager entityManager;
    private final Object[] args;
    private final Method method;
    private final JtaEntityManager jtaEntityManager;
    private final Collection<QueryOperation> appliedOperations;
    private boolean underTx;
    private boolean unwrap;
    private Query query;
    
    public JtaQuery(final EntityManager entityManager, final JtaEntityManager jtaEntityManager, final Method method, final Object... args) {
        this.appliedOperations = new ArrayList<QueryOperation>();
        this.entityManager = entityManager;
        this.jtaEntityManager = jtaEntityManager;
        this.method = method;
        this.args = args;
        this.underTx = jtaEntityManager.isTransactionActive();
        this.createQuery();
    }
    
    private Query createQuery() {
        if (!this.unwrap) {
            this.query = this.jtaEntityManager.createQuery(this.queryType(), this.entityManager, this.method, this.args);
        }
        if (!this.underTx) {
            for (final QueryOperation op : this.appliedOperations) {
                this.query = op.apply(this.query);
            }
        }
        return this.query;
    }
    
    protected Class<? extends Query> queryType() {
        return Query.class;
    }
    
    private EntityManager getEntityManager() {
        if (!this.underTx) {
            this.entityManager = this.jtaEntityManager.getEntityManager();
            this.underTx = this.jtaEntityManager.isTransactionActive();
            this.createQuery();
        }
        return this.entityManager;
    }
    
    public List getResultList() {
        final EntityManager em = this.getEntityManager();
        try {
            return this.query.getResultList();
        }
        finally {
            this.jtaEntityManager.closeIfNoTx(em);
        }
    }
    
    public Object getSingleResult() {
        final EntityManager em = this.getEntityManager();
        try {
            return this.query.getSingleResult();
        }
        finally {
            this.jtaEntityManager.closeIfNoTx(em);
        }
    }
    
    public int executeUpdate() {
        final EntityManager em = this.getEntityManager();
        try {
            return this.query.executeUpdate();
        }
        finally {
            this.jtaEntityManager.closeIfNoTx(em);
        }
    }
    
    public Query setMaxResults(final int i) {
        this.query.setMaxResults(i);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setMaxResults(i);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setFirstResult(final int i) {
        this.query.setFirstResult(i);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setFirstResult(i);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setFlushMode(final FlushModeType flushModeType) {
        this.query.setFlushMode(flushModeType);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setFlushMode(flushModeType);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setHint(final String s, final Object o) {
        this.query.setHint(s, o);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setHint(s, o);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setParameter(final String s, final Object o) {
        this.query.setParameter(s, o);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(s, o);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setParameter(final String s, final Date date, final TemporalType temporalType) {
        this.query.setParameter(s, date, temporalType);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(s, date, temporalType);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setParameter(final String s, final Calendar calendar, final TemporalType temporalType) {
        this.query.setParameter(s, calendar, temporalType);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(s, calendar, temporalType);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setParameter(final int i, final Object o) {
        this.query.setParameter(i, o);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(i, o);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setParameter(final int i, final Date date, final TemporalType temporalType) {
        this.query.setParameter(i, date, temporalType);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(i, date, temporalType);
                }
            });
        }
        return (Query)this;
    }
    
    public Query setParameter(final int i, final Calendar calendar, final TemporalType temporalType) {
        this.query.setParameter(i, calendar, temporalType);
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(i, calendar, temporalType);
                }
            });
        }
        return (Query)this;
    }
    
    public int getFirstResult() {
        return this.query.getFirstResult();
    }
    
    public FlushModeType getFlushMode() {
        return this.query.getFlushMode();
    }
    
    public Map<String, Object> getHints() {
        return (Map<String, Object>)this.query.getHints();
    }
    
    public LockModeType getLockMode() {
        return this.query.getLockMode();
    }
    
    public int getMaxResults() {
        return this.query.getMaxResults();
    }
    
    public Parameter<?> getParameter(final String name) {
        return (Parameter<?>)this.query.getParameter(name);
    }
    
    public Parameter<?> getParameter(final int position) {
        return (Parameter<?>)this.query.getParameter(position);
    }
    
    public <T> Parameter<T> getParameter(final String name, final Class<T> type) {
        return (Parameter<T>)this.query.getParameter(name, (Class)type);
    }
    
    public <T> Parameter<T> getParameter(final int position, final Class<T> type) {
        return (Parameter<T>)this.query.getParameter(position, (Class)type);
    }
    
    public <T> T getParameterValue(final Parameter<T> param) {
        return (T)this.query.getParameterValue((Parameter)param);
    }
    
    public Object getParameterValue(final String name) {
        return this.query.getParameterValue(name);
    }
    
    public Object getParameterValue(final int position) {
        return this.query.getParameterValue(position);
    }
    
    public Set<Parameter<?>> getParameters() {
        return (Set<Parameter<?>>)this.query.getParameters();
    }
    
    public boolean isBound(final Parameter<?> param) {
        return this.query.isBound((Parameter)param);
    }
    
    public Query setLockMode(final LockModeType lockMode) {
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setLockMode(lockMode);
                }
            });
        }
        return this.query.setLockMode(lockMode);
    }
    
    public <T> Query setParameter(final Parameter<T> param, final T value) {
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(param, value);
                }
            });
        }
        return this.query.setParameter((Parameter)param, (Object)value);
    }
    
    public Query setParameter(final Parameter<Calendar> param, final Calendar value, final TemporalType temporalType) {
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(param, value, temporalType);
                }
            });
        }
        return this.query.setParameter((Parameter)param, value, temporalType);
    }
    
    public Query setParameter(final Parameter<Date> param, final Date value, final TemporalType temporalType) {
        if (!this.underTx) {
            this.appliedOperations.add(new QueryOperation() {
                @Override
                public Query apply(final Query query) {
                    return query.setParameter(param, value, temporalType);
                }
            });
        }
        return this.query.setParameter((Parameter)param, value, temporalType);
    }
    
    public <T> T unwrap(final Class<T> cls) {
        this.unwrap = true;
        if (this.getClass() == cls) {
            return cls.cast(this);
        }
        return (T)this.query.unwrap((Class)cls);
    }
}
