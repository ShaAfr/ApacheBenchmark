// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.spi;

import javax.servlet.http.HttpServletRequest;
import org.apache.openejb.InterfaceType;
import java.lang.reflect.Method;
import java.security.Principal;
import javax.security.auth.login.LoginException;

public interface SecurityService<T> extends Service
{
    T login(final String p0, final String p1) throws LoginException;
    
    T login(final String p0, final String p1, final String p2) throws LoginException;
    
    void associate(final T p0) throws LoginException;
    
    T disassociate();
    
    void logout(final T p0) throws LoginException;
    
    boolean isCallerInRole(final String p0);
    
    Principal getCallerPrincipal();
    
    boolean isCallerAuthorized(final Method p0, final InterfaceType p1);
    
    void setState(final Object p0);
    
    Object currentState();
    
    void onLogout(final HttpServletRequest p0);
}
