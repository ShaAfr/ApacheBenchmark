// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb;

public interface Container
{
    ContainerType getContainerType();
    
    Object getContainerID();
    
    BeanContext getBeanContext(final Object p0);
    
    BeanContext[] getBeanContexts();
    
    void deploy(final BeanContext p0) throws OpenEJBException;
    
    void start(final BeanContext p0) throws OpenEJBException;
    
    void stop(final BeanContext p0) throws OpenEJBException;
    
    void undeploy(final BeanContext p0) throws OpenEJBException;
}
