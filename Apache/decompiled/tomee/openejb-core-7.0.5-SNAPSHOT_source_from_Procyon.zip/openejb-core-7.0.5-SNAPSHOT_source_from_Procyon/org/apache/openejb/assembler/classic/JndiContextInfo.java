// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class JndiContextInfo extends ServiceInfo
{
}
