// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.entity;

import org.apache.openejb.core.transaction.TransactionPolicy.TransactionSynchronization;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.util.Stack;
import java.rmi.RemoteException;
import org.apache.openejb.core.transaction.TransactionRolledbackException;
import org.apache.openejb.ApplicationException;
import javax.ejb.EntityContext;
import org.apache.openejb.SystemException;
import org.apache.openejb.OpenEJBException;
import javax.ejb.NoSuchEntityException;
import org.apache.openejb.InvalidateReferenceException;
import org.apache.openejb.core.NoSuchObjectException;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.core.Operation;
import javax.ejb.EntityBean;
import org.apache.openejb.core.ThreadContext;
import javax.ejb.EJBContext;
import org.apache.openejb.BeanContext;
import java.util.HashMap;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.util.LinkedListStack;
import java.util.Map;
import org.apache.openejb.util.Logger;

public class EntityInstanceManager
{
    private static final Logger logger;
    private final int poolsize;
    private final Map<Object, LinkedListStack> poolMap;
    private final SecurityService securityService;
    
    public EntityInstanceManager(final EntityContainer container, final SecurityService securityService, final int poolSize) {
        this.securityService = securityService;
        this.poolsize = poolSize;
        this.poolMap = new HashMap<Object, LinkedListStack>();
        final BeanContext[] beanContexts2;
        final BeanContext[] beanContexts = beanContexts2 = container.getBeanContexts();
        for (final BeanContext beanContext : beanContexts2) {
            this.deploy(beanContext);
        }
    }
    
    public void deploy(final BeanContext beanContext) {
        this.poolMap.put(beanContext.getDeploymentID(), new LinkedListStack(this.poolsize / 2));
        beanContext.set((Class<Object>)EJBContext.class, this.createEntityContext());
    }
    
    public void undeploy(final BeanContext beanContext) {
        this.poolMap.remove(beanContext.getDeploymentID());
    }
    
    public EntityBean obtainInstance(final ThreadContext callContext) throws OpenEJBException {
        final Object primaryKey = callContext.getPrimaryKey();
        final TransactionPolicy txPolicy = callContext.getTransactionPolicy();
        if (callContext.getPrimaryKey() == null || txPolicy == null || !txPolicy.isTransactionActive()) {
            return this.getPooledInstance(callContext);
        }
        final Key key = new Key(callContext.getBeanContext().getDeploymentID(), primaryKey);
        SynchronizationWrapper wrapper = (SynchronizationWrapper)txPolicy.getResource(key);
        if (wrapper == null) {
            final EntityBean bean = this.getPooledInstance(callContext);
            wrapper = new SynchronizationWrapper(callContext.getBeanContext(), primaryKey, bean, false, key, txPolicy);
            if (callContext.getCurrentOperation() == Operation.REMOVE) {
                wrapper.disassociate();
            }
            txPolicy.registerSynchronization(wrapper);
            this.loadingBean(bean, callContext);
            final Operation orginalOperation = callContext.getCurrentOperation();
            callContext.setCurrentOperation(Operation.LOAD);
            try {
                bean.ejbLoad();
            }
            catch (NoSuchEntityException e) {
                wrapper.disassociate();
                throw new InvalidateReferenceException(new NoSuchObjectException("Entity not found: " + primaryKey, (Throwable)e));
            }
            catch (Exception e2) {
                EntityInstanceManager.logger.error("Exception encountered during ejbLoad():", e2);
                wrapper.disassociate();
                throw new OpenEJBException(e2);
            }
            finally {
                callContext.setCurrentOperation(orginalOperation);
            }
            txPolicy.putResource(key, wrapper);
            return bean;
        }
        if (!wrapper.isAssociated()) {
            throw new InvalidateReferenceException(new NoSuchObjectException("Entity not found: " + primaryKey));
        }
        if (callContext.getCurrentOperation() == Operation.REMOVE) {
            wrapper.disassociate();
        }
        if (wrapper.isAvailable() || wrapper.primaryKey.equals(primaryKey)) {
            return wrapper.getEntityBean();
        }
        return wrapper.getEntityBean();
    }
    
    protected void loadingBean(final EntityBean bean, final ThreadContext callContext) throws OpenEJBException {
    }
    
    protected void reusingBean(final EntityBean bean, final ThreadContext callContext) throws OpenEJBException {
    }
    
    protected EntityBean getPooledInstance(final ThreadContext callContext) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final Stack methodReadyPool = this.poolMap.get(beanContext.getDeploymentID());
        if (methodReadyPool == null) {
            throw new SystemException("Invalid deployment id " + beanContext.getDeploymentID() + " for this container");
        }
        EntityBean bean = (EntityBean)methodReadyPool.pop();
        if (bean == null) {
            try {
                bean = beanContext.getBeanClass().newInstance();
            }
            catch (Exception e) {
                EntityInstanceManager.logger.error("Bean instantiation failed for class " + beanContext.getBeanClass(), e);
                throw new SystemException(e);
            }
            final Operation currentOp = callContext.getCurrentOperation();
            callContext.setCurrentOperation(Operation.SET_CONTEXT);
            try {
                bean.setEntityContext((EntityContext)this.createEntityContext());
            }
            catch (Exception e2) {
                EntityInstanceManager.logger.error("Bean callback method failed ", e2);
                throw new ApplicationException(e2);
            }
            finally {
                callContext.setCurrentOperation(currentOp);
            }
        }
        else {
            this.reusingBean(bean, callContext);
        }
        if (callContext.getCurrentOperation() == Operation.BUSINESS || callContext.getCurrentOperation() == Operation.REMOVE) {
            final Operation currentOp = callContext.getCurrentOperation();
            callContext.setCurrentOperation(Operation.ACTIVATE);
            try {
                bean.ejbActivate();
            }
            catch (Throwable e3) {
                EntityInstanceManager.logger.error("Encountered exception during call to ejbActivate()", e3);
                final TransactionPolicy txPolicy = callContext.getTransactionPolicy();
                if (txPolicy != null && txPolicy.isTransactionActive()) {
                    txPolicy.setRollbackOnly(e3);
                    throw new ApplicationException((Exception)new TransactionRolledbackException("Reflection exception thrown while attempting to call ejbActivate() on the instance", e3));
                }
                throw new ApplicationException(new RemoteException("Exception thrown while attempting to call ejbActivate() on the instance. Exception message = " + e3.getMessage(), e3));
            }
            finally {
                callContext.setCurrentOperation(currentOp);
            }
        }
        return bean;
    }
    
    private org.apache.openejb.core.entity.EntityContext createEntityContext() {
        return new org.apache.openejb.core.entity.EntityContext(this.securityService);
    }
    
    public void poolInstance(final ThreadContext callContext, final EntityBean bean, final Object primaryKey) throws OpenEJBException {
        if (bean == null) {
            return;
        }
        final TransactionPolicy txPolicy = callContext.getTransactionPolicy();
        if (primaryKey != null && txPolicy != null && txPolicy.isTransactionActive()) {
            final Key key = new Key(callContext.getBeanContext().getDeploymentID(), primaryKey);
            SynchronizationWrapper wrapper = (SynchronizationWrapper)txPolicy.getResource(key);
            if (wrapper != null) {
                if (callContext.getCurrentOperation() == Operation.REMOVE) {
                    wrapper.disassociate();
                    final Stack methodReadyPool = this.poolMap.get(callContext.getBeanContext().getDeploymentID());
                    methodReadyPool.push(bean);
                }
                else {
                    if (callContext.getCurrentOperation() == Operation.CREATE) {
                        wrapper.associate();
                    }
                    wrapper.setEntityBean(bean);
                }
            }
            else {
                wrapper = new SynchronizationWrapper(callContext.getBeanContext(), primaryKey, bean, true, key, txPolicy);
                txPolicy.registerSynchronization(wrapper);
                txPolicy.putResource(key, wrapper);
            }
        }
        else {
            if (primaryKey != null && callContext.getCurrentOperation() != Operation.REMOVE) {
                final Operation currentOp = callContext.getCurrentOperation();
                callContext.setCurrentOperation(Operation.PASSIVATE);
                try {
                    bean.ejbPassivate();
                }
                catch (Throwable e) {
                    if (txPolicy.isTransactionActive()) {
                        txPolicy.setRollbackOnly(e);
                        throw new ApplicationException((Exception)new TransactionRolledbackException("Reflection exception thrown while attempting to call ejbPassivate() on the instance", e));
                    }
                    throw new ApplicationException(new RemoteException("Reflection exception thrown while attempting to call ejbPassivate() on the instance. Exception message = " + e.getMessage(), e));
                }
                finally {
                    callContext.setCurrentOperation(currentOp);
                }
            }
            final Stack methodReadyPool2 = this.poolMap.get(callContext.getBeanContext().getDeploymentID());
            methodReadyPool2.push(bean);
        }
    }
    
    public void freeInstance(final ThreadContext callContext, final EntityBean bean) throws SystemException {
        this.discardInstance(callContext, bean);
        final Operation currentOp = callContext.getCurrentOperation();
        callContext.setCurrentOperation(Operation.UNSET_CONTEXT);
        try {
            bean.unsetEntityContext();
        }
        catch (Exception e) {
            EntityInstanceManager.logger.info(this.getClass().getName() + ".freeInstance: ignoring exception " + e + " on bean instance " + bean);
        }
        finally {
            callContext.setCurrentOperation(currentOp);
        }
    }
    
    public void discardInstance(final ThreadContext callContext, final EntityBean bean) throws SystemException {
        final Object primaryKey = callContext.getPrimaryKey();
        final TransactionPolicy txPolicy = callContext.getTransactionPolicy();
        if (primaryKey == null || txPolicy == null || !txPolicy.isTransactionActive()) {
            return;
        }
        final Key key = new Key(callContext.getBeanContext().getDeploymentID(), primaryKey);
        final SynchronizationWrapper wrapper = (SynchronizationWrapper)txPolicy.getResource(key);
        if (wrapper != null) {
            wrapper.disassociate();
        }
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
    }
    
    private static class Key
    {
        private final Object deploymentId;
        private final Object primaryKey;
        
        public Key(final Object deploymentId, final Object primaryKey) {
            if (deploymentId == null) {
                throw new NullPointerException("deploymentId is null");
            }
            if (primaryKey == null) {
                throw new NullPointerException("primaryKey is null");
            }
            this.deploymentId = deploymentId;
            this.primaryKey = primaryKey;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final Key key = (Key)o;
            return this.deploymentId.equals(key.deploymentId) && this.primaryKey.equals(key.primaryKey);
        }
        
        @Override
        public int hashCode() {
            int result = this.deploymentId.hashCode();
            result = 31 * result + this.primaryKey.hashCode();
            return result;
        }
    }
    
    protected class SynchronizationWrapper implements TransactionPolicy.TransactionSynchronization
    {
        private EntityBean bean;
        private boolean available;
        private boolean associated;
        private final Key readyPoolKey;
        private final BeanContext beanContext;
        private final Object primaryKey;
        private final TransactionPolicy txPolicy;
        
        public SynchronizationWrapper(final BeanContext beanContext, final Object primaryKey, final EntityBean bean, final boolean available, final Key readyPoolKey, final TransactionPolicy txPolicy) {
            if (bean == null) {
                throw new IllegalArgumentException("bean is null");
            }
            if (readyPoolKey == null) {
                throw new IllegalArgumentException("key is null");
            }
            if (beanContext == null) {
                throw new IllegalArgumentException("deploymentInfo is null");
            }
            if (primaryKey == null) {
                throw new IllegalArgumentException("primaryKey is null");
            }
            if (txPolicy == null) {
                throw new IllegalArgumentException("txEnv is null");
            }
            this.beanContext = beanContext;
            this.bean = bean;
            this.primaryKey = primaryKey;
            this.available = available;
            this.readyPoolKey = readyPoolKey;
            this.txPolicy = txPolicy;
            this.associated = true;
        }
        
        public void associate() {
            this.associated = true;
        }
        
        public void disassociate() {
            this.associated = false;
        }
        
        public boolean isAssociated() {
            return this.associated;
        }
        
        public synchronized boolean isAvailable() {
            return this.available;
        }
        
        public synchronized void setEntityBean(final EntityBean ebean) {
            this.available = true;
            this.bean = ebean;
        }
        
        public synchronized EntityBean getEntityBean() {
            this.available = false;
            return this.bean;
        }
        
        @Override
        public void beforeCompletion() {
            if (this.associated) {
                final EntityBean bean;
                synchronized (this) {
                    bean = this.bean;
                }
                final ThreadContext callContext = new ThreadContext(this.beanContext, this.primaryKey);
                callContext.setCurrentOperation(Operation.STORE);
                final ThreadContext oldCallContext = ThreadContext.enter(callContext);
                try {
                    bean.ejbStore();
                }
                catch (Exception re) {
                    EntityInstanceManager.logger.error("Exception occured during ejbStore()", re);
                    this.txPolicy.setRollbackOnly(re);
                }
                finally {
                    ThreadContext.exit(oldCallContext);
                }
            }
        }
        
        @Override
        public void afterCompletion(final Status status) {
            this.txPolicy.removeResource(this.readyPoolKey);
        }
    }
}
