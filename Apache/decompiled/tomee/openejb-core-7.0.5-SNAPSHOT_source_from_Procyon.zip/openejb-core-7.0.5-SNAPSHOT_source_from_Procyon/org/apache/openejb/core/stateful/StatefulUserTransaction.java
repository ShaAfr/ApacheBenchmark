// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import javax.transaction.RollbackException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.SystemException;
import javax.transaction.NotSupportedException;
import org.apache.openejb.BeanContext;
import org.apache.openejb.BeanType;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.persistence.JtaEntityManagerRegistry;
import javax.transaction.UserTransaction;

public class StatefulUserTransaction implements UserTransaction
{
    private final UserTransaction userTransaction;
    private final JtaEntityManagerRegistry jtaEntityManagerRegistry;
    
    public StatefulUserTransaction(final UserTransaction userTransaction, final JtaEntityManagerRegistry jtaEntityManagerRegistry) {
        this.userTransaction = userTransaction;
        this.jtaEntityManagerRegistry = jtaEntityManagerRegistry;
    }
    
    public void begin() throws NotSupportedException, SystemException {
        this.userTransaction.begin();
        final ThreadContext callContext = ThreadContext.getThreadContext();
        if (callContext == null) {
            return;
        }
        final BeanContext beanContext = callContext.getBeanContext();
        if (beanContext.getComponentType() != BeanType.STATEFUL) {
            return;
        }
        final Object primaryKey = callContext.getPrimaryKey();
        if (primaryKey == null) {
            return;
        }
        this.jtaEntityManagerRegistry.transactionStarted((String)beanContext.getDeploymentID(), primaryKey);
    }
    
    public void commit() throws HeuristicMixedException, HeuristicRollbackException, IllegalStateException, RollbackException, SecurityException, SystemException {
        this.userTransaction.commit();
    }
    
    public int getStatus() throws SystemException {
        return this.userTransaction.getStatus();
    }
    
    public void rollback() throws IllegalStateException, SecurityException, SystemException {
        this.userTransaction.rollback();
    }
    
    public void setRollbackOnly() throws IllegalStateException, SystemException {
        this.userTransaction.setRollbackOnly();
    }
    
    public void setTransactionTimeout(final int i) throws SystemException {
        this.userTransaction.setTransactionTimeout(i);
    }
}
