// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.HashMap;
import java.util.Map;

public class MessageDrivenBeanInfo extends EnterpriseBeanInfo
{
    public String mdbInterface;
    public String destinationId;
    public final Map<String, String> activationProperties;
    
    public MessageDrivenBeanInfo() {
        this.activationProperties = new HashMap<String, String>();
        this.type = 3;
    }
}
