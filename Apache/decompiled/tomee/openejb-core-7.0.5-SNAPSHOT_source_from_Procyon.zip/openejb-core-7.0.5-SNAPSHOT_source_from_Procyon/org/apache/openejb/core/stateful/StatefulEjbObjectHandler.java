// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.stateful;

import java.io.Serializable;
import org.apache.openejb.util.proxy.ProxyManager;
import java.rmi.RemoteException;
import java.lang.reflect.Method;
import org.apache.openejb.Container;
import java.util.List;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.BeanContext;
import org.apache.openejb.core.ivm.EjbObjectProxyHandler;

public class StatefulEjbObjectHandler extends EjbObjectProxyHandler
{
    public StatefulEjbObjectHandler(final BeanContext beanContext, final Object pk, final InterfaceType interfaceType, final List<Class> interfaces, final Class mainInterface) {
        super(beanContext, pk, interfaceType, interfaces, mainInterface);
    }
    
    @Override
    public Object getRegistryId() {
        return new RegistryId(this.container, this.deploymentID, this.primaryKey);
    }
    
    @Override
    protected Object getPrimaryKey(final Method method, final Object[] args, final Object proxy) throws Throwable {
        throw new RemoteException("Session objects are private resources and do not have primary keys");
    }
    
    @Override
    protected Object isIdentical(final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        if (args.length != 1) {
            throw new IllegalArgumentException("Expected one argument to isIdentical, but received " + args.length);
        }
        final Object that = args[0];
        final Object invocationHandler = ProxyManager.getInvocationHandler(that);
        if (invocationHandler instanceof StatefulEjbObjectHandler) {
            final StatefulEjbObjectHandler handler = (StatefulEjbObjectHandler)invocationHandler;
            return this.getRegistryId().equals(handler.getRegistryId());
        }
        return false;
    }
    
    @Override
    protected Object remove(final Class interfce, final Method method, final Object[] args, final Object proxy) throws Throwable {
        this.checkAuthorization(method);
        final Object value = this.container.invoke(this.deploymentID, this.interfaceType, interfce, method, args, this.primaryKey);
        this.invalidateAllHandlers(this.getRegistryId());
        return value;
    }
    
    public static class RegistryId implements Serializable
    {
        private static final long serialVersionUID = 5037368364299042022L;
        private final Object containerId;
        private final Object deploymentId;
        private final Object primaryKey;
        
        public RegistryId(final Container container, final Object deploymentId, final Object primaryKey) {
            if (container == null) {
                throw new NullPointerException("container is null");
            }
            if (deploymentId == null) {
                throw new NullPointerException("deploymentId is null");
            }
            this.containerId = container.getContainerID();
            this.deploymentId = deploymentId;
            this.primaryKey = primaryKey;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final RegistryId that = (RegistryId)o;
            if (this.containerId.equals(that.containerId) && this.deploymentId.equals(that.deploymentId)) {
                if (this.primaryKey != null) {
                    if (!this.primaryKey.equals(that.primaryKey)) {
                        return false;
                    }
                }
                else if (that.primaryKey != null) {
                    return false;
                }
                return true;
            }
            return false;
        }
        
        @Override
        public int hashCode() {
            int result = this.containerId.hashCode();
            result = 31 * result + this.deploymentId.hashCode();
            result = 31 * result + ((this.primaryKey != null) ? this.primaryKey.hashCode() : 0);
            return result;
        }
        
        @Override
        public String toString() {
            return "[" + this.containerId + ", " + this.deploymentId + ", " + this.primaryKey + "]";
        }
        
        public Object getPrimaryKey() {
            return this.primaryKey;
        }
    }
}
