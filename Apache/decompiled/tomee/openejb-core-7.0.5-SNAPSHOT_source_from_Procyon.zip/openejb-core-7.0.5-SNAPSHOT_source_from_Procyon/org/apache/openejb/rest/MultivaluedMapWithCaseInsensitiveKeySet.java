// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.List;
import javax.ws.rs.core.MultivaluedMap;

public class MultivaluedMapWithCaseInsensitiveKeySet<V> implements MultivaluedMap<String, V>
{
    private final MultivaluedMap<String, V> delegate;
    
    public MultivaluedMapWithCaseInsensitiveKeySet(final MultivaluedMap<String, V> map) {
        this.delegate = map;
    }
    
    public void add(final String key, final V value) {
        this.delegate.add((Object)key, (Object)value);
    }
    
    public V getFirst(final String key) {
        return (V)this.delegate.getFirst((Object)this.realKey(key));
    }
    
    public void addAll(final String key, final V... newValues) {
        this.delegate.addAll((Object)key, (Object[])newValues);
    }
    
    public void addAll(final String key, final List<V> valueList) {
        this.delegate.addAll((Object)key, (List)valueList);
    }
    
    public void addFirst(final String key, final V value) {
        this.delegate.addFirst((Object)key, (Object)value);
    }
    
    public boolean equalsIgnoreValueOrder(final MultivaluedMap<String, V> otherMap) {
        return this.delegate.equalsIgnoreValueOrder((MultivaluedMap)otherMap);
    }
    
    public void putSingle(final String key, final V value) {
        this.delegate.putSingle((Object)key, (Object)value);
    }
    
    public int size() {
        return this.delegate.size();
    }
    
    public boolean isEmpty() {
        return this.delegate.isEmpty();
    }
    
    public boolean containsKey(final Object key) {
        return getInsensitiveKeySet(this.delegate.keySet()).contains(key.toString());
    }
    
    public boolean containsValue(final Object value) {
        return this.delegate.containsValue(value);
    }
    
    public List<V> get(final Object key) {
        return (List<V>)this.delegate.get((Object)this.realKey(key));
    }
    
    public List<V> put(final String key, final List<V> value) {
        return (List<V>)this.delegate.put((Object)key, (Object)value);
    }
    
    public List<V> remove(final Object key) {
        return (List<V>)this.delegate.remove((Object)this.realKey(key));
    }
    
    public void putAll(final Map<? extends String, ? extends List<V>> m) {
        this.delegate.putAll((Map)m);
    }
    
    public void clear() {
        this.delegate.clear();
    }
    
    public Set<String> keySet() {
        return getInsensitiveKeySet(this.delegate.keySet());
    }
    
    public Collection<List<V>> values() {
        return (Collection<List<V>>)this.delegate.values();
    }
    
    public Set<Map.Entry<String, List<V>>> entrySet() {
        return (Set<Map.Entry<String, List<V>>>)this.delegate.entrySet();
    }
    
    private static Set<String> getInsensitiveKeySet(final Set<String> values) {
        final Set<String> set = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
        set.addAll(values);
        return set;
    }
    
    private static Object lowerCase(final Object key) {
        if (key instanceof String) {
            return ((String)key).toLowerCase();
        }
        return key;
    }
    
    private String realKey(final Object key) {
        for (final Map.Entry<String, ?> entry : this.delegate.entrySet()) {
            if (entry.getKey().toLowerCase().equals(lowerCase(key))) {
                return entry.getKey();
            }
        }
        return null;
    }
}
