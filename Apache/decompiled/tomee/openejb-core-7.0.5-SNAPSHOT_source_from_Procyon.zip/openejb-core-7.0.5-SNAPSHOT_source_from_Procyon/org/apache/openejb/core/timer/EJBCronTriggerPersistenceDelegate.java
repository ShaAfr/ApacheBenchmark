// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.quartz.spi.MutableTrigger;
import java.io.IOException;
import org.apache.openejb.quartz.JobDetail;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import org.apache.openejb.quartz.ScheduleBuilder;
import javax.ejb.ScheduleExpression;
import org.apache.openejb.quartz.impl.jdbcjobstore.Util;
import org.apache.openejb.quartz.impl.jdbcjobstore.TriggerPersistenceDelegate;
import org.apache.openejb.quartz.TriggerKey;
import java.sql.Connection;
import org.apache.openejb.quartz.spi.OperableTrigger;
import org.apache.openejb.quartz.impl.jdbcjobstore.CronTriggerPersistenceDelegate;

public class EJBCronTriggerPersistenceDelegate extends CronTriggerPersistenceDelegate
{
    public String getHandledTriggerTypeDiscriminator() {
        return "EJB_CRON";
    }
    
    public boolean canHandleTriggerType(final OperableTrigger trigger) {
        return trigger instanceof EJBCronTrigger;
    }
    
    public TriggerPersistenceDelegate.TriggerPropertyBundle loadExtendedTriggerProperties(final Connection conn, final TriggerKey triggerKey) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(Util.rtp("SELECT * FROM {0}CRON_TRIGGERS WHERE SCHED_NAME = {1} AND TRIGGER_NAME = ? AND TRIGGER_GROUP = ?", this.tablePrefix, this.schedNameLiteral));
            ps.setString(1, triggerKey.getName());
            ps.setString(2, triggerKey.getGroup());
            rs = ps.executeQuery();
            if (rs.next()) {
                final String cronExpr = rs.getString("CRON_EXPRESSION");
                final String timeZoneId = rs.getString("TIME_ZONE_ID");
                final String[] parts = cronExpr.split(";");
                try {
                    final EJBCronTrigger cb = new EJBCronTrigger(new ScheduleExpression().year(parts[0]).month(parts[1]).dayOfMonth(parts[2]).dayOfWeek(parts[3]).hour(parts[4]).minute(parts[5]).second(parts[6]).timezone(timeZoneId));
                    return new TriggerPersistenceDelegate.TriggerPropertyBundle((ScheduleBuilder)new EJBCronTriggerSceduleBuilder(cb), (String[])null, (Object[])null);
                }
                catch (EJBCronTrigger.ParseException e) {
                    throw new IllegalStateException("Can't build the Trigger with key: '" + triggerKey + "' and statement: " + Util.rtp("SELECT * FROM {0}CRON_TRIGGERS WHERE SCHED_NAME = {1} AND TRIGGER_NAME = ? AND TRIGGER_GROUP = ?", this.tablePrefix, this.schedNameLiteral));
                }
            }
            throw new IllegalStateException("No record found for selection of Trigger with key: '" + triggerKey + "' and statement: " + Util.rtp("SELECT * FROM {0}CRON_TRIGGERS WHERE SCHED_NAME = {1} AND TRIGGER_NAME = ? AND TRIGGER_GROUP = ?", this.tablePrefix, this.schedNameLiteral));
        }
        finally {
            Util.closeResultSet(rs);
            Util.closeStatement((Statement)ps);
        }
    }
    
    public int insertExtendedTriggerProperties(final Connection conn, final OperableTrigger trigger, final String state, final JobDetail jobDetail) throws SQLException, IOException {
        final EJBCronTrigger cronTrigger = (EJBCronTrigger)trigger;
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(Util.rtp("INSERT INTO {0}CRON_TRIGGERS (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, CRON_EXPRESSION, TIME_ZONE_ID)  VALUES({1}, ?, ?, ?, ?)", this.tablePrefix, this.schedNameLiteral));
            ps.setString(1, trigger.getKey().getName());
            ps.setString(2, trigger.getKey().getGroup());
            ps.setString(3, cronTrigger.getRawValue());
            ps.setString(4, cronTrigger.getTimeZone().getID());
            return ps.executeUpdate();
        }
        finally {
            Util.closeStatement((Statement)ps);
        }
    }
    
    public int updateExtendedTriggerProperties(final Connection conn, final OperableTrigger trigger, final String state, final JobDetail jobDetail) throws SQLException, IOException {
        final EJBCronTrigger cronTrigger = (EJBCronTrigger)trigger;
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(Util.rtp("UPDATE {0}CRON_TRIGGERS SET CRON_EXPRESSION = ?, TIME_ZONE_ID = ? WHERE SCHED_NAME = {1} AND TRIGGER_NAME = ? AND TRIGGER_GROUP = ?", this.tablePrefix, this.schedNameLiteral));
            ps.setString(1, cronTrigger.getRawValue());
            ps.setString(2, cronTrigger.getTimeZone().getID());
            ps.setString(3, trigger.getKey().getName());
            ps.setString(4, trigger.getKey().getGroup());
            return ps.executeUpdate();
        }
        finally {
            Util.closeStatement((Statement)ps);
        }
    }
    
    private static class EJBCronTriggerSceduleBuilder extends ScheduleBuilder<EJBCronTrigger>
    {
        private final EJBCronTrigger trigger;
        
        public EJBCronTriggerSceduleBuilder(final EJBCronTrigger trig) {
            this.trigger = trig;
        }
        
        protected MutableTrigger build() {
            return (MutableTrigger)this.trigger;
        }
    }
}
