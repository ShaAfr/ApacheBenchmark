// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.io.Serializable;
import org.apache.openejb.util.LogCategory;
import org.apache.openejb.util.IntrospectionSupport;
import org.apache.openejb.core.ivm.naming.JndiUrlReference;
import org.apache.openejb.core.ivm.naming.JndiReference;
import javax.naming.Name;
import org.apache.openejb.core.CoreUserTransaction;
import javax.ejb.spi.HandleDelegate;
import org.apache.openejb.core.ivm.naming.SystemComponentReference;
import org.apache.openejb.core.ParentClassLoaderFinder;
import org.apache.openejb.core.TransactionSynchronizationRegistryWrapper;
import javax.transaction.TransactionManager;
import org.apache.openejb.core.webservices.HandlerChainData;
import java.util.List;
import org.apache.openejb.core.ivm.naming.Reference;
import java.util.Iterator;
import org.apache.openejb.core.webservices.ServiceRefData;
import org.apache.openejb.core.ivm.naming.JaxWsServiceReference;
import org.apache.openejb.core.webservices.PortRefData;
import java.util.ArrayList;
import javax.xml.ws.Service;
import javax.persistence.EntityManager;
import org.apache.openejb.core.ivm.naming.PersistenceContextReference;
import org.apache.openejb.persistence.JtaEntityManager;
import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import org.apache.openejb.spi.ContainerSystem;
import javax.transaction.UserTransaction;
import org.apache.openejb.core.ivm.naming.LazyObjectReference;
import org.apache.webbeans.container.InjectableBeanManager;
import org.apache.webbeans.config.WebBeansContext;
import java.util.concurrent.Callable;
import javax.enterprise.inject.spi.BeanManager;
import javax.ejb.TimerService;
import javax.xml.ws.WebServiceContext;
import javax.validation.ValidatorFactory;
import javax.validation.Validator;
import javax.ejb.EJBContext;
import org.apache.openejb.core.ivm.naming.MapObjectReference;
import javax.ws.rs.core.Configuration;
import javax.ws.rs.container.ResourceContext;
import javax.ws.rs.container.ResourceInfo;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;
import javax.servlet.ServletConfig;
import javax.ws.rs.ext.Providers;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriInfo;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import org.apache.openejb.core.ivm.naming.ObjectReference;
import org.apache.openejb.rest.ThreadLocalContextManager;
import javax.ws.rs.core.Request;
import javax.naming.LinkRef;
import java.lang.annotation.Annotation;
import javax.annotation.ManagedBean;
import org.apache.openejb.core.ivm.naming.URLReference;
import java.net.MalformedURLException;
import org.apache.openejb.core.ivm.naming.ClassReference;
import java.net.URL;
import org.apache.openejb.util.Classes;
import org.apache.openejb.core.ivm.naming.IntraVmJndiReference;
import org.apache.openejb.core.ivm.naming.CrossClassLoaderJndiReference;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.persistence.JtaEntityManagerRegistry;
import java.util.TreeMap;
import org.apache.openejb.SystemException;
import java.util.HashMap;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.core.JndiFactory;
import java.util.Map;
import javax.naming.Context;
import org.apache.openejb.OpenEJBException;
import java.util.Properties;
import org.apache.openejb.Injection;
import java.util.Collection;
import java.net.URI;
import org.apache.openejb.util.Logger;

public class JndiEncBuilder
{
    public static final Logger logger;
    private final boolean beanManagedTransactions;
    private final JndiEncInfo jndiEnc;
    private final URI moduleUri;
    private final String moduleId;
    private final String uniqueId;
    private final Collection<Injection> injections;
    private final ClassLoader classLoader;
    private final Properties properties;
    private boolean useCrossClassLoaderRef;
    private boolean client;
    
    public JndiEncBuilder(final JndiEncInfo jndiEnc, final Collection<Injection> injections, final String moduleId, final URI moduleUri, final String uniqueId, final ClassLoader classLoader, final Properties properties) throws OpenEJBException {
        this(jndiEnc, injections, null, moduleId, moduleUri, uniqueId, classLoader, properties);
    }
    
    public JndiEncBuilder(final JndiEncInfo jndiEnc, final Collection<Injection> injections, final String transactionType, final String moduleId, final URI moduleUri, final String uniqueId, final ClassLoader classLoader, final Properties properties) throws OpenEJBException {
        this.useCrossClassLoaderRef = true;
        this.jndiEnc = jndiEnc;
        this.properties = properties;
        this.injections = injections;
        this.beanManagedTransactions = (transactionType != null && transactionType.equalsIgnoreCase("Bean"));
        this.moduleId = moduleId;
        this.moduleUri = moduleUri;
        this.uniqueId = uniqueId;
        this.classLoader = classLoader;
    }
    
    public boolean isUseCrossClassLoaderRef() {
        return this.useCrossClassLoaderRef;
    }
    
    public void setUseCrossClassLoaderRef(final boolean useCrossClassLoaderRef) {
        this.useCrossClassLoaderRef = useCrossClassLoaderRef;
    }
    
    public boolean isClient() {
        return this.client;
    }
    
    public void setClient(final boolean client) {
        this.client = client;
    }
    
    public Context build(final JndiScope type) throws OpenEJBException {
        final Map<String, Object> bindings = this.buildBindings(type);
        return this.build(bindings);
    }
    
    public Context build(final Map<String, Object> bindings) throws SystemException {
        final JndiFactory jndiFactory = (JndiFactory)SystemInstance.get().getComponent((Class)JndiFactory.class);
        if (SystemInstance.get().hasProperty("openejb.geronimo")) {
            return jndiFactory.createComponentContext(new HashMap<String, Object>());
        }
        return jndiFactory.createComponentContext(bindings);
    }
    
    public Map<String, Object> buildBindings(final JndiScope type) throws OpenEJBException {
        final Map<String, Object> bindings = this.buildMap(type);
        switch (type) {
            case comp: {
                this.addSpecialCompBindings(bindings);
                break;
            }
            case module: {
                this.addSpecialModuleBindings(bindings);
                break;
            }
            case app: {
                this.addSpecialAppBindings(bindings);
                break;
            }
            case global: {
                this.addSpecialGlobalBindings(bindings);
                break;
            }
        }
        return bindings;
    }
    
    public Map<String, Object> buildMap(final JndiScope scope) throws OpenEJBException {
        final Map<String, Object> bindings = new TreeMap<String, Object>();
        final JtaEntityManagerRegistry jtaEntityManagerRegistry = (JtaEntityManagerRegistry)SystemInstance.get().getComponent((Class)JtaEntityManagerRegistry.class);
        for (final EjbReferenceInfo referenceInfo : this.jndiEnc.ejbReferences) {
            Reference reference;
            if (referenceInfo.location != null) {
                reference = this.buildReferenceLocation(referenceInfo.location);
            }
            else if (referenceInfo.ejbDeploymentId == null) {
                reference = new LazyEjbReference(new Ref(referenceInfo), this.moduleUri, this.useCrossClassLoaderRef);
            }
            else {
                final String jndiName = "openejb/Deployment/" + JndiBuilder.format(referenceInfo.ejbDeploymentId, referenceInfo.interfaceClassName, referenceInfo.localbean ? InterfaceType.LOCALBEAN : InterfaceType.BUSINESS_REMOTE);
                if (this.useCrossClassLoaderRef && referenceInfo.externalReference) {
                    reference = new CrossClassLoaderJndiReference(jndiName);
                }
                else {
                    reference = new IntraVmJndiReference(jndiName);
                }
            }
            bindings.put(this.normalize(referenceInfo.referenceName), reference);
        }
        for (final EjbReferenceInfo referenceInfo : this.jndiEnc.ejbLocalReferences) {
            Reference reference;
            if (referenceInfo.location != null) {
                reference = this.buildReferenceLocation(referenceInfo.location);
            }
            else if (referenceInfo.ejbDeploymentId == null) {
                reference = new LazyEjbReference(new Ref(referenceInfo), this.moduleUri, false);
            }
            else {
                final String jndiName = "openejb/Deployment/" + JndiBuilder.format(referenceInfo.ejbDeploymentId, referenceInfo.interfaceClassName, referenceInfo.localbean ? InterfaceType.LOCALBEAN : InterfaceType.BUSINESS_LOCAL);
                reference = new IntraVmJndiReference(jndiName);
            }
            bindings.put(this.normalize(referenceInfo.referenceName), reference);
        }
        for (final EnvEntryInfo entry : this.jndiEnc.envEntries) {
            if (entry.location != null) {
                final Reference reference = this.buildReferenceLocation(entry.location);
                bindings.put(this.normalize(entry.referenceName), reference);
            }
            else {
                if (entry.value == null) {
                    continue;
                }
                try {
                    final Class type = Classes.deprimitivize(this.getType(entry.type, entry));
                    Object obj;
                    if (type == String.class) {
                        obj = new String(entry.value);
                    }
                    else if (type == Double.class) {
                        obj = new Double(entry.value);
                    }
                    else if (type == Integer.class) {
                        obj = new Integer(entry.value);
                    }
                    else if (type == Long.class) {
                        obj = new Long(entry.value);
                    }
                    else if (type == Float.class) {
                        obj = new Float(entry.value);
                    }
                    else if (type == Short.class) {
                        obj = new Short(entry.value);
                    }
                    else if (type == Boolean.class) {
                        obj = Boolean.valueOf(entry.value);
                    }
                    else if (type == Byte.class) {
                        obj = new Byte(entry.value);
                    }
                    else if (type == Character.class) {
                        final StringBuilder sb = new StringBuilder(entry.value + " ");
                        obj = new Character(sb.charAt(0));
                    }
                    else if (type == URL.class) {
                        obj = new URL(entry.value);
                    }
                    else if (type == Class.class) {
                        obj = new ClassReference(entry.value.trim());
                    }
                    else {
                        if (!type.isEnum()) {
                            throw new IllegalArgumentException("Invalid env-entry-type " + type);
                        }
                        obj = Enum.valueOf((Class<Object>)type, entry.value.trim());
                    }
                    bindings.put(this.normalize(entry.referenceName), obj);
                }
                catch (NumberFormatException e) {
                    throw new IllegalArgumentException("The env-entry-value for entry " + entry.referenceName + " was not recognizable as type " + entry.type + ". Received Message: " + e.getLocalizedMessage(), e);
                }
                catch (MalformedURLException e2) {
                    throw new IllegalArgumentException("URL for reference " + entry.referenceName + " was not a valid URL: " + entry.value, e2);
                }
            }
        }
        for (final ResourceReferenceInfo referenceInfo2 : this.jndiEnc.resourceRefs) {
            if (!(referenceInfo2 instanceof ContextReferenceInfo)) {
                if (referenceInfo2.location != null) {
                    final Reference reference = this.buildReferenceLocation(referenceInfo2.location);
                    bindings.put(this.normalize(referenceInfo2.referenceName), reference);
                }
                else {
                    final Class<?> type2 = (Class<?>)this.getType(referenceInfo2.referenceType, referenceInfo2);
                    Object reference2;
                    if (URL.class.equals(type2)) {
                        reference2 = new URLReference(referenceInfo2.resourceID);
                    }
                    else if (type2.isAnnotationPresent((Class<? extends Annotation>)ManagedBean.class)) {
                        final ManagedBean managed = type2.getAnnotation(ManagedBean.class);
                        final String name = (managed.value().length() == 0) ? type2.getSimpleName() : managed.value();
                        reference2 = new LinkRef("module/" + name);
                    }
                    else if (referenceInfo2.resourceID != null) {
                        final String jndiName2 = "openejb/Resource/" + referenceInfo2.resourceID;
                        reference2 = new IntraVmJndiReference(jndiName2);
                    }
                    else {
                        final String jndiName2 = "openejb/Resource/" + referenceInfo2.referenceName;
                        reference2 = new IntraVmJndiReference(jndiName2);
                    }
                    bindings.put(this.normalize(referenceInfo2.referenceName), reference2);
                }
            }
            else {
                final Class<?> type2 = (Class<?>)this.getType(referenceInfo2.referenceType, referenceInfo2);
                Object reference2;
                if (Request.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.REQUEST);
                }
                else if (HttpServletRequest.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.HTTP_SERVLET_REQUEST);
                }
                else if (ServletRequest.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.SERVLET_REQUEST);
                }
                else if (UriInfo.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.URI_INFO);
                }
                else if (HttpHeaders.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.HTTP_HEADERS);
                }
                else if (SecurityContext.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.SECURITY_CONTEXT);
                }
                else if (ContextResolver.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.CONTEXT_RESOLVER);
                }
                else if (Providers.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.PROVIDERS);
                }
                else if (ServletConfig.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.SERVLET_CONFIG);
                }
                else if (ServletContext.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.SERVLET_CONTEXT);
                }
                else if (HttpServletResponse.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.HTTP_SERVLET_RESPONSE);
                }
                else if (ResourceInfo.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.RESOURCE_INFO);
                }
                else if (ResourceContext.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.RESOURCE_CONTEXT);
                }
                else if (Configuration.class.equals(type2)) {
                    reference2 = new ObjectReference(ThreadLocalContextManager.CONFIGURATION);
                }
                else {
                    reference2 = new MapObjectReference(ThreadLocalContextManager.OTHERS, referenceInfo2.referenceType);
                }
                bindings.put(this.normalize(referenceInfo2.referenceName), reference2);
            }
        }
        for (final ResourceEnvReferenceInfo referenceInfo3 : this.jndiEnc.resourceEnvRefs) {
            if (referenceInfo3.location != null) {
                final Reference reference = this.buildReferenceLocation(referenceInfo3.location);
                bindings.put(this.normalize(referenceInfo3.referenceName), reference);
            }
            else {
                final Class<?> type2 = (Class<?>)this.getType(referenceInfo3.resourceEnvRefType, referenceInfo3);
                Object reference2;
                if (EJBContext.class.isAssignableFrom(type2)) {
                    final String jndiName2 = "comp/EJBContext";
                    reference2 = new LinkRef("comp/EJBContext");
                    if ("comp/EJBContext".equals(referenceInfo3.referenceName)) {
                        continue;
                    }
                }
                else if (Validator.class.equals(type2)) {
                    final String jndiName2 = "comp/Validator";
                    reference2 = new LinkRef("comp/Validator");
                }
                else if (ValidatorFactory.class.equals(type2)) {
                    final String jndiName2 = "comp/ValidatorFactory";
                    reference2 = new LinkRef("comp/ValidatorFactory");
                }
                else if (WebServiceContext.class.equals(type2)) {
                    final String jndiName2 = "comp/WebServiceContext";
                    reference2 = new LinkRef("comp/WebServiceContext");
                }
                else if (TimerService.class.equals(type2)) {
                    final String jndiName2 = "comp/TimerService";
                    reference2 = new LinkRef("comp/TimerService");
                }
                else if (BeanManager.class.equals(type2)) {
                    reference2 = new LazyObjectReference((Callable<Object>)new Callable<BeanManager>() {
                        @Override
                        public BeanManager call() throws Exception {
                            return (BeanManager)new InjectableBeanManager(WebBeansContext.currentInstance().getBeanManagerImpl());
                        }
                    });
                }
                else if (UserTransaction.class.equals(type2)) {
                    reference2 = new IntraVmJndiReference("comp/UserTransaction");
                }
                else if (referenceInfo3.resourceID != null) {
                    final String jndiName2 = "openejb/Resource/" + referenceInfo3.resourceID;
                    reference2 = new IntraVmJndiReference(jndiName2);
                }
                else {
                    final String jndiName2 = "openejb/Resource/" + referenceInfo3.referenceName;
                    reference2 = new IntraVmJndiReference(jndiName2);
                }
                bindings.put(this.normalize(referenceInfo3.referenceName), reference2);
            }
        }
        for (final PersistenceUnitReferenceInfo referenceInfo4 : this.jndiEnc.persistenceUnitRefs) {
            if (referenceInfo4.location != null) {
                final Reference reference = this.buildReferenceLocation(referenceInfo4.location);
                bindings.put(this.normalize(referenceInfo4.referenceName), reference);
            }
            else {
                final String jndiName3 = PersistenceBuilder.getOpenEJBJndiName(referenceInfo4.unitId);
                final Reference reference3 = new IntraVmJndiReference(jndiName3);
                bindings.put(this.normalize(referenceInfo4.referenceName), reference3);
            }
        }
        for (final PersistenceContextReferenceInfo contextInfo : this.jndiEnc.persistenceContextRefs) {
            if (contextInfo.location != null) {
                final Reference reference = this.buildReferenceLocation(contextInfo.location);
                bindings.put(this.normalize(contextInfo.referenceName), reference);
            }
            else {
                final Context context = ((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext();
                EntityManagerFactory factory;
                try {
                    final String jndiName2 = PersistenceBuilder.getOpenEJBJndiName(contextInfo.unitId);
                    factory = (EntityManagerFactory)context.lookup(jndiName2);
                }
                catch (NamingException e6) {
                    throw new OpenEJBException("PersistenceUnit '" + contextInfo.unitId + "' not found for EXTENDED ref '" + contextInfo.referenceName + "'");
                }
                final JtaEntityManager jtaEntityManager = new JtaEntityManager(contextInfo.persistenceUnitName, jtaEntityManagerRegistry, factory, contextInfo.properties, contextInfo.extended, contextInfo.synchronizationType);
                final Reference reference4 = new PersistenceContextReference((EntityManager)jtaEntityManager);
                bindings.put(this.normalize(contextInfo.referenceName), reference4);
            }
        }
        for (final ServiceReferenceInfo referenceInfo5 : this.jndiEnc.serviceRefs) {
            if (referenceInfo5.location != null) {
                final Reference reference = this.buildReferenceLocation(referenceInfo5.location);
                bindings.put(this.normalize(referenceInfo5.referenceName), reference);
            }
            else {
                Class<? extends Service> serviceClass = Service.class;
                if (referenceInfo5.serviceType != null) {
                    try {
                        serviceClass = this.classLoader.loadClass(referenceInfo5.serviceType).asSubclass(Service.class);
                    }
                    catch (Exception e3) {
                        throw new OpenEJBException("Could not load service type class " + referenceInfo5.serviceType, e3);
                    }
                }
                Class<?> referenceClass = null;
                if (referenceInfo5.referenceType != null) {
                    try {
                        referenceClass = this.classLoader.loadClass(referenceInfo5.referenceType);
                    }
                    catch (Exception e4) {
                        throw new OpenEJBException("Could not load reference type class " + referenceInfo5.referenceType, e4);
                    }
                }
                if (referenceClass != null && Service.class.isAssignableFrom(referenceClass)) {
                    serviceClass = referenceClass.asSubclass(Service.class);
                }
                URL wsdlUrl = null;
                if (referenceInfo5.wsdlFile != null) {
                    try {
                        wsdlUrl = new URL(referenceInfo5.wsdlFile);
                    }
                    catch (MalformedURLException e5) {
                        wsdlUrl = this.classLoader.getResource(referenceInfo5.wsdlFile);
                        if (wsdlUrl == null) {
                            JndiEncBuilder.logger.warning("Error obtaining WSDL: " + referenceInfo5.wsdlFile, e5);
                        }
                    }
                }
                final List<PortRefData> portRefs = new ArrayList<PortRefData>(referenceInfo5.portRefs.size());
                for (final PortRefInfo portRefInfo : referenceInfo5.portRefs) {
                    final PortRefData portRef = new PortRefData();
                    portRef.setQName(portRefInfo.qname);
                    portRef.setServiceEndpointInterface(portRefInfo.serviceEndpointInterface);
                    portRef.setEnableMtom(portRefInfo.enableMtom);
                    portRef.getProperties().putAll(portRefInfo.properties);
                    portRefs.add(portRef);
                }
                List<HandlerChainData> handlerChains = null;
                if (!referenceInfo5.handlerChains.isEmpty()) {
                    handlerChains = WsBuilder.toHandlerChainData(referenceInfo5.handlerChains, this.classLoader);
                }
                if (!this.client) {
                    final Reference reference5 = new JaxWsServiceReference(referenceInfo5.id, referenceInfo5.serviceQName, serviceClass, referenceInfo5.portQName, referenceClass, wsdlUrl, portRefs, handlerChains, this.injections, this.properties);
                    bindings.put(this.normalize(referenceInfo5.referenceName), reference5);
                }
                else {
                    final ServiceRefData serviceRefData = new ServiceRefData(referenceInfo5.id, referenceInfo5.serviceQName, serviceClass, referenceInfo5.portQName, referenceClass, wsdlUrl, handlerChains, portRefs);
                    bindings.put(this.normalize(referenceInfo5.referenceName), serviceRefData);
                }
            }
        }
        final OpenEjbConfiguration config = (OpenEjbConfiguration)SystemInstance.get().getComponent((Class)OpenEjbConfiguration.class);
        if (config != null) {
            for (final org.apache.openejb.assembler.classic.ResourceInfo resource : config.facilities.resources) {
                final String jndiName = resource.jndiName;
                if (jndiName != null && !jndiName.isEmpty() && this.isNotGobalOrIsHoldByThisApp(resource, scope)) {
                    final String refName = "openejb/Resource/" + resource.id;
                    final Object reference6 = new IntraVmJndiReference(refName);
                    final String boundName = this.normalize(jndiName);
                    bindings.put(boundName, reference6);
                }
            }
        }
        return bindings;
    }
    
    private boolean isNotGobalOrIsHoldByThisApp(final org.apache.openejb.assembler.classic.ResourceInfo info, final JndiScope scope) {
        return !info.jndiName.startsWith("global/") || (info.originAppName != null && info.originAppName.equals(this.moduleId) && JndiScope.global.equals(scope));
    }
    
    private void addSpecialCompBindings(final Map<String, Object> bindings) {
        final TransactionManager transactionManager = (TransactionManager)SystemInstance.get().getComponent((Class)TransactionManager.class);
        bindings.put("comp/TransactionManager", transactionManager);
        bindings.put("comp/TransactionSynchronizationRegistry", new TransactionSynchronizationRegistryWrapper());
        try {
            bindings.put("comp/ORB", new SystemComponentReference(ParentClassLoaderFinder.Helper.get().loadClass("org.omg.CORBA.ORB")));
        }
        catch (NoClassDefFoundError noClassDefFoundError) {}
        catch (ClassNotFoundException ex) {}
        bindings.put("comp/HandleDelegate", new SystemComponentReference(HandleDelegate.class));
        bindings.put("comp/ValidatorFactory", new IntraVmJndiReference("openejb/ValidatorFactory/" + this.uniqueId));
        bindings.put("comp/Validator", new IntraVmJndiReference("openejb/Validator/" + this.uniqueId));
        if (this.beanManagedTransactions) {
            final UserTransaction userTransaction = (UserTransaction)new CoreUserTransaction(transactionManager);
            bindings.put("comp/UserTransaction", userTransaction);
        }
    }
    
    private void addSpecialModuleBindings(final Map<String, Object> bindings) {
        if (this.moduleId != null) {
            bindings.put("module/ModuleName", this.moduleId);
        }
        if (bindings.isEmpty()) {
            bindings.put("module/dummy", "dummy");
        }
    }
    
    private void addSpecialAppBindings(final Map<String, Object> bindings) {
        if (this.moduleId != null) {
            bindings.put("app/AppName", this.moduleId);
        }
        if (bindings.isEmpty()) {
            bindings.put("app/dummy", "dummy");
        }
    }
    
    private void addSpecialGlobalBindings(final Map<String, Object> bindings) {
        if (bindings.isEmpty()) {
            bindings.put("global/dummy", "dummy");
        }
    }
    
    public static boolean bindingExists(final Context context, final Name contextName) {
        try {
            return context.lookup(contextName) != null;
        }
        catch (NamingException ex) {
            return false;
        }
    }
    
    private Reference buildReferenceLocation(final ReferenceLocationInfo location) {
        if (location.jndiProviderId != null) {
            final String subContextName = "openejb/remote_jndi_contexts/" + location.jndiProviderId;
            return new JndiReference(subContextName, location.jndiName);
        }
        return new JndiUrlReference(location.jndiName);
    }
    
    private String normalize(final String name) {
        return name;
    }
    
    private Class getType(final String type, final InjectableInfo injectable) throws OpenEJBException {
        if (type != null) {
            try {
                return this.classLoader.loadClass(type.trim());
            }
            catch (ClassNotFoundException e) {
                throw new OpenEJBException("Unable to load type '" + type + "' for " + injectable.referenceName);
            }
        }
        return this.inferType(injectable);
    }
    
    private Class inferType(final InjectableInfo injectable) throws OpenEJBException {
        for (final InjectionInfo injection : injectable.targets) {
            try {
                final Class<?> target = this.classLoader.loadClass(injection.className.trim());
                return IntrospectionSupport.getPropertyType(target, injection.propertyName.trim());
            }
            catch (ClassNotFoundException | NoSuchFieldException ex) {
                continue;
            }
            break;
        }
        throw new OpenEJBException("Unable to infer type for " + injectable.referenceName);
    }
    
    static {
        logger = Logger.getInstance(LogCategory.OPENEJB_STARTUP, JndiEncBuilder.class.getPackage().getName());
    }
    
    public enum JndiScope
    {
        comp, 
        module, 
        app, 
        global;
    }
    
    private static class Ref implements EjbResolver.Reference, Serializable
    {
        private final EjbReferenceInfo info;
        
        public Ref(final EjbReferenceInfo info) {
            this.info = info;
        }
        
        @Override
        public String getEjbLink() {
            return this.info.link;
        }
        
        @Override
        public String getHome() {
            return this.info.homeClassName;
        }
        
        @Override
        public String getInterface() {
            return this.info.interfaceClassName;
        }
        
        @Override
        public String getMappedName() {
            return null;
        }
        
        @Override
        public String getName() {
            return this.info.referenceName;
        }
        
        @Override
        public EjbResolver.Type getRefType() {
            if (this.info instanceof EjbLocalReferenceInfo) {
                return EjbResolver.Type.LOCAL;
            }
            if (this.info.homeClassName != null) {
                return EjbResolver.Type.REMOTE;
            }
            return EjbResolver.Type.UNKNOWN;
        }
    }
}
