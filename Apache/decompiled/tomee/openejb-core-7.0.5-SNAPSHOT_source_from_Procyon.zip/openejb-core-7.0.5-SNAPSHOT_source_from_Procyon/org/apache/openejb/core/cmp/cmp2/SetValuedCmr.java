// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp.cmp2;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collection;
import javax.ejb.EJBException;
import java.util.Set;
import org.apache.openejb.loader.SystemInstance;
import javax.transaction.TransactionSynchronizationRegistry;
import org.apache.openejb.BeanContext;
import javax.ejb.EJBLocalObject;
import javax.ejb.EntityBean;

public class SetValuedCmr<Bean extends EntityBean, Proxy extends EJBLocalObject>
{
    private final EntityBean source;
    private final String sourceProperty;
    private final String relatedProperty;
    private final BeanContext relatedInfo;
    private final TransactionSynchronizationRegistry transactionRegistry;
    
    public SetValuedCmr(final EntityBean source, final String sourceProperty, final Class<Bean> relatedType, final String relatedProperty) {
        if (source == null) {
            throw new NullPointerException("source is null");
        }
        if (relatedType == null) {
            throw new NullPointerException("relatedType is null");
        }
        this.source = source;
        this.sourceProperty = sourceProperty;
        this.relatedProperty = relatedProperty;
        this.relatedInfo = Cmp2Util.getBeanContext(relatedType);
        this.transactionRegistry = (TransactionSynchronizationRegistry)SystemInstance.get().getComponent((Class)TransactionSynchronizationRegistry.class);
    }
    
    public Set<Proxy> get(final Set<Bean> others) {
        if (this.sourceProperty == null) {
            throw new EJBException("Internal error: this container managed relationship is unidirectional and, this entity does not have a cmr field for the relationship");
        }
        if (others == null) {
            throw new NullPointerException("others is null");
        }
        CmrSet<Bean, Proxy> cmrSet = null;
        try {
            cmrSet = (CmrSet<Bean, Proxy>)this.transactionRegistry.getResource((Object)this);
        }
        catch (IllegalStateException ex) {}
        if (cmrSet == null) {
            cmrSet = new CmrSet<Bean, Proxy>(this.source, this.sourceProperty, this.relatedInfo, this.relatedProperty, others);
            try {
                this.transactionRegistry.putResource((Object)this, (Object)cmrSet);
            }
            catch (IllegalStateException ex2) {}
        }
        return (Set<Proxy>)cmrSet;
    }
    
    public void set(final Set<Bean> relatedBeans, final Collection newProxies) {
        if (this.sourceProperty == null) {
            throw new EJBException("Internal error: this container managed relationship is unidirectional and, this entity does not have a cmr field for the relationship");
        }
        if (newProxies == null) {
            throw new IllegalArgumentException("null can not be set into a collection-valued cmr-field");
        }
        if (this.relatedProperty != null) {
            for (final Bean oldBean : relatedBeans) {
                if (oldBean != null) {
                    this.toCmp2Entity(oldBean).OpenEJB_removeCmr(this.relatedProperty, this.source);
                }
            }
        }
        relatedBeans.clear();
        for (final Proxy newProxy : new ArrayList(newProxies)) {
            final Bean newBean = Cmp2Util.getEntityBean(newProxy);
            if (newProxy != null) {
                Object oldBackRef = null;
                if (this.relatedProperty != null) {
                    oldBackRef = this.toCmp2Entity(newBean).OpenEJB_addCmr(this.relatedProperty, this.source);
                }
                relatedBeans.add(newBean);
                if (this.relatedProperty == null || oldBackRef == null) {
                    continue;
                }
                this.toCmp2Entity(oldBackRef).OpenEJB_removeCmr(this.sourceProperty, newBean);
            }
        }
    }
    
    public void deleted(final Set<Bean> relatedBeans) {
        final CmrSet<Bean, Proxy> cmrSet = (CmrSet<Bean, Proxy>)this.transactionRegistry.getResource((Object)this);
        if (cmrSet != null) {
            this.transactionRegistry.putResource((Object)this, (Object)null);
            cmrSet.entityDeleted();
        }
        if (this.relatedProperty != null) {
            for (final Bean oldBean : relatedBeans) {
                if (oldBean != null) {
                    this.toCmp2Entity(oldBean).OpenEJB_removeCmr(this.relatedProperty, this.source);
                }
            }
        }
    }
    
    private Cmp2Entity toCmp2Entity(final Object object) {
        return (Cmp2Entity)object;
    }
}
