// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.util.Set;
import org.apache.openejb.OpenEJBException;
import javax.xml.namespace.QName;

public interface PortAddressRegistry
{
    void addPort(final String p0, final QName p1, final String p2, final QName p3, final String p4, final String p5) throws OpenEJBException;
    
    void removePort(final String p0, final QName p1, final String p2, final String p3);
    
    Set<PortAddress> getPorts(final String p0, final QName p1, final String p2);
}
