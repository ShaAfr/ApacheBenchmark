// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import java.util.concurrent.CopyOnWriteArrayList;
import org.apache.openejb.util.LogCategory;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.openejb.core.transaction.TransactionPolicy;
import java.util.Map;
import org.apache.openejb.BeanContext;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.List;
import org.apache.openejb.util.Logger;

public class ThreadContext
{
    private static final Logger log;
    private static final ThreadLocal<ThreadContext> threadStorage;
    private static final List<ThreadContextListener> listeners;
    private static final ThreadLocal<AtomicBoolean> asynchronousCancelled;
    private final BeanContext beanContext;
    private final Object primaryKey;
    private final Map<Class, Object> data;
    private ClassLoader oldClassLoader;
    private Operation currentOperation;
    private Class invokedInterface;
    private TransactionPolicy transactionPolicy;
    private boolean discardInstance;
    
    public static ThreadContext getThreadContext() {
        return ThreadContext.threadStorage.get();
    }
    
    public static ThreadContext enter(final ThreadContext newContext) {
        if (newContext == null) {
            throw new NullPointerException("newContext is null");
        }
        final Thread thread = Thread.currentThread();
        newContext.oldClassLoader = thread.getContextClassLoader();
        thread.setContextClassLoader(newContext.beanContext.getClassLoader());
        final ThreadContext oldContext = ThreadContext.threadStorage.get();
        ThreadContext.threadStorage.set(newContext);
        for (final ThreadContextListener listener : ThreadContext.listeners) {
            try {
                listener.contextEntered(oldContext, newContext);
            }
            catch (Throwable e) {
                ThreadContext.log.warning("ThreadContextListener threw an exception", e);
            }
        }
        return oldContext;
    }
    
    public static void exit(final ThreadContext oldContext) {
        final ThreadContext exitingContext = ThreadContext.threadStorage.get();
        if (exitingContext == null) {
            throw new IllegalStateException("No existing context");
        }
        Thread.currentThread().setContextClassLoader(exitingContext.oldClassLoader);
        exitingContext.oldClassLoader = null;
        ThreadContext.threadStorage.set(oldContext);
        for (final ThreadContextListener listener : ThreadContext.listeners) {
            try {
                listener.contextExited(exitingContext, oldContext);
            }
            catch (Throwable e) {
                ThreadContext.log.debug("ThreadContextListener threw an exception", e);
            }
        }
    }
    
    public static void initAsynchronousCancelled(final AtomicBoolean initializeValue) {
        ThreadContext.asynchronousCancelled.set(initializeValue);
    }
    
    public static boolean isAsynchronousCancelled() {
        return ThreadContext.asynchronousCancelled.get().get();
    }
    
    public static void removeAsynchronousCancelled() {
        ThreadContext.asynchronousCancelled.remove();
    }
    
    public static void addThreadContextListener(final ThreadContextListener listener) {
        ThreadContext.listeners.add(listener);
    }
    
    public static void removeThreadContextListener(final ThreadContextListener listener) {
        ThreadContext.listeners.remove(listener);
    }
    
    public ThreadContext(final BeanContext beanContext, final Object primaryKey) {
        this(beanContext, primaryKey, null);
    }
    
    public ThreadContext(final BeanContext beanContext, final Object primaryKey, final Operation operation) {
        this.data = (Map<Class, Object>)Collections.synchronizedMap(new HashMap<Class, Object>());
        if (beanContext == null) {
            throw new NullPointerException("deploymentInfo is null");
        }
        this.beanContext = beanContext;
        this.primaryKey = primaryKey;
        this.currentOperation = operation;
    }
    
    public ThreadContext(final ThreadContext that) {
        this.data = (Map<Class, Object>)Collections.synchronizedMap(new HashMap<Class, Object>());
        this.beanContext = that.beanContext;
        this.primaryKey = that.primaryKey;
        this.data.putAll(that.data);
        this.oldClassLoader = that.oldClassLoader;
    }
    
    public BeanContext getBeanContext() {
        return this.beanContext;
    }
    
    public Object getPrimaryKey() {
        return this.primaryKey;
    }
    
    public Operation getCurrentOperation() {
        return this.currentOperation;
    }
    
    public void setCurrentOperation(final Operation operation) {
        this.currentOperation = operation;
    }
    
    public Class getInvokedInterface() {
        return this.invokedInterface;
    }
    
    public void setInvokedInterface(final Class invokedInterface) {
        this.invokedInterface = invokedInterface;
    }
    
    public TransactionPolicy getTransactionPolicy() {
        return this.transactionPolicy;
    }
    
    public void setTransactionPolicy(final TransactionPolicy transactionPolicy) {
        this.transactionPolicy = transactionPolicy;
    }
    
    public BaseContext.State[] getCurrentAllowedStates() {
        return null;
    }
    
    public BaseContext.State[] setCurrentAllowedStates(final BaseContext.State[] newAllowedStates) {
        return null;
    }
    
    public <T> T get(final Class<T> type) {
        return (T)this.data.get(type);
    }
    
    public <T> T set(final Class<T> type, final T value) {
        return (T)this.data.put(type, value);
    }
    
    public <T> T remove(final Class<T> type) {
        return (T)this.data.remove(type);
    }
    
    public boolean isDiscardInstance() {
        return this.discardInstance;
    }
    
    public void setDiscardInstance(final boolean discardInstance) {
        this.discardInstance = discardInstance;
    }
    
    @Override
    public String toString() {
        return "ThreadContext{beanContext=" + this.beanContext.getId() + ", primaryKey=" + this.primaryKey + ", data=" + this.data.size() + ", oldClassLoader=" + this.oldClassLoader + ", currentOperation=" + this.currentOperation + ", invokedInterface=" + this.invokedInterface + ", transactionPolicy=" + this.transactionPolicy + ", discardInstance=" + this.discardInstance + '}';
    }
    
    static {
        log = Logger.getInstance(LogCategory.OPENEJB, "org.apache.openejb.util.resources");
        threadStorage = new ThreadLocal<ThreadContext>();
        listeners = new CopyOnWriteArrayList<ThreadContextListener>();
        asynchronousCancelled = new ThreadLocal<AtomicBoolean>();
    }
}
