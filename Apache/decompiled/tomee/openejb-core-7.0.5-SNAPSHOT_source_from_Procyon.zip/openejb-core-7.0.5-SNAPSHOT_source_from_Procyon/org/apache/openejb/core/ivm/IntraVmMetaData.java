// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

import java.io.ObjectStreamException;
import org.apache.openejb.spi.ApplicationServer;
import org.apache.openejb.core.ServerFederation;
import org.apache.openejb.util.proxy.ProxyManager;
import org.apache.openejb.BeanType;
import javax.ejb.EJBHome;
import java.io.Serializable;
import javax.ejb.EJBMetaData;

public class IntraVmMetaData implements EJBMetaData, Serializable
{
    protected Class homeClass;
    protected Class remoteClass;
    protected Class keyClass;
    protected EJBHome homeStub;
    protected BeanType type;
    
    public IntraVmMetaData(final Class homeInterface, final Class remoteInterface, final BeanType typeOfBean) {
        this(homeInterface, remoteInterface, null, typeOfBean);
    }
    
    public IntraVmMetaData(final Class homeInterface, final Class remoteInterface, final Class primaryKeyClass, final BeanType typeOfBean) {
        this.type = typeOfBean;
        if (homeInterface == null || remoteInterface == null) {
            throw new IllegalArgumentException();
        }
        if (typeOfBean.isEntity() && primaryKeyClass == null) {
            throw new IllegalArgumentException("Entity beans must have a primary key class");
        }
        this.type = typeOfBean;
        this.homeClass = homeInterface;
        this.remoteClass = remoteInterface;
        this.keyClass = primaryKeyClass;
    }
    
    public Class getHomeInterfaceClass() {
        return this.homeClass;
    }
    
    public Class getRemoteInterfaceClass() {
        return this.remoteClass;
    }
    
    public Class getPrimaryKeyClass() {
        if (this.type.isEntity()) {
            return this.keyClass;
        }
        throw new UnsupportedOperationException("Session objects are private resources and do not have primary keys");
    }
    
    public boolean isSession() {
        return this.type.isSession();
    }
    
    public boolean isStatelessSession() {
        return this.type == BeanType.STATELESS;
    }
    
    public boolean isSingletonSession() {
        return this.type == BeanType.SINGLETON;
    }
    
    public boolean isManagedSession() {
        return this.type == BeanType.MANAGED;
    }
    
    public boolean isStatefulSession() {
        return this.type == BeanType.STATEFUL;
    }
    
    public void setEJBHome(final EJBHome home) {
        this.homeStub = home;
    }
    
    public EJBHome getEJBHome() {
        return this.homeStub;
    }
    
    protected Object writeReplace() throws ObjectStreamException {
        if (IntraVmCopyMonitor.isIntraVmCopyOperation()) {
            return new IntraVmArtifact(this);
        }
        if (IntraVmCopyMonitor.isStatefulPassivationOperation()) {
            return this;
        }
        if (IntraVmCopyMonitor.isCrossClassLoaderOperation()) {
            return this;
        }
        final BaseEjbProxyHandler handler = (BaseEjbProxyHandler)ProxyManager.getInvocationHandler(this.homeStub);
        final ApplicationServer applicationServer = ServerFederation.getApplicationServer();
        return applicationServer.getEJBMetaData(handler.getProxyInfo());
    }
}
