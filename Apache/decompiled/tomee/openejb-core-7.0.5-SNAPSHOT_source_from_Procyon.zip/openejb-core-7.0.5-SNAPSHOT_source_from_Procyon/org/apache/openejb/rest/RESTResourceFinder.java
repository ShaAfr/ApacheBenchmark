// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

public interface RESTResourceFinder
{
     <T> T find(final Class<T> p0);
}
