// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cipher;

public abstract class SafePasswordCipherBase implements SafePasswordCipher
{
    @Override
    public String decrypt(final char[] encryptedPassword) {
        throw new UnsupportedOperationException(this.getClass().getName() + " doesn't support String decryption");
    }
}
