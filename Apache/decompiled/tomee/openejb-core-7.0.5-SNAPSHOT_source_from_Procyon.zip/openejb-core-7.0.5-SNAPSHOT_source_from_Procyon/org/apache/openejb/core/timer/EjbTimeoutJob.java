// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import org.apache.openejb.quartz.JobExecutionException;
import org.apache.openejb.quartz.JobDataMap;
import org.apache.openejb.quartz.JobExecutionContext;
import org.apache.openejb.quartz.Job;

public class EjbTimeoutJob implements Job
{
    public static final String EJB_TIMERS_SERVICE = "EJB_TIMERS_SERVICE";
    public static final String TIMER_DATA = "TIMER_DATA";
    
    public void execute(final JobExecutionContext jobExecutionContext) throws JobExecutionException {
        final JobDataMap jobDataMap = jobExecutionContext.getMergedJobDataMap();
        final EjbTimerServiceImpl ejbTimerService = (EjbTimerServiceImpl)jobDataMap.get((Object)"EJB_TIMERS_SERVICE");
        final TimerData timerData = (TimerData)jobDataMap.get((Object)"TIMER_DATA");
        ejbTimerService.ejbTimeout(timerData);
    }
}
