// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb;

import java.util.Collection;
import org.apache.openejb.api.LocalClient;
import java.util.List;
import javax.naming.NamingException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.naming.Context;

public final class ClientInjections
{
    private ClientInjections() {
    }
    
    public static InjectionProcessor<?> clientInjector(final Object object) throws OpenEJBException {
        if (object == null) {
            throw new NullPointerException("Object supplied to 'inject' operation is null");
        }
        Context clients;
        try {
            clients = (Context)((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext().lookup("openejb/client/");
        }
        catch (NamingException e) {
            throw new OpenEJBException(object.getClass().getName(), e);
        }
        Context ctx = null;
        List<Injection> injections = null;
        Class<?> current = object.getClass();
        while (current != null && !current.equals(Object.class)) {
            try {
                final String moduleId = (String)clients.lookup(current.getName());
                ctx = (Context)clients.lookup(moduleId);
                injections = (List<Injection>)ctx.lookup("info/injections");
            }
            catch (NamingException e2) {
                current = current.getSuperclass();
                continue;
            }
            break;
        }
        if (injections == null) {
            throw new OpenEJBException("Unable to find injection meta-data for " + object.getClass().getName() + ".  Ensure that class was annotated with @" + LocalClient.class.getName() + " and was successfully discovered and deployed.  See http://tomee.apache.org/3.0/local-client-injection.html");
        }
        return new InjectionProcessor<Object>(object, injections, ctx);
    }
}
