// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import java.util.Map;
import java.util.Properties;
import javax.naming.NamingException;
import org.apache.openejb.spi.ContainerSystem;
import javax.security.auth.login.LoginException;
import javax.naming.AuthenticationException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.OpenEJB;
import javax.naming.Context;
import java.util.Hashtable;
import javax.naming.spi.InitialContextFactory;

@Deprecated
public class InitContextFactory implements InitialContextFactory
{
    @Override
    public Context getInitialContext(final Hashtable env) throws NamingException {
        if (!OpenEJB.isInitialized()) {
            this.initializeOpenEJB(env);
        }
        final String user = env.get("java.naming.security.principal");
        final String pass = env.get("java.naming.security.credentials");
        final String realmName = env.get("openejb.authentication.realmName");
        if (user != null && pass != null) {
            try {
                final SecurityService securityService = (SecurityService)SystemInstance.get().getComponent((Class)SecurityService.class);
                Object identity;
                if (realmName == null) {
                    identity = securityService.login(user, pass);
                }
                else {
                    identity = securityService.login(realmName, user, pass);
                }
                securityService.associate(identity);
            }
            catch (LoginException e) {
                throw (AuthenticationException)new AuthenticationException("User could not be authenticated: " + user).initCause(e);
            }
        }
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        Context context = containerSystem.getJNDIContext();
        context = (Context)context.lookup("openejb/local");
        return context;
    }
    
    private void initializeOpenEJB(final Hashtable env) throws NamingException {
        try {
            final Properties props = new Properties();
            props.put("org/openejb/assembler_class", "org.apache.openejb.assembler.classic.Assembler");
            props.put("org/openejb/configuration_factory", "org.apache.openejb.config.ConfigurationFactory");
            props.put("org/openejb/configuration_source", "conf/default.openejb.conf");
            props.putAll(SystemInstance.get().getProperties());
            props.putAll(env);
            OpenEJB.init(props);
        }
        catch (Exception e) {
            throw new org.apache.openejb.core.ivm.naming.NamingException("Cannot initailize OpenEJB", e);
        }
    }
}
