// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.Properties;
import java.util.List;

public class PersistenceUnitInfo extends InfoObject
{
    public String id;
    public String name;
    public String provider;
    public String transactionType;
    public String jtaDataSource;
    public String nonJtaDataSource;
    public final List<String> mappingFiles;
    public final List<String> jarFiles;
    public final List<String> classes;
    public boolean excludeUnlistedClasses;
    public final Properties properties;
    public String persistenceUnitRootUrl;
    public final Set<String> watchedResources;
    public String persistenceXMLSchemaVersion;
    public String sharedCacheMode;
    public String validationMode;
    public String webappName;
    
    public PersistenceUnitInfo() {
        this.mappingFiles = new ArrayList<String>();
        this.jarFiles = new ArrayList<String>();
        this.classes = new ArrayList<String>();
        this.properties = new Properties();
        this.watchedResources = new TreeSet<String>();
    }
}
