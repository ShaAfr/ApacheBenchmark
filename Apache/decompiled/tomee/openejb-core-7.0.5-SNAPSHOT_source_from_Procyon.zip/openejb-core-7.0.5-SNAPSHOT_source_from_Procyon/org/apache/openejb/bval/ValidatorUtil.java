// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.bval;

import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.Iterator;
import org.apache.openejb.core.WebContext;
import javax.naming.NameNotFoundException;
import org.apache.openejb.BeanContext;
import java.util.ArrayList;
import org.apache.openejb.AppContext;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import org.apache.openejb.core.ThreadContext;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationHandler;
import javax.validation.Validator;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.validation.ValidatorFactory;

public final class ValidatorUtil
{
    private ValidatorUtil() {
    }
    
    public static ValidatorFactory validatorFactory() {
        try {
            return lookupFactory();
        }
        catch (NamingException e) {
            return tryJndiLaterFactory();
        }
    }
    
    public static ValidatorFactory lookupFactory() throws NamingException {
        return (ValidatorFactory)new InitialContext().lookup("java:comp/ValidatorFactory");
    }
    
    public static ValidatorFactory tryJndiLaterFactory() {
        return proxy(ValidatorFactory.class, "java:comp/ValidatorFactory");
    }
    
    public static Validator validator() {
        try {
            return (Validator)new InitialContext().lookup("java:comp/Validator");
        }
        catch (NamingException e) {
            return proxy(Validator.class, "java:comp/Validator");
        }
    }
    
    private static <T> T proxy(final Class<T> t, final String jndi) {
        return t.cast(Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class[] { t }, new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
                if (Object.class.equals(method.getDeclaringClass())) {
                    return method.invoke(this, new Object[0]);
                }
                final ThreadContext ctx = ThreadContext.getThreadContext();
                if (ctx != null) {
                    return method.invoke(ctx.getBeanContext().getJndiContext().lookup(jndi), args);
                }
                final ClassLoader tccl = Thread.currentThread().getContextClassLoader();
                if (tccl == null) {
                    return null;
                }
                final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
                Object value = null;
                for (final AppContext appContext : containerSystem.getAppContexts()) {
                    final ClassLoader appContextClassLoader = appContext.getClassLoader();
                    if (tccl.equals(appContextClassLoader) || appContextClassLoader.equals(tccl)) {
                        final Collection<String> tested = new ArrayList<String>();
                        for (final BeanContext bean : appContext.getBeanContexts()) {
                            if (BeanContext.Comp.class.equals(bean.getBeanClass())) {
                                final String uniqueId = bean.getModuleContext().getUniqueId();
                                if (tested.contains(uniqueId)) {
                                    continue;
                                }
                                tested.add(uniqueId);
                                try {
                                    value = containerSystem.getJNDIContext().lookup((jndi.endsWith("Factory") ? "openejb/ValidatorFactory/" : "openejb/Validator/") + uniqueId);
                                    break;
                                }
                                catch (NameNotFoundException ex) {}
                            }
                        }
                        if (ClassLoader.getSystemClassLoader() != appContextClassLoader) {
                            break;
                        }
                    }
                    for (final WebContext web : appContext.getWebContexts()) {
                        final ClassLoader webClassLoader = web.getClassLoader();
                        if (webClassLoader.equals(tccl) || tccl.equals(webClassLoader)) {
                            value = web.getJndiEnc().lookup(jndi);
                            break;
                        }
                    }
                    if (value != null) {
                        break;
                    }
                }
                if (value != null) {
                    return method.invoke(value, args);
                }
                return null;
            }
            
            @Override
            public String toString() {
                return "Proxy::" + t.getName();
            }
        }));
    }
}
