// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.TreeSet;
import java.util.List;
import java.util.Set;

public class WebAppInfo extends CommonInfoObject
{
    public String path;
    public String description;
    public String displayName;
    public String smallIcon;
    public String largeIcon;
    public String moduleId;
    public String host;
    public String contextRoot;
    public int sessionTimeout;
    public final Set<String> watchedResources;
    public final Set<String> restClass;
    public final Set<String> restApplications;
    public final Set<String> ejbWebServices;
    public final Set<String> ejbRestServices;
    public final Set<ClassListInfo> webAnnotatedClasses;
    public final List<PortInfo> portInfos;
    public final JndiEncInfo jndiEnc;
    public final List<ServletInfo> servlets;
    public final List<ClassListInfo> jsfAnnotatedClasses;
    public final Set<String> jaxRsProviders;
    public final List<ListenerInfo> listeners;
    public final List<FilterInfo> filters;
    
    public WebAppInfo() {
        this.watchedResources = new TreeSet<String>();
        this.restClass = new TreeSet<String>();
        this.restApplications = new TreeSet<String>();
        this.ejbWebServices = new TreeSet<String>();
        this.ejbRestServices = new TreeSet<String>();
        this.webAnnotatedClasses = new LinkedHashSet<ClassListInfo>();
        this.portInfos = new ArrayList<PortInfo>();
        this.jndiEnc = new JndiEncInfo();
        this.servlets = new ArrayList<ServletInfo>();
        this.jsfAnnotatedClasses = new ArrayList<ClassListInfo>();
        this.jaxRsProviders = new TreeSet<String>();
        this.listeners = new ArrayList<ListenerInfo>();
        this.filters = new ArrayList<FilterInfo>();
    }
}
