// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm;

public final class IntraVmCopyMonitor
{
    private static final ThreadLocal<IntraVmCopyMonitor> threadMonitor;
    private State state;
    
    private IntraVmCopyMonitor() {
        this.state = State.NONE;
    }
    
    public static boolean exists() {
        return IntraVmCopyMonitor.threadMonitor.get() != null;
    }
    
    public static void release() {
        IntraVmCopyMonitor.threadMonitor.set(null);
    }
    
    private static IntraVmCopyMonitor getMonitor() {
        IntraVmCopyMonitor monitor = IntraVmCopyMonitor.threadMonitor.get();
        if (monitor == null) {
            monitor = new IntraVmCopyMonitor();
            IntraVmCopyMonitor.threadMonitor.set(monitor);
        }
        return monitor;
    }
    
    public static void pre(final State state) {
        getMonitor().state = state;
    }
    
    public static void post() {
        pre(State.NONE);
    }
    
    public static State state() {
        return getMonitor().state;
    }
    
    public static void prePassivationOperation() {
        pre(State.PASSIVATION);
    }
    
    public static void postPassivationOperation() {
        post();
    }
    
    public static void preCrossClassLoaderOperation() {
        pre(State.CLASSLOADER_COPY);
    }
    
    public static void postCrossClassLoaderOperation() {
        post();
    }
    
    public static void preCopyOperation() {
        pre(State.COPY);
    }
    
    public static void postCopyOperation() {
        post();
    }
    
    public static boolean isIntraVmCopyOperation() {
        return state() == State.COPY;
    }
    
    public static boolean isStatefulPassivationOperation() {
        return state() == State.PASSIVATION;
    }
    
    public static boolean isCrossClassLoaderOperation() {
        return state() == State.CLASSLOADER_COPY;
    }
    
    static {
        threadMonitor = new ThreadLocal<IntraVmCopyMonitor>();
    }
    
    public enum State
    {
        NONE, 
        COPY(true), 
        CLASSLOADER_COPY(true), 
        PASSIVATION;
        
        private final boolean copy;
        
        private State() {
            this.copy = false;
        }
        
        private State(final boolean copy) {
            this.copy = copy;
        }
        
        public boolean isCopy() {
            return this.copy;
        }
    }
}
