// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.ApplicationException;
import org.apache.openejb.SystemException;
import javax.transaction.TransactionManager;
import javax.transaction.Transaction;

public class TxRequiresNew extends JtaTransactionPolicy
{
    private final Transaction clientTx;
    private final Transaction currentTx;
    
    public TxRequiresNew(final TransactionManager transactionManager) throws SystemException {
        super(TransactionType.RequiresNew, transactionManager);
        this.clientTx = this.suspendTransaction();
        this.currentTx = this.beginTransaction();
    }
    
    @Override
    public boolean isNewTransaction() {
        return true;
    }
    
    @Override
    public boolean isClientTransaction() {
        return false;
    }
    
    @Override
    public Transaction getCurrentTransaction() {
        return this.currentTx;
    }
    
    @Override
    public void commit() throws SystemException, ApplicationException {
        try {
            this.completeTransaction(this.currentTx);
        }
        finally {
            if (this.clientTx != null) {
                this.resumeTransaction(this.clientTx);
            }
            else {
                TxRequiresNew.txLogger.debug("TX {0}: No transaction to resume", this.transactionType);
            }
        }
    }
}
