// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.transaction;

import org.apache.openejb.SystemException;
import javax.transaction.TransactionManager;
import javax.transaction.Transaction;

public class TxSupports extends JtaTransactionPolicy
{
    private final Transaction clientTx;
    
    public TxSupports(final TransactionManager transactionManager) throws SystemException {
        super(TransactionType.Supports, transactionManager);
        this.clientTx = this.getTransaction();
    }
    
    @Override
    public boolean isNewTransaction() {
        return false;
    }
    
    @Override
    public boolean isClientTransaction() {
        return this.clientTx != null;
    }
    
    @Override
    public Transaction getCurrentTransaction() {
        return this.clientTx;
    }
    
    @Override
    public void commit() {
        this.fireNonTransactionalCompletion();
    }
}
