// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jaas;

import java.util.HashSet;
import org.apache.openejb.util.LogCategory;
import java.util.List;
import java.util.Iterator;
import java.util.Collection;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.callback.UnsupportedCallbackException;
import java.io.IOException;
import javax.security.auth.login.LoginException;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.Callback;
import java.util.Map;
import java.util.LinkedHashSet;
import java.security.Principal;
import java.util.Set;
import java.util.ServiceLoader;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.Subject;
import org.apache.openejb.util.Logger;
import javax.security.auth.spi.LoginModule;

public class ServiceProviderLoginModule implements LoginModule
{
    private static final Logger log;
    private Subject subject;
    private CallbackHandler callbackHandler;
    private ServiceLoader<LoginProvider> loader;
    public Set<Principal> principals;
    private UserData userData;
    
    public ServiceProviderLoginModule() {
        this.principals = new LinkedHashSet<Principal>();
    }
    
    @Override
    public void initialize(final Subject subject, final CallbackHandler callbackHandler, final Map<String, ?> sharedState, final Map<String, ?> options) {
        this.subject = subject;
        this.callbackHandler = callbackHandler;
        this.loader = ServiceLoader.load(LoginProvider.class);
    }
    
    private UserData getUserData() throws LoginException {
        final Callback[] callbacks = { new NameCallback("Username: "), new PasswordCallback("Password: ", false) };
        try {
            this.callbackHandler.handle(callbacks);
        }
        catch (IOException ioe) {
            throw new LoginException(ioe.getMessage());
        }
        catch (UnsupportedCallbackException uce) {
            throw new LoginException(uce.getMessage() + " not available to obtain information from user");
        }
        final String user = ((NameCallback)callbacks[0]).getName();
        char[] tmpPassword = ((PasswordCallback)callbacks[1]).getPassword();
        if (tmpPassword == null) {
            tmpPassword = new char[0];
        }
        final String password = new String(tmpPassword);
        return new UserData(user, password);
    }
    
    @Override
    public boolean login() throws LoginException {
        final Iterator<LoginProvider> loginProviders = this.loader.iterator();
        if (!loginProviders.hasNext()) {
            throw new FailedLoginException("No LoginProvider defined.");
        }
        this.userData = this.getUserData();
        while (loginProviders.hasNext()) {
            final LoginProvider loginProvider = loginProviders.next();
            final List<String> myGroups = loginProvider.authenticate(this.userData.user, this.userData.pass);
            if (myGroups != null) {
                this.userData.groups.addAll(myGroups);
            }
        }
        return true;
    }
    
    @Override
    public boolean commit() throws LoginException {
        this.principals.add(new UserPrincipal(this.userData.user));
        for (final String myGroup : this.userData.groups) {
            this.principals.add(new GroupPrincipal(myGroup));
        }
        this.subject.getPrincipals().addAll(this.principals);
        this.clear();
        ServiceProviderLoginModule.log.debug("commit");
        return true;
    }
    
    @Override
    public boolean abort() throws LoginException {
        this.clear();
        ServiceProviderLoginModule.log.debug("abort");
        return true;
    }
    
    @Override
    public boolean logout() throws LoginException {
        this.subject.getPrincipals().removeAll(this.principals);
        this.principals.clear();
        ServiceProviderLoginModule.log.debug("logout");
        return true;
    }
    
    private void clear() {
        this.userData = null;
    }
    
    static {
        log = Logger.getInstance(LogCategory.OPENEJB_SECURITY, "org.apache.openejb.util.resources");
    }
    
    private final class UserData
    {
        public final String user;
        public final String pass;
        public final Set<String> groups;
        
        private UserData(final String user, final String pass) {
            this.groups = new HashSet<String>();
            this.user = user;
            this.pass = pass;
        }
    }
}
