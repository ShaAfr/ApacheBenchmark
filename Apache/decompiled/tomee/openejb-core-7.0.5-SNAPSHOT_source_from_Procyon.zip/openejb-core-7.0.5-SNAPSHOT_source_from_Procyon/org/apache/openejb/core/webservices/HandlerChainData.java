// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;

public class HandlerChainData
{
    private final QName serviceNamePattern;
    private final QName portNamePattern;
    private final List<String> protocolBindings;
    private final List<HandlerData> handlers;
    
    public HandlerChainData(final QName serviceNamePattern, final QName portNamePattern, final List<String> protocolBindings, final List<HandlerData> handlers) {
        this.protocolBindings = new ArrayList<String>();
        this.handlers = new ArrayList<HandlerData>();
        this.serviceNamePattern = serviceNamePattern;
        this.portNamePattern = portNamePattern;
        this.protocolBindings.addAll(protocolBindings);
        this.handlers.addAll(handlers);
    }
    
    public QName getServiceNamePattern() {
        return this.serviceNamePattern;
    }
    
    public QName getPortNamePattern() {
        return this.portNamePattern;
    }
    
    public List<String> getProtocolBindings() {
        return this.protocolBindings;
    }
    
    public List<HandlerData> getHandlers() {
        return this.handlers;
    }
}
