// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import javax.naming.NameNotFoundException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.apache.openejb.core.ivm.naming.ContextWrapper;
import javax.naming.NamingException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.naming.Context;
import java.util.Hashtable;
import javax.naming.spi.InitialContextFactory;

public class OpenEJBInitialContextFactory implements InitialContextFactory
{
    @Override
    public Context getInitialContext(final Hashtable env) throws NamingException {
        return new LocalFallbackContextWrapper(((ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class)).getJNDIContext());
    }
    
    private static final class LocalFallbackContextWrapper extends ContextWrapper
    {
        private final ConcurrentMap<String, String> mapping;
        
        private LocalFallbackContextWrapper(final Context jndiContext) {
            super(jndiContext);
            this.mapping = new ConcurrentHashMap<String, String>();
        }
        
        @Override
        public Object lookup(final String userName) throws NamingException {
            String jndi = this.mapping.get(userName);
            if (jndi == null) {
                jndi = userName;
            }
            try {
                return super.lookup(jndi);
            }
            catch (NameNotFoundException nnfe) {
                if (!jndi.startsWith("java:") && !jndi.startsWith("openejb:")) {
                    try {
                        final String ejb = "java:openejb/local/" + jndi;
                        final Object lookup = super.lookup(ejb);
                        this.mapping.put(userName, ejb);
                        return lookup;
                    }
                    catch (NameNotFoundException nnfeIgnored) {
                        try {
                            final String resource = "java:openejb/Resource/" + jndi;
                            final Object resourceInstance = super.lookup(resource);
                            this.mapping.put(userName, resource);
                            return resourceInstance;
                        }
                        catch (NameNotFoundException nnfeIgnoredAgain) {
                            throw nnfe;
                        }
                    }
                }
                throw nnfe;
            }
        }
    }
}
