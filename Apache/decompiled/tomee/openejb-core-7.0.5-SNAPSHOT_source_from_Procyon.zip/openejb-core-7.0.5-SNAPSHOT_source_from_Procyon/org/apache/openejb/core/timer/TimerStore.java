// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.timer;

import javax.ejb.ScheduleExpression;
import javax.ejb.TimerConfig;
import java.util.Date;
import java.lang.reflect.Method;
import java.util.Collection;

public interface TimerStore
{
    TimerData getTimer(final String p0, final long p1);
    
    Collection<TimerData> getTimers(final String p0);
    
    Collection<TimerData> loadTimers(final EjbTimerServiceImpl p0, final String p1) throws TimerStoreException;
    
    void addTimerData(final TimerData p0) throws TimerStoreException;
    
    TimerData createSingleActionTimer(final EjbTimerServiceImpl p0, final String p1, final Object p2, final Method p3, final Date p4, final TimerConfig p5) throws TimerStoreException;
    
    TimerData createIntervalTimer(final EjbTimerServiceImpl p0, final String p1, final Object p2, final Method p3, final Date p4, final long p5, final TimerConfig p6) throws TimerStoreException;
    
    TimerData createCalendarTimer(final EjbTimerServiceImpl p0, final String p1, final Object p2, final Method p3, final ScheduleExpression p4, final TimerConfig p5, final boolean p6) throws TimerStoreException;
    
    void removeTimer(final long p0);
    
    void updateIntervalTimer(final TimerData p0);
}
