// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import javax.ejb.EntityBean;
import org.apache.openejb.OpenEJBException;
import java.lang.reflect.Field;

public class SimpleKeyGenerator extends AbstractKeyGenerator
{
    private final Field pkField;
    
    public SimpleKeyGenerator(final Class beanClass, final String pkField) throws OpenEJBException {
        this.pkField = AbstractKeyGenerator.getField(beanClass, pkField);
        if (!AbstractKeyGenerator.isValidPkField(this.pkField)) {
            throw new OpenEJBException("Invalid primray key field: " + pkField);
        }
    }
    
    @Override
    public Object getPrimaryKey(final EntityBean bean) {
        final Object value = AbstractKeyGenerator.getFieldValue(this.pkField, bean);
        return value;
    }
}
