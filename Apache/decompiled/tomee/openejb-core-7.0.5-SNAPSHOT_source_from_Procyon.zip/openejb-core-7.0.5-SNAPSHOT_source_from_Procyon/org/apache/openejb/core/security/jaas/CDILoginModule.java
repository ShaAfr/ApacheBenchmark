// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jaas;

import javax.security.auth.login.LoginException;
import java.util.Iterator;
import org.apache.openejb.core.WebContext;
import org.apache.openejb.AppContext;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import javax.enterprise.inject.spi.Bean;
import org.apache.webbeans.container.BeanManagerImpl;
import javax.enterprise.inject.spi.BeanManager;
import org.apache.webbeans.inject.OWBInjector;
import javax.enterprise.context.spi.CreationalContext;
import java.util.Set;
import java.lang.reflect.Type;
import java.lang.annotation.Annotation;
import javax.enterprise.context.spi.Contextual;
import org.apache.openejb.OpenEJBRuntimeException;
import org.apache.webbeans.config.WebBeansContext;
import java.util.Map;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.Subject;
import org.apache.webbeans.context.creational.CreationalContextImpl;
import javax.security.auth.spi.LoginModule;

public class CDILoginModule implements LoginModule
{
    private CreationalContextImpl<?> cc;
    private LoginModule loginModule;
    
    @Override
    public void initialize(final Subject subject, final CallbackHandler callbackHandler, final Map<String, ?> sharedState, final Map<String, ?> options) {
        final WebBeansContext webBeansContext = WebBeansContext.currentInstance();
        final BeanManagerImpl bm = webBeansContext.getBeanManagerImpl();
        if (!bm.isInUse()) {
            throw new OpenEJBRuntimeException("CDI not activated");
        }
        String delegate = String.valueOf(options.get("delegate"));
        if ("null".equals(delegate)) {
            final String app = findAppName(webBeansContext);
            delegate = String.valueOf(options.get(app));
            if ("null".equals(delegate)) {
                throw new OpenEJBRuntimeException("Please specify a delegate class");
            }
        }
        Class<?> clazz;
        try {
            clazz = Thread.currentThread().getContextClassLoader().loadClass(delegate);
        }
        catch (ClassNotFoundException e) {
            throw new OpenEJBRuntimeException(e.getMessage(), e);
        }
        this.cc = (CreationalContextImpl<?>)bm.createCreationalContext((Contextual)null);
        final String cdiName = String.valueOf(options.get("cdiName"));
        if ("true".equals(String.valueOf(options.get("loginModuleAsCdiBean")))) {
            Set<Bean<?>> beans;
            if ("null".equals(cdiName)) {
                beans = (Set<Bean<?>>)bm.getBeans((Type)clazz, new Annotation[0]);
            }
            else {
                beans = (Set<Bean<?>>)bm.getBeans(cdiName);
            }
            this.loginModule = LoginModule.class.cast(bm.getReference(bm.resolve((Set)beans), (Type)clazz, (CreationalContext)this.cc));
        }
        else {
            try {
                OWBInjector.inject((BeanManager)bm, (Object)(this.loginModule = LoginModule.class.cast(clazz.newInstance())), (CreationalContext)this.cc);
            }
            catch (Exception e2) {
                throw new OpenEJBRuntimeException("Can't inject into delegate class " + this.loginModule, e2);
            }
        }
        this.loginModule.initialize(subject, callbackHandler, sharedState, options);
    }
    
    private static String findAppName(final WebBeansContext webBeansContext) {
        final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
        for (final AppContext appContext : containerSystem.getAppContexts()) {
            if (appContext.getWebBeansContext() == webBeansContext) {
                return appContext.getId();
            }
            for (final WebContext web : appContext.getWebContexts()) {
                if (web.getWebbeansContext() == webBeansContext) {
                    return web.getId();
                }
            }
        }
        return "defaultDelegate";
    }
    
    @Override
    public boolean login() throws LoginException {
        return this.loginModule != null && this.loginModule.login();
    }
    
    @Override
    public boolean commit() throws LoginException {
        return this.loginModule == null || this.loginModule.commit();
    }
    
    @Override
    public boolean abort() throws LoginException {
        try {
            return this.loginModule == null || this.loginModule.abort();
        }
        finally {
            this.cleanUp();
        }
    }
    
    @Override
    public boolean logout() throws LoginException {
        try {
            return this.loginModule == null || this.loginModule.logout();
        }
        finally {
            this.cleanUp();
        }
    }
    
    private void cleanUp() {
        if (this.cc != null) {
            this.cc.release();
            this.cc = null;
        }
    }
}
