// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.ivm.naming;

import javax.naming.NamingException;
import org.apache.openejb.BeanContext;

public class BusinessLocalReference extends Reference
{
    private final BeanContext.BusinessLocalHome businessHome;
    
    public BusinessLocalReference(final BeanContext.BusinessLocalHome businessHome) {
        this.businessHome = businessHome;
    }
    
    @Override
    public Object getObject() throws NamingException {
        return this.businessHome.create();
    }
}
