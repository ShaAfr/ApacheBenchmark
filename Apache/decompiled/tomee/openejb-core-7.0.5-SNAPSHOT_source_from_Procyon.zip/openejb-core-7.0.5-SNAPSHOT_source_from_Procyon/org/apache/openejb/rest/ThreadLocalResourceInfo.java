// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import java.lang.reflect.Method;
import javax.ws.rs.container.ResourceInfo;

public class ThreadLocalResourceInfo extends AbstractRestThreadLocalProxy<ResourceInfo> implements ResourceInfo
{
    protected ThreadLocalResourceInfo() {
        super(ResourceInfo.class);
    }
    
    public Method getResourceMethod() {
        return this.get().getResourceMethod();
    }
    
    public Class<?> getResourceClass() {
        return (Class<?>)this.get().getResourceClass();
    }
}
