// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb;

public class OpenEJBException extends Exception
{
    public OpenEJBException() {
    }
    
    public OpenEJBException(final String message) {
        super(message);
    }
    
    public OpenEJBException(final Throwable rootCause) {
        super(rootCause);
    }
    
    public OpenEJBException(final String message, final Throwable rootCause) {
        super(message, rootCause);
    }
    
    @Override
    public String getMessage() {
        final Throwable rootCause = this.getCause();
        if (rootCause != null) {
            return super.getMessage() + ": " + rootCause.getMessage();
        }
        return super.getMessage();
    }
    
    public Throwable getRootCause() {
        return super.getCause();
    }
}
