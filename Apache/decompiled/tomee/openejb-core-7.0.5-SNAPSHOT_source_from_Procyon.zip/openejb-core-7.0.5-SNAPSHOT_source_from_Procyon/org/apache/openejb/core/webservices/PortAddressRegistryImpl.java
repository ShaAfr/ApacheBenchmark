// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.webservices;

import java.util.Collection;
import java.util.HashSet;
import java.util.Collections;
import java.util.Set;
import org.apache.openejb.OpenEJBException;
import java.util.HashMap;
import java.util.TreeMap;
import javax.xml.namespace.QName;
import java.util.Map;

public class PortAddressRegistryImpl implements PortAddressRegistry
{
    private final Map<String, PortAddress> portsById;
    private final Map<String, Map<String, PortAddress>> portsByInterface;
    private final Map<String, Map<String, PortAddress>> portsByServiceId;
    private final Map<QName, Map<String, PortAddress>> portsByServiceQName;
    
    public PortAddressRegistryImpl() {
        this.portsById = new TreeMap<String, PortAddress>();
        this.portsByInterface = new TreeMap<String, Map<String, PortAddress>>();
        this.portsByServiceId = new TreeMap<String, Map<String, PortAddress>>();
        this.portsByServiceQName = new HashMap<QName, Map<String, PortAddress>>();
    }
    
    @Override
    public synchronized void addPort(final String serviceId, final QName serviceQName, final String portId, final QName portQName, final String portInterface, final String address) throws OpenEJBException {
        if (serviceId == null) {
            throw new NullPointerException("serviceId is null");
        }
        if (serviceQName == null) {
            throw new NullPointerException("serviceQName is null");
        }
        if (portId == null) {
            throw new NullPointerException("portId is null");
        }
        if (portQName == null) {
            throw new NullPointerException("portQName is null");
        }
        if (address == null) {
            throw new NullPointerException("address is null");
        }
        PortAddress portAddress = this.portsById.get(portId);
        if (portAddress != null) {
            throw new OpenEJBException("A webservice port with qname " + portAddress.getPortQName() + " is already registered to the portId " + portId);
        }
        portAddress = new PortAddress(portId, serviceQName, portQName, address, portInterface);
        this.portsById.put(portId, portAddress);
        Map<String, PortAddress> ports = null;
        if (portInterface != null) {
            ports = this.portsByInterface.get(portInterface);
            if (ports == null) {
                ports = new TreeMap<String, PortAddress>();
                this.portsByInterface.put(portInterface, ports);
            }
            ports.put(portId, portAddress);
        }
        ports = this.portsByServiceId.get(serviceId);
        if (ports == null) {
            ports = new TreeMap<String, PortAddress>();
            this.portsByServiceId.put(serviceId, ports);
        }
        ports.put(portId, portAddress);
        ports = this.portsByServiceQName.get(serviceQName);
        if (ports == null) {
            ports = new TreeMap<String, PortAddress>();
            this.portsByServiceQName.put(serviceQName, ports);
        }
        ports.put(portId, portAddress);
    }
    
    @Override
    public synchronized void removePort(final String serviceId, final QName serviceQName, final String portId, final String portInterface) {
        if (serviceId == null) {
            throw new NullPointerException("serviceId is null");
        }
        if (serviceQName == null) {
            throw new NullPointerException("serviceQName is null");
        }
        if (portId == null) {
            throw new NullPointerException("portId is null");
        }
        final PortAddress portAddress = this.portsById.remove(portId);
        if (portAddress != null) {
            return;
        }
        Map<String, PortAddress> ports = null;
        if (portInterface != null) {
            ports = this.portsByInterface.get(portInterface);
            if (ports != null) {
                ports.remove(portId);
                if (ports.isEmpty()) {
                    this.portsByInterface.remove(portInterface);
                }
            }
        }
        ports = this.portsByServiceId.get(serviceId);
        if (ports != null) {
            ports.remove(portId);
            if (ports.isEmpty()) {
                this.portsByServiceId.remove(serviceId);
            }
        }
        ports = this.portsByServiceQName.get(serviceQName);
        if (ports != null) {
            ports.remove(portId);
            if (ports.isEmpty()) {
                this.portsByServiceId.remove(serviceId);
            }
        }
    }
    
    @Override
    public synchronized Set<PortAddress> getPorts(final String id, final QName serviceQName, final String referenceClassName) {
        if (serviceQName == null) {
            throw new NullPointerException("serviceQName is null");
        }
        if (id != null) {
            final PortAddress portAddress = this.portsById.get(id);
            if (portAddress != null) {
                return Collections.singleton(portAddress);
            }
        }
        if (referenceClassName != null) {
            final Map<String, PortAddress> interfacePorts = this.portsByInterface.get(referenceClassName);
            if (interfacePorts != null && interfacePorts.size() == 1) {
                final PortAddress portAddress2 = interfacePorts.values().iterator().next();
                return Collections.singleton(portAddress2);
            }
        }
        final Map<String, PortAddress> ports = new TreeMap<String, PortAddress>();
        if (id != null) {
            final Map<String, PortAddress> idPorts = this.portsByServiceId.get(id);
            if (idPorts != null) {
                ports.putAll(idPorts);
            }
        }
        if (ports.isEmpty()) {
            final Map<String, PortAddress> qnamePorts = this.portsByServiceQName.get(serviceQName);
            if (qnamePorts != null) {
                ports.putAll(qnamePorts);
            }
        }
        final Set<PortAddress> portAddresses = new HashSet<PortAddress>(ports.values());
        return portAddresses;
    }
}
