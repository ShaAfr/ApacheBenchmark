// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security.jaas;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.util.Base64;
import org.apache.openejb.util.HexConverter;
import java.util.Collection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.callback.UnsupportedCallbackException;
import java.io.IOException;
import javax.security.auth.login.LoginException;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.Callback;
import java.util.Iterator;
import javax.naming.NamingException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.ContainerSystem;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import org.apache.openejb.util.Strings;
import java.util.Map;
import java.util.HashSet;
import java.security.Principal;
import java.util.Set;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.Subject;
import javax.sql.DataSource;
import java.sql.Driver;
import java.util.Properties;
import java.util.EnumMap;
import org.apache.openejb.util.Logger;
import javax.security.auth.spi.LoginModule;

public class SQLLoginModule implements LoginModule
{
    private static final Logger log;
    private final EnumMap<Option, String> optionsMap;
    private String connectionURL;
    private Properties properties;
    private Driver driver;
    private DataSource dataSource;
    private String userSelect;
    private String groupSelect;
    private String digest;
    private String encoding;
    private boolean loginSucceeded;
    private Subject subject;
    private CallbackHandler handler;
    private String cbUsername;
    private String cbPassword;
    private final Set<String> groups;
    private final Set<Principal> allPrincipals;
    
    public SQLLoginModule() {
        this.optionsMap = new EnumMap<Option, String>(Option.class);
        this.groups = new HashSet<String>();
        this.allPrincipals = new HashSet<Principal>();
    }
    
    @Override
    public void initialize(final Subject subject, final CallbackHandler callbackHandler, final Map sharedState, final Map options) {
        this.subject = subject;
        this.handler = callbackHandler;
        for (final Object key : options.keySet()) {
            final Option option = Option.findByName((String)key);
            if (option != null) {
                final String value = (String)options.get(key);
                this.optionsMap.put(option, value.trim());
            }
            else {
                SQLLoginModule.log.warning("Ignoring option: {0}. Not supported.", key);
            }
        }
        this.userSelect = this.optionsMap.get(Option.USER_SELECT);
        this.groupSelect = this.optionsMap.get(Option.GROUP_SELECT);
        this.digest = this.optionsMap.get(Option.DIGEST);
        this.encoding = this.optionsMap.get(Option.ENCODING);
        if (!Strings.checkNullBlankString(this.digest)) {
            try {
                MessageDigest.getInstance(this.digest);
            }
            catch (NoSuchAlgorithmException e) {
                this.initError(e, "Digest algorithm %s is not available.", this.digest);
            }
            if (this.encoding != null && !"hex".equalsIgnoreCase(this.encoding) && !"base64".equalsIgnoreCase(this.encoding)) {
                this.initError(null, "Digest Encoding %s is not supported.", this.encoding);
            }
        }
        if (this.optionsMap.containsKey(Option.DATABASE_POOL_NAME)) {
            final String dataSourceName = this.optionsMap.get(Option.DATABASE_POOL_NAME);
            final ContainerSystem containerSystem = (ContainerSystem)SystemInstance.get().getComponent((Class)ContainerSystem.class);
            try {
                this.dataSource = (DataSource)containerSystem.getJNDIContext().lookup("openejb/Resource/" + dataSourceName);
            }
            catch (NamingException e2) {
                this.initError(e2, "Data source %s not found.", dataSourceName);
            }
        }
        else if (this.optionsMap.containsKey(Option.CONNECTION_URL)) {
            this.connectionURL = this.optionsMap.get(Option.CONNECTION_URL);
            final String user = this.optionsMap.get(Option.USER);
            final String password = this.optionsMap.get(Option.PASSWORD);
            final String driverName = this.optionsMap.get(Option.DRIVER);
            this.properties = new Properties();
            if (user != null) {
                this.properties.put("user", user);
            }
            if (password != null) {
                this.properties.put("password", password);
            }
            if (driverName != null) {
                final ClassLoader cl = this.getClass().getClassLoader();
                try {
                    this.driver = (Driver)cl.loadClass(driverName).newInstance();
                }
                catch (ClassNotFoundException e3) {
                    this.initError(e3, "Driver class %s is not available. Perhaps you need to add it as a dependency in your deployment plan?", driverName);
                }
                catch (Exception e4) {
                    this.initError(e4, "Unable to load, instantiate, register driver %s: %s", driverName, e4.getMessage());
                }
            }
        }
        else {
            this.initError(null, "Neither %s nor %s was specified", Option.DATABASE_POOL_NAME.name, Option.CONNECTION_URL.name);
        }
    }
    
    private void initError(final Exception e, final String format, final Object... args) {
        final String message = String.format(format, args);
        SQLLoginModule.log.error("Initialization failed. {0}", message);
        throw new IllegalArgumentException(message, e);
    }
    
    @Override
    public boolean login() throws LoginException {
        this.loginSucceeded = false;
        final Callback[] callbacks = { new NameCallback("User name"), new PasswordCallback("Password", false) };
        try {
            this.handler.handle(callbacks);
        }
        catch (IOException | UnsupportedCallbackException ex2) {
            final Exception ex;
            final Exception ioe = ex;
            throw (LoginException)new LoginException().initCause(ioe);
        }
        assert callbacks.length == 2;
        this.cbUsername = ((NameCallback)callbacks[0]).getName();
        if (Strings.checkNullBlankString(this.cbUsername)) {
            throw new FailedLoginException();
        }
        final char[] provided = ((PasswordCallback)callbacks[1]).getPassword();
        this.cbPassword = ((provided == null) ? null : new String(provided));
        try {
            Connection conn;
            if (this.dataSource != null) {
                conn = this.dataSource.getConnection();
            }
            else if (this.driver != null) {
                conn = this.driver.connect(this.connectionURL, this.properties);
            }
            else {
                conn = DriverManager.getConnection(this.connectionURL, this.properties);
            }
            try {
                PreparedStatement statement = conn.prepareStatement(this.userSelect);
                try {
                    for (int count = statement.getParameterMetaData().getParameterCount(), i = 0; i < count; ++i) {
                        statement.setObject(i + 1, this.cbUsername);
                    }
                    final ResultSet result = statement.executeQuery();
                    try {
                        boolean found = false;
                        while (result.next()) {
                            final String userName = result.getString(1);
                            final String userPassword = result.getString(2);
                            if (this.cbUsername.equals(userName)) {
                                found = true;
                                if (!this.checkPassword(userPassword, this.cbPassword)) {
                                    throw new FailedLoginException();
                                }
                                break;
                            }
                        }
                        if (!found) {
                            throw new FailedLoginException();
                        }
                    }
                    finally {
                        result.close();
                    }
                }
                finally {
                    statement.close();
                }
                statement = conn.prepareStatement(this.groupSelect);
                try {
                    for (int count = statement.getParameterMetaData().getParameterCount(), i = 0; i < count; ++i) {
                        statement.setObject(i + 1, this.cbUsername);
                    }
                    final ResultSet result = statement.executeQuery();
                    try {
                        while (result.next()) {
                            final String userName2 = result.getString(1);
                            final String groupName = result.getString(2);
                            if (this.cbUsername.equals(userName2)) {
                                this.groups.add(groupName);
                            }
                        }
                    }
                    finally {
                        result.close();
                    }
                }
                finally {
                    statement.close();
                }
            }
            finally {
                conn.close();
            }
        }
        catch (LoginException e) {
            this.cbUsername = null;
            this.cbPassword = null;
            this.groups.clear();
            throw e;
        }
        catch (SQLException sqle) {
            this.cbUsername = null;
            this.cbPassword = null;
            this.groups.clear();
            throw (LoginException)new LoginException("SQL error").initCause(sqle);
        }
        catch (Exception e2) {
            this.cbUsername = null;
            this.cbPassword = null;
            this.groups.clear();
            throw (LoginException)new LoginException("Could not access datasource").initCause(e2);
        }
        return this.loginSucceeded = true;
    }
    
    @Override
    public boolean commit() throws LoginException {
        if (this.loginSucceeded) {
            if (this.cbUsername != null) {
                this.allPrincipals.add(new UserPrincipal(this.cbUsername));
            }
            for (final String group : this.groups) {
                this.allPrincipals.add(new GroupPrincipal(group));
            }
            this.subject.getPrincipals().addAll(this.allPrincipals);
        }
        this.cbUsername = null;
        this.cbPassword = null;
        this.groups.clear();
        return this.loginSucceeded;
    }
    
    @Override
    public boolean abort() throws LoginException {
        if (this.loginSucceeded) {
            this.cbUsername = null;
            this.cbPassword = null;
            this.groups.clear();
            this.allPrincipals.clear();
        }
        return this.loginSucceeded;
    }
    
    @Override
    public boolean logout() throws LoginException {
        this.loginSucceeded = false;
        this.cbUsername = null;
        this.cbPassword = null;
        this.groups.clear();
        if (!this.subject.isReadOnly()) {
            this.subject.getPrincipals().removeAll(this.allPrincipals);
        }
        this.allPrincipals.clear();
        return true;
    }
    
    private boolean checkPassword(final String real, final String provided) {
        if (real == null && provided == null) {
            return true;
        }
        if (real == null || provided == null) {
            return false;
        }
        if (Strings.checkNullBlankString(this.digest)) {
            return real.equals(provided);
        }
        try {
            final MessageDigest md = MessageDigest.getInstance(this.digest);
            final byte[] data = md.digest(provided.getBytes());
            if (this.encoding == null || "hex".equalsIgnoreCase(this.encoding)) {
                return real.equalsIgnoreCase(HexConverter.bytesToHex(data));
            }
            if ("base64".equalsIgnoreCase(this.encoding)) {
                return real.equals(new String(Base64.encodeBase64(data)));
            }
        }
        catch (NoSuchAlgorithmException e) {
            SQLLoginModule.log.error("Should not occur.  Availability of algorithm has been checked at initialization.", e);
        }
        return false;
    }
    
    static {
        log = Logger.getInstance(LogCategory.OPENEJB_SECURITY, "org.apache.openejb.util.resources");
    }
    
    private enum Option
    {
        USER_SELECT("userSelect"), 
        GROUP_SELECT("groupSelect"), 
        CONNECTION_URL("jdbcURL"), 
        USER("jdbcUser"), 
        PASSWORD("jdbcPassword"), 
        DRIVER("jdbcDriver"), 
        DATABASE_POOL_NAME("dataSourceName"), 
        DIGEST("digest"), 
        ENCODING("encoding");
        
        public final String name;
        
        private Option(final String name) {
            this.name = name;
        }
        
        public static Option findByName(final String name) {
            for (final Option opt : values()) {
                if (opt.name.equals(name)) {
                    return opt;
                }
            }
            return null;
        }
    }
}
