// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.security;

import java.util.Arrays;
import java.util.List;
import java.io.IOException;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.message.callback.TrustStoreCallback;
import javax.security.auth.message.callback.SecretKeyCallback;
import javax.security.auth.message.callback.PrivateKeyCallback;
import javax.security.auth.message.callback.CertStoreCallback;
import javax.security.auth.login.LoginException;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.spi.SecurityService;
import javax.security.auth.message.callback.PasswordValidationCallback;
import javax.security.auth.message.callback.GroupPrincipalCallback;
import javax.security.auth.message.callback.CallerPrincipalCallback;
import javax.security.auth.callback.Callback;
import java.security.Principal;
import javax.security.auth.callback.CallbackHandler;

public class ConnectorCallbackHandler implements CallbackHandler
{
    private Principal callerPrincipal;
    private String[] groupsArray;
    private final String securityRealmName;
    
    public ConnectorCallbackHandler(final String securityRealmName) {
        this.securityRealmName = securityRealmName;
    }
    
    @Override
    public void handle(final Callback[] callbacks) throws IOException, UnsupportedCallbackException {
        for (final Callback callback : callbacks) {
            if (callback instanceof CallerPrincipalCallback) {
                this.callerPrincipal = ((CallerPrincipalCallback)callback).getPrincipal();
            }
            else if (callback instanceof GroupPrincipalCallback) {
                this.groupsArray = ((GroupPrincipalCallback)callback).getGroups();
            }
            else if (callback instanceof PasswordValidationCallback) {
                final PasswordValidationCallback passwordValidationCallback = (PasswordValidationCallback)callback;
                final String userName = passwordValidationCallback.getUsername();
                final char[] password = passwordValidationCallback.getPassword();
                final SecurityService securityService = (SecurityService)SystemInstance.get().getComponent((Class)SecurityService.class);
                try {
                    final Object loginObj = securityService.login(this.securityRealmName, userName, (password == null) ? "" : new String(password));
                    securityService.associate(loginObj);
                    this.callerPrincipal = securityService.getCallerPrincipal();
                    passwordValidationCallback.setResult(true);
                }
                catch (LoginException e) {
                    passwordValidationCallback.setResult(false);
                }
            }
            else if (!(callback instanceof CertStoreCallback)) {
                if (!(callback instanceof PrivateKeyCallback)) {
                    if (!(callback instanceof SecretKeyCallback)) {
                        if (!(callback instanceof TrustStoreCallback)) {
                            throw new UnsupportedCallbackException(callback);
                        }
                    }
                }
            }
        }
    }
    
    public Principal getCallerPrincipal() {
        return this.callerPrincipal;
    }
    
    public List<String> getGroups() {
        return (this.groupsArray == null) ? null : Arrays.asList(this.groupsArray);
    }
}
