// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

public class EnvProps
{
    public static final String IM_CLASS_NAME = "InstanceManager";
    public static final String IM_TIME_OUT = "TimeOut";
    public static final String IM_PASSIVATOR_PATH_PREFIX = "org/openejb/core/InstanceManager/PASSIVATOR_PATH_PREFIX";
    public static final String IM_POOL_SIZE = "PoolSize";
    public static final String IM_PASSIVATE_SIZE = "BulkPassivate";
    public static final String IM_PASSIVATOR = "Passivator";
    public static final String IM_CONCURRENT_ATTEMPTS = "org/openejb/core/InstanceManager/CONCURRENT_ATTEMPTS";
    public static final String IM_STRICT_POOLING = "StrictPooling";
    public static final String INTRA_VM_COPY = "org/openejb/core/ivm/BaseEjbProxyHandler/INTRA_VM_COPY";
    public static final String JDBC_DRIVER = "JdbcDriver";
    public static final String JDBC_URL = "JdbcUrl";
    public static final String USER_NAME = "UserName";
    public static final String PASSWORD = "Password";
}
