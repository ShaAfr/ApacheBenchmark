// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.rest;

import javax.ws.rs.container.ResourceContext;

public class ThreadLocalResourceContext extends AbstractRestThreadLocalProxy<ResourceContext> implements ResourceContext
{
    protected ThreadLocalResourceContext() {
        super(ResourceContext.class);
    }
    
    public <T> T getResource(final Class<T> tClass) {
        return (T)this.get().getResource((Class)tClass);
    }
    
    public <T> T initResource(final T t) {
        return (T)this.get().initResource((Object)t);
    }
}
