// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.cmp;

import javax.ejb.Timer;
import org.apache.openejb.core.timer.EjbTimerServiceImpl;
import java.util.List;
import org.apache.openejb.util.Enumerator;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Collection;
import javax.ejb.FinderException;
import javax.ejb.ObjectNotFoundException;
import org.apache.openejb.ProxyInfo;
import org.apache.openejb.core.transaction.TransactionPolicy;
import org.apache.openejb.core.ExceptionType;
import java.lang.reflect.InvocationTargetException;
import java.rmi.NoSuchObjectException;
import org.apache.openejb.core.transaction.EjbTransactionUtil;
import javax.ejb.RemoveException;
import java.util.Iterator;
import java.util.Set;
import javax.transaction.Synchronization;
import java.util.LinkedHashSet;
import java.rmi.RemoteException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import org.apache.openejb.core.Operation;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBHome;
import org.apache.openejb.ApplicationException;
import javax.ejb.EJBAccessException;
import java.lang.reflect.Method;
import org.apache.openejb.InterfaceType;
import org.apache.openejb.core.ThreadContext;
import org.apache.openejb.core.timer.EjbTimerService;
import java.lang.reflect.Field;
import org.apache.openejb.Container;
import org.apache.openejb.core.entity.EntityContext;
import javax.ejb.EJBContext;
import org.apache.openejb.ContainerType;
import org.apache.openejb.OpenEJBException;
import org.apache.openejb.loader.SystemInstance;
import java.util.HashMap;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionSynchronizationRegistry;
import org.apache.openejb.core.entity.EntrancyTracker;
import org.apache.openejb.BeanContext;
import java.util.Map;
import org.apache.openejb.spi.SecurityService;
import org.apache.openejb.RpcContainer;

public class CmpContainer implements RpcContainer
{
    protected final Object containerID;
    protected final SecurityService securityService;
    protected final Map<Object, BeanContext> deploymentsById;
    protected final Map<Class, BeanContext> beansByClass;
    protected final CmpEngine cmpEngine;
    protected EntrancyTracker entrancyTracker;
    protected TransactionSynchronizationRegistry synchronizationRegistry;
    private static final Object ENTITIES_TO_STORE;
    
    public CmpContainer(final Object id, final TransactionManager transactionManager, final SecurityService securityService, final String cmpEngineFactory) throws OpenEJBException {
        this.deploymentsById = new HashMap<Object, BeanContext>();
        this.beansByClass = new HashMap<Class, BeanContext>();
        this.containerID = id;
        this.securityService = securityService;
        this.synchronizationRegistry = (TransactionSynchronizationRegistry)SystemInstance.get().getComponent((Class)TransactionSynchronizationRegistry.class);
        this.entrancyTracker = new EntrancyTracker(this.synchronizationRegistry);
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        if (classLoader == null) {
            classLoader = this.getClass().getClassLoader();
        }
        CmpEngineFactory factory;
        try {
            final Class<?> cmpEngineFactoryClass = classLoader.loadClass(cmpEngineFactory);
            factory = (CmpEngineFactory)cmpEngineFactoryClass.newInstance();
        }
        catch (Exception e) {
            throw new OpenEJBException("Unable to create cmp engine factory " + cmpEngineFactory, e);
        }
        factory.setTransactionManager(transactionManager);
        factory.setTransactionSynchronizationRegistry(this.synchronizationRegistry);
        factory.setCmpCallback(new ContainerCmpCallback());
        this.cmpEngine = factory.create();
    }
    
    @Override
    public Object getContainerID() {
        return this.containerID;
    }
    
    @Override
    public ContainerType getContainerType() {
        return ContainerType.CMP_ENTITY;
    }
    
    @Override
    public synchronized BeanContext[] getBeanContexts() {
        return this.deploymentsById.values().toArray(new BeanContext[this.deploymentsById.size()]);
    }
    
    @Override
    public synchronized BeanContext getBeanContext(final Object deploymentID) {
        return this.deploymentsById.get(deploymentID);
    }
    
    private BeanContext getBeanContextByClass(Class type) {
        BeanContext beanContext;
        for (beanContext = null; type != null && beanContext == null; beanContext = this.beansByClass.get(type), type = type.getSuperclass()) {}
        return beanContext;
    }
    
    @Override
    public void deploy(final BeanContext beanContext) throws OpenEJBException {
        synchronized (this) {
            final Object deploymentId = beanContext.getDeploymentID();
            this.cmpEngine.deploy(beanContext);
            beanContext.setContainerData(this.cmpEngine);
            beanContext.set((Class<EntityContext>)EJBContext.class, new EntityContext(this.securityService));
            try {
                final Field field = beanContext.getCmpImplClass().getField("deploymentInfo");
                field.set(null, beanContext);
            }
            catch (Exception ex) {}
            this.deploymentsById.put(deploymentId, beanContext);
            this.beansByClass.put(beanContext.getCmpImplClass(), beanContext);
            beanContext.setContainer(this);
        }
    }
    
    @Override
    public void start(final BeanContext beanContext) throws OpenEJBException {
        final EjbTimerService timerService = beanContext.getEjbTimerService();
        if (timerService != null) {
            timerService.start();
        }
    }
    
    @Override
    public void stop(final BeanContext beanContext) throws OpenEJBException {
        beanContext.stop();
    }
    
    @Override
    public void undeploy(final BeanContext beanContext) throws OpenEJBException {
        synchronized (this) {
            this.deploymentsById.remove(beanContext.getDeploymentID());
            this.beansByClass.remove(beanContext.getCmpImplClass());
            try {
                final Field field = beanContext.getCmpImplClass().getField("deploymentInfo");
                field.set(null, null);
            }
            catch (Exception ex) {}
            beanContext.setContainer(null);
            beanContext.setContainerData(null);
        }
    }
    
    public Object getEjbInstance(final BeanContext beanContext, final Object primaryKey) {
        final ThreadContext callContext = new ThreadContext(beanContext, primaryKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            return this.cmpEngine.loadBean(callContext, primaryKey);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    @Override
    public Object invoke(final Object deployID, InterfaceType type, final Class callInterface, final Method callMethod, final Object[] args, final Object primKey) throws OpenEJBException {
        final BeanContext beanContext = this.getBeanContext(deployID);
        if (beanContext == null) {
            throw new OpenEJBException("Deployment does not exist in this container. Deployment(id='" + deployID + "'), Container(id='" + this.containerID + "')");
        }
        if (type == null) {
            type = beanContext.getInterfaceType(callInterface);
        }
        final ThreadContext callContext = new ThreadContext(beanContext, primKey);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            final boolean authorized = this.securityService.isCallerAuthorized(callMethod, type);
            if (!authorized) {
                throw new ApplicationException((Exception)new EJBAccessException("Unauthorized Access by Principal Denied"));
            }
            final Class declaringClass = callMethod.getDeclaringClass();
            final String methodName = callMethod.getName();
            if (EJBHome.class.isAssignableFrom(declaringClass) || EJBLocalHome.class.isAssignableFrom(declaringClass)) {
                if (declaringClass != EJBHome.class && declaringClass != EJBLocalHome.class) {
                    if (methodName.startsWith("create")) {
                        return this.createEJBObject(callMethod, args, callContext, type);
                    }
                    if (methodName.equals("findByPrimaryKey")) {
                        return this.findByPrimaryKey(callMethod, args, callContext, type);
                    }
                    if (methodName.startsWith("find")) {
                        return this.findEJBObject(callMethod, args, callContext, type);
                    }
                    return this.homeMethod(callMethod, args, callContext, type);
                }
                else if (methodName.equals("remove")) {
                    this.removeEJBObject(callMethod, callContext, type);
                    return null;
                }
            }
            else if ((EJBObject.class == declaringClass || EJBLocalObject.class == declaringClass) && methodName.equals("remove")) {
                this.removeEJBObject(callMethod, callContext, type);
                return null;
            }
            callContext.setCurrentOperation(Operation.BUSINESS);
            final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
            callContext.set(Method.class, runMethod);
            return this.businessMethod(callMethod, runMethod, args, callContext, type);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private EntityBean createNewInstance(final ThreadContext callContext) {
        final BeanContext beanContext = callContext.getBeanContext();
        try {
            return beanContext.getCmpImplClass().newInstance();
        }
        catch (Exception e) {
            throw new EJBException("Unable to create new entity bean instance " + beanContext.getCmpImplClass(), e);
        }
    }
    
    private ThreadContext createThreadContext(final EntityBean entityBean) {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        final BeanContext beanContext = this.getBeanContextByClass(entityBean.getClass());
        final KeyGenerator keyGenerator = beanContext.getKeyGenerator();
        final Object primaryKey = keyGenerator.getPrimaryKey(entityBean);
        return new ThreadContext(beanContext, primaryKey);
    }
    
    private void setEntityContext(final EntityBean entityBean) {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        final BeanContext beanContext = this.getBeanContextByClass(entityBean.getClass());
        final ThreadContext callContext = new ThreadContext(beanContext, null);
        callContext.setCurrentOperation(Operation.SET_CONTEXT);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            entityBean.setEntityContext((javax.ejb.EntityContext)new EntityContext(this.securityService));
        }
        catch (RemoteException e) {
            throw new EJBException((Exception)e);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private void unsetEntityContext(final EntityBean entityBean) {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        final ThreadContext callContext = this.createThreadContext(entityBean);
        callContext.setCurrentOperation(Operation.UNSET_CONTEXT);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            entityBean.unsetEntityContext();
        }
        catch (RemoteException e) {
            throw new EJBException((Exception)e);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private void ejbLoad(final EntityBean entityBean) {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        final ThreadContext callContext = this.createThreadContext(entityBean);
        callContext.setCurrentOperation(Operation.LOAD);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            entityBean.ejbLoad();
        }
        catch (RemoteException e) {
            throw new EJBException((Exception)e);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
        try {
            Set<EntityBean> registeredEntities = (Set<EntityBean>)this.synchronizationRegistry.getResource(CmpContainer.ENTITIES_TO_STORE);
            if (registeredEntities == null) {
                registeredEntities = new LinkedHashSet<EntityBean>();
                this.synchronizationRegistry.putResource(CmpContainer.ENTITIES_TO_STORE, (Object)registeredEntities);
                this.synchronizationRegistry.registerInterposedSynchronization((Synchronization)new Synchronization() {
                    public void beforeCompletion() {
                        final Set<EntityBean> registeredEntities = (Set<EntityBean>)CmpContainer.this.synchronizationRegistry.getResource(CmpContainer.ENTITIES_TO_STORE);
                        if (registeredEntities == null) {
                            return;
                        }
                        for (final EntityBean entityBean : registeredEntities) {
                            CmpContainer.this.ejbStore(entityBean);
                        }
                    }
                    
                    public void afterCompletion(final int i) {
                    }
                });
            }
            registeredEntities.add(entityBean);
        }
        catch (Exception ex) {}
    }
    
    private void ejbStore(final EntityBean entityBean) {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        final ThreadContext callContext = this.createThreadContext(entityBean);
        callContext.setCurrentOperation(Operation.STORE);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            entityBean.ejbStore();
        }
        catch (RemoteException e) {
            throw new EJBException((Exception)e);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private void ejbRemove(final EntityBean entityBean) throws RemoveException {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        if (this.isDeleted(entityBean)) {
            return;
        }
        final ThreadContext callContext = this.createThreadContext(entityBean);
        callContext.setCurrentOperation(Operation.REMOVE);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            entityBean.ejbRemove();
        }
        catch (RemoteException e) {
            throw new EJBException((Exception)e);
        }
        finally {
            try {
                entityBean.getClass().getMethod("OpenEJB_deleted", (Class<?>[])new Class[0]).invoke(entityBean, new Object[0]);
            }
            catch (Exception ex) {}
            this.cancelTimers(callContext);
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private boolean isDeleted(final EntityBean entityBean) {
        try {
            return (boolean)entityBean.getClass().getMethod("OpenEJB_isDeleted", (Class<?>[])new Class[0]).invoke(entityBean, new Object[0]);
        }
        catch (NoSuchMethodException e2) {
            return false;
        }
        catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    private void ejbActivate(final EntityBean entityBean) {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        final ThreadContext callContext = this.createThreadContext(entityBean);
        callContext.setCurrentOperation(Operation.ACTIVATE);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            entityBean.ejbActivate();
        }
        catch (RemoteException e) {
            throw new EJBException((Exception)e);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private void ejbPassivate(final EntityBean entityBean) {
        if (entityBean == null) {
            throw new NullPointerException("entityBean is null");
        }
        final ThreadContext callContext = this.createThreadContext(entityBean);
        callContext.setCurrentOperation(Operation.PASSIVATE);
        final ThreadContext oldCallContext = ThreadContext.enter(callContext);
        try {
            entityBean.ejbPassivate();
        }
        catch (RemoteException e) {
            throw new EJBException((Exception)e);
        }
        finally {
            ThreadContext.exit(oldCallContext);
        }
    }
    
    private Object businessMethod(final Method callMethod, final Method runMethod, final Object[] args, final ThreadContext callContext, final InterfaceType interfaceType) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, interfaceType), callContext);
        Object returnValue = null;
        this.entrancyTracker.enter(beanContext, callContext.getPrimaryKey());
        try {
            final EntityBean bean = (EntityBean)this.cmpEngine.loadBean(callContext, callContext.getPrimaryKey());
            if (bean == null) {
                throw new NoSuchObjectException(beanContext.getDeploymentID() + " : " + callContext.getPrimaryKey());
            }
            returnValue = runMethod.invoke(bean, args);
            this.cmpEngine.storeBeanIfNoTx(callContext, bean);
            return returnValue;
        }
        catch (NoSuchObjectException e) {
            EjbTransactionUtil.handleApplicationException(txPolicy, e, false);
        }
        catch (Throwable e2) {
            if (e2 instanceof InvocationTargetException) {
                e2 = ((InvocationTargetException)e2).getTargetException();
            }
            final ExceptionType type = callContext.getBeanContext().getExceptionType(e2);
            if (type == ExceptionType.SYSTEM) {
                EjbTransactionUtil.handleSystemException(txPolicy, e2, callContext);
            }
            else {
                EjbTransactionUtil.handleApplicationException(txPolicy, e2, type == ExceptionType.APPLICATION_ROLLBACK);
            }
        }
        finally {
            this.entrancyTracker.exit(beanContext, callContext.getPrimaryKey());
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        return returnValue;
    }
    
    private Object homeMethod(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType interfaceType) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, interfaceType), callContext);
        Object returnValue = null;
        try {
            final EntityBean bean = this.createNewInstance(callContext);
            this.setEntityContext(bean);
            try {
                callContext.setCurrentOperation(Operation.HOME);
                final Method runMethod = beanContext.getMatchingBeanMethod(callMethod);
                try {
                    returnValue = runMethod.invoke(bean, args);
                }
                catch (IllegalArgumentException e) {
                    System.out.println("********************************************************");
                    System.out.println("callMethod = " + callMethod);
                    System.out.println("runMethod = " + runMethod);
                    System.out.println("bean = " + bean.getClass().getName());
                    throw e;
                }
            }
            finally {
                this.unsetEntityContext(bean);
            }
        }
        catch (Throwable e2) {
            if (e2 instanceof InvocationTargetException) {
                e2 = ((InvocationTargetException)e2).getTargetException();
            }
            final ExceptionType type = callContext.getBeanContext().getExceptionType(e2);
            if (type == ExceptionType.SYSTEM) {
                EjbTransactionUtil.handleSystemException(txPolicy, e2, callContext);
            }
            else {
                EjbTransactionUtil.handleApplicationException(txPolicy, e2, type == ExceptionType.APPLICATION_ROLLBACK);
            }
        }
        finally {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        return returnValue;
    }
    
    private ProxyInfo createEJBObject(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType interfaceType) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, interfaceType), callContext);
        Object primaryKey = null;
        try {
            final EntityBean bean = this.createNewInstance(callContext);
            this.setEntityContext(bean);
            final Method ejbCreateMethod = beanContext.getMatchingBeanMethod(callMethod);
            callContext.setCurrentOperation(Operation.CREATE);
            ejbCreateMethod.invoke(bean, args);
            primaryKey = this.cmpEngine.createBean(bean, callContext);
            final Method ejbPostCreateMethod = beanContext.getMatchingPostCreateMethod(ejbCreateMethod);
            final ThreadContext postCreateContext = new ThreadContext(beanContext, primaryKey);
            postCreateContext.setCurrentOperation(Operation.POST_CREATE);
            final ThreadContext oldContext = ThreadContext.enter(postCreateContext);
            try {
                ejbPostCreateMethod.invoke(bean, args);
            }
            finally {
                ThreadContext.exit(oldContext);
            }
            this.cmpEngine.storeBeanIfNoTx(callContext, bean);
        }
        catch (Throwable e) {
            if (e instanceof InvocationTargetException) {
                e = ((InvocationTargetException)e).getTargetException();
            }
            final ExceptionType type = callContext.getBeanContext().getExceptionType(e);
            if (type == ExceptionType.SYSTEM) {
                EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
            }
            else {
                EjbTransactionUtil.handleApplicationException(txPolicy, e, type == ExceptionType.APPLICATION_ROLLBACK);
            }
        }
        finally {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        return new ProxyInfo(beanContext, primaryKey);
    }
    
    private Object findByPrimaryKey(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType interfaceType) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, interfaceType), callContext);
        try {
            final EntityBean bean = (EntityBean)this.cmpEngine.loadBean(callContext, args[0]);
            if (bean == null) {
                throw new ObjectNotFoundException(beanContext.getDeploymentID() + " : " + args[0]);
            }
            final KeyGenerator kg = beanContext.getKeyGenerator();
            final Object primaryKey = kg.getPrimaryKey(bean);
            return new ProxyInfo(beanContext, primaryKey);
        }
        catch (FinderException fe) {
            EjbTransactionUtil.handleApplicationException(txPolicy, (Throwable)fe, false);
        }
        catch (Throwable e) {
            EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
        }
        finally {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        throw new AssertionError((Object)"Should not get here");
    }
    
    private Object findEJBObject(final Method callMethod, final Object[] args, final ThreadContext callContext, final InterfaceType interfaceType) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, interfaceType), callContext);
        try {
            final List<Object> results = this.cmpEngine.queryBeans(callContext, callMethod, args);
            final KeyGenerator kg = beanContext.getKeyGenerator();
            if (callMethod.getReturnType() == Collection.class || callMethod.getReturnType() == Enumeration.class) {
                final List<ProxyInfo> proxies = new ArrayList<ProxyInfo>();
                for (final Object value : results) {
                    final EntityBean bean = (EntityBean)value;
                    if (value == null) {
                        proxies.add(null);
                    }
                    else {
                        final Object primaryKey = kg.getPrimaryKey(bean);
                        proxies.add(new ProxyInfo(beanContext, primaryKey));
                    }
                }
                if (callMethod.getReturnType() == Enumeration.class) {
                    return new Enumerator(proxies);
                }
                return proxies;
            }
            else {
                if (results.size() != 1) {
                    throw new ObjectNotFoundException("A Enteprise bean with deployment_id = " + beanContext.getDeploymentID() + ((args != null && args.length >= 1) ? (" and primarykey = " + args[0]) : "") + " Does not exist");
                }
                final EntityBean bean2 = results.get(0);
                if (bean2 == null) {
                    return null;
                }
                final Object primaryKey2 = kg.getPrimaryKey(bean2);
                return new ProxyInfo(beanContext, primaryKey2);
            }
        }
        catch (FinderException fe) {
            EjbTransactionUtil.handleApplicationException(txPolicy, (Throwable)fe, false);
        }
        catch (Throwable e) {
            EjbTransactionUtil.handleSystemException(txPolicy, e, callContext);
        }
        finally {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
        throw new AssertionError((Object)"Should not get here");
    }
    
    public Object select(final BeanContext beanContext, final String methodSignature, final String returnType, final Object... args) throws FinderException {
        final String signature = beanContext.getAbstractSchemaName() + "." + methodSignature;
        try {
            final Collection<Object> results = this.cmpEngine.queryBeans(beanContext, signature, args);
            Collection<Object> proxies;
            if (returnType.equals("java.util.Set")) {
                proxies = new LinkedHashSet<Object>();
            }
            else {
                proxies = new ArrayList<Object>();
            }
            final boolean isSingleValued = !returnType.equals("java.util.Collection") && !returnType.equals("java.util.Set");
            ProxyFactory proxyFactory = null;
            for (Object value : results) {
                if (isSingleValued && !proxies.isEmpty()) {
                    throw new FinderException("The single valued query " + methodSignature + "returned more than one item");
                }
                if (value instanceof EntityBean) {
                    final EntityBean entityBean = (EntityBean)value;
                    if (proxyFactory == null) {
                        final BeanContext result = this.getBeanContextByClass(entityBean.getClass());
                        if (result != null) {
                            proxyFactory = new ProxyFactory(result);
                        }
                    }
                    if (proxyFactory != null) {
                        if (beanContext.isRemoteQueryResults(methodSignature)) {
                            value = proxyFactory.createRemoteProxy(entityBean, this);
                        }
                        else {
                            value = proxyFactory.createLocalProxy(entityBean, this);
                        }
                    }
                }
                proxies.add(value);
            }
            if (!isSingleValued) {
                return proxies;
            }
            if (proxies.isEmpty()) {
                throw new ObjectNotFoundException();
            }
            return proxies.iterator().next();
        }
        catch (RuntimeException e) {
            throw new EJBException((Exception)e);
        }
    }
    
    public int update(final BeanContext beanContext, final String methodSignature, final Object... args) throws FinderException {
        final String signature = beanContext.getAbstractSchemaName() + "." + methodSignature;
        return this.cmpEngine.executeUpdateQuery(beanContext, signature, args);
    }
    
    private void removeEJBObject(final Method callMethod, final ThreadContext callContext, final InterfaceType interfaceType) throws OpenEJBException {
        final BeanContext beanContext = callContext.getBeanContext();
        final TransactionPolicy txPolicy = EjbTransactionUtil.createTransactionPolicy(beanContext.getTransactionType(callMethod, interfaceType), callContext);
        try {
            final EntityBean entityBean = (EntityBean)this.cmpEngine.loadBean(callContext, callContext.getPrimaryKey());
            if (entityBean == null) {
                throw new NoSuchObjectException(callContext.getBeanContext().getDeploymentID() + " " + callContext.getPrimaryKey());
            }
            this.ejbRemove(entityBean);
            this.cmpEngine.removeBean(callContext);
        }
        catch (NoSuchObjectException e) {
            EjbTransactionUtil.handleApplicationException(txPolicy, e, false);
        }
        catch (Throwable e2) {
            EjbTransactionUtil.handleSystemException(txPolicy, e2, callContext);
        }
        finally {
            EjbTransactionUtil.afterInvoke(txPolicy, callContext);
        }
    }
    
    private void cancelTimers(final ThreadContext threadContext) {
        final BeanContext beanContext = threadContext.getBeanContext();
        final Object primaryKey = threadContext.getPrimaryKey();
        if (primaryKey != null && beanContext.getEjbTimerService() != null) {
            final EjbTimerService timerService = beanContext.getEjbTimerService();
            if (timerService != null && timerService instanceof EjbTimerServiceImpl) {
                for (final Timer timer : beanContext.getEjbTimerService().getTimers(primaryKey)) {
                    timer.cancel();
                }
            }
        }
    }
    
    static {
        ENTITIES_TO_STORE = new Object() {
            @Override
            public String toString() {
                return "EntitiesToStore";
            }
        };
    }
    
    private class ContainerCmpCallback implements CmpCallback
    {
        @Override
        public void setEntityContext(final EntityBean entity) {
            CmpContainer.this.setEntityContext(entity);
        }
        
        @Override
        public void unsetEntityContext(final EntityBean entity) {
            CmpContainer.this.unsetEntityContext(entity);
        }
        
        @Override
        public void ejbActivate(final EntityBean entity) {
            CmpContainer.this.ejbActivate(entity);
        }
        
        @Override
        public void ejbPassivate(final EntityBean entity) {
            CmpContainer.this.ejbPassivate(entity);
        }
        
        @Override
        public void ejbLoad(final EntityBean entity) {
            CmpContainer.this.ejbLoad(entity);
        }
        
        @Override
        public void ejbStore(final EntityBean entity) {
            CmpContainer.this.ejbStore(entity);
        }
        
        @Override
        public void ejbRemove(final EntityBean entity) throws RemoveException {
            CmpContainer.this.ejbRemove(entity);
        }
    }
}
