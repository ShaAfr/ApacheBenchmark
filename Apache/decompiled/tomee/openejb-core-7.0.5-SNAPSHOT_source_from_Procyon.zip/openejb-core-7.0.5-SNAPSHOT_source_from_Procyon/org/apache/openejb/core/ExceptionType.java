// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

public enum ExceptionType
{
    APPLICATION, 
    APPLICATION_ROLLBACK, 
    APPLICATION_NOT_INHERITED, 
    APPLICATION_ROLLBACK_NOT_INHERITED, 
    SYSTEM;
}
