// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.cli;

public interface Main
{
    void main(final String[] p0) throws Exception;
}
