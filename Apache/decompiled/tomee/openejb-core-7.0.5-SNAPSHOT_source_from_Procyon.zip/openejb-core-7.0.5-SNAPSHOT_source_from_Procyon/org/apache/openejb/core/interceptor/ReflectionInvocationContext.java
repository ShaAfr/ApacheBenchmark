// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core.interceptor;

import java.lang.reflect.InvocationTargetException;
import org.apache.openejb.util.Classes;
import java.lang.reflect.Constructor;
import java.util.TreeMap;
import java.util.List;
import org.apache.openejb.core.Operation;
import java.util.Map;
import java.lang.reflect.Method;
import java.util.Iterator;
import javax.interceptor.InvocationContext;

public class ReflectionInvocationContext implements InvocationContext
{
    private final Iterator<Interceptor> interceptors;
    private final Object target;
    private final Method method;
    private final Object[] parameters;
    private final Map<String, Object> contextData;
    private final Class<?>[] parameterTypes;
    private final Operation operation;
    
    public ReflectionInvocationContext(final Operation operation, final List<Interceptor> interceptors, final Object target, final Method method, final Object... parameters) {
        this.contextData = new TreeMap<String, Object>();
        if (operation == null) {
            throw new NullPointerException("operation is null");
        }
        if (interceptors == null) {
            throw new NullPointerException("interceptors is null");
        }
        if (target == null) {
            throw new NullPointerException("target is null");
        }
        this.operation = operation;
        this.interceptors = interceptors.iterator();
        this.target = target;
        this.method = method;
        this.parameters = parameters;
        if (method == null) {
            this.parameterTypes = (Class<?>[])new Class[0];
        }
        else {
            this.parameterTypes = method.getParameterTypes();
        }
    }
    
    public Object getTimer() {
        if (this.operation.equals(Operation.TIMEOUT)) {
            return this.parameters[0];
        }
        return null;
    }
    
    public Object getTarget() {
        return this.target;
    }
    
    public Method getMethod() {
        return this.method;
    }
    
    public Constructor<?> getConstructor() {
        throw new IllegalStateException();
    }
    
    public Object[] getParameters() {
        if (Operation.POST_CONSTRUCT.equals(this.operation) || Operation.PRE_DESTROY.equals(this.operation)) {
            throw new IllegalStateException(this.getIllegalParameterAccessMessage());
        }
        return this.parameters;
    }
    
    private String getIllegalParameterAccessMessage() {
        String m = "Callback methods cannot access parameters.";
        m = m + "  Callback Type: " + this.operation;
        if (this.method != null) {
            m = m + ", Target Method: " + this.method.getName();
        }
        if (this.target != null) {
            m = m + ", Target Bean: " + this.target.getClass().getName();
        }
        return m;
    }
    
    public void setParameters(final Object[] parameters) {
        if (this.operation.isCallback() && !this.operation.equals(Operation.TIMEOUT)) {
            throw new IllegalStateException(this.getIllegalParameterAccessMessage());
        }
        if (parameters == null) {
            throw new IllegalArgumentException("parameters is null");
        }
        if (parameters.length != this.parameters.length) {
            throw new IllegalArgumentException("Expected " + this.parameters.length + " parameters, but only got " + parameters.length + " parameters");
        }
        for (int i = 0; i < parameters.length; ++i) {
            final Object parameter = parameters[i];
            final Class<?> parameterType = this.parameterTypes[i];
            if (parameter == null) {
                if (parameterType.isPrimitive()) {
                    throw new IllegalArgumentException("Expected parameter " + i + " to be primitive type " + parameterType.getName() + ", but got a parameter that is null");
                }
            }
            else {
                final Class<?> actual = Classes.deprimitivize(parameterType);
                final Class<?> given = Classes.deprimitivize(parameter.getClass());
                if (!actual.isAssignableFrom(given)) {
                    throw new IllegalArgumentException("Expected parameter " + i + " to be of type " + parameterType.getName() + ", but got a parameter of type " + parameter.getClass().getName());
                }
            }
        }
        System.arraycopy(parameters, 0, this.parameters, 0, parameters.length);
    }
    
    public Map<String, Object> getContextData() {
        return this.contextData;
    }
    
    private Invocation next() {
        if (this.interceptors.hasNext()) {
            final Interceptor interceptor = this.interceptors.next();
            final Object nextInstance = interceptor.getInstance();
            final Method nextMethod = interceptor.getMethod();
            if (nextMethod.getParameterTypes().length == 1 && nextMethod.getParameterTypes()[0] == InvocationContext.class) {
                return new InterceptorInvocation(nextInstance, nextMethod, (InvocationContext)this);
            }
            return new LifecycleInvocation(nextInstance, nextMethod, (InvocationContext)this, this.parameters);
        }
        else {
            if (this.method != null) {
                Object[] methodParameters;
                if (this.operation.equals(Operation.TIMEOUT) && this.method.getParameterTypes().length == 0) {
                    methodParameters = new Object[0];
                }
                else {
                    methodParameters = this.parameters;
                }
                return new BeanInvocation(this.target, this.method, methodParameters);
            }
            return new NoOpInvocation();
        }
    }
    
    public Object proceed() throws Exception {
        try {
            final Invocation next = this.next();
            return next.invoke();
        }
        catch (InvocationTargetException e) {
            throw this.unwrapInvocationTargetException(e);
        }
    }
    
    private Exception unwrapInvocationTargetException(final InvocationTargetException e) {
        final Throwable cause = e.getCause();
        if (cause == null) {
            return e;
        }
        if (cause instanceof Exception) {
            return (Exception)cause;
        }
        if (cause instanceof Error) {
            throw (Error)cause;
        }
        throw new AssertionError((Object)cause);
    }
    
    @Override
    public String toString() {
        final String methodName = (this.method != null) ? this.method.getName() : null;
        return "InvocationContext(operation=" + this.operation + ", target=" + this.target.getClass().getName() + ", method=" + methodName + ")";
    }
    
    private abstract static class Invocation
    {
        private final Method method;
        private final Object[] args;
        private final Object target;
        
        public Invocation(final Object target, final Method method, final Object[] args) {
            this.target = target;
            this.method = method;
            this.args = args;
        }
        
        public Object invoke() throws Exception {
            final Object value = this.method.invoke(this.target, this.args);
            return value;
        }
        
        @Override
        public String toString() {
            return this.method.getDeclaringClass().getName() + "." + this.method.getName();
        }
    }
    
    private static class BeanInvocation extends Invocation
    {
        public BeanInvocation(final Object target, final Method method, final Object[] args) {
            super(target, method, args);
        }
    }
    
    private static class InterceptorInvocation extends Invocation
    {
        public InterceptorInvocation(final Object target, final Method method, final InvocationContext invocationContext) {
            super(target, method, new Object[] { invocationContext });
        }
    }
    
    private static class LifecycleInvocation extends Invocation
    {
        private final InvocationContext invocationContext;
        
        public LifecycleInvocation(final Object target, final Method method, final InvocationContext invocationContext, final Object[] args) {
            super(target, method, args);
            this.invocationContext = invocationContext;
        }
        
        @Override
        public Object invoke() throws Exception {
            super.invoke();
            final Object value = this.invocationContext.proceed();
            return value;
        }
    }
    
    private static class NoOpInvocation extends Invocation
    {
        public NoOpInvocation() {
            super(null, null, null);
        }
        
        @Override
        public Object invoke() throws IllegalAccessException, InvocationTargetException {
            return null;
        }
    }
}
