// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.core;

import javax.transaction.Synchronization;
import javax.transaction.SystemException;
import java.util.HashMap;
import javax.transaction.Transaction;
import java.util.Map;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionSynchronizationRegistry;

public class SimpleTransactionSynchronizationRegistry implements TransactionSynchronizationRegistry
{
    private final TransactionManager transactionManager;
    private final Map<Transaction, Map<Object, Object>> transactionResources;
    
    public SimpleTransactionSynchronizationRegistry(final TransactionManager transactionManager) {
        this.transactionResources = new HashMap<Transaction, Map<Object, Object>>();
        this.transactionManager = transactionManager;
    }
    
    public Transaction getTransactionKey() {
        try {
            return this.transactionManager.getTransaction();
        }
        catch (SystemException e) {
            return null;
        }
    }
    
    public Object getResource(final Object key) {
        final Transaction transaction = this.getActiveTransaction();
        final Map<Object, Object> resources = this.transactionResources.get(transaction);
        if (resources == null) {
            return null;
        }
        return resources.get(key);
    }
    
    public void putResource(final Object key, final Object value) {
        final Transaction transaction = this.getActiveTransaction();
        Map<Object, Object> resources = this.transactionResources.get(transaction);
        if (resources == null) {
            try {
                transaction.registerSynchronization((Synchronization)new RemoveTransactionResources(transaction));
            }
            catch (Exception e) {
                throw new IllegalStateException("No transaction active", e);
            }
            resources = new HashMap<Object, Object>();
            this.transactionResources.put(transaction, resources);
        }
        resources.put(key, value);
    }
    
    public int getTransactionStatus() {
        try {
            return this.transactionManager.getStatus();
        }
        catch (SystemException e) {
            return 6;
        }
    }
    
    public void registerInterposedSynchronization(final Synchronization synchronization) {
        if (synchronization == null) {
            throw new NullPointerException("synchronization is null");
        }
        final Transaction transaction = this.getActiveTransaction();
        try {
            transaction.registerSynchronization(synchronization);
        }
        catch (Exception ex) {}
    }
    
    public boolean getRollbackOnly() {
        final Transaction transaction = this.getActiveTransaction();
        try {
            return transaction.getStatus() == 1;
        }
        catch (Exception e) {
            throw new IllegalStateException("No transaction active", e);
        }
    }
    
    public void setRollbackOnly() {
        final Transaction transaction = this.getActiveTransaction();
        try {
            transaction.setRollbackOnly();
        }
        catch (Exception e) {
            throw new IllegalStateException("No transaction active", e);
        }
    }
    
    private Transaction getActiveTransaction() {
        try {
            final Transaction transaction = this.transactionManager.getTransaction();
            if (transaction == null) {
                throw new IllegalStateException("No transaction active");
            }
            final int status = transaction.getStatus();
            if (status != 0 && status != 1) {
                throw new IllegalStateException("No transaction active");
            }
            return transaction;
        }
        catch (SystemException e) {
            throw new IllegalStateException("No transaction active", (Throwable)e);
        }
    }
    
    private class RemoveTransactionResources implements Synchronization
    {
        private final Transaction transaction;
        
        public RemoveTransactionResources(final Transaction transaction) {
            this.transaction = transaction;
        }
        
        public void beforeCompletion() {
        }
        
        public void afterCompletion(final int i) {
            SimpleTransactionSynchronizationRegistry.this.transactionResources.remove(this.transaction);
        }
    }
}
