// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

public class CallbackInfo extends InfoObject
{
    public String className;
    public String method;
}
