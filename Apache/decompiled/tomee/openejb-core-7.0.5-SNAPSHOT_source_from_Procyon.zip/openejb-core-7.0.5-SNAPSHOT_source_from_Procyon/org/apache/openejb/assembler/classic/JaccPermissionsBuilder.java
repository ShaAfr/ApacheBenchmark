// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.assembler.classic;

import org.apache.openejb.util.LogCategory;
import org.apache.openejb.util.JavaSecurityManagers;
import java.util.Enumeration;
import javax.security.jacc.EJBRoleRefPermission;
import java.security.Permission;
import javax.security.jacc.EJBMethodPermission;
import org.apache.openejb.InterfaceType;
import java.util.Collection;
import java.lang.reflect.Method;
import java.util.List;
import java.util.ArrayList;
import org.apache.openejb.BeanContext;
import java.util.HashMap;
import java.util.Iterator;
import javax.security.jacc.PolicyConfiguration;
import javax.security.jacc.PolicyContextException;
import org.apache.openejb.OpenEJBException;
import java.security.PermissionCollection;
import java.util.Map;
import javax.security.jacc.PolicyConfigurationFactory;
import org.apache.openejb.loader.SystemInstance;
import org.apache.openejb.util.Logger;

public class JaccPermissionsBuilder
{
    private static final Logger log;
    
    public void install(final PolicyContext policyContext) throws OpenEJBException {
        if (SystemInstance.get().hasProperty("openejb.geronimo")) {
            return;
        }
        try {
            final PolicyConfigurationFactory factory = PolicyConfigurationFactory.getPolicyConfigurationFactory();
            final PolicyConfiguration policy = factory.getPolicyConfiguration(policyContext.getContextID(), false);
            policy.addToExcludedPolicy(policyContext.getExcludedPermissions());
            policy.addToUncheckedPolicy(policyContext.getUncheckedPermissions());
            for (final Map.Entry<String, PermissionCollection> entry : policyContext.getRolePermissions().entrySet()) {
                policy.addToRole((String)entry.getKey(), (PermissionCollection)entry.getValue());
            }
            policy.commit();
        }
        catch (ClassNotFoundException e) {
            throw new OpenEJBException("PolicyConfigurationFactory class not found", e);
        }
        catch (PolicyContextException e2) {
            throw new OpenEJBException("JACC PolicyConfiguration failed: ContextId=" + policyContext.getContextID(), (Throwable)e2);
        }
    }
    
    public PolicyContext build(final EjbJarInfo ejbJar, final HashMap<String, BeanContext> deployments) throws OpenEJBException {
        final List<MethodPermissionInfo> normalized = new ArrayList<MethodPermissionInfo>();
        List<MethodPermissionInfo> perms = ejbJar.methodPermissions;
        for (final MethodInfo info : ejbJar.excludeList) {
            final MethodPermissionInfo perm = new MethodPermissionInfo();
            perm.excluded = true;
            perm.methods.add(info);
            perms.add(perm);
        }
        perms = MethodInfoUtil.normalizeMethodPermissionInfos(perms);
        for (final BeanContext beanContext : deployments.values()) {
            final Map<Method, MethodAttributeInfo> attributes = MethodInfoUtil.resolveAttributes(perms, beanContext);
            if (JaccPermissionsBuilder.log.isDebugEnabled()) {
                for (final Map.Entry<Method, MethodAttributeInfo> entry : attributes.entrySet()) {
                    final Method method = entry.getKey();
                    final MethodPermissionInfo value = entry.getValue();
                    JaccPermissionsBuilder.log.debug("Security Attribute: " + method + " -- " + MethodInfoUtil.toString(value));
                }
            }
            for (final Map.Entry<Method, MethodAttributeInfo> entry : attributes.entrySet()) {
                final Method method = entry.getKey();
                final MethodPermissionInfo a = entry.getValue();
                final MethodPermissionInfo b = new MethodPermissionInfo();
                b.excluded = a.excluded;
                b.unchecked = a.unchecked;
                b.roleNames.addAll(a.roleNames);
                final MethodInfo am = a.methods.get(0);
                final MethodInfo bm = new MethodInfo();
                bm.ejbName = beanContext.getEjbName();
                bm.ejbDeploymentId = String.valueOf(beanContext.getDeploymentID());
                bm.methodIntf = am.methodIntf;
                bm.className = method.getDeclaringClass().getName();
                bm.methodName = method.getName();
                bm.methodParams = new ArrayList<String>();
                for (final Class<?> type : method.getParameterTypes()) {
                    bm.methodParams.add(type.getName());
                }
                b.methods.add(bm);
                normalized.add(b);
            }
        }
        ejbJar.methodPermissions.clear();
        ejbJar.methodPermissions.addAll(normalized);
        ejbJar.excludeList.clear();
        final PolicyContext policyContext = new PolicyContext(ejbJar.moduleUri.toString());
        for (final EnterpriseBeanInfo enterpriseBean : ejbJar.enterpriseBeans) {
            final BeanContext beanContext2 = deployments.get(enterpriseBean.ejbDeploymentId);
            final PermissionCollection permissions = DelegatePermissionCollection.getPermissionCollection();
            final String ejbName = enterpriseBean.ejbName;
            for (final InterfaceType type2 : InterfaceType.values()) {
                if (type2 != InterfaceType.UNKNOWN) {
                    for (final Class interfce : beanContext2.getInterfaces(type2)) {
                        this.addPossibleEjbMethodPermissions(permissions, ejbName, type2.getSpecName(), interfce);
                    }
                }
            }
            this.addPossibleEjbMethodPermissions(permissions, ejbName, null, beanContext2.getBeanClass());
            this.addDeclaredEjbPermissions(ejbJar, enterpriseBean, null, permissions, policyContext);
        }
        return policyContext;
    }
    
    private void addDeclaredEjbPermissions(final EjbJarInfo ejbJar, final EnterpriseBeanInfo beanInfo, final String defaultRole, PermissionCollection notAssigned, final PolicyContext policyContext) throws OpenEJBException {
        final PermissionCollection uncheckedPermissions = policyContext.getUncheckedPermissions();
        final PermissionCollection excludedPermissions = policyContext.getExcludedPermissions();
        final Map<String, PermissionCollection> rolePermissions = policyContext.getRolePermissions();
        final String ejbName = beanInfo.ejbName;
        for (final MethodPermissionInfo methodPermission : ejbJar.methodPermissions) {
            final List<String> roleNames = methodPermission.roleNames;
            final boolean unchecked = methodPermission.unchecked;
            final boolean excluded = methodPermission.excluded;
            for (final MethodInfo method : methodPermission.methods) {
                if (!ejbName.equals(method.ejbName)) {
                    continue;
                }
                String methodName = method.methodName;
                if ("*".equals(methodName)) {
                    methodName = null;
                }
                final String methodIntf = method.methodIntf;
                String[] methodParams;
                if (method.methodParams != null) {
                    final List<String> paramList = method.methodParams;
                    methodParams = paramList.toArray(new String[paramList.size()]);
                }
                else {
                    methodParams = null;
                }
                final EJBMethodPermission permission = new EJBMethodPermission(ejbName, methodName, methodIntf, methodParams);
                notAssigned = this.cullPermissions(notAssigned, (Permission)permission);
                if (unchecked) {
                    uncheckedPermissions.add((Permission)permission);
                }
                else if (excluded) {
                    excludedPermissions.add((Permission)permission);
                }
                else {
                    for (final String roleName : roleNames) {
                        PermissionCollection permissions = rolePermissions.get(roleName);
                        if (permissions == null) {
                            permissions = DelegatePermissionCollection.getPermissionCollection();
                            rolePermissions.put(roleName, permissions);
                        }
                        permissions.add((Permission)permission);
                    }
                }
            }
        }
        for (final SecurityRoleReferenceInfo securityRoleRef : beanInfo.securityRoleReferences) {
            if (securityRoleRef.roleLink == null) {
                throw new OpenEJBException("Missing role-link");
            }
            final String roleLink = securityRoleRef.roleLink;
            PermissionCollection roleLinks = rolePermissions.get(roleLink);
            if (roleLinks == null) {
                roleLinks = DelegatePermissionCollection.getPermissionCollection();
                rolePermissions.put(roleLink, roleLinks);
            }
            roleLinks.add((Permission)new EJBRoleRefPermission(ejbName, securityRoleRef.roleName));
        }
        PermissionCollection permissions2;
        if (defaultRole == null) {
            permissions2 = uncheckedPermissions;
        }
        else {
            permissions2 = rolePermissions.get(defaultRole);
            if (permissions2 == null) {
                permissions2 = DelegatePermissionCollection.getPermissionCollection();
                rolePermissions.put(defaultRole, permissions2);
            }
        }
        final Enumeration e = notAssigned.elements();
        while (e.hasMoreElements()) {
            final Permission p = e.nextElement();
            permissions2.add(p);
        }
    }
    
    public void addPossibleEjbMethodPermissions(final PermissionCollection permissions, final String ejbName, final String methodInterface, final Class clazz) throws OpenEJBException {
        if (clazz == null) {
            return;
        }
        for (final Method method : clazz.getMethods()) {
            final String methodIface = ("LocalBean".equals(methodInterface) || "LocalBeanHome".equals(methodInterface)) ? null : methodInterface;
            permissions.add((Permission)new EJBMethodPermission(ejbName, methodIface, method));
        }
    }
    
    private PermissionCollection cullPermissions(final PermissionCollection toBeChecked, final Permission permission) {
        final PermissionCollection result = DelegatePermissionCollection.getPermissionCollection();
        final Enumeration e = toBeChecked.elements();
        while (e.hasMoreElements()) {
            final Permission test = e.nextElement();
            if (!permission.implies(test)) {
                result.add(test);
            }
        }
        return result;
    }
    
    static {
        JavaSecurityManagers.setSystemProperty("org.apache.security.jacc.EJBMethodPermission.methodInterfaces", "BusinessLocalHome,BusinessRemoteHome,BusinessRemote,BusinessLocal");
        log = Logger.getInstance(LogCategory.OPENEJB_STARTUP.createChild("attributes"), JaccPermissionsBuilder.class);
    }
}
