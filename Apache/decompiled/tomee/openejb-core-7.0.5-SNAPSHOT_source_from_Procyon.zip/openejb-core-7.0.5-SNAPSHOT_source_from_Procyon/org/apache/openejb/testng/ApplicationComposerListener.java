// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.openejb.testng;

import org.apache.openejb.OpenEJBRuntimeException;
import org.testng.ITestResult;
import org.testng.IInvokedMethod;
import org.apache.openejb.testing.ApplicationComposers;
import org.testng.IInvokedMethodListener;

public class ApplicationComposerListener implements IInvokedMethodListener
{
    private ApplicationComposers delegate;
    
    public void beforeInvocation(final IInvokedMethod method, final ITestResult testResult) {
        this.delegate = new ApplicationComposers(method.getTestMethod().getRealClass(), new Object[0]);
        try {
            this.delegate.before(testResult.getInstance());
        }
        catch (Exception e) {
            throw new OpenEJBRuntimeException(e);
        }
    }
    
    public void afterInvocation(final IInvokedMethod method, final ITestResult testResult) {
        try {
            this.delegate.after();
        }
        catch (Exception e) {
            throw new OpenEJBRuntimeException(e);
        }
    }
}
