// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.changepwd.messages;

import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswordException;
import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswdErrorType;
import org.apache.directory.shared.kerberos.codec.KerberosDecoder;
import org.apache.directory.api.asn1.EncoderException;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.KrbPriv;
import org.apache.directory.shared.kerberos.messages.ApRep;

public class ChangePasswordReply extends AbstractPasswordMessage
{
    private ApRep applicationReply;
    private KrbPriv privateMessage;
    private short applicationReplyLen;
    private short privateMessageLen;
    private short messageLength;
    
    public ChangePasswordReply(final ApRep applicationReply, final KrbPriv privateMessage) {
        this((short)(-128), applicationReply, privateMessage);
    }
    
    public ChangePasswordReply(final short versionNumber, final ApRep applicationReply, final KrbPriv privateMessage) {
        super(versionNumber);
        this.applicationReply = applicationReply;
        this.privateMessage = privateMessage;
    }
    
    public ApRep getApplicationReply() {
        return this.applicationReply;
    }
    
    public KrbPriv getPrivateMessage() {
        return this.privateMessage;
    }
    
    @Override
    public short computeLength() {
        this.applicationReplyLen = (short)this.applicationReply.computeLength();
        this.privateMessageLen = (short)this.privateMessage.computeLength();
        return this.messageLength = (short)(6 + this.applicationReplyLen + this.privateMessageLen);
    }
    
    @Override
    public ByteBuffer encode(final ByteBuffer buf) throws EncoderException {
        buf.putShort(this.messageLength);
        buf.putShort(this.getVersionNumber());
        buf.putShort(this.applicationReplyLen);
        this.applicationReply.encode(buf);
        this.privateMessage.encode(buf);
        return buf;
    }
    
    public static ChangePasswordReply decode(final ByteBuffer buf) throws ChangePasswordException {
        try {
            final short messageLength = buf.getShort();
            final short protocolVersion = buf.getShort();
            final short encodedAppReplyLength = buf.getShort();
            final byte[] encodedAppReply = new byte[encodedAppReplyLength];
            buf.get(encodedAppReply);
            final ApRep applicationReply = KerberosDecoder.decodeApRep(encodedAppReply);
            final int privateBytesLength = messageLength - 6 - encodedAppReplyLength;
            final byte[] encodedPrivateMessage = new byte[privateBytesLength];
            buf.get(encodedPrivateMessage);
            final KrbPriv privateMessage = KerberosDecoder.decodeKrbPriv(encodedPrivateMessage);
            return new ChangePasswordReply(protocolVersion, applicationReply, privateMessage);
        }
        catch (KerberosException e) {
            throw new ChangePasswordException(ChangePasswdErrorType.KRB5_KPASSWD_MALFORMED, e);
        }
    }
}
