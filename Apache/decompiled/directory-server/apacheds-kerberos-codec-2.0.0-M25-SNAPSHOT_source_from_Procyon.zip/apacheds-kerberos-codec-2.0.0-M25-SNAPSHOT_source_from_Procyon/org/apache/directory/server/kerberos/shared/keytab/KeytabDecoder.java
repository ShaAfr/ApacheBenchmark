// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.keytab;

import java.io.UnsupportedEncodingException;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.KerberosTime;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.nio.ByteBuffer;

class KeytabDecoder
{
    byte[] getKeytabVersion(final ByteBuffer buffer) {
        final byte[] version = new byte[2];
        buffer.get(version);
        return version;
    }
    
    List<KeytabEntry> getKeytabEntries(final ByteBuffer buffer) throws IOException {
        final List<KeytabEntry> entries = new ArrayList<KeytabEntry>();
        while (buffer.remaining() > 0) {
            final int size = buffer.getInt();
            if (size < 0 || size > buffer.capacity()) {
                throw new IOException("Invalid size for the keytab entry");
            }
            final byte[] entry = new byte[size];
            buffer.get(entry);
            entries.add(this.getKeytabEntry(ByteBuffer.wrap(entry)));
        }
        return entries;
    }
    
    private KeytabEntry getKeytabEntry(final ByteBuffer buffer) throws IOException {
        final String principalName = this.getPrincipalName(buffer);
        final int principalType = buffer.getInt();
        final long time = buffer.getInt();
        final KerberosTime timeStamp = new KerberosTime(time * 1000L);
        final byte keyVersion = buffer.get();
        final EncryptionKey key = this.getKeyBlock(buffer);
        return new KeytabEntry(principalName, principalType, timeStamp, keyVersion, key);
    }
    
    private String getPrincipalName(final ByteBuffer buffer) throws IOException {
        final int count = buffer.getShort();
        final String realm = this.getCountedString(buffer);
        final StringBuffer principalNameBuffer = new StringBuffer();
        for (int ii = 0; ii < count; ++ii) {
            final String nameComponent = this.getCountedString(buffer);
            principalNameBuffer.append(nameComponent);
            if (ii < count - 1) {
                principalNameBuffer.append("/");
            }
        }
        principalNameBuffer.append("@").append(realm);
        return principalNameBuffer.toString();
    }
    
    private EncryptionKey getKeyBlock(final ByteBuffer buffer) throws IOException {
        final int type = buffer.getShort();
        final byte[] keyblock = this.getCountedBytes(buffer);
        final EncryptionType encryptionType = EncryptionType.getTypeByValue(type);
        final EncryptionKey key = new EncryptionKey(encryptionType, keyblock);
        return key;
    }
    
    private String getCountedString(final ByteBuffer buffer) throws IOException {
        final int length = buffer.getShort();
        if (length < 0 || length > buffer.capacity()) {
            throw new IOException("Invalid size for the keytab entry");
        }
        final byte[] data = new byte[length];
        buffer.get(data);
        try {
            return new String(data, "ASCII");
        }
        catch (UnsupportedEncodingException uee) {
            return "";
        }
    }
    
    private byte[] getCountedBytes(final ByteBuffer buffer) throws IOException {
        final int length = buffer.getShort();
        if (length < 0 || length > buffer.capacity()) {
            throw new IOException("Invalid size for the keytab entry");
        }
        final byte[] data = new byte[length];
        buffer.get(data);
        return data;
    }
}
