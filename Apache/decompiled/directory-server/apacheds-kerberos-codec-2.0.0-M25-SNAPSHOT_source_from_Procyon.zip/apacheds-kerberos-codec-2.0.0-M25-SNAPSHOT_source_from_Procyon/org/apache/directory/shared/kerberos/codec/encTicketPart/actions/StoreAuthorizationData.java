// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadAuthorizationData;

public class StoreAuthorizationData extends AbstractReadAuthorizationData<EncTicketPartContainer>
{
    public StoreAuthorizationData() {
        super("EncTicketPart authorization-data");
    }
    
    @Override
    protected void setAuthorizationData(final AuthorizationData authorizationData, final EncTicketPartContainer encTicketPartContainer) {
        encTicketPartContainer.getEncTicketPart().setAuthorizationData(authorizationData);
        encTicketPartContainer.setGrammarEndAllowed(true);
    }
}
