// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddress.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.util.Strings;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.hostAddress.HostAddressContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreAddress extends AbstractReadOctetString<HostAddressContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreAddress() {
        super("Store the HostAddress' address");
    }
    
    protected void setOctetString(final byte[] data, final HostAddressContainer hostAddressContainer) {
        hostAddressContainer.getHostAddress().setAddress(data);
        hostAddressContainer.setGrammarEndAllowed(true);
        if (StoreAddress.IS_DEBUG) {
            StoreAddress.LOG.debug("Address : {}", (Object)Strings.utf8ToString(data));
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreAddress.class);
        IS_DEBUG = StoreAddress.LOG.isDebugEnabled();
    }
}
