// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.tgsRep;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.TgsRep;
import org.apache.directory.shared.kerberos.codec.kdcRep.KdcRepContainer;

public class TgsRepContainer extends KdcRepContainer
{
    private TgsRep tgsRep;
    
    public TgsRepContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)TgsRepGrammar.getInstance());
        this.setTransition((Enum)TgsRepStatesEnum.START_STATE);
    }
    
    public TgsRep getTgsRep() {
        return this.tgsRep;
    }
    
    public void setTgsRep(final TgsRep tgsRep) {
        this.tgsRep = tgsRep;
    }
}
