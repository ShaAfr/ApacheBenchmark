// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafe.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.Checksum;
import org.apache.directory.shared.kerberos.codec.krbSafe.KrbSafeContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadCheckSum;

public class StoreChecksum extends AbstractReadCheckSum<KrbSafeContainer>
{
    public StoreChecksum() {
        super("KRB-SAFE cksum");
    }
    
    @Override
    protected void setChecksum(final Checksum checksum, final KrbSafeContainer krbSafeContainer) {
        krbSafeContainer.getKrbSafe().setChecksum(checksum);
        krbSafeContainer.setGrammarEndAllowed(true);
    }
}
