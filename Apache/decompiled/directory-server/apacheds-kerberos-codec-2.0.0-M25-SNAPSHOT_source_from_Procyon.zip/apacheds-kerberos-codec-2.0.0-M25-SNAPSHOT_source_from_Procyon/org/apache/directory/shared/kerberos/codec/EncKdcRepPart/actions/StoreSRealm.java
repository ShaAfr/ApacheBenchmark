// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.EncKdcRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StoreSRealm extends AbstractReadRealm<EncKdcRepPartContainer>
{
    public StoreSRealm() {
        super("EncKdcRepPart srealm value");
    }
    
    @Override
    protected void setRealm(final String srealm, final EncKdcRepPartContainer encKdcRepPartContainer) {
        encKdcRepPartContainer.getEncKdcRepPart().setSRealm(srealm);
    }
}
