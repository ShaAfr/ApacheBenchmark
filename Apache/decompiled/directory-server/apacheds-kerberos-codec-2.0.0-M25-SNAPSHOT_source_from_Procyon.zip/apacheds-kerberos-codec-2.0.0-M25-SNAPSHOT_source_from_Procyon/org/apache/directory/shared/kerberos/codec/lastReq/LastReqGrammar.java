// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.lastReq;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.lastReq.actions.StoreLrValue;
import org.apache.directory.shared.kerberos.codec.lastReq.actions.StoreLrType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.lastReq.actions.LastReqInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class LastReqGrammar extends AbstractGrammar<LastReqContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<LastReqContainer> instance;
    
    private LastReqGrammar() {
        this.setName(LastReqGrammar.class.getName());
        super.transitions = new GrammarTransition[LastReqStatesEnum.LAST_LAST_REQ_STATE.ordinal()][256];
        super.transitions[LastReqStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)LastReqStatesEnum.START_STATE, (Enum)LastReqStatesEnum.LAST_REQ_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new LastReqInit());
        super.transitions[LastReqStatesEnum.LAST_REQ_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)LastReqStatesEnum.LAST_REQ_SEQ_STATE, (Enum)LastReqStatesEnum.LAST_REQ_SEQ_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[LastReqStatesEnum.LAST_REQ_SEQ_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)LastReqStatesEnum.LAST_REQ_SEQ_SEQ_STATE, (Enum)LastReqStatesEnum.LAST_REQ_LR_TYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[LastReqStatesEnum.LAST_REQ_LR_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)LastReqStatesEnum.LAST_REQ_LR_TYPE_TAG_STATE, (Enum)LastReqStatesEnum.LAST_REQ_LR_TYPE_STATE, UniversalTag.INTEGER, (Action)new StoreLrType());
        super.transitions[LastReqStatesEnum.LAST_REQ_LR_TYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)LastReqStatesEnum.LAST_REQ_LR_TYPE_STATE, (Enum)LastReqStatesEnum.LAST_REQ_LR_VALUE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[LastReqStatesEnum.LAST_REQ_LR_VALUE_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)LastReqStatesEnum.LAST_REQ_LR_VALUE_TAG_STATE, (Enum)LastReqStatesEnum.LAST_REQ_LR_VALUE_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreLrValue());
        super.transitions[LastReqStatesEnum.LAST_REQ_LR_VALUE_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)LastReqStatesEnum.LAST_REQ_LR_VALUE_STATE, (Enum)LastReqStatesEnum.LAST_REQ_SEQ_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
    }
    
    public static Grammar<LastReqContainer> getInstance() {
        return LastReqGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)LastReqGrammar.class);
        IS_DEBUG = LastReqGrammar.LOG.isDebugEnabled();
        LastReqGrammar.instance = (Grammar<LastReqContainer>)new LastReqGrammar();
    }
}
