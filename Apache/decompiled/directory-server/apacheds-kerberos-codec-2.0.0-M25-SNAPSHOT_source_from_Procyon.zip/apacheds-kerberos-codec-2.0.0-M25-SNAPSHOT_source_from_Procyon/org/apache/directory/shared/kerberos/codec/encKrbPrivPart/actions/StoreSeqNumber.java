// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbPrivPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encKrbPrivPart.EncKrbPrivPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreSeqNumber extends AbstractReadInteger<EncKrbPrivPartContainer>
{
    public StoreSeqNumber() {
        super("EncKrbPrivPart seq-number", Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    
    protected void setIntegerValue(final int value, final EncKrbPrivPartContainer encKrbPrivPartContainer) {
        encKrbPrivPartContainer.getEncKrbPrivPart().setSeqNumber(value);
    }
}
