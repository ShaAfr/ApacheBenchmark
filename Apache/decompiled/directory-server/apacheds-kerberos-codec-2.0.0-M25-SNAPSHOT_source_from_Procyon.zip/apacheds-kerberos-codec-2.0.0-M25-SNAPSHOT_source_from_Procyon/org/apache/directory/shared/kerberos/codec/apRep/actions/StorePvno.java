// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apRep.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.apRep.ApRepContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPvno;

public class StorePvno extends AbstractReadPvno<ApRepContainer>
{
    public StorePvno() {
        super("StorePvno value");
    }
    
    @Override
    protected void setPvno(final int pvno, final ApRepContainer apRepContainer) {
        apRepContainer.getApRep().setProtocolVersionNumber(pvno);
    }
}
