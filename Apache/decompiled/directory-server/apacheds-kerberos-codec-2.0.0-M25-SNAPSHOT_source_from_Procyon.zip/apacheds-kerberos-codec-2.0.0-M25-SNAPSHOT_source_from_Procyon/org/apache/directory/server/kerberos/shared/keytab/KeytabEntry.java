// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.keytab;

import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.KerberosTime;

public class KeytabEntry
{
    private String principalName;
    private int principalType;
    private KerberosTime timeStamp;
    private byte keyVersion;
    private EncryptionKey key;
    
    public KeytabEntry(final String principalName, final int principalType, final KerberosTime timeStamp, final byte keyVersion, final EncryptionKey key) {
        this.principalName = principalName;
        this.principalType = principalType;
        this.timeStamp = timeStamp;
        this.keyVersion = keyVersion;
        this.key = key;
    }
    
    public EncryptionKey getKey() {
        return this.key;
    }
    
    public byte getKeyVersion() {
        return this.keyVersion;
    }
    
    public String getPrincipalName() {
        return this.principalName;
    }
    
    public int getPrincipalType() {
        return this.principalType;
    }
    
    public KerberosTime getTimeStamp() {
        return this.timeStamp;
    }
}
