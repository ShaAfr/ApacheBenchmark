// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbError.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.krbError.KrbErrorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreSTime extends AbstractReadKerberosTime<KrbErrorContainer>
{
    public StoreSTime() {
        super("Stores the STime");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final KrbErrorContainer krbErrorContainer) {
        krbErrorContainer.getKrbError().setSTime(krbtime);
    }
}
