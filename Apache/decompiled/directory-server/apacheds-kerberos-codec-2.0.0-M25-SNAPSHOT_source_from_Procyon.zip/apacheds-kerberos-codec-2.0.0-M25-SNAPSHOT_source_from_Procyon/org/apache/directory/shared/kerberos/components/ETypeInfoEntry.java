// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class ETypeInfoEntry implements Asn1Object
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private EncryptionType etype;
    private byte[] salt;
    private int etypeTagLength;
    private int saltTagLength;
    private int etypeInfoEntrySeqLength;
    
    public ETypeInfoEntry(final EncryptionType etype, final byte[] salt) {
        this.etype = etype;
        this.salt = salt;
    }
    
    public ETypeInfoEntry() {
    }
    
    public byte[] getSalt() {
        return this.salt;
    }
    
    public void setSalt(final byte[] salt) {
        this.salt = salt;
    }
    
    public EncryptionType getEType() {
        return this.etype;
    }
    
    public void setEType(final EncryptionType etype) {
        this.etype = etype;
    }
    
    public int computeLength() {
        final int etypeLength = BerValue.getNbBytes(this.etype.getValue());
        this.etypeTagLength = 1 + TLV.getNbBytes(etypeLength) + etypeLength;
        this.etypeInfoEntrySeqLength = 1 + TLV.getNbBytes(this.etypeTagLength) + this.etypeTagLength;
        if (this.salt != null) {
            this.saltTagLength = 1 + TLV.getNbBytes(this.salt.length) + this.salt.length;
            this.etypeInfoEntrySeqLength += 1 + TLV.getNbBytes(this.saltTagLength) + this.saltTagLength;
        }
        return 1 + TLV.getNbBytes(this.etypeInfoEntrySeqLength) + this.etypeInfoEntrySeqLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.etypeInfoEntrySeqLength));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.etypeTagLength));
            BerValue.encode(buffer, this.etype.getValue());
            if (this.salt != null) {
                buffer.put((byte)(-95));
                buffer.put(TLV.getBytes(this.saltTagLength));
                BerValue.encode(buffer, this.salt);
            }
        }
        catch (BufferOverflowException boe) {
            ETypeInfoEntry.LOG.error(I18n.err(I18n.ERR_145, new Object[] { 1 + TLV.getNbBytes(this.etypeInfoEntrySeqLength) + this.etypeInfoEntrySeqLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (ETypeInfoEntry.IS_DEBUG) {
            ETypeInfoEntry.LOG.debug("ETYPE-INFO-ENTRY encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            ETypeInfoEntry.LOG.debug("ETYPE-INFO-ENTRY initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ETYPE-INFO-ENTRY : {\n");
        sb.append("    etype: ").append(this.etype).append('\n');
        if (this.salt != null) {
            sb.append("    salt: ").append(Strings.dumpBytes(this.salt)).append('\n');
        }
        sb.append("}\n");
        return sb.toString();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfoEntry.class);
        IS_DEBUG = ETypeInfoEntry.LOG.isDebugEnabled();
    }
}
