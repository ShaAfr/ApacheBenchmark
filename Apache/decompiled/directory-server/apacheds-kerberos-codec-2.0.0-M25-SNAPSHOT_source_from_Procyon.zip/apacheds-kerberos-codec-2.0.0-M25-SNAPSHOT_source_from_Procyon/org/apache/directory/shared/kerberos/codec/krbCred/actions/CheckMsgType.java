// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCred.actions;

import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.shared.kerberos.codec.krbCred.KrbCredContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadMsgType;

public class CheckMsgType extends AbstractReadMsgType<KrbCredContainer>
{
    public CheckMsgType() {
        super("KRB-CRED msg-type", KerberosMessageType.KRB_CRED);
    }
}
