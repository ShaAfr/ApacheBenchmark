// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.principalName.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.util.Strings;
import org.apache.directory.shared.kerberos.KerberosUtils;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.principalName.PrincipalNameContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreNameString extends GrammarAction<PrincipalNameContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private static boolean ALLOW_UTF8_NAMES;
    
    public StoreNameString() {
        super("Store the PrincipalName string");
    }
    
    public void action(final PrincipalNameContainer principalNameContainer) throws DecoderException {
        final TLV tlv = principalNameContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreNameString.LOG.error(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
        }
        final PrincipalName principalName = principalNameContainer.getPrincipalName();
        final BerValue value = tlv.getValue();
        if (StoreNameString.ALLOW_UTF8_NAMES || KerberosUtils.isKerberosString(value.getData())) {
            final String nameString = Strings.utf8ToString(value.getData());
            principalName.addName(nameString);
            principalNameContainer.setGrammarEndAllowed(true);
            if (StoreNameString.IS_DEBUG) {
                StoreNameString.LOG.debug("PrincipalName String : {}", (Object)nameString);
            }
            return;
        }
        final String valBytes = Strings.dumpBytes(value.getData());
        final String valStr = Strings.utf8ToString(value.getData());
        final String valAll = valBytes + "/" + valStr;
        StoreNameString.LOG.error(I18n.err(I18n.ERR_745_NOT_A_KERBEROS_STRING, new Object[] { valAll }));
        throw new DecoderException(I18n.err(I18n.ERR_745_NOT_A_KERBEROS_STRING, new Object[] { valAll }));
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreNameString.class);
        IS_DEBUG = StoreNameString.LOG.isDebugEnabled();
        StoreNameString.ALLOW_UTF8_NAMES = false;
        final String allowUTF8Names = System.getProperty("sun.security.krb5.msinterop.kstring");
        if ("true".equalsIgnoreCase(Strings.trim(allowUTF8Names))) {
            StoreNameString.ALLOW_UTF8_NAMES = true;
        }
    }
}
