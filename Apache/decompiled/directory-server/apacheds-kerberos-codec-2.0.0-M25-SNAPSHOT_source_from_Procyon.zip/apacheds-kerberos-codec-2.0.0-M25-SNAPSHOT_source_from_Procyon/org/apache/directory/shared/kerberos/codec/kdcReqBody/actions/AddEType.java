// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.shared.kerberos.components.KdcReqBody;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.IntegerDecoderException;
import org.apache.directory.api.util.Strings;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.apache.directory.api.asn1.ber.tlv.IntegerDecoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AddEType extends GrammarAction<KdcReqBodyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AddEType() {
        super("KDC-REQ-BODY AddEType");
    }
    
    public void action(final KdcReqBodyContainer kdcReqBodyContainer) throws DecoderException {
        final TLV tlv = kdcReqBodyContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AddEType.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final KdcReqBody kdcReqBody = kdcReqBodyContainer.getKdcReqBody();
        final BerValue value = tlv.getValue();
        try {
            final int etype = IntegerDecoder.parse(value);
            final EncryptionType encryptionType = EncryptionType.getTypeByValue(etype);
            kdcReqBody.addEType(encryptionType);
            if (AddEType.IS_DEBUG) {
                AddEType.LOG.debug("EncryptionType : {}", (Object)encryptionType);
            }
        }
        catch (IntegerDecoderException ide) {
            AddEType.LOG.error(I18n.err(I18n.ERR_04070, new Object[] { Strings.dumpBytes(value.getData()), ide.getLocalizedMessage() }));
            throw new DecoderException(ide.getMessage());
        }
        kdcReqBodyContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AddEType.class);
        IS_DEBUG = AddEType.LOG.isDebugEnabled();
    }
}
