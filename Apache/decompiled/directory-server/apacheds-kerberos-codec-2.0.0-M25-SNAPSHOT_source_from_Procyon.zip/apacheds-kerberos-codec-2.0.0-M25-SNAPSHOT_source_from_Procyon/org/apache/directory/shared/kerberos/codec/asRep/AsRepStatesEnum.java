// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.asRep;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum AsRepStatesEnum implements States
{
    START_STATE, 
    AS_REP_STATE, 
    LAST_AS_REP_STATE;
    
    public String getGrammarName(final int grammar) {
        return "AS_REP_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<AsRepContainer> grammar) {
        if (grammar instanceof AsRepGrammar) {
            return "AS_REP_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == AsRepStatesEnum.LAST_AS_REP_STATE.ordinal()) ? "AS_REP_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == AsRepStatesEnum.LAST_AS_REP_STATE;
    }
    
    public AsRepStatesEnum getStartState() {
        return AsRepStatesEnum.START_STATE;
    }
}
