// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.shared.kerberos.components.KdcReqBody;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.api.util.Strings;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreFrom extends GrammarAction<KdcReqBodyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreFrom() {
        super("Stores the From");
    }
    
    public void action(final KdcReqBodyContainer kdcReqBodyContainer) throws DecoderException {
        final TLV tlv = kdcReqBodyContainer.getCurrentTLV();
        if (tlv.getLength() != 15) {
            StoreFrom.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final KdcReqBody kdcReqBody = kdcReqBodyContainer.getKdcReqBody();
        final BerValue value = tlv.getValue();
        final String date = Strings.utf8ToString(value.getData());
        try {
            final KerberosTime from = new KerberosTime(date);
            kdcReqBody.setFrom(from);
            if (StoreFrom.IS_DEBUG) {
                StoreFrom.LOG.debug("From : {}", (Object)from);
            }
        }
        catch (IllegalArgumentException iae) {
            StoreFrom.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreFrom.class);
        IS_DEBUG = StoreFrom.LOG.isDebugEnabled();
    }
}
