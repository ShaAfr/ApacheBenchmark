// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.ETypeInfo2Entry;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.ETypeInfo2EntryContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.etypeInfo2.ETypeInfo2Container;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AddETypeInfo2Entry extends GrammarAction<ETypeInfo2Container>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AddETypeInfo2Entry() {
        super("Add an ETypeInfo2Entry instance");
    }
    
    public void action(final ETypeInfo2Container eTypeInfo2Container) throws DecoderException {
        final TLV tlv = eTypeInfo2Container.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AddETypeInfo2Entry.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder etypeInfo2EntryDecoder = new Asn1Decoder();
        final ETypeInfo2EntryContainer etypeInfo2EntryContainer = new ETypeInfo2EntryContainer();
        etypeInfo2EntryContainer.setStream(eTypeInfo2Container.getStream());
        eTypeInfo2Container.rewind();
        try {
            etypeInfo2EntryDecoder.decode(eTypeInfo2Container.getStream(), (Asn1Container)etypeInfo2EntryContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        eTypeInfo2Container.updateParent();
        final ETypeInfo2Entry etypeInfo2Entry = etypeInfo2EntryContainer.getETypeInfo2Entry();
        eTypeInfo2Container.addEtypeInfo2Entry(etypeInfo2Entry);
        if (AddETypeInfo2Entry.IS_DEBUG) {
            AddETypeInfo2Entry.LOG.debug("ETYPE-INFO2-ENTRY added : {}", (Object)etypeInfo2Entry);
        }
        eTypeInfo2Container.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AddETypeInfo2Entry.class);
        IS_DEBUG = AddETypeInfo2Entry.LOG.isDebugEnabled();
    }
}
