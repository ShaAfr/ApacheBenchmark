// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbPriv;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.KrbPriv;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KrbPrivContainer extends AbstractContainer
{
    private KrbPriv krbPriv;
    
    public KrbPrivContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)KrbPrivGrammar.getInstance());
        this.setTransition((Enum)KrbPrivStatesEnum.START_STATE);
    }
    
    public KrbPriv getKrbPriv() {
        return this.krbPriv;
    }
    
    public void setKrbPriv(final KrbPriv krbPriv) {
        this.krbPriv = krbPriv;
    }
}
