// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.ticket.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StoreRealm extends AbstractReadRealm<TicketContainer>
{
    public StoreRealm() {
        super("Kerberos Ticket realm value");
    }
    
    @Override
    protected void setRealm(final String realm, final TicketContainer ticketContainer) {
        ticketContainer.getTicket().setRealm(realm);
    }
}
