// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafeBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.shared.kerberos.codec.krbSafeBody.KrbSafeBodyContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadHostAddress;

public class StoreRecipientAddress extends AbstractReadHostAddress<KrbSafeBodyContainer>
{
    public StoreRecipientAddress() {
        super("KRB-SAFE-BODY r-address");
    }
    
    @Override
    protected void setAddress(final HostAddress hostAddress, final KrbSafeBodyContainer krbSafeBodyContainer) {
        krbSafeBodyContainer.getKrbSafeBody().setRecipientAddress(hostAddress);
        krbSafeBodyContainer.setGrammarEndAllowed(true);
    }
}
