// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos;

public class KerberosAttribute
{
    public static final String KRB5_PRINCIPAL_NAME_AT = "krb5PrincipalName";
    public static final String KRB5_PRINCIPAL_NAME_AT_OID = "1.3.6.1.4.1.5322.10.1.1";
    public static final String KRB5_KEY_AT = "krb5Key";
    public static final String KRB5_KEY_AT_OID = "1.3.6.1.4.1.5322.10.1.10";
    public static final String KRB5_KEY_VERSION_NUMBER_AT = "krb5KeyVersionNumber";
    public static final String KRB5_KEY_VERSION_NUMBER_AT_OID = "1.3.6.1.4.1.5322.10.1.2";
    public static final String KRB5_ACCOUNT_DISABLED_AT = "krb5AccountDisabled";
    public static final String KRB5_ACCOUNT_DISABLED_AT_OID = "1.3.6.1.4.1.5322.10.1.13";
    public static final String KRB5_ACCOUNT_LOCKEDOUT_AT = "krb5AccountLockedOut";
    public static final String KRB5_ACCOUNT_LOCKEDOUT_AT_OID = "1.3.6.1.4.1.5322.10.1.14";
    public static final String KRB5_ACCOUNT_EXPIRATION_TIME_AT = "krb5AccountExpirationTime";
    public static final String KRB5_ACCOUNT_EXPIRATION_TIME_AT_OID = "1.3.6.1.4.1.5322.10.1.15";
    public static final String APACHE_SAM_TYPE_AT = "apacheSamType";
    public static final String APACHE_SAM_TYPE_AT_OID = "1.3.6.1.4.1.18060.0.4.1.2.9";
}
