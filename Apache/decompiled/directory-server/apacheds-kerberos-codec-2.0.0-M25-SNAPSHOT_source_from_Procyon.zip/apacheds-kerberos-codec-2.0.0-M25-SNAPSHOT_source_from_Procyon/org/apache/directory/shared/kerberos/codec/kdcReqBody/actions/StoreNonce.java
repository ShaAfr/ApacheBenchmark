// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreNonce extends AbstractReadInteger<KdcReqBodyContainer>
{
    public StoreNonce() {
        super("KDC-REQ-BODY nonce", Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    
    public void setIntegerValue(final int value, final KdcReqBodyContainer kdcReqBodyContainer) {
        kdcReqBodyContainer.getKdcReqBody().setNonce(value);
    }
}
