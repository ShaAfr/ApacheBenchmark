// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafe.actions;

import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.shared.kerberos.codec.krbSafe.KrbSafeContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadMsgType;

public class CheckMsgType extends AbstractReadMsgType<KrbSafeContainer>
{
    public CheckMsgType() {
        super("KRB-SAFE msg-type", KerberosMessageType.KRB_SAFE);
    }
}
