// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.exceptions;

import org.apache.directory.shared.kerberos.messages.KrbError;

public class KerberosException extends Exception
{
    private static final long serialVersionUID = 2968072183596955597L;
    private KrbError error;
    private final int errorCode;
    private byte[] explanatoryData;
    
    public KerberosException(final ErrorType errorType) {
        super(errorType.getMessage());
        this.errorCode = errorType.getValue();
    }
    
    public KerberosException(final KrbError error) {
        super(error.getMessageType().getMessage());
        this.errorCode = error.getErrorCode().getValue();
        this.error = error;
    }
    
    public KerberosException(final ErrorType errorType, final Throwable cause) {
        super(errorType.getMessage(), cause);
        this.errorCode = errorType.getValue();
    }
    
    public KerberosException(final ErrorType errorType, final String msg) {
        super(msg);
        this.errorCode = errorType.getValue();
    }
    
    public KerberosException(final ErrorType errorType, final String msg, final Throwable cause) {
        super(msg, cause);
        this.errorCode = errorType.getValue();
    }
    
    public KerberosException(final ErrorType errorType, final byte[] explanatoryData) {
        super(errorType.getMessage());
        this.errorCode = errorType.getValue();
        this.explanatoryData = explanatoryData;
    }
    
    public KerberosException(final ErrorType errorType, final byte[] explanatoryData, final Throwable cause) {
        super(errorType.getMessage(), cause);
        this.errorCode = errorType.getValue();
        this.explanatoryData = explanatoryData;
    }
    
    public int getErrorCode() {
        return this.errorCode;
    }
    
    public byte[] getExplanatoryData() {
        return this.explanatoryData;
    }
    
    protected KerberosException(final int errorCode, final String msg) {
        super(msg);
        this.errorCode = errorCode;
    }
    
    protected KerberosException(final int errorCode, final String msg, final Throwable cause) {
        super(msg, cause);
        this.errorCode = errorCode;
    }
    
    protected KerberosException(final int errorCode, final String msg, final byte[] explanatoryData) {
        super(msg);
        this.errorCode = errorCode;
        this.explanatoryData = explanatoryData;
    }
    
    protected KerberosException(final int errorCode, final String msg, final byte[] explanatoryData, final Throwable cause) {
        super(msg, cause);
        this.errorCode = errorCode;
        this.explanatoryData = explanatoryData;
    }
    
    public KrbError getError() {
        return this.error;
    }
}
