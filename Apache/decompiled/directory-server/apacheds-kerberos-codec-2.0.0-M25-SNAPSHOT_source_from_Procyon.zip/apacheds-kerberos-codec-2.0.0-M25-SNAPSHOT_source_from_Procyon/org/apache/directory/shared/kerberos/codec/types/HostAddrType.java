// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.types;

public enum HostAddrType
{
    NULL(0), 
    ADDRTYPE_INET(2), 
    ADDRTYPE_IMPLINK(3), 
    ADDRTYPE_CHAOS(5), 
    ADDRTYPE_XNS(6), 
    ADDRTYPE_OSI(7), 
    ADDRTYPE_DECNET(12), 
    ADDRTYPE_APPLETALK(16), 
    ADDRTYPE_NETBIOS(20), 
    ADDRTYPE_INET6(24);
    
    private final int value;
    
    private HostAddrType(final int value) {
        this.value = value;
    }
    
    public static HostAddrType getTypeByOrdinal(final int type) {
        switch (type) {
            case 0: {
                return HostAddrType.NULL;
            }
            case 2: {
                return HostAddrType.ADDRTYPE_INET;
            }
            case 3: {
                return HostAddrType.ADDRTYPE_IMPLINK;
            }
            case 5: {
                return HostAddrType.ADDRTYPE_CHAOS;
            }
            case 6: {
                return HostAddrType.ADDRTYPE_XNS;
            }
            case 7: {
                return HostAddrType.ADDRTYPE_OSI;
            }
            case 12: {
                return HostAddrType.ADDRTYPE_DECNET;
            }
            case 16: {
                return HostAddrType.ADDRTYPE_APPLETALK;
            }
            case 20: {
                return HostAddrType.ADDRTYPE_NETBIOS;
            }
            case 24: {
                return HostAddrType.ADDRTYPE_INET6;
            }
            default: {
                return HostAddrType.NULL;
            }
        }
    }
    
    public int getValue() {
        return this.value;
    }
    
    @Override
    public String toString() {
        switch (this.value) {
            case 2: {
                return "Internet(" + this.value + ")";
            }
            case 3: {
                return "Arpanet(" + this.value + ")";
            }
            case 5: {
                return "CHAOS(" + this.value + ")";
            }
            case 6: {
                return "XEROX Network Services(" + this.value + ")";
            }
            case 7: {
                return "OSI(" + this.value + ")";
            }
            case 12: {
                return "DECnet(" + this.value + ")";
            }
            case 20: {
                return "NetBios(" + this.value + ")";
            }
            case 24: {
                return "Internet Protocol V6(" + this.value + ")";
            }
            default: {
                return "null(" + this.value + ")";
            }
        }
    }
}
