// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.AddTicket;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreEncAuthorizationData;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreAddresses;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.AddEType;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.ETypeSequence;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreNonce;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreRTime;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreTill;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreFrom;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreSName;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreRealm;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreCName;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.StoreKdcOptions;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.actions.KdcReqBodyInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class KdcReqBodyGrammar extends AbstractGrammar<KdcReqBodyContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<KdcReqBodyContainer> instance;
    
    private KdcReqBodyGrammar() {
        this.setName(KdcReqBodyGrammar.class.getName());
        super.transitions = new GrammarTransition[KdcReqBodyStatesEnum.LAST_KDC_REQ_BODY_STATE.ordinal()][256];
        super.transitions[KdcReqBodyStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.START_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_KDC_OPTIONS_TAG_STATE, UniversalTag.SEQUENCE, (Action)new KdcReqBodyInit());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_KDC_OPTIONS_TAG_STATE.ordinal()][160] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_KDC_OPTIONS_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_KDC_OPTIONS_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_KDC_OPTIONS_STATE.ordinal()][UniversalTag.BIT_STRING.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_KDC_OPTIONS_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_OR_REALM_TAG_STATE, UniversalTag.BIT_STRING, (Action)new StoreKdcOptions());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_OR_REALM_TAG_STATE.ordinal()][161] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_OR_REALM_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_STATE, 161, (Action)new StoreCName());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_OR_REALM_TAG_STATE.ordinal()][162] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_OR_REALM_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_REALM_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_STATE.ordinal()][162] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_CNAME_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_REALM_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_REALM_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_REALM_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_OR_FROM_OR_TILL_TAG_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreRealm());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_OR_FROM_OR_TILL_TAG_STATE.ordinal()][163] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_OR_FROM_OR_TILL_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_STATE, 163, (Action)new StoreSName());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_OR_FROM_OR_TILL_TAG_STATE.ordinal()][164] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_OR_FROM_OR_TILL_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_FROM_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_OR_FROM_OR_TILL_TAG_STATE.ordinal()][165] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_OR_FROM_OR_TILL_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_STATE.ordinal()][164] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_FROM_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_STATE.ordinal()][165] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_SNAME_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_FROM_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_FROM_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_TAG_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreFrom());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_TAG_STATE.ordinal()][165] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_TILL_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_OR_NONCE_TAG_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreTill());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_OR_NONCE_TAG_STATE.ordinal()][166] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_OR_NONCE_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_OR_NONCE_TAG_STATE.ordinal()][167] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_OR_NONCE_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_NONCE_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_RTIME_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_NONCE_TAG_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreRTime());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_NONCE_TAG_STATE.ordinal()][167] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_NONCE_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_NONCE_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_NONCE_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_NONCE_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_TAG_STATE, UniversalTag.INTEGER, (Action)new StoreNonce());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_TAG_STATE.ordinal()][168] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_SEQ_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_SEQ_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE, UniversalTag.SEQUENCE, (Action)new ETypeSequence());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE, UniversalTag.INTEGER, (Action)new AddEType());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE.ordinal()][169] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDRESSES_STATE, 169, (Action)new StoreAddresses());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE.ordinal()][170] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ENC_AUTH_DATA_STATE, 170, (Action)new StoreEncAuthorizationData());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE.ordinal()][171] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ETYPE_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_TAG_STATE, 171, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDRESSES_STATE.ordinal()][170] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDRESSES_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ENC_AUTH_DATA_STATE, 170, (Action)new StoreEncAuthorizationData());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDRESSES_STATE.ordinal()][171] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDRESSES_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_TAG_STATE, 171, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ENC_AUTH_DATA_STATE.ordinal()][171] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ENC_AUTH_DATA_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_TAG_STATE, 171, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_TAG_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_SEQ_STATE.ordinal()][97] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_SEQ_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_STATE, 97, (Action)new AddTicket());
        super.transitions[KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_STATE.ordinal()][97] = new GrammarTransition((Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_STATE, (Enum)KdcReqBodyStatesEnum.KDC_REQ_BODY_ADDITIONAL_TICKETS_STATE, 97, (Action)new AddTicket());
    }
    
    public static Grammar<KdcReqBodyContainer> getInstance() {
        return KdcReqBodyGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KdcReqBodyGrammar.class);
        IS_DEBUG = KdcReqBodyGrammar.LOG.isDebugEnabled();
        KdcReqBodyGrammar.instance = (Grammar<KdcReqBodyContainer>)new KdcReqBodyGrammar();
    }
}
