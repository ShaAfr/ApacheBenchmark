// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import java.net.UnknownHostException;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import java.util.Arrays;
import java.net.Inet6Address;
import java.net.InetAddress;
import org.apache.directory.shared.kerberos.codec.types.HostAddrType;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class HostAddress implements Asn1Object
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private HostAddrType addrType;
    private byte[] address;
    private int addrTypeLength;
    private int addressLength;
    private int hostAddressLength;
    private int hostAddressSeqLength;
    
    public HostAddress() {
    }
    
    public HostAddress(final HostAddrType addrType, final byte[] address) {
        this.addrType = addrType;
        this.address = address;
    }
    
    public HostAddress(final InetAddress internetAddress) {
        this.addrType = ((internetAddress instanceof Inet6Address) ? HostAddrType.ADDRTYPE_INET6 : HostAddrType.ADDRTYPE_INET);
        final byte[] newAddress = internetAddress.getAddress();
        System.arraycopy(newAddress, 0, this.address = new byte[newAddress.length], 0, newAddress.length);
    }
    
    @Override
    public int hashCode() {
        int hash = 37;
        hash = hash * 17 + this.addrType.hashCode();
        if (this.address != null) {
            hash = hash * 17 + Arrays.hashCode(this.address);
        }
        return hash;
    }
    
    @Override
    public boolean equals(final Object that) {
        if (this == that) {
            return true;
        }
        if (!(that instanceof HostAddress)) {
            return false;
        }
        final HostAddress hostAddress = (HostAddress)that;
        if (this.addrType != hostAddress.addrType || (this.address != null && hostAddress.address == null) || (this.address == null && hostAddress.address != null)) {
            return false;
        }
        if (this.address != null && hostAddress.address != null) {
            if (this.address.length != hostAddress.address.length) {
                return false;
            }
            for (int ii = 0; ii < this.address.length; ++ii) {
                if (this.address[ii] != hostAddress.address[ii]) {
                    return false;
                }
            }
        }
        return true;
    }
    
    public byte[] getAddress() {
        return this.address;
    }
    
    public void setAddress(final byte[] addresse) {
        this.address = addresse;
    }
    
    public int computeLength() {
        this.addrTypeLength = 2 + BerValue.getNbBytes(this.addrType.getValue());
        this.hostAddressLength = 1 + TLV.getNbBytes(this.addrTypeLength) + this.addrTypeLength;
        if (this.address == null) {
            this.addressLength = 2;
        }
        else {
            this.addressLength = 1 + TLV.getNbBytes(this.address.length) + this.address.length;
        }
        this.hostAddressLength += 1 + TLV.getNbBytes(this.addressLength) + this.addressLength;
        return this.hostAddressSeqLength = 1 + TLV.getNbBytes(this.hostAddressLength) + this.hostAddressLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.hostAddressLength));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.addrTypeLength));
            BerValue.encode(buffer, this.addrType.getValue());
            buffer.put((byte)(-95));
            buffer.put(TLV.getBytes(this.addressLength));
            BerValue.encode(buffer, this.address);
        }
        catch (BufferOverflowException boe) {
            HostAddress.LOG.error(I18n.err(I18n.ERR_143, new Object[] { 1 + TLV.getNbBytes(this.hostAddressLength) + this.hostAddressLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (HostAddress.IS_DEBUG) {
            HostAddress.LOG.debug("Checksum encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            HostAddress.LOG.debug("Checksum initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    public HostAddrType getAddrType() {
        return this.addrType;
    }
    
    public void setAddrType(final HostAddrType addrType) {
        this.addrType = addrType;
    }
    
    public void setAddrType(final int addrType) {
        this.addrType = HostAddrType.getTypeByOrdinal(addrType);
    }
    
    @Override
    public String toString() {
        try {
            return InetAddress.getByAddress(this.address).getHostAddress();
        }
        catch (UnknownHostException uhe) {
            return "Unknow host : " + Strings.utf8ToString(this.address);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)HostAddress.class);
        IS_DEBUG = HostAddress.LOG.isDebugEnabled();
    }
}
