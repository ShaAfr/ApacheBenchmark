// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.replay;

import org.apache.directory.shared.kerberos.KerberosTime;
import javax.security.auth.kerberos.KerberosPrincipal;

public interface ReplayCache
{
    boolean isReplay(final KerberosPrincipal p0, final KerberosPrincipal p1, final KerberosTime p2, final int p3);
    
    void save(final KerberosPrincipal p0, final KerberosPrincipal p1, final KerberosTime p2, final int p3);
    
    void clear();
}
