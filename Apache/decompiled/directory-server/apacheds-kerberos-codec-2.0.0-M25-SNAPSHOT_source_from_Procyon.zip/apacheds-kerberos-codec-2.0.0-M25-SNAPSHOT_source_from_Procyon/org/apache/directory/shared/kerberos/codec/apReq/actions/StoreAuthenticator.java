// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apReq.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.codec.apReq.ApReqContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptedPart;

public class StoreAuthenticator extends AbstractReadEncryptedPart<ApReqContainer>
{
    public StoreAuthenticator() {
        super("Encrypted Authenticator");
    }
    
    @Override
    protected void setEncryptedData(final EncryptedData encryptedData, final ApReqContainer apReqContainer) {
        apReqContainer.getApReq().setAuthenticator(encryptedData);
        apReqContainer.setGrammarEndAllowed(true);
    }
}
