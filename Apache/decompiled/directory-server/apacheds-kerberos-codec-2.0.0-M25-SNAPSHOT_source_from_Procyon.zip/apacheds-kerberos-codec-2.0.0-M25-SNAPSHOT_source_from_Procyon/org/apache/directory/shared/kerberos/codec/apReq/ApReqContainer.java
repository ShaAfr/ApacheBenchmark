// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.ApReq;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ApReqContainer extends AbstractContainer
{
    private ApReq apReq;
    
    public ApReqContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)ApReqGrammar.getInstance());
        this.setTransition((Enum)ApReqStatesEnum.START_STATE);
    }
    
    public ApReq getApReq() {
        return this.apReq;
    }
    
    public void setApReq(final ApReq apReq) {
        this.apReq = apReq;
    }
}
