// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encAsRepPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum EncAsRepPartStatesEnum implements States
{
    START_STATE, 
    ENC_AS_REP_PART_STATE, 
    LAST_ENC_AS_REP_PART_STATE;
    
    public String getGrammarName(final int grammar) {
        return "ENC_AS_REP_PART_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<EncAsRepPartContainer> grammar) {
        if (grammar instanceof EncAsRepPartGrammar) {
            return "ENC_AS_REP_PART_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == EncAsRepPartStatesEnum.LAST_ENC_AS_REP_PART_STATE.ordinal()) ? "ENC_AS_REP_PART_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == EncAsRepPartStatesEnum.LAST_ENC_AS_REP_PART_STATE;
    }
    
    public EncAsRepPartStatesEnum getStartState() {
        return EncAsRepPartStatesEnum.START_STATE;
    }
}
