// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.store;

import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswordException;
import javax.security.auth.kerberos.KerberosPrincipal;

public interface PrincipalStore
{
    void changePassword(final KerberosPrincipal p0, final KerberosPrincipal p1, final String p2, final boolean p3) throws ChangePasswordException;
    
    PrincipalStoreEntry getPrincipal(final KerberosPrincipal p0) throws Exception;
}
