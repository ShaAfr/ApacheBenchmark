// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcRep.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.KdcRep;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.kdcRep.KdcRepContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreTicket extends GrammarAction<KdcRepContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreTicket() {
        super("KDC-REP Store Ticket");
    }
    
    public void action(final KdcRepContainer kdcRepContainer) throws DecoderException {
        final TLV tlv = kdcRepContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreTicket.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder ticketDecoder = new Asn1Decoder();
        final TicketContainer ticketContainer = new TicketContainer(kdcRepContainer.getStream());
        try {
            ticketDecoder.decode(kdcRepContainer.getStream(), (Asn1Container)ticketContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        kdcRepContainer.updateParent();
        final Ticket ticket = ticketContainer.getTicket();
        final KdcRep kdcRep = kdcRepContainer.getKdcRep();
        kdcRep.setTicket(ticket);
        if (StoreTicket.IS_DEBUG) {
            StoreTicket.LOG.debug("Stored ticket:  {}", (Object)ticket);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreTicket.class);
        IS_DEBUG = StoreTicket.LOG.isDebugEnabled();
    }
}
