// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.EncKdcRepPart.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.LastReq;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.lastReq.LastReqContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreLastReq extends GrammarAction<EncKdcRepPartContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreLastReq() {
        super("Store the EncKDCRepPart LastReq");
    }
    
    public final void action(final EncKdcRepPartContainer encKdcRepPartContainer) throws DecoderException {
        final TLV tlv = encKdcRepPartContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreLastReq.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder lastReqDecoder = new Asn1Decoder();
        final LastReqContainer lastReqContainer = new LastReqContainer();
        try {
            lastReqDecoder.decode(encKdcRepPartContainer.getStream(), (Asn1Container)lastReqContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        final LastReq lastReq = lastReqContainer.getLastReq();
        if (StoreLastReq.IS_DEBUG) {
            StoreLastReq.LOG.debug("LastReq : " + lastReq);
        }
        encKdcRepPartContainer.getEncKdcRepPart().setLastReq(lastReq);
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        encKdcRepPartContainer.updateParent();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreLastReq.class);
        IS_DEBUG = StoreLastReq.LOG.isDebugEnabled();
    }
}
