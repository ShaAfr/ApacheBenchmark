// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.KrbCredInfoContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreSName extends AbstractReadPrincipalName<KrbCredInfoContainer>
{
    public StoreSName() {
        super("KrbCredInfo sname");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final KrbCredInfoContainer krbCredInfoContainer) {
        krbCredInfoContainer.getKrbCredInfo().setsName(principalName);
        krbCredInfoContainer.setGrammarEndAllowed(true);
    }
}
