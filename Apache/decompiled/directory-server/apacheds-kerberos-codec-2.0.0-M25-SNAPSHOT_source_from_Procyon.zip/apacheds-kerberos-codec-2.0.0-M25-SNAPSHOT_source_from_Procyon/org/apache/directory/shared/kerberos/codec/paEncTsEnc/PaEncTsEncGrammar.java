// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.paEncTsEnc;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.paEncTsEnc.actions.StorePaUsec;
import org.apache.directory.shared.kerberos.codec.paEncTsEnc.actions.StorePaTimestamp;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.paEncTsEnc.actions.PaEncTsEncInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class PaEncTsEncGrammar extends AbstractGrammar<PaEncTsEncContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<PaEncTsEncContainer> instance;
    
    private PaEncTsEncGrammar() {
        this.setName(PaEncTsEncGrammar.class.getName());
        super.transitions = new GrammarTransition[PaEncTsEncStatesEnum.LAST_PA_ENC_TS_ENC_STATE.ordinal()][256];
        super.transitions[PaEncTsEncStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)PaEncTsEncStatesEnum.START_STATE, (Enum)PaEncTsEncStatesEnum.PA_ENC_TS_ENC_STATE, UniversalTag.SEQUENCE, (Action)new PaEncTsEncInit());
        super.transitions[PaEncTsEncStatesEnum.PA_ENC_TS_ENC_STATE.ordinal()][160] = new GrammarTransition((Enum)PaEncTsEncStatesEnum.PA_ENC_TS_ENC_STATE, (Enum)PaEncTsEncStatesEnum.PA_ENC_TS_ENC_PA_TIMESTAMP_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[PaEncTsEncStatesEnum.PA_ENC_TS_ENC_PA_TIMESTAMP_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)PaEncTsEncStatesEnum.PA_ENC_TS_ENC_PA_TIMESTAMP_TAG_STATE, (Enum)PaEncTsEncStatesEnum.PA_ENC_TS_PA_TIMESTAMP_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StorePaTimestamp());
        super.transitions[PaEncTsEncStatesEnum.PA_ENC_TS_PA_TIMESTAMP_STATE.ordinal()][161] = new GrammarTransition((Enum)PaEncTsEncStatesEnum.PA_ENC_TS_PA_TIMESTAMP_STATE, (Enum)PaEncTsEncStatesEnum.PA_ENC_TS_ENC_PA_USEC_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[PaEncTsEncStatesEnum.PA_ENC_TS_ENC_PA_USEC_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)PaEncTsEncStatesEnum.PA_ENC_TS_ENC_PA_USEC_TAG_STATE, (Enum)PaEncTsEncStatesEnum.PA_ENC_TS_ENC_PA_USEC_STATE, UniversalTag.INTEGER, (Action)new StorePaUsec());
    }
    
    public static Grammar<PaEncTsEncContainer> getInstance() {
        return PaEncTsEncGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)PaEncTsEncGrammar.class);
        IS_DEBUG = PaEncTsEncGrammar.LOG.isDebugEnabled();
        PaEncTsEncGrammar.instance = (Grammar<PaEncTsEncContainer>)new PaEncTsEncGrammar();
    }
}
