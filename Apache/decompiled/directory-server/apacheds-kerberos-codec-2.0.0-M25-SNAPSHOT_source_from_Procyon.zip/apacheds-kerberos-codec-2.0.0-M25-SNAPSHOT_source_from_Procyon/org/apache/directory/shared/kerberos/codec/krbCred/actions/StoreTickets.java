// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCred.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.krbCred.KrbCredContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreTickets extends GrammarAction<KrbCredContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public void action(final KrbCredContainer krbCredContainer) throws DecoderException {
        final TLV tlv = krbCredContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreTickets.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder decoder = new Asn1Decoder();
        final TicketContainer ticketContainer = new TicketContainer(krbCredContainer.getStream());
        krbCredContainer.rewind();
        try {
            decoder.decode(krbCredContainer.getStream(), (Asn1Container)ticketContainer);
        }
        catch (DecoderException e) {
            throw e;
        }
        final Ticket ticket = ticketContainer.getTicket();
        krbCredContainer.getKrbCred().addTicket(ticket);
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        krbCredContainer.updateParent();
        if (StoreTickets.IS_DEBUG) {
            StoreTickets.LOG.debug("Ticket : {}", (Object)ticket);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreTickets.class);
        IS_DEBUG = StoreTickets.LOG.isDebugEnabled();
    }
}
