// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apRep.actions;

import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.shared.kerberos.codec.apRep.ApRepContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadMsgType;

public class CheckMsgType extends AbstractReadMsgType<ApRepContainer>
{
    public CheckMsgType() {
        super("AP-REP msg-type", KerberosMessageType.AP_REP);
    }
}
