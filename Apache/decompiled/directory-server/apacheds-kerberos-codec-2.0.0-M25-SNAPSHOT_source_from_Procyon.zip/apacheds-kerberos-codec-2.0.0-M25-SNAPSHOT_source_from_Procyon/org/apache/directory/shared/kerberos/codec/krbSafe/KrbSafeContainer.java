// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafe;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.KrbSafe;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KrbSafeContainer extends AbstractContainer
{
    private KrbSafe krbSafe;
    
    public KrbSafeContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)KrbSafeGrammar.getInstance());
        this.setTransition((Enum)KrbSafeStatesEnum.START_STATE);
    }
    
    public KrbSafe getKrbSafe() {
        return this.krbSafe;
    }
    
    public void setKrbSafe(final KrbSafe krbSafe) {
        this.krbSafe = krbSafe;
    }
}
