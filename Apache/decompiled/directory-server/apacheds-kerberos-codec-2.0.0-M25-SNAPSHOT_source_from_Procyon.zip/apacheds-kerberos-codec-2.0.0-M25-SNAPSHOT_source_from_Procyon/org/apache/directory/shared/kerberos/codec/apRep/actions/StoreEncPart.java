// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apRep.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.codec.apRep.ApRepContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptedPart;

public class StoreEncPart extends AbstractReadEncryptedPart<ApRepContainer>
{
    public StoreEncPart() {
        super("AP-REP enc-part");
    }
    
    @Override
    protected void setEncryptedData(final EncryptedData encryptedData, final ApRepContainer apRepContainer) {
        apRepContainer.getApRep().setEncPart(encryptedData);
        apRepContainer.setGrammarEndAllowed(true);
    }
}
