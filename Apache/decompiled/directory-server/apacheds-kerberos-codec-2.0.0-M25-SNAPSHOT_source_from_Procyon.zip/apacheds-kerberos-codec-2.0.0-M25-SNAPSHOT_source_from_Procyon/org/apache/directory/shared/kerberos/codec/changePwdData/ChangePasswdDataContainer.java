// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.changePwdData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.ChangePasswdData;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ChangePasswdDataContainer extends AbstractContainer
{
    private ChangePasswdData chngPwdData;
    
    public ChangePasswdDataContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)ChangePasswdDataGrammar.getInstance());
        this.setTransition((Enum)ChangePasswdDataStatesEnum.START_STATE);
    }
    
    public ChangePasswdData getChngPwdData() {
        return this.chngPwdData;
    }
    
    public void setChngPwdData(final ChangePasswdData chngPwdData) {
        this.chngPwdData = chngPwdData;
    }
}
