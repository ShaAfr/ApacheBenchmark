// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2Entry;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.ETypeInfo2Entry;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ETypeInfo2EntryContainer extends AbstractContainer
{
    private ETypeInfo2Entry etypeInfo2Entry;
    
    public ETypeInfo2EntryContainer() {
        this.setGrammar((Grammar)ETypeInfo2EntryGrammar.getInstance());
        this.setTransition((Enum)ETypeInfo2EntryStatesEnum.START_STATE);
    }
    
    public ETypeInfo2Entry getETypeInfo2Entry() {
        return this.etypeInfo2Entry;
    }
    
    public void setETypeInfo2Entry(final ETypeInfo2Entry etypeInfo2Entry) {
        this.etypeInfo2Entry = etypeInfo2Entry;
    }
}
