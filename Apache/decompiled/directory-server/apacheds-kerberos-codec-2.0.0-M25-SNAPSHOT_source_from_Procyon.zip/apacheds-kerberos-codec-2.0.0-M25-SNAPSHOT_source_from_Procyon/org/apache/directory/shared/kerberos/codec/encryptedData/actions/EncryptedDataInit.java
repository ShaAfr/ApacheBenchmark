// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptedData.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encryptedData.EncryptedDataContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class EncryptedDataInit extends GrammarAction<EncryptedDataContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public EncryptedDataInit() {
        super("Creates a EncryptedData instance");
    }
    
    public void action(final EncryptedDataContainer encryptedDataContainer) throws DecoderException {
        final TLV tlv = encryptedDataContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            EncryptedDataInit.LOG.error(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
        }
        if (encryptedDataContainer.getEncryptedData() == null) {
            final EncryptedData encryptedData = new EncryptedData();
            encryptedDataContainer.setEncryptedData(encryptedData);
            if (EncryptedDataInit.IS_DEBUG) {
                EncryptedDataInit.LOG.debug("EncryptedData created");
            }
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncryptedDataInit.class);
        IS_DEBUG = EncryptedDataInit.LOG.isDebugEnabled();
    }
}
