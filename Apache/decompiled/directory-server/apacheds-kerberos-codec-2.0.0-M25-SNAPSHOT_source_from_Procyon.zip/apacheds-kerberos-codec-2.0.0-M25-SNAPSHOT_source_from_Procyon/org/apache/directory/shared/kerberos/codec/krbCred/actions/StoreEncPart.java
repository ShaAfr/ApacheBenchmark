// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCred.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.codec.krbCred.KrbCredContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptedPart;

public class StoreEncPart extends AbstractReadEncryptedPart<KrbCredContainer>
{
    public StoreEncPart() {
        super("KRB-CRED enc-part");
    }
    
    @Override
    protected void setEncryptedData(final EncryptedData encryptedData, final KrbCredContainer krbCredContainer) {
        krbCredContainer.getKrbCred().setEncPart(encryptedData);
        krbCredContainer.setGrammarEndAllowed(true);
    }
}
