// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.methodData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum MethodDataStatesEnum implements States
{
    START_STATE, 
    METHOD_DATA_SEQ_STATE, 
    LAST_METHOD_DATA_STATE;
    
    public String getGrammarName(final int grammar) {
        return "METHOD_DATA_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<MethodDataContainer> grammar) {
        if (grammar instanceof MethodDataGrammar) {
            return "METHOD_DATA_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == MethodDataStatesEnum.LAST_METHOD_DATA_STATE.ordinal()) ? "LAST_METHOD_DATA_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == MethodDataStatesEnum.LAST_METHOD_DATA_STATE;
    }
    
    public MethodDataStatesEnum getStartState() {
        return MethodDataStatesEnum.START_STATE;
    }
}
