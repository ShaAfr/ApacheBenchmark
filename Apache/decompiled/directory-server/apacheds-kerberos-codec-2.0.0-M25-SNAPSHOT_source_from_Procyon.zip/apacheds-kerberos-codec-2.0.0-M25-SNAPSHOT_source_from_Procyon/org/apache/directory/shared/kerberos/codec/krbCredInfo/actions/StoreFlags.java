// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.flags.TicketFlags;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.KrbCredInfoContainer;
import org.apache.directory.api.asn1.actions.AbstractReadBitString;

public class StoreFlags extends AbstractReadBitString<KrbCredInfoContainer>
{
    public StoreFlags() {
        super("KrbCredInfo flags");
    }
    
    protected void setBitString(final byte[] data, final KrbCredInfoContainer krbCredInfoContainer) {
        krbCredInfoContainer.getKrbCredInfo().setTicketFlags(new TicketFlags(data));
        krbCredInfoContainer.setGrammarEndAllowed(true);
    }
}
