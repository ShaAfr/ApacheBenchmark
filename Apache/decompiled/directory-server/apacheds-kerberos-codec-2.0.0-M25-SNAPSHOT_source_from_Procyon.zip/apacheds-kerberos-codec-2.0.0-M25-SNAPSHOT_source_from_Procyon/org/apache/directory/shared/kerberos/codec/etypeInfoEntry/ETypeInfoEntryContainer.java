// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfoEntry;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.ETypeInfoEntry;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ETypeInfoEntryContainer extends AbstractContainer
{
    private ETypeInfoEntry etypeInfoEntry;
    
    public ETypeInfoEntryContainer() {
        this.setGrammar((Grammar)ETypeInfoEntryGrammar.getInstance());
        this.setTransition((Enum)ETypeInfoEntryStatesEnum.START_STATE);
    }
    
    public ETypeInfoEntry getETypeInfoEntry() {
        return this.etypeInfoEntry;
    }
    
    public void setETypeInfoEntry(final ETypeInfoEntry etypeInfoEntry) {
        this.etypeInfoEntry = etypeInfoEntry;
    }
}
