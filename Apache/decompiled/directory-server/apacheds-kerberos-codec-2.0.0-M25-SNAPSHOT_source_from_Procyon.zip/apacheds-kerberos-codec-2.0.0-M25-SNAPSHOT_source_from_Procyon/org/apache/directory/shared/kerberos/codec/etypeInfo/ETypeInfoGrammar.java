// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.etypeInfo.actions.AddETypeInfoEntry;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class ETypeInfoGrammar extends AbstractGrammar<ETypeInfoContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<ETypeInfoContainer> instance;
    
    private ETypeInfoGrammar() {
        this.setName(ETypeInfoGrammar.class.getName());
        super.transitions = new GrammarTransition[ETypeInfoStatesEnum.LAST_ETYPE_INFO_STATE.ordinal()][256];
        super.transitions[ETypeInfoStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ETypeInfoStatesEnum.START_STATE, (Enum)ETypeInfoStatesEnum.ETYPE_INFO_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfoStatesEnum.ETYPE_INFO_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ETypeInfoStatesEnum.ETYPE_INFO_SEQ_STATE, (Enum)ETypeInfoStatesEnum.ETYPE_INFO_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new AddETypeInfoEntry());
    }
    
    public static Grammar<ETypeInfoContainer> getInstance() {
        return ETypeInfoGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfoGrammar.class);
        IS_DEBUG = ETypeInfoGrammar.LOG.isDebugEnabled();
        ETypeInfoGrammar.instance = (Grammar<ETypeInfoContainer>)new ETypeInfoGrammar();
    }
}
