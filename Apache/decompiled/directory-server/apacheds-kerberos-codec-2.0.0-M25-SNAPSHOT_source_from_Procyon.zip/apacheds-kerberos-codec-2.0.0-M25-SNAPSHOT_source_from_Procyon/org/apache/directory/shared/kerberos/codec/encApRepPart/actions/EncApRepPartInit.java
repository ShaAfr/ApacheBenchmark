// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encApRepPart.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.messages.EncApRepPart;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encApRepPart.EncApRepPartContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class EncApRepPartInit extends GrammarAction<EncApRepPartContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public EncApRepPartInit() {
        super("Creates an EncApRepPart instance");
    }
    
    public void action(final EncApRepPartContainer encApRepPartContainer) throws DecoderException {
        final TLV tlv = encApRepPartContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            EncApRepPartInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final EncApRepPart encApRepPart = new EncApRepPart();
        encApRepPartContainer.setEncApRepPart(encApRepPart);
        if (EncApRepPartInit.IS_DEBUG) {
            EncApRepPartInit.LOG.debug("EncApRepPart created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncApRepPartInit.class);
        IS_DEBUG = EncApRepPartInit.LOG.isDebugEnabled();
    }
}
