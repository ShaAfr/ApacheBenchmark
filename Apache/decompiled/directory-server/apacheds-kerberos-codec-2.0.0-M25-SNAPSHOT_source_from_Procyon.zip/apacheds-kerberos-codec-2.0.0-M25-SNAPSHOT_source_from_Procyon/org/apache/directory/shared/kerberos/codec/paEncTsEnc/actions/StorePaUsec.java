// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.paEncTsEnc.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.paEncTsEnc.PaEncTsEncContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StorePaUsec extends AbstractReadInteger<PaEncTsEncContainer>
{
    public StorePaUsec() {
        super("EncApRepPart pausec", 0, 999999);
    }
    
    protected void setIntegerValue(final int value, final PaEncTsEncContainer paEncTsEncContainer) {
        paEncTsEncContainer.getPaEncTsEnc().setPausec(value);
        paEncTsEncContainer.setGrammarEndAllowed(true);
    }
}
