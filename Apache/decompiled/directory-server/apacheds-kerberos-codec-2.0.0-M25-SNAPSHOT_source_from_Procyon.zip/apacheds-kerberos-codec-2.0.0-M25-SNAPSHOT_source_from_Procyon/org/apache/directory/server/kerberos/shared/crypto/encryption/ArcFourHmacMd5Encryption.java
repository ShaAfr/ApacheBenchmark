// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import javax.crypto.SecretKey;
import java.security.GeneralSecurityException;
import java.security.Key;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Mac;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;

class ArcFourHmacMd5Encryption extends EncryptionEngine
{
    public EncryptionType getEncryptionType() {
        return EncryptionType.RC4_HMAC;
    }
    
    public int getChecksumLength() {
        return 16;
    }
    
    public int getConfounderLength() {
        return 8;
    }
    
    public byte[] getDecryptedData(final EncryptionKey key, final EncryptedData data, final KeyUsage usage) throws KerberosException {
        return data.getCipher();
    }
    
    public EncryptedData getEncryptedData(final EncryptionKey key, final byte[] plainText, final KeyUsage usage) {
        return new EncryptedData(this.getEncryptionType(), key.getKeyVersion(), plainText);
    }
    
    public byte[] encrypt(final byte[] plainText, final byte[] keyBytes) {
        return this.processCipher(true, plainText, keyBytes);
    }
    
    public byte[] decrypt(final byte[] cipherText, final byte[] keyBytes) {
        return this.processCipher(false, cipherText, keyBytes);
    }
    
    public byte[] calculateIntegrity(final byte[] data, final byte[] key, final KeyUsage usage) {
        try {
            final Mac digester = Mac.getInstance("HmacMD5");
            return digester.doFinal(data);
        }
        catch (NoSuchAlgorithmException nsae) {
            return null;
        }
    }
    
    private byte[] processCipher(final boolean isEncrypt, final byte[] data, final byte[] keyBytes) {
        try {
            final Cipher cipher = Cipher.getInstance("ARCFOUR");
            final SecretKey key = new SecretKeySpec(keyBytes, "ARCFOUR");
            if (isEncrypt) {
                cipher.init(1, key);
            }
            else {
                cipher.init(2, key);
            }
            return cipher.doFinal(data);
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
}
