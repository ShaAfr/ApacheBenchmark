// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafe.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.KrbSafeBody;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbSafeBody.KrbSafeBodyContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.krbSafe.KrbSafeContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreSafeBody extends GrammarAction<KrbSafeContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreSafeBody() {
        super("KRB-SAFE safe-body");
    }
    
    public void action(final KrbSafeContainer krbSafeContainer) throws DecoderException {
        final TLV tlv = krbSafeContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreSafeBody.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder krbSafeBodyDecoder = new Asn1Decoder();
        final KrbSafeBodyContainer krbSafeBodyContainer = new KrbSafeBodyContainer();
        krbSafeBodyContainer.setStream(krbSafeContainer.getStream());
        try {
            krbSafeBodyDecoder.decode(krbSafeContainer.getStream(), (Asn1Container)krbSafeBodyContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        final KrbSafeBody krbSafeBody = krbSafeBodyContainer.getKrbSafeBody();
        if (StoreSafeBody.IS_DEBUG) {
            StoreSafeBody.LOG.debug("KrbSafeBody : {}", (Object)krbSafeBody);
        }
        krbSafeContainer.getKrbSafe().setSafeBody(krbSafeBody);
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        krbSafeContainer.updateParent();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreSafeBody.class);
        IS_DEBUG = StoreSafeBody.LOG.isDebugEnabled();
    }
}
