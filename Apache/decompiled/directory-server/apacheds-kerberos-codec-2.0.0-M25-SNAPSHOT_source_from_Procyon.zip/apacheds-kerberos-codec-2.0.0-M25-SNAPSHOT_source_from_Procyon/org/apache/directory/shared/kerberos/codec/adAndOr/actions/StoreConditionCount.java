// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adAndOr.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.adAndOr.AdAndOrContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreConditionCount extends AbstractReadInteger<AdAndOrContainer>
{
    public StoreConditionCount() {
        super("AdAndOr condition count");
    }
    
    protected void setIntegerValue(final int value, final AdAndOrContainer adAndOrContainer) {
        adAndOrContainer.getAdAndOr().setConditionCount(value);
    }
}
