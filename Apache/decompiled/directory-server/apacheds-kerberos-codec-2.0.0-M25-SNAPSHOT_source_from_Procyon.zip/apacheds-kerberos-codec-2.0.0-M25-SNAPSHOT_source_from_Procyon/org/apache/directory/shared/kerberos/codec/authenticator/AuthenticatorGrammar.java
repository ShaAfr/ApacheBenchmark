// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreSeqNumber;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreAuthorizationData;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreSubKey;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreCTime;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreCusec;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreChecksum;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreCName;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreCRealm;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.StoreAuthenticatorVno;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.authenticator.actions.AuthenticatorInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class AuthenticatorGrammar extends AbstractGrammar<AuthenticatorContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<AuthenticatorContainer> instance;
    
    private AuthenticatorGrammar() {
        this.setName(AuthenticatorGrammar.class.getName());
        super.transitions = new GrammarTransition[AuthenticatorStatesEnum.LAST_AUTHENTICATOR_STATE.ordinal()][256];
        super.transitions[AuthenticatorStatesEnum.START_STATE.ordinal()][98] = new GrammarTransition((Enum)AuthenticatorStatesEnum.START_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_STATE, 98, (Action)new AuthenticatorInit());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_AUTHENTICATOR_VNO_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_AUTHENTICATOR_VNO_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_AUTHENTICATOR_VNO_TAG_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_AUTHENTICATOR_VNO_STATE, UniversalTag.INTEGER, (Action)new StoreAuthenticatorVno());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_AUTHENTICATOR_VNO_STATE.ordinal()][161] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_AUTHENTICATOR_VNO_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CREALM_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CREALM_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CREALM_TAG_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CREALM_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreCRealm());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CREALM_STATE.ordinal()][162] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CREALM_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CNAME_STATE, 162, (Action)new StoreCName());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CNAME_STATE.ordinal()][163] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CNAME_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CKSUM_STATE, 163, (Action)new StoreChecksum());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CNAME_STATE.ordinal()][164] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CNAME_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CUSEC_TAG_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CKSUM_STATE.ordinal()][164] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CKSUM_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CUSEC_TAG_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CUSEC_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CUSEC_TAG_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CUSEC_STATE, UniversalTag.INTEGER, (Action)new StoreCusec());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CUSEC_STATE.ordinal()][165] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CUSEC_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_TAG_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_TAG_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreCTime());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_STATE.ordinal()][166] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SUBKEY_STATE, 166, (Action)new StoreSubKey());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_STATE.ordinal()][167] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_NUMBER_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_STATE.ordinal()][168] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_CTIME_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_AUTHORIZATION_DATA_STATE, 168, (Action)new StoreAuthorizationData());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_SUBKEY_STATE.ordinal()][167] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SUBKEY_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_NUMBER_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_SUBKEY_STATE.ordinal()][168] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SUBKEY_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_AUTHORIZATION_DATA_STATE, 168, (Action)new StoreAuthorizationData());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_NUMBER_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_NUMBER_TAG_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_NUMBER_STATE, UniversalTag.INTEGER, (Action)new StoreSeqNumber());
        super.transitions[AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_NUMBER_STATE.ordinal()][168] = new GrammarTransition((Enum)AuthenticatorStatesEnum.AUTHENTICATOR_SEQ_NUMBER_STATE, (Enum)AuthenticatorStatesEnum.AUTHENTICATOR_AUTHORIZATION_DATA_STATE, 168, (Action)new StoreAuthorizationData());
    }
    
    public static Grammar<AuthenticatorContainer> getInstance() {
        return AuthenticatorGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AuthenticatorGrammar.class);
        IS_DEBUG = AuthenticatorGrammar.LOG.isDebugEnabled();
        AuthenticatorGrammar.instance = (Grammar<AuthenticatorContainer>)new AuthenticatorGrammar();
    }
}
