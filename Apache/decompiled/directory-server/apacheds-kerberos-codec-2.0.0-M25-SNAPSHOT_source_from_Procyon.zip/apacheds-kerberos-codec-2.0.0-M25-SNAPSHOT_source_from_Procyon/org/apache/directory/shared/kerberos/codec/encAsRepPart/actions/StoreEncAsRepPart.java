// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encAsRepPart.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.EncKdcRepPart;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encAsRepPart.EncAsRepPartContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreEncAsRepPart extends GrammarAction<EncAsRepPartContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreEncAsRepPart() {
        super("Add an EncAsRepPart instance");
    }
    
    public void action(final EncAsRepPartContainer encAsRepPartContainer) throws DecoderException {
        final TLV tlv = encAsRepPartContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreEncAsRepPart.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder encKdcRepPartDecoder = new Asn1Decoder();
        final EncKdcRepPartContainer encKdcRepPartContainer = new EncKdcRepPartContainer(encAsRepPartContainer.getStream());
        try {
            encKdcRepPartDecoder.decode(encAsRepPartContainer.getStream(), (Asn1Container)encKdcRepPartContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        encAsRepPartContainer.updateParent();
        final EncKdcRepPart encKdcRepPart = encKdcRepPartContainer.getEncKdcRepPart();
        encAsRepPartContainer.getEncAsRepPart().setEncKdcRepPart(encKdcRepPart);
        if (StoreEncAsRepPart.IS_DEBUG) {
            StoreEncAsRepPart.LOG.debug("EncAsRepPart : {}", (Object)encKdcRepPart);
        }
        encAsRepPartContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreEncAsRepPart.class);
        IS_DEBUG = StoreEncAsRepPart.LOG.isDebugEnabled();
    }
}
