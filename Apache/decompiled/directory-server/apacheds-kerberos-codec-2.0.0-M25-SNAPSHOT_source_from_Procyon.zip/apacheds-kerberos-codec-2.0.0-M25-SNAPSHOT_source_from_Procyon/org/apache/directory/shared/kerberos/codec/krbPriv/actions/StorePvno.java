// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbPriv.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbPriv.KrbPrivContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPvno;

public class StorePvno extends AbstractReadPvno<KrbPrivContainer>
{
    public StorePvno() {
        super("KRB-PRIV pvno");
    }
    
    @Override
    protected void setPvno(final int pvno, final KrbPrivContainer krbPrivContainer) {
        krbPrivContainer.getKrbPriv().setProtocolVersionNumber(pvno);
    }
}
