// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.components.EncTicketPart;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncTicketPartContainer extends AbstractContainer
{
    private EncTicketPart encTicketPart;
    
    public EncTicketPartContainer(final ByteBuffer stream) {
        super(stream);
        this.encTicketPart = new EncTicketPart();
        this.setGrammar((Grammar)EncTicketPartGrammar.getInstance());
        this.setTransition((Enum)EncTicketPartStatesEnum.START_STATE);
    }
    
    public EncTicketPart getEncTicketPart() {
        return this.encTicketPart;
    }
    
    public void setEncTicketPart(final EncTicketPart encTicketPart) {
        this.encTicketPart = encTicketPart;
    }
}
