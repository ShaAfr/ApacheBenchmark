// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.KrbCredInfoContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StorePRealm extends AbstractReadRealm<KrbCredInfoContainer>
{
    public StorePRealm() {
        super("KrbCredInfo prealm value");
    }
    
    @Override
    protected void setRealm(final String realm, final KrbCredInfoContainer krbCredInfoContainer) {
        krbCredInfoContainer.getKrbCredInfo().setpRealm(realm);
        krbCredInfoContainer.setGrammarEndAllowed(true);
    }
}
