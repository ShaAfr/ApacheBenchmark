// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo;

import org.apache.directory.shared.kerberos.components.ETypeInfoEntry;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.ETypeInfo;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ETypeInfoContainer extends AbstractContainer
{
    private ETypeInfo etypeInfo;
    
    public ETypeInfoContainer() {
        this.etypeInfo = new ETypeInfo();
        this.setGrammar((Grammar)ETypeInfoGrammar.getInstance());
        this.setTransition((Enum)ETypeInfoStatesEnum.START_STATE);
    }
    
    public ETypeInfo getETypeInfo() {
        return this.etypeInfo;
    }
    
    public void setETypeInfo(final ETypeInfo etypeInfo) {
        this.etypeInfo = etypeInfo;
    }
    
    public void addEtypeInfoEntry(final ETypeInfoEntry etypeInfoEntry) {
        this.etypeInfo.addETypeInfoEntry(etypeInfoEntry);
    }
}
