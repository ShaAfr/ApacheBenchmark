// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class MethodData implements Asn1Object
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private List<PaData> paDatas;
    private int methodDataLength;
    
    public MethodData() {
        this.paDatas = new ArrayList<PaData>();
    }
    
    public void addPaData(final PaData paData) {
        this.paDatas.add(paData);
    }
    
    public boolean contains(final PaData paData) {
        return this.paDatas != null && this.paDatas.contains(paData);
    }
    
    @Override
    public int hashCode() {
        int hash = 37;
        if (this.paDatas != null) {
            hash = hash * 17 + this.paDatas.size();
            for (final PaData paData : this.paDatas) {
                hash = hash * 17 + paData.hashCode();
            }
        }
        return hash;
    }
    
    public boolean equals(final MethodData that) {
        if (that == null) {
            return false;
        }
        if (this.paDatas.size() != that.paDatas.size()) {
            return false;
        }
        for (int i = 0; i < this.paDatas.size(); ++i) {
            if (!this.paDatas.get(i).equals(that.paDatas.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    public PaData[] getPaDatas() {
        return this.paDatas.toArray(new PaData[0]);
    }
    
    public int computeLength() {
        this.methodDataLength = 0;
        if (this.paDatas != null && this.paDatas.size() != 0) {
            for (final PaData paData : this.paDatas) {
                final int length = paData.computeLength();
                this.methodDataLength += length;
            }
        }
        return 1 + TLV.getNbBytes(this.methodDataLength) + this.methodDataLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.methodDataLength));
            if (this.paDatas != null && this.paDatas.size() != 0) {
                for (final PaData paData : this.paDatas) {
                    paData.encode(buffer);
                }
            }
        }
        catch (BufferOverflowException boe) {
            MethodData.LOG.error(I18n.err(I18n.ERR_144, new Object[] { 1 + TLV.getNbBytes(this.methodDataLength) + this.methodDataLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (MethodData.IS_DEBUG) {
            MethodData.LOG.debug("METHOD-DATA encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            MethodData.LOG.debug("METHOD-DATA initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        boolean isFirst = true;
        sb.append("METHOD-DATA : ");
        for (final PaData paData : this.paDatas) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sb.append(", ");
            }
            sb.append(paData.toString());
        }
        return sb.toString();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)MethodData.class);
        IS_DEBUG = MethodData.LOG.isDebugEnabled();
    }
}
