// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.lastReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.LastReq;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class LastReqContainer extends AbstractContainer
{
    private LastReq lastReq;
    
    public LastReqContainer() {
        this.setGrammar((Grammar)LastReqGrammar.getInstance());
        this.setTransition((Enum)LastReqStatesEnum.START_STATE);
    }
    
    public LastReq getLastReq() {
        return this.lastReq;
    }
    
    public void setLastReq(final LastReq lastReq) {
        this.lastReq = lastReq;
    }
}
