// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcRep;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum KdcRepStatesEnum implements States
{
    START_STATE, 
    KDC_REP_SEQ_STATE, 
    KDC_REP_PVNO_TAG_STATE, 
    KDC_REP_PVNO_STATE, 
    KDC_REP_MSG_TYPE_TAG_STATE, 
    KDC_REP_MSG_TYPE_STATE, 
    KDC_REP_PA_DATA_TAG_STATE, 
    KDC_REP_PA_DATA_STATE, 
    KDC_REP_CREALM_TAG_STATE, 
    KDC_REP_CREALM_STATE, 
    KDC_REP_CNAME_STATE, 
    KDC_REP_TICKET_STATE, 
    KDC_REP_ENC_PART_STATE, 
    LAST_KDC_REP_STATE;
    
    public String getGrammarName(final int grammar) {
        return "KDC_REP_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<KdcRepContainer> grammar) {
        if (grammar instanceof KdcRepGrammar) {
            return "KDC_REP_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == KdcRepStatesEnum.LAST_KDC_REP_STATE.ordinal()) ? "KDC_REP_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == KdcRepStatesEnum.LAST_KDC_REP_STATE;
    }
    
    public KdcRepStatesEnum getStartState() {
        return KdcRepStatesEnum.START_STATE;
    }
}
