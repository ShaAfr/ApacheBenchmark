// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import java.util.Iterator;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class ETypeInfo2 implements Asn1Object
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private List<ETypeInfo2Entry> etypeInfo2Entries;
    private int etypeInfo2Length;
    
    public ETypeInfo2() {
        this.etypeInfo2Entries = new ArrayList<ETypeInfo2Entry>();
    }
    
    public ETypeInfo2(final ETypeInfo2Entry[] etypeInfo2Entries) {
        if (etypeInfo2Entries == null) {
            this.etypeInfo2Entries = new ArrayList<ETypeInfo2Entry>();
        }
        else {
            this.etypeInfo2Entries = Arrays.asList(etypeInfo2Entries);
        }
    }
    
    public void addETypeInfo2Entry(final ETypeInfo2Entry etypeInfo2Entry) {
        this.etypeInfo2Entries.add(etypeInfo2Entry);
    }
    
    public boolean contains(final ETypeInfo2Entry etypeInfo2Entry) {
        return this.etypeInfo2Entries != null && this.etypeInfo2Entries.contains(etypeInfo2Entry);
    }
    
    @Override
    public int hashCode() {
        int hash = 37;
        if (this.etypeInfo2Entries != null) {
            hash = hash * 17 + this.etypeInfo2Entries.size();
            for (final ETypeInfo2Entry etypeInfo2Entry : this.etypeInfo2Entries) {
                hash = hash * 17 + etypeInfo2Entry.hashCode();
            }
        }
        return hash;
    }
    
    public boolean equals(final ETypeInfo2 that) {
        if (that == null) {
            return false;
        }
        if (this.etypeInfo2Entries.size() != that.etypeInfo2Entries.size()) {
            return false;
        }
        for (int i = 0; i < this.etypeInfo2Entries.size(); ++i) {
            if (!this.etypeInfo2Entries.get(i).equals(that.etypeInfo2Entries.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    public ETypeInfo2Entry[] getETypeInfo2Entries() {
        return this.etypeInfo2Entries.toArray(new ETypeInfo2Entry[0]);
    }
    
    public int computeLength() {
        this.etypeInfo2Length = 0;
        if (this.etypeInfo2Entries != null && this.etypeInfo2Entries.size() != 0) {
            for (final ETypeInfo2Entry info2Entry : this.etypeInfo2Entries) {
                final int length = info2Entry.computeLength();
                this.etypeInfo2Length += length;
            }
        }
        return 1 + TLV.getNbBytes(this.etypeInfo2Length) + this.etypeInfo2Length;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.etypeInfo2Length));
            if (this.etypeInfo2Entries != null && this.etypeInfo2Entries.size() != 0) {
                for (final ETypeInfo2Entry info2Entry : this.etypeInfo2Entries) {
                    info2Entry.encode(buffer);
                }
            }
        }
        catch (BufferOverflowException boe) {
            ETypeInfo2.LOG.error(I18n.err(I18n.ERR_144, new Object[] { 1 + TLV.getNbBytes(this.etypeInfo2Length) + this.etypeInfo2Length, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (ETypeInfo2.IS_DEBUG) {
            ETypeInfo2.LOG.debug("ETYPE-INFO encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            ETypeInfo2.LOG.debug("ETYPE-INFO initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        boolean isFirst = true;
        for (final ETypeInfo2Entry info2Entry : this.etypeInfo2Entries) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sb.append(", ");
            }
            sb.append(info2Entry.toString());
        }
        return sb.toString();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfo2.class);
        IS_DEBUG = ETypeInfo2.LOG.isDebugEnabled();
    }
}
