// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafe;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum KrbSafeStatesEnum implements States
{
    START_STATE, 
    KRB_SAFE_TAG_STATE, 
    KRB_SAFE_SEQ_STATE, 
    KRB_SAFE_PVNO_TAG_STATE, 
    KRB_SAFE_PVNO_STATE, 
    KRB_SAFE_MSGTYPE_TAG_STATE, 
    KRB_SAFE_MSGTYPE_STATE, 
    KRB_SAFE_SAFE_BODY_TAG_STATE, 
    KRB_SAFE_CKSUM_TAG_STATE, 
    LAST_KRB_SAFE_STATE;
    
    public String getGrammarName(final int grammar) {
        return "KRB_SAFE_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<KrbSafeContainer> grammar) {
        if (grammar instanceof KrbSafeGrammar) {
            return "KRB_SAFE_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == KrbSafeStatesEnum.LAST_KRB_SAFE_STATE.ordinal()) ? "LAST_KRB_SAFE_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == KrbSafeStatesEnum.LAST_KRB_SAFE_STATE;
    }
    
    public KrbSafeStatesEnum getStartState() {
        return KrbSafeStatesEnum.START_STATE;
    }
}
