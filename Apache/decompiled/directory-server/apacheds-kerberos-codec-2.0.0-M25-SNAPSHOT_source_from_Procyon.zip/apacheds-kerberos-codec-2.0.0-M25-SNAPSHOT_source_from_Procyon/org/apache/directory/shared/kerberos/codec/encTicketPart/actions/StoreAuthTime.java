// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreAuthTime extends AbstractReadKerberosTime<EncTicketPartContainer>
{
    public StoreAuthTime() {
        super("Stores the authtime");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final EncTicketPartContainer encTicketPartContainer) {
        encTicketPartContainer.getEncTicketPart().setAuthTime(krbtime);
    }
}
