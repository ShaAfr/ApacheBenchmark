// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.KrbCredInfoContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreEndTime extends AbstractReadKerberosTime<KrbCredInfoContainer>
{
    public StoreEndTime() {
        super("KrbCredInfo endtime");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final KrbCredInfoContainer krbCredInfoContainer) {
        krbCredInfoContainer.getKrbCredInfo().setEndTime(krbtime);
        krbCredInfoContainer.setGrammarEndAllowed(true);
    }
}
