// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.changepwd.io;

import java.nio.InvalidMarkException;
import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswordException;
import org.apache.directory.server.kerberos.changepwd.messages.ChangePasswordError;
import org.apache.directory.server.kerberos.changepwd.messages.ChangePasswordReply;
import org.apache.directory.server.kerberos.changepwd.messages.ChangePasswordRequest;
import org.apache.directory.server.kerberos.changepwd.messages.AbstractPasswordMessage;
import java.nio.ByteBuffer;

public class ChangePasswordDecoder
{
    public static AbstractPasswordMessage decode(final ByteBuffer buf, final boolean isTcp) throws ChangePasswordException {
        if (isTcp) {
            buf.getInt();
            buf.mark();
        }
        try {
            return ChangePasswordRequest.decode(buf);
        }
        catch (Exception e) {
            resetOrRewind(buf);
            try {
                return ChangePasswordReply.decode(buf);
            }
            catch (Exception e) {
                resetOrRewind(buf);
                return ChangePasswordError.decode(buf);
            }
        }
    }
    
    private static void resetOrRewind(final ByteBuffer buf) {
        try {
            buf.reset();
        }
        catch (InvalidMarkException e) {
            buf.rewind();
        }
    }
}
