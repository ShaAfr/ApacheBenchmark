// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbPrivPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.components.EncKrbPrivPart;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncKrbPrivPartContainer extends AbstractContainer
{
    private EncKrbPrivPart encKrbPrivPart;
    
    public EncKrbPrivPartContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)EncKrbPrivPartGrammar.getInstance());
        this.setTransition((Enum)EncKrbPrivPartStatesEnum.START_STATE);
    }
    
    public EncKrbPrivPart getEncKrbPrivPart() {
        return this.encKrbPrivPart;
    }
    
    public void setEncKrbPrivPart(final EncKrbPrivPart encKrbPrivPart) {
        this.encKrbPrivPart = encKrbPrivPart;
    }
}
