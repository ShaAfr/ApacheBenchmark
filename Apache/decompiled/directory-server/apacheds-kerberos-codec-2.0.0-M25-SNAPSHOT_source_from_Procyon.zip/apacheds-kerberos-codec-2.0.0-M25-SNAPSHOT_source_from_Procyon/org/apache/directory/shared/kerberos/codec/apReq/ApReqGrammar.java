// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apReq;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.apReq.actions.StoreAuthenticator;
import org.apache.directory.shared.kerberos.codec.apReq.actions.StoreTicket;
import org.apache.directory.shared.kerberos.codec.apReq.actions.StoreApOptions;
import org.apache.directory.shared.kerberos.codec.apReq.actions.CheckMsgType;
import org.apache.directory.shared.kerberos.codec.apReq.actions.StorePvno;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.apReq.actions.ApReqInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class ApReqGrammar extends AbstractGrammar<ApReqContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<ApReqContainer> instance;
    
    private ApReqGrammar() {
        this.setName(ApReqGrammar.class.getName());
        super.transitions = new GrammarTransition[ApReqStatesEnum.LAST_AP_REQ_STATE.ordinal()][256];
        super.transitions[ApReqStatesEnum.START_STATE.ordinal()][110] = new GrammarTransition((Enum)ApReqStatesEnum.START_STATE, (Enum)ApReqStatesEnum.AP_REQ_STATE, 110, (Action)new ApReqInit());
        super.transitions[ApReqStatesEnum.AP_REQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_STATE, (Enum)ApReqStatesEnum.AP_REQ_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[ApReqStatesEnum.AP_REQ_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_SEQ_STATE, (Enum)ApReqStatesEnum.AP_REQ_PVNO_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[ApReqStatesEnum.AP_REQ_PVNO_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_PVNO_TAG_STATE, (Enum)ApReqStatesEnum.AP_REQ_PVNO_STATE, UniversalTag.INTEGER, (Action)new StorePvno());
        super.transitions[ApReqStatesEnum.AP_REQ_PVNO_STATE.ordinal()][161] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_PVNO_STATE, (Enum)ApReqStatesEnum.AP_REQ_MSG_TYPE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[ApReqStatesEnum.AP_REQ_MSG_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_MSG_TYPE_TAG_STATE, (Enum)ApReqStatesEnum.AP_REQ_MSG_TYPE_STATE, UniversalTag.INTEGER, (Action)new CheckMsgType());
        super.transitions[ApReqStatesEnum.AP_REQ_MSG_TYPE_STATE.ordinal()][162] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_MSG_TYPE_STATE, (Enum)ApReqStatesEnum.AP_REQ_AP_OPTIONS_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[ApReqStatesEnum.AP_REQ_AP_OPTIONS_TAG_STATE.ordinal()][UniversalTag.BIT_STRING.getValue()] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_AP_OPTIONS_TAG_STATE, (Enum)ApReqStatesEnum.AP_REQ_AP_OPTIONS_STATE, UniversalTag.BIT_STRING, (Action)new StoreApOptions());
        super.transitions[ApReqStatesEnum.AP_REQ_AP_OPTIONS_STATE.ordinal()][163] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_AP_OPTIONS_STATE, (Enum)ApReqStatesEnum.AP_REQ_TICKET_STATE, 163, (Action)new StoreTicket());
        super.transitions[ApReqStatesEnum.AP_REQ_TICKET_STATE.ordinal()][164] = new GrammarTransition((Enum)ApReqStatesEnum.AP_REQ_TICKET_STATE, (Enum)ApReqStatesEnum.LAST_AP_REQ_STATE, 164, (Action)new StoreAuthenticator());
    }
    
    public static Grammar<ApReqContainer> getInstance() {
        return ApReqGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ApReqGrammar.class);
        IS_DEBUG = ApReqGrammar.LOG.isDebugEnabled();
        ApReqGrammar.instance = (Grammar<ApReqContainer>)new ApReqGrammar();
    }
}
