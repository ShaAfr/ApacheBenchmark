// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.crypto.checksum.ChecksumType;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;

public class Aes128CtsSha1Encryption extends AesCtsSha1Encryption
{
    public EncryptionType getEncryptionType() {
        return EncryptionType.AES128_CTS_HMAC_SHA1_96;
    }
    
    @Override
    public ChecksumType checksumType() {
        return ChecksumType.HMAC_SHA1_96_AES128;
    }
    
    public int getKeyLength() {
        return 128;
    }
}
