// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.changePwdData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.changePwdData.ChangePasswdDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreNewPassword extends AbstractReadOctetString<ChangePasswdDataContainer>
{
    public StoreNewPassword() {
        super("Kerberos changepassword's new password value");
    }
    
    protected void setOctetString(final byte[] newPasswd, final ChangePasswdDataContainer container) {
        container.getChngPwdData().setNewPasswd(newPasswd);
        container.setGrammarEndAllowed(true);
    }
}
