// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.checksum.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.Checksum;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.checksum.ChecksumContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class ChecksumInit extends GrammarAction<ChecksumContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public ChecksumInit() {
        super("Creates a Checksum instance");
    }
    
    public void action(final ChecksumContainer checksumContainer) throws DecoderException {
        final TLV tlv = checksumContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            ChecksumInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Checksum checksum = new Checksum();
        checksumContainer.setChecksum(checksum);
        if (ChecksumInit.IS_DEBUG) {
            ChecksumInit.LOG.debug("Checksum created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ChecksumInit.class);
        IS_DEBUG = ChecksumInit.LOG.isDebugEnabled();
    }
}
