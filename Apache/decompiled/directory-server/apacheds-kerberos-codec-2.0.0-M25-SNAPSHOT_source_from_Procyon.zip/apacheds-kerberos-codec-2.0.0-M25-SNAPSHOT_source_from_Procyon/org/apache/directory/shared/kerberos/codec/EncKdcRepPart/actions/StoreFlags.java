// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.EncKdcRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncKdcRepPart;
import org.apache.directory.shared.kerberos.flags.TicketFlags;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadBitString;

public class StoreFlags extends AbstractReadBitString<EncKdcRepPartContainer>
{
    public StoreFlags() {
        super("Stores the flags");
    }
    
    protected void setBitString(final byte[] data, final EncKdcRepPartContainer encKdcRepPartContainer) {
        final EncKdcRepPart encKdcRepPart = encKdcRepPartContainer.getEncKdcRepPart();
        final TicketFlags flags = new TicketFlags(data);
        encKdcRepPart.setFlags(flags);
    }
}
