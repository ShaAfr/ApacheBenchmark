// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.methodData.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.PaData;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.padata.PaDataContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.methodData.MethodDataContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AddPaData extends GrammarAction<MethodDataContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AddPaData() {
        super("Add a PA-DATA instance");
    }
    
    public void action(final MethodDataContainer methodDataContainer) throws DecoderException {
        final TLV tlv = methodDataContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AddPaData.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder paDataDecoder = new Asn1Decoder();
        final PaDataContainer paDataContainer = new PaDataContainer();
        paDataContainer.setStream(methodDataContainer.getStream());
        methodDataContainer.rewind();
        try {
            paDataDecoder.decode(methodDataContainer.getStream(), (Asn1Container)paDataContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        methodDataContainer.updateParent();
        final PaData paData = paDataContainer.getPaData();
        methodDataContainer.addPaData(paData);
        if (AddPaData.IS_DEBUG) {
            AddPaData.LOG.debug("PA-DATA added : {}", (Object)paData);
        }
        methodDataContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AddPaData.class);
        IS_DEBUG = AddPaData.LOG.isDebugEnabled();
    }
}
