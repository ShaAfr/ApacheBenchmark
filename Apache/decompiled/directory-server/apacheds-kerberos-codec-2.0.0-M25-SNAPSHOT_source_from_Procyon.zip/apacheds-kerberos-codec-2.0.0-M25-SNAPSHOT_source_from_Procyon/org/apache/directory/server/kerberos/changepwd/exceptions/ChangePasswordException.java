// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.changepwd.exceptions;

import org.apache.directory.shared.kerberos.exceptions.KerberosException;

public class ChangePasswordException extends KerberosException
{
    private static final long serialVersionUID = 4880242751298831543L;
    
    public ChangePasswordException(final ChangePasswdErrorType errorType) {
        super(errorType.getValue(), errorType.getMessage());
    }
    
    public ChangePasswordException(final ChangePasswdErrorType errorType, final String message) {
        super(errorType.getValue(), message);
    }
    
    public ChangePasswordException(final ChangePasswdErrorType errorType, final Throwable cause) {
        super(errorType.getValue(), errorType.getMessage(), cause);
    }
    
    public ChangePasswordException(final ChangePasswdErrorType errorType, final byte[] explanatoryData) {
        super(errorType.getValue(), errorType.getMessage(), explanatoryData);
    }
    
    public ChangePasswordException(final ChangePasswdErrorType errorType, final byte[] explanatoryData, final Throwable cause) {
        super(errorType.getValue(), errorType.getMessage(), explanatoryData, cause);
    }
}
