// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddresses;

import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.HostAddresses;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class HostAddressesContainer extends AbstractContainer
{
    private HostAddresses hostAddresses;
    
    public HostAddressesContainer() {
        this.hostAddresses = new HostAddresses();
        this.setGrammar((Grammar)HostAddressesGrammar.getInstance());
        this.setTransition((Enum)HostAddressesStatesEnum.START_STATE);
    }
    
    public HostAddresses getHostAddresses() {
        return this.hostAddresses;
    }
    
    public void addHostAddress(final HostAddress hostAddress) {
        this.hostAddresses.addHostAddress(hostAddress);
    }
}
