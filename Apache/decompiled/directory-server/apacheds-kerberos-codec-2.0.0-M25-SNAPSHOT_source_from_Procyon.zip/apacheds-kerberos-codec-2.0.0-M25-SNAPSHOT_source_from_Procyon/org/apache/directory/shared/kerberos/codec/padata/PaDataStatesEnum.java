// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.padata;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum PaDataStatesEnum implements States
{
    START_STATE, 
    PADATA_SEQ_STATE, 
    PADATA_TYPE_TAG_STATE, 
    PADATA_TYPE_STATE, 
    PADATA_VALUE_TAG_STATE, 
    PADATA_VALUE_STATE, 
    LAST_PADATA_STATE;
    
    public String getGrammarName(final int grammar) {
        return "PADATA_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<PaDataContainer> grammar) {
        if (grammar instanceof PaDataGrammar) {
            return "PADATA_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == PaDataStatesEnum.LAST_PADATA_STATE.ordinal()) ? "LAST_PADATA_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == PaDataStatesEnum.LAST_PADATA_STATE;
    }
    
    public PaDataStatesEnum getStartState() {
        return PaDataStatesEnum.START_STATE;
    }
}
