// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.authenticator.AuthenticatorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPvno;

public class StoreAuthenticatorVno extends AbstractReadPvno<AuthenticatorContainer>
{
    public StoreAuthenticatorVno() {
        super("Authenticator vno");
    }
    
    @Override
    protected void setPvno(final int pvno, final AuthenticatorContainer authenticatorContainer) {
        authenticatorContainer.getAuthenticator().setProtocolVersionNumber(pvno);
    }
}
