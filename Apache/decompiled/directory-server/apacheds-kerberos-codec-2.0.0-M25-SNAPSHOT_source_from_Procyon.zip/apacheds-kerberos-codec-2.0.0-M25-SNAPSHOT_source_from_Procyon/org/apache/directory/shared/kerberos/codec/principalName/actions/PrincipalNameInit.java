// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.principalName.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.principalName.PrincipalNameContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class PrincipalNameInit extends GrammarAction<PrincipalNameContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public PrincipalNameInit() {
        super("Creates a PrincipalName instance");
    }
    
    public void action(final PrincipalNameContainer principalNameContainer) throws DecoderException {
        final TLV tlv = principalNameContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            PrincipalNameInit.LOG.error(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
        }
        final PrincipalName principalName = new PrincipalName();
        principalNameContainer.setPrincipalName(principalName);
        if (PrincipalNameInit.IS_DEBUG) {
            PrincipalNameInit.LOG.debug("PrincipalName created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)PrincipalNameInit.class);
        IS_DEBUG = PrincipalNameInit.LOG.isDebugEnabled();
    }
}
