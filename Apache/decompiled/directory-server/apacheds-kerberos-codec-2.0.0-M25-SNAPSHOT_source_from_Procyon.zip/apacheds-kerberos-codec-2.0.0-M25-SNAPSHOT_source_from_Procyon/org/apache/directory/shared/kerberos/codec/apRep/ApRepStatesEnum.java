// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apRep;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum ApRepStatesEnum implements States
{
    START_STATE, 
    AP_REP_STATE, 
    AP_REP_SEQ_STATE, 
    AP_REP_PVNO_TAG_STATE, 
    AP_REP_PVNO_STATE, 
    AP_REP_MSG_TYPE_TAG_STATE, 
    AP_REP_MSG_TYPE_STATE, 
    AP_REP_ENC_PART_STATE, 
    LAST_AP_REP_STATE;
    
    public String getGrammarName(final int grammar) {
        return "AP_REP_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<ApRepContainer> grammar) {
        if (grammar instanceof ApRepGrammar) {
            return "AP_REP_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == ApRepStatesEnum.LAST_AP_REP_STATE.ordinal()) ? "AP_REP_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == ApRepStatesEnum.LAST_AP_REP_STATE;
    }
    
    public ApRepStatesEnum getStartState() {
        return ApRepStatesEnum.START_STATE;
    }
}
