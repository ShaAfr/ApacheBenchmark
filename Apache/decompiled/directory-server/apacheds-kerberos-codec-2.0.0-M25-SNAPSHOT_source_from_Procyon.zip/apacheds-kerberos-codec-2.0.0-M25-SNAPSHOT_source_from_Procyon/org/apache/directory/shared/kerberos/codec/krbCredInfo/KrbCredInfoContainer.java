// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.KrbCredInfo;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KrbCredInfoContainer extends AbstractContainer
{
    private KrbCredInfo krbCredInfo;
    
    public KrbCredInfoContainer() {
        this.setGrammar((Grammar)KrbCredInfoGrammar.getInstance());
        this.setTransition((Enum)KrbCredInfoStatesEnum.START_STATE);
    }
    
    public KrbCredInfo getKrbCredInfo() {
        return this.krbCredInfo;
    }
    
    public void setKrbCredInfo(final KrbCredInfo krbCredInfo) {
        this.krbCredInfo = krbCredInfo;
    }
}
