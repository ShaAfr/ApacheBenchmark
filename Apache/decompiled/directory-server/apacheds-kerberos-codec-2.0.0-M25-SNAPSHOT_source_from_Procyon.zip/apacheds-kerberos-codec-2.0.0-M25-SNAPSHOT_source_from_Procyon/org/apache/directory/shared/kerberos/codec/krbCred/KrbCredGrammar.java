// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCred;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.krbCred.actions.StoreEncPart;
import org.apache.directory.shared.kerberos.codec.krbCred.actions.StoreTickets;
import org.apache.directory.shared.kerberos.codec.krbCred.actions.CheckMsgType;
import org.apache.directory.shared.kerberos.codec.krbCred.actions.StorePvno;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.krbCred.actions.KrbCredInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class KrbCredGrammar extends AbstractGrammar<KrbCredContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<KrbCredContainer> instance;
    
    private KrbCredGrammar() {
        this.setName(KrbCredGrammar.class.getName());
        super.transitions = new GrammarTransition[KrbCredStatesEnum.LAST_KRB_CRED_STATE.ordinal()][256];
        super.transitions[KrbCredStatesEnum.START_STATE.ordinal()][118] = new GrammarTransition((Enum)KrbCredStatesEnum.START_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_TAG_STATE, 118, (Action)new KrbCredInit());
        super.transitions[KrbCredStatesEnum.KRB_CRED_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_TAG_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_SEQ_TAG_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KrbCredStatesEnum.KRB_CRED_SEQ_TAG_STATE.ordinal()][160] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_SEQ_TAG_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_PVNO_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[KrbCredStatesEnum.KRB_CRED_PVNO_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_PVNO_TAG_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_PVNO_STATE, UniversalTag.INTEGER, (Action)new StorePvno());
        super.transitions[KrbCredStatesEnum.KRB_CRED_PVNO_STATE.ordinal()][161] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_PVNO_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_MSGTYPE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[KrbCredStatesEnum.KRB_CRED_MSGTYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_MSGTYPE_TAG_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_MSGTYPE_STATE, UniversalTag.INTEGER, (Action)new CheckMsgType());
        super.transitions[KrbCredStatesEnum.KRB_CRED_MSGTYPE_STATE.ordinal()][162] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_MSGTYPE_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_TICKETS_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[KrbCredStatesEnum.KRB_CRED_TICKETS_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_TICKETS_TAG_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_TICKETS_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KrbCredStatesEnum.KRB_CRED_TICKETS_STATE.ordinal()][97] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_TICKETS_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_TICKETS_STATE, 97, (Action)new StoreTickets());
        super.transitions[KrbCredStatesEnum.KRB_CRED_TICKETS_STATE.ordinal()][163] = new GrammarTransition((Enum)KrbCredStatesEnum.KRB_CRED_TICKETS_STATE, (Enum)KrbCredStatesEnum.KRB_CRED_ENCPART_TAG_STATE, 163, (Action)new StoreEncPart());
    }
    
    public static Grammar<KrbCredContainer> getInstance() {
        return KrbCredGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KrbCredGrammar.class);
        IS_DEBUG = KrbCredGrammar.LOG.isDebugEnabled();
        KrbCredGrammar.instance = (Grammar<KrbCredContainer>)new KrbCredGrammar();
    }
}
