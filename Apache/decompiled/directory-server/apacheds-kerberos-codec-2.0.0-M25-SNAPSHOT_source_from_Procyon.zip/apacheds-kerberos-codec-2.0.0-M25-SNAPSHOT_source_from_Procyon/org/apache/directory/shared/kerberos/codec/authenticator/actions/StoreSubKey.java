// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.authenticator.AuthenticatorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptionKey;

public class StoreSubKey extends AbstractReadEncryptionKey<AuthenticatorContainer>
{
    public StoreSubKey() {
        super("Authenticator subkey");
    }
    
    @Override
    protected void setEncryptionKey(final EncryptionKey encryptionKey, final AuthenticatorContainer authenticatorContainer) {
        authenticatorContainer.getAuthenticator().setSubKey(encryptionKey);
        authenticatorContainer.setGrammarEndAllowed(true);
    }
}
