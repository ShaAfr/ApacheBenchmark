// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptionKey;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum EncryptionKeyStatesEnum implements States
{
    START_STATE, 
    ENCRYPTION_KEY_SEQ_STATE, 
    ENCRYPTION_KEY_TYPE_TAG_STATE, 
    ENCRYPTION_KEY_TYPE_STATE, 
    ENCRYPTION_KEY_VALUE_TAG_STATE, 
    ENCRYPTION_KEY_VALUE_STATE, 
    LAST_ENCRYPTION_KEY_STATE;
    
    public String getGrammarName(final int grammar) {
        return "ENCRYPTION_KEY_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<EncryptionKeyContainer> grammar) {
        if (grammar instanceof EncryptionKeyGrammar) {
            return "ENCRYPTION_KEY_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == EncryptionKeyStatesEnum.LAST_ENCRYPTION_KEY_STATE.ordinal()) ? "LAST_ENCRYPTION_KEY_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == EncryptionKeyStatesEnum.LAST_ENCRYPTION_KEY_STATE;
    }
    
    public EncryptionKeyStatesEnum getStartState() {
        return EncryptionKeyStatesEnum.START_STATE;
    }
}
