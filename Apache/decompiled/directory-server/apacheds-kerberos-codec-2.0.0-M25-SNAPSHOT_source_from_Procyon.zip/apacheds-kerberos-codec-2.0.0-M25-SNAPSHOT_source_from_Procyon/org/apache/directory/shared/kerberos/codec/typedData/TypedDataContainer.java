// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.typedData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.TypedData;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class TypedDataContainer extends AbstractContainer
{
    private TypedData typedData;
    
    public TypedDataContainer() {
        this.setGrammar((Grammar)TypedDataGrammar.getInstance());
        this.setTransition((Enum)TypedDataStatesEnum.START_STATE);
    }
    
    public TypedData getTypedData() {
        return this.typedData;
    }
    
    public void setTypedData(final TypedData typedData) {
        this.typedData = typedData;
    }
}
