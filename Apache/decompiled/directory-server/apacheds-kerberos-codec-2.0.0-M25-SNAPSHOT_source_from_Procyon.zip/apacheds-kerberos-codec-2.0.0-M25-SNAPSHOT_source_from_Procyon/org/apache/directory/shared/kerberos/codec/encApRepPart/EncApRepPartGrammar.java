// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encApRepPart;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.encApRepPart.actions.StoreSeqNumber;
import org.apache.directory.shared.kerberos.codec.encApRepPart.actions.StoreSubKey;
import org.apache.directory.shared.kerberos.codec.encApRepPart.actions.StoreCusec;
import org.apache.directory.shared.kerberos.codec.encApRepPart.actions.StoreCTime;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.encApRepPart.actions.EncApRepPartInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class EncApRepPartGrammar extends AbstractGrammar<EncApRepPartContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<EncApRepPartContainer> instance;
    
    private EncApRepPartGrammar() {
        this.setName(EncApRepPartGrammar.class.getName());
        super.transitions = new GrammarTransition[EncApRepPartStatesEnum.LAST_ENC_AP_REP_PART_STATE.ordinal()][256];
        super.transitions[EncApRepPartStatesEnum.START_STATE.ordinal()][123] = new GrammarTransition((Enum)EncApRepPartStatesEnum.START_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_STATE, 123, (Action)new EncApRepPartInit());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CTIME_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_CTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CTIME_TAG_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreCTime());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_CTIME_STATE.ordinal()][161] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CTIME_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_TAG_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_STATE, UniversalTag.INTEGER, (Action)new StoreCusec());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_STATE.ordinal()][162] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SUBKEY_STATE, 162, (Action)new StoreSubKey());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_STATE.ordinal()][163] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_CUSEC_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_NUMBER_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_SUBKEY_STATE.ordinal()][163] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SUBKEY_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_NUMBER_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_NUMBER_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_NUMBER_TAG_STATE, (Enum)EncApRepPartStatesEnum.ENC_AP_REP_PART_SEQ_NUMBER_STATE, UniversalTag.INTEGER, (Action)new StoreSeqNumber());
    }
    
    public static Grammar<EncApRepPartContainer> getInstance() {
        return EncApRepPartGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncApRepPartGrammar.class);
        IS_DEBUG = EncApRepPartGrammar.LOG.isDebugEnabled();
        EncApRepPartGrammar.instance = (Grammar<EncApRepPartContainer>)new EncApRepPartGrammar();
    }
}
