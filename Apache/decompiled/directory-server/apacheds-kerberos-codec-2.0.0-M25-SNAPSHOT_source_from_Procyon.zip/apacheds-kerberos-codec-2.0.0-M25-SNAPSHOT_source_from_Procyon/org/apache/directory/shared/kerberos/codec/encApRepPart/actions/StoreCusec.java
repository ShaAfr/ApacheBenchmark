// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encApRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encApRepPart.EncApRepPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreCusec extends AbstractReadInteger<EncApRepPartContainer>
{
    public StoreCusec() {
        super("EncApRepPart cusec", 0, 999999);
    }
    
    protected void setIntegerValue(final int value, final EncApRepPartContainer encApRepPartContainer) {
        encApRepPartContainer.getEncApRepPart().setCusec(value);
        encApRepPartContainer.setGrammarEndAllowed(true);
    }
}
