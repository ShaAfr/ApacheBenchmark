// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.exceptions;

import java.util.Collections;
import java.util.Arrays;
import java.util.List;

public final class ErrorType implements Comparable<ErrorType>
{
    public static final ErrorType KDC_ERR_NONE;
    public static final ErrorType KDC_ERR_NAME_EXP;
    public static final ErrorType KDC_ERR_SERVICE_EXP;
    public static final ErrorType KDC_ERR_BAD_PVNO;
    public static final ErrorType KDC_ERR_C_OLD_MAST_KVNO;
    public static final ErrorType KDC_ERR_S_OLD_MAST_KVNO;
    public static final ErrorType KDC_ERR_C_PRINCIPAL_UNKNOWN;
    public static final ErrorType KDC_ERR_S_PRINCIPAL_UNKNOWN;
    public static final ErrorType KDC_ERR_PRINCIPAL_NOT_UNIQUE;
    public static final ErrorType KDC_ERR_NULL_KEY;
    public static final ErrorType KDC_ERR_CANNOT_POSTDATE;
    public static final ErrorType KDC_ERR_NEVER_VALID;
    public static final ErrorType KDC_ERR_POLICY;
    public static final ErrorType KDC_ERR_BADOPTION;
    public static final ErrorType KDC_ERR_ETYPE_NOSUPP;
    public static final ErrorType KDC_ERR_SUMTYPE_NOSUPP;
    public static final ErrorType KDC_ERR_PADATA_TYPE_NOSUPP;
    public static final ErrorType KDC_ERR_TRTYPE_NOSUPP;
    public static final ErrorType KDC_ERR_CLIENT_REVOKED;
    public static final ErrorType KDC_ERR_SERVICE_REVOKED;
    public static final ErrorType KDC_ERR_TGT_REVOKED;
    public static final ErrorType KDC_ERR_CLIENT_NOTYET;
    public static final ErrorType KDC_ERR_SERVICE_NOTYET;
    public static final ErrorType KDC_ERR_KEY_EXPIRED;
    public static final ErrorType KDC_ERR_PREAUTH_FAILED;
    public static final ErrorType KDC_ERR_PREAUTH_REQUIRED;
    public static final ErrorType KDC_ERR_SERVER_NOMATCH;
    public static final ErrorType KDC_ERR_MUST_USE_USER2USER;
    public static final ErrorType KDC_ERR_PATH_NOT_ACCEPTED;
    public static final ErrorType KDC_ERR_SVC_UNAVAILABLE;
    public static final ErrorType KRB_AP_ERR_BAD_INTEGRITY;
    public static final ErrorType KRB_AP_ERR_TKT_EXPIRED;
    public static final ErrorType KRB_AP_ERR_TKT_NYV;
    public static final ErrorType KRB_AP_ERR_REPEAT;
    public static final ErrorType KRB_AP_ERR_NOT_US;
    public static final ErrorType KRB_AP_ERR_BADMATCH;
    public static final ErrorType KRB_AP_ERR_SKEW;
    public static final ErrorType KRB_AP_ERR_BADADDR;
    public static final ErrorType KRB_AP_ERR_BADVERSION;
    public static final ErrorType KRB_AP_ERR_MSG_TYPE;
    public static final ErrorType KRB_AP_ERR_MODIFIED;
    public static final ErrorType KRB_AP_ERR_BADORDER;
    public static final ErrorType KRB_AP_ERR_BADKEYVER;
    public static final ErrorType KRB_AP_ERR_NOKEY;
    public static final ErrorType KRB_AP_ERR_MUT_FAIL;
    public static final ErrorType KRB_AP_ERR_BADDIRECTION;
    public static final ErrorType KRB_AP_ERR_METHOD;
    public static final ErrorType KRB_AP_ERR_BADSEQ;
    public static final ErrorType KRB_AP_ERR_INAPP_CKSUM;
    public static final ErrorType KRB_AP_PATH_NOT_ACCEPTED;
    public static final ErrorType KRB_ERR_RESPONSE_TOO_BIG;
    public static final ErrorType KRB_ERR_GENERIC;
    public static final ErrorType KRB_ERR_FIELD_TOOLONG;
    public static final ErrorType KDC_ERR_CLIENT_NOT_TRUSTED;
    public static final ErrorType KRB_ERR_KDC_NOT_TRUSTED;
    public static final ErrorType KDC_ERR_INVALID_SIG;
    public static final ErrorType KDC_ERR_DH_KEY_PARAMETERS_NOT_ACCEPTED;
    public static final ErrorType KRB_ERR_CERTIFICATE_MISMATCH;
    public static final ErrorType KRB_AP_ERR_NO_TGT;
    public static final ErrorType KRB_ERR_WRONG_REALM;
    public static final ErrorType KRB_AP_ERR_USER_TO_USER_REQUIRED;
    public static final ErrorType KDC_ERR_CANT_VERIFY_CERTIFICATE;
    public static final ErrorType KDC_ERR_INVALID_CERTIFICATE;
    public static final ErrorType KDC_ERR_REVOKED_CERTIFICATE;
    public static final ErrorType KDC_ERR_REVOCATION_STATUS_UNKNOWN;
    public static final ErrorType KRB_ERR_REVOCATION_STATUS_UNAVAILABLE;
    public static final ErrorType KDC_ERR_CLIENT_NAME_MISMATCH;
    public static final ErrorType KRB_ERR_KDC_NAME_MISMATCH;
    public static final ErrorType KDC_ERR_INCONSISTENT_KEY_PURPOSE;
    public static final ErrorType KDC_ERR_DIGEST_IN_CERT_NOT_ACCEPTED;
    public static final ErrorType KDC_ERR_PA_CHECKSUM_MUST_BE_INCLUDED;
    public static final ErrorType KDC_ERR_DIGEST_IN_SIGNED_DATA_NOT_ACCEPTED;
    public static final ErrorType KDC_ERR_PUBLIC_KEY_ENCRYPTION_NOT_SUPPORTED;
    private static final ErrorType[] values;
    public static final List<ErrorType> VALUES;
    private final String name;
    private final int value;
    
    private ErrorType(final int value, final String name) {
        this.value = value;
        this.name = name;
    }
    
    public String getMessage() {
        return this.name;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    @Override
    public int compareTo(final ErrorType that) {
        return this.value - that.value;
    }
    
    public static ErrorType getTypeByValue(final int ordinal) {
        for (int ii = 0; ii < ErrorType.values.length; ++ii) {
            if (ErrorType.values[ii].value == ordinal) {
                return ErrorType.values[ii];
            }
        }
        return ErrorType.KRB_ERR_GENERIC;
    }
    
    public int getValue() {
        return this.value;
    }
    
    static {
        KDC_ERR_NONE = new ErrorType(0, "No error");
        KDC_ERR_NAME_EXP = new ErrorType(1, "Client's entry in database has expired");
        KDC_ERR_SERVICE_EXP = new ErrorType(2, "Server's entry in database has expired");
        KDC_ERR_BAD_PVNO = new ErrorType(3, "Requested protocol version number not supported");
        KDC_ERR_C_OLD_MAST_KVNO = new ErrorType(4, "Client's key encrypted in old master key");
        KDC_ERR_S_OLD_MAST_KVNO = new ErrorType(5, "Server's key encrypted in old master key");
        KDC_ERR_C_PRINCIPAL_UNKNOWN = new ErrorType(6, "Client not found in Kerberos database");
        KDC_ERR_S_PRINCIPAL_UNKNOWN = new ErrorType(7, "Server not found in Kerberos database");
        KDC_ERR_PRINCIPAL_NOT_UNIQUE = new ErrorType(8, "Multiple principal entries in database");
        KDC_ERR_NULL_KEY = new ErrorType(9, "The client or server has a null key");
        KDC_ERR_CANNOT_POSTDATE = new ErrorType(10, "Ticket not eligible for postdating");
        KDC_ERR_NEVER_VALID = new ErrorType(11, "Requested start time is later than end time");
        KDC_ERR_POLICY = new ErrorType(12, "KDC policy rejects request");
        KDC_ERR_BADOPTION = new ErrorType(13, "KDC cannot accommodate requested option");
        KDC_ERR_ETYPE_NOSUPP = new ErrorType(14, "KDC has no support for encryption type");
        KDC_ERR_SUMTYPE_NOSUPP = new ErrorType(15, "KDC has no support for checksum type");
        KDC_ERR_PADATA_TYPE_NOSUPP = new ErrorType(16, "KDC has no support for padata type");
        KDC_ERR_TRTYPE_NOSUPP = new ErrorType(17, "KDC has no support for transited type");
        KDC_ERR_CLIENT_REVOKED = new ErrorType(18, "Clients credentials have been revoked");
        KDC_ERR_SERVICE_REVOKED = new ErrorType(19, "Credentials for server have been revoked");
        KDC_ERR_TGT_REVOKED = new ErrorType(20, "TGT has been revoked");
        KDC_ERR_CLIENT_NOTYET = new ErrorType(21, "Client not yet valid; try again later");
        KDC_ERR_SERVICE_NOTYET = new ErrorType(22, "Server not yet valid; try again later");
        KDC_ERR_KEY_EXPIRED = new ErrorType(23, "Password has expired; change password to reset");
        KDC_ERR_PREAUTH_FAILED = new ErrorType(24, "Pre-authentication information was invalid");
        KDC_ERR_PREAUTH_REQUIRED = new ErrorType(25, "Additional pre-authentication required");
        KDC_ERR_SERVER_NOMATCH = new ErrorType(26, "Requested server and ticket don't match");
        KDC_ERR_MUST_USE_USER2USER = new ErrorType(27, "Server valid for user2user only");
        KDC_ERR_PATH_NOT_ACCEPTED = new ErrorType(28, "KDC Policy rejects transited path");
        KDC_ERR_SVC_UNAVAILABLE = new ErrorType(29, "A service is not available");
        KRB_AP_ERR_BAD_INTEGRITY = new ErrorType(31, "Integrity check on decrypted field failed");
        KRB_AP_ERR_TKT_EXPIRED = new ErrorType(32, "Ticket expired");
        KRB_AP_ERR_TKT_NYV = new ErrorType(33, "Ticket not yet valid");
        KRB_AP_ERR_REPEAT = new ErrorType(34, "Request is a replay");
        KRB_AP_ERR_NOT_US = new ErrorType(35, "The ticket isn't for us");
        KRB_AP_ERR_BADMATCH = new ErrorType(36, "Ticket and authenticator don't match");
        KRB_AP_ERR_SKEW = new ErrorType(37, "Clock skew too great");
        KRB_AP_ERR_BADADDR = new ErrorType(38, "Incorrect net address");
        KRB_AP_ERR_BADVERSION = new ErrorType(39, "Protocol version mismatch");
        KRB_AP_ERR_MSG_TYPE = new ErrorType(40, "Invalid msg type");
        KRB_AP_ERR_MODIFIED = new ErrorType(41, "Message stream modified");
        KRB_AP_ERR_BADORDER = new ErrorType(42, "Message out of order");
        KRB_AP_ERR_BADKEYVER = new ErrorType(44, "Specified version of key is not available");
        KRB_AP_ERR_NOKEY = new ErrorType(45, "Service key not available");
        KRB_AP_ERR_MUT_FAIL = new ErrorType(46, "Mutual authentication failed");
        KRB_AP_ERR_BADDIRECTION = new ErrorType(47, "Incorrect message direction");
        KRB_AP_ERR_METHOD = new ErrorType(48, "Alternative authentication method required");
        KRB_AP_ERR_BADSEQ = new ErrorType(49, "Incorrect sequence number in message");
        KRB_AP_ERR_INAPP_CKSUM = new ErrorType(50, "Inappropriate type of checksum in message");
        KRB_AP_PATH_NOT_ACCEPTED = new ErrorType(51, "Policy rejects transited path");
        KRB_ERR_RESPONSE_TOO_BIG = new ErrorType(52, "Response too big for UDP; retry with TCP");
        KRB_ERR_GENERIC = new ErrorType(60, "Generic error (description in e-text)");
        KRB_ERR_FIELD_TOOLONG = new ErrorType(61, "Field is too long for this implementation");
        KDC_ERR_CLIENT_NOT_TRUSTED = new ErrorType(62, "Client is not trusted");
        KRB_ERR_KDC_NOT_TRUSTED = new ErrorType(63, "KDC is not trusted");
        KDC_ERR_INVALID_SIG = new ErrorType(64, "Signature is invalid");
        KDC_ERR_DH_KEY_PARAMETERS_NOT_ACCEPTED = new ErrorType(65, "Diffie-Hellman (DH) key parameters not accepted.");
        KRB_ERR_CERTIFICATE_MISMATCH = new ErrorType(66, "Certificates do not match");
        KRB_AP_ERR_NO_TGT = new ErrorType(67, "No TGT available to validate USER-TO-USER");
        KRB_ERR_WRONG_REALM = new ErrorType(68, "Wrong realm");
        KRB_AP_ERR_USER_TO_USER_REQUIRED = new ErrorType(69, "Ticket must be for USER-TO-USER");
        KDC_ERR_CANT_VERIFY_CERTIFICATE = new ErrorType(70, "Can't verify certificate");
        KDC_ERR_INVALID_CERTIFICATE = new ErrorType(71, "Invalid certificate");
        KDC_ERR_REVOKED_CERTIFICATE = new ErrorType(72, "Revoked certificate");
        KDC_ERR_REVOCATION_STATUS_UNKNOWN = new ErrorType(73, "Revocation status unknown");
        KRB_ERR_REVOCATION_STATUS_UNAVAILABLE = new ErrorType(74, "Revocation status unavailable");
        KDC_ERR_CLIENT_NAME_MISMATCH = new ErrorType(75, "Client names do not match");
        KRB_ERR_KDC_NAME_MISMATCH = new ErrorType(76, "KDC names do not match");
        KDC_ERR_INCONSISTENT_KEY_PURPOSE = new ErrorType(77, "Inconsistent key purpose");
        KDC_ERR_DIGEST_IN_CERT_NOT_ACCEPTED = new ErrorType(78, "Digest in certificate not accepted");
        KDC_ERR_PA_CHECKSUM_MUST_BE_INCLUDED = new ErrorType(79, "PA checksum must be included");
        KDC_ERR_DIGEST_IN_SIGNED_DATA_NOT_ACCEPTED = new ErrorType(80, "Digest in signed data not accepted");
        KDC_ERR_PUBLIC_KEY_ENCRYPTION_NOT_SUPPORTED = new ErrorType(81, "Public key encryption not supported");
        values = new ErrorType[] { ErrorType.KDC_ERR_NONE, ErrorType.KDC_ERR_NAME_EXP, ErrorType.KDC_ERR_SERVICE_EXP, ErrorType.KDC_ERR_BAD_PVNO, ErrorType.KDC_ERR_C_OLD_MAST_KVNO, ErrorType.KDC_ERR_S_OLD_MAST_KVNO, ErrorType.KDC_ERR_C_PRINCIPAL_UNKNOWN, ErrorType.KDC_ERR_S_PRINCIPAL_UNKNOWN, ErrorType.KDC_ERR_PRINCIPAL_NOT_UNIQUE, ErrorType.KDC_ERR_NULL_KEY, ErrorType.KDC_ERR_CANNOT_POSTDATE, ErrorType.KDC_ERR_NEVER_VALID, ErrorType.KDC_ERR_POLICY, ErrorType.KDC_ERR_BADOPTION, ErrorType.KDC_ERR_ETYPE_NOSUPP, ErrorType.KDC_ERR_SUMTYPE_NOSUPP, ErrorType.KDC_ERR_PADATA_TYPE_NOSUPP, ErrorType.KDC_ERR_TRTYPE_NOSUPP, ErrorType.KDC_ERR_CLIENT_REVOKED, ErrorType.KDC_ERR_SERVICE_REVOKED, ErrorType.KDC_ERR_TGT_REVOKED, ErrorType.KDC_ERR_CLIENT_NOTYET, ErrorType.KDC_ERR_SERVICE_NOTYET, ErrorType.KDC_ERR_KEY_EXPIRED, ErrorType.KDC_ERR_PREAUTH_FAILED, ErrorType.KDC_ERR_PREAUTH_REQUIRED, ErrorType.KDC_ERR_SERVER_NOMATCH, ErrorType.KDC_ERR_MUST_USE_USER2USER, ErrorType.KDC_ERR_PATH_NOT_ACCEPTED, ErrorType.KDC_ERR_SVC_UNAVAILABLE, ErrorType.KRB_AP_ERR_BAD_INTEGRITY, ErrorType.KRB_AP_ERR_TKT_EXPIRED, ErrorType.KRB_AP_ERR_TKT_NYV, ErrorType.KRB_AP_ERR_REPEAT, ErrorType.KRB_AP_ERR_NOT_US, ErrorType.KRB_AP_ERR_BADMATCH, ErrorType.KRB_AP_ERR_SKEW, ErrorType.KRB_AP_ERR_BADADDR, ErrorType.KRB_AP_ERR_BADVERSION, ErrorType.KRB_AP_ERR_MSG_TYPE, ErrorType.KRB_AP_ERR_MODIFIED, ErrorType.KRB_AP_ERR_BADORDER, ErrorType.KRB_AP_ERR_BADKEYVER, ErrorType.KRB_AP_ERR_NOKEY, ErrorType.KRB_AP_ERR_MUT_FAIL, ErrorType.KRB_AP_ERR_BADDIRECTION, ErrorType.KRB_AP_ERR_METHOD, ErrorType.KRB_AP_ERR_BADSEQ, ErrorType.KRB_AP_ERR_INAPP_CKSUM, ErrorType.KRB_AP_PATH_NOT_ACCEPTED, ErrorType.KRB_ERR_RESPONSE_TOO_BIG, ErrorType.KRB_ERR_GENERIC, ErrorType.KRB_ERR_FIELD_TOOLONG, ErrorType.KDC_ERR_CLIENT_NOT_TRUSTED, ErrorType.KRB_ERR_KDC_NOT_TRUSTED, ErrorType.KDC_ERR_INVALID_SIG, ErrorType.KDC_ERR_DH_KEY_PARAMETERS_NOT_ACCEPTED, ErrorType.KRB_ERR_CERTIFICATE_MISMATCH, ErrorType.KRB_AP_ERR_NO_TGT, ErrorType.KRB_ERR_WRONG_REALM, ErrorType.KRB_AP_ERR_USER_TO_USER_REQUIRED, ErrorType.KDC_ERR_CANT_VERIFY_CERTIFICATE, ErrorType.KDC_ERR_INVALID_CERTIFICATE, ErrorType.KDC_ERR_REVOKED_CERTIFICATE, ErrorType.KDC_ERR_REVOCATION_STATUS_UNKNOWN, ErrorType.KRB_ERR_REVOCATION_STATUS_UNAVAILABLE, ErrorType.KDC_ERR_CLIENT_NAME_MISMATCH, ErrorType.KRB_ERR_KDC_NAME_MISMATCH, ErrorType.KDC_ERR_INCONSISTENT_KEY_PURPOSE, ErrorType.KDC_ERR_DIGEST_IN_CERT_NOT_ACCEPTED, ErrorType.KDC_ERR_PA_CHECKSUM_MUST_BE_INCLUDED, ErrorType.KDC_ERR_DIGEST_IN_SIGNED_DATA_NOT_ACCEPTED, ErrorType.KDC_ERR_PUBLIC_KEY_ENCRYPTION_NOT_SUPPORTED };
        VALUES = Collections.unmodifiableList((List<? extends ErrorType>)Arrays.asList((T[])ErrorType.values));
    }
}
