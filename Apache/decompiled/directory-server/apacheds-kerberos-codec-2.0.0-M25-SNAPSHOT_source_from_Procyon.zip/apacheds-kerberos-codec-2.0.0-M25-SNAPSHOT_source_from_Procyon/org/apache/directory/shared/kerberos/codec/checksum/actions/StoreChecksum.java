// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.checksum.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.checksum.ChecksumContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreChecksum extends AbstractReadOctetString<ChecksumContainer>
{
    public StoreChecksum() {
        super("Checksum's 'checksum' value");
    }
    
    protected void setOctetString(final byte[] data, final ChecksumContainer checksumContainer) {
        checksumContainer.getChecksum().setChecksumValue(data);
        checksumContainer.setGrammarEndAllowed(true);
    }
}
