// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.transitedEncoding.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.types.TransitedEncodingType;
import org.apache.directory.shared.kerberos.codec.transitedEncoding.TransitedEncodingContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreTrType extends AbstractReadInteger<TransitedEncodingContainer>
{
    public StoreTrType() {
        super("TransitedEncoding tr-type");
    }
    
    protected void setIntegerValue(final int value, final TransitedEncodingContainer transitedEncodingContainer) {
        final TransitedEncodingType type = TransitedEncodingType.getTypeByOrdinal(value);
        transitedEncodingContainer.getTransitedEncoding().setTrType(type);
    }
}
