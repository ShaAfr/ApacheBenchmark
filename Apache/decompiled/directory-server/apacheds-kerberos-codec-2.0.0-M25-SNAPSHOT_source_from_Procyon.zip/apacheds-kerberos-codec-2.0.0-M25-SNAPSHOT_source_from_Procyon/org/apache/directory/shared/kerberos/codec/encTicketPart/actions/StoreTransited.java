// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.TransitedEncoding;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.shared.kerberos.codec.transitedEncoding.TransitedEncodingContainer;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreTransited extends GrammarAction<EncTicketPartContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreTransited() {
        super("EncTicketPart transited");
    }
    
    public void action(final EncTicketPartContainer encTicketPartContainer) throws DecoderException {
        final TLV tlv = encTicketPartContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreTransited.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final TransitedEncodingContainer transitedContainer = new TransitedEncodingContainer();
        final Asn1Decoder transitedEncodingDecoder = new Asn1Decoder();
        try {
            transitedEncodingDecoder.decode(encTicketPartContainer.getStream(), (Asn1Container)transitedContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        final TransitedEncoding te = transitedContainer.getTransitedEncoding();
        if (StoreTransited.IS_DEBUG) {
            StoreTransited.LOG.debug("TransitedEncoding {}", (Object)te);
        }
        encTicketPartContainer.getEncTicketPart().setTransited(te);
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        encTicketPartContainer.updateParent();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreTransited.class);
        IS_DEBUG = StoreTransited.LOG.isDebugEnabled();
    }
}
