// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authorizationData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.authorizationData.AuthorizationDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreAdData extends AbstractReadOctetString<AuthorizationDataContainer>
{
    public StoreAdData() {
        super("AuthorizationData ad-data");
    }
    
    protected void setOctetString(final byte[] data, final AuthorizationDataContainer authorizationDataContainer) {
        authorizationDataContainer.getAuthorizationData().setCurrentAdData(data);
        authorizationDataContainer.setGrammarEndAllowed(true);
    }
}
