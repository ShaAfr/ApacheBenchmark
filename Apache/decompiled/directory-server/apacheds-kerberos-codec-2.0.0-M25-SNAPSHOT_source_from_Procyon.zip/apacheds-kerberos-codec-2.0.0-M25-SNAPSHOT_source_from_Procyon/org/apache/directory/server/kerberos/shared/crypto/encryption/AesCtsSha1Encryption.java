// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import java.security.GeneralSecurityException;
import java.security.Key;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.exceptions.ErrorType;
import java.util.Arrays;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.server.kerberos.shared.crypto.checksum.ChecksumEngine;

abstract class AesCtsSha1Encryption extends EncryptionEngine implements ChecksumEngine
{
    private static final byte[] iv;
    
    public int getConfounderLength() {
        return 16;
    }
    
    public int getChecksumLength() {
        return 12;
    }
    
    protected abstract int getKeyLength();
    
    @Override
    public byte[] calculateChecksum(final byte[] data, final byte[] key, final KeyUsage usage) {
        final byte[] Kc = this.deriveKey(key, this.getUsageKc(usage), 128, this.getKeyLength());
        final byte[] checksum = this.processChecksum(data, Kc);
        return this.removeTrailingBytes(checksum, 0, checksum.length - this.getChecksumLength());
    }
    
    public byte[] calculateIntegrity(final byte[] data, final byte[] key, final KeyUsage usage) {
        final byte[] Ki = this.deriveKey(key, this.getUsageKi(usage), 128, this.getKeyLength());
        final byte[] checksum = this.processChecksum(data, Ki);
        return this.removeTrailingBytes(checksum, 0, checksum.length - this.getChecksumLength());
    }
    
    public byte[] getDecryptedData(final EncryptionKey key, final EncryptedData data, final KeyUsage usage) throws KerberosException {
        final byte[] Ke = this.deriveKey(key.getKeyValue(), this.getUsageKe(usage), 128, this.getKeyLength());
        byte[] encryptedData = data.getCipher();
        final byte[] oldChecksum = new byte[this.getChecksumLength()];
        System.arraycopy(encryptedData, encryptedData.length - this.getChecksumLength(), oldChecksum, 0, oldChecksum.length);
        encryptedData = this.removeTrailingBytes(encryptedData, 0, this.getChecksumLength());
        final byte[] decryptedData = this.decrypt(encryptedData, Ke);
        final byte[] withoutConfounder = this.removeLeadingBytes(decryptedData, this.getConfounderLength(), 0);
        final byte[] newChecksum = this.calculateIntegrity(decryptedData, key.getKeyValue(), usage);
        if (!Arrays.equals(oldChecksum, newChecksum)) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY);
        }
        return withoutConfounder;
    }
    
    public EncryptedData getEncryptedData(final EncryptionKey key, final byte[] plainText, final KeyUsage usage) {
        final byte[] Ke = this.deriveKey(key.getKeyValue(), this.getUsageKe(usage), 128, this.getKeyLength());
        final byte[] conFounder = this.getRandomBytes(this.getConfounderLength());
        final byte[] dataBytes = this.concatenateBytes(conFounder, plainText);
        final byte[] checksumBytes = this.calculateIntegrity(dataBytes, key.getKeyValue(), usage);
        final byte[] encryptedData = this.encrypt(dataBytes, Ke);
        final byte[] cipherText = this.concatenateBytes(encryptedData, checksumBytes);
        return new EncryptedData(this.getEncryptionType(), key.getKeyVersion(), cipherText);
    }
    
    public byte[] encrypt(final byte[] plainText, final byte[] keyBytes) {
        return this.processCipher(true, plainText, keyBytes);
    }
    
    public byte[] decrypt(final byte[] cipherText, final byte[] keyBytes) {
        return this.processCipher(false, cipherText, keyBytes);
    }
    
    protected byte[] deriveKey(final byte[] baseKey, final byte[] usage, final int n, final int k) {
        return this.deriveRandom(baseKey, usage, n, k);
    }
    
    private byte[] processChecksum(final byte[] data, final byte[] key) {
        try {
            final SecretKey sk = new SecretKeySpec(key, "AES");
            final Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(sk);
            return mac.doFinal(data);
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
    
    private byte[] processCipher(final boolean isEncrypt, final byte[] data, final byte[] keyBytes) {
        try {
            final Cipher cipher = Cipher.getInstance("AES/CTS/NoPadding");
            final SecretKey key = new SecretKeySpec(keyBytes, "AES");
            final AlgorithmParameterSpec paramSpec = new IvParameterSpec(AesCtsSha1Encryption.iv);
            if (isEncrypt) {
                cipher.init(1, key, paramSpec);
            }
            else {
                cipher.init(2, key, paramSpec);
            }
            return cipher.doFinal(data);
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
    
    static {
        iv = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    }
}
