// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adKdcIssued.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.adKdcIssued.AdKdcIssuedContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreISName extends AbstractReadPrincipalName<AdKdcIssuedContainer>
{
    public StoreISName() {
        super("AD-KDCIssued i-sname");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final AdKdcIssuedContainer adKdcIssuedContainer) {
        adKdcIssuedContainer.getAdKdcIssued().setISName(principalName);
    }
}
