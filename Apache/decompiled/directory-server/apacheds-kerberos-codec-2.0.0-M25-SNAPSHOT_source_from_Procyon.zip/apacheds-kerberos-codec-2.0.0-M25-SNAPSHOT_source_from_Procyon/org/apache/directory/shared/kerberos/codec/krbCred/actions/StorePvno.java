// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCred.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbCred.KrbCredContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPvno;

public class StorePvno extends AbstractReadPvno<KrbCredContainer>
{
    public StorePvno() {
        super("KRB-CRED pvno");
    }
    
    @Override
    protected void setPvno(final int pvno, final KrbCredContainer krbCredContainer) {
        krbCredContainer.getKrbCred().setProtocolVersionNumber(pvno);
    }
}
