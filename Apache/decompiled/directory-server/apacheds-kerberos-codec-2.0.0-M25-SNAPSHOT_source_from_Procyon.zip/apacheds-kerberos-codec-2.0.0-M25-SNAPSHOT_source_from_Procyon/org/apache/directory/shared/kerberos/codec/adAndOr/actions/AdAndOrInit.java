// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adAndOr.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.AdAndOr;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.adAndOr.AdAndOrContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AdAndOrInit extends GrammarAction<AdAndOrContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AdAndOrInit() {
        super("Creates a AD-AND-OR instance");
    }
    
    public void action(final AdAndOrContainer adAndOrContainer) throws DecoderException {
        final TLV tlv = adAndOrContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AdAndOrInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final AdAndOr adAndor = new AdAndOr();
        adAndOrContainer.setAdAndOr(adAndor);
        if (AdAndOrInit.IS_DEBUG) {
            AdAndOrInit.LOG.debug("AdAndOr created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AdAndOrInit.class);
        IS_DEBUG = AdAndOrInit.LOG.isDebugEnabled();
    }
}
