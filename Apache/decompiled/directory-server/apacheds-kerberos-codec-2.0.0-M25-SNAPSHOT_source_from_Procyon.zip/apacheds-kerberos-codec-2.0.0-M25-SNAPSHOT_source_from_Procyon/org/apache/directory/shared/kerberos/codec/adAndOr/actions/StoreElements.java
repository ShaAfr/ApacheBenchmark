// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adAndOr.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.codec.adAndOr.AdAndOrContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadAuthorizationData;

public class StoreElements extends AbstractReadAuthorizationData<AdAndOrContainer>
{
    public StoreElements() {
        super("AdAndOr 'elements' value");
    }
    
    @Override
    protected void setAuthorizationData(final AuthorizationData authorizationData, final AdAndOrContainer adAndOrContainer) {
        adAndOrContainer.getAdAndOr().setElements(authorizationData);
        adAndOrContainer.setGrammarEndAllowed(true);
    }
}
