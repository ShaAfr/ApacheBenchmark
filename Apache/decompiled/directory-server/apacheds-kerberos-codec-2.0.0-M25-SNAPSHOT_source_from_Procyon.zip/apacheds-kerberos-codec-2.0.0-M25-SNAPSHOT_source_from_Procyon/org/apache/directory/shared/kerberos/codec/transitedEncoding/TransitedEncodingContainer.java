// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.transitedEncoding;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.TransitedEncoding;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class TransitedEncodingContainer extends AbstractContainer
{
    private TransitedEncoding transitedEncoding;
    
    public TransitedEncodingContainer() {
        this.setGrammar((Grammar)TransitedEncodingGrammar.getInstance());
        this.setTransition((Enum)TransitedEncodingStatesEnum.START_STATE);
    }
    
    public TransitedEncoding getTransitedEncoding() {
        return this.transitedEncoding;
    }
    
    public void setTransitedEncoding(final TransitedEncoding transitedEncoding) {
        this.transitedEncoding = transitedEncoding;
    }
}
