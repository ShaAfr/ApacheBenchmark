// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class AdAndOr implements Asn1Object
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private int conditionCount;
    private AuthorizationData elements;
    private int conditionCountTagLength;
    private int elementsTagLength;
    private int adAndOrSeqLength;
    
    public int getConditionCount() {
        return this.conditionCount;
    }
    
    public void setConditionCount(final int conditionCount) {
        this.conditionCount = conditionCount;
    }
    
    public AuthorizationData getElements() {
        return this.elements;
    }
    
    public void setElements(final AuthorizationData elements) {
        this.elements = elements;
    }
    
    public int computeLength() {
        final int conditionCountLength = BerValue.getNbBytes(this.conditionCount);
        this.conditionCountTagLength = 1 + TLV.getNbBytes(conditionCountLength) + conditionCountLength;
        this.adAndOrSeqLength = 1 + TLV.getNbBytes(this.conditionCountTagLength) + this.conditionCountTagLength;
        this.elementsTagLength = this.elements.computeLength();
        this.adAndOrSeqLength += 1 + TLV.getNbBytes(this.elementsTagLength) + this.elementsTagLength;
        return 1 + TLV.getNbBytes(this.adAndOrSeqLength) + this.adAndOrSeqLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.adAndOrSeqLength));
            buffer.put((byte)(-96));
            buffer.put((byte)this.conditionCountTagLength);
            BerValue.encode(buffer, this.conditionCount);
            buffer.put((byte)(-95));
            buffer.put((byte)this.elementsTagLength);
            this.elements.encode(buffer);
        }
        catch (BufferOverflowException boe) {
            AdAndOr.LOG.error(I18n.err(I18n.ERR_139, new Object[] { 1 + TLV.getNbBytes(this.adAndOrSeqLength) + this.adAndOrSeqLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (AdAndOr.IS_DEBUG) {
            AdAndOr.LOG.debug("AD-AND-OR encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            AdAndOr.LOG.debug("AD-AND-OR initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        return this.toString("");
    }
    
    public String toString(final String tabs) {
        final StringBuilder sb = new StringBuilder();
        sb.append(tabs).append("AD-AND-OR : {\n");
        sb.append(tabs).append("    condition-count: ").append(this.conditionCount).append('\n');
        sb.append(tabs + "    elements:").append(this.elements).append('\n');
        sb.append(tabs + "}\n");
        return sb.toString();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AdAndOr.class);
        IS_DEBUG = AdAndOr.LOG.isDebugEnabled();
    }
}
