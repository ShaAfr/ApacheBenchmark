// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddress;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.hostAddress.actions.StoreAddress;
import org.apache.directory.shared.kerberos.codec.hostAddress.actions.StoreAddrType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.hostAddress.actions.HostAddressInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class HostAddressGrammar extends AbstractGrammar<HostAddressContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<HostAddressContainer> instance;
    
    private HostAddressGrammar() {
        this.setName(HostAddressGrammar.class.getName());
        super.transitions = new GrammarTransition[HostAddressStatesEnum.LAST_HOST_ADDRESS_STATE.ordinal()][256];
        super.transitions[HostAddressStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)HostAddressStatesEnum.START_STATE, (Enum)HostAddressStatesEnum.HOST_ADDRESS_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new HostAddressInit());
        super.transitions[HostAddressStatesEnum.HOST_ADDRESS_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)HostAddressStatesEnum.HOST_ADDRESS_SEQ_STATE, (Enum)HostAddressStatesEnum.HOST_ADDRESS_ADDR_TYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[HostAddressStatesEnum.HOST_ADDRESS_ADDR_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)HostAddressStatesEnum.HOST_ADDRESS_ADDR_TYPE_TAG_STATE, (Enum)HostAddressStatesEnum.HOST_ADDRESS_ADDR_TYPE_STATE, UniversalTag.INTEGER, (Action)new StoreAddrType());
        super.transitions[HostAddressStatesEnum.HOST_ADDRESS_ADDR_TYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)HostAddressStatesEnum.HOST_ADDRESS_ADDR_TYPE_STATE, (Enum)HostAddressStatesEnum.HOST_ADDRESS_ADDRESS_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[HostAddressStatesEnum.HOST_ADDRESS_ADDRESS_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.ordinal()] = new GrammarTransition((Enum)HostAddressStatesEnum.HOST_ADDRESS_ADDRESS_TAG_STATE, (Enum)HostAddressStatesEnum.HOST_ADDRESS_ADDRESS_STATE, UniversalTag.OCTET_STRING, (Action)new StoreAddress());
    }
    
    public static Grammar<HostAddressContainer> getInstance() {
        return HostAddressGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)HostAddressGrammar.class);
        IS_DEBUG = HostAddressGrammar.LOG.isDebugEnabled();
        HostAddressGrammar.instance = (Grammar<HostAddressContainer>)new HostAddressGrammar();
    }
}
