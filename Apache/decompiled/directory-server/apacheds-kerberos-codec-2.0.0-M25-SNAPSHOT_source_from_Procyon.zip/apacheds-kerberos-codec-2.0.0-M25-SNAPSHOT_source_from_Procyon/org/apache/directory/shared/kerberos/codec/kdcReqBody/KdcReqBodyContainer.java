// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.components.KdcReqBody;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KdcReqBodyContainer extends AbstractContainer
{
    private KdcReqBody kdcReqBody;
    
    public KdcReqBodyContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)KdcReqBodyGrammar.getInstance());
        this.setTransition((Enum)KdcReqBodyStatesEnum.START_STATE);
    }
    
    public KdcReqBody getKdcReqBody() {
        return this.kdcReqBody;
    }
    
    public void setKdcReqBody(final KdcReqBody kdcReqBody) {
        this.kdcReqBody = kdcReqBody;
    }
}
