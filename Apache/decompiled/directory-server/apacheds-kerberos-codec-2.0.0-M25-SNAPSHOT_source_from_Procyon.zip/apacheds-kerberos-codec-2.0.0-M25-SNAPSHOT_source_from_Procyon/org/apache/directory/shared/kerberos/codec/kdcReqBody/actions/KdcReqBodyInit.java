// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.KdcReqBody;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class KdcReqBodyInit extends GrammarAction<KdcReqBodyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public KdcReqBodyInit() {
        super("Creates a KdcReqBody instance");
    }
    
    public void action(final KdcReqBodyContainer kdcReqBodyContainer) throws DecoderException {
        final TLV tlv = kdcReqBodyContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            KdcReqBodyInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final KdcReqBody kdcReqBody = new KdcReqBody();
        kdcReqBodyContainer.setKdcReqBody(kdcReqBody);
        if (KdcReqBodyInit.IS_DEBUG) {
            KdcReqBodyInit.LOG.debug("KdcReqBody created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KdcReqBodyInit.class);
        IS_DEBUG = KdcReqBodyInit.LOG.isDebugEnabled();
    }
}
