// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfoEntry.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.etypeInfoEntry.ETypeInfoEntryContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreSalt extends AbstractReadOctetString<ETypeInfoEntryContainer>
{
    public StoreSalt() {
        super("ETYPE-INFO-ENTRY salt", true);
    }
    
    protected void setOctetString(final byte[] data, final ETypeInfoEntryContainer eTypeInfoEntryContainer) {
        eTypeInfoEntryContainer.getETypeInfoEntry().setSalt(data);
        eTypeInfoEntryContainer.setGrammarEndAllowed(true);
    }
}
