// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.checksum;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.Checksum;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ChecksumContainer extends AbstractContainer
{
    private Checksum checksum;
    
    public ChecksumContainer() {
        this.setGrammar((Grammar)ChecksumGrammar.getInstance());
        this.setTransition((Enum)ChecksumStatesEnum.START_STATE);
    }
    
    public Checksum getChecksum() {
        return this.checksum;
    }
    
    public void setChecksum(final Checksum checksum) {
        this.checksum = checksum;
    }
}
