// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreAuthorizationData;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreCaddr;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreRenewtill;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreEndTime;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreStartTime;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreAuthTime;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreTransited;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreCName;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreCRealm;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreKey;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.StoreFlags;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.encTicketPart.actions.EncTicketPartInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class EncTicketPartGrammar extends AbstractGrammar<EncTicketPartContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<EncTicketPartContainer> instance;
    
    private EncTicketPartGrammar() {
        this.setName(EncTicketPartGrammar.class.getName());
        super.transitions = new GrammarTransition[EncTicketPartStatesEnum.LAST_ENC_TICKET_PART_STATE.ordinal()][256];
        super.transitions[EncTicketPartStatesEnum.START_STATE.ordinal()][99] = new GrammarTransition((Enum)EncTicketPartStatesEnum.START_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_TAG_STATE, 99, (Action)new EncTicketPartInit());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_SEQ_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_FLAGS_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_FLAGS_TAG_STATE.ordinal()][UniversalTag.BIT_STRING.getValue()] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_FLAGS_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_FLAGS_STATE, UniversalTag.BIT_STRING, (Action)new StoreFlags());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_FLAGS_STATE.ordinal()][161] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_FLAGS_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_KEY_TAG_STATE, 161, (Action)new StoreKey());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_KEY_TAG_STATE.ordinal()][162] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_KEY_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CREALM_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_CREALM_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CREALM_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CREALM_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreCRealm());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_CREALM_STATE.ordinal()][163] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CREALM_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CNAME_TAG_STATE, 163, (Action)new StoreCName());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_CNAME_TAG_STATE.ordinal()][164] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CNAME_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_TRANSITED_TAG_STATE, 164, (Action)new StoreTransited());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_TRANSITED_TAG_STATE.ordinal()][165] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_TRANSITED_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_TAG_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreAuthTime());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_STATE.ordinal()][166] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_STARTTIME_TAG_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_STARTTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_STARTTIME_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_STARTTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreStartTime());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_STARTTIME_STATE.ordinal()][167] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_STARTTIME_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreEndTime());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_STATE.ordinal()][168] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreRenewtill());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_STATE.ordinal()][169] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CADDR_TAG_STATE, 169, (Action)new StoreCaddr());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_CADDR_TAG_STATE.ordinal()][170] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CADDR_TAG_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHZ_DATA_TAG_STATE, 170, (Action)new StoreAuthorizationData());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_STATE.ordinal()][167] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHTIME_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_STATE.ordinal()][169] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_CADDR_TAG_STATE, 169, (Action)new StoreCaddr());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_STATE.ordinal()][170] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_ENDTIME_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHZ_DATA_TAG_STATE, 170, (Action)new StoreAuthorizationData());
        super.transitions[EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_STATE.ordinal()][170] = new GrammarTransition((Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_RENEWTILL_STATE, (Enum)EncTicketPartStatesEnum.ENC_TICKET_PART_AUTHZ_DATA_TAG_STATE, 170, (Action)new StoreAuthorizationData());
    }
    
    public static Grammar<EncTicketPartContainer> getInstance() {
        return EncTicketPartGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncTicketPartGrammar.class);
        IS_DEBUG = EncTicketPartGrammar.LOG.isDebugEnabled();
        EncTicketPartGrammar.instance = (Grammar<EncTicketPartContainer>)new EncTicketPartGrammar();
    }
}
