// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import java.util.Iterator;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class HostAddresses implements Asn1Object
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private List<HostAddress> addresses;
    private int addressesLength;
    
    public HostAddresses() {
        this.addresses = new ArrayList<HostAddress>();
    }
    
    public HostAddresses(final HostAddress[] addresses) {
        if (addresses == null) {
            this.addresses = new ArrayList<HostAddress>();
        }
        else {
            this.addresses = Arrays.asList(addresses);
        }
    }
    
    public void addHostAddress(final HostAddress hostAddress) {
        this.addresses.add(hostAddress);
    }
    
    public boolean contains(final HostAddress address) {
        return this.addresses != null && this.addresses.contains(address);
    }
    
    @Override
    public int hashCode() {
        int hash = 37;
        if (this.addresses != null) {
            hash = hash * 17 + this.addresses.size();
            hash = 17 + this.addresses.hashCode();
        }
        return hash;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj == null) {
            return false;
        }
        final HostAddresses that = (HostAddresses)obj;
        if (this.addresses.size() != that.addresses.size()) {
            return false;
        }
        for (int i = 0; i < this.addresses.size(); ++i) {
            if (!this.addresses.get(i).equals(that.addresses.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    public HostAddress[] getAddresses() {
        return this.addresses.toArray(new HostAddress[0]);
    }
    
    public int computeLength() {
        this.addressesLength = 0;
        if (this.addresses != null && this.addresses.size() != 0) {
            for (final HostAddress hostAddress : this.addresses) {
                final int length = hostAddress.computeLength();
                this.addressesLength += length;
            }
        }
        return 1 + TLV.getNbBytes(this.addressesLength) + this.addressesLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.addressesLength));
            if (this.addresses != null && this.addresses.size() != 0) {
                for (final HostAddress hostAddress : this.addresses) {
                    hostAddress.encode(buffer);
                }
            }
        }
        catch (BufferOverflowException boe) {
            HostAddresses.LOG.error(I18n.err(I18n.ERR_144, new Object[] { 1 + TLV.getNbBytes(this.addressesLength) + this.addressesLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (HostAddresses.IS_DEBUG) {
            HostAddresses.LOG.debug("HostAddresses encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            HostAddresses.LOG.debug("HostAddresses initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        boolean isFirst = true;
        for (final HostAddress hostAddress : this.addresses) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sb.append(", ");
            }
            sb.append(hostAddress.toString());
        }
        return sb.toString();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)HostAddresses.class);
        IS_DEBUG = HostAddresses.LOG.isDebugEnabled();
    }
}
