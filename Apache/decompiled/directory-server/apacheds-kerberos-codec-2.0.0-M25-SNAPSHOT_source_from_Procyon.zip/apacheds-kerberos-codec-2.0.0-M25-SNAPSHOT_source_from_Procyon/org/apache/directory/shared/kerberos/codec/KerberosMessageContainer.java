// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec;

import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.messages.KerberosMessage;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KerberosMessageContainer extends AbstractContainer
{
    private KerberosMessage message;
    private PrincipalName principalName;
    private boolean isTCP;
    private int tcpLength;
    
    public KerberosMessageContainer() {
        this.tcpLength = -1;
        this.setGrammar((Grammar)KerberosMessageGrammar.getInstance());
        this.setTransition((Enum)KerberosMessageStatesEnum.START_STATE);
    }
    
    public KerberosMessage getMessage() {
        return this.message;
    }
    
    public void setMessage(final KerberosMessage message) {
        this.message = message;
    }
    
    public Ticket getTicket() {
        return (Ticket)this.message;
    }
    
    public PrincipalName getPrincipalName() {
        return this.principalName;
    }
    
    public void setPrincipalName(final PrincipalName principalName) {
        this.principalName = principalName;
    }
    
    public boolean isTCP() {
        return this.isTCP;
    }
    
    public void setTCP(final boolean isTCP) {
        this.isTCP = isTCP;
    }
    
    public int getTcpLength() {
        return this.tcpLength;
    }
    
    public void setTcpLength(final int tcpLength) {
        this.tcpLength = tcpLength;
    }
}
