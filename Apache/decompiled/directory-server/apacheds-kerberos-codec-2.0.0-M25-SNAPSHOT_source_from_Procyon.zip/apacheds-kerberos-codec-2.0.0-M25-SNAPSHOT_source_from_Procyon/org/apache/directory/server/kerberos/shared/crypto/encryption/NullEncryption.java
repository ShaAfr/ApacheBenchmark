// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;

class NullEncryption extends EncryptionEngine
{
    public EncryptionType getEncryptionType() {
        return EncryptionType.NULL;
    }
    
    public int getChecksumLength() {
        return 0;
    }
    
    public int getConfounderLength() {
        return 0;
    }
    
    public byte[] getDecryptedData(final EncryptionKey key, final EncryptedData data, final KeyUsage usage) throws KerberosException {
        return data.getCipher();
    }
    
    public EncryptedData getEncryptedData(final EncryptionKey key, final byte[] plainText, final KeyUsage usage) {
        return new EncryptedData(this.getEncryptionType(), key.getKeyVersion(), plainText);
    }
    
    public byte[] encrypt(final byte[] plainText, final byte[] keyBytes) {
        return plainText;
    }
    
    public byte[] decrypt(final byte[] cipherText, final byte[] keyBytes) {
        return cipherText;
    }
    
    public byte[] calculateIntegrity(final byte[] plainText, final byte[] key, final KeyUsage usage) {
        return null;
    }
}
