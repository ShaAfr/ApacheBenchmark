// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.padata.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.padata.PaDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StorePaDataValue extends AbstractReadOctetString<PaDataContainer>
{
    public StorePaDataValue() {
        super("PaData's padata-value", true);
    }
    
    protected void setOctetString(final byte[] data, final PaDataContainer paDataContainer) {
        paDataContainer.getPaData().setPaDataValue(data);
        paDataContainer.setGrammarEndAllowed(true);
    }
}
