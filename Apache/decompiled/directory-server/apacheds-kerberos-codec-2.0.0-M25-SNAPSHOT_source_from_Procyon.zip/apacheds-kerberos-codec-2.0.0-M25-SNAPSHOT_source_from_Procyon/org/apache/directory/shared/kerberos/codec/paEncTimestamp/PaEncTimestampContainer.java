// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.paEncTimestamp;

import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.PaEncTimestamp;
import org.apache.directory.shared.kerberos.codec.encryptedData.EncryptedDataContainer;

public class PaEncTimestampContainer extends EncryptedDataContainer
{
    public PaEncTimestampContainer() {
        this.setEncryptedData(new PaEncTimestamp());
    }
    
    public PaEncTimestamp getPaEncTimestamp() {
        return (PaEncTimestamp)this.getEncryptedData();
    }
}
