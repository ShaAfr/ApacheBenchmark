// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import java.util.Arrays;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class EncryptedData implements Asn1Object
{
    private static final Logger log;
    private static final boolean IS_DEBUG;
    private EncryptionType eType;
    private int kvno;
    private boolean hasKvno;
    private byte[] cipher;
    public static final boolean HAS_KVNO = true;
    private int eTypeTagLength;
    private int kvnoTagLength;
    private int cipherTagLength;
    private int encryptedDataSeqLength;
    
    public EncryptedData() {
        this.hasKvno = false;
    }
    
    public EncryptedData(final EncryptionType eType, final int kvno, final byte[] cipher) {
        this.eType = eType;
        this.hasKvno = (kvno > 0);
        this.kvno = kvno;
        this.cipher = cipher;
    }
    
    public EncryptedData(final EncryptionType eType, final byte[] cipher) {
        this.eType = eType;
        this.hasKvno = false;
        this.kvno = -1;
        this.cipher = cipher;
    }
    
    public EncryptionType getEType() {
        return this.eType;
    }
    
    public void setEType(final EncryptionType eType) {
        this.eType = eType;
    }
    
    public int getKvno() {
        return this.hasKvno ? this.kvno : -1;
    }
    
    public void setKvno(final int kvno) {
        this.kvno = kvno;
        this.hasKvno = true;
    }
    
    public boolean hasKvno() {
        return this.hasKvno;
    }
    
    public byte[] getCipher() {
        return this.cipher;
    }
    
    public void setCipher(final byte[] cipher) {
        this.cipher = cipher;
    }
    
    public int computeLength() {
        this.encryptedDataSeqLength = 0;
        final int eTypeLength = BerValue.getNbBytes(this.eType.getValue());
        this.eTypeTagLength = 1 + TLV.getNbBytes(eTypeLength) + eTypeLength;
        this.encryptedDataSeqLength = 1 + TLV.getNbBytes(this.eTypeTagLength) + this.eTypeTagLength;
        if (this.hasKvno) {
            final int kvnoLength = BerValue.getNbBytes(this.kvno);
            this.kvnoTagLength = 1 + TLV.getNbBytes(kvnoLength) + kvnoLength;
            this.encryptedDataSeqLength += 1 + TLV.getNbBytes(this.kvnoTagLength) + this.kvnoTagLength;
        }
        else {
            this.kvnoTagLength = 0;
        }
        if (this.cipher == null || this.cipher.length == 0) {
            this.cipherTagLength = 2;
        }
        else {
            this.cipherTagLength = 1 + TLV.getNbBytes(this.cipher.length) + this.cipher.length;
        }
        this.encryptedDataSeqLength += 1 + TLV.getNbBytes(this.cipherTagLength) + this.cipherTagLength;
        return 1 + TLV.getNbBytes(this.encryptedDataSeqLength) + this.encryptedDataSeqLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.encryptedDataSeqLength));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.eTypeTagLength));
            BerValue.encode(buffer, this.eType.getValue());
            if (this.hasKvno) {
                buffer.put((byte)(-95));
                buffer.put(TLV.getBytes(this.kvnoTagLength));
                BerValue.encode(buffer, this.kvno);
            }
            buffer.put((byte)(-94));
            buffer.put(TLV.getBytes(this.cipherTagLength));
            BerValue.encode(buffer, this.cipher);
        }
        catch (BufferOverflowException boe) {
            EncryptedData.log.error(I18n.err(I18n.ERR_141, new Object[] { 1 + TLV.getNbBytes(this.encryptedDataSeqLength) + this.encryptedDataSeqLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (EncryptedData.IS_DEBUG) {
            EncryptedData.log.debug("EncryptedData encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            EncryptedData.log.debug("EncryptedData initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + Arrays.hashCode(this.cipher);
        result = 31 * result + ((this.eType == null) ? 0 : this.eType.hashCode());
        result = 31 * result + this.kvno;
        return result;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        final EncryptedData other = (EncryptedData)obj;
        return Arrays.equals(this.cipher, other.cipher) && this.eType == other.eType && this.kvno == other.kvno;
    }
    
    @Override
    public String toString() {
        return this.toString("");
    }
    
    public String toString(final String tabs) {
        final StringBuilder sb = new StringBuilder();
        sb.append(tabs).append("EncryptedData : {\n");
        sb.append(tabs).append("    etype: ").append(this.eType).append('\n');
        if (this.hasKvno) {
            sb.append(tabs).append("    kvno: ").append(this.kvno).append('\n');
        }
        sb.append(tabs).append("    cipher: ").append(Strings.dumpBytes(this.cipher)).append("\n}\n");
        return sb.toString();
    }
    
    static {
        log = LoggerFactory.getLogger((Class)EncryptedData.class);
        IS_DEBUG = EncryptedData.log.isDebugEnabled();
    }
}
