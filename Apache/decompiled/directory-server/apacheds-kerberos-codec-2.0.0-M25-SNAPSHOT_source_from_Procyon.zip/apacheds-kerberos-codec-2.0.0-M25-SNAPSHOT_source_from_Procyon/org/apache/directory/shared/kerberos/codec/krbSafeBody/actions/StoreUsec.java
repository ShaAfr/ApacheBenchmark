// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafeBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbSafeBody.KrbSafeBodyContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreUsec extends AbstractReadInteger<KrbSafeBodyContainer>
{
    public StoreUsec() {
        super("KRB-SAFE-BODY usec", 0, 999999);
    }
    
    protected void setIntegerValue(final int value, final KrbSafeBodyContainer krbSafeBodyContainer) {
        krbSafeBodyContainer.getKrbSafeBody().setUsec(value);
    }
}
