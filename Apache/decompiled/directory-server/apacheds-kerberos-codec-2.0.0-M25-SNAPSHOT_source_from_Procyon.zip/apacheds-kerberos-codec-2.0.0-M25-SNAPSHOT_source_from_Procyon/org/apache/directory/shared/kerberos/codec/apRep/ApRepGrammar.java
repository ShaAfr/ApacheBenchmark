// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apRep;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.apRep.actions.StoreEncPart;
import org.apache.directory.shared.kerberos.codec.apRep.actions.CheckMsgType;
import org.apache.directory.shared.kerberos.codec.apRep.actions.StorePvno;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.apRep.actions.ApRepInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class ApRepGrammar extends AbstractGrammar<ApRepContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<ApRepContainer> instance;
    
    private ApRepGrammar() {
        this.setName(ApRepGrammar.class.getName());
        super.transitions = new GrammarTransition[ApRepStatesEnum.LAST_AP_REP_STATE.ordinal()][256];
        super.transitions[ApRepStatesEnum.START_STATE.ordinal()][111] = new GrammarTransition((Enum)ApRepStatesEnum.START_STATE, (Enum)ApRepStatesEnum.AP_REP_STATE, 111, (Action)new ApRepInit());
        super.transitions[ApRepStatesEnum.AP_REP_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ApRepStatesEnum.AP_REP_STATE, (Enum)ApRepStatesEnum.AP_REP_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[ApRepStatesEnum.AP_REP_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)ApRepStatesEnum.AP_REP_SEQ_STATE, (Enum)ApRepStatesEnum.AP_REP_PVNO_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[ApRepStatesEnum.AP_REP_PVNO_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)ApRepStatesEnum.AP_REP_PVNO_TAG_STATE, (Enum)ApRepStatesEnum.AP_REP_PVNO_STATE, UniversalTag.INTEGER, (Action)new StorePvno());
        super.transitions[ApRepStatesEnum.AP_REP_PVNO_STATE.ordinal()][161] = new GrammarTransition((Enum)ApRepStatesEnum.AP_REP_PVNO_STATE, (Enum)ApRepStatesEnum.AP_REP_MSG_TYPE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[ApRepStatesEnum.AP_REP_MSG_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)ApRepStatesEnum.AP_REP_MSG_TYPE_TAG_STATE, (Enum)ApRepStatesEnum.AP_REP_MSG_TYPE_STATE, UniversalTag.INTEGER, (Action)new CheckMsgType());
        super.transitions[ApRepStatesEnum.AP_REP_MSG_TYPE_STATE.ordinal()][162] = new GrammarTransition((Enum)ApRepStatesEnum.AP_REP_MSG_TYPE_STATE, (Enum)ApRepStatesEnum.AP_REP_ENC_PART_STATE, 162, (Action)new StoreEncPart());
    }
    
    public static Grammar<ApRepContainer> getInstance() {
        return ApRepGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ApRepGrammar.class);
        IS_DEBUG = ApRepGrammar.LOG.isDebugEnabled();
        ApRepGrammar.instance = (Grammar<ApRepContainer>)new ApRepGrammar();
    }
}
