// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apRep.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.messages.ApRep;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.apRep.ApRepContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class ApRepInit extends GrammarAction<ApRepContainer>
{
    private static final Logger LOG;
    
    public ApRepInit() {
        super("AP-REP initialization");
    }
    
    public void action(final ApRepContainer apRepContainer) throws DecoderException {
        final TLV tlv = apRepContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            ApRepInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final ApRep apRep = new ApRep();
        apRepContainer.setApRep(apRep);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ApRepInit.class);
    }
}
