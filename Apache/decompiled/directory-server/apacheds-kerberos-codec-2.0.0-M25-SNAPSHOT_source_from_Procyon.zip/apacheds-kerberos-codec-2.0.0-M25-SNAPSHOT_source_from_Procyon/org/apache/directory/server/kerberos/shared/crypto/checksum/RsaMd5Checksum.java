// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.checksum;

import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import org.apache.directory.api.ldap.model.constants.LdapSecurityConstants;
import org.apache.directory.server.kerberos.shared.crypto.encryption.KeyUsage;
import org.apache.directory.shared.kerberos.crypto.checksum.ChecksumType;

class RsaMd5Checksum implements ChecksumEngine
{
    @Override
    public ChecksumType checksumType() {
        return ChecksumType.RSA_MD5;
    }
    
    @Override
    public byte[] calculateChecksum(final byte[] data, final byte[] key, final KeyUsage usage) {
        try {
            final MessageDigest digester = MessageDigest.getInstance(LdapSecurityConstants.HASH_METHOD_MD5.getAlgorithm());
            return digester.digest(data);
        }
        catch (NoSuchAlgorithmException nsae) {
            return null;
        }
    }
}
