// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.padata;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.padata.actions.StorePaDataValue;
import org.apache.directory.shared.kerberos.codec.padata.actions.StoreDataType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.padata.actions.PaDataInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class PaDataGrammar extends AbstractGrammar<PaDataContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<PaDataContainer> instance;
    
    private PaDataGrammar() {
        this.setName(PaDataGrammar.class.getName());
        super.transitions = new GrammarTransition[PaDataStatesEnum.LAST_PADATA_STATE.ordinal()][256];
        super.transitions[PaDataStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)PaDataStatesEnum.START_STATE, (Enum)PaDataStatesEnum.PADATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new PaDataInit());
        super.transitions[PaDataStatesEnum.PADATA_SEQ_STATE.ordinal()][161] = new GrammarTransition((Enum)PaDataStatesEnum.PADATA_SEQ_STATE, (Enum)PaDataStatesEnum.PADATA_TYPE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[PaDataStatesEnum.PADATA_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)PaDataStatesEnum.PADATA_TYPE_TAG_STATE, (Enum)PaDataStatesEnum.PADATA_TYPE_STATE, UniversalTag.INTEGER, (Action)new StoreDataType());
        super.transitions[PaDataStatesEnum.PADATA_TYPE_STATE.ordinal()][162] = new GrammarTransition((Enum)PaDataStatesEnum.PADATA_TYPE_STATE, (Enum)PaDataStatesEnum.PADATA_VALUE_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[PaDataStatesEnum.PADATA_VALUE_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.getValue()] = new GrammarTransition((Enum)PaDataStatesEnum.PADATA_VALUE_TAG_STATE, (Enum)PaDataStatesEnum.PADATA_VALUE_STATE, UniversalTag.OCTET_STRING, (Action)new StorePaDataValue());
    }
    
    public static Grammar<PaDataContainer> getInstance() {
        return PaDataGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)PaDataGrammar.class);
        IS_DEBUG = PaDataGrammar.LOG.isDebugEnabled();
        PaDataGrammar.instance = (Grammar<PaDataContainer>)new PaDataGrammar();
    }
}
