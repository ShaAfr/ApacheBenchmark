// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.tgsReq;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.tgsReq.actions.StoreKdcReq;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class TgsReqGrammar extends AbstractGrammar<TgsReqContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<TgsReqContainer> instance;
    
    private TgsReqGrammar() {
        this.setName(TgsReqGrammar.class.getName());
        super.transitions = new GrammarTransition[TgsReqStatesEnum.LAST_TGS_REQ_STATE.ordinal()][256];
        super.transitions[TgsReqStatesEnum.START_STATE.ordinal()][108] = new GrammarTransition((Enum)TgsReqStatesEnum.START_STATE, (Enum)TgsReqStatesEnum.TGS_REQ_STATE, 108, (Action)new StoreKdcReq());
    }
    
    public static Grammar<TgsReqContainer> getInstance() {
        return TgsReqGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)TgsReqGrammar.class);
        IS_DEBUG = TgsReqGrammar.LOG.isDebugEnabled();
        TgsReqGrammar.instance = (Grammar<TgsReqContainer>)new TgsReqGrammar();
    }
}
