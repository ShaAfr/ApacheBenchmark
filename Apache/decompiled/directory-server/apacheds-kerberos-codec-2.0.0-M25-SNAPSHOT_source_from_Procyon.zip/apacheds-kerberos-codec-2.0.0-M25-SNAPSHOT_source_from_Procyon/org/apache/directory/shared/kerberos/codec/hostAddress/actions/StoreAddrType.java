// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddress.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.shared.kerberos.codec.types.HostAddrType;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.hostAddress.HostAddressContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreAddrType extends AbstractReadInteger<HostAddressContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreAddrType() {
        super("Creates a HostAddress instance", 0, Integer.MAX_VALUE);
    }
    
    protected void setIntegerValue(final int value, final HostAddressContainer hostAddressContainer) {
        final HostAddress hostAddressData = hostAddressContainer.getHostAddress();
        final HostAddrType hostAddrType = HostAddrType.getTypeByOrdinal(value);
        hostAddressData.setAddrType(hostAddrType);
        if (StoreAddrType.IS_DEBUG) {
            StoreAddrType.LOG.debug("addr-type : {}", (Object)hostAddrType);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreAddrType.class);
        IS_DEBUG = StoreAddrType.LOG.isDebugEnabled();
    }
}
