// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptionKey.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encryptionKey.EncryptionKeyContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreKeyType extends AbstractReadInteger<EncryptionKeyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreKeyType() {
        super("EncryptionKey's keytype");
    }
    
    protected void setIntegerValue(final int value, final EncryptionKeyContainer encryptionKeyContainer) {
        final EncryptionKey encKey = encryptionKeyContainer.getEncryptionKey();
        final EncryptionType encryptionType = EncryptionType.getTypeByValue(value);
        encKey.setKeyType(encryptionType);
        if (StoreKeyType.IS_DEBUG) {
            StoreKeyType.LOG.debug("keytype : {}", (Object)encryptionType);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreKeyType.class);
        IS_DEBUG = StoreKeyType.LOG.isDebugEnabled();
    }
}
