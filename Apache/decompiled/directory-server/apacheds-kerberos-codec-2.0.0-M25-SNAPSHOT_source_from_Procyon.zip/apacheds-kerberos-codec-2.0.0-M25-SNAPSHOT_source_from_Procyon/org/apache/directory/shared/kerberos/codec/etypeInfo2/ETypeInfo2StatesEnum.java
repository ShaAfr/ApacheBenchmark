// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum ETypeInfo2StatesEnum implements States
{
    START_STATE, 
    ETYPE_INFO2_SEQ_STATE, 
    LAST_ETYPE_INFO2_STATE;
    
    public String getGrammarName(final int grammar) {
        return "ETYPE_INFO2_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<ETypeInfo2Container> grammar) {
        if (grammar instanceof ETypeInfo2Grammar) {
            return "ETYPE_INFO2_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == ETypeInfo2StatesEnum.LAST_ETYPE_INFO2_STATE.ordinal()) ? "LAST_ETYPE_INFO2_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == ETypeInfo2StatesEnum.LAST_ETYPE_INFO2_STATE;
    }
    
    public ETypeInfo2StatesEnum getStartState() {
        return ETypeInfo2StatesEnum.START_STATE;
    }
}
