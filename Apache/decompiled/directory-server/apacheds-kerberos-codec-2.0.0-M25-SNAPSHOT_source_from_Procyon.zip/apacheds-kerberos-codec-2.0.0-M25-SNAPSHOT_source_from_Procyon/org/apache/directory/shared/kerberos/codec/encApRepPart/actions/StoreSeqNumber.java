// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encApRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encApRepPart.EncApRepPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreSeqNumber extends AbstractReadInteger<EncApRepPartContainer>
{
    public StoreSeqNumber() {
        super("EncApRepPart seq-number", Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    
    protected void setIntegerValue(final int value, final EncApRepPartContainer encApRepPartContainer) {
        encApRepPartContainer.getEncApRepPart().setSeqNumber(value);
        encApRepPartContainer.setGrammarEndAllowed(true);
    }
}
