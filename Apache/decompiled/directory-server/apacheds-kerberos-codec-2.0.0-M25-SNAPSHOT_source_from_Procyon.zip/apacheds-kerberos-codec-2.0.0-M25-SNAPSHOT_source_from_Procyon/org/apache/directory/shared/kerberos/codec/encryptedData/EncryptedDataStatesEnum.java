// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptedData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum EncryptedDataStatesEnum implements States
{
    START_STATE, 
    ENCRYPTED_DATA_SEQ_STATE, 
    ENCRYPTED_DATA_ETYPE_TAG_STATE, 
    ENCRYPTED_DATA_ETYPE_STATE, 
    ENCRYPTED_DATA_KVNO_TAG_STATE, 
    ENCRYPTED_DATA_KVNO_STATE, 
    ENCRYPTED_DATA_CIPHER_TAG_STATE, 
    ENCRYPTED_DATA_CIPHER_STATE, 
    LAST_ENCRYPTED_DATA_STATE;
    
    public String getGrammarName(final int grammar) {
        return "ENCRYPTED_DATA_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<EncryptedDataContainer> grammar) {
        if (grammar instanceof EncryptedDataGrammar) {
            return "ENCRYPTED_DATA_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == EncryptedDataStatesEnum.LAST_ENCRYPTED_DATA_STATE.ordinal()) ? "ENCRYPTED_DATA_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == EncryptedDataStatesEnum.LAST_ENCRYPTED_DATA_STATE;
    }
    
    public EncryptedDataStatesEnum getStartState() {
        return EncryptedDataStatesEnum.START_STATE;
    }
}
