// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

public class NFold
{
    public static byte[] nFold(final int n, final byte[] data) {
        final int k = data.length * 8;
        final int lcm = getLcm(n, k);
        final int replicate = lcm / k;
        final byte[] sumBytes = new byte[lcm / 8];
        for (int i = 0; i < replicate; ++i) {
            final int rotation = 13 * i;
            final byte[] temp = rotateRight(data, data.length * 8, rotation);
            for (int j = 0; j < temp.length; ++j) {
                sumBytes[j + i * temp.length] = temp[j];
            }
        }
        final byte[] sum = new byte[n / 8];
        byte[] nfold = new byte[n / 8];
        for (int m = 0; m < lcm / n; ++m) {
            for (int o = 0; o < n / 8; ++o) {
                sum[o] = sumBytes[o + m * n / 8];
            }
            nfold = sum(nfold, sum, nfold.length * 8);
        }
        return nfold;
    }
    
    protected static int getLcm(int n1, int n2) {
        final int product = n1 * n2;
        do {
            if (n1 < n2) {
                final int temp = n1;
                n1 = n2;
                n2 = temp;
            }
            n1 %= n2;
        } while (n1 != 0);
        return product / n2;
    }
    
    private static byte[] rotateRight(final byte[] in, final int len, final int step) {
        final int numOfBytes = (len - 1) / 8 + 1;
        final byte[] out = new byte[numOfBytes];
        for (int i = 0; i < len; ++i) {
            final int val = getBit(in, i);
            setBit(out, (i + step) % len, val);
        }
        return out;
    }
    
    protected static byte[] sum(final byte[] n1, final byte[] n2, final int len) {
        final int numOfBytes = (len - 1) / 8 + 1;
        byte[] out = new byte[numOfBytes];
        int carry = 0;
        for (int i = len - 1; i > -1; --i) {
            final int n1b = getBit(n1, i);
            final int n2b = getBit(n2, i);
            final int sum = n1b + n2b + carry;
            if (sum == 0 || sum == 1) {
                setBit(out, i, sum);
                carry = 0;
            }
            else if (sum == 2) {
                carry = 1;
            }
            else if (sum == 3) {
                setBit(out, i, 1);
                carry = 1;
            }
        }
        if (carry == 1) {
            final byte[] carryArray = new byte[n1.length];
            carryArray[carryArray.length - 1] = 1;
            out = sum(out, carryArray, n1.length * 8);
        }
        return out;
    }
    
    private static int getBit(final byte[] data, final int pos) {
        final int posByte = pos / 8;
        final int posBit = pos % 8;
        final byte valByte = data[posByte];
        final int valInt = valByte >> 8 - (posBit + 1) & 0x1;
        return valInt;
    }
    
    private static void setBit(final byte[] data, final int pos, final int val) {
        final int posByte = pos / 8;
        final int posBit = pos % 8;
        byte oldByte = data[posByte];
        oldByte = (byte)(65407 >> posBit & oldByte & 0xFF);
        final byte newByte = (byte)(val << 8 - (posBit + 1) | oldByte);
        data[posByte] = newByte;
    }
}
