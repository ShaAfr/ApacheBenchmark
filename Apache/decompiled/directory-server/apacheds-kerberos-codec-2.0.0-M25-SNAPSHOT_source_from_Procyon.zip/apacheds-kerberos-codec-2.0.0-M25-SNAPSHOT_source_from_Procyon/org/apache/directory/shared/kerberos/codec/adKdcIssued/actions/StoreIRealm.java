// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adKdcIssued.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.adKdcIssued.AdKdcIssuedContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StoreIRealm extends AbstractReadRealm<AdKdcIssuedContainer>
{
    public StoreIRealm() {
        super("Authenticator i-realm value");
    }
    
    @Override
    protected void setRealm(final String realm, final AdKdcIssuedContainer adKdcIssuedContainer) {
        adKdcIssuedContainer.getAdKdcIssued().setIRealm(realm);
    }
}
