// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddresses;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.hostAddresses.actions.AddHostAddress;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class HostAddressesGrammar extends AbstractGrammar<HostAddressesContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<HostAddressesContainer> instance;
    
    private HostAddressesGrammar() {
        this.setName(HostAddressesGrammar.class.getName());
        super.transitions = new GrammarTransition[HostAddressesStatesEnum.LAST_HOST_ADDRESSES_STATE.ordinal()][256];
        super.transitions[HostAddressesStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)HostAddressesStatesEnum.START_STATE, (Enum)HostAddressesStatesEnum.HOST_ADDRESSES_ADDRESS_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[HostAddressesStatesEnum.HOST_ADDRESSES_ADDRESS_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)HostAddressesStatesEnum.HOST_ADDRESSES_ADDRESS_STATE, (Enum)HostAddressesStatesEnum.HOST_ADDRESSES_ADDRESS_STATE, UniversalTag.SEQUENCE, (Action)new AddHostAddress());
    }
    
    public static Grammar<HostAddressesContainer> getInstance() {
        return HostAddressesGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)HostAddressesGrammar.class);
        IS_DEBUG = HostAddressesGrammar.LOG.isDebugEnabled();
        HostAddressesGrammar.instance = (Grammar<HostAddressesContainer>)new HostAddressesGrammar();
    }
}
