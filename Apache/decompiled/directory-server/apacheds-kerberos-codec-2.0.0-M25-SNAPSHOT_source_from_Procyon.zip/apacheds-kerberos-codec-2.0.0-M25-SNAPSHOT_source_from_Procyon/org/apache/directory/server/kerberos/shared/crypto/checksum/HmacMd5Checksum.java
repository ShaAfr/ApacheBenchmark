// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.checksum;

import javax.crypto.SecretKey;
import java.security.GeneralSecurityException;
import java.security.Key;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.directory.server.kerberos.shared.crypto.encryption.KeyUsage;
import org.apache.directory.shared.kerberos.crypto.checksum.ChecksumType;

class HmacMd5Checksum implements ChecksumEngine
{
    @Override
    public ChecksumType checksumType() {
        return ChecksumType.HMAC_MD5;
    }
    
    @Override
    public byte[] calculateChecksum(final byte[] data, final byte[] key, final KeyUsage usage) {
        try {
            final SecretKey sk = new SecretKeySpec(key, "ARCFOUR");
            final Mac mac = Mac.getInstance("HmacMD5");
            mac.init(sk);
            return mac.doFinal(data);
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
}
