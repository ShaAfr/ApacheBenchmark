// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfoEntry;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum ETypeInfoEntryStatesEnum implements States
{
    START_STATE, 
    ETYPE_INFO_ENTRY_SEQ_STATE, 
    ETYPE_INFO_ENTRY_ETYPE_TAG_STATE, 
    ETYPE_INFO_ENTRY_ETYPE_STATE, 
    ETYPE_INFO_ENTRY_SALT_TAG_STATE, 
    ETYPE_INFO_ENTRY_SALT_STATE, 
    LAST_ETYPE_INFO_ENTRY_STATE;
    
    public String getGrammarName(final int grammar) {
        return "ETYPE_INFO_ENTRY_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<ETypeInfoEntryContainer> grammar) {
        if (grammar instanceof ETypeInfoEntryGrammar) {
            return "ETYPE_INFO_ENTRY_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == ETypeInfoEntryStatesEnum.LAST_ETYPE_INFO_ENTRY_STATE.ordinal()) ? "LAST_ETYPE_INFO_ENTRY_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == ETypeInfoEntryStatesEnum.LAST_ETYPE_INFO_ENTRY_STATE;
    }
    
    public ETypeInfoEntryStatesEnum getStartState() {
        return ETypeInfoEntryStatesEnum.START_STATE;
    }
}
