// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.messages;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.shared.kerberos.components.Checksum;
import org.apache.directory.shared.kerberos.components.KrbSafeBody;
import org.slf4j.Logger;

public class KrbSafe extends KerberosMessage
{
    private static final Logger log;
    private static final boolean IS_DEBUG;
    private KrbSafeBody krbSafeBody;
    private Checksum checksum;
    private int pvnoLen;
    private int msgTypeLength;
    private int krbSafeBodyLen;
    private int checksumLen;
    private int krbSafeSeqLen;
    private int krbSafeLen;
    
    public KrbSafe() {
        super(KerberosMessageType.KRB_SAFE);
    }
    
    public KrbSafeBody getSafeBody() {
        return this.krbSafeBody;
    }
    
    public void setSafeBody(final KrbSafeBody safeBody) {
        this.krbSafeBody = safeBody;
    }
    
    public Checksum getChecksum() {
        return this.checksum;
    }
    
    public void setChecksum(final Checksum checksum) {
        this.checksum = checksum;
    }
    
    public int computeLength() {
        this.pvnoLen = 3;
        this.krbSafeSeqLen = 1 + TLV.getNbBytes(this.pvnoLen) + this.pvnoLen;
        this.msgTypeLength = 2 + BerValue.getNbBytes(this.getMessageType().getValue());
        this.krbSafeSeqLen += 1 + TLV.getNbBytes(this.msgTypeLength) + this.msgTypeLength;
        this.krbSafeBodyLen = this.krbSafeBody.computeLength();
        this.krbSafeSeqLen += 1 + TLV.getNbBytes(this.krbSafeBodyLen) + this.krbSafeBodyLen;
        this.checksumLen = this.checksum.computeLength();
        this.krbSafeSeqLen += 1 + TLV.getNbBytes(this.checksumLen) + this.checksumLen;
        this.krbSafeLen = 1 + TLV.getNbBytes(this.krbSafeSeqLen) + this.krbSafeSeqLen;
        return 1 + TLV.getNbBytes(this.krbSafeLen) + this.krbSafeLen;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put((byte)116);
            buffer.put(TLV.getBytes(this.krbSafeLen));
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.krbSafeSeqLen));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.pvnoLen));
            BerValue.encode(buffer, this.getProtocolVersionNumber());
            buffer.put((byte)(-95));
            buffer.put(TLV.getBytes(this.msgTypeLength));
            BerValue.encode(buffer, this.getMessageType().getValue());
            buffer.put((byte)(-94));
            buffer.put(TLV.getBytes(this.krbSafeBodyLen));
            this.krbSafeBody.encode(buffer);
            buffer.put((byte)(-93));
            buffer.put(TLV.getBytes(this.checksumLen));
            this.checksum.encode(buffer);
        }
        catch (BufferOverflowException boe) {
            KrbSafe.log.error(I18n.err(I18n.ERR_736_CANNOT_ENCODE_KRBSAFE, new Object[] { 1 + TLV.getNbBytes(this.krbSafeLen) + this.krbSafeLen, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (KrbSafe.IS_DEBUG) {
            KrbSafe.log.debug("KrbSafe encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            KrbSafe.log.debug("KrbSafe initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("KRB-SAFE : {\n");
        sb.append("    pvno: ").append(this.getProtocolVersionNumber()).append('\n');
        sb.append("    msgType: ").append(this.getMessageType()).append('\n');
        if (this.krbSafeBody != null) {
            sb.append("    safe-body: ").append(this.krbSafeBody).append('\n');
        }
        if (this.checksum != null) {
            sb.append("    cusec: ").append(this.checksum).append('\n');
        }
        sb.append("}\n");
        return sb.toString();
    }
    
    static {
        log = LoggerFactory.getLogger((Class)KrbError.class);
        IS_DEBUG = KrbSafe.log.isDebugEnabled();
    }
}
