// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authorizationData.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.encryptedData.actions.StoreEType;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.codec.types.AuthorizationType;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.authorizationData.AuthorizationDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreAdType extends AbstractReadInteger<AuthorizationDataContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreAdType() {
        super("AuthorizationData adType");
    }
    
    protected void setIntegerValue(final int value, final AuthorizationDataContainer authorizationDataContainer) {
        final AuthorizationType authType = AuthorizationType.getTypeByValue(value);
        final AuthorizationData authorizationData = authorizationDataContainer.getAuthorizationData();
        authorizationData.createNewAD();
        authorizationData.setCurrentAdType(authType);
        if (StoreAdType.IS_DEBUG) {
            StoreAdType.LOG.debug("zdType : {}", (Object)authType);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreEType.class);
        IS_DEBUG = StoreAdType.LOG.isDebugEnabled();
    }
}
