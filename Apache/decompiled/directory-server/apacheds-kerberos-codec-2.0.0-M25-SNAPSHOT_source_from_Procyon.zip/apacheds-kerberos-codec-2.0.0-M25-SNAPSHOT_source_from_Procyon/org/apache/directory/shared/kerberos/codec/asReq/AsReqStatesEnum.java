// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.asReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum AsReqStatesEnum implements States
{
    START_STATE, 
    AS_REQ_STATE, 
    LAST_AS_REQ_STATE;
    
    public String getGrammarName(final int grammar) {
        return "AS_REQ_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<AsReqContainer> grammar) {
        if (grammar instanceof AsReqGrammar) {
            return "AS_REQ_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == AsReqStatesEnum.LAST_AS_REQ_STATE.ordinal()) ? "AS_REQ_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == AsReqStatesEnum.LAST_AS_REQ_STATE;
    }
    
    public AsReqStatesEnum getStartState() {
        return AsReqStatesEnum.START_STATE;
    }
}
