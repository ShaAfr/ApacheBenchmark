// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import java.security.SecureRandom;

public abstract class EncryptionEngine
{
    private static final SecureRandom random;
    
    protected abstract byte[] getDecryptedData(final EncryptionKey p0, final EncryptedData p1, final KeyUsage p2) throws KerberosException;
    
    protected abstract EncryptedData getEncryptedData(final EncryptionKey p0, final byte[] p1, final KeyUsage p2);
    
    protected abstract EncryptionType getEncryptionType();
    
    protected abstract int getConfounderLength();
    
    protected abstract int getChecksumLength();
    
    protected abstract byte[] encrypt(final byte[] p0, final byte[] p1);
    
    protected abstract byte[] decrypt(final byte[] p0, final byte[] p1);
    
    protected abstract byte[] calculateIntegrity(final byte[] p0, final byte[] p1, final KeyUsage p2);
    
    protected byte[] deriveRandom(final byte[] key, final byte[] usage, final int n, final int k) {
        final byte[] nFoldedUsage = NFold.nFold(n, usage);
        final int kBytes = k / 8;
        final byte[] result = new byte[kBytes];
        byte[] fillingKey = this.encrypt(nFoldedUsage, key);
        int pos = 0;
        for (int i = 0; i < kBytes; ++i) {
            if (pos < fillingKey.length) {
                result[i] = fillingKey[pos];
                ++pos;
            }
            else {
                fillingKey = this.encrypt(fillingKey, key);
                pos = 0;
                result[i] = fillingKey[pos];
                ++pos;
            }
        }
        return result;
    }
    
    protected byte[] getRandomBytes(final int size) {
        final byte[] bytes = new byte[size];
        EncryptionEngine.random.nextBytes(bytes);
        return bytes;
    }
    
    protected byte[] padString(final byte[] encodedString) {
        int x;
        if (encodedString.length < 8) {
            x = encodedString.length;
        }
        else {
            x = encodedString.length % 8;
        }
        if (x == 0) {
            return encodedString;
        }
        final byte[] paddedByteArray = new byte[8 - x + encodedString.length];
        for (int y = paddedByteArray.length - 1; y > encodedString.length - 1; --y) {
            paddedByteArray[y] = 0;
        }
        System.arraycopy(encodedString, 0, paddedByteArray, 0, encodedString.length);
        return paddedByteArray;
    }
    
    protected byte[] concatenateBytes(final byte[] array1, final byte[] array2) {
        final int l1 = array1.length;
        final int l2 = array2.length;
        final byte[] concatenatedBytes = new byte[l1 + l2];
        System.arraycopy(array1, 0, concatenatedBytes, 0, l1);
        System.arraycopy(array2, 0, concatenatedBytes, l1, l2);
        return concatenatedBytes;
    }
    
    protected byte[] removeLeadingBytes(final byte[] array, final int confounder, final int checksum) {
        final byte[] lessBytes = new byte[array.length - confounder - checksum];
        int j = 0;
        for (int i = confounder + checksum; i < array.length; ++i) {
            lessBytes[j] = array[i];
            ++j;
        }
        return lessBytes;
    }
    
    protected byte[] removeTrailingBytes(final byte[] array, final int confounder, final int checksum) {
        final byte[] lessBytes = new byte[array.length - confounder - checksum];
        int j = 0;
        for (int i = 0; i < array.length - confounder - checksum; ++i) {
            lessBytes[j] = array[i];
            ++j;
        }
        return lessBytes;
    }
    
    protected int getBit(final byte[] data, final int pos) {
        final int posByte = pos / 8;
        final int posBit = pos % 8;
        final byte valByte = data[posByte];
        final int valInt = valByte >> 8 - (posBit + 1) & 0x1;
        return valInt;
    }
    
    protected void setBit(final byte[] data, final int pos, final int val) {
        final int posByte = pos / 8;
        final int posBit = pos % 8;
        byte oldByte = data[posByte];
        oldByte = (byte)(65407 >> posBit & oldByte & 0xFF);
        final byte newByte = (byte)(val << 8 - (posBit + 1) | oldByte);
        data[posByte] = newByte;
    }
    
    protected byte[] getUsageKc(final KeyUsage usage) {
        return this.getUsage(usage.getOrdinal(), (byte)(-103));
    }
    
    protected byte[] getUsageKe(final KeyUsage usage) {
        return this.getUsage(usage.getOrdinal(), (byte)(-86));
    }
    
    protected byte[] getUsageKi(final KeyUsage usage) {
        return this.getUsage(usage.getOrdinal(), (byte)85);
    }
    
    private byte[] getUsage(final int usage, final byte constant) {
        final byte[] bytes = { (byte)(usage >>> 24 & 0xFF), (byte)(usage >> 16 & 0xFF), (byte)(usage >> 8 & 0xFF), (byte)(usage & 0xFF), constant };
        return bytes;
    }
    
    static {
        random = new SecureRandom();
    }
}
