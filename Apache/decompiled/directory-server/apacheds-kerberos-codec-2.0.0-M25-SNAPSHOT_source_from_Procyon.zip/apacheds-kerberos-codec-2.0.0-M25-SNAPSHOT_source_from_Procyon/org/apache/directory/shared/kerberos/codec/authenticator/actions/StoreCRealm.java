// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.authenticator.AuthenticatorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StoreCRealm extends AbstractReadRealm<AuthenticatorContainer>
{
    public StoreCRealm() {
        super("Authenticator crealm value");
    }
    
    @Override
    protected void setRealm(final String realm, final AuthenticatorContainer authenticatorContainer) {
        authenticatorContainer.getAuthenticator().setCRealm(realm);
    }
}
