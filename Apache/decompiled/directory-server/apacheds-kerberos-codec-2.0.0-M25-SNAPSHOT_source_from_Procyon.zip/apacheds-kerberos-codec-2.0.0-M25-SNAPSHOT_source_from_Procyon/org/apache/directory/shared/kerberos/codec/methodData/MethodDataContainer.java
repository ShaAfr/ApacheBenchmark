// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.methodData;

import org.apache.directory.shared.kerberos.components.PaData;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.MethodData;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class MethodDataContainer extends AbstractContainer
{
    private MethodData methodData;
    
    public MethodDataContainer() {
        this.methodData = new MethodData();
        this.setGrammar((Grammar)MethodDataGrammar.getInstance());
        this.setTransition((Enum)MethodDataStatesEnum.START_STATE);
    }
    
    public MethodData getMethodData() {
        return this.methodData;
    }
    
    public void setMethodData(final MethodData methodData) {
        this.methodData = methodData;
    }
    
    public void addPaData(final PaData paData) {
        this.methodData.addPaData(paData);
    }
}
