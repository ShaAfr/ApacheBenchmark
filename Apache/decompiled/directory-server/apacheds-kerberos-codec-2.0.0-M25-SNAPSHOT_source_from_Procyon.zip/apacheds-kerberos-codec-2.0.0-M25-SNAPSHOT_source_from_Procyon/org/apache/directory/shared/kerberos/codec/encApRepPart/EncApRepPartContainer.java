// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encApRepPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.EncApRepPart;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncApRepPartContainer extends AbstractContainer
{
    private EncApRepPart encApRepPart;
    
    public EncApRepPartContainer(final ByteBuffer stream) {
        super(stream);
        this.encApRepPart = new EncApRepPart();
        this.setGrammar((Grammar)EncApRepPartGrammar.getInstance());
        this.setTransition((Enum)EncApRepPartStatesEnum.START_STATE);
    }
    
    public EncApRepPart getEncApRepPart() {
        return this.encApRepPart;
    }
    
    public void setEncApRepPart(final EncApRepPart encApRepPart) {
        this.encApRepPart = encApRepPart;
    }
}
