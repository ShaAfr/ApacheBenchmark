// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcRep.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.kdcRep.KdcRepContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StoreCRealm extends AbstractReadRealm<KdcRepContainer>
{
    public StoreCRealm() {
        super("KDC-REP realm value");
    }
    
    @Override
    protected void setRealm(final String realm, final KdcRepContainer kdcRepContainer) {
        kdcRepContainer.getKdcRep().setCRealm(realm);
    }
}
