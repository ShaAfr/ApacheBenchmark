// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbPrivPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encKrbPrivPart.EncKrbPrivPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreUsec extends AbstractReadInteger<EncKrbPrivPartContainer>
{
    public StoreUsec() {
        super("EncKrbPrivPart usec", 0, 999999);
    }
    
    protected void setIntegerValue(final int value, final EncKrbPrivPartContainer encKrbPrivPartContainer) {
        encKrbPrivPartContainer.getEncKrbPrivPart().setUsec(value);
    }
}
