// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbPriv.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.codec.krbPriv.KrbPrivContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptedPart;

public class StoreEncPart extends AbstractReadEncryptedPart<KrbPrivContainer>
{
    public StoreEncPart() {
        super("KRB-PRIV enc-part");
    }
    
    @Override
    protected void setEncryptedData(final EncryptedData encryptedData, final KrbPrivContainer krbPrivContainer) {
        krbPrivContainer.getKrbPriv().setEncPart(encryptedData);
        krbPrivContainer.setGrammarEndAllowed(true);
    }
}
