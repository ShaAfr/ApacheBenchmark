// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.checksum;

import org.apache.directory.server.kerberos.shared.crypto.encryption.KeyUsage;
import org.apache.directory.shared.kerberos.crypto.checksum.ChecksumType;

public interface ChecksumEngine
{
    ChecksumType checksumType();
    
    byte[] calculateChecksum(final byte[] p0, final byte[] p1, final KeyUsage p2);
}
