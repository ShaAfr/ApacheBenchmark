// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import org.apache.directory.api.util.Strings;
import java.security.InvalidKeyException;
import javax.crypto.spec.DESKeySpec;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.SecretKey;
import java.security.GeneralSecurityException;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;

public class DesStringToKey
{
    public byte[] getKey(final String passPhrase) {
        return this.generateKey(passPhrase);
    }
    
    public byte[] getKey(final String password, final String realmName, final String userName) {
        return this.generateKey(password + realmName + userName);
    }
    
    protected byte[] generateKey(final String passPhrase) {
        final byte[] encodedByteArray = this.characterEncodeString(passPhrase);
        final byte[] paddedByteArray = this.padString(encodedByteArray);
        byte[] secretKey = this.fanFold(paddedByteArray);
        secretKey = this.setParity(secretKey);
        secretKey = this.getStrongKey(secretKey);
        secretKey = this.calculateChecksum(paddedByteArray, secretKey);
        secretKey = this.setParity(secretKey);
        secretKey = this.getStrongKey(secretKey);
        return secretKey;
    }
    
    protected byte[] setParity(final byte[] in) {
        final byte[] out = new byte[8];
        int bitCount = 0;
        int index = 0;
        for (int i = 0; i < 64; ++i) {
            if ((i + 1) % 8 == 0) {
                if (bitCount % 2 == 0) {
                    this.setBit(out, i, 1);
                }
                ++index;
                bitCount = 0;
            }
            else {
                final int val = this.getBit(in, index);
                final boolean bit = val > 0;
                if (bit) {
                    this.setBit(out, i, val);
                    ++bitCount;
                }
                ++index;
            }
        }
        return out;
    }
    
    protected int getBit(final byte[] data, final int pos) {
        final int posByte = pos / 8;
        final int posBit = pos % 8;
        final byte valByte = data[posByte];
        final int valInt = valByte >> 8 - (posBit + 1) & 0x1;
        return valInt;
    }
    
    protected void setBit(final byte[] data, final int pos, final int val) {
        final int posByte = pos / 8;
        final int posBit = pos % 8;
        byte oldByte = data[posByte];
        oldByte = (byte)(65407 >> posBit & oldByte & 0xFF);
        final byte newByte = (byte)(val << 8 - (posBit + 1) | oldByte);
        data[posByte] = newByte;
    }
    
    protected byte[] fanFold(final byte[] paddedByteArray) {
        final byte[] secretKey = new byte[8];
        for (int div = paddedByteArray.length / 8, ii = 0; ii < div; ++ii) {
            final byte[] blockValue1 = new byte[8];
            System.arraycopy(paddedByteArray, ii * 8, blockValue1, 0, 8);
            if (ii % 2 == 1) {
                byte tempbyte1 = 0;
                byte tempbyte2 = 0;
                final byte[] blockValue2 = new byte[8];
                for (int jj = 0; jj < 8; ++jj) {
                    tempbyte2 = 0;
                    for (int kk = 0; kk < 4; ++kk) {
                        tempbyte2 = (byte)(1 << 7 - kk & 0xFF);
                        tempbyte1 |= (byte)((blockValue1[jj] & tempbyte2) >>> 7 - 2 * kk);
                        tempbyte2 = 0;
                    }
                    for (int kk = 4; kk < 8; ++kk) {
                        tempbyte2 = (byte)(1 << 7 - kk & 0xFF);
                        tempbyte1 |= (byte)((blockValue1[jj] & tempbyte2) << 2 * kk - 7);
                        tempbyte2 = 0;
                    }
                    blockValue2[7 - jj] = tempbyte1;
                    tempbyte1 = 0;
                }
                for (int jj = 0; jj < 8; ++jj) {
                    blockValue2[jj] = (byte)((blockValue2[jj] & 0xFF) >>> 1 & 0xFF);
                }
                System.arraycopy(blockValue2, 0, blockValue1, 0, blockValue2.length);
            }
            for (int jj2 = 0; jj2 < 8; ++jj2) {
                blockValue1[jj2] = (byte)((blockValue1[jj2] & 0xFF) << 1 & 0xFF);
            }
            for (int jj2 = 0; jj2 < 8; ++jj2) {
                final byte[] array = secretKey;
                final int n = jj2;
                array[n] ^= blockValue1[jj2];
            }
        }
        return secretKey;
    }
    
    protected byte[] calculateChecksum(final byte[] data, final byte[] keyBytes) {
        try {
            final Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
            final SecretKey key = new SecretKeySpec(keyBytes, "DES");
            final AlgorithmParameterSpec paramSpec = new IvParameterSpec(keyBytes);
            cipher.init(1, key, paramSpec);
            final byte[] result = cipher.doFinal(data);
            final byte[] checksum = new byte[8];
            System.arraycopy(result, result.length - 8, checksum, 0, 8);
            return checksum;
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
    
    protected byte[] getStrongKey(final byte[] secretKey) {
        try {
            if (DESKeySpec.isWeak(secretKey, 0)) {
                final int n = 7;
                secretKey[n] ^= (byte)240;
            }
        }
        catch (InvalidKeyException ike) {
            return new byte[8];
        }
        return secretKey;
    }
    
    protected byte[] characterEncodeString(final String string) {
        byte[] encodedByteArray = new byte[string.length()];
        encodedByteArray = Strings.getBytesUtf8(string);
        return encodedByteArray;
    }
    
    protected byte[] padString(final byte[] encodedString) {
        int length;
        if (encodedString.length < 8) {
            length = encodedString.length;
        }
        else {
            length = encodedString.length % 8;
        }
        if (length == 0) {
            return encodedString;
        }
        final byte[] paddedByteArray = new byte[8 - length + encodedString.length];
        for (int ii = paddedByteArray.length - 1; ii > encodedString.length - 1; --ii) {
            paddedByteArray[ii] = 0;
        }
        System.arraycopy(encodedString, 0, paddedByteArray, 0, encodedString.length);
        return paddedByteArray;
    }
}
