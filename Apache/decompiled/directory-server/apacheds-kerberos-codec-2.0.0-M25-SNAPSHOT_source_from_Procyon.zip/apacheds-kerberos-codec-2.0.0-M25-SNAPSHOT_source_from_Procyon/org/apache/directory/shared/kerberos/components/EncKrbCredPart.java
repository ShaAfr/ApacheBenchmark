// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import java.util.Iterator;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosTime;
import java.util.List;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class EncKrbCredPart implements Asn1Object
{
    private static final Logger log;
    private static final boolean IS_DEBUG;
    private List<KrbCredInfo> ticketInfo;
    private Integer nonce;
    private KerberosTime timestamp;
    private Integer usec;
    private HostAddress senderAddress;
    private HostAddress recipientAddress;
    private int ticketInfoSeqLen;
    private int ticketInfoLen;
    private int nonceLen;
    private int timestampLen;
    private byte[] timestampBytes;
    private int usecLen;
    private int senderAddressLen;
    private int recipientAddressLen;
    private int encKrbCredPartSeqLen;
    private int encKrbCredPartLen;
    
    public int computeLength() {
        for (final KrbCredInfo kci : this.ticketInfo) {
            this.ticketInfoSeqLen += kci.computeLength();
        }
        this.ticketInfoLen = 1 + TLV.getNbBytes(this.ticketInfoSeqLen) + this.ticketInfoSeqLen;
        this.encKrbCredPartSeqLen = 1 + TLV.getNbBytes(this.ticketInfoLen) + this.ticketInfoLen;
        if (this.nonce != null) {
            this.nonceLen = BerValue.getNbBytes((int)this.nonce);
            this.nonceLen += 1 + TLV.getNbBytes(this.nonceLen);
            this.encKrbCredPartSeqLen += 1 + TLV.getNbBytes(this.nonceLen) + this.nonceLen;
        }
        if (this.timestamp != null) {
            this.timestampBytes = this.timestamp.getBytes();
            this.timestampLen = 1 + TLV.getNbBytes(this.timestampBytes.length) + this.timestampBytes.length;
            this.encKrbCredPartSeqLen += 1 + TLV.getNbBytes(this.timestampLen) + this.timestampLen;
        }
        if (this.usec != null) {
            this.usecLen = BerValue.getNbBytes((int)this.usec);
            this.usecLen += 1 + TLV.getNbBytes(this.usecLen);
            this.encKrbCredPartSeqLen += 1 + TLV.getNbBytes(this.usecLen) + this.usecLen;
        }
        if (this.senderAddress != null) {
            this.senderAddressLen = this.senderAddress.computeLength();
            this.encKrbCredPartSeqLen += 1 + TLV.getNbBytes(this.senderAddressLen) + this.senderAddressLen;
        }
        if (this.recipientAddress != null) {
            this.recipientAddressLen = this.recipientAddress.computeLength();
            this.encKrbCredPartSeqLen += 1 + TLV.getNbBytes(this.recipientAddressLen) + this.recipientAddressLen;
        }
        this.encKrbCredPartLen = 1 + TLV.getNbBytes(this.encKrbCredPartSeqLen) + this.encKrbCredPartSeqLen;
        return 1 + TLV.getNbBytes(this.encKrbCredPartLen) + this.encKrbCredPartLen;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put((byte)125);
            buffer.put(TLV.getBytes(this.encKrbCredPartLen));
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.encKrbCredPartSeqLen));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.ticketInfoLen));
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.ticketInfoSeqLen));
            for (final KrbCredInfo ki : this.ticketInfo) {
                ki.encode(buffer);
            }
            if (this.nonce != null) {
                buffer.put((byte)(-95));
                buffer.put(TLV.getBytes(this.nonceLen));
                BerValue.encode(buffer, (int)this.nonce);
            }
            if (this.timestamp != null) {
                buffer.put((byte)(-94));
                buffer.put(TLV.getBytes(this.timestampLen));
                buffer.put(UniversalTag.GENERALIZED_TIME.getValue());
                buffer.put((byte)15);
                buffer.put(this.timestampBytes);
            }
            if (this.usec != null) {
                buffer.put((byte)(-93));
                buffer.put(TLV.getBytes(this.usecLen));
                BerValue.encode(buffer, (int)this.usec);
            }
            if (this.senderAddress != null) {
                buffer.put((byte)(-92));
                buffer.put(TLV.getBytes(this.senderAddressLen));
                this.senderAddress.encode(buffer);
            }
            if (this.recipientAddress != null) {
                buffer.put((byte)(-91));
                buffer.put(TLV.getBytes(this.recipientAddressLen));
                this.recipientAddress.encode(buffer);
            }
        }
        catch (BufferOverflowException boe) {
            EncKrbCredPart.log.error(I18n.err(I18n.ERR_740_CANNOT_ENCODE_ENC_KRB_CRED_PART, new Object[] { 1 + TLV.getNbBytes(this.encKrbCredPartLen) + this.encKrbCredPartLen, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (EncKrbCredPart.IS_DEBUG) {
            EncKrbCredPart.log.debug("EncKrbCredPart encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            EncKrbCredPart.log.debug("EncKrbCredPart initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    public List<KrbCredInfo> getTicketInfo() {
        return this.ticketInfo;
    }
    
    public void setTicketInfo(final List<KrbCredInfo> ticketInfo) {
        this.ticketInfo = ticketInfo;
    }
    
    public Integer getNonce() {
        return this.nonce;
    }
    
    public void setNonce(final Integer nonce) {
        this.nonce = nonce;
    }
    
    public KerberosTime getTimestamp() {
        return this.timestamp;
    }
    
    public void setTimestamp(final KerberosTime timestamp) {
        this.timestamp = timestamp;
    }
    
    public Integer getUsec() {
        return this.usec;
    }
    
    public void setUsec(final Integer usec) {
        this.usec = usec;
    }
    
    public HostAddress getSenderAddress() {
        return this.senderAddress;
    }
    
    public void setSenderAddress(final HostAddress senderAddress) {
        this.senderAddress = senderAddress;
    }
    
    public HostAddress getRecipientAddress() {
        return this.recipientAddress;
    }
    
    public void setRecipientAddress(final HostAddress recipientAddress) {
        this.recipientAddress = recipientAddress;
    }
    
    public void addTicketInfo(final KrbCredInfo info) {
        if (info == null) {
            throw new IllegalArgumentException();
        }
        if (this.ticketInfo == null) {
            this.ticketInfo = new ArrayList<KrbCredInfo>();
        }
        this.ticketInfo.add(info);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("EncKrbCredPart : {\n");
        sb.append("    ticketInfo: ").append(this.ticketInfo).append('\n');
        if (this.nonce != null) {
            sb.append("    nonce: ").append(this.nonce).append('\n');
        }
        if (this.timestamp != null) {
            sb.append("    timestamp: ").append(this.timestamp).append('\n');
        }
        if (this.usec != null) {
            sb.append("    usec: ").append(this.usec).append('\n');
        }
        if (this.senderAddress != null) {
            sb.append("    senderAddress: ").append(this.senderAddress).append('\n');
        }
        if (this.recipientAddress != null) {
            sb.append("    recipientAddress: ").append(this.recipientAddress).append('\n');
        }
        sb.append("}\n");
        return sb.toString();
    }
    
    static {
        log = LoggerFactory.getLogger((Class)EncKrbCredPart.class);
        IS_DEBUG = EncKrbCredPart.log.isDebugEnabled();
    }
}
