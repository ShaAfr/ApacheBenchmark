// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec;

import org.apache.directory.api.asn1.EncoderException;
import java.io.IOException;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.Asn1Object;

public class KerberosEncoder
{
    public static ByteBuffer encode(final Asn1Object asn1Obj, final boolean isTcp) throws IOException {
        ByteBuffer kerberosMessage = null;
        int bufferLen;
        final int responseLength = bufferLen = asn1Obj.computeLength();
        if (isTcp) {
            bufferLen += 4;
        }
        kerberosMessage = ByteBuffer.allocate(bufferLen);
        if (isTcp) {
            kerberosMessage.putInt(responseLength);
        }
        try {
            asn1Obj.encode(kerberosMessage);
            kerberosMessage.flip();
            return kerberosMessage;
        }
        catch (EncoderException e) {
            throw new IOException(e.getMessage());
        }
    }
}
