// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.padata.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.shared.kerberos.components.PaData;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.padata.PaDataContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class PaDataInit extends GrammarAction<PaDataContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public PaDataInit() {
        super("Creates a PaData instance");
    }
    
    public void action(final PaDataContainer paDataContainer) throws DecoderException {
        final PaData paData = new PaData();
        paDataContainer.setPaData(paData);
        if (PaDataInit.IS_DEBUG) {
            PaDataInit.LOG.debug("PaData created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)PaDataInit.class);
        IS_DEBUG = PaDataInit.LOG.isDebugEnabled();
    }
}
