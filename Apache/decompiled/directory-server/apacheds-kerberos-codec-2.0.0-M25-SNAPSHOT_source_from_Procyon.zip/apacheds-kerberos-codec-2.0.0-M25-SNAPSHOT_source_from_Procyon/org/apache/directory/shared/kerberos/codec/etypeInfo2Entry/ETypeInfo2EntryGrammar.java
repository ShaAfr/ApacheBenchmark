// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2Entry;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.actions.StoreS2KParams;
import org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.actions.StoreSalt;
import org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.actions.StoreEType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.actions.ETypeInfo2EntryInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class ETypeInfo2EntryGrammar extends AbstractGrammar<ETypeInfo2EntryContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<ETypeInfo2EntryContainer> instance;
    
    private ETypeInfo2EntryGrammar() {
        this.setName(ETypeInfo2EntryGrammar.class.getName());
        super.transitions = new GrammarTransition[ETypeInfo2EntryStatesEnum.LAST_ETYPE_INFO2_ENTRY_STATE.ordinal()][256];
        super.transitions[ETypeInfo2EntryStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.START_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new ETypeInfo2EntryInit());
        super.transitions[ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SEQ_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_TAG_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_STATE, UniversalTag.INTEGER, (Action)new StoreEType());
        super.transitions[ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SALT_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_STATE.ordinal()][162] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_ETYPE_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_S2KPARAMS_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SALT_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SALT_TAG_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SALT_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreSalt());
        super.transitions[ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SALT_STATE.ordinal()][162] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_SALT_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_S2KPARAMS_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_S2KPARAMS_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.getValue()] = new GrammarTransition((Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_S2KPARAMS_TAG_STATE, (Enum)ETypeInfo2EntryStatesEnum.ETYPE_INFO2_ENTRY_S2KPARAMS_STATE, UniversalTag.OCTET_STRING, (Action)new StoreS2KParams());
    }
    
    public static Grammar<ETypeInfo2EntryContainer> getInstance() {
        return ETypeInfo2EntryGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfo2EntryGrammar.class);
        IS_DEBUG = ETypeInfo2EntryGrammar.LOG.isDebugEnabled();
        ETypeInfo2EntryGrammar.instance = (Grammar<ETypeInfo2EntryContainer>)new ETypeInfo2EntryGrammar();
    }
}
