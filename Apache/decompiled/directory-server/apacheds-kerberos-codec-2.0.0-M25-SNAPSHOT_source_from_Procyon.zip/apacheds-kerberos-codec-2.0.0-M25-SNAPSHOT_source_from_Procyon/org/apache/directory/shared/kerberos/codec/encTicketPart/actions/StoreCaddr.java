// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.HostAddresses;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadHostAddresses;

public class StoreCaddr extends AbstractReadHostAddresses<EncTicketPartContainer>
{
    public StoreCaddr() {
        super("EncTicketPart caddr");
    }
    
    @Override
    protected void setHostAddresses(final HostAddresses hostAddresses, final EncTicketPartContainer encTicketPartContainer) {
        encTicketPartContainer.getEncTicketPart().setClientAddresses(hostAddresses);
        encTicketPartContainer.setGrammarEndAllowed(true);
    }
}
