// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import java.util.Iterator;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class ETypeInfo implements Asn1Object
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private List<ETypeInfoEntry> etypeInfoEntries;
    private int etypeInfoLength;
    
    public ETypeInfo() {
        this.etypeInfoEntries = new ArrayList<ETypeInfoEntry>();
    }
    
    public ETypeInfo(final ETypeInfoEntry[] etypeInfoEntries) {
        if (etypeInfoEntries == null) {
            this.etypeInfoEntries = new ArrayList<ETypeInfoEntry>();
        }
        else {
            this.etypeInfoEntries = Arrays.asList(etypeInfoEntries);
        }
    }
    
    public void addETypeInfoEntry(final ETypeInfoEntry etypeInfoEntry) {
        this.etypeInfoEntries.add(etypeInfoEntry);
    }
    
    public boolean contains(final ETypeInfoEntry etypeInfoEntry) {
        return this.etypeInfoEntries != null && this.etypeInfoEntries.contains(etypeInfoEntry);
    }
    
    @Override
    public int hashCode() {
        int hash = 37;
        if (this.etypeInfoEntries != null) {
            hash = hash * 17 + this.etypeInfoEntries.size();
            for (final ETypeInfoEntry etypeInfoEntry : this.etypeInfoEntries) {
                hash = hash * 17 + etypeInfoEntry.hashCode();
            }
        }
        return hash;
    }
    
    public boolean equals(final ETypeInfo that) {
        if (that == null) {
            return false;
        }
        if (this.etypeInfoEntries.size() != that.etypeInfoEntries.size()) {
            return false;
        }
        for (int i = 0; i < this.etypeInfoEntries.size(); ++i) {
            if (!this.etypeInfoEntries.get(i).equals(that.etypeInfoEntries.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    public ETypeInfoEntry[] getETypeInfoEntries() {
        return this.etypeInfoEntries.toArray(new ETypeInfoEntry[0]);
    }
    
    public int computeLength() {
        this.etypeInfoLength = 0;
        if (this.etypeInfoEntries != null && this.etypeInfoEntries.size() != 0) {
            for (final ETypeInfoEntry infoEntry : this.etypeInfoEntries) {
                final int length = infoEntry.computeLength();
                this.etypeInfoLength += length;
            }
        }
        return 1 + TLV.getNbBytes(this.etypeInfoLength) + this.etypeInfoLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.etypeInfoLength));
            if (this.etypeInfoEntries != null && this.etypeInfoEntries.size() != 0) {
                for (final ETypeInfoEntry infoEntry : this.etypeInfoEntries) {
                    infoEntry.encode(buffer);
                }
            }
        }
        catch (BufferOverflowException boe) {
            ETypeInfo.LOG.error(I18n.err(I18n.ERR_144, new Object[] { 1 + TLV.getNbBytes(this.etypeInfoLength) + this.etypeInfoLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (ETypeInfo.IS_DEBUG) {
            ETypeInfo.LOG.debug("ETYPE-INFO encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            ETypeInfo.LOG.debug("ETYPE-INFO initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        boolean isFirst = true;
        for (final ETypeInfoEntry infoEntry : this.etypeInfoEntries) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sb.append(", ");
            }
            sb.append(infoEntry.toString());
        }
        return sb.toString();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfo.class);
        IS_DEBUG = ETypeInfo.LOG.isDebugEnabled();
    }
}
