// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.tgsRep;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.tgsRep.actions.StoreKdcRep;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class TgsRepGrammar extends AbstractGrammar<TgsRepContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<TgsRepContainer> instance;
    
    private TgsRepGrammar() {
        this.setName(TgsRepGrammar.class.getName());
        super.transitions = new GrammarTransition[TgsRepStatesEnum.LAST_TGS_REP_STATE.ordinal()][256];
        super.transitions[TgsRepStatesEnum.START_STATE.ordinal()][109] = new GrammarTransition((Enum)TgsRepStatesEnum.START_STATE, (Enum)TgsRepStatesEnum.TGS_REP_STATE, 109, (Action)new StoreKdcRep());
    }
    
    public static Grammar<TgsRepContainer> getInstance() {
        return TgsRepGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)TgsRepGrammar.class);
        IS_DEBUG = TgsRepGrammar.LOG.isDebugEnabled();
        TgsRepGrammar.instance = (Grammar<TgsRepContainer>)new TgsRepGrammar();
    }
}
