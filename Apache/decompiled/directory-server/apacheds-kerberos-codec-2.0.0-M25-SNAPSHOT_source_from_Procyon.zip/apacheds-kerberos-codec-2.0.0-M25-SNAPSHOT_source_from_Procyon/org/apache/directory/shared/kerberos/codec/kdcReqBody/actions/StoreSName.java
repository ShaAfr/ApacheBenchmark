// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreSName extends AbstractReadPrincipalName<KdcReqBodyContainer>
{
    public StoreSName() {
        super("Stores the SName");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final KdcReqBodyContainer kdcReqBodyContainer) {
        kdcReqBodyContainer.getKdcReqBody().setSName(principalName);
    }
}
