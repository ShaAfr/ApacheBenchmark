// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.changePwdData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum ChangePasswdDataStatesEnum implements States
{
    START_STATE, 
    CHNGPWD_SEQ_STATE, 
    CHNGPWD_NEWPASSWD_TAG_STATE, 
    CHNGPWD_NEWPASSWD_STATE, 
    CHNGPWD_TARGNAME_TAG_STATE, 
    CHNGPWD_TARGREALM_TAG_STATE, 
    CHNGPWD_TARGREALM_STATE, 
    LAST_CHNGPWD_STATE;
    
    public String getGrammarName(final int grammar) {
        return "CHNGPWD_DATA_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<ChangePasswdDataContainer> grammar) {
        if (grammar instanceof ChangePasswdDataGrammar) {
            return "CHNGPWD_DATA_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == ChangePasswdDataStatesEnum.LAST_CHNGPWD_STATE.ordinal()) ? "LAST_CHNGPWD_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == ChangePasswdDataStatesEnum.LAST_CHNGPWD_STATE;
    }
    
    public ChangePasswdDataStatesEnum getStartState() {
        return ChangePasswdDataStatesEnum.START_STATE;
    }
}
