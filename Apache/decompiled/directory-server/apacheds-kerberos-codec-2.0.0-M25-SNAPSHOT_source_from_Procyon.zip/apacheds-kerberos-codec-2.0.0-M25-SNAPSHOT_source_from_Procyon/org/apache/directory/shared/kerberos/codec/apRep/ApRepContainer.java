// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apRep;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.ApRep;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ApRepContainer extends AbstractContainer
{
    private ApRep apRep;
    
    public ApRepContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)ApRepGrammar.getInstance());
        this.setTransition((Enum)ApRepStatesEnum.START_STATE);
    }
    
    public ApRep getApRep() {
        return this.apRep;
    }
    
    public void setApRep(final ApRep apRep) {
        this.apRep = apRep;
    }
}
