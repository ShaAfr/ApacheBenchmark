// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreCName extends AbstractReadPrincipalName<EncTicketPartContainer>
{
    public StoreCName() {
        super("EncTicketPart cname");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final EncTicketPartContainer encTicketPartContainer) {
        encTicketPartContainer.getEncTicketPart().setCName(principalName);
    }
}
