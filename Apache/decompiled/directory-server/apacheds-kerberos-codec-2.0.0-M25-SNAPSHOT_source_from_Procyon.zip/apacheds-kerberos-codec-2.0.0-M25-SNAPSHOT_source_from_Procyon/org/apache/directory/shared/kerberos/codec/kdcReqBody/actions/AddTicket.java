// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.KdcReqBody;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AddTicket extends GrammarAction<KdcReqBodyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AddTicket() {
        super("KDC-REQ-BODY Add Ticket");
    }
    
    public void action(final KdcReqBodyContainer kdcReqBodyContainer) throws DecoderException {
        final TLV tlv = kdcReqBodyContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AddTicket.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder ticketDecoder = new Asn1Decoder();
        final TicketContainer ticketContainer = new TicketContainer(kdcReqBodyContainer.getStream());
        kdcReqBodyContainer.rewind();
        try {
            ticketDecoder.decode(kdcReqBodyContainer.getStream(), (Asn1Container)ticketContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        kdcReqBodyContainer.updateParent();
        final Ticket ticket = ticketContainer.getTicket();
        final KdcReqBody kdcReqBody = kdcReqBodyContainer.getKdcReqBody();
        kdcReqBody.addAdditionalTicket(ticket);
        kdcReqBodyContainer.setGrammarEndAllowed(true);
        if (AddTicket.IS_DEBUG) {
            AddTicket.LOG.debug("Added ticket:  {}", (Object)ticket);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AddTicket.class);
        IS_DEBUG = AddTicket.LOG.isDebugEnabled();
    }
}
