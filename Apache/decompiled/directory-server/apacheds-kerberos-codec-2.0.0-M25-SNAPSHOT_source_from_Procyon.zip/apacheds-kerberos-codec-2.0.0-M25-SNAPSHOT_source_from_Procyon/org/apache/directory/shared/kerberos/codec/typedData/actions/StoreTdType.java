// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.typedData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.TypedData;
import org.apache.directory.shared.kerberos.codec.typedData.TypedDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreTdType extends AbstractReadInteger<TypedDataContainer>
{
    public StoreTdType() {
        super("TypedData data-type");
    }
    
    protected void setIntegerValue(final int value, final TypedDataContainer typedDataContainer) {
        final TypedData typedData = typedDataContainer.getTypedData();
        typedData.createNewTD();
        typedData.setCurrentDataType(value);
        typedDataContainer.setGrammarEndAllowed(true);
    }
}
