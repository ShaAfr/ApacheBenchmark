// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.codec.authenticator.AuthenticatorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadAuthorizationData;

public class StoreAuthorizationData extends AbstractReadAuthorizationData<AuthenticatorContainer>
{
    public StoreAuthorizationData() {
        super("Authenticator authorization-data");
    }
    
    @Override
    protected void setAuthorizationData(final AuthorizationData authorizationData, final AuthenticatorContainer authenticatorContainer) {
        authenticatorContainer.getAuthenticator().setAuthorizationData(authorizationData);
        authenticatorContainer.setGrammarEndAllowed(true);
    }
}
