// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import java.util.Arrays;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class EncryptionKey implements Asn1Object
{
    private static final Logger log;
    private static final boolean IS_DEBUG;
    private EncryptionType keyType;
    private byte[] keyValue;
    private int keyVersion;
    private int keyTypeLength;
    private int keyValueLength;
    private int encryptionKeyLength;
    
    public EncryptionKey() {
    }
    
    public EncryptionKey(final EncryptionType keyType, final byte[] keyValue) {
        this.keyType = keyType;
        this.keyValue = keyValue;
    }
    
    public EncryptionKey(final EncryptionType keyType, final byte[] keyValue, final int keyVersion) {
        this.keyType = keyType;
        this.keyValue = keyValue;
        this.keyVersion = keyVersion;
    }
    
    public synchronized void destroy() {
        if (this.keyValue != null) {
            Arrays.fill(this.keyValue, (byte)0);
        }
    }
    
    public EncryptionType getKeyType() {
        return this.keyType;
    }
    
    public void setKeyType(final EncryptionType keyType) {
        this.keyType = keyType;
    }
    
    public byte[] getKeyValue() {
        return this.keyValue;
    }
    
    public int getKeyVersion() {
        return this.keyVersion;
    }
    
    public void setKeyVersion(final int keyVersion) {
        this.keyVersion = keyVersion;
    }
    
    public void setKeyValue(final byte[] keyValue) {
        this.keyValue = keyValue;
    }
    
    @Override
    public int hashCode() {
        int hash = 37;
        hash = hash * 17 + this.keyType.hashCode();
        hash = hash * 17 + Arrays.hashCode(this.keyValue);
        return hash;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || !(o instanceof EncryptionKey)) {
            return false;
        }
        final EncryptionKey that = (EncryptionKey)o;
        return this.keyType == that.keyType && Arrays.equals(this.keyValue, that.keyValue);
    }
    
    public int computeLength() {
        this.keyTypeLength = 2 + BerValue.getNbBytes(this.keyType.getValue());
        this.encryptionKeyLength = 1 + TLV.getNbBytes(this.keyTypeLength) + this.keyTypeLength;
        if (this.keyValue == null) {
            this.keyValueLength = 2;
        }
        else {
            this.keyValueLength = 1 + TLV.getNbBytes(this.keyValue.length) + this.keyValue.length;
        }
        this.encryptionKeyLength += 1 + TLV.getNbBytes(this.keyValueLength) + this.keyValueLength;
        final int encryptionKeySeqLength = 1 + BerValue.getNbBytes(this.encryptionKeyLength) + this.encryptionKeyLength;
        return encryptionKeySeqLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.encryptionKeyLength));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.keyTypeLength));
            BerValue.encode(buffer, this.keyType.getValue());
            buffer.put((byte)(-95));
            buffer.put(TLV.getBytes(this.keyValueLength));
            BerValue.encode(buffer, this.keyValue);
        }
        catch (BufferOverflowException boe) {
            EncryptionKey.log.error(I18n.err(I18n.ERR_142, new Object[] { 1 + TLV.getNbBytes(this.encryptionKeyLength) + this.encryptionKeyLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (EncryptionKey.IS_DEBUG) {
            EncryptionKey.log.debug("EncryptionKey encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            EncryptionKey.log.debug("EncryptionKey initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        return this.keyType.toString() + " (" + this.keyType.getValue() + ")";
    }
    
    static {
        log = LoggerFactory.getLogger((Class)EncryptionKey.class);
        IS_DEBUG = EncryptionKey.log.isDebugEnabled();
    }
}
