// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.principalName;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum PrincipalNameStatesEnum implements States
{
    START_STATE, 
    PRINCIPAL_NAME_SEQ_STATE, 
    PRINCIPAL_NAME_NAME_TYPE_TAG_STATE, 
    PRINCIPAL_NAME_NAME_TYPE_STATE, 
    PRINCIPAL_NAME_NAME_STRING_SEQ_STATE, 
    PRINCIPAL_NAME_NAME_STRING_TAG_STATE, 
    PRINCIPAL_NAME_NAME_STRING_STATE, 
    LAST_PRINCIPAL_NAME_STATE;
    
    public String getGrammarName(final int grammar) {
        return "PRINCIPAL_NAME_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<PrincipalNameContainer> grammar) {
        if (grammar instanceof PrincipalNameGrammar) {
            return "PRINCIPAL_NAME_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == PrincipalNameStatesEnum.LAST_PRINCIPAL_NAME_STATE.ordinal()) ? "PRINCIPAL_NAME_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == PrincipalNameStatesEnum.LAST_PRINCIPAL_NAME_STATE;
    }
    
    public PrincipalNameStatesEnum getStartState() {
        return PrincipalNameStatesEnum.START_STATE;
    }
}
