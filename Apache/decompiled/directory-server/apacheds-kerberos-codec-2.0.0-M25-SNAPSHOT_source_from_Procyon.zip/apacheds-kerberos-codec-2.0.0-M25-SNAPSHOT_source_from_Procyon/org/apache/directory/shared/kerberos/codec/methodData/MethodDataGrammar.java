// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.methodData;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.methodData.actions.AddPaData;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class MethodDataGrammar extends AbstractGrammar<MethodDataContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<MethodDataContainer> instance;
    
    private MethodDataGrammar() {
        this.setName(MethodDataGrammar.class.getName());
        super.transitions = new GrammarTransition[MethodDataStatesEnum.LAST_METHOD_DATA_STATE.ordinal()][256];
        super.transitions[MethodDataStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)MethodDataStatesEnum.START_STATE, (Enum)MethodDataStatesEnum.METHOD_DATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[MethodDataStatesEnum.METHOD_DATA_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)MethodDataStatesEnum.METHOD_DATA_SEQ_STATE, (Enum)MethodDataStatesEnum.METHOD_DATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new AddPaData());
    }
    
    public static Grammar<MethodDataContainer> getInstance() {
        return MethodDataGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)MethodDataGrammar.class);
        IS_DEBUG = MethodDataGrammar.LOG.isDebugEnabled();
        MethodDataGrammar.instance = (Grammar<MethodDataContainer>)new MethodDataGrammar();
    }
}
