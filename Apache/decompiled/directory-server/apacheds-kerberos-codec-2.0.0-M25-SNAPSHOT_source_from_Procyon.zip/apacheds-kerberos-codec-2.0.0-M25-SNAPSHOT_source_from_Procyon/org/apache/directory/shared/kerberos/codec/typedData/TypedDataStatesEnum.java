// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.typedData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum TypedDataStatesEnum implements States
{
    START_STATE, 
    TYPED_DATA_SEQ_STATE, 
    TYPED_DATA_SEQ_SEQ_STATE, 
    TYPED_DATA_TDTYPE_TAG_STATE, 
    TYPED_DATA_TDTYPE_STATE, 
    TYPED_DATA_TDDATA_TAG_STATE, 
    TYPED_DATA_TDDATA_STATE, 
    LAST_TYPED_DATA_STATE;
    
    public String getGrammarName(final int grammar) {
        return "TYPED_DATA_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<TypedDataContainer> grammar) {
        if (grammar instanceof TypedDataGrammar) {
            return "TYPED_DATA_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == TypedDataStatesEnum.LAST_TYPED_DATA_STATE.ordinal()) ? "LAST_TYPED_DATA_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == TypedDataStatesEnum.LAST_TYPED_DATA_STATE;
    }
    
    public TypedDataStatesEnum getStartState() {
        return TypedDataStatesEnum.START_STATE;
    }
}
