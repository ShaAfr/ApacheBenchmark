// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import javax.crypto.Mac;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.SecretKey;
import java.security.GeneralSecurityException;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import org.apache.directory.api.util.Strings;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.exceptions.ErrorType;
import java.util.Arrays;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.crypto.checksum.ChecksumType;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.apache.directory.server.kerberos.shared.crypto.checksum.ChecksumEngine;

public class Des3CbcSha1KdEncryption extends EncryptionEngine implements ChecksumEngine
{
    private static final byte[] iv;
    
    public EncryptionType getEncryptionType() {
        return EncryptionType.DES3_CBC_SHA1_KD;
    }
    
    public int getConfounderLength() {
        return 8;
    }
    
    public int getChecksumLength() {
        return 20;
    }
    
    @Override
    public ChecksumType checksumType() {
        return ChecksumType.HMAC_SHA1_DES3_KD;
    }
    
    @Override
    public byte[] calculateChecksum(final byte[] data, final byte[] key, final KeyUsage usage) {
        final byte[] Kc = this.deriveKey(key, this.getUsageKc(usage), 64, 168);
        return this.processChecksum(data, Kc);
    }
    
    public byte[] calculateIntegrity(final byte[] data, final byte[] key, final KeyUsage usage) {
        final byte[] Ki = this.deriveKey(key, this.getUsageKi(usage), 64, 168);
        return this.processChecksum(data, Ki);
    }
    
    public byte[] getDecryptedData(final EncryptionKey key, final EncryptedData data, final KeyUsage usage) throws KerberosException {
        final byte[] Ke = this.deriveKey(key.getKeyValue(), this.getUsageKe(usage), 64, 168);
        byte[] encryptedData = data.getCipher();
        final byte[] oldChecksum = new byte[this.getChecksumLength()];
        System.arraycopy(encryptedData, encryptedData.length - this.getChecksumLength(), oldChecksum, 0, oldChecksum.length);
        encryptedData = this.removeTrailingBytes(encryptedData, 0, this.getChecksumLength());
        final byte[] decryptedData = this.decrypt(encryptedData, Ke);
        final byte[] withoutConfounder = this.removeLeadingBytes(decryptedData, this.getConfounderLength(), 0);
        final byte[] newChecksum = this.calculateIntegrity(decryptedData, key.getKeyValue(), usage);
        if (!Arrays.equals(oldChecksum, newChecksum)) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY);
        }
        return withoutConfounder;
    }
    
    public EncryptedData getEncryptedData(final EncryptionKey key, final byte[] plainText, final KeyUsage usage) {
        final byte[] Ke = this.deriveKey(key.getKeyValue(), this.getUsageKe(usage), 64, 168);
        final byte[] conFounder = this.getRandomBytes(this.getConfounderLength());
        final byte[] paddedPlainText = this.padString(plainText);
        final byte[] dataBytes = this.concatenateBytes(conFounder, paddedPlainText);
        final byte[] checksumBytes = this.calculateIntegrity(dataBytes, key.getKeyValue(), usage);
        final byte[] encryptedData = this.encrypt(dataBytes, Ke);
        final byte[] cipherText = this.concatenateBytes(encryptedData, checksumBytes);
        return new EncryptedData(this.getEncryptionType(), key.getKeyVersion(), cipherText);
    }
    
    public byte[] encrypt(final byte[] plainText, final byte[] keyBytes) {
        return this.processCipher(true, plainText, keyBytes);
    }
    
    public byte[] decrypt(final byte[] cipherText, final byte[] keyBytes) {
        return this.processCipher(false, cipherText, keyBytes);
    }
    
    protected byte[] deriveKey(final byte[] baseKey, final byte[] usage, final int n, final int k) {
        byte[] result = this.deriveRandom(baseKey, usage, n, k);
        result = this.randomToKey(result);
        return result;
    }
    
    protected byte[] randomToKey(final byte[] seed) {
        final int kBytes = 24;
        final byte[] result = new byte[kBytes];
        byte[] fillingKey = Strings.EMPTY_BYTES;
        int pos = 0;
        for (int i = 0; i < kBytes; ++i) {
            if (pos < fillingKey.length) {
                result[i] = fillingKey[pos];
                ++pos;
            }
            else {
                fillingKey = this.getBitGroup(seed, i / 8);
                fillingKey = this.setParity(fillingKey);
                pos = 0;
                result[i] = fillingKey[pos];
                ++pos;
            }
        }
        return result;
    }
    
    protected byte[] getBitGroup(final byte[] seed, final int group) {
        final int srcPos = group * 7;
        final byte[] result = new byte[7];
        System.arraycopy(seed, srcPos, result, 0, 7);
        return result;
    }
    
    protected byte[] setParity(final byte[] in) {
        final byte[] expandedIn = new byte[8];
        System.arraycopy(in, 0, expandedIn, 0, in.length);
        this.setBit(expandedIn, 62, this.getBit(in, 7));
        this.setBit(expandedIn, 61, this.getBit(in, 15));
        this.setBit(expandedIn, 60, this.getBit(in, 23));
        this.setBit(expandedIn, 59, this.getBit(in, 31));
        this.setBit(expandedIn, 58, this.getBit(in, 39));
        this.setBit(expandedIn, 57, this.getBit(in, 47));
        this.setBit(expandedIn, 56, this.getBit(in, 55));
        final byte[] out = new byte[8];
        int bitCount = 0;
        int index = 0;
        for (int i = 0; i < 64; ++i) {
            if ((i + 1) % 8 == 0) {
                if (bitCount % 2 == 0) {
                    this.setBit(out, i, 1);
                }
                ++index;
                bitCount = 0;
            }
            else {
                final int val = this.getBit(expandedIn, index);
                final boolean bit = val > 0;
                if (bit) {
                    this.setBit(out, i, val);
                    ++bitCount;
                }
                ++index;
            }
        }
        return out;
    }
    
    private byte[] processCipher(final boolean isEncrypt, final byte[] data, final byte[] keyBytes) {
        try {
            final Cipher cipher = Cipher.getInstance("DESede/CBC/NoPadding");
            final SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            final AlgorithmParameterSpec paramSpec = new IvParameterSpec(Des3CbcSha1KdEncryption.iv);
            if (isEncrypt) {
                cipher.init(1, key, paramSpec);
            }
            else {
                cipher.init(2, key, paramSpec);
            }
            return cipher.doFinal(data);
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
    
    private byte[] processChecksum(final byte[] data, final byte[] key) {
        try {
            final SecretKey sk = new SecretKeySpec(key, "DESede");
            final Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(sk);
            return mac.doFinal(data);
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
    
    static {
        iv = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
    }
}
