// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.flags;

public interface KerberosFlag
{
    int getValue();
}
