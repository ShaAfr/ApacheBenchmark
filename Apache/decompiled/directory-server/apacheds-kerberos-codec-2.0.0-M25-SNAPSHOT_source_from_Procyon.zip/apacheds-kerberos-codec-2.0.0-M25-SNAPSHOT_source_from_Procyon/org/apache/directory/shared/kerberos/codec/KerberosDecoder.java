// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec;

import org.slf4j.LoggerFactory;
import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswordException;
import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswdErrorType;
import org.apache.directory.shared.kerberos.codec.encTgsRepPart.EncTgsRepPartContainer;
import org.apache.directory.shared.kerberos.messages.EncTgsRepPart;
import org.apache.directory.shared.kerberos.codec.encAsRepPart.EncAsRepPartContainer;
import org.apache.directory.shared.kerberos.messages.EncAsRepPart;
import org.apache.directory.shared.kerberos.codec.krbPriv.KrbPrivContainer;
import org.apache.directory.shared.kerberos.messages.KrbPriv;
import org.apache.directory.shared.kerberos.codec.apReq.ApReqContainer;
import org.apache.directory.shared.kerberos.messages.ApReq;
import org.apache.directory.shared.kerberos.codec.apRep.ApRepContainer;
import org.apache.directory.shared.kerberos.messages.ApRep;
import org.apache.directory.shared.kerberos.codec.authorizationData.AuthorizationDataContainer;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.codec.authenticator.AuthenticatorContainer;
import org.apache.directory.shared.kerberos.messages.Authenticator;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.shared.kerberos.codec.principalName.PrincipalNameContainer;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.encryptionKey.EncryptionKeyContainer;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.shared.kerberos.components.EncTicketPart;
import org.apache.directory.shared.kerberos.codec.encKrbPrivPart.EncKrbPrivPartContainer;
import org.apache.directory.shared.kerberos.components.EncKrbPrivPart;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.shared.kerberos.components.EncKdcRepPart;
import org.apache.directory.shared.kerberos.codec.encApRepPart.EncApRepPartContainer;
import org.apache.directory.shared.kerberos.messages.EncApRepPart;
import org.apache.directory.shared.kerberos.codec.paEncTsEnc.PaEncTsEncContainer;
import org.apache.directory.shared.kerberos.components.PaEncTsEnc;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.exceptions.ErrorType;
import org.apache.directory.shared.kerberos.codec.encryptedData.EncryptedDataContainer;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.asn1.ber.tlv.TLVStateEnum;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.slf4j.Logger;

public class KerberosDecoder
{
    private static Logger LOG;
    private static final boolean IS_DEBUG;
    
    public static Object decode(final KerberosMessageContainer kerberosMessageContainer, final Asn1Decoder asn1Decoder) throws DecoderException {
        final ByteBuffer buf = kerberosMessageContainer.getStream();
        if (kerberosMessageContainer.isTCP()) {
            if (buf.remaining() <= 4) {
                return null;
            }
            kerberosMessageContainer.setTcpLength(buf.getInt());
            buf.mark();
        }
        else {
            buf.mark();
        }
        while (buf.hasRemaining()) {
            try {
                asn1Decoder.decode(buf, (Asn1Container)kerberosMessageContainer);
                if (kerberosMessageContainer.getState() == TLVStateEnum.PDU_DECODED) {
                    if (KerberosDecoder.IS_DEBUG) {
                        KerberosDecoder.LOG.debug("Decoded KerberosMessage : " + kerberosMessageContainer.getMessage());
                        buf.mark();
                    }
                    return kerberosMessageContainer.getMessage();
                }
                continue;
            }
            catch (DecoderException de) {
                KerberosDecoder.LOG.warn("error while decoding", (Throwable)de);
                buf.clear();
                kerberosMessageContainer.clean();
                throw de;
            }
            break;
        }
        return null;
    }
    
    public static EncryptedData decodeEncryptedData(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encryptedDataContainer = (Asn1Container)new EncryptedDataContainer();
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encryptedDataContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final EncryptedData encryptedData = ((EncryptedDataContainer)encryptedDataContainer).getEncryptedData();
        return encryptedData;
    }
    
    public static PaEncTsEnc decodePaEncTsEnc(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container paEncTsEncContainer = (Asn1Container)new PaEncTsEncContainer();
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, paEncTsEncContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final PaEncTsEnc paEncTsEnc = ((PaEncTsEncContainer)paEncTsEncContainer).getPaEncTsEnc();
        return paEncTsEnc;
    }
    
    public static EncApRepPart decodeEncApRepPart(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encApRepPartContainer = (Asn1Container)new EncApRepPartContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encApRepPartContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final EncApRepPart encApRepPart = ((EncApRepPartContainer)encApRepPartContainer).getEncApRepPart();
        return encApRepPart;
    }
    
    public static EncKdcRepPart decodeEncKdcRepPart(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encKdcRepPartContainer = (Asn1Container)new EncKdcRepPartContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encKdcRepPartContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final EncKdcRepPart encKdcRepPart = ((EncKdcRepPartContainer)encKdcRepPartContainer).getEncKdcRepPart();
        return encKdcRepPart;
    }
    
    public static EncKrbPrivPart decodeEncKrbPrivPart(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encKrbPrivPartContainer = (Asn1Container)new EncKrbPrivPartContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encKrbPrivPartContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final EncKrbPrivPart encKrbPrivPart = ((EncKrbPrivPartContainer)encKrbPrivPartContainer).getEncKrbPrivPart();
        return encKrbPrivPart;
    }
    
    public static EncTicketPart decodeEncTicketPart(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encTicketPartContainer = (Asn1Container)new EncTicketPartContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encTicketPartContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final EncTicketPart encTicketPart = ((EncTicketPartContainer)encTicketPartContainer).getEncTicketPart();
        return encTicketPart;
    }
    
    public static EncryptionKey decodeEncryptionKey(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encryptionKeyContainer = (Asn1Container)new EncryptionKeyContainer();
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encryptionKeyContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final EncryptionKey encryptionKey = ((EncryptionKeyContainer)encryptionKeyContainer).getEncryptionKey();
        return encryptionKey;
    }
    
    public static PrincipalName decodePrincipalName(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container principalNameContainer = (Asn1Container)new PrincipalNameContainer();
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, principalNameContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final PrincipalName principalName = ((PrincipalNameContainer)principalNameContainer).getPrincipalName();
        return principalName;
    }
    
    public static Ticket decodeTicket(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container ticketContainer = (Asn1Container)new TicketContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, ticketContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final Ticket ticket = ((TicketContainer)ticketContainer).getTicket();
        return ticket;
    }
    
    public static Authenticator decodeAuthenticator(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container authenticatorContainer = (Asn1Container)new AuthenticatorContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, authenticatorContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final Authenticator authenticator = ((AuthenticatorContainer)authenticatorContainer).getAuthenticator();
        return authenticator;
    }
    
    public static AuthorizationData decodeAuthorizationData(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container authorizationDataContainer = (Asn1Container)new AuthorizationDataContainer();
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, authorizationDataContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final AuthorizationData authorizationData = ((AuthorizationDataContainer)authorizationDataContainer).getAuthorizationData();
        return authorizationData;
    }
    
    public static ApRep decodeApRep(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container apRepContainer = (Asn1Container)new ApRepContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, apRepContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final ApRep apRep = ((ApRepContainer)apRepContainer).getApRep();
        return apRep;
    }
    
    public static ApReq decodeApReq(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container apReqContainer = (Asn1Container)new ApReqContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, apReqContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final ApReq apReq = ((ApReqContainer)apReqContainer).getApReq();
        return apReq;
    }
    
    public static KrbPriv decodeKrbPriv(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container krbPrivContainer = (Asn1Container)new KrbPrivContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, krbPrivContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final KrbPriv krbPriv = ((KrbPrivContainer)krbPrivContainer).getKrbPriv();
        return krbPriv;
    }
    
    public static EncAsRepPart decodeEncAsRepPart(final byte[] data) throws KerberosException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encAsRepPartContainer = (Asn1Container)new EncAsRepPartContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encAsRepPartContainer);
        }
        catch (DecoderException de) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY, (Throwable)de);
        }
        final EncAsRepPart encAsRepPart = ((EncAsRepPartContainer)encAsRepPartContainer).getEncAsRepPart();
        return encAsRepPart;
    }
    
    public static EncTgsRepPart decodeEncTgsRepPart(final byte[] data) throws ChangePasswordException {
        final ByteBuffer stream = ByteBuffer.allocate(data.length);
        stream.put(data);
        stream.flip();
        final Asn1Container encTgsRepPartContainer = (Asn1Container)new EncTgsRepPartContainer(stream);
        final Asn1Decoder kerberosDecoder = new Asn1Decoder();
        try {
            kerberosDecoder.decode(stream, encTgsRepPartContainer);
        }
        catch (DecoderException de) {
            throw new ChangePasswordException(ChangePasswdErrorType.KRB5_KPASSWD_MALFORMED, (Throwable)de);
        }
        final EncTgsRepPart encTgsRepPart = ((EncTgsRepPartContainer)encTgsRepPartContainer).getEncTgsRepPart();
        return encTgsRepPart;
    }
    
    static {
        KerberosDecoder.LOG = LoggerFactory.getLogger((Class)KerberosDecoder.class);
        IS_DEBUG = KerberosDecoder.LOG.isDebugEnabled();
    }
}
