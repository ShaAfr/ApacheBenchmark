// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.messages;

import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.api.asn1.Asn1Object;

public abstract class KerberosMessage implements Asn1Object
{
    private int protocolVersionNumber;
    private KerberosMessageType messageType;
    
    public KerberosMessage(final KerberosMessageType type) {
        this(5, type);
    }
    
    public KerberosMessage(final int versionNumber, final KerberosMessageType type) {
        this.protocolVersionNumber = 5;
        this.protocolVersionNumber = versionNumber;
        this.messageType = type;
    }
    
    public KerberosMessageType getMessageType() {
        return this.messageType;
    }
    
    public void setMessageType(final KerberosMessageType type) {
        this.messageType = type;
    }
    
    public int getProtocolVersionNumber() {
        return this.protocolVersionNumber;
    }
    
    public void setProtocolVersionNumber(final int versionNumber) {
        this.protocolVersionNumber = versionNumber;
    }
}
