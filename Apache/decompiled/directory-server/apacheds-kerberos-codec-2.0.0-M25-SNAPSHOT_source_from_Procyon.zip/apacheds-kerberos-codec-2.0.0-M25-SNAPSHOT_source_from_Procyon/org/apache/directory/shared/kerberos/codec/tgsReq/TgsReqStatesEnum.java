// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.tgsReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum TgsReqStatesEnum implements States
{
    START_STATE, 
    TGS_REQ_STATE, 
    LAST_TGS_REQ_STATE;
    
    public String getGrammarName(final int grammar) {
        return "TGS_REQ_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<TgsReqContainer> grammar) {
        if (grammar instanceof TgsReqGrammar) {
            return "TGS_REQ_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == TgsReqStatesEnum.LAST_TGS_REQ_STATE.ordinal()) ? "TGS_REQ_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == TgsReqStatesEnum.LAST_TGS_REQ_STATE;
    }
    
    public TgsReqStatesEnum getStartState() {
        return TgsReqStatesEnum.START_STATE;
    }
}
