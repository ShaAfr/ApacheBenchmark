// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbCredPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encKrbCredPart.EncKrbCredPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreUsec extends AbstractReadInteger<EncKrbCredPartContainer>
{
    public StoreUsec() {
        super("EncKrbCredPart usec", 0, 999999);
    }
    
    protected void setIntegerValue(final int value, final EncKrbCredPartContainer encKrbCredPartContainer) {
        encKrbCredPartContainer.getEncKrbCredPart().setUsec(value);
        encKrbCredPartContainer.setGrammarEndAllowed(true);
    }
}
