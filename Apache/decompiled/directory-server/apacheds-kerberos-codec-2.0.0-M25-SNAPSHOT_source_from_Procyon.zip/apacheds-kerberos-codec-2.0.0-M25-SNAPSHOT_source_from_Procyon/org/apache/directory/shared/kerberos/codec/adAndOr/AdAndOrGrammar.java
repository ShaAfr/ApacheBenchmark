// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adAndOr;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.adAndOr.actions.StoreElements;
import org.apache.directory.shared.kerberos.codec.adAndOr.actions.StoreConditionCount;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.adAndOr.actions.AdAndOrInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class AdAndOrGrammar extends AbstractGrammar<AdAndOrContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<AdAndOrContainer> instance;
    
    private AdAndOrGrammar() {
        this.setName(AdAndOrGrammar.class.getName());
        super.transitions = new GrammarTransition[AdAndOrStatesEnum.LAST_AD_AND_OR_STATE.ordinal()][256];
        super.transitions[AdAndOrStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)AdAndOrStatesEnum.START_STATE, (Enum)AdAndOrStatesEnum.AD_AND_OR_STATE, UniversalTag.SEQUENCE, (Action)new AdAndOrInit());
        super.transitions[AdAndOrStatesEnum.AD_AND_OR_STATE.ordinal()][160] = new GrammarTransition((Enum)AdAndOrStatesEnum.AD_AND_OR_STATE, (Enum)AdAndOrStatesEnum.AD_AND_OR_CONDITION_COUNT_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[AdAndOrStatesEnum.AD_AND_OR_CONDITION_COUNT_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)AdAndOrStatesEnum.AD_AND_OR_CONDITION_COUNT_TAG_STATE, (Enum)AdAndOrStatesEnum.AD_AND_OR_CONDITION_COUNT_STATE, UniversalTag.INTEGER, (Action)new StoreConditionCount());
        super.transitions[AdAndOrStatesEnum.AD_AND_OR_CONDITION_COUNT_STATE.ordinal()][161] = new GrammarTransition((Enum)AdAndOrStatesEnum.AD_AND_OR_CONDITION_COUNT_STATE, (Enum)AdAndOrStatesEnum.AD_AND_OR_ELEMENTS_TAG_STATE, 161, (Action)new StoreElements());
    }
    
    public static Grammar<AdAndOrContainer> getInstance() {
        return AdAndOrGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AdAndOrGrammar.class);
        IS_DEBUG = AdAndOrGrammar.LOG.isDebugEnabled();
        AdAndOrGrammar.instance = (Grammar<AdAndOrContainer>)new AdAndOrGrammar();
    }
}
