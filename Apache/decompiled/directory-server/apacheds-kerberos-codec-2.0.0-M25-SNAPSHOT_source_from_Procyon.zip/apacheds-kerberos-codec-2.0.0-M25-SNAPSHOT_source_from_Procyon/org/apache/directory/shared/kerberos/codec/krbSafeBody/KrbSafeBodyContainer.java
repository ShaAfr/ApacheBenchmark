// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafeBody;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.KrbSafeBody;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KrbSafeBodyContainer extends AbstractContainer
{
    private KrbSafeBody krbSafeBody;
    
    public KrbSafeBodyContainer() {
        this.setGrammar((Grammar)KrbSafeBodyGrammar.getInstance());
        this.setTransition((Enum)KrbSafeBodyStatesEnum.START_STATE);
    }
    
    public KrbSafeBody getKrbSafeBody() {
        return this.krbSafeBody;
    }
    
    public void setKrbSafeBody(final KrbSafeBody krbSafeBody) {
        this.krbSafeBody = krbSafeBody;
    }
}
