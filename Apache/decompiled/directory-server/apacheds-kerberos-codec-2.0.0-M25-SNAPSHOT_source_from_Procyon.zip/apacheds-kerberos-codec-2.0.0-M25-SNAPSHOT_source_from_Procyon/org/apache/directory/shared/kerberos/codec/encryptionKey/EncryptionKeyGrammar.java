// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptionKey;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.encryptionKey.actions.StoreKeyValue;
import org.apache.directory.shared.kerberos.codec.encryptionKey.actions.StoreKeyType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.encryptionKey.actions.EncryptionKeyInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class EncryptionKeyGrammar extends AbstractGrammar<EncryptionKeyContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<EncryptionKeyContainer> instance;
    
    private EncryptionKeyGrammar() {
        this.setName(EncryptionKeyGrammar.class.getName());
        super.transitions = new GrammarTransition[EncryptionKeyStatesEnum.LAST_ENCRYPTION_KEY_STATE.ordinal()][256];
        super.transitions[EncryptionKeyStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)EncryptionKeyStatesEnum.START_STATE, (Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new EncryptionKeyInit());
        super.transitions[EncryptionKeyStatesEnum.ENCRYPTION_KEY_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_SEQ_STATE, (Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_TYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[EncryptionKeyStatesEnum.ENCRYPTION_KEY_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_TYPE_TAG_STATE, (Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_TYPE_STATE, UniversalTag.INTEGER, (Action)new StoreKeyType());
        super.transitions[EncryptionKeyStatesEnum.ENCRYPTION_KEY_TYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_TYPE_STATE, (Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_VALUE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[EncryptionKeyStatesEnum.ENCRYPTION_KEY_VALUE_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.getValue()] = new GrammarTransition((Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_VALUE_TAG_STATE, (Enum)EncryptionKeyStatesEnum.ENCRYPTION_KEY_VALUE_STATE, UniversalTag.OCTET_STRING, (Action)new StoreKeyValue());
    }
    
    public static Grammar<EncryptionKeyContainer> getInstance() {
        return EncryptionKeyGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncryptionKeyGrammar.class);
        IS_DEBUG = EncryptionKeyGrammar.LOG.isDebugEnabled();
        EncryptionKeyGrammar.instance = (Grammar<EncryptionKeyContainer>)new EncryptionKeyGrammar();
    }
}
