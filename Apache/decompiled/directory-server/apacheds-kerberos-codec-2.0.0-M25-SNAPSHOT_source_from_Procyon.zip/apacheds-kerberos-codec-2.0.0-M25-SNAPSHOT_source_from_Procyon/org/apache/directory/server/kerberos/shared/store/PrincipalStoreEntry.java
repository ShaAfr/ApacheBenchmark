// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.store;

import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import java.util.Map;
import org.apache.directory.shared.kerberos.codec.types.SamType;
import org.apache.directory.shared.kerberos.KerberosTime;
import javax.security.auth.kerberos.KerberosPrincipal;

public class PrincipalStoreEntry
{
    private String distinguishedName;
    private String commonName;
    private KerberosPrincipal principal;
    private String realmName;
    private String userId;
    private KerberosTime validStart;
    private KerberosTime validEnd;
    private KerberosTime passwordEnd;
    private int keyVersionNumber;
    private int maxLife;
    private int maxRenew;
    private int kdcFlags;
    private SamType samType;
    private boolean disabled;
    private boolean lockedOut;
    private KerberosTime expiration;
    private Map<EncryptionType, EncryptionKey> keyMap;
    
    PrincipalStoreEntry(final String distinguishedName, final String commonName, final String userId, final KerberosPrincipal principal, final int keyVersionNumber, final KerberosTime validStart, final KerberosTime validEnd, final KerberosTime passwordEnd, final int maxLife, final int maxRenew, final int kdcFlags, final Map<EncryptionType, EncryptionKey> keyMap, final String realmName, final SamType samType, final boolean disabled, final boolean lockedOut, final KerberosTime expiration) {
        this.distinguishedName = distinguishedName;
        this.commonName = commonName;
        this.userId = userId;
        this.principal = principal;
        this.validStart = validStart;
        this.validEnd = validEnd;
        this.passwordEnd = passwordEnd;
        this.keyVersionNumber = keyVersionNumber;
        this.maxLife = maxLife;
        this.maxRenew = maxRenew;
        this.kdcFlags = kdcFlags;
        this.realmName = realmName;
        this.disabled = disabled;
        this.lockedOut = lockedOut;
        this.expiration = expiration;
        this.samType = samType;
        this.keyMap = keyMap;
    }
    
    public boolean isDisabled() {
        return this.disabled;
    }
    
    public boolean isLockedOut() {
        return this.lockedOut;
    }
    
    public KerberosTime getExpiration() {
        return this.expiration;
    }
    
    public String getDistinguishedName() {
        return this.distinguishedName;
    }
    
    public String getCommonName() {
        return this.commonName;
    }
    
    public String getUserId() {
        return this.userId;
    }
    
    public Map<EncryptionType, EncryptionKey> getKeyMap() {
        return this.keyMap;
    }
    
    public int getKDCFlags() {
        return this.kdcFlags;
    }
    
    public int getKeyVersionNumber() {
        return this.keyVersionNumber;
    }
    
    public int getMaxLife() {
        return this.maxLife;
    }
    
    public int getMaxRenew() {
        return this.maxRenew;
    }
    
    public KerberosTime getPasswordEnd() {
        return this.passwordEnd;
    }
    
    public KerberosPrincipal getPrincipal() {
        return this.principal;
    }
    
    public String getRealmName() {
        return this.realmName;
    }
    
    public KerberosTime getValidEnd() {
        return this.validEnd;
    }
    
    public KerberosTime getValidStart() {
        return this.validStart;
    }
    
    public SamType getSamType() {
        return this.samType;
    }
}
