// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.tgsRep.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.KdcRep;
import org.apache.directory.shared.kerberos.messages.TgsRep;
import org.apache.directory.shared.kerberos.codec.kdcRep.KdcRepContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.tgsRep.TgsRepContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreKdcRep extends GrammarAction<TgsRepContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreKdcRep() {
        super("Add an KDC-REP instance");
    }
    
    public void action(final TgsRepContainer tgsRepContainer) throws DecoderException {
        final TLV tlv = tgsRepContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreKdcRep.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder kdcRepDecoder = new Asn1Decoder();
        final KdcRepContainer kdcRepContainer = new KdcRepContainer(tgsRepContainer.getStream());
        final TgsRep tgsRep = new TgsRep();
        kdcRepContainer.setKdcRep(tgsRep);
        try {
            kdcRepDecoder.decode(tgsRepContainer.getStream(), (Asn1Container)kdcRepContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        tgsRepContainer.updateParent();
        if (tgsRep.getMessageType() != KerberosMessageType.TGS_REP) {
            throw new DecoderException("Bad message type");
        }
        tgsRepContainer.setTgsRep(tgsRep);
        if (StoreKdcRep.IS_DEBUG) {
            StoreKdcRep.LOG.debug("TGS-REP : {}", (Object)tgsRep);
        }
        tgsRepContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreKdcRep.class);
        IS_DEBUG = StoreKdcRep.LOG.isDebugEnabled();
    }
}
