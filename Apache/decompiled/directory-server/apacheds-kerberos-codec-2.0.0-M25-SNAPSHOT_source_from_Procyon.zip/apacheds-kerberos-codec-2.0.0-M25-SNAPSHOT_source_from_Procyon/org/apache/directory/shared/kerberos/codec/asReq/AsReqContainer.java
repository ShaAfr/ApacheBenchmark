// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.asReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.AsReq;
import org.apache.directory.shared.kerberos.codec.kdcReq.KdcReqContainer;

public class AsReqContainer extends KdcReqContainer
{
    private AsReq asReq;
    
    public AsReqContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)AsReqGrammar.getInstance());
        this.setTransition((Enum)AsReqStatesEnum.START_STATE);
    }
    
    public AsReq getAsReq() {
        return this.asReq;
    }
    
    public void setAsReq(final AsReq asReq) {
        this.asReq = asReq;
    }
}
