// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.IntegerDecoderException;
import org.apache.directory.api.util.Strings;
import org.apache.directory.api.asn1.ber.tlv.IntegerDecoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;
import org.apache.directory.api.asn1.ber.Asn1Container;

public abstract class AbstractReadPvno<E extends Asn1Container> extends GrammarAction<E>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AbstractReadPvno(final String name) {
        super(name);
    }
    
    protected abstract void setPvno(final int p0, final E p1);
    
    public final void action(final E container) throws DecoderException {
        final TLV tlv = container.getCurrentTLV();
        if (tlv.getLength() != 1) {
            AbstractReadPvno.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final BerValue value = tlv.getValue();
        try {
            final int pvno = IntegerDecoder.parse(value);
            if (pvno != 5) {
                AbstractReadPvno.LOG.error(I18n.err(I18n.ERR_04070, new Object[] { Strings.dumpBytes(value.getData()), "The PVNO should be 5" }));
                throw new DecoderException("The PVNO should be 5");
            }
            if (AbstractReadPvno.IS_DEBUG) {
                AbstractReadPvno.LOG.debug("pvno : {}", (Object)pvno);
            }
            this.setPvno(pvno, container);
        }
        catch (IntegerDecoderException ide) {
            AbstractReadPvno.LOG.error(I18n.err(I18n.ERR_04070, new Object[] { Strings.dumpBytes(value.getData()), ide.getLocalizedMessage() }));
            throw new DecoderException(ide.getMessage());
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AbstractReadPvno.class);
        IS_DEBUG = AbstractReadPvno.LOG.isDebugEnabled();
    }
}
