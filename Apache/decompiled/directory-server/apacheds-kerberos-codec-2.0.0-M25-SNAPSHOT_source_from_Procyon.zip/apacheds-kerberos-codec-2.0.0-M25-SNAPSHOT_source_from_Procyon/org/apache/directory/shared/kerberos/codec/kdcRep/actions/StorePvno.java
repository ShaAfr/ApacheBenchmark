// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcRep.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.kdcRep.KdcRepContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPvno;

public class StorePvno extends AbstractReadPvno<KdcRepContainer>
{
    public StorePvno() {
        super("KDC-REP pvno");
    }
    
    @Override
    protected void setPvno(final int pvno, final KdcRepContainer kdcRepContainer) {
        kdcRepContainer.getKdcRep().setPvno(pvno);
    }
}
