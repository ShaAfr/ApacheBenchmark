// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfoEntry.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.ETypeInfoEntry;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.etypeInfoEntry.ETypeInfoEntryContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class ETypeInfoEntryInit extends GrammarAction<ETypeInfoEntryContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public ETypeInfoEntryInit() {
        super("Creates a ETYPE-INFO-ENTRY instance");
    }
    
    public void action(final ETypeInfoEntryContainer eTypeInfoEntryContainer) throws DecoderException {
        final TLV tlv = eTypeInfoEntryContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            ETypeInfoEntryInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final ETypeInfoEntry etypeInfoEntry = new ETypeInfoEntry();
        eTypeInfoEntryContainer.setETypeInfoEntry(etypeInfoEntry);
        if (ETypeInfoEntryInit.IS_DEBUG) {
            ETypeInfoEntryInit.LOG.debug("ETYPE-INFO-ENTRY created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfoEntryInit.class);
        IS_DEBUG = ETypeInfoEntryInit.LOG.isDebugEnabled();
    }
}
