// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.Authenticator;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class AuthenticatorContainer extends AbstractContainer
{
    private Authenticator authenticator;
    
    public AuthenticatorContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)AuthenticatorGrammar.getInstance());
        this.setTransition((Enum)AuthenticatorStatesEnum.START_STATE);
    }
    
    public Authenticator getAuthenticator() {
        return this.authenticator;
    }
    
    public void setAuthenticator(final Authenticator authenticator) {
        this.authenticator = authenticator;
    }
}
