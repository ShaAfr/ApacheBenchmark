// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbCredPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encKrbCredPart.EncKrbCredPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreNonce extends AbstractReadInteger<EncKrbCredPartContainer>
{
    public StoreNonce() {
        super("EncKrbCredPart nonce", Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    
    public void setIntegerValue(final int value, final EncKrbCredPartContainer encKrbCredPartContainer) {
        encKrbCredPartContainer.getEncKrbCredPart().setNonce(value);
        encKrbCredPartContainer.setGrammarEndAllowed(true);
    }
}
