// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.principalName;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.principalName.actions.StoreNameString;
import org.apache.directory.shared.kerberos.codec.principalName.actions.StoreNameType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.principalName.actions.PrincipalNameInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class PrincipalNameGrammar extends AbstractGrammar<PrincipalNameContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<PrincipalNameContainer> instance;
    
    private PrincipalNameGrammar() {
        this.setName(PrincipalNameGrammar.class.getName());
        super.transitions = new GrammarTransition[PrincipalNameStatesEnum.LAST_PRINCIPAL_NAME_STATE.ordinal()][256];
        super.transitions[PrincipalNameStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)PrincipalNameStatesEnum.START_STATE, (Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new PrincipalNameInit());
        super.transitions[PrincipalNameStatesEnum.PRINCIPAL_NAME_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_SEQ_STATE, (Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_TYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_TYPE_TAG_STATE, (Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_TYPE_STATE, UniversalTag.INTEGER, (Action)new StoreNameType());
        super.transitions[PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_TYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_TYPE_STATE, (Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_STRING_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_STRING_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_STRING_TAG_STATE, (Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_STRING_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_STRING_SEQ_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_STRING_SEQ_STATE, (Enum)PrincipalNameStatesEnum.PRINCIPAL_NAME_NAME_STRING_SEQ_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreNameString());
    }
    
    public static Grammar<PrincipalNameContainer> getInstance() {
        return PrincipalNameGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)PrincipalNameGrammar.class);
        IS_DEBUG = PrincipalNameGrammar.LOG.isDebugEnabled();
        PrincipalNameGrammar.instance = (Grammar<PrincipalNameContainer>)new PrincipalNameGrammar();
    }
}
