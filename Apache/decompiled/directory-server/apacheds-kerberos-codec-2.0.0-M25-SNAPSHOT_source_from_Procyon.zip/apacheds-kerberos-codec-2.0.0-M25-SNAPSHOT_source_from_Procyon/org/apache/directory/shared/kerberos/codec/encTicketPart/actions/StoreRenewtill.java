// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreRenewtill extends AbstractReadKerberosTime<EncTicketPartContainer>
{
    public StoreRenewtill() {
        super("Stores the renew-till");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final EncTicketPartContainer encTicketPartContainer) {
        encTicketPartContainer.getEncTicketPart().setRenewTill(krbtime);
        encTicketPartContainer.setGrammarEndAllowed(true);
    }
}
