// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCred;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.KrbCred;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KrbCredContainer extends AbstractContainer
{
    private KrbCred krbCred;
    
    public KrbCredContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)KrbCredGrammar.getInstance());
        this.setTransition((Enum)KrbCredStatesEnum.START_STATE);
    }
    
    public KrbCred getKrbCred() {
        return this.krbCred;
    }
    
    public void setKrbCred(final KrbCred krbCred) {
        this.krbCred = krbCred;
    }
}
