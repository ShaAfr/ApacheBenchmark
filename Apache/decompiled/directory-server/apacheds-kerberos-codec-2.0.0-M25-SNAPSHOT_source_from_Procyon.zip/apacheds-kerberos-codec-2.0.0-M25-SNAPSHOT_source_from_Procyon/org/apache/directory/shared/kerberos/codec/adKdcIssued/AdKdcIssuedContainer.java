// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adKdcIssued;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.AdKdcIssued;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class AdKdcIssuedContainer extends AbstractContainer
{
    private AdKdcIssued adKdcIssued;
    
    public AdKdcIssuedContainer() {
        this.adKdcIssued = new AdKdcIssued();
        this.setGrammar((Grammar)AdKDCIssuedGrammar.getInstance());
        this.setTransition((Enum)AdKDCIssuedStatesEnum.START_STATE);
    }
    
    public AdKdcIssued getAdKdcIssued() {
        return this.adKdcIssued;
    }
    
    public void setAdKdcIssued(final AdKdcIssued adKdcIssued) {
        this.adKdcIssued = adKdcIssued;
    }
}
