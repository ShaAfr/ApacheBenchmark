// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.etypeInfo2.actions.AddETypeInfo2Entry;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class ETypeInfo2Grammar extends AbstractGrammar<ETypeInfo2Container>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<ETypeInfo2Container> instance;
    
    private ETypeInfo2Grammar() {
        this.setName(ETypeInfo2Grammar.class.getName());
        super.transitions = new GrammarTransition[ETypeInfo2StatesEnum.LAST_ETYPE_INFO2_STATE.ordinal()][256];
        super.transitions[ETypeInfo2StatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ETypeInfo2StatesEnum.START_STATE, (Enum)ETypeInfo2StatesEnum.ETYPE_INFO2_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfo2StatesEnum.ETYPE_INFO2_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ETypeInfo2StatesEnum.ETYPE_INFO2_SEQ_STATE, (Enum)ETypeInfo2StatesEnum.ETYPE_INFO2_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new AddETypeInfo2Entry());
    }
    
    public static Grammar<ETypeInfo2Container> getInstance() {
        return ETypeInfo2Grammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfo2Grammar.class);
        IS_DEBUG = ETypeInfo2Grammar.LOG.isDebugEnabled();
        ETypeInfo2Grammar.instance = (Grammar<ETypeInfo2Container>)new ETypeInfo2Grammar();
    }
}
