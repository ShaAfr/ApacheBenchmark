// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

public class AdMandatoryForKdc extends AuthorizationData
{
    @Override
    public String toString() {
        return this.toString("");
    }
    
    @Override
    public String toString(final String tabs) {
        final StringBuilder sb = new StringBuilder();
        sb.append(tabs).append("AD-MANDATORY-FOR-KDC : {\n");
        sb.append(tabs).append(super.toString("    " + tabs)).append('\n');
        sb.append(tabs + "}\n");
        return sb.toString();
    }
}
