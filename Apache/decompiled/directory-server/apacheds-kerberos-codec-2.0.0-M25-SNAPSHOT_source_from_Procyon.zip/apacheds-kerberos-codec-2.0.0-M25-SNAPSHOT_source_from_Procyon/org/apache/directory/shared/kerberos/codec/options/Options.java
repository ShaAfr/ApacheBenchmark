// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.options;

import org.apache.directory.shared.kerberos.flags.AbstractKerberosFlags;

public abstract class Options extends AbstractKerberosFlags
{
    protected Options(final int maxSize) {
        super(maxSize);
    }
    
    public boolean match(final Options options, final int option) {
        return options.get(option) == this.get(option);
    }
    
    public boolean get(final int index) {
        if (index < 0 || index >= this.size()) {
            throw new ArrayIndexOutOfBoundsException();
        }
        return super.getBit(index);
    }
    
    public void set(final int index) {
        if (index < 0 || index >= this.size()) {
            return;
        }
        this.setBit(index);
    }
    
    public void clear(final int index) {
        if (index < 0 || index >= this.size()) {
            return;
        }
        this.clearBit(index);
    }
    
    public byte[] getBytes() {
        return super.getData();
    }
    
    protected void setBytes(final byte[] bytes) {
        super.setData(bytes);
    }
    
    public String toString() {
        return super.toString();
    }
}
