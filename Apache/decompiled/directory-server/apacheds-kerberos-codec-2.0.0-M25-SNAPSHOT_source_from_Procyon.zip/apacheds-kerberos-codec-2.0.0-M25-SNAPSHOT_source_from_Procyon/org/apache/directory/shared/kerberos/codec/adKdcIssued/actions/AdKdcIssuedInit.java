// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adKdcIssued.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.AdKdcIssued;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.adKdcIssued.AdKdcIssuedContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AdKdcIssuedInit extends GrammarAction<AdKdcIssuedContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AdKdcIssuedInit() {
        super("Creates a AD-KDCIssued instance");
    }
    
    public void action(final AdKdcIssuedContainer adKdcIssuedContainer) throws DecoderException {
        final TLV tlv = adKdcIssuedContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AdKdcIssuedInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final AdKdcIssued adKdcIssued = new AdKdcIssued();
        adKdcIssuedContainer.setAdKdcIssued(adKdcIssued);
        if (AdKdcIssuedInit.IS_DEBUG) {
            AdKdcIssuedInit.LOG.debug("AdKdcIssued created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AdKdcIssuedInit.class);
        IS_DEBUG = AdKdcIssuedInit.LOG.isDebugEnabled();
    }
}
