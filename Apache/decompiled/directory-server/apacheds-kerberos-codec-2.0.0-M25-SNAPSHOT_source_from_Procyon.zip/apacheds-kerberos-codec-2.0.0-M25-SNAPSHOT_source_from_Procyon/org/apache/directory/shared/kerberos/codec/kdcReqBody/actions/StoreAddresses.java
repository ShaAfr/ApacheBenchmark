// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.HostAddresses;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadHostAddresses;

public class StoreAddresses extends AbstractReadHostAddresses<KdcReqBodyContainer>
{
    public StoreAddresses() {
        super("KDC-REQ-BODY addresses");
    }
    
    @Override
    protected void setHostAddresses(final HostAddresses hostAddresses, final KdcReqBodyContainer kdcReqBodyContainer) {
        kdcReqBodyContainer.getKdcReqBody().setAddresses(hostAddresses);
        kdcReqBodyContainer.setGrammarEndAllowed(true);
    }
}
