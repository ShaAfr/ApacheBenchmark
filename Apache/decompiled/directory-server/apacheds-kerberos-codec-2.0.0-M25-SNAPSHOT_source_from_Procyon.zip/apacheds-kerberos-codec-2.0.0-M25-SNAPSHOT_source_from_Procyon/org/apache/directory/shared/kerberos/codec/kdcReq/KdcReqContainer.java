// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.components.KdcReq;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KdcReqContainer extends AbstractContainer
{
    private KdcReq kdcReq;
    
    public KdcReqContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)KdcReqGrammar.getInstance());
        this.setTransition((Enum)KdcReqStatesEnum.START_STATE);
    }
    
    public KdcReq getKdcReq() {
        return this.kdcReq;
    }
    
    public void setKdcReq(final KdcReq kdcReq) {
        this.kdcReq = kdcReq;
    }
}
