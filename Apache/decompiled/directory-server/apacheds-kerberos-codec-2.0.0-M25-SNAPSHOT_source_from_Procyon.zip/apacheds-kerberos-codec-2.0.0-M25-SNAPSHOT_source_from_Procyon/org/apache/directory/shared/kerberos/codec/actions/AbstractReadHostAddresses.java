// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.codec.hostAddresses.HostAddressesContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.apache.directory.shared.kerberos.components.HostAddresses;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;
import org.apache.directory.api.asn1.ber.Asn1Container;

public abstract class AbstractReadHostAddresses<E extends Asn1Container> extends GrammarAction<E>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AbstractReadHostAddresses(final String name) {
        super(name);
    }
    
    protected abstract void setHostAddresses(final HostAddresses p0, final E p1);
    
    public final void action(final E container) throws DecoderException {
        final TLV tlv = container.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AbstractReadHostAddresses.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder hostAddressesDecoder = new Asn1Decoder();
        final HostAddressesContainer hostAddressesContainer = new HostAddressesContainer();
        hostAddressesContainer.setStream(container.getStream());
        try {
            hostAddressesDecoder.decode(container.getStream(), (Asn1Container)hostAddressesContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        final HostAddresses hostAddresses = hostAddressesContainer.getHostAddresses();
        this.setHostAddresses(hostAddresses, container);
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        container.updateParent();
        if (AbstractReadHostAddresses.IS_DEBUG) {
            AbstractReadHostAddresses.LOG.debug("HostAddresses : {}", (Object)hostAddresses);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AbstractReadHostAddresses.class);
        IS_DEBUG = AbstractReadHostAddresses.LOG.isDebugEnabled();
    }
}
