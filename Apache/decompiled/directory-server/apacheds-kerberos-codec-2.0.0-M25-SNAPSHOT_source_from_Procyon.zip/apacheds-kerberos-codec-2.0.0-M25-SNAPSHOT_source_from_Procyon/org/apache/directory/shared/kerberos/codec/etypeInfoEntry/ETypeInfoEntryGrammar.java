// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfoEntry;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.etypeInfoEntry.actions.StoreSalt;
import org.apache.directory.shared.kerberos.codec.etypeInfoEntry.actions.StoreEType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.etypeInfoEntry.actions.ETypeInfoEntryInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class ETypeInfoEntryGrammar extends AbstractGrammar<ETypeInfoEntryContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<ETypeInfoEntryContainer> instance;
    
    private ETypeInfoEntryGrammar() {
        this.setName(ETypeInfoEntryGrammar.class.getName());
        super.transitions = new GrammarTransition[ETypeInfoEntryStatesEnum.LAST_ETYPE_INFO_ENTRY_STATE.ordinal()][256];
        super.transitions[ETypeInfoEntryStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)ETypeInfoEntryStatesEnum.START_STATE, (Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new ETypeInfoEntryInit());
        super.transitions[ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_SEQ_STATE, (Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_ETYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_ETYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_ETYPE_TAG_STATE, (Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_ETYPE_STATE, UniversalTag.INTEGER, (Action)new StoreEType());
        super.transitions[ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_ETYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_ETYPE_STATE, (Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_SALT_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_SALT_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.getValue()] = new GrammarTransition((Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_SALT_TAG_STATE, (Enum)ETypeInfoEntryStatesEnum.ETYPE_INFO_ENTRY_SALT_STATE, UniversalTag.OCTET_STRING, (Action)new StoreSalt());
    }
    
    public static Grammar<ETypeInfoEntryContainer> getInstance() {
        return ETypeInfoEntryGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfoEntryGrammar.class);
        IS_DEBUG = ETypeInfoEntryGrammar.LOG.isDebugEnabled();
        ETypeInfoEntryGrammar.instance = (Grammar<ETypeInfoEntryContainer>)new ETypeInfoEntryGrammar();
    }
}
