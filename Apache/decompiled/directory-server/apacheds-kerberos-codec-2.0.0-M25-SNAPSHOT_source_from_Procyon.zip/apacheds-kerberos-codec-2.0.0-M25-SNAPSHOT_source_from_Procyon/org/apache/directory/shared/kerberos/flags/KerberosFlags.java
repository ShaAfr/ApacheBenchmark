// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.flags;

public interface KerberosFlags
{
    int getIntValue();
    
    boolean isFlagSet(final KerberosFlag p0);
    
    boolean isFlagSet(final int p0);
    
    void setFlag(final KerberosFlag p0);
    
    void setFlag(final int p0);
    
    void clearFlag(final KerberosFlag p0);
    
    void clearFlag(final int p0);
}
