// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.store;

import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import java.util.Iterator;
import org.apache.directory.shared.kerberos.codec.KerberosDecoder;
import org.apache.directory.server.i18n.I18n;
import org.apache.directory.api.ldap.model.entry.StringValue;
import org.apache.directory.api.ldap.model.entry.Value;
import java.util.HashMap;
import org.apache.directory.api.ldap.model.entry.Attribute;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import java.util.Map;
import org.apache.directory.shared.kerberos.codec.types.SamType;
import org.apache.directory.shared.kerberos.KerberosTime;
import javax.security.auth.kerberos.KerberosPrincipal;

public class PrincipalStoreEntryModifier
{
    private String distinguishedName;
    private String commonName;
    private KerberosPrincipal principal;
    private String realmName;
    private String userId;
    private int keyVersionNumber;
    private KerberosTime validStart;
    private KerberosTime validEnd;
    private KerberosTime passwordEnd;
    private int maxLife;
    private int maxRenew;
    private int kdcFlags;
    private SamType samType;
    private boolean disabled;
    private boolean lockedOut;
    private KerberosTime expiration;
    private Map<EncryptionType, EncryptionKey> keyMap;
    
    public PrincipalStoreEntryModifier() {
        this.disabled = false;
        this.lockedOut = false;
        this.expiration = KerberosTime.INFINITY;
    }
    
    public PrincipalStoreEntry getEntry() {
        return new PrincipalStoreEntry(this.distinguishedName, this.commonName, this.userId, this.principal, this.keyVersionNumber, this.validStart, this.validEnd, this.passwordEnd, this.maxLife, this.maxRenew, this.kdcFlags, this.keyMap, this.realmName, this.samType, this.disabled, this.lockedOut, this.expiration);
    }
    
    public void setDisabled(final boolean disabled) {
        this.disabled = disabled;
    }
    
    public void setLockedOut(final boolean lockedOut) {
        this.lockedOut = lockedOut;
    }
    
    public void setExpiration(final KerberosTime expiration) {
        this.expiration = expiration;
    }
    
    public void setDistinguishedName(final String distinguishedName) {
        this.distinguishedName = distinguishedName;
    }
    
    public void setCommonName(final String commonName) {
        this.commonName = commonName;
    }
    
    public void setUserId(final String userId) {
        this.userId = userId;
    }
    
    public void setKDCFlags(final int kdcFlags) {
        this.kdcFlags = kdcFlags;
    }
    
    public void setKeyMap(final Map<EncryptionType, EncryptionKey> keyMap) {
        this.keyMap = keyMap;
    }
    
    public void setKeyVersionNumber(final int keyVersionNumber) {
        this.keyVersionNumber = keyVersionNumber;
    }
    
    public void setMaxLife(final int maxLife) {
        this.maxLife = maxLife;
    }
    
    public void setMaxRenew(final int maxRenew) {
        this.maxRenew = maxRenew;
    }
    
    public void setPasswordEnd(final KerberosTime passwordEnd) {
        this.passwordEnd = passwordEnd;
    }
    
    public void setPrincipal(final KerberosPrincipal principal) {
        this.principal = principal;
    }
    
    public void setRealmName(final String realmName) {
        this.realmName = realmName;
    }
    
    public void setValidEnd(final KerberosTime validEnd) {
        this.validEnd = validEnd;
    }
    
    public void setValidStart(final KerberosTime validStart) {
        this.validStart = validStart;
    }
    
    public void setSamType(final SamType samType) {
        this.samType = samType;
    }
    
    public Map<EncryptionType, EncryptionKey> reconstituteKeyMap(final Attribute krb5key) throws KerberosException, LdapException {
        final Map<EncryptionType, EncryptionKey> map = new HashMap<EncryptionType, EncryptionKey>();
        for (final Value<?> val : krb5key) {
            if (val instanceof StringValue) {
                throw new IllegalStateException(I18n.err(I18n.ERR_626, new Object[0]));
            }
            final byte[] encryptionKeyBytes = val.getBytes();
            final EncryptionKey encryptionKey = KerberosDecoder.decodeEncryptionKey(encryptionKeyBytes);
            map.put(encryptionKey.getKeyType(), encryptionKey);
        }
        return map;
    }
}
