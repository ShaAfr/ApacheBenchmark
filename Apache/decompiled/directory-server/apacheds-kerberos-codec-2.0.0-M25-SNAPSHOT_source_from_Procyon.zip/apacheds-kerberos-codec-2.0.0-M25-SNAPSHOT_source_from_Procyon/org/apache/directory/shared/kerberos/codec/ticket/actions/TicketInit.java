// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.ticket.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class TicketInit extends GrammarAction<TicketContainer>
{
    private static final Logger LOG;
    
    public TicketInit() {
        super("Ticket initialization");
    }
    
    public void action(final TicketContainer ticketContainer) throws DecoderException {
        final TLV tlv = ticketContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            TicketInit.LOG.error(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
        }
        final Ticket ticket = new Ticket();
        ticketContainer.setTicket(ticket);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)TicketInit.class);
    }
}
