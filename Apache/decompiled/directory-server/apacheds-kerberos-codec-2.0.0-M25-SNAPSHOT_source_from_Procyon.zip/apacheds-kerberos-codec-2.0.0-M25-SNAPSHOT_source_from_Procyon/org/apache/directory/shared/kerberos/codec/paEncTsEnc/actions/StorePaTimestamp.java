// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.paEncTsEnc.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.paEncTsEnc.PaEncTsEncContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StorePaTimestamp extends AbstractReadKerberosTime<PaEncTsEncContainer>
{
    public StorePaTimestamp() {
        super("Stores the CTime");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final PaEncTsEncContainer paEncTsEncContainer) {
        paEncTsEncContainer.getPaEncTsEnc().setPaTimestamp(krbtime);
        paEncTsEncContainer.setGrammarEndAllowed(true);
    }
}
