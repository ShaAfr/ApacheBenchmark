// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.KrbCredInfoContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptionKey;

public class StoreKey extends AbstractReadEncryptionKey<KrbCredInfoContainer>
{
    public StoreKey() {
        super("KrbCredInfo key");
    }
    
    @Override
    protected void setEncryptionKey(final EncryptionKey encryptionKey, final KrbCredInfoContainer krbCredInfoContainer) {
        krbCredInfoContainer.getKrbCredInfo().setKey(encryptionKey);
        krbCredInfoContainer.setGrammarEndAllowed(true);
    }
}
