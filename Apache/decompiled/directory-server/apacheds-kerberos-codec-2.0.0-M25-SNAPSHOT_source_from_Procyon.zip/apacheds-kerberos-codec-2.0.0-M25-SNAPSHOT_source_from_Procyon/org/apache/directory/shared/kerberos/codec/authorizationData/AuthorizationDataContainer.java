// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authorizationData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class AuthorizationDataContainer extends AbstractContainer
{
    private AuthorizationData authorizationData;
    
    public AuthorizationDataContainer() {
        this.setGrammar((Grammar)AuthorizationDataGrammar.getInstance());
        this.setTransition((Enum)AuthorizationDataStatesEnum.START_STATE);
    }
    
    public AuthorizationData getAuthorizationData() {
        return this.authorizationData;
    }
    
    public void setAuthorizationData(final AuthorizationData authorizationData) {
        this.authorizationData = authorizationData;
    }
}
