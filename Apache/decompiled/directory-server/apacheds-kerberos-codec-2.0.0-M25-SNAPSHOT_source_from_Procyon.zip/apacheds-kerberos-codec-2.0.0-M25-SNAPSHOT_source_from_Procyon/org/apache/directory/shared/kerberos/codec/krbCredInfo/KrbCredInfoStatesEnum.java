// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum KrbCredInfoStatesEnum implements States
{
    START_STATE, 
    KRB_CRED_INFO_SEQ_TAG_STATE, 
    KRB_CRED_INFO_KEY_TAG_STATE, 
    KRB_CRED_INFO_PREALM_TAG_STATE, 
    KRB_CRED_INFO_PREALM_STATE, 
    KRB_CRED_INFO_PNAME_TAG_STATE, 
    KRB_CRED_INFO_FLAGS_TAG_STATE, 
    KRB_CRED_INFO_FLAGS_STATE, 
    KRB_CRED_INFO_AUTHTIME_TAG_STATE, 
    KRB_CRED_INFO_AUTHTIME_STATE, 
    KRB_CRED_INFO_STARTTIME_TAG_STATE, 
    KRB_CRED_INFO_STARTTIME_STATE, 
    KRB_CRED_INFO_ENDTIME_TAG_STATE, 
    KRB_CRED_INFO_ENDTIME_STATE, 
    KRB_CRED_INFO_RENEWTILL_TAG_STATE, 
    KRB_CRED_INFO_RENEWTILL_STATE, 
    KRB_CRED_INFO_SREALM_TAG_STATE, 
    KRB_CRED_INFO_SREALM_STATE, 
    KRB_CRED_INFO_SNAME_TAG_STATE, 
    KRB_CRED_INFO_CADDR_TAG_STATE, 
    LAST_KRB_CRED_INFO_STATE;
    
    public String getGrammarName(final int grammar) {
        return "KRB_CRED_INFO_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<KrbCredInfoContainer> grammar) {
        if (grammar instanceof KrbCredInfoGrammar) {
            return "KRB_CRED_INFO_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == KrbCredInfoStatesEnum.LAST_KRB_CRED_INFO_STATE.ordinal()) ? "LAST_KRB_CRED_INFO_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == KrbCredInfoStatesEnum.LAST_KRB_CRED_INFO_STATE;
    }
    
    public KrbCredInfoStatesEnum getStartState() {
        return KrbCredInfoStatesEnum.START_STATE;
    }
}
