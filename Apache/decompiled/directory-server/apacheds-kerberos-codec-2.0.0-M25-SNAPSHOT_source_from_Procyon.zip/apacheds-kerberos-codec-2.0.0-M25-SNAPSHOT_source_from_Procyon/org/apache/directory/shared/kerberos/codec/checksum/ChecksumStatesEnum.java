// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.checksum;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum ChecksumStatesEnum implements States
{
    START_STATE, 
    CHECKSUM_SEQ_STATE, 
    CHECKSUM_TYPE_TAG_STATE, 
    CHECKSUM_TYPE_STATE, 
    CHECKSUM_CHECKSUM_TAG_STATE, 
    CHECKSUM_CHECKSUM_STATE, 
    LAST_CHECKSUM_STATE;
    
    public String getGrammarName(final int grammar) {
        return "CHECKSUM_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<ChecksumContainer> grammar) {
        if (grammar instanceof ChecksumGrammar) {
            return "CHECKSUM_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == ChecksumStatesEnum.LAST_CHECKSUM_STATE.ordinal()) ? "LAST_CHECKSUM_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == ChecksumStatesEnum.LAST_CHECKSUM_STATE;
    }
    
    public ChecksumStatesEnum getStartState() {
        return ChecksumStatesEnum.START_STATE;
    }
}
