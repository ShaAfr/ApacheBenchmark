// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.tgsReq.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.KdcReq;
import org.apache.directory.shared.kerberos.messages.TgsReq;
import org.apache.directory.shared.kerberos.codec.kdcReq.KdcReqContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.tgsReq.TgsReqContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreKdcReq extends GrammarAction<TgsReqContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreKdcReq() {
        super("Add an KDC-REQ instance");
    }
    
    public void action(final TgsReqContainer tgsReqContainer) throws DecoderException {
        final TLV tlv = tgsReqContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreKdcReq.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder kdcReqDecoder = new Asn1Decoder();
        final KdcReqContainer kdcReqContainer = new KdcReqContainer(tgsReqContainer.getStream());
        final TgsReq tgsReq = new TgsReq();
        kdcReqContainer.setKdcReq(tgsReq);
        try {
            kdcReqDecoder.decode(tgsReqContainer.getStream(), (Asn1Container)kdcReqContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        tgsReqContainer.updateParent();
        if (tgsReq.getMessageType() != KerberosMessageType.TGS_REQ) {
            throw new DecoderException("Bad message type");
        }
        tgsReqContainer.setTgsReq(tgsReq);
        if (StoreKdcReq.IS_DEBUG) {
            StoreKdcReq.LOG.debug("TGS-REQ : {}", (Object)tgsReq);
        }
        tgsReqContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreKdcReq.class);
        IS_DEBUG = StoreKdcReq.LOG.isDebugEnabled();
    }
}
