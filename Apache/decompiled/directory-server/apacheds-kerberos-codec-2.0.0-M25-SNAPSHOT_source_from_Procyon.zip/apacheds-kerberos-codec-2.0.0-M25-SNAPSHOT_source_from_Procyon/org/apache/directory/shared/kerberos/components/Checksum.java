// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import java.util.Arrays;
import org.apache.directory.shared.kerberos.crypto.checksum.ChecksumType;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class Checksum implements Asn1Object
{
    private static final Logger log;
    private static final boolean IS_DEBUG;
    private ChecksumType cksumtype;
    private byte[] checksum;
    private int checksumTypeLength;
    private int checksumBytesLength;
    private int checksumLength;
    
    public Checksum() {
    }
    
    public Checksum(final ChecksumType cksumtype, final byte[] checksum) {
        this.cksumtype = cksumtype;
        this.checksum = checksum;
    }
    
    @Override
    public int hashCode() {
        int hash = 37;
        hash = hash * 17 + this.cksumtype.hashCode();
        hash = hash * 17 + Arrays.hashCode(this.checksum);
        return hash;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Checksum)) {
            return false;
        }
        final Checksum that = (Checksum)o;
        return this.cksumtype == that.cksumtype && Arrays.equals(this.checksum, that.checksum);
    }
    
    public byte[] getChecksumValue() {
        return this.checksum;
    }
    
    public void setChecksumValue(final byte[] checksum) {
        this.checksum = checksum;
    }
    
    public ChecksumType getChecksumType() {
        return this.cksumtype;
    }
    
    public void setChecksumType(final ChecksumType cksumType) {
        this.cksumtype = cksumType;
    }
    
    public int computeLength() {
        this.checksumTypeLength = 2 + BerValue.getNbBytes(this.cksumtype.getValue());
        this.checksumLength = 1 + TLV.getNbBytes(this.checksumTypeLength) + this.checksumTypeLength;
        if (this.checksum == null) {
            this.checksumBytesLength = 2;
        }
        else {
            this.checksumBytesLength = 1 + TLV.getNbBytes(this.checksum.length) + this.checksum.length;
        }
        this.checksumLength += 1 + TLV.getNbBytes(this.checksumBytesLength) + this.checksumBytesLength;
        final int checksumSeqLength = 1 + TLV.getNbBytes(this.checksumLength) + this.checksumLength;
        return checksumSeqLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.checksumLength));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.checksumTypeLength));
            BerValue.encode(buffer, this.cksumtype.getValue());
            buffer.put((byte)(-95));
            buffer.put(TLV.getBytes(this.checksumBytesLength));
            BerValue.encode(buffer, this.checksum);
        }
        catch (BufferOverflowException boe) {
            Checksum.log.error(I18n.err(I18n.ERR_140, new Object[] { 1 + TLV.getNbBytes(this.checksumLength) + this.checksumLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (Checksum.IS_DEBUG) {
            Checksum.log.debug("Checksum encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            Checksum.log.debug("Checksum initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        return this.toString("");
    }
    
    public String toString(final String tabs) {
        final StringBuilder sb = new StringBuilder();
        sb.append(tabs).append("Checksum : {\n");
        sb.append(tabs).append("    cksumtype: ").append(this.cksumtype).append('\n');
        if (this.checksum != null) {
            sb.append(tabs + "    checksum:").append(Strings.dumpBytes(this.checksum)).append('\n');
        }
        sb.append(tabs + "}\n");
        return sb.toString();
    }
    
    static {
        log = LoggerFactory.getLogger((Class)Checksum.class);
        IS_DEBUG = Checksum.log.isDebugEnabled();
    }
}
