// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.checksum;

import java.util.zip.CRC32;
import org.apache.directory.server.kerberos.shared.crypto.encryption.KeyUsage;
import org.apache.directory.shared.kerberos.crypto.checksum.ChecksumType;

class Crc32Checksum implements ChecksumEngine
{
    @Override
    public ChecksumType checksumType() {
        return ChecksumType.CRC32;
    }
    
    @Override
    public byte[] calculateChecksum(final byte[] data, final byte[] key, final KeyUsage usage) {
        final CRC32 crc32 = new CRC32();
        crc32.update(data);
        return this.int2octet((int)crc32.getValue());
    }
    
    private byte[] int2octet(final int value) {
        final byte[] bytes = new byte[4];
        for (int i = 0, shift = 24; i < 4; ++i, shift -= 8) {
            bytes[i] = (byte)(0xFF & value >> shift);
        }
        return bytes;
    }
}
