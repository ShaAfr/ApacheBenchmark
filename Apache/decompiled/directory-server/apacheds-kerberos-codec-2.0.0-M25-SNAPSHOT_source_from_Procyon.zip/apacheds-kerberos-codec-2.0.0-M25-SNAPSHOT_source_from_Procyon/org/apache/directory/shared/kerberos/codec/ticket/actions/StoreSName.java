// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.ticket.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreSName extends AbstractReadPrincipalName<TicketContainer>
{
    public StoreSName() {
        super("Kerberos Ticket principalName");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final TicketContainer ticketContainer) {
        ticketContainer.getTicket().setSName(principalName);
    }
}
