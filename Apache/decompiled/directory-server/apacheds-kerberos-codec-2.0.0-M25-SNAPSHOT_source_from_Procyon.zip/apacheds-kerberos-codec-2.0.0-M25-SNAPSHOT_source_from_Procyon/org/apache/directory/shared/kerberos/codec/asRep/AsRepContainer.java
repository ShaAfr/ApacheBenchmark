// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.asRep;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.AsRep;
import org.apache.directory.shared.kerberos.codec.kdcRep.KdcRepContainer;

public class AsRepContainer extends KdcRepContainer
{
    private AsRep asRep;
    
    public AsRepContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)AsRepGrammar.getInstance());
        this.setTransition((Enum)AsRepStatesEnum.START_STATE);
    }
    
    public AsRep getAsRep() {
        return this.asRep;
    }
    
    public void setAsRep(final AsRep asRep) {
        this.asRep = asRep;
    }
}
