// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.authenticator.AuthenticatorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreCName extends AbstractReadPrincipalName<AuthenticatorContainer>
{
    public StoreCName() {
        super("Authenticator cname");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final AuthenticatorContainer authenticatorContainer) {
        authenticatorContainer.getAuthenticator().setCName(principalName);
    }
}
