// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.EncKdcRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreNonce extends AbstractReadInteger<EncKdcRepPartContainer>
{
    public StoreNonce() {
        super("EncKdcRepPart nonce", Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    
    public void setIntegerValue(final int value, final EncKdcRepPartContainer encKdcRepPartContainer) {
        encKdcRepPartContainer.getEncKdcRepPart().setNonce(value);
    }
}
