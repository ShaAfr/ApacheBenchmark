// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTgsRepPart;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.encTgsRepPart.actions.StoreEncTgsRepPart;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class EncTgsRepPartGrammar extends AbstractGrammar<EncTgsRepPartContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<EncTgsRepPartContainer> instance;
    
    private EncTgsRepPartGrammar() {
        this.setName(EncTgsRepPartGrammar.class.getName());
        super.transitions = new GrammarTransition[EncTgsRepPartStatesEnum.LAST_ENC_TGS_REP_PART_STATE.ordinal()][256];
        super.transitions[EncTgsRepPartStatesEnum.START_STATE.ordinal()][122] = new GrammarTransition((Enum)EncTgsRepPartStatesEnum.START_STATE, (Enum)EncTgsRepPartStatesEnum.ENC_TGS_REP_PART_STATE, 122, (Action)new StoreEncTgsRepPart());
    }
    
    public static Grammar<EncTgsRepPartContainer> getInstance() {
        return EncTgsRepPartGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncTgsRepPartGrammar.class);
        IS_DEBUG = EncTgsRepPartGrammar.LOG.isDebugEnabled();
        EncTgsRepPartGrammar.instance = (Grammar<EncTgsRepPartContainer>)new EncTgsRepPartGrammar();
    }
}
