// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apReq.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.apReq.ApReqContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPvno;

public class StorePvno extends AbstractReadPvno<ApReqContainer>
{
    public StorePvno() {
        super("StorePvno value");
    }
    
    @Override
    protected void setPvno(final int pvno, final ApReqContainer apReqContainer) {
        apReqContainer.getApReq().setProtocolVersionNumber(pvno);
    }
}
