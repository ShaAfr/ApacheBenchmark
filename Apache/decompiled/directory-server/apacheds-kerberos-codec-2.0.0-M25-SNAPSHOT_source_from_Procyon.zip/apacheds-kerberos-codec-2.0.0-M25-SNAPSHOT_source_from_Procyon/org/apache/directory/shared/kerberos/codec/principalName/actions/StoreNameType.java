// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.principalName.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.types.PrincipalNameType;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.principalName.PrincipalNameContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreNameType extends AbstractReadInteger<PrincipalNameContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreNameType() {
        super("Store the PrincipalName type");
    }
    
    protected void setIntegerValue(final int value, final PrincipalNameContainer principalNameContainer) {
        final PrincipalName principalName = principalNameContainer.getPrincipalName();
        final PrincipalNameType principalNameType = PrincipalNameType.getTypeByValue(value);
        principalName.setNameType(principalNameType);
        if (StoreNameType.IS_DEBUG) {
            StoreNameType.LOG.debug("name-type : {}" + principalNameType);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreNameType.class);
        IS_DEBUG = StoreNameType.LOG.isDebugEnabled();
    }
}
