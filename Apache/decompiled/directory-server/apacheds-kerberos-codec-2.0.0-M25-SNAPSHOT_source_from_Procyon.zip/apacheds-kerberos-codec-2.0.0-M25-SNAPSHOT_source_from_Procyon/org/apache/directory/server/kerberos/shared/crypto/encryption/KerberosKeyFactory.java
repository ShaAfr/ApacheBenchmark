// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import java.util.Collections;
import javax.security.auth.kerberos.KerberosKey;
import org.apache.directory.shared.kerberos.KerberosUtils;
import javax.security.auth.kerberos.KerberosPrincipal;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Set;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import java.util.Map;

public class KerberosKeyFactory
{
    public static final Map<EncryptionType, String> DEFAULT_CIPHERS;
    
    public static Map<EncryptionType, EncryptionKey> getKerberosKeys(final String principalName, final String passPhrase) {
        return getKerberosKeys(principalName, passPhrase, KerberosKeyFactory.DEFAULT_CIPHERS.keySet());
    }
    
    public static Map<EncryptionType, EncryptionKey> getKerberosKeys(final String principalName, final String passPhrase, final Set<EncryptionType> ciphers) {
        final Map<EncryptionType, EncryptionKey> kerberosKeys = new HashMap<EncryptionType, EncryptionKey>();
        for (final EncryptionType encryptionType : ciphers) {
            try {
                kerberosKeys.put(encryptionType, string2Key(principalName, passPhrase, encryptionType));
            }
            catch (IllegalArgumentException ex) {}
        }
        return kerberosKeys;
    }
    
    public static EncryptionKey string2Key(final String principalName, final String passPhrase, final EncryptionType encryptionType) {
        final KerberosPrincipal principal = new KerberosPrincipal(principalName);
        final KerberosKey kerberosKey = new KerberosKey(principal, passPhrase.toCharArray(), KerberosUtils.getAlgoNameFromEncType(encryptionType));
        final EncryptionKey encryptionKey = new EncryptionKey(encryptionType, kerberosKey.getEncoded(), kerberosKey.getVersionNumber());
        return encryptionKey;
    }
    
    static {
        final Map<EncryptionType, String> map = new HashMap<EncryptionType, String>();
        map.put(EncryptionType.DES_CBC_MD5, "DES");
        map.put(EncryptionType.DES3_CBC_SHA1_KD, "DESede");
        map.put(EncryptionType.RC4_HMAC, "ArcFourHmac");
        map.put(EncryptionType.AES128_CTS_HMAC_SHA1_96, "AES128");
        map.put(EncryptionType.AES256_CTS_HMAC_SHA1_96, "AES256");
        DEFAULT_CIPHERS = Collections.unmodifiableMap((Map<? extends EncryptionType, ? extends String>)map);
    }
}
