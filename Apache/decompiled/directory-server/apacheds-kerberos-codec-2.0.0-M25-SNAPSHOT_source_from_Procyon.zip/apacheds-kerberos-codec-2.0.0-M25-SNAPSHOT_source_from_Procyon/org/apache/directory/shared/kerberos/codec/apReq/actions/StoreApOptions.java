// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apReq.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.messages.ApReq;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.codec.options.ApOptions;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.apReq.ApReqContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreApOptions extends GrammarAction<ApReqContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreApOptions() {
        super("Stores the ApOptions");
    }
    
    public void action(final ApReqContainer apReqContainer) throws DecoderException {
        final TLV tlv = apReqContainer.getCurrentTLV();
        if (tlv.getLength() != 5) {
            StoreApOptions.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final ApReq apReq = apReqContainer.getApReq();
        final ApOptions apOptions = new ApOptions(tlv.getValue().getData());
        apReq.setApOptions(apOptions);
        if (StoreApOptions.IS_DEBUG) {
            StoreApOptions.LOG.debug("APOptions : {}", (Object)apOptions);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreApOptions.class);
        IS_DEBUG = StoreApOptions.LOG.isDebugEnabled();
    }
}
