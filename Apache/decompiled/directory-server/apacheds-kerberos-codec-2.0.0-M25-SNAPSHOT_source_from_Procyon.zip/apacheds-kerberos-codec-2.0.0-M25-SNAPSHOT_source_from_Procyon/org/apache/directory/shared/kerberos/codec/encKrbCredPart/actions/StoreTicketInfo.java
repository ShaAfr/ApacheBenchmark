// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbCredPart.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.KrbCredInfo;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.KrbCredInfoContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encKrbCredPart.EncKrbCredPartContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreTicketInfo extends GrammarAction<EncKrbCredPartContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public void action(final EncKrbCredPartContainer encKrbCredPartContainer) throws DecoderException {
        final TLV tlv = encKrbCredPartContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreTicketInfo.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder decoder = new Asn1Decoder();
        final KrbCredInfoContainer ticketInfoContainer = new KrbCredInfoContainer();
        ticketInfoContainer.setStream(encKrbCredPartContainer.getStream());
        encKrbCredPartContainer.rewind();
        try {
            decoder.decode(encKrbCredPartContainer.getStream(), (Asn1Container)ticketInfoContainer);
        }
        catch (DecoderException e) {
            throw e;
        }
        final KrbCredInfo ticketInfo = ticketInfoContainer.getKrbCredInfo();
        encKrbCredPartContainer.getEncKrbCredPart().addTicketInfo(ticketInfo);
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        encKrbCredPartContainer.updateParent();
        encKrbCredPartContainer.setGrammarEndAllowed(true);
        if (StoreTicketInfo.IS_DEBUG) {
            StoreTicketInfo.LOG.debug("KrbCredInfo : {}", (Object)ticketInfo);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreTicketInfo.class);
        IS_DEBUG = StoreTicketInfo.LOG.isDebugEnabled();
    }
}
