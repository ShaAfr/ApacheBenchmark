// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adIfRelevant;

import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.components.AdIfRelevant;
import org.apache.directory.shared.kerberos.codec.authorizationData.AuthorizationDataContainer;

public class AdIfRelevantContainer extends AuthorizationDataContainer
{
    public AdIfRelevantContainer() {
        this.setAuthorizationData(new AdIfRelevant());
    }
    
    public AdIfRelevant getAdIfRelevant() {
        return (AdIfRelevant)this.getAuthorizationData();
    }
}
