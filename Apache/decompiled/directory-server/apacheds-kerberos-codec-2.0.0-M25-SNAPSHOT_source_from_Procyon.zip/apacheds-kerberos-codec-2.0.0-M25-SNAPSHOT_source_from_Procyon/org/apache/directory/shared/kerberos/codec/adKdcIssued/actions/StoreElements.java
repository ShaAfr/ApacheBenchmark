// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adKdcIssued.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.codec.adKdcIssued.AdKdcIssuedContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadAuthorizationData;

public class StoreElements extends AbstractReadAuthorizationData<AdKdcIssuedContainer>
{
    public StoreElements() {
        super("AdKdcIssued 'elements' value");
    }
    
    @Override
    protected void setAuthorizationData(final AuthorizationData authorizationData, final AdKdcIssuedContainer adKdcIssuedContainer) {
        adKdcIssuedContainer.getAdKdcIssued().setElements(authorizationData);
        adKdcIssuedContainer.setGrammarEndAllowed(true);
    }
}
