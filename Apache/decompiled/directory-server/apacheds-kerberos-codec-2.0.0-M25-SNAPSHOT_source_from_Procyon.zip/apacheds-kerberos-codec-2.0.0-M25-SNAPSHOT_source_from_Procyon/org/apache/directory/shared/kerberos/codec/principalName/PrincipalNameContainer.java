// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.principalName;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class PrincipalNameContainer extends AbstractContainer
{
    private PrincipalName principalName;
    
    public PrincipalNameContainer() {
        this.setGrammar((Grammar)PrincipalNameGrammar.getInstance());
        this.setTransition((Enum)PrincipalNameStatesEnum.START_STATE);
    }
    
    public PrincipalName getPrincipalName() {
        return this.principalName;
    }
    
    public void setPrincipalName(final PrincipalName principalName) {
        this.principalName = principalName;
    }
}
