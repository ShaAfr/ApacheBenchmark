// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptedData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncryptedDataContainer extends AbstractContainer
{
    private EncryptedData encryptedData;
    
    public EncryptedDataContainer() {
        this.setGrammar((Grammar)EncryptedDataGrammar.getInstance());
        this.setTransition((Enum)EncryptedDataStatesEnum.START_STATE);
    }
    
    public EncryptedData getEncryptedData() {
        return this.encryptedData;
    }
    
    public void setEncryptedData(final EncryptedData encryptedData) {
        this.encryptedData = encryptedData;
    }
}
