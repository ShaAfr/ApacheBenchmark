// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbPriv;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.krbPriv.actions.StoreEncPart;
import org.apache.directory.shared.kerberos.codec.krbPriv.actions.CheckMsgType;
import org.apache.directory.shared.kerberos.codec.krbPriv.actions.StorePvno;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.krbPriv.actions.KrbPrivInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class KrbPrivGrammar extends AbstractGrammar<KrbPrivContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<KrbPrivContainer> instance;
    
    private KrbPrivGrammar() {
        this.setName(KrbPrivGrammar.class.getName());
        super.transitions = new GrammarTransition[KrbPrivStatesEnum.LAST_KRB_PRIV_STATE.ordinal()][256];
        super.transitions[KrbPrivStatesEnum.START_STATE.ordinal()][117] = new GrammarTransition((Enum)KrbPrivStatesEnum.START_STATE, (Enum)KrbPrivStatesEnum.KRB_PRIV_TAG_STATE, 117, (Action)new KrbPrivInit());
        super.transitions[KrbPrivStatesEnum.KRB_PRIV_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KrbPrivStatesEnum.KRB_PRIV_TAG_STATE, (Enum)KrbPrivStatesEnum.KRB_PRIV_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KrbPrivStatesEnum.KRB_PRIV_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)KrbPrivStatesEnum.KRB_PRIV_SEQ_STATE, (Enum)KrbPrivStatesEnum.KRB_PRIV_PVNO_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[KrbPrivStatesEnum.KRB_PRIV_PVNO_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KrbPrivStatesEnum.KRB_PRIV_PVNO_TAG_STATE, (Enum)KrbPrivStatesEnum.KRB_PRIV_PVNO_STATE, UniversalTag.INTEGER, (Action)new StorePvno());
        super.transitions[KrbPrivStatesEnum.KRB_PRIV_PVNO_STATE.ordinal()][161] = new GrammarTransition((Enum)KrbPrivStatesEnum.KRB_PRIV_PVNO_STATE, (Enum)KrbPrivStatesEnum.KRB_PRIV_MSGTYPE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[KrbPrivStatesEnum.KRB_PRIV_MSGTYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KrbPrivStatesEnum.KRB_PRIV_MSGTYPE_TAG_STATE, (Enum)KrbPrivStatesEnum.KRB_PRIV_MSGTYPE_STATE, UniversalTag.INTEGER, (Action)new CheckMsgType());
        super.transitions[KrbPrivStatesEnum.KRB_PRIV_MSGTYPE_STATE.ordinal()][163] = new GrammarTransition((Enum)KrbPrivStatesEnum.KRB_PRIV_MSGTYPE_STATE, (Enum)KrbPrivStatesEnum.KRB_PRIV_EN_PART_TAG_STATE, 163, (Action)new StoreEncPart());
    }
    
    public static Grammar<KrbPrivContainer> getInstance() {
        return KrbPrivGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KrbPrivGrammar.class);
        IS_DEBUG = KrbPrivGrammar.LOG.isDebugEnabled();
        KrbPrivGrammar.instance = (Grammar<KrbPrivContainer>)new KrbPrivGrammar();
    }
}
