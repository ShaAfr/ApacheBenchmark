// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.lastReq.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.LastReq;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.lastReq.LastReqContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class LastReqInit extends GrammarAction<LastReqContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public LastReqInit() {
        super("Creates a LastReq instance");
    }
    
    public void action(final LastReqContainer lastReqContainer) throws DecoderException {
        final TLV tlv = lastReqContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            LastReqInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final LastReq lastReq = new LastReq();
        lastReqContainer.setLastReq(lastReq);
        if (LastReqInit.IS_DEBUG) {
            LastReqInit.LOG.debug("LastReq created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)LastReqInit.class);
        IS_DEBUG = LastReqInit.LOG.isDebugEnabled();
    }
}
