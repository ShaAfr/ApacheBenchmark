// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos;

import org.apache.directory.api.util.Strings;
import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.util.TimeZone;
import java.io.Serializable;

public class KerberosTime implements Comparable<KerberosTime>, Serializable
{
    private static final long serialVersionUID = -7541256140193748103L;
    private static final TimeZone UTC;
    private String date;
    private long kerberosTime;
    public static final KerberosTime INFINITY;
    public static final int MINUTE = 60000;
    public static final int DAY = 86400000;
    public static final int WEEK = 604800000;
    
    public KerberosTime() {
        this.convertInternal(this.kerberosTime = System.currentTimeMillis() / 1000L * 1000L);
    }
    
    public KerberosTime(final String date) {
        try {
            this.setDate(date);
        }
        catch (ParseException pe) {
            throw new IllegalArgumentException("Bad time : " + date);
        }
    }
    
    public KerberosTime(final long date) {
        this.convertInternal(date);
    }
    
    public KerberosTime(final Date time) {
        this.convertInternal(this.kerberosTime = time.getTime() / 1000L * 1000L);
    }
    
    private void convertInternal(final long date) {
        final Calendar calendar = Calendar.getInstance(KerberosTime.UTC);
        calendar.setTimeInMillis(date);
        synchronized (KerberosUtils.UTC_DATE_FORMAT) {
            this.date = KerberosUtils.UTC_DATE_FORMAT.format(calendar.getTime());
        }
        this.kerberosTime = calendar.getTimeInMillis() / 1000L * 1000L;
    }
    
    public long getTime() {
        return this.kerberosTime;
    }
    
    public Date toDate() {
        return new Date(this.kerberosTime);
    }
    
    public static KerberosTime getTime(final String zuluTime) throws ParseException {
        Date date = null;
        synchronized (KerberosUtils.UTC_DATE_FORMAT) {
            date = KerberosUtils.UTC_DATE_FORMAT.parse(zuluTime);
        }
        return new KerberosTime(date);
    }
    
    public void setDate(final String date) throws ParseException {
        synchronized (KerberosUtils.UTC_DATE_FORMAT) {
            this.kerberosTime = KerberosUtils.UTC_DATE_FORMAT.parse(date).getTime();
        }
        this.convertInternal(this.kerberosTime);
    }
    
    public byte[] getBytes() {
        return Strings.getBytesUtf8(this.date);
    }
    
    public String getDate() {
        return this.date;
    }
    
    @Override
    public int hashCode() {
        return (int)this.kerberosTime;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return true;
        }
        final KerberosTime other = (KerberosTime)obj;
        return this.kerberosTime == other.kerberosTime;
    }
    
    public boolean isInClockSkew(final long clockSkew) {
        final long delta = Math.abs(this.kerberosTime - System.currentTimeMillis());
        return delta < clockSkew;
    }
    
    @Override
    public int compareTo(final KerberosTime that) {
        final int BEFORE = -1;
        final int EQUAL = 0;
        final int AFTER = 1;
        if (this == that) {
            return 0;
        }
        if (this.kerberosTime < that.kerberosTime) {
            return -1;
        }
        if (this.kerberosTime > that.kerberosTime) {
            return 1;
        }
        return 0;
    }
    
    public boolean lessThan(final KerberosTime ktime) {
        return this.kerberosTime <= ktime.kerberosTime;
    }
    
    public boolean greaterThan(final KerberosTime ktime) {
        return this.kerberosTime > ktime.kerberosTime;
    }
    
    public boolean isZero() {
        return this.kerberosTime == 0L;
    }
    
    @Override
    public String toString() {
        return this.date;
    }
    
    static {
        UTC = TimeZone.getTimeZone("UTC");
        INFINITY = new KerberosTime(Long.MAX_VALUE);
    }
}
