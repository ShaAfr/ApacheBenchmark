// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.padata;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.PaData;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class PaDataContainer extends AbstractContainer
{
    private PaData paData;
    
    public PaDataContainer() {
        this.setGrammar((Grammar)PaDataGrammar.getInstance());
        this.setTransition((Enum)PaDataStatesEnum.START_STATE);
    }
    
    public PaData getPaData() {
        return this.paData;
    }
    
    public void setPaData(final PaData paData) {
        this.paData = paData;
    }
}
