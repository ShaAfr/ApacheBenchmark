// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authorizationData;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.authorizationData.actions.StoreAdData;
import org.apache.directory.shared.kerberos.codec.authorizationData.actions.StoreAdType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.authorizationData.actions.AuthorizationDataInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class AuthorizationDataGrammar extends AbstractGrammar<AuthorizationDataContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<AuthorizationDataContainer> instance;
    
    private AuthorizationDataGrammar() {
        this.setName(AuthorizationDataGrammar.class.getName());
        super.transitions = new GrammarTransition[AuthorizationDataStatesEnum.LAST_AUTHORIZATION_DATA_STATE.ordinal()][256];
        super.transitions[AuthorizationDataStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)AuthorizationDataStatesEnum.START_STATE, (Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_SEQ_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new AuthorizationDataInit());
        super.transitions[AuthorizationDataStatesEnum.AUTHORIZATION_DATA_SEQ_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_SEQ_SEQ_STATE, (Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[AuthorizationDataStatesEnum.AUTHORIZATION_DATA_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_SEQ_STATE, (Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADTYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADTYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADTYPE_TAG_STATE, (Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADTYPE_STATE, UniversalTag.INTEGER, (Action)new StoreAdType());
        super.transitions[AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADTYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADTYPE_STATE, (Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADDATA_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADDATA_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.getValue()] = new GrammarTransition((Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADDATA_TAG_STATE, (Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADDATA_STATE, UniversalTag.OCTET_STRING, (Action)new StoreAdData());
        super.transitions[AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADDATA_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_ADDATA_STATE, (Enum)AuthorizationDataStatesEnum.AUTHORIZATION_DATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
    }
    
    public static Grammar<AuthorizationDataContainer> getInstance() {
        return AuthorizationDataGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AuthorizationDataGrammar.class);
        IS_DEBUG = AuthorizationDataGrammar.LOG.isDebugEnabled();
        AuthorizationDataGrammar.instance = (Grammar<AuthorizationDataContainer>)new AuthorizationDataGrammar();
    }
}
