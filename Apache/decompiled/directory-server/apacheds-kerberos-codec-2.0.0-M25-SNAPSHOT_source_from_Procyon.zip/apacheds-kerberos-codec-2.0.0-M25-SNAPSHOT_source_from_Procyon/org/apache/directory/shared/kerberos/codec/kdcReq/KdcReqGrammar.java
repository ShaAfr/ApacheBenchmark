// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReq;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.kdcReq.actions.AddPaData;
import org.apache.directory.shared.kerberos.codec.kdcReq.actions.StoreKdcReqBody;
import org.apache.directory.shared.kerberos.codec.kdcReq.actions.CheckMsgType;
import org.apache.directory.shared.kerberos.codec.kdcReq.actions.StorePvno;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class KdcReqGrammar extends AbstractGrammar<KdcReqContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<KdcReqContainer> instance;
    
    private KdcReqGrammar() {
        this.setName(KdcReqGrammar.class.getName());
        super.transitions = new GrammarTransition[KdcReqStatesEnum.LAST_KDC_REQ_STATE.ordinal()][256];
        super.transitions[KdcReqStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcReqStatesEnum.START_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_PVNO_TAG_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PVNO_TAG_STATE.ordinal()][161] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PVNO_TAG_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_PVNO_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PVNO_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PVNO_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_MSG_TYPE_TAG_STATE, UniversalTag.INTEGER, (Action)new StorePvno());
        super.transitions[KdcReqStatesEnum.KDC_REQ_MSG_TYPE_TAG_STATE.ordinal()][162] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_MSG_TYPE_TAG_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_MSG_TYPE_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[KdcReqStatesEnum.KDC_REQ_MSG_TYPE_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_MSG_TYPE_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_OR_REQ_BODY_STATE, UniversalTag.INTEGER, (Action)new CheckMsgType());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PA_DATA_OR_REQ_BODY_STATE.ordinal()][163] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_OR_REQ_BODY_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PA_DATA_OR_REQ_BODY_STATE.ordinal()][164] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_OR_REQ_BODY_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_KDC_REQ_BODY_STATE, 164, (Action)new StoreKdcReqBody());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PA_DATA_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_TAG_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PA_DATA_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_SEQ_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_STATE, UniversalTag.SEQUENCE, (Action)new AddPaData());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PA_DATA_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_STATE, UniversalTag.SEQUENCE, (Action)new AddPaData());
        super.transitions[KdcReqStatesEnum.KDC_REQ_PA_DATA_STATE.ordinal()][164] = new GrammarTransition((Enum)KdcReqStatesEnum.KDC_REQ_PA_DATA_STATE, (Enum)KdcReqStatesEnum.KDC_REQ_KDC_REQ_BODY_STATE, 164, (Action)new StoreKdcReqBody());
    }
    
    public static Grammar<KdcReqContainer> getInstance() {
        return KdcReqGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KdcReqGrammar.class);
        IS_DEBUG = KdcReqGrammar.LOG.isDebugEnabled();
        KdcReqGrammar.instance = (Grammar<KdcReqContainer>)new KdcReqGrammar();
    }
}
