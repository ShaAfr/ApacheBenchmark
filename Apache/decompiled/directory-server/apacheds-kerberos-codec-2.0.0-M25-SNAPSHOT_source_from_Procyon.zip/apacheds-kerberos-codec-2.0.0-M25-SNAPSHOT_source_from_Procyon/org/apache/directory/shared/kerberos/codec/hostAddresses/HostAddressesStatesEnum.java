// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddresses;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum HostAddressesStatesEnum implements States
{
    START_STATE, 
    HOST_ADDRESSES_SEQ_STATE, 
    HOST_ADDRESSES_ADDRESS_STATE, 
    LAST_HOST_ADDRESSES_STATE;
    
    public String getGrammarName(final int grammar) {
        return "HOST_ADDRESSES_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<HostAddressesContainer> grammar) {
        if (grammar instanceof HostAddressesGrammar) {
            return "HOST_ADDRESSES_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == HostAddressesStatesEnum.LAST_HOST_ADDRESSES_STATE.ordinal()) ? "HOST_ADDRESSES_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == HostAddressesStatesEnum.LAST_HOST_ADDRESSES_STATE;
    }
    
    public HostAddressesStatesEnum getStartState() {
        return HostAddressesStatesEnum.START_STATE;
    }
}
