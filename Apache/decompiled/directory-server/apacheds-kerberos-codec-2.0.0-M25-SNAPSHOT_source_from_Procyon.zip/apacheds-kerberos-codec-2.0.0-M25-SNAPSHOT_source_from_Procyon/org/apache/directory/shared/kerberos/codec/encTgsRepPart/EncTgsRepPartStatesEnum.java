// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTgsRepPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum EncTgsRepPartStatesEnum implements States
{
    START_STATE, 
    ENC_TGS_REP_PART_STATE, 
    LAST_ENC_TGS_REP_PART_STATE;
    
    public String getGrammarName(final int grammar) {
        return "ENC_TGS_REP_PART_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<EncTgsRepPartContainer> grammar) {
        if (grammar instanceof EncTgsRepPartGrammar) {
            return "ENC_TGS_REP_PART_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == EncTgsRepPartStatesEnum.LAST_ENC_TGS_REP_PART_STATE.ordinal()) ? "ENC_TGS_REP_PART_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == EncTgsRepPartStatesEnum.LAST_ENC_TGS_REP_PART_STATE;
    }
    
    public EncTgsRepPartStatesEnum getStartState() {
        return EncTgsRepPartStatesEnum.START_STATE;
    }
}
