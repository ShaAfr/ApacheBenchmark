// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbError;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.KrbError;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KrbErrorContainer extends AbstractContainer
{
    private KrbError krbError;
    
    public KrbErrorContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)KrbErrorGrammar.getInstance());
        this.setTransition((Enum)KrbErrorStatesEnum.START_STATE);
    }
    
    public KrbError getKrbError() {
        return this.krbError;
    }
    
    public void setKrbError(final KrbError krbError) {
        this.krbError = krbError;
    }
}
