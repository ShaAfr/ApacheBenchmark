// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbPrivPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encKrbPrivPart.EncKrbPrivPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreUserData extends AbstractReadOctetString<EncKrbPrivPartContainer>
{
    public StoreUserData() {
        super("EncKrbPrivPart user-data", true);
    }
    
    protected void setOctetString(final byte[] data, final EncKrbPrivPartContainer encKrbPrivPartContainer) {
        encKrbPrivPartContainer.getEncKrbPrivPart().setUserData(data);
    }
}
