// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbCredPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.encKrbCredPart.EncKrbCredPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreTimestamp extends AbstractReadKerberosTime<EncKrbCredPartContainer>
{
    public StoreTimestamp() {
        super("EncKrbCredPart timemstamp");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final EncKrbCredPartContainer encKrbCredPartContainer) {
        encKrbCredPartContainer.getEncKrbCredPart().setTimestamp(krbtime);
        encKrbCredPartContainer.setGrammarEndAllowed(true);
    }
}
