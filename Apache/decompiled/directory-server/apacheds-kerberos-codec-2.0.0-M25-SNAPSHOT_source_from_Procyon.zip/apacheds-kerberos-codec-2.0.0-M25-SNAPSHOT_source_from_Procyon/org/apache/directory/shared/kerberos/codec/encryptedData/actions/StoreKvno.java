// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptedData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.codec.encryptedData.EncryptedDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreKvno extends AbstractReadInteger<EncryptedDataContainer>
{
    public StoreKvno() {
        super("EncryptedPart kvno", 0, Integer.MAX_VALUE);
    }
    
    protected void setIntegerValue(final int value, final EncryptedDataContainer encryptedDataContainer) {
        final EncryptedData encryptedData = encryptedDataContainer.getEncryptedData();
        encryptedData.setKvno(value);
    }
}
