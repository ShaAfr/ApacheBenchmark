// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.crypto.encryption;

import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.SecretKey;
import java.security.GeneralSecurityException;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.exceptions.ErrorType;
import java.util.Arrays;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import java.util.zip.CRC32;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;

public class DesCbcCrcEncryption extends EncryptionEngine
{
    private static final byte[] iv;
    
    public EncryptionType getEncryptionType() {
        return EncryptionType.DES_CBC_CRC;
    }
    
    public int getConfounderLength() {
        return 8;
    }
    
    public int getChecksumLength() {
        return 4;
    }
    
    public byte[] calculateIntegrity(final byte[] data, final byte[] key, final KeyUsage usage) {
        final CRC32 crc32 = new CRC32();
        crc32.update(data);
        return this.int2octet((int)crc32.getValue());
    }
    
    private byte[] int2octet(final int value) {
        final byte[] bytes = new byte[4];
        for (int i = 0, shift = 24; i < 4; ++i, shift -= 8) {
            bytes[i] = (byte)(0xFF & value >> shift);
        }
        return bytes;
    }
    
    public byte[] getDecryptedData(final EncryptionKey key, final EncryptedData data, final KeyUsage usage) throws KerberosException {
        final byte[] decryptedData = this.decrypt(data.getCipher(), key.getKeyValue());
        final byte[] oldChecksum = new byte[this.getChecksumLength()];
        System.arraycopy(decryptedData, this.getConfounderLength(), oldChecksum, 0, oldChecksum.length);
        for (int i = this.getConfounderLength(); i < this.getConfounderLength() + this.getChecksumLength(); ++i) {
            decryptedData[i] = 0;
        }
        final byte[] newChecksum = this.calculateIntegrity(decryptedData, key.getKeyValue(), usage);
        if (!Arrays.equals(oldChecksum, newChecksum)) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BAD_INTEGRITY);
        }
        return this.removeLeadingBytes(decryptedData, this.getConfounderLength(), this.getChecksumLength());
    }
    
    public EncryptedData getEncryptedData(final EncryptionKey key, final byte[] plainText, final KeyUsage usage) {
        final byte[] conFounder = this.getRandomBytes(this.getConfounderLength());
        final byte[] zeroedChecksum = new byte[this.getChecksumLength()];
        final byte[] dataBytes = this.concatenateBytes(conFounder, this.concatenateBytes(zeroedChecksum, plainText));
        final byte[] paddedDataBytes = this.padString(dataBytes);
        final byte[] checksumBytes = this.calculateIntegrity(paddedDataBytes, null, usage);
        for (int i = this.getConfounderLength(); i < this.getConfounderLength() + this.getChecksumLength(); ++i) {
            paddedDataBytes[i] = checksumBytes[i - this.getConfounderLength()];
        }
        final byte[] encryptedData = this.encrypt(paddedDataBytes, key.getKeyValue());
        return new EncryptedData(this.getEncryptionType(), key.getKeyVersion(), encryptedData);
    }
    
    public byte[] encrypt(final byte[] plainText, final byte[] keyBytes) {
        return this.processCipher(true, plainText, keyBytes);
    }
    
    public byte[] decrypt(final byte[] cipherText, final byte[] keyBytes) {
        return this.processCipher(false, cipherText, keyBytes);
    }
    
    private byte[] processCipher(final boolean isEncrypt, final byte[] data, final byte[] keyBytes) {
        try {
            final Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
            final SecretKey key = new SecretKeySpec(keyBytes, "DES");
            final AlgorithmParameterSpec paramSpec = new IvParameterSpec(DesCbcCrcEncryption.iv);
            if (isEncrypt) {
                cipher.init(1, key, paramSpec);
            }
            else {
                cipher.init(2, key, paramSpec);
            }
            return cipher.doFinal(data);
        }
        catch (GeneralSecurityException nsae) {
            nsae.printStackTrace();
            return null;
        }
    }
    
    static {
        iv = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
    }
}
