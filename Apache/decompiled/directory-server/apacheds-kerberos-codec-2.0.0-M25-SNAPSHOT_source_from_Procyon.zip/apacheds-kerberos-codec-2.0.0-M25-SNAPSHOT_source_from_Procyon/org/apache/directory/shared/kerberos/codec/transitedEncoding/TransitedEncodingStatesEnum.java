// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.transitedEncoding;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum TransitedEncodingStatesEnum implements States
{
    START_STATE, 
    TRANSITED_ENCODING_SEQ_STATE, 
    TRANSITED_ENCODING_TR_TYPE_TAG_STATE, 
    TRANSITED_ENCODING_TR_TYPE_STATE, 
    TRANSITED_ENCODING_CONTENTS_TAG_STATE, 
    TRANSITED_ENCODING_CONTENTS_STATE, 
    LAST_TRANSITED_ENCODING_STATE;
    
    public String getGrammarName(final int grammar) {
        return "TRANSITED_ENCODING_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<TransitedEncodingContainer> grammar) {
        if (grammar instanceof TransitedEncodingGrammar) {
            return "TRANSITED_ENCODING_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == TransitedEncodingStatesEnum.LAST_TRANSITED_ENCODING_STATE.ordinal()) ? "TRANSITED_ENCODING_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == TransitedEncodingStatesEnum.LAST_TRANSITED_ENCODING_STATE;
    }
    
    public TransitedEncodingStatesEnum getStartState() {
        return TransitedEncodingStatesEnum.START_STATE;
    }
}
