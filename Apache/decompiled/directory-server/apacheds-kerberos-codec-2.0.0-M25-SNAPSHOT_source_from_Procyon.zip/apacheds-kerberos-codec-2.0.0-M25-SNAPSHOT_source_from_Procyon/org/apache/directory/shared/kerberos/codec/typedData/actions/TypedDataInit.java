// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.typedData.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.TypedData;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.typedData.TypedDataContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class TypedDataInit extends GrammarAction<TypedDataContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public TypedDataInit() {
        super("Creates a TypedData instance");
    }
    
    public void action(final TypedDataContainer typedDataContainer) throws DecoderException {
        final TLV tlv = typedDataContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            TypedDataInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        if (typedDataContainer.getTypedData() == null) {
            final TypedData typedData = new TypedData();
            typedDataContainer.setTypedData(typedData);
            if (TypedDataInit.IS_DEBUG) {
                TypedDataInit.LOG.debug("TypedData created");
            }
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)TypedDataInit.class);
        IS_DEBUG = TypedDataInit.LOG.isDebugEnabled();
    }
}
