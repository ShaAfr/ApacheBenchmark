// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StoreRealm extends AbstractReadRealm<KdcReqBodyContainer>
{
    public StoreRealm() {
        super("Stores the Realm");
    }
    
    @Override
    protected void setRealm(final String srealm, final KdcReqBodyContainer kdcReqBodyContainer) {
        kdcReqBodyContainer.getKdcReqBody().setRealm(srealm);
    }
}
