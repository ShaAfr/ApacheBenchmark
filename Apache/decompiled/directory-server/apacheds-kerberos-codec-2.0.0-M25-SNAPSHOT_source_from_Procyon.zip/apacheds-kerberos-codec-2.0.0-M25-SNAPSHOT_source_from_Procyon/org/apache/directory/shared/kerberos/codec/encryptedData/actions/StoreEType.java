// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptedData.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encryptedData.EncryptedDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreEType extends AbstractReadInteger<EncryptedDataContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreEType() {
        super("EncryptedPart Etype");
    }
    
    protected void setIntegerValue(final int value, final EncryptedDataContainer encryptedDataContainer) {
        final EncryptionType encryptionType = EncryptionType.getTypeByValue(value);
        final EncryptedData encryptedData = encryptedDataContainer.getEncryptedData();
        encryptedData.setEType(encryptionType);
        if (StoreEType.IS_DEBUG) {
            StoreEType.LOG.debug("e-type : {}", (Object)encryptionType);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreEType.class);
        IS_DEBUG = StoreEType.LOG.isDebugEnabled();
    }
}
