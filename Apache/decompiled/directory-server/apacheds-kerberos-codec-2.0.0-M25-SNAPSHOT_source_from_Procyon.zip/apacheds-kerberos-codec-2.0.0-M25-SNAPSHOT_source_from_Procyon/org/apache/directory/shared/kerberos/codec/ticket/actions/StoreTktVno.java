// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.ticket.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.ticket.TicketContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreTktVno extends AbstractReadInteger<TicketContainer>
{
    public StoreTktVno() {
        super("Kerberos Ticket tktvno value", 5, 5);
    }
    
    protected void setIntegerValue(final int value, final TicketContainer ticketContainer) {
        ticketContainer.getTicket().setTktVno(value);
    }
}
