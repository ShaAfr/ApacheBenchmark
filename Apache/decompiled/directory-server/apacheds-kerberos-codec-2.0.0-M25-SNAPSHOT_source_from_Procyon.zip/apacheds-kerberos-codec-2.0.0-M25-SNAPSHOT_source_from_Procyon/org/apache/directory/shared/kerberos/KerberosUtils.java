// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos;

import java.util.HashSet;
import java.util.LinkedHashMap;
import org.apache.directory.shared.kerberos.components.EncTicketPart;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.shared.kerberos.codec.KerberosDecoder;
import org.apache.directory.shared.kerberos.messages.Authenticator;
import org.apache.directory.server.kerberos.shared.crypto.encryption.KeyUsage;
import org.apache.directory.server.kerberos.shared.crypto.encryption.CipherTextHandler;
import java.net.InetAddress;
import org.apache.directory.server.kerberos.shared.replay.ReplayCache;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.shared.kerberos.messages.ApReq;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.server.kerberos.shared.store.PrincipalStoreEntry;
import org.apache.directory.shared.kerberos.exceptions.ErrorType;
import org.apache.directory.server.kerberos.shared.store.PrincipalStore;
import java.util.LinkedHashSet;
import java.util.Iterator;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.server.i18n.I18n;
import java.util.ArrayList;
import java.text.ParseException;
import org.apache.directory.api.util.Strings;
import javax.security.auth.kerberos.KerberosPrincipal;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.Map;
import java.util.List;

public class KerberosUtils
{
    public static final int NULL = -1;
    public static final List<String> EMPTY_PRINCIPAL_NAME;
    private static final Map<String, String> cipherAlgoMap;
    public static final TimeZone UTC_TIME_ZONE;
    public static final SimpleDateFormat UTC_DATE_FORMAT;
    private static final Set<EncryptionType> oldEncTypes;
    
    public static List<String> getNames(final KerberosPrincipal principal) throws ParseException {
        if (principal == null) {
            return KerberosUtils.EMPTY_PRINCIPAL_NAME;
        }
        final String names = principal.getName();
        if (Strings.isEmpty(names)) {
            return KerberosUtils.EMPTY_PRINCIPAL_NAME;
        }
        return getNames(names);
    }
    
    public static List<String> getNames(final String principalNames) throws ParseException {
        if (principalNames == null) {
            return KerberosUtils.EMPTY_PRINCIPAL_NAME;
        }
        final List<String> nameComponents = new ArrayList<String>();
        final char[] chars = principalNames.toCharArray();
        boolean escaped = false;
        boolean done = false;
        int start = 0;
        int pos = 0;
        int i = 0;
        while (i < chars.length) {
            pos = i;
            switch (chars[i]) {
                case '\\': {
                    escaped = !escaped;
                    break;
                }
                case '/': {
                    if (escaped) {
                        escaped = false;
                        break;
                    }
                    if (i - start > 0) {
                        final String nameComponent = new String(chars, start, i - start);
                        nameComponents.add(nameComponent);
                        start = i + 1;
                        break;
                    }
                    throw new ParseException(I18n.err(I18n.ERR_628, new Object[0]), i);
                }
                case '@': {
                    if (escaped) {
                        escaped = false;
                        break;
                    }
                    done = true;
                    break;
                }
            }
            if (done) {
                if (i - start > 0) {
                    final String nameComponent = new String(chars, start, i - start);
                    nameComponents.add(nameComponent);
                    start = i + 1;
                    break;
                }
                throw new ParseException(I18n.err(I18n.ERR_628, new Object[0]), i);
            }
            else {
                if (i + 1 == chars.length) {
                    final String nameComponent = new String(chars, start, i - start + 1);
                    nameComponents.add(nameComponent);
                    break;
                }
                ++i;
            }
        }
        if (escaped) {
            throw new ParseException(I18n.err(I18n.ERR_629, new Object[0]), pos);
        }
        return nameComponents;
    }
    
    public static KerberosPrincipal getKerberosPrincipal(final PrincipalName principal, final String realm) {
        String name = principal.getNameString();
        if (!Strings.isEmpty(realm)) {
            name = name + '@' + realm;
        }
        return new KerberosPrincipal(name, principal.getNameType().getValue());
    }
    
    public static EncryptionType getBestEncryptionType(final Set<EncryptionType> requestedTypes, final Set<EncryptionType> configuredTypes) {
        for (final EncryptionType encryptionType : configuredTypes) {
            if (requestedTypes.contains(encryptionType)) {
                return encryptionType;
            }
        }
        return null;
    }
    
    public static String getEncryptionTypesString(final Set<EncryptionType> encryptionTypes) {
        final StringBuilder sb = new StringBuilder();
        boolean isFirst = true;
        for (final EncryptionType etype : encryptionTypes) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sb.append(", ");
            }
            sb.append(etype);
        }
        return sb.toString();
    }
    
    public static boolean isKerberosString(final byte[] value) {
        if (value == null) {
            return false;
        }
        for (final byte b : value) {
            if (b < 32 || b > 126) {
                return false;
            }
        }
        return true;
    }
    
    public static String getAlgoNameFromEncType(final EncryptionType encType) {
        final String cipherName = Strings.toLowerCaseAscii(encType.getName());
        for (final String c : KerberosUtils.cipherAlgoMap.keySet()) {
            if (cipherName.startsWith(c)) {
                return KerberosUtils.cipherAlgoMap.get(c);
            }
        }
        throw new IllegalArgumentException("Unknown algorithm name for the encryption type " + encType);
    }
    
    public static Set<EncryptionType> orderEtypesByStrength(final Set<EncryptionType> etypes) {
        final Set<EncryptionType> ordered = new LinkedHashSet<EncryptionType>(etypes.size());
        for (final String algo : KerberosUtils.cipherAlgoMap.values()) {
            for (final EncryptionType encType : etypes) {
                final String foundAlgo = getAlgoNameFromEncType(encType);
                if (algo.equals(foundAlgo)) {
                    ordered.add(encType);
                }
            }
        }
        return ordered;
    }
    
    public static PrincipalStoreEntry getEntry(final KerberosPrincipal principal, final PrincipalStore store, final ErrorType errorType) throws KerberosException {
        PrincipalStoreEntry entry = null;
        try {
            entry = store.getPrincipal(principal);
        }
        catch (Exception e) {
            throw new KerberosException(errorType, e);
        }
        if (entry == null) {
            throw new KerberosException(errorType);
        }
        if (entry.getKeyMap() == null || entry.getKeyMap().isEmpty()) {
            throw new KerberosException(ErrorType.KDC_ERR_NULL_KEY);
        }
        return entry;
    }
    
    public static Authenticator verifyAuthHeader(final ApReq authHeader, final Ticket ticket, final EncryptionKey serverKey, final long clockSkew, final ReplayCache replayCache, final boolean emptyAddressesAllowed, final InetAddress clientAddress, final CipherTextHandler lockBox, final KeyUsage authenticatorKeyUsage, final boolean isValidate) throws KerberosException {
        if (authHeader.getProtocolVersionNumber() != 5) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BADVERSION);
        }
        if (authHeader.getMessageType() != KerberosMessageType.AP_REQ) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_MSG_TYPE);
        }
        if (authHeader.getTicket().getTktVno() != 5) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BADVERSION);
        }
        EncryptionKey ticketKey = null;
        if (authHeader.getOption(1)) {
            ticketKey = authHeader.getTicket().getEncTicketPart().getKey();
        }
        else {
            ticketKey = serverKey;
        }
        if (ticketKey == null) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_NOKEY);
        }
        final byte[] encTicketPartData = lockBox.decrypt(ticketKey, ticket.getEncPart(), KeyUsage.AS_OR_TGS_REP_TICKET_WITH_SRVKEY);
        final EncTicketPart encPart = KerberosDecoder.decodeEncTicketPart(encTicketPartData);
        ticket.setEncTicketPart(encPart);
        final byte[] authenticatorData = lockBox.decrypt(ticket.getEncTicketPart().getKey(), authHeader.getAuthenticator(), authenticatorKeyUsage);
        final Authenticator authenticator = KerberosDecoder.decodeAuthenticator(authenticatorData);
        if (!authenticator.getCName().getNameString().equals(ticket.getEncTicketPart().getCName().getNameString())) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BADMATCH);
        }
        if (ticket.getEncTicketPart().getClientAddresses() != null) {
            if (!ticket.getEncTicketPart().getClientAddresses().contains(new HostAddress(clientAddress))) {
                throw new KerberosException(ErrorType.KRB_AP_ERR_BADADDR);
            }
        }
        else if (!emptyAddressesAllowed) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_BADADDR);
        }
        final KerberosPrincipal serverPrincipal = getKerberosPrincipal(ticket.getSName(), ticket.getRealm());
        final KerberosPrincipal clientPrincipal = getKerberosPrincipal(authenticator.getCName(), authenticator.getCRealm());
        final KerberosTime clientTime = authenticator.getCtime();
        final int clientMicroSeconds = authenticator.getCusec();
        if (replayCache != null) {
            if (replayCache.isReplay(serverPrincipal, clientPrincipal, clientTime, clientMicroSeconds)) {
                throw new KerberosException(ErrorType.KRB_AP_ERR_REPEAT);
            }
            replayCache.save(serverPrincipal, clientPrincipal, clientTime, clientMicroSeconds);
        }
        if (!authenticator.getCtime().isInClockSkew(clockSkew)) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_SKEW);
        }
        final KerberosTime startTime = (ticket.getEncTicketPart().getStartTime() != null) ? ticket.getEncTicketPart().getStartTime() : ticket.getEncTicketPart().getAuthTime();
        final KerberosTime now = new KerberosTime();
        final boolean isValidStartTime = startTime.lessThan(now);
        if (!isValidStartTime || (ticket.getEncTicketPart().getFlags().isInvalid() && !isValidate)) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_TKT_NYV);
        }
        if (!ticket.getEncTicketPart().getEndTime().greaterThan(now)) {
            throw new KerberosException(ErrorType.KRB_AP_ERR_TKT_EXPIRED);
        }
        authHeader.getApOptions().set(2);
        return authenticator;
    }
    
    public static boolean isNewEncryptionType(final EncryptionType eType) {
        return !KerberosUtils.oldEncTypes.contains(eType);
    }
    
    static {
        EMPTY_PRINCIPAL_NAME = new ArrayList<String>();
        cipherAlgoMap = new LinkedHashMap<String, String>();
        UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
        UTC_DATE_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss'Z'");
        oldEncTypes = new HashSet<EncryptionType>();
        KerberosUtils.UTC_DATE_FORMAT.setTimeZone(KerberosUtils.UTC_TIME_ZONE);
        KerberosUtils.cipherAlgoMap.put("rc4", "ArcFourHmac");
        KerberosUtils.cipherAlgoMap.put("aes256", "AES256");
        KerberosUtils.cipherAlgoMap.put("aes128", "AES128");
        KerberosUtils.cipherAlgoMap.put("des3", "DESede");
        KerberosUtils.cipherAlgoMap.put("des", "DES");
        KerberosUtils.oldEncTypes.add(EncryptionType.DES_CBC_CRC);
        KerberosUtils.oldEncTypes.add(EncryptionType.DES_CBC_MD4);
        KerberosUtils.oldEncTypes.add(EncryptionType.DES_CBC_MD5);
        KerberosUtils.oldEncTypes.add(EncryptionType.DES_EDE3_CBC_ENV_OID);
        KerberosUtils.oldEncTypes.add(EncryptionType.DES3_CBC_MD5);
        KerberosUtils.oldEncTypes.add(EncryptionType.DES3_CBC_SHA1);
        KerberosUtils.oldEncTypes.add(EncryptionType.DES3_CBC_SHA1_KD);
        KerberosUtils.oldEncTypes.add(EncryptionType.DSAWITHSHA1_CMSOID);
        KerberosUtils.oldEncTypes.add(EncryptionType.MD5WITHRSAENCRYPTION_CMSOID);
        KerberosUtils.oldEncTypes.add(EncryptionType.SHA1WITHRSAENCRYPTION_CMSOID);
        KerberosUtils.oldEncTypes.add(EncryptionType.RC2CBC_ENVOID);
        KerberosUtils.oldEncTypes.add(EncryptionType.RSAENCRYPTION_ENVOID);
        KerberosUtils.oldEncTypes.add(EncryptionType.RSAES_OAEP_ENV_OID);
        KerberosUtils.oldEncTypes.add(EncryptionType.RC4_HMAC);
    }
}
