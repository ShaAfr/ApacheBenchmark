// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.exceptions;

public class InvalidTicketException extends KerberosException
{
    static final long serialVersionUID = 1L;
    
    public InvalidTicketException(final ErrorType errorType) {
        super(errorType);
    }
    
    public InvalidTicketException(final ErrorType errorType, final String explanation) {
        super(errorType, explanation);
    }
}
