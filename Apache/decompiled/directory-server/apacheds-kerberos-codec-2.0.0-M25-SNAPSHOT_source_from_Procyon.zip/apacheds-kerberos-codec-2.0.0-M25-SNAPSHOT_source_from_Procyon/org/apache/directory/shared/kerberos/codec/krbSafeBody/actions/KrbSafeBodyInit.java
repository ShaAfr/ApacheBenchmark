// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbSafeBody.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.KrbSafeBody;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.krbSafeBody.KrbSafeBodyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class KrbSafeBodyInit extends GrammarAction<KrbSafeBodyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public KrbSafeBodyInit() {
        super("Creates a KrbSafeBody instance");
    }
    
    public void action(final KrbSafeBodyContainer krbSafeBodyContainer) throws DecoderException {
        final TLV tlv = krbSafeBodyContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            KrbSafeBodyInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final KrbSafeBody krbSafeBody = new KrbSafeBody();
        krbSafeBodyContainer.setKrbSafeBody(krbSafeBody);
        if (KrbSafeBodyInit.IS_DEBUG) {
            KrbSafeBodyInit.LOG.debug("KrbSafeBody created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KrbSafeBodyInit.class);
        IS_DEBUG = KrbSafeBodyInit.LOG.isDebugEnabled();
    }
}
