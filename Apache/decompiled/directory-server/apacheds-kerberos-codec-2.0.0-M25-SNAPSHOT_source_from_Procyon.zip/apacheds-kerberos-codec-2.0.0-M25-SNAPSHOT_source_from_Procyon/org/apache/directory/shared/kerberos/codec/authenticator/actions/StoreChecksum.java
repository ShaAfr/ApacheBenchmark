// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authenticator.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.Checksum;
import org.apache.directory.shared.kerberos.codec.authenticator.AuthenticatorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadCheckSum;

public class StoreChecksum extends AbstractReadCheckSum<AuthenticatorContainer>
{
    public StoreChecksum() {
        super("Authenticator cksum");
    }
    
    @Override
    protected void setChecksum(final Checksum checksum, final AuthenticatorContainer authenticatorContainer) {
        authenticatorContainer.getAuthenticator().setCksum(checksum);
    }
}
