// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos;

public enum KerberosMessageType
{
    TICKET(1, "ticket"), 
    AUTHENTICATOR(2, "Authenticator"), 
    ENC_TICKET_PART(3, "EncTicketPart"), 
    AS_REQ(10, "initial authentication request"), 
    AS_REP(11, "initial authentication response"), 
    TGS_REQ(12, "request for authentication based on TGT"), 
    TGS_REP(13, "response to authentication based on TGT"), 
    AP_REQ(14, "application request"), 
    AP_REP(15, "application response"), 
    KRB_SAFE(20, "safe (checksummed) application message"), 
    KRB_PRIV(21, "private (encrypted) application message"), 
    KRB_CRED(22, "private (encrypted) message to forward credentials"), 
    ENC_AS_REP_PART(25, "encrypted authentication reply part"), 
    ENC_TGS_REP_PART(26, "encrypted TGT reply part"), 
    ENC_AP_REP_PART(27, "encrypted application reply part"), 
    ENC_PRIV_PART(28, "encrypted private message part"), 
    KRB_ERROR(30, "error response");
    
    private int value;
    private String message;
    
    private KerberosMessageType(final int value, final String message) {
        this.value = value;
        this.message = message;
    }
    
    public int getValue() {
        return this.value;
    }
    
    public String getMessage() {
        return this.message;
    }
    
    public static KerberosMessageType getTypeByValue(final int value) {
        switch (value) {
            case 1: {
                return KerberosMessageType.TICKET;
            }
            case 2: {
                return KerberosMessageType.AUTHENTICATOR;
            }
            case 3: {
                return KerberosMessageType.ENC_TICKET_PART;
            }
            case 10: {
                return KerberosMessageType.AS_REQ;
            }
            case 11: {
                return KerberosMessageType.AS_REP;
            }
            case 12: {
                return KerberosMessageType.TGS_REQ;
            }
            case 13: {
                return KerberosMessageType.TGS_REP;
            }
            case 14: {
                return KerberosMessageType.AP_REQ;
            }
            case 15: {
                return KerberosMessageType.AP_REP;
            }
            case 20: {
                return KerberosMessageType.KRB_SAFE;
            }
            case 21: {
                return KerberosMessageType.KRB_PRIV;
            }
            case 22: {
                return KerberosMessageType.KRB_CRED;
            }
            case 27: {
                return KerberosMessageType.ENC_AP_REP_PART;
            }
            case 28: {
                return KerberosMessageType.ENC_PRIV_PART;
            }
            case 30: {
                return KerberosMessageType.KRB_ERROR;
            }
            default: {
                return null;
            }
        }
    }
}
