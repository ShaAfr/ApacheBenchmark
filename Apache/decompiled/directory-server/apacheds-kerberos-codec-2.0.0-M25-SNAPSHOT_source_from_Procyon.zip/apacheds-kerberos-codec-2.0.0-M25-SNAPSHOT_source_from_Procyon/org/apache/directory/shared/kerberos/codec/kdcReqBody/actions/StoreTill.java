// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.shared.kerberos.components.KdcReqBody;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.api.util.Strings;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreTill extends GrammarAction<KdcReqBodyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreTill() {
        super("Stores the Till");
    }
    
    public void action(final KdcReqBodyContainer kdcReqBodyContainer) throws DecoderException {
        final TLV tlv = kdcReqBodyContainer.getCurrentTLV();
        if (tlv.getLength() != 15) {
            StoreTill.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final KdcReqBody kdcReqBody = kdcReqBodyContainer.getKdcReqBody();
        final BerValue value = tlv.getValue();
        final String date = Strings.utf8ToString(value.getData());
        try {
            final KerberosTime till = new KerberosTime(date);
            kdcReqBody.setTill(till);
            if (StoreTill.IS_DEBUG) {
                StoreTill.LOG.debug("Till : {}", (Object)till);
            }
        }
        catch (IllegalArgumentException iae) {
            StoreTill.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreTill.class);
        IS_DEBUG = StoreTill.LOG.isDebugEnabled();
    }
}
