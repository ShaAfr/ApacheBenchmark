// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbCredInfo;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreCaddr;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreSName;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreSRealm;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreRenewtill;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreEndTime;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreStartTime;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreAuthTime;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreFlags;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StorePName;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StorePRealm;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.StoreKey;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.krbCredInfo.actions.KrbCredInfoInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class KrbCredInfoGrammar extends AbstractGrammar<KrbCredInfoContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<KrbCredInfoContainer> instance;
    
    private KrbCredInfoGrammar() {
        this.setName(KrbCredInfoGrammar.class.getName());
        super.transitions = new GrammarTransition[KrbCredInfoStatesEnum.LAST_KRB_CRED_INFO_STATE.ordinal()][256];
        super.transitions[KrbCredInfoStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.START_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SEQ_TAG_STATE, UniversalTag.SEQUENCE, (Action)new KrbCredInfoInit());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_SEQ_TAG_STATE.ordinal()][160] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SEQ_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, 160, (Action)new StoreKey());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][161] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, UniversalTag.GENERAL_STRING, (Action)new StorePRealm());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][162] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, 162, (Action)new StorePName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][163] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_TAG_STATE.ordinal()][UniversalTag.BIT_STRING.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, UniversalTag.BIT_STRING, (Action)new StoreFlags());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE.ordinal()][164] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_TAG_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreAuthTime());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE.ordinal()][165] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_TAG_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreStartTime());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE.ordinal()][166] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreEndTime());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE.ordinal()][167] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE.ordinal()][UniversalTag.GENERALIZED_TIME.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_STATE, UniversalTag.GENERALIZED_TIME, (Action)new StoreRenewtill());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreSRealm());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][162] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, 162, (Action)new StorePName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][163] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][164] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_TAG_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][165] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_TAG_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][166] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][167] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_KEY_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][163] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][164] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_TAG_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][165] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_TAG_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][166] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][167] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][164] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_TAG_STATE, 164, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][165] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_TAG_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][166] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][167] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_PNAME_TAG_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE.ordinal()][165] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_TAG_STATE, 165, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE.ordinal()][166] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE.ordinal()][167] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_FLAGS_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE.ordinal()][166] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_TAG_STATE, 166, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE.ordinal()][167] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_AUTHTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE.ordinal()][167] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_TAG_STATE, 167, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_STARTTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE.ordinal()][168] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_TAG_STATE, 168, (Action)new CheckNotNullLength());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_ENDTIME_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_STATE.ordinal()][169] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SNAME_TAG_STATE, 169, (Action)new StoreSName());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_RENEWTILL_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
        super.transitions[KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_STATE.ordinal()][170] = new GrammarTransition((Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_SREALM_STATE, (Enum)KrbCredInfoStatesEnum.KRB_CRED_INFO_CADDR_TAG_STATE, 170, (Action)new StoreCaddr());
    }
    
    public static Grammar<KrbCredInfoContainer> getInstance() {
        return KrbCredInfoGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KrbCredInfoGrammar.class);
        IS_DEBUG = KrbCredInfoGrammar.LOG.isDebugEnabled();
        KrbCredInfoGrammar.instance = (Grammar<KrbCredInfoContainer>)new KrbCredInfoGrammar();
    }
}
