// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.flags;

import org.apache.directory.api.asn1.util.BitString;

public abstract class AbstractKerberosFlags extends BitString
{
    public static final int MAX_SIZE = 32;
    protected int value;
    
    public AbstractKerberosFlags() {
        super(32);
        this.value = 0;
    }
    
    public AbstractKerberosFlags(final int value) {
        super(32);
        this.setData(value);
    }
    
    public void setData(final int value) {
        final byte[] bytes = { 0, (byte)(value >> 24), 0, (byte)(value >> 16 & 0xFF), 0 };
        bytes[3] = (byte)(value >> 8 & 0xFF);
        bytes[4] = (byte)(value & 0xFF);
        super.setData(bytes);
        this.value = value;
    }
    
    public AbstractKerberosFlags(final byte[] flags) {
        super(flags);
        if (flags == null || flags.length != 5) {
            throw new IllegalArgumentException("The given flags is not correct");
        }
        this.value = ((flags[1] & 0xFF) << 24 | (flags[2] & 0xFF) << 16 | (flags[3] & 0xFF) << 8 | (0xFF & flags[4]));
    }
    
    public int getIntValue() {
        return this.value;
    }
    
    public static boolean isFlagSet(final int flags, final int flag) {
        return (flags & 1 << 31 - flag) != 0x0;
    }
    
    public boolean isFlagSet(final KerberosFlag flag) {
        final int mask = 1 << 31 - flag.getValue();
        return (this.value & mask) != 0x0;
    }
    
    public boolean isFlagSet(final int flag) {
        return (this.value & 1 << 31 - flag) != 0x0;
    }
    
    public void setFlag(final KerberosFlag flag) {
        final int pos = 31 - flag.getValue();
        this.setBit(flag.getValue());
        this.value |= 1 << pos;
    }
    
    public void setFlag(final int flag) {
        final int pos = 31 - flag;
        this.setBit(flag);
        this.value |= 1 << pos;
    }
    
    public void clearFlag(final KerberosFlag flag) {
        final int pos = 31 - flag.getValue();
        this.clearBit(flag.getValue());
        this.value &= ~(1 << pos);
    }
    
    public void clearFlag(final int flag) {
        final int pos = 31 - flag;
        this.clearBit(flag);
        this.value &= ~(1 << pos);
    }
    
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + this.value;
        return result;
    }
    
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        final AbstractKerberosFlags other = (AbstractKerberosFlags)obj;
        return this.value == other.value;
    }
}
