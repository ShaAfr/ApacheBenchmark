// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.transitedEncoding;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.transitedEncoding.actions.StoreContents;
import org.apache.directory.shared.kerberos.codec.transitedEncoding.actions.StoreTrType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.transitedEncoding.actions.TransitedEncodingInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class TransitedEncodingGrammar extends AbstractGrammar<TransitedEncodingContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<TransitedEncodingContainer> instance;
    
    private TransitedEncodingGrammar() {
        this.setName(TransitedEncodingGrammar.class.getName());
        super.transitions = new GrammarTransition[TransitedEncodingStatesEnum.LAST_TRANSITED_ENCODING_STATE.ordinal()][256];
        super.transitions[TransitedEncodingStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)TransitedEncodingStatesEnum.START_STATE, (Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new TransitedEncodingInit());
        super.transitions[TransitedEncodingStatesEnum.TRANSITED_ENCODING_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_SEQ_STATE, (Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_TR_TYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[TransitedEncodingStatesEnum.TRANSITED_ENCODING_TR_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_TR_TYPE_TAG_STATE, (Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_TR_TYPE_STATE, UniversalTag.INTEGER, (Action)new StoreTrType());
        super.transitions[TransitedEncodingStatesEnum.TRANSITED_ENCODING_TR_TYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_TR_TYPE_STATE, (Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_CONTENTS_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[TransitedEncodingStatesEnum.TRANSITED_ENCODING_CONTENTS_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.getValue()] = new GrammarTransition((Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_CONTENTS_TAG_STATE, (Enum)TransitedEncodingStatesEnum.TRANSITED_ENCODING_CONTENTS_STATE, UniversalTag.OCTET_STRING, (Action)new StoreContents());
    }
    
    public static Grammar<TransitedEncodingContainer> getInstance() {
        return TransitedEncodingGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)TransitedEncodingGrammar.class);
        IS_DEBUG = TransitedEncodingGrammar.LOG.isDebugEnabled();
        TransitedEncodingGrammar.instance = (Grammar<TransitedEncodingContainer>)new TransitedEncodingGrammar();
    }
}
