// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.changepwd.messages;

import org.apache.directory.api.util.Strings;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswordException;
import org.apache.directory.server.kerberos.changepwd.exceptions.ChangePasswdErrorType;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.shared.kerberos.codec.krbError.KrbErrorContainer;
import org.apache.directory.api.asn1.EncoderException;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.KrbError;

public class ChangePasswordError extends AbstractPasswordMessage
{
    private KrbError krbError;
    private short krbErrorLen;
    private short messageLength;
    
    public ChangePasswordError(final KrbError krbError) {
        this((short)(-128), krbError);
    }
    
    public ChangePasswordError(final short versionNumber, final KrbError krbError) {
        super(versionNumber);
        this.krbError = krbError;
    }
    
    public KrbError getKrbError() {
        return this.krbError;
    }
    
    @Override
    public short computeLength() {
        this.krbErrorLen = (short)this.krbError.computeLength();
        return this.messageLength = (short)(6 + this.krbErrorLen);
    }
    
    @Override
    public ByteBuffer encode(final ByteBuffer buf) throws EncoderException {
        buf.putShort(this.messageLength);
        buf.putShort(this.getVersionNumber());
        buf.putShort((short)0);
        this.krbError.encode(buf);
        return buf;
    }
    
    public static ChangePasswordError decode(final ByteBuffer buf) throws ChangePasswordException {
        final short messageLength = buf.getShort();
        final short pvno = buf.getShort();
        buf.getShort();
        final int errorLength = messageLength - 6;
        final byte[] errorBytes = new byte[errorLength];
        buf.get(errorBytes);
        final ByteBuffer errorBuffer = ByteBuffer.wrap(errorBytes);
        final KrbErrorContainer container = new KrbErrorContainer(errorBuffer);
        final Asn1Decoder decoder = new Asn1Decoder();
        try {
            decoder.decode(errorBuffer, (Asn1Container)container);
        }
        catch (DecoderException e) {
            throw new ChangePasswordException(ChangePasswdErrorType.KRB5_KPASSWD_MALFORMED, (Throwable)e);
        }
        final KrbError errorMessage = container.getKrbError();
        return new ChangePasswordError(pvno, errorMessage);
    }
    
    public ChangePasswdErrorType getResultCode() {
        final ByteBuffer buf = ByteBuffer.wrap(this.krbError.getEData());
        return ChangePasswdErrorType.getTypeByValue(buf.getShort());
    }
    
    public String getResultString() {
        final byte[] edata = this.krbError.getEData();
        return Strings.utf8ToString(edata, 2, edata.length - 2);
    }
}
