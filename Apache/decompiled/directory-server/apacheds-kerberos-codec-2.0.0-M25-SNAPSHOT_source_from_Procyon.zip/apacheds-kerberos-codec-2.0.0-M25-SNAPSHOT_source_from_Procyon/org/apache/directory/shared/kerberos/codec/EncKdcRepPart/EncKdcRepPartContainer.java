// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.EncKdcRepPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.components.EncKdcRepPart;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncKdcRepPartContainer extends AbstractContainer
{
    private EncKdcRepPart encKdcRepPart;
    
    public EncKdcRepPartContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)EncKdcRepPartGrammar.getInstance());
        this.setTransition((Enum)EncKdcRepPartStatesEnum.START_STATE);
    }
    
    public EncKdcRepPart getEncKdcRepPart() {
        return this.encKdcRepPart;
    }
    
    public void setEncKdcRepPart(final EncKdcRepPart encKdcRepPart) {
        this.encKdcRepPart = encKdcRepPart;
    }
}
