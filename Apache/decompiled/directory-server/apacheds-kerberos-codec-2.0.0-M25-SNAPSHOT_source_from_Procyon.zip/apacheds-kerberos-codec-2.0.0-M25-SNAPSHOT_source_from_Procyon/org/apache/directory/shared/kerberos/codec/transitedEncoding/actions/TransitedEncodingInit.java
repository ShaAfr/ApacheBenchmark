// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.transitedEncoding.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.TransitedEncoding;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.transitedEncoding.TransitedEncodingContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class TransitedEncodingInit extends GrammarAction<TransitedEncodingContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public TransitedEncodingInit() {
        super("Creates a TransitedEncoding instance");
    }
    
    public void action(final TransitedEncodingContainer transitedEncodingContainer) throws DecoderException {
        final TLV tlv = transitedEncodingContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            TransitedEncodingInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final TransitedEncoding transitedEncoding = new TransitedEncoding();
        transitedEncodingContainer.setTransitedEncoding(transitedEncoding);
        if (TransitedEncodingInit.IS_DEBUG) {
            TransitedEncodingInit.LOG.debug("TransitedEncoding created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)TransitedEncodingInit.class);
        IS_DEBUG = TransitedEncodingInit.LOG.isDebugEnabled();
    }
}
