// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbPrivPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.shared.kerberos.codec.encKrbPrivPart.EncKrbPrivPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadHostAddress;

public class StoreSenderAddress extends AbstractReadHostAddress<EncKrbPrivPartContainer>
{
    public StoreSenderAddress() {
        super("EncKrbPrivPart s-address");
    }
    
    @Override
    protected void setAddress(final HostAddress hostAddress, final EncKrbPrivPartContainer encKrbPrivPartContainer) {
        encKrbPrivPartContainer.getEncKrbPrivPart().setSenderAddress(hostAddress);
        encKrbPrivPartContainer.setGrammarEndAllowed(true);
    }
}
