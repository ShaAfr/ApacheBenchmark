// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptedPart;

public class StoreEncAuthorizationData extends AbstractReadEncryptedPart<KdcReqBodyContainer>
{
    public StoreEncAuthorizationData() {
        super("KDC-REQ-BODY enc-authorization-data");
    }
    
    @Override
    protected void setEncryptedData(final EncryptedData encryptedData, final KdcReqBodyContainer kdcReqBodyContainer) {
        kdcReqBodyContainer.getKdcReqBody().setEncAuthorizationData(encryptedData);
        kdcReqBodyContainer.setGrammarEndAllowed(true);
    }
}
