// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcRep;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.kdcRep.actions.StoreEncPart;
import org.apache.directory.shared.kerberos.codec.kdcRep.actions.StoreTicket;
import org.apache.directory.shared.kerberos.codec.kdcRep.actions.StoreCName;
import org.apache.directory.shared.kerberos.codec.kdcRep.actions.StoreCRealm;
import org.apache.directory.shared.kerberos.codec.kdcRep.actions.AddPaData;
import org.apache.directory.shared.kerberos.codec.kdcRep.actions.CheckMsgType;
import org.apache.directory.shared.kerberos.codec.kdcRep.actions.StorePvno;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class KdcRepGrammar extends AbstractGrammar<KdcRepContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<KdcRepContainer> instance;
    
    private KdcRepGrammar() {
        this.setName(KdcRepGrammar.class.getName());
        super.transitions = new GrammarTransition[KdcRepStatesEnum.LAST_KDC_REP_STATE.ordinal()][256];
        super.transitions[KdcRepStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcRepStatesEnum.START_STATE, (Enum)KdcRepStatesEnum.KDC_REP_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KdcRepStatesEnum.KDC_REP_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_SEQ_STATE, (Enum)KdcRepStatesEnum.KDC_REP_PVNO_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[KdcRepStatesEnum.KDC_REP_PVNO_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_PVNO_TAG_STATE, (Enum)KdcRepStatesEnum.KDC_REP_PVNO_STATE, UniversalTag.INTEGER, (Action)new StorePvno());
        super.transitions[KdcRepStatesEnum.KDC_REP_PVNO_STATE.ordinal()][161] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_PVNO_STATE, (Enum)KdcRepStatesEnum.KDC_REP_MSG_TYPE_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[KdcRepStatesEnum.KDC_REP_MSG_TYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_MSG_TYPE_TAG_STATE, (Enum)KdcRepStatesEnum.KDC_REP_MSG_TYPE_STATE, UniversalTag.INTEGER, (Action)new CheckMsgType());
        super.transitions[KdcRepStatesEnum.KDC_REP_MSG_TYPE_STATE.ordinal()][162] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_MSG_TYPE_STATE, (Enum)KdcRepStatesEnum.KDC_REP_PA_DATA_TAG_STATE, 162, (Action)new CheckNotNullLength());
        super.transitions[KdcRepStatesEnum.KDC_REP_PA_DATA_TAG_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_PA_DATA_TAG_STATE, (Enum)KdcRepStatesEnum.KDC_REP_PA_DATA_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[KdcRepStatesEnum.KDC_REP_PA_DATA_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_PA_DATA_STATE, (Enum)KdcRepStatesEnum.KDC_REP_PA_DATA_STATE, UniversalTag.SEQUENCE, (Action)new AddPaData());
        super.transitions[KdcRepStatesEnum.KDC_REP_PA_DATA_STATE.ordinal()][163] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_PA_DATA_STATE, (Enum)KdcRepStatesEnum.KDC_REP_CREALM_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[KdcRepStatesEnum.KDC_REP_MSG_TYPE_STATE.ordinal()][163] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_MSG_TYPE_STATE, (Enum)KdcRepStatesEnum.KDC_REP_CREALM_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[KdcRepStatesEnum.KDC_REP_CREALM_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_CREALM_TAG_STATE, (Enum)KdcRepStatesEnum.KDC_REP_CREALM_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreCRealm());
        super.transitions[KdcRepStatesEnum.KDC_REP_CREALM_STATE.ordinal()][164] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_CREALM_STATE, (Enum)KdcRepStatesEnum.KDC_REP_CNAME_STATE, 164, (Action)new StoreCName());
        super.transitions[KdcRepStatesEnum.KDC_REP_CNAME_STATE.ordinal()][165] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_CNAME_STATE, (Enum)KdcRepStatesEnum.KDC_REP_TICKET_STATE, 165, (Action)new StoreTicket());
        super.transitions[KdcRepStatesEnum.KDC_REP_TICKET_STATE.ordinal()][166] = new GrammarTransition((Enum)KdcRepStatesEnum.KDC_REP_TICKET_STATE, (Enum)KdcRepStatesEnum.KDC_REP_ENC_PART_STATE, 166, (Action)new StoreEncPart());
    }
    
    public static Grammar<KdcRepContainer> getInstance() {
        return KdcRepGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KdcRepGrammar.class);
        IS_DEBUG = KdcRepGrammar.LOG.isDebugEnabled();
        KdcRepGrammar.instance = (Grammar<KdcRepContainer>)new KdcRepGrammar();
    }
}
