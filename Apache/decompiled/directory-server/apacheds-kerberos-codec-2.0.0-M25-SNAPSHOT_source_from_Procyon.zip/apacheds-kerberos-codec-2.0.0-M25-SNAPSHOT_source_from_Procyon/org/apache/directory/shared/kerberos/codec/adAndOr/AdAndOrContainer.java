// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adAndOr;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.AdAndOr;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class AdAndOrContainer extends AbstractContainer
{
    private AdAndOr adAndOr;
    
    public AdAndOrContainer() {
        this.adAndOr = new AdAndOr();
        this.setGrammar((Grammar)AdAndOrGrammar.getInstance());
        this.setTransition((Enum)AdAndOrStatesEnum.START_STATE);
    }
    
    public AdAndOr getAdAndOr() {
        return this.adAndOr;
    }
    
    public void setAdAndOr(final AdAndOr adAndOr) {
        this.adAndOr = adAndOr;
    }
}
