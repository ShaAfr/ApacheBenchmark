// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptionKey;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncryptionKeyContainer extends AbstractContainer
{
    private EncryptionKey encryptionKey;
    
    public EncryptionKeyContainer() {
        this.setGrammar((Grammar)EncryptionKeyGrammar.getInstance());
        this.setTransition((Enum)EncryptionKeyStatesEnum.START_STATE);
    }
    
    public EncryptionKey getEncryptionKey() {
        return this.encryptionKey;
    }
    
    public void setEncryptionKey(final EncryptionKey encryptionKey) {
        this.encryptionKey = encryptionKey;
    }
}
