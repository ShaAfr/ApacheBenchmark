// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.util.Strings;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;
import org.apache.directory.api.asn1.ber.Asn1Container;

public abstract class AbstractReadKerberosTime<E extends Asn1Container> extends GrammarAction<E>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AbstractReadKerberosTime(final String name) {
        super(name);
    }
    
    protected abstract void setKerberosTime(final KerberosTime p0, final E p1);
    
    public final void action(final E container) throws DecoderException {
        final TLV tlv = container.getCurrentTLV();
        if (tlv.getLength() != 15) {
            AbstractReadKerberosTime.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final BerValue value = tlv.getValue();
        final String date = Strings.utf8ToString(value.getData());
        try {
            final KerberosTime krbTime = new KerberosTime(date);
            if (AbstractReadKerberosTime.IS_DEBUG) {
                AbstractReadKerberosTime.LOG.debug("decoded kerberos time is : {}", (Object)krbTime);
            }
            this.setKerberosTime(krbTime, container);
        }
        catch (IllegalArgumentException iae) {
            AbstractReadKerberosTime.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AbstractReadKerberosTime.class);
        IS_DEBUG = AbstractReadKerberosTime.LOG.isDebugEnabled();
    }
}
