// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.typedData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.typedData.TypedDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreDataValue extends AbstractReadOctetString<TypedDataContainer>
{
    public StoreDataValue() {
        super("TypedData data-value");
    }
    
    protected void setOctetString(final byte[] data, final TypedDataContainer typedDataContainer) {
        typedDataContainer.getTypedData().setCurrentDataValue(data);
        typedDataContainer.setGrammarEndAllowed(true);
    }
}
