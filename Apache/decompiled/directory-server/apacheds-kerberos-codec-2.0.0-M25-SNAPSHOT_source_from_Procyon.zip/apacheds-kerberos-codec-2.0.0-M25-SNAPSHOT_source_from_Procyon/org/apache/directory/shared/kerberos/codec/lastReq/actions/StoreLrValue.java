// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.lastReq.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.lastReq.LastReqContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreLrValue extends AbstractReadKerberosTime<LastReqContainer>
{
    public StoreLrValue() {
        super("LastReq lr-value");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final LastReqContainer lastReqContainer) {
        lastReqContainer.getLastReq().setCurrentLrValue(krbtime);
        lastReqContainer.setGrammarEndAllowed(true);
    }
}
