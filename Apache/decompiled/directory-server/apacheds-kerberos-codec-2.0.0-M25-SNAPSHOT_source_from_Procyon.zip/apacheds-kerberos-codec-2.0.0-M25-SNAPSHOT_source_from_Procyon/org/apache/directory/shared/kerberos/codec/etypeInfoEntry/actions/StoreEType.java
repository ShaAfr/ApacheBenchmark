// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfoEntry.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.ETypeInfoEntry;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.IntegerDecoderException;
import org.apache.directory.api.util.Strings;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import org.apache.directory.api.asn1.ber.tlv.IntegerDecoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.etypeInfoEntry.ETypeInfoEntryContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreEType extends GrammarAction<ETypeInfoEntryContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreEType() {
        super("ETYPE-INFO-ENTRY etype");
    }
    
    public void action(final ETypeInfoEntryContainer eTypeInfoEntryContainer) throws DecoderException {
        final TLV tlv = eTypeInfoEntryContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            StoreEType.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final BerValue value = tlv.getValue();
        EncryptionType etype = null;
        final ETypeInfoEntry etypeInfoEntry = eTypeInfoEntryContainer.getETypeInfoEntry();
        try {
            final int eType = IntegerDecoder.parse(value);
            etype = EncryptionType.getTypeByValue(eType);
            etypeInfoEntry.setEType(etype);
            if (StoreEType.IS_DEBUG) {
                StoreEType.LOG.debug("etype : " + etype);
            }
            eTypeInfoEntryContainer.setGrammarEndAllowed(true);
        }
        catch (IntegerDecoderException ide) {
            StoreEType.LOG.error(I18n.err(I18n.ERR_04070, new Object[] { Strings.dumpBytes(value.getData()), ide.getLocalizedMessage() }));
            throw new DecoderException(ide.getMessage());
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreEType.class);
        IS_DEBUG = StoreEType.LOG.isDebugEnabled();
    }
}
