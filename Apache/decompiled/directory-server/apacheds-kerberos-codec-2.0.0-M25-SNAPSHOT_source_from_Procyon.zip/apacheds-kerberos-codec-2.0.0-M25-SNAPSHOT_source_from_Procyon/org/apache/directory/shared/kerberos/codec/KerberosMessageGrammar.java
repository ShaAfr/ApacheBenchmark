// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec;

import org.apache.directory.shared.kerberos.messages.KerberosMessage;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.codec.krbError.KrbErrorContainer;
import org.apache.directory.shared.kerberos.codec.krbCred.KrbCredContainer;
import org.apache.directory.shared.kerberos.codec.krbPriv.KrbPrivContainer;
import org.apache.directory.shared.kerberos.codec.krbSafe.KrbSafeContainer;
import org.apache.directory.shared.kerberos.codec.apRep.ApRepContainer;
import org.apache.directory.shared.kerberos.codec.apReq.ApReqContainer;
import org.apache.directory.shared.kerberos.codec.tgsRep.TgsRepContainer;
import org.apache.directory.shared.kerberos.codec.tgsReq.TgsReqContainer;
import org.apache.directory.shared.kerberos.codec.asRep.AsRepContainer;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.asReq.AsReqContainer;
import java.nio.InvalidMarkException;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;
import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class KerberosMessageGrammar extends AbstractGrammar<KerberosMessageContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<KerberosMessageContainer> instance;
    Asn1Decoder kerberosDecoder;
    
    private KerberosMessageGrammar() {
        this.kerberosDecoder = new Asn1Decoder();
        this.setName(KerberosMessageGrammar.class.getName());
        super.transitions = new GrammarTransition[KerberosMessageStatesEnum.LAST_KERBEROS_MESSAGE_STATE.ordinal()][256];
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][106] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.AS_REQ_STATE, 106, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][107] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.AS_REP_TAG_STATE, 107, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][108] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.TGS_REQ_TAG_STATE, 108, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][109] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.TGS_REP_TAG_STATE, 109, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][110] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.AP_REQ_TAG_STATE, 110, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][111] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.AP_REP_TAG_STATE, 111, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][116] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.KRB_SAFE_STATE, 116, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][117] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.KRB_PRIV_STATE, 117, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][118] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.KRB_CRED_STATE, 118, (Action)new DecodeKerberosMessage());
        super.transitions[KerberosMessageStatesEnum.START_STATE.ordinal()][126] = new GrammarTransition((Enum)KerberosMessageStatesEnum.START_STATE, (Enum)KerberosMessageStatesEnum.KRB_ERROR_STATE, 126, (Action)new DecodeKerberosMessage());
    }
    
    public static Grammar<KerberosMessageContainer> getInstance() {
        return KerberosMessageGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)KerberosMessageGrammar.class);
        IS_DEBUG = KerberosMessageGrammar.LOG.isDebugEnabled();
        KerberosMessageGrammar.instance = (Grammar<KerberosMessageContainer>)new KerberosMessageGrammar();
    }
    
    private class DecodeKerberosMessage extends GrammarAction<KerberosMessageContainer>
    {
        public void action(final KerberosMessageContainer kerberosMessageContainer) throws DecoderException {
            final ByteBuffer stream = kerberosMessageContainer.getStream();
            try {
                stream.reset();
            }
            catch (InvalidMarkException ime) {
                stream.rewind();
            }
            final TLV tlv = kerberosMessageContainer.getCurrentTLV();
            kerberosMessageContainer.setGrammarEndAllowed(true);
            switch (tlv.getTag()) {
                case 106: {
                    final AsReqContainer asReqContainer = new AsReqContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)asReqContainer);
                    }
                    catch (DecoderException de) {
                        throw de;
                    }
                    final KerberosMessage asReq = asReqContainer.getAsReq();
                    kerberosMessageContainer.setMessage(asReq);
                    break;
                }
                case 107: {
                    final AsRepContainer asRepContainer = new AsRepContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)asRepContainer);
                    }
                    catch (DecoderException de2) {
                        throw de2;
                    }
                    final KerberosMessage asRep = asRepContainer.getAsRep();
                    kerberosMessageContainer.setMessage(asRep);
                    break;
                }
                case 108: {
                    final TgsReqContainer tgsReqContainer = new TgsReqContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)tgsReqContainer);
                    }
                    catch (DecoderException de3) {
                        throw de3;
                    }
                    final KerberosMessage tgsReq = tgsReqContainer.getTgsReq();
                    kerberosMessageContainer.setMessage(tgsReq);
                    break;
                }
                case 109: {
                    final TgsRepContainer tgsRepContainer = new TgsRepContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)tgsRepContainer);
                    }
                    catch (DecoderException de4) {
                        throw de4;
                    }
                    final KerberosMessage tgsRep = tgsRepContainer.getTgsRep();
                    kerberosMessageContainer.setMessage(tgsRep);
                    break;
                }
                case 110: {
                    final ApReqContainer apReqContainer = new ApReqContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)apReqContainer);
                    }
                    catch (DecoderException de5) {
                        throw de5;
                    }
                    final KerberosMessage apReq = apReqContainer.getApReq();
                    kerberosMessageContainer.setMessage(apReq);
                    break;
                }
                case 111: {
                    final ApRepContainer apRepContainer = new ApRepContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)apRepContainer);
                    }
                    catch (DecoderException de6) {
                        throw de6;
                    }
                    final KerberosMessage apRep = apRepContainer.getApRep();
                    kerberosMessageContainer.setMessage(apRep);
                    break;
                }
                case 116: {
                    final KrbSafeContainer krbSafeContainer = new KrbSafeContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)krbSafeContainer);
                    }
                    catch (DecoderException de7) {
                        throw de7;
                    }
                    final KerberosMessage krbSafe = krbSafeContainer.getKrbSafe();
                    kerberosMessageContainer.setMessage(krbSafe);
                    break;
                }
                case 117: {
                    final KrbPrivContainer krbPrivContainer = new KrbPrivContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)krbPrivContainer);
                    }
                    catch (DecoderException de8) {
                        throw de8;
                    }
                    final KerberosMessage krbPriv = krbPrivContainer.getKrbPriv();
                    kerberosMessageContainer.setMessage(krbPriv);
                    break;
                }
                case 118: {
                    final KrbCredContainer krbCredContainer = new KrbCredContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)krbCredContainer);
                    }
                    catch (DecoderException de9) {
                        throw de9;
                    }
                    final KerberosMessage krbCred = krbCredContainer.getKrbCred();
                    kerberosMessageContainer.setMessage(krbCred);
                    break;
                }
                case 126: {
                    final KrbErrorContainer krbErrorContainer = new KrbErrorContainer(stream);
                    try {
                        KerberosMessageGrammar.this.kerberosDecoder.decode(stream, (Asn1Container)krbErrorContainer);
                    }
                    catch (DecoderException de10) {
                        throw de10;
                    }
                    final KerberosMessage krbError = krbErrorContainer.getKrbError();
                    kerberosMessageContainer.setMessage(krbError);
                    break;
                }
            }
            if (KerberosMessageGrammar.IS_DEBUG) {
                KerberosMessageGrammar.LOG.debug("Decoded KerberosMessage {}", (Object)kerberosMessageContainer.getMessage());
            }
        }
    }
}
