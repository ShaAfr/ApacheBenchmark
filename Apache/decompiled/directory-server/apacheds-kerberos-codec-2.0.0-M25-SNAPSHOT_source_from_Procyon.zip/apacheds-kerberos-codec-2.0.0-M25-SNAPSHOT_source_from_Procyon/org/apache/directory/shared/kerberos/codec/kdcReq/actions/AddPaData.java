// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReq.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.KdcReq;
import org.apache.directory.shared.kerberos.components.PaData;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.padata.PaDataContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.kdcReq.KdcReqContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AddPaData extends GrammarAction<KdcReqContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AddPaData() {
        super("KDC-REQ Add PA-DATA");
    }
    
    public void action(final KdcReqContainer kdcReqContainer) throws DecoderException {
        final TLV tlv = kdcReqContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AddPaData.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder paDataDecoder = new Asn1Decoder();
        final PaDataContainer paDataContainer = new PaDataContainer();
        paDataContainer.setStream(kdcReqContainer.getStream());
        kdcReqContainer.rewind();
        try {
            paDataDecoder.decode(kdcReqContainer.getStream(), (Asn1Container)paDataContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        kdcReqContainer.updateParent();
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        final PaData paData = paDataContainer.getPaData();
        final KdcReq kdcReq = kdcReqContainer.getKdcReq();
        kdcReq.addPaData(paData);
        if (AddPaData.IS_DEBUG) {
            AddPaData.LOG.debug("Added PA-DATA:  {}", (Object)paData);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AddPaData.class);
        IS_DEBUG = AddPaData.LOG.isDebugEnabled();
    }
}
