// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptedData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encryptedData.EncryptedDataContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreCipher extends AbstractReadOctetString<EncryptedDataContainer>
{
    public StoreCipher() {
        super("EncryptedPart cipher");
    }
    
    protected void setOctetString(final byte[] data, final EncryptedDataContainer encryptedDataContainer) {
        encryptedDataContainer.getEncryptedData().setCipher(data);
        encryptedDataContainer.setGrammarEndAllowed(true);
    }
}
