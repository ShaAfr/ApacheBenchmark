// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.codec.authorizationData.AuthorizationDataContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;
import org.apache.directory.api.asn1.ber.Asn1Container;

public abstract class AbstractReadAuthorizationData<E extends Asn1Container> extends GrammarAction<E>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AbstractReadAuthorizationData(final String name) {
        super(name);
    }
    
    protected abstract void setAuthorizationData(final AuthorizationData p0, final E p1);
    
    public final void action(final E container) throws DecoderException {
        final TLV tlv = container.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AbstractReadAuthorizationData.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder authorizationDataDecoder = new Asn1Decoder();
        final AuthorizationDataContainer authorizationDataContainer = new AuthorizationDataContainer();
        try {
            authorizationDataDecoder.decode(container.getStream(), (Asn1Container)authorizationDataContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        final AuthorizationData authorizationData = authorizationDataContainer.getAuthorizationData();
        if (AbstractReadAuthorizationData.IS_DEBUG) {
            AbstractReadAuthorizationData.LOG.debug("AuthorizationData : " + authorizationData);
        }
        this.setAuthorizationData(authorizationData, container);
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        container.updateParent();
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AbstractReadAuthorizationData.class);
        IS_DEBUG = AbstractReadAuthorizationData.LOG.isDebugEnabled();
    }
}
