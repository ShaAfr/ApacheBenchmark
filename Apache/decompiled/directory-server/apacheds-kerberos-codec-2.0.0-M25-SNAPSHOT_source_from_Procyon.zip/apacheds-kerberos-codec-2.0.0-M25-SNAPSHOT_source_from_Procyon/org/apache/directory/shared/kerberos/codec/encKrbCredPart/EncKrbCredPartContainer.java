// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbCredPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.components.EncKrbCredPart;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncKrbCredPartContainer extends AbstractContainer
{
    private EncKrbCredPart encKrbCredPart;
    
    public EncKrbCredPartContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)EncKrbCredPartGrammar.getInstance());
        this.setTransition((Enum)EncKrbCredPartStatesEnum.START_STATE);
    }
    
    public EncKrbCredPart getEncKrbCredPart() {
        return this.encKrbCredPart;
    }
    
    public void setEncKrbCredPart(final EncKrbCredPart encKrbCredPart) {
        this.encKrbCredPart = encKrbCredPart;
    }
}
