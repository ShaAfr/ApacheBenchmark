// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.tgsReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.TgsReq;
import org.apache.directory.shared.kerberos.codec.kdcReq.KdcReqContainer;

public class TgsReqContainer extends KdcReqContainer
{
    private TgsReq tgsReq;
    
    public TgsReqContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)TgsReqGrammar.getInstance());
        this.setTransition((Enum)TgsReqStatesEnum.START_STATE);
    }
    
    public TgsReq getTgsReq() {
        return this.tgsReq;
    }
    
    public void setTgsReq(final TgsReq tgsReq) {
        this.tgsReq = tgsReq;
    }
}
