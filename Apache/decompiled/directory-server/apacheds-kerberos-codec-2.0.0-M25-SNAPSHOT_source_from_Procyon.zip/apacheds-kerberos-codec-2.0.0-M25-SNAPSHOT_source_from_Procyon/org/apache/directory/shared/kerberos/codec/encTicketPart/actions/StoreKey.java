// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptionKey;

public class StoreKey extends AbstractReadEncryptionKey<EncTicketPartContainer>
{
    public StoreKey() {
        super("EncTicketPart key");
    }
    
    @Override
    protected void setEncryptionKey(final EncryptionKey encryptionKey, final EncTicketPartContainer encTicketPartContainer) {
        encTicketPartContainer.getEncTicketPart().setKey(encryptionKey);
    }
}
