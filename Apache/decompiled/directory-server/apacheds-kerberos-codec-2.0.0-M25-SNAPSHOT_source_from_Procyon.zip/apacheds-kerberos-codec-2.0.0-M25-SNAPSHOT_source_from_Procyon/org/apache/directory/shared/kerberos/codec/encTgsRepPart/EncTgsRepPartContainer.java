// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTgsRepPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.EncTgsRepPart;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncTgsRepPartContainer extends AbstractContainer
{
    private EncTgsRepPart encTgsRepPart;
    
    public EncTgsRepPartContainer(final ByteBuffer stream) {
        super(stream);
        this.encTgsRepPart = new EncTgsRepPart();
        this.setGrammar((Grammar)EncTgsRepPartGrammar.getInstance());
        this.setTransition((Enum)EncTgsRepPartStatesEnum.START_STATE);
    }
    
    public EncTgsRepPart getEncTgsRepPart() {
        return this.encTgsRepPart;
    }
    
    public void setEncTgsRepPart(final EncTgsRepPart encTgsRepPart) {
        this.encTgsRepPart = encTgsRepPart;
    }
}
