// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encTicketPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.flags.TicketFlags;
import org.apache.directory.shared.kerberos.codec.encTicketPart.EncTicketPartContainer;
import org.apache.directory.api.asn1.actions.AbstractReadBitString;

public class StoreFlags extends AbstractReadBitString<EncTicketPartContainer>
{
    public StoreFlags() {
        super("Store EncTicketPart's flags");
    }
    
    protected void setBitString(final byte[] data, final EncTicketPartContainer encTicketPartContainer) {
        final TicketFlags flags = new TicketFlags(data);
        encTicketPartContainer.getEncTicketPart().setFlags(flags);
    }
}
