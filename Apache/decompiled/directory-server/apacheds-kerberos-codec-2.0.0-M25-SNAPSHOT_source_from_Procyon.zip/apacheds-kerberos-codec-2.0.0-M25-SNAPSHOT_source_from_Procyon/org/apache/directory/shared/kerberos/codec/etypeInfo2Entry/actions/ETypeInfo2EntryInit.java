// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.ETypeInfo2Entry;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.ETypeInfo2EntryContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class ETypeInfo2EntryInit extends GrammarAction<ETypeInfo2EntryContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public ETypeInfo2EntryInit() {
        super("Creates a ETYPE-INFO2-ENTRY instance");
    }
    
    public void action(final ETypeInfo2EntryContainer eTypeInfo2EntryContainer) throws DecoderException {
        final TLV tlv = eTypeInfo2EntryContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            ETypeInfo2EntryInit.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final ETypeInfo2Entry etypeInfo2Entry = new ETypeInfo2Entry();
        eTypeInfo2EntryContainer.setETypeInfo2Entry(etypeInfo2Entry);
        if (ETypeInfo2EntryInit.IS_DEBUG) {
            ETypeInfo2EntryInit.LOG.debug("ETYPE-INFO2-ENTRY created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ETypeInfo2EntryInit.class);
        IS_DEBUG = ETypeInfo2EntryInit.LOG.isDebugEnabled();
    }
}
