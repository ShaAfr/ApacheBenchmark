// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.typedData;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.typedData.actions.StoreDataValue;
import org.apache.directory.shared.kerberos.codec.typedData.actions.StoreTdType;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.typedData.actions.TypedDataInit;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class TypedDataGrammar extends AbstractGrammar<TypedDataContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<TypedDataContainer> instance;
    
    private TypedDataGrammar() {
        this.setName(TypedDataGrammar.class.getName());
        super.transitions = new GrammarTransition[TypedDataStatesEnum.LAST_TYPED_DATA_STATE.ordinal()][256];
        super.transitions[TypedDataStatesEnum.START_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)TypedDataStatesEnum.START_STATE, (Enum)TypedDataStatesEnum.TYPED_DATA_SEQ_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new TypedDataInit());
        super.transitions[TypedDataStatesEnum.TYPED_DATA_SEQ_SEQ_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)TypedDataStatesEnum.TYPED_DATA_SEQ_SEQ_STATE, (Enum)TypedDataStatesEnum.TYPED_DATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[TypedDataStatesEnum.TYPED_DATA_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)TypedDataStatesEnum.TYPED_DATA_SEQ_STATE, (Enum)TypedDataStatesEnum.TYPED_DATA_TDTYPE_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[TypedDataStatesEnum.TYPED_DATA_TDTYPE_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)TypedDataStatesEnum.TYPED_DATA_TDTYPE_TAG_STATE, (Enum)TypedDataStatesEnum.TYPED_DATA_TDTYPE_STATE, UniversalTag.INTEGER, (Action)new StoreTdType());
        super.transitions[TypedDataStatesEnum.TYPED_DATA_TDTYPE_STATE.ordinal()][161] = new GrammarTransition((Enum)TypedDataStatesEnum.TYPED_DATA_TDTYPE_STATE, (Enum)TypedDataStatesEnum.TYPED_DATA_TDDATA_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[TypedDataStatesEnum.TYPED_DATA_TDDATA_TAG_STATE.ordinal()][UniversalTag.OCTET_STRING.getValue()] = new GrammarTransition((Enum)TypedDataStatesEnum.TYPED_DATA_TDDATA_TAG_STATE, (Enum)TypedDataStatesEnum.TYPED_DATA_TDDATA_STATE, UniversalTag.OCTET_STRING, (Action)new StoreDataValue());
        super.transitions[TypedDataStatesEnum.TYPED_DATA_TDDATA_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)TypedDataStatesEnum.TYPED_DATA_TDDATA_STATE, (Enum)TypedDataStatesEnum.TYPED_DATA_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
    }
    
    public static Grammar<TypedDataContainer> getInstance() {
        return TypedDataGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)TypedDataGrammar.class);
        IS_DEBUG = TypedDataGrammar.LOG.isDebugEnabled();
        TypedDataGrammar.instance = (Grammar<TypedDataContainer>)new TypedDataGrammar();
    }
}
