// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.EncKdcRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreKeyExpiration extends AbstractReadKerberosTime<EncKdcRepPartContainer>
{
    public StoreKeyExpiration() {
        super("EncKdcRepPart key expiration");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final EncKdcRepPartContainer encKdcRepPartContainer) {
        encKdcRepPartContainer.getEncKdcRepPart().setKeyExpiration(krbtime);
    }
}
