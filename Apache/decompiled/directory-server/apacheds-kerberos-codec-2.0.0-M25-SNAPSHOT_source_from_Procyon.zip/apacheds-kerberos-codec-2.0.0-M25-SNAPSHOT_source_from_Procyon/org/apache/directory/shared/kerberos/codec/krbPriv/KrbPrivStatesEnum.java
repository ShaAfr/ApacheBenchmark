// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbPriv;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum KrbPrivStatesEnum implements States
{
    START_STATE, 
    KRB_PRIV_TAG_STATE, 
    KRB_PRIV_SEQ_STATE, 
    KRB_PRIV_PVNO_TAG_STATE, 
    KRB_PRIV_PVNO_STATE, 
    KRB_PRIV_MSGTYPE_TAG_STATE, 
    KRB_PRIV_MSGTYPE_STATE, 
    KRB_PRIV_EN_PART_TAG_STATE, 
    LAST_KRB_PRIV_STATE;
    
    public String getGrammarName(final int grammar) {
        return "KRB_PRIV_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<KrbPrivContainer> grammar) {
        if (grammar instanceof KrbPrivGrammar) {
            return "KRB_PRIV_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == KrbPrivStatesEnum.LAST_KRB_PRIV_STATE.ordinal()) ? "LAST_KRB_PRIV_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == KrbPrivStatesEnum.LAST_KRB_PRIV_STATE;
    }
    
    public KrbPrivStatesEnum getStartState() {
        return KrbPrivStatesEnum.START_STATE;
    }
}
