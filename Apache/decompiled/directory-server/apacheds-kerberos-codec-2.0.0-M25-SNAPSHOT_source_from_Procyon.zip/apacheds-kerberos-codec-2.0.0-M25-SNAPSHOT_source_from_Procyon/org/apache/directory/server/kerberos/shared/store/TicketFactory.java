// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.store;

import java.text.ParseException;
import org.apache.directory.shared.kerberos.exceptions.KerberosException;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.apache.directory.api.asn1.Asn1Object;
import org.apache.directory.server.kerberos.shared.crypto.encryption.KeyUsage;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.components.TransitedEncoding;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.types.PrincipalNameType;
import org.apache.directory.server.kerberos.shared.crypto.encryption.RandomKeyFactory;
import org.apache.directory.shared.kerberos.flags.KerberosFlag;
import org.apache.directory.shared.kerberos.flags.TicketFlag;
import org.apache.directory.shared.kerberos.flags.TicketFlags;
import org.apache.directory.shared.kerberos.components.EncTicketPart;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.shared.kerberos.codec.types.EncryptionType;
import javax.security.auth.kerberos.KerberosKey;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import javax.security.auth.kerberos.KerberosPrincipal;
import org.apache.directory.server.kerberos.shared.crypto.encryption.CipherTextHandler;

public class TicketFactory
{
    private static final int ONE_DAY = 86400000;
    private static final int ONE_WEEK = 604800000;
    private CipherTextHandler cipherTextHandler;
    
    public TicketFactory() {
        this.cipherTextHandler = new CipherTextHandler();
    }
    
    public EncryptionKey getServerKey(final KerberosPrincipal serverPrincipal, final String serverPassword) {
        final KerberosKey serverKerberosKey = new KerberosKey(serverPrincipal, serverPassword.toCharArray(), "DES");
        final byte[] serverKeyBytes = serverKerberosKey.getEncoded();
        final EncryptionKey serverKey = new EncryptionKey(EncryptionType.DES_CBC_MD5, serverKeyBytes);
        return serverKey;
    }
    
    public Ticket getTicket(final KerberosPrincipal clientPrincipal, final KerberosPrincipal serverPrincipal, final EncryptionKey serverKey) throws KerberosException, ParseException {
        final EncTicketPart encTicketPart = new EncTicketPart();
        final TicketFlags ticketFlags = new TicketFlags();
        ticketFlags.setFlag(TicketFlag.RENEWABLE);
        encTicketPart.setFlags(ticketFlags);
        final EncryptionKey sessionKey = RandomKeyFactory.getRandomKey(EncryptionType.DES_CBC_MD5);
        encTicketPart.setKey(sessionKey);
        encTicketPart.setCName(new PrincipalName(clientPrincipal.getName(), PrincipalNameType.KRB_NT_PRINCIPAL));
        encTicketPart.setTransited(new TransitedEncoding());
        encTicketPart.setAuthTime(new KerberosTime());
        final long now = System.currentTimeMillis();
        final KerberosTime endTime = new KerberosTime(now + 86400000L);
        encTicketPart.setEndTime(endTime);
        final KerberosTime renewTill = new KerberosTime(now + 604800000L);
        encTicketPart.setRenewTill(renewTill);
        final EncryptedData encryptedTicketPart = this.cipherTextHandler.seal(serverKey, (Asn1Object)encTicketPart, KeyUsage.AS_OR_TGS_REP_TICKET_WITH_SRVKEY);
        final Ticket ticket = new Ticket();
        ticket.setTktVno(5);
        ticket.setSName(new PrincipalName(serverPrincipal.getName(), PrincipalNameType.KRB_NT_PRINCIPAL));
        ticket.setRealm(serverPrincipal.getRealm());
        ticket.setEncPart(encryptedTicketPart);
        return ticket;
    }
}
