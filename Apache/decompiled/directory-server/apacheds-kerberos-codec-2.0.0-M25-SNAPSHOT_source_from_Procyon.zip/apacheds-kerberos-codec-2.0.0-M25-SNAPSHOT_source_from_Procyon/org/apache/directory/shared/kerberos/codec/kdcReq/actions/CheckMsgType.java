// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReq.actions;

import org.apache.directory.shared.kerberos.codec.kdcReq.KdcReqContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadMsgType;

public class CheckMsgType extends AbstractReadMsgType<KdcReqContainer>
{
    public CheckMsgType() {
        super("KDC-REQ msg-type");
    }
}
