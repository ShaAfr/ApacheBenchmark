// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encKrbCredPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.shared.kerberos.codec.encKrbCredPart.EncKrbCredPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadHostAddress;

public class StoreSenderAddress extends AbstractReadHostAddress<EncKrbCredPartContainer>
{
    public StoreSenderAddress() {
        super("EncKrbCredPart s-address");
    }
    
    @Override
    protected void setAddress(final HostAddress hostAddress, final EncKrbCredPartContainer encKrbCredPartContainer) {
        encKrbCredPartContainer.getEncKrbCredPart().setSenderAddress(hostAddress);
        encKrbCredPartContainer.setGrammarEndAllowed(true);
    }
}
