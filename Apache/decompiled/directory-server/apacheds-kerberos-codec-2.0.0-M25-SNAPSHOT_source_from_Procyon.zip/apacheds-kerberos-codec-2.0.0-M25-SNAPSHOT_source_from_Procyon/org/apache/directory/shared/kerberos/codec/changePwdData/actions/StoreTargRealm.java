// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.changePwdData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.changePwdData.ChangePasswdDataContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadRealm;

public class StoreTargRealm extends AbstractReadRealm<ChangePasswdDataContainer>
{
    public StoreTargRealm() {
        super("Kerberos changepassword target realm value");
    }
    
    @Override
    protected void setRealm(final String realm, final ChangePasswdDataContainer container) {
        container.getChngPwdData().setTargRealm(realm);
        container.setGrammarEndAllowed(true);
    }
}
