// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.authorizationData;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum AuthorizationDataStatesEnum implements States
{
    START_STATE, 
    AUTHORIZATION_DATA_SEQ_STATE, 
    AUTHORIZATION_DATA_SEQ_SEQ_STATE, 
    AUTHORIZATION_DATA_ADTYPE_TAG_STATE, 
    AUTHORIZATION_DATA_ADTYPE_STATE, 
    AUTHORIZATION_DATA_ADDATA_TAG_STATE, 
    AUTHORIZATION_DATA_ADDATA_STATE, 
    LAST_AUTHORIZATION_DATA_STATE;
    
    public String getGrammarName(final int grammar) {
        return "AUTHORIZATION_DATA_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<AuthorizationDataContainer> grammar) {
        if (grammar instanceof AuthorizationDataGrammar) {
            return "AUTHORIZATION_DATA_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == AuthorizationDataStatesEnum.LAST_AUTHORIZATION_DATA_STATE.ordinal()) ? "LAST_AUTHORIZATION_DATA_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == AuthorizationDataStatesEnum.LAST_AUTHORIZATION_DATA_STATE;
    }
    
    public AuthorizationDataStatesEnum getStartState() {
        return AuthorizationDataStatesEnum.START_STATE;
    }
}
