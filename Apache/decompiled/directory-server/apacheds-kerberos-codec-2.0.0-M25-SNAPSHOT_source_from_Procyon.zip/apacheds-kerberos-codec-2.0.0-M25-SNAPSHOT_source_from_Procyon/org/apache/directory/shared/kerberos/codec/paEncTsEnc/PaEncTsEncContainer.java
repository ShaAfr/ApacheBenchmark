// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.paEncTsEnc;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.PaEncTsEnc;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class PaEncTsEncContainer extends AbstractContainer
{
    private PaEncTsEnc paEncTsEnc;
    
    public PaEncTsEncContainer() {
        this.paEncTsEnc = new PaEncTsEnc();
        this.setGrammar((Grammar)PaEncTsEncGrammar.getInstance());
        this.setTransition((Enum)PaEncTsEncStatesEnum.START_STATE);
    }
    
    public PaEncTsEnc getPaEncTsEnc() {
        return this.paEncTsEnc;
    }
    
    public void setPaEncTsEnc(final PaEncTsEnc paEncTsEnc) {
        this.paEncTsEnc = paEncTsEnc;
    }
}
