// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReq.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.kdcReq.KdcReqContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPvno;

public class StorePvno extends AbstractReadPvno<KdcReqContainer>
{
    public StorePvno() {
        super("KDC-REQ pvno");
    }
    
    public void setPvno(final int pvno, final KdcReqContainer kdcReqContainer) {
        kdcReqContainer.getKdcReq().setPvno(pvno);
    }
}
