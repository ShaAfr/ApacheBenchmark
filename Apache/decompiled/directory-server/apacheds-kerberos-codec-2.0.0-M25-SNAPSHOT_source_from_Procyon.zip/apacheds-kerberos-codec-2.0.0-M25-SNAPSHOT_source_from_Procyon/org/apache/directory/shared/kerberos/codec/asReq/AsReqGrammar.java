// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.asReq;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.asReq.actions.StoreKdcReq;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class AsReqGrammar extends AbstractGrammar<AsReqContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<AsReqContainer> instance;
    
    private AsReqGrammar() {
        this.setName(AsReqGrammar.class.getName());
        super.transitions = new GrammarTransition[AsReqStatesEnum.LAST_AS_REQ_STATE.ordinal()][256];
        super.transitions[AsReqStatesEnum.START_STATE.ordinal()][106] = new GrammarTransition((Enum)AsReqStatesEnum.START_STATE, (Enum)AsReqStatesEnum.AS_REQ_STATE, 106, (Action)new StoreKdcReq());
    }
    
    public static Grammar<AsReqContainer> getInstance() {
        return AsReqGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AsReqGrammar.class);
        IS_DEBUG = AsReqGrammar.LOG.isDebugEnabled();
        AsReqGrammar.instance = (Grammar<AsReqContainer>)new AsReqGrammar();
    }
}
