// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.EncKdcRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.shared.kerberos.codec.EncKdcRepPart.EncKdcRepPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadEncryptionKey;

public class StoreKey extends AbstractReadEncryptionKey<EncKdcRepPartContainer>
{
    public StoreKey() {
        super("EncKdcRepPart key");
    }
    
    @Override
    protected void setEncryptionKey(final EncryptionKey encryptionKey, final EncKdcRepPartContainer encKdcRepPartContainer) {
        encKdcRepPartContainer.getEncKdcRepPart().setKey(encryptionKey);
    }
}
