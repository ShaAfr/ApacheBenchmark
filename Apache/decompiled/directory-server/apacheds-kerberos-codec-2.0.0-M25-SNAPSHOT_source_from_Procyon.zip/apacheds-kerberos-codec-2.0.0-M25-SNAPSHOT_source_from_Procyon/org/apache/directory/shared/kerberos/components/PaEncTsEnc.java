// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.Asn1Object;

public class PaEncTsEnc implements Asn1Object
{
    private static final Logger log;
    private static final boolean IS_DEBUG;
    private KerberosTime patimestamp;
    private Integer pausec;
    private int paTimestampLength;
    private int paUsecLength;
    private int paEncTsEncLength;
    
    public PaEncTsEnc() {
    }
    
    public PaEncTsEnc(final KerberosTime paTimestamp, final int pausec) {
        this.patimestamp = paTimestamp;
        this.pausec = pausec;
    }
    
    public KerberosTime getPaTimestamp() {
        return this.patimestamp;
    }
    
    public void setPaTimestamp(final KerberosTime patimestamp) {
        this.patimestamp = patimestamp;
    }
    
    public int getPausec() {
        if (this.pausec == null) {
            return -1;
        }
        return this.pausec;
    }
    
    public void setPausec(final int pausec) {
        this.pausec = pausec;
    }
    
    public int computeLength() {
        this.paTimestampLength = 17;
        this.paEncTsEncLength = 1 + TLV.getNbBytes(this.paTimestampLength) + this.paTimestampLength;
        if (this.pausec != null) {
            final int pausecLength = BerValue.getNbBytes((int)this.pausec);
            this.paUsecLength = 1 + TLV.getNbBytes(pausecLength) + pausecLength;
            this.paEncTsEncLength += 1 + TLV.getNbBytes(this.paUsecLength) + this.paUsecLength;
        }
        return 1 + TLV.getNbBytes(this.paEncTsEncLength) + this.paEncTsEncLength;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.paEncTsEncLength));
            buffer.put((byte)(-96));
            buffer.put((byte)17);
            buffer.put(UniversalTag.GENERALIZED_TIME.getValue());
            buffer.put((byte)15);
            buffer.put(this.patimestamp.getBytes());
            if (this.pausec != null) {
                buffer.put((byte)(-95));
                buffer.put(TLV.getBytes(this.paUsecLength));
                BerValue.encode(buffer, (int)this.pausec);
            }
        }
        catch (BufferOverflowException boe) {
            PaEncTsEnc.log.error(I18n.err(I18n.ERR_140, new Object[] { 1 + TLV.getNbBytes(this.paEncTsEncLength) + this.paEncTsEncLength, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (PaEncTsEnc.IS_DEBUG) {
            PaEncTsEnc.log.debug("Checksum encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            PaEncTsEnc.log.debug("Checksum initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        return this.toString("");
    }
    
    public String toString(final String tabs) {
        final StringBuilder sb = new StringBuilder();
        sb.append(tabs).append("PA-ENC-TS-ENC : {\n");
        sb.append(tabs).append("    patimestamp : ").append(this.patimestamp).append('\n');
        if (this.pausec != null) {
            sb.append(tabs + "    pausec :").append(this.pausec).append('\n');
        }
        sb.append(tabs + "}\n");
        return sb.toString();
    }
    
    static {
        log = LoggerFactory.getLogger((Class)PaEncTsEnc.class);
        IS_DEBUG = PaEncTsEnc.log.isDebugEnabled();
    }
}
