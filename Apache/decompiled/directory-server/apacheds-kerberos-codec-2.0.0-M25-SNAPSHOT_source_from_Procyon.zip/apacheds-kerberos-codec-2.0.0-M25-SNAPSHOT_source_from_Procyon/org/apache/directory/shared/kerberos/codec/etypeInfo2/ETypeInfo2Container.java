// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2;

import org.apache.directory.shared.kerberos.components.ETypeInfo2Entry;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.ETypeInfo2;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class ETypeInfo2Container extends AbstractContainer
{
    private ETypeInfo2 etypeInfo2;
    
    public ETypeInfo2Container() {
        this.etypeInfo2 = new ETypeInfo2();
        this.setGrammar((Grammar)ETypeInfo2Grammar.getInstance());
        this.setTransition((Enum)ETypeInfo2StatesEnum.START_STATE);
    }
    
    public ETypeInfo2 getETypeInfo2() {
        return this.etypeInfo2;
    }
    
    public void setETypeInfo2(final ETypeInfo2 etypeInfo2) {
        this.etypeInfo2 = etypeInfo2;
    }
    
    public void addEtypeInfo2Entry(final ETypeInfo2Entry etypeInfo2Entry) {
        this.etypeInfo2.addETypeInfo2Entry(etypeInfo2Entry);
    }
}
