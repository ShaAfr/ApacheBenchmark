// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddresses.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.hostAddress.HostAddressContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.hostAddresses.HostAddressesContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AddHostAddress extends GrammarAction<HostAddressesContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AddHostAddress() {
        super("Add an HostAddress instance");
    }
    
    public void action(final HostAddressesContainer hostAddressesContainer) throws DecoderException {
        final TLV tlv = hostAddressesContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AddHostAddress.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder hostAddressDecoder = new Asn1Decoder();
        final HostAddressContainer hostAddressContainer = new HostAddressContainer();
        hostAddressContainer.setStream(hostAddressesContainer.getStream());
        hostAddressesContainer.rewind();
        try {
            hostAddressDecoder.decode(hostAddressesContainer.getStream(), (Asn1Container)hostAddressContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        hostAddressesContainer.updateParent();
        final HostAddress hostAddress = hostAddressContainer.getHostAddress();
        hostAddressesContainer.addHostAddress(hostAddress);
        if (AddHostAddress.IS_DEBUG) {
            AddHostAddress.LOG.debug("HostAddress added : {}", (Object)hostAddress);
        }
        hostAddressesContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AddHostAddress.class);
        IS_DEBUG = AddHostAddress.LOG.isDebugEnabled();
    }
}
