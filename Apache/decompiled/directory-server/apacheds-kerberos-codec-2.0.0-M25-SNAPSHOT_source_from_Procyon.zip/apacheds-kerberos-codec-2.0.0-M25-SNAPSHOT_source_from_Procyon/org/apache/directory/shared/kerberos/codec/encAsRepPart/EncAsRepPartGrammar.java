// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encAsRepPart;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.encAsRepPart.actions.StoreEncAsRepPart;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class EncAsRepPartGrammar extends AbstractGrammar<EncAsRepPartContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<EncAsRepPartContainer> instance;
    
    private EncAsRepPartGrammar() {
        this.setName(EncAsRepPartGrammar.class.getName());
        super.transitions = new GrammarTransition[EncAsRepPartStatesEnum.LAST_ENC_AS_REP_PART_STATE.ordinal()][256];
        super.transitions[EncAsRepPartStatesEnum.START_STATE.ordinal()][121] = new GrammarTransition((Enum)EncAsRepPartStatesEnum.START_STATE, (Enum)EncAsRepPartStatesEnum.ENC_AS_REP_PART_STATE, 121, (Action)new StoreEncAsRepPart());
    }
    
    public static Grammar<EncAsRepPartContainer> getInstance() {
        return EncAsRepPartGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncAsRepPartGrammar.class);
        IS_DEBUG = EncAsRepPartGrammar.LOG.isDebugEnabled();
        EncAsRepPartGrammar.instance = (Grammar<EncAsRepPartContainer>)new EncAsRepPartGrammar();
    }
}
