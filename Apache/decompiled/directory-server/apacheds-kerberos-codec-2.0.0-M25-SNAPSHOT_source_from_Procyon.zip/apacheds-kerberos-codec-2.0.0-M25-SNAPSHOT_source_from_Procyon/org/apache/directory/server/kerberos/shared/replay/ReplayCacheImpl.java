// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.replay;

import net.sf.ehcache.store.AbstractPolicy;
import org.slf4j.LoggerFactory;
import net.sf.ehcache.Status;
import net.sf.ehcache.Element;
import java.io.Serializable;
import org.apache.directory.shared.kerberos.KerberosTime;
import javax.security.auth.kerberos.KerberosPrincipal;
import net.sf.ehcache.store.Policy;
import net.sf.ehcache.Cache;
import org.slf4j.Logger;

public class ReplayCacheImpl implements ReplayCache
{
    private static final Logger LOG;
    private Cache cache;
    private static final long DEFAULT_CLOCK_SKEW = 300000L;
    private long clockSkew;
    
    public ReplayCacheImpl(final Cache cache) {
        this.clockSkew = 300000L;
        (this.cache = cache).setMemoryStoreEvictionPolicy((Policy)new ClockskewExpirationPolicy());
    }
    
    public ReplayCacheImpl(final Cache cache, final long clockSkew) {
        this.clockSkew = 300000L;
        this.cache = cache;
        this.clockSkew = clockSkew;
        this.cache.setMemoryStoreEvictionPolicy((Policy)new ClockskewExpirationPolicy());
    }
    
    public void setClockSkew(final long clockSkew) {
        this.clockSkew = clockSkew;
    }
    
    @Override
    public synchronized boolean isReplay(final KerberosPrincipal serverPrincipal, final KerberosPrincipal clientPrincipal, final KerberosTime clientTime, final int clientMicroSeconds) {
        ReplayCacheEntry entry = new ReplayCacheEntry(serverPrincipal, clientPrincipal, clientTime, clientMicroSeconds);
        final Element element = this.cache.get((Serializable)entry.createKey());
        if (element == null) {
            return false;
        }
        entry = (ReplayCacheEntry)element.getValue();
        return serverPrincipal.equals(entry.serverPrincipal) && clientTime.equals(entry.clientTime) && clientMicroSeconds == entry.clientMicroSeconds;
    }
    
    @Override
    public synchronized void save(final KerberosPrincipal serverPrincipal, final KerberosPrincipal clientPrincipal, final KerberosTime clientTime, final int clientMicroSeconds) {
        final ReplayCacheEntry entry = new ReplayCacheEntry(serverPrincipal, clientPrincipal, clientTime, clientMicroSeconds);
        final Element element = new Element((Serializable)entry.createKey(), (Serializable)entry);
        this.cache.put(element);
    }
    
    @Override
    public void clear() {
        ReplayCacheImpl.LOG.debug("removing all the elements from cache");
        if (this.cache.getStatus().equals(Status.STATUS_ALIVE)) {
            this.cache.removeAll();
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ReplayCacheImpl.class);
    }
    
    public static class ReplayCacheEntry implements Serializable
    {
        private static final long serialVersionUID = 1L;
        private KerberosPrincipal serverPrincipal;
        private KerberosPrincipal clientPrincipal;
        private KerberosTime clientTime;
        private int clientMicroSeconds;
        
        public ReplayCacheEntry(final KerberosPrincipal serverPrincipal, final KerberosPrincipal clientPrincipal, final KerberosTime clientTime, final int clientMicroSeconds) {
            this.serverPrincipal = serverPrincipal;
            this.clientPrincipal = clientPrincipal;
            this.clientTime = clientTime;
            this.clientMicroSeconds = clientMicroSeconds;
        }
        
        public boolean equals(final ReplayCacheEntry that) {
            return this.serverPrincipal.equals(that.serverPrincipal) && this.clientPrincipal.equals(that.clientPrincipal) && this.clientTime.equals(that.clientTime) && this.clientMicroSeconds == that.clientMicroSeconds;
        }
        
        public boolean isOutsideClockSkew(final long clockSkew) {
            return !this.clientTime.isInClockSkew(clockSkew);
        }
        
        private String createKey() {
            final StringBuilder sb = new StringBuilder();
            sb.append((this.clientPrincipal == null) ? "null" : this.clientPrincipal.getName());
            sb.append('#');
            sb.append((this.serverPrincipal == null) ? "null" : this.serverPrincipal.getName());
            sb.append('#');
            sb.append((this.clientTime == null) ? "null" : this.clientTime.getDate());
            sb.append('#');
            sb.append(this.clientMicroSeconds);
            return sb.toString();
        }
    }
    
    private class ClockskewExpirationPolicy extends AbstractPolicy
    {
        public String getName() {
            return "CLOCK-SKEW";
        }
        
        public boolean compare(final Element element1, final Element element2) {
            final ReplayCacheEntry entry = (ReplayCacheEntry)element2.getValue();
            return entry.isOutsideClockSkew(ReplayCacheImpl.this.clockSkew);
        }
    }
}
