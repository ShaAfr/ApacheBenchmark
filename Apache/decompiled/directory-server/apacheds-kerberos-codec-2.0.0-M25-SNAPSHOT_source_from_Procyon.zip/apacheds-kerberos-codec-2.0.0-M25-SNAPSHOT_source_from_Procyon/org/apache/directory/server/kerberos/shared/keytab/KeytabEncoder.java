// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.keytab;

import java.io.UnsupportedEncodingException;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import java.util.Iterator;
import java.util.ArrayList;
import java.nio.ByteBuffer;
import java.util.List;

public class KeytabEncoder
{
    private short getKeytabVersion(final byte[] version) {
        if (version == null || version.length != 2 || version[0] != 5) {
            return -1;
        }
        switch (version[1]) {
            case 1: {
                return 1281;
            }
            case 2: {
                return 1282;
            }
            default: {
                return -1;
            }
        }
    }
    
    public ByteBuffer write(final byte[] keytabVersion, final List<KeytabEntry> entries) {
        final List<ByteBuffer> keytabEntryBuffers = new ArrayList<ByteBuffer>();
        final short version = this.getKeytabVersion(keytabVersion);
        final int buffersSize = this.encodeKeytabEntries(keytabEntryBuffers, version, entries);
        final ByteBuffer buffer = ByteBuffer.allocate(keytabVersion.length + buffersSize);
        buffer.put(keytabVersion);
        for (final ByteBuffer keytabEntryBuffer : keytabEntryBuffers) {
            buffer.put(keytabEntryBuffer);
        }
        buffer.flip();
        return buffer;
    }
    
    private int encodeKeytabEntries(final List<ByteBuffer> buffers, final short version, final List<KeytabEntry> entries) {
        int size = 0;
        for (final KeytabEntry keytabEntry : entries) {
            final ByteBuffer entryBuffer = this.encodeKeytabEntry(version, keytabEntry);
            buffers.add(entryBuffer);
            size += entryBuffer.limit();
        }
        return size;
    }
    
    private ByteBuffer encodeKeytabEntry(final short version, final KeytabEntry entry) {
        final ByteBuffer principalNameBuffer = this.encodePrincipalName(version, entry.getPrincipalName());
        final ByteBuffer keyBlockBuffer = this.encodeKeyBlock(entry.getKey());
        int bufferSize = 4 + principalNameBuffer.limit() + 4 + 1 + keyBlockBuffer.limit();
        if (version == 1282) {
            bufferSize += 4;
        }
        final ByteBuffer buffer = ByteBuffer.allocate(bufferSize);
        buffer.putInt(bufferSize - 4);
        buffer.put(principalNameBuffer);
        if (version == 1282) {
            buffer.putInt(entry.getPrincipalType());
        }
        buffer.putInt((int)(entry.getTimeStamp().getTime() / 1000L));
        buffer.put(entry.getKeyVersion());
        buffer.put(keyBlockBuffer);
        buffer.flip();
        return buffer;
    }
    
    private ByteBuffer encodePrincipalName(final short version, final String principalName) {
        final String[] split = principalName.split("@");
        final String nameComponentPart = split[0];
        final String realm = split[1];
        final String[] nameComponents = nameComponentPart.split("/");
        final List<byte[]> strings = new ArrayList<byte[]>();
        int size = 2;
        size += this.encodeCountedString(strings, realm);
        for (final String nameComponent : nameComponents) {
            size += this.encodeCountedString(strings, nameComponent);
        }
        final ByteBuffer buffer = ByteBuffer.allocate(size);
        if (version == 1281) {
            buffer.putShort((short)(nameComponents.length + 1));
        }
        else {
            buffer.putShort((short)nameComponents.length);
        }
        for (final byte[] string : strings) {
            buffer.putShort((short)string.length);
            buffer.put(string);
        }
        buffer.flip();
        return buffer;
    }
    
    private ByteBuffer encodeKeyBlock(final EncryptionKey key) {
        final byte[] keyBytes = key.getKeyValue();
        final int size = 4 + keyBytes.length;
        final ByteBuffer buffer = ByteBuffer.allocate(size);
        buffer.putShort((short)key.getKeyType().getValue());
        buffer.putShort((short)keyBytes.length);
        buffer.put(keyBytes);
        buffer.flip();
        return buffer;
    }
    
    private short encodeCountedString(final List<byte[]> nameComponentBytes, final String string) {
        try {
            final byte[] data = string.getBytes("US-ASCII");
            nameComponentBytes.add(data);
            return (short)(data.length + 2);
        }
        catch (UnsupportedEncodingException uee) {
            throw new RuntimeException(uee.getMessage(), uee);
        }
    }
}
