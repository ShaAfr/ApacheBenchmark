// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encAsRepPart;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.EncAsRepPart;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class EncAsRepPartContainer extends AbstractContainer
{
    private EncAsRepPart encAsRepPart;
    
    public EncAsRepPartContainer(final ByteBuffer stream) {
        super(stream);
        this.encAsRepPart = new EncAsRepPart();
        this.setGrammar((Grammar)EncAsRepPartGrammar.getInstance());
        this.setTransition((Enum)EncAsRepPartStatesEnum.START_STATE);
    }
    
    public EncAsRepPart getEncAsRepPart() {
        return this.encAsRepPart;
    }
    
    public void setEncAsRepPart(final EncAsRepPart encAsRepPart) {
        this.encAsRepPart = encAsRepPart;
    }
}
