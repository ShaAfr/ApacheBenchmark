// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.apReq.actions;

import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.shared.kerberos.codec.apReq.ApReqContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadMsgType;

public class CheckMsgType extends AbstractReadMsgType<ApReqContainer>
{
    public CheckMsgType() {
        super("AP-REQ msg-type", KerberosMessageType.AP_REQ);
    }
}
