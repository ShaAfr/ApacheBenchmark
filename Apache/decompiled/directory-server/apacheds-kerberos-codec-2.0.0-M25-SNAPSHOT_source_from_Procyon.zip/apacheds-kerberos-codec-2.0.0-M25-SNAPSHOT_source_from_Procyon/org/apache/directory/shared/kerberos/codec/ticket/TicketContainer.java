// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.ticket;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.messages.Ticket;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class TicketContainer extends AbstractContainer
{
    private Ticket ticket;
    
    public TicketContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)TicketGrammar.getInstance());
        this.setTransition((Enum)TicketStatesEnum.START_STATE);
    }
    
    public Ticket getTicket() {
        return this.ticket;
    }
    
    public void setTicket(final Ticket ticket) {
        this.ticket = ticket;
    }
}
