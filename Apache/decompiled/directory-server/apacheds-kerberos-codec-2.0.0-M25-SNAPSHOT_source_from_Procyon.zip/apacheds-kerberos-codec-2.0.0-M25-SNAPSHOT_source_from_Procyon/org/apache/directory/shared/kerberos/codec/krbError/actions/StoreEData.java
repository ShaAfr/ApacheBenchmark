// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbError.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbError.KrbErrorContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreEData extends AbstractReadOctetString<KrbErrorContainer>
{
    public StoreEData() {
        super("KRB-ERROR edata", true);
    }
    
    protected void setOctetString(final byte[] data, final KrbErrorContainer krbErrorContainer) {
        krbErrorContainer.getKrbError().setEData(data);
        krbErrorContainer.setGrammarEndAllowed(true);
    }
}
