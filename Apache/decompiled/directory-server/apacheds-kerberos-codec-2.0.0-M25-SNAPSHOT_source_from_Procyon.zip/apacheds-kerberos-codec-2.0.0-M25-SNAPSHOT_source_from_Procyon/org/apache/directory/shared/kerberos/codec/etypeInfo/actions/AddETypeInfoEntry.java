// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.components.ETypeInfoEntry;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.etypeInfoEntry.ETypeInfoEntryContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.etypeInfo.ETypeInfoContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class AddETypeInfoEntry extends GrammarAction<ETypeInfoContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AddETypeInfoEntry() {
        super("Add an ETypeInfoEntry instance");
    }
    
    public void action(final ETypeInfoContainer eTypeInfoContainer) throws DecoderException {
        final TLV tlv = eTypeInfoContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AddETypeInfoEntry.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder etypeInfoEntryDecoder = new Asn1Decoder();
        final ETypeInfoEntryContainer etypeInfoEntryContainer = new ETypeInfoEntryContainer();
        etypeInfoEntryContainer.setStream(eTypeInfoContainer.getStream());
        eTypeInfoContainer.rewind();
        try {
            etypeInfoEntryDecoder.decode(eTypeInfoContainer.getStream(), (Asn1Container)etypeInfoEntryContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        eTypeInfoContainer.updateParent();
        final ETypeInfoEntry etypeInfoEntry = etypeInfoEntryContainer.getETypeInfoEntry();
        eTypeInfoContainer.addEtypeInfoEntry(etypeInfoEntry);
        if (AddETypeInfoEntry.IS_DEBUG) {
            AddETypeInfoEntry.LOG.debug("ETYPE-INFO-ENTRY added : {}", (Object)etypeInfoEntry);
        }
        eTypeInfoContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AddETypeInfoEntry.class);
        IS_DEBUG = AddETypeInfoEntry.LOG.isDebugEnabled();
    }
}
