// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.components;

import org.slf4j.LoggerFactory;
import org.apache.directory.shared.kerberos.codec.types.AuthorizationType;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import java.util.Iterator;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import java.util.ArrayList;
import org.slf4j.Logger;
import java.util.List;
import org.apache.directory.api.asn1.Asn1Object;

public class AuthorizationData implements Asn1Object
{
    private List<AuthorizationDataEntry> authorizationData;
    private AuthorizationDataEntry currentAD;
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    private int[] adTypeTagLen;
    private int[] adDataTagLen;
    private int[] authorizationDataSeqLen;
    private int authorizationDataSeqSeqLen;
    
    public AuthorizationData() {
        this.authorizationData = new ArrayList<AuthorizationDataEntry>();
    }
    
    public int computeLength() {
        int i = 0;
        this.authorizationDataSeqLen = new int[this.authorizationData.size()];
        this.adTypeTagLen = new int[this.authorizationData.size()];
        this.adDataTagLen = new int[this.authorizationData.size()];
        this.authorizationDataSeqSeqLen = 0;
        for (final AuthorizationDataEntry ad : this.authorizationData) {
            final int adTypeLen = BerValue.getNbBytes(ad.getAdType().getValue());
            this.adTypeTagLen[i] = 1 + TLV.getNbBytes(adTypeLen) + adTypeLen;
            this.adDataTagLen[i] = 1 + TLV.getNbBytes(ad.getAdDataRef().length) + ad.getAdDataRef().length;
            this.authorizationDataSeqLen[i] = 1 + TLV.getNbBytes(this.adTypeTagLen[i]) + this.adTypeTagLen[i] + 1 + TLV.getNbBytes(this.adDataTagLen[i]) + this.adDataTagLen[i];
            this.authorizationDataSeqSeqLen += 1 + TLV.getNbBytes(this.authorizationDataSeqLen[i]) + this.authorizationDataSeqLen[i];
            ++i;
        }
        return 1 + TLV.getNbBytes(this.authorizationDataSeqSeqLen) + this.authorizationDataSeqSeqLen;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.authorizationDataSeqSeqLen));
            int i = 0;
            for (final AuthorizationDataEntry ad : this.authorizationData) {
                buffer.put(UniversalTag.SEQUENCE.getValue());
                buffer.put(TLV.getBytes(this.authorizationDataSeqLen[i]));
                buffer.put((byte)(-96));
                buffer.put(TLV.getBytes(this.adTypeTagLen[i]));
                BerValue.encode(buffer, ad.getAdType().getValue());
                buffer.put((byte)(-95));
                buffer.put(TLV.getBytes(this.adDataTagLen[i]));
                BerValue.encode(buffer, ad.getAdDataRef());
                ++i;
            }
        }
        catch (BufferOverflowException boe) {
            AuthorizationData.LOG.error(I18n.err(I18n.ERR_139, new Object[] { 1 + TLV.getNbBytes(this.authorizationDataSeqSeqLen) + this.authorizationDataSeqSeqLen, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (AuthorizationData.IS_DEBUG) {
            AuthorizationData.LOG.debug("AuthorizationData encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            AuthorizationData.LOG.debug("AuthorizationData initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    public AuthorizationType getCurrentAdType() {
        return this.currentAD.getAdType();
    }
    
    public void setCurrentAdType(final AuthorizationType adType) {
        this.currentAD.setAdType(adType);
    }
    
    public byte[] getCurrentAdData() {
        return this.currentAD.getAdData();
    }
    
    public void setCurrentAdData(final byte[] adData) {
        this.currentAD.setAdData(adData);
    }
    
    public AuthorizationDataEntry getCurrentAD() {
        return this.currentAD;
    }
    
    public void createNewAD() {
        this.currentAD = new AuthorizationDataEntry();
        this.authorizationData.add(this.currentAD);
    }
    
    public void addEntry(final AuthorizationDataEntry entry) {
        this.authorizationData.add(entry);
    }
    
    public List<AuthorizationDataEntry> getAuthorizationData() {
        return this.authorizationData;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + ((this.authorizationData == null) ? 0 : this.authorizationData.hashCode());
        result = 31 * result + ((this.currentAD == null) ? 0 : this.currentAD.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj == null) {
            return false;
        }
        final AuthorizationData other = (AuthorizationData)obj;
        if (this.authorizationData == null) {
            if (other.authorizationData != null) {
                return false;
            }
        }
        else if (!this.authorizationData.equals(other.authorizationData)) {
            return false;
        }
        if (this.currentAD == null) {
            if (other.currentAD != null) {
                return false;
            }
        }
        else if (!this.currentAD.equals(other.currentAD)) {
            return false;
        }
        return true;
    }
    
    public String toString(final String tabs) {
        final StringBuilder sb = new StringBuilder();
        sb.append(tabs).append("AuthorizationData : \n");
        for (final AuthorizationDataEntry ad : this.authorizationData) {
            sb.append(ad.toString(tabs + "    "));
        }
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return this.toString("");
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncryptedData.class);
        IS_DEBUG = AuthorizationData.LOG.isDebugEnabled();
    }
}
