// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.changepwd.messages;

import org.apache.directory.api.asn1.EncoderException;
import java.nio.ByteBuffer;

public abstract class AbstractPasswordMessage
{
    public static final short PVNO = -128;
    public static final short OLD_PVNO = 1;
    static final int HEADER_LENGTH = 6;
    private short versionNumber;
    
    protected AbstractPasswordMessage(final short versionNumber) {
        this.versionNumber = versionNumber;
    }
    
    public short getVersionNumber() {
        return this.versionNumber;
    }
    
    public abstract short computeLength();
    
    public abstract ByteBuffer encode(final ByteBuffer p0) throws EncoderException;
}
