// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.changePwdData.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.changePwdData.ChangePasswdDataContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreTargName extends AbstractReadPrincipalName<ChangePasswdDataContainer>
{
    public StoreTargName() {
        super("Kerberos change password targetName");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final ChangePasswdDataContainer ticketContainer) {
        ticketContainer.getChngPwdData().setTargName(principalName);
        ticketContainer.setGrammarEndAllowed(true);
    }
}
