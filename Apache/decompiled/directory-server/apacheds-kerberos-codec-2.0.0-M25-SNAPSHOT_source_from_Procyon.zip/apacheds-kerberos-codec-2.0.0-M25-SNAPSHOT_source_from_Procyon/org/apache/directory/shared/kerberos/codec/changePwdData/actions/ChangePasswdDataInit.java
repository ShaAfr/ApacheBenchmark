// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.changePwdData.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.messages.ChangePasswdData;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.changePwdData.ChangePasswdDataContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class ChangePasswdDataInit extends GrammarAction<ChangePasswdDataContainer>
{
    private static final Logger LOG;
    
    public ChangePasswdDataInit() {
        super("Ticket initialization");
    }
    
    public void action(final ChangePasswdDataContainer chngPwdDataContainer) throws DecoderException {
        final TLV tlv = chngPwdDataContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            ChangePasswdDataInit.LOG.error(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
        }
        final ChangePasswdData chngPwdData = new ChangePasswdData();
        chngPwdDataContainer.setChngPwdData(chngPwdData);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)ChangePasswdDataInit.class);
    }
}
