// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.ticket;

import org.apache.directory.shared.kerberos.codec.ticket.actions.StoreEncPart;
import org.apache.directory.shared.kerberos.codec.ticket.actions.StoreSName;
import org.apache.directory.shared.kerberos.codec.ticket.actions.StoreRealm;
import org.apache.directory.shared.kerberos.codec.ticket.actions.StoreTktVno;
import org.apache.directory.api.asn1.actions.CheckNotNullLength;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.ticket.actions.TicketInit;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class TicketGrammar extends AbstractGrammar<TicketContainer>
{
    private static Grammar<TicketContainer> instance;
    
    private TicketGrammar() {
        this.setName(TicketGrammar.class.getName());
        super.transitions = new GrammarTransition[TicketStatesEnum.LAST_TICKET_STATE.ordinal()][256];
        super.transitions[TicketStatesEnum.START_STATE.ordinal()][97] = new GrammarTransition((Enum)TicketStatesEnum.START_STATE, (Enum)TicketStatesEnum.TICKET_STATE, 97, (Action)new TicketInit());
        super.transitions[TicketStatesEnum.TICKET_STATE.ordinal()][UniversalTag.SEQUENCE.getValue()] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_STATE, (Enum)TicketStatesEnum.TICKET_SEQ_STATE, UniversalTag.SEQUENCE, (Action)new CheckNotNullLength());
        super.transitions[TicketStatesEnum.TICKET_SEQ_STATE.ordinal()][160] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_SEQ_STATE, (Enum)TicketStatesEnum.TICKET_VNO_TAG_STATE, 160, (Action)new CheckNotNullLength());
        super.transitions[TicketStatesEnum.TICKET_VNO_TAG_STATE.ordinal()][UniversalTag.INTEGER.getValue()] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_VNO_TAG_STATE, (Enum)TicketStatesEnum.TICKET_VNO_STATE, UniversalTag.INTEGER, (Action)new StoreTktVno());
        super.transitions[TicketStatesEnum.TICKET_VNO_STATE.ordinal()][161] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_VNO_STATE, (Enum)TicketStatesEnum.TICKET_REALM_TAG_STATE, 161, (Action)new CheckNotNullLength());
        super.transitions[TicketStatesEnum.TICKET_REALM_TAG_STATE.ordinal()][UniversalTag.GENERAL_STRING.getValue()] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_REALM_TAG_STATE, (Enum)TicketStatesEnum.TICKET_REALM_STATE, UniversalTag.GENERAL_STRING, (Action)new StoreRealm());
        super.transitions[TicketStatesEnum.TICKET_REALM_STATE.ordinal()][162] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_REALM_STATE, (Enum)TicketStatesEnum.TICKET_SNAME_TAG_STATE, 162, (Action)new StoreSName());
        super.transitions[TicketStatesEnum.TICKET_SNAME_TAG_STATE.ordinal()][163] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_SNAME_TAG_STATE, (Enum)TicketStatesEnum.TICKET_ENC_PART_TAG_STATE, 163, (Action)new CheckNotNullLength());
        super.transitions[TicketStatesEnum.TICKET_SNAME_TAG_STATE.ordinal()][163] = new GrammarTransition((Enum)TicketStatesEnum.TICKET_SNAME_TAG_STATE, (Enum)TicketStatesEnum.TICKET_ENC_PART_TAG_STATE, 163, (Action)new StoreEncPart());
    }
    
    public static Grammar<TicketContainer> getInstance() {
        return TicketGrammar.instance;
    }
    
    static {
        TicketGrammar.instance = (Grammar<TicketContainer>)new TicketGrammar();
    }
}
