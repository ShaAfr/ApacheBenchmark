// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptionKey.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.EncryptionKey;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.encryptionKey.EncryptionKeyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class EncryptionKeyInit extends GrammarAction<EncryptionKeyContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public EncryptionKeyInit() {
        super("Creates a EncryptionKey instance");
    }
    
    public void action(final EncryptionKeyContainer encryptionKeyContainer) throws DecoderException {
        final TLV tlv = encryptionKeyContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            EncryptionKeyInit.LOG.error(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
        }
        final EncryptionKey encKey = new EncryptionKey();
        encryptionKeyContainer.setEncryptionKey(encKey);
        if (EncryptionKeyInit.IS_DEBUG) {
            EncryptionKeyInit.LOG.debug("EncryptionKey created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)EncryptionKeyInit.class);
        IS_DEBUG = EncryptionKeyInit.LOG.isDebugEnabled();
    }
}
