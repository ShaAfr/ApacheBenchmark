// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcRep;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import java.nio.ByteBuffer;
import org.apache.directory.shared.kerberos.components.KdcRep;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class KdcRepContainer extends AbstractContainer
{
    private KdcRep kdcRep;
    
    public KdcRepContainer(final ByteBuffer stream) {
        super(stream);
        this.setGrammar((Grammar)KdcRepGrammar.getInstance());
        this.setTransition((Enum)KdcRepStatesEnum.START_STATE);
    }
    
    public KdcRep getKdcRep() {
        return this.kdcRep;
    }
    
    public void setKdcRep(final KdcRep kdcRep) {
        this.kdcRep = kdcRep;
    }
}
