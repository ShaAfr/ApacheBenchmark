// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.server.kerberos.shared.keytab;

import java.nio.channels.WritableByteChannel;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.io.InputStream;
import org.apache.directory.server.i18n.I18n;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.Collections;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Keytab
{
    public static final byte[] VERSION_0X501_BYTES;
    public static final short VERSION_0X501 = 1281;
    public static final byte[] VERSION_0X502_BYTES;
    public static final short VERSION_0X502 = 1282;
    private byte[] keytabVersion;
    private List<KeytabEntry> entries;
    
    public Keytab() {
        this.keytabVersion = Keytab.VERSION_0X502_BYTES;
        this.entries = new ArrayList<KeytabEntry>();
    }
    
    public static Keytab read(final File file) throws IOException {
        final ByteBuffer buffer = ByteBuffer.wrap(getBytesFromFile(file));
        return readKeytab(buffer);
    }
    
    public static Keytab getInstance() {
        return new Keytab();
    }
    
    public void write(final File file) throws IOException {
        final KeytabEncoder writer = new KeytabEncoder();
        final ByteBuffer buffer = writer.write(this.keytabVersion, this.entries);
        this.writeFile(buffer, file);
    }
    
    public void setEntries(final List<KeytabEntry> entries) {
        this.entries = entries;
    }
    
    public void setKeytabVersion(final byte[] keytabVersion) {
        this.keytabVersion = keytabVersion;
    }
    
    public List<KeytabEntry> getEntries() {
        return Collections.unmodifiableList((List<? extends KeytabEntry>)this.entries);
    }
    
    public byte[] getKeytabVersion() {
        return this.keytabVersion;
    }
    
    static Keytab read(final byte[] bytes) throws IOException {
        final ByteBuffer buffer = ByteBuffer.wrap(bytes);
        return readKeytab(buffer);
    }
    
    ByteBuffer write() {
        final KeytabEncoder writer = new KeytabEncoder();
        return writer.write(this.keytabVersion, this.entries);
    }
    
    private static Keytab readKeytab(final ByteBuffer buffer) throws IOException {
        final KeytabDecoder reader = new KeytabDecoder();
        final byte[] keytabVersion = reader.getKeytabVersion(buffer);
        final List<KeytabEntry> entries = reader.getKeytabEntries(buffer);
        final Keytab keytab = new Keytab();
        keytab.setKeytabVersion(keytabVersion);
        keytab.setEntries(entries);
        return keytab;
    }
    
    protected static byte[] getBytesFromFile(final File file) throws IOException {
        try (final InputStream is = Files.newInputStream(file.toPath(), new OpenOption[0])) {
            final long length = file.length();
            if (length > 2147483647L) {
                throw new IOException(I18n.err(I18n.ERR_618, new Object[] { file.getName() }));
            }
            final byte[] bytes = new byte[(int)length];
            int offset = 0;
            for (int numRead = 0; offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0; offset += numRead) {}
            if (offset < bytes.length) {
                throw new IOException(I18n.err(I18n.ERR_619, new Object[] { file.getName() }));
            }
            return bytes;
        }
    }
    
    protected void writeFile(final ByteBuffer buffer, final File file) throws IOException {
        final OutputStream out = Files.newOutputStream(file.toPath(), new OpenOption[0]);
        try (final WritableByteChannel channel = Channels.newChannel(out)) {
            channel.write(buffer);
        }
        finally {
            out.close();
        }
    }
    
    static {
        VERSION_0X501_BYTES = new byte[] { 5, 1 };
        VERSION_0X502_BYTES = new byte[] { 5, 2 };
    }
}
