// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encryptionKey.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.encryptionKey.EncryptionKeyContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreKeyValue extends AbstractReadOctetString<EncryptionKeyContainer>
{
    public StoreKeyValue() {
        super("EncryptionKey's keyvalue");
    }
    
    protected void setOctetString(final byte[] data, final EncryptionKeyContainer encryptionKeyContainer) {
        encryptionKeyContainer.getEncryptionKey().setKeyValue(data);
        encryptionKeyContainer.setGrammarEndAllowed(true);
    }
}
