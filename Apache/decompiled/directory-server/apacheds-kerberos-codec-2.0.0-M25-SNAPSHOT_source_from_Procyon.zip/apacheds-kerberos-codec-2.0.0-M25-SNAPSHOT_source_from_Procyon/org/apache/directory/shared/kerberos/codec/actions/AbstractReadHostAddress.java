// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.codec.hostAddress.HostAddressContainer;
import org.apache.directory.api.asn1.ber.Asn1Decoder;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.i18n.I18n;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;
import org.apache.directory.api.asn1.ber.Asn1Container;

public abstract class AbstractReadHostAddress<E extends Asn1Container> extends GrammarAction<E>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public AbstractReadHostAddress(final String name) {
        super(name);
    }
    
    protected abstract void setAddress(final HostAddress p0, final E p1);
    
    public void action(final E container) throws DecoderException {
        final TLV tlv = container.getCurrentTLV();
        if (tlv.getLength() == 0) {
            AbstractReadHostAddress.LOG.error(I18n.err(I18n.ERR_04066, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_04067, new Object[0]));
        }
        final Asn1Decoder hostAddressDecoder = new Asn1Decoder();
        final HostAddressContainer hostAddressContainer = new HostAddressContainer();
        hostAddressContainer.setStream(container.getStream());
        try {
            hostAddressDecoder.decode(container.getStream(), (Asn1Container)hostAddressContainer);
        }
        catch (DecoderException de) {
            throw de;
        }
        final HostAddress hostAddress = hostAddressContainer.getHostAddress();
        tlv.setExpectedLength(tlv.getExpectedLength() - tlv.getLength());
        container.updateParent();
        this.setAddress(hostAddress, container);
        if (AbstractReadHostAddress.IS_DEBUG) {
            AbstractReadHostAddress.LOG.debug("HostAddress : {}", (Object)hostAddress);
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AbstractReadHostAddress.class);
        IS_DEBUG = AbstractReadHostAddress.LOG.isDebugEnabled();
    }
}
