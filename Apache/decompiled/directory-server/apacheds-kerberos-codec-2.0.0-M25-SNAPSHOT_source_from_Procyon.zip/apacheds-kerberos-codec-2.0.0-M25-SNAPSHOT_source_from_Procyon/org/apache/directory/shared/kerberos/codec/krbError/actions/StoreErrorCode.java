// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbError.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.exceptions.ErrorType;
import org.apache.directory.shared.kerberos.codec.krbError.KrbErrorContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreErrorCode extends AbstractReadInteger<KrbErrorContainer>
{
    public StoreErrorCode() {
        super("KRB-ERROR errorCode");
    }
    
    protected void setIntegerValue(final int value, final KrbErrorContainer krbErrorContainer) {
        final ErrorType errorCode = ErrorType.getTypeByValue(value);
        krbErrorContainer.getKrbError().setErrorCode(errorCode);
    }
}
