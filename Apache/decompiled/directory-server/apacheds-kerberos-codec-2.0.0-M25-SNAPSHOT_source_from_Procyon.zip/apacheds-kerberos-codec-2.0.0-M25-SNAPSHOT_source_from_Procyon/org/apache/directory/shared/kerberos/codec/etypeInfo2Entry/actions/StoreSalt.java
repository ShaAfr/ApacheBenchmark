// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.shared.kerberos.components.ETypeInfo2Entry;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.api.util.Strings;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.etypeInfo2Entry.ETypeInfo2EntryContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class StoreSalt extends GrammarAction<ETypeInfo2EntryContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public StoreSalt() {
        super("ETYPE-INFO2-ENTRY salt");
    }
    
    public void action(final ETypeInfo2EntryContainer eTypeInfo2EntryContainer) throws DecoderException {
        final TLV tlv = eTypeInfo2EntryContainer.getCurrentTLV();
        final ETypeInfo2Entry etypeInfo2Entry = eTypeInfo2EntryContainer.getETypeInfo2Entry();
        if (tlv.getLength() != 0) {
            final BerValue value = tlv.getValue();
            if (value.getData() != null) {
                final String salt = Strings.utf8ToString(value.getData());
                etypeInfo2Entry.setSalt(salt);
            }
        }
        if (StoreSalt.IS_DEBUG) {
            StoreSalt.LOG.debug("salt : {}", (Object)etypeInfo2Entry.getSalt());
        }
        eTypeInfo2EntryContainer.setGrammarEndAllowed(true);
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)StoreSalt.class);
        IS_DEBUG = StoreSalt.LOG.isDebugEnabled();
    }
}
