// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.encApRepPart.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.KerberosTime;
import org.apache.directory.shared.kerberos.codec.encApRepPart.EncApRepPartContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadKerberosTime;

public class StoreCTime extends AbstractReadKerberosTime<EncApRepPartContainer>
{
    public StoreCTime() {
        super("Stores the CTime");
    }
    
    @Override
    protected void setKerberosTime(final KerberosTime krbtime, final EncApRepPartContainer encApRepPartContainer) {
        encApRepPartContainer.getEncApRepPart().setCTime(krbtime);
    }
}
