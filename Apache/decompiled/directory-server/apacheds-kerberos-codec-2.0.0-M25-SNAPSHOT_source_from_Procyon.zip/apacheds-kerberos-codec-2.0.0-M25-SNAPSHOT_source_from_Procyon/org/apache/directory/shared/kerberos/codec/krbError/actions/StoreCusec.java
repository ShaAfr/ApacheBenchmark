// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbError.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.krbError.KrbErrorContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreCusec extends AbstractReadInteger<KrbErrorContainer>
{
    public StoreCusec() {
        super("KRB-ERROR cusec", 0, 999999);
    }
    
    protected void setIntegerValue(final int value, final KrbErrorContainer krbErrorContainer) {
        krbErrorContainer.getKrbError().setCusec(value);
    }
}
