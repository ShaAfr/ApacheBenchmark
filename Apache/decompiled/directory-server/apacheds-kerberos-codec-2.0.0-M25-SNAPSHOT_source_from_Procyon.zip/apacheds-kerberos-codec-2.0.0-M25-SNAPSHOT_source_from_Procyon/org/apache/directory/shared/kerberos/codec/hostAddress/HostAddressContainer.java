// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddress;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.api.asn1.ber.AbstractContainer;

public class HostAddressContainer extends AbstractContainer
{
    private HostAddress hostAddress;
    
    public HostAddressContainer() {
        this.setGrammar((Grammar)HostAddressGrammar.getInstance());
        this.setTransition((Enum)HostAddressStatesEnum.START_STATE);
    }
    
    public HostAddress getHostAddress() {
        return this.hostAddress;
    }
    
    public void setHostAddress(final HostAddress hostAddress) {
        this.hostAddress = hostAddress;
    }
}
