// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adKdcIssued.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.Checksum;
import org.apache.directory.shared.kerberos.codec.adKdcIssued.AdKdcIssuedContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadCheckSum;

public class StoreChecksum extends AbstractReadCheckSum<AdKdcIssuedContainer>
{
    public StoreChecksum() {
        super("AD-KDCIssued cksum");
    }
    
    @Override
    protected void setChecksum(final Checksum checksum, final AdKdcIssuedContainer adKdcIssuedContainer) {
        adKdcIssuedContainer.getAdKdcIssued().setAdChecksum(checksum);
    }
}
