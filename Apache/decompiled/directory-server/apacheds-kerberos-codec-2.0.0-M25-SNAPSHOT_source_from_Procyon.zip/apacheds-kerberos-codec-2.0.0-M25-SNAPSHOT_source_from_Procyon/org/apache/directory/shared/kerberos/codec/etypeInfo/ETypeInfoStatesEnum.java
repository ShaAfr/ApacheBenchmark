// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.etypeInfo;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum ETypeInfoStatesEnum implements States
{
    START_STATE, 
    ETYPE_INFO_SEQ_STATE, 
    LAST_ETYPE_INFO_STATE;
    
    public String getGrammarName(final int grammar) {
        return "ETYPE_INFO_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<ETypeInfoContainer> grammar) {
        if (grammar instanceof ETypeInfoGrammar) {
            return "ETYPE_INFO_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == ETypeInfoStatesEnum.LAST_ETYPE_INFO_STATE.ordinal()) ? "LAST_ETYPE_INFO_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == ETypeInfoStatesEnum.LAST_ETYPE_INFO_STATE;
    }
    
    public ETypeInfoStatesEnum getStartState() {
        return ETypeInfoStatesEnum.START_STATE;
    }
}
