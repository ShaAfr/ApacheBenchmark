// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReqBody.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.codec.kdcReqBody.KdcReqBodyContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class ETypeSequence extends GrammarAction<KdcReqBodyContainer>
{
    public ETypeSequence() {
        super("KDC-REQ-BODY EType sequence");
    }
    
    public void action(final KdcReqBodyContainer kdcReqBodyContainer) throws DecoderException {
        final TLV tlv = kdcReqBodyContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            kdcReqBodyContainer.setGrammarEndAllowed(true);
        }
    }
}
