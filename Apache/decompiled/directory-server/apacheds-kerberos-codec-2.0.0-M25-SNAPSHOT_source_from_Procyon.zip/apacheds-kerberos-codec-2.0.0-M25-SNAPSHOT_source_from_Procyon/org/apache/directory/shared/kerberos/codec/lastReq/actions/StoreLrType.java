// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.lastReq.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.LastReq;
import org.apache.directory.shared.kerberos.codec.types.LastReqType;
import org.apache.directory.shared.kerberos.codec.lastReq.LastReqContainer;
import org.apache.directory.api.asn1.actions.AbstractReadInteger;

public class StoreLrType extends AbstractReadInteger<LastReqContainer>
{
    public StoreLrType() {
        super("LastReq lrType");
    }
    
    protected void setIntegerValue(final int value, final LastReqContainer lastReqContainer) {
        final LastReqType lrType = LastReqType.getTypeByValue(value);
        final LastReq lastReq = lastReqContainer.getLastReq();
        lastReq.createNewLR();
        lastReq.setCurrentLrType(lrType);
    }
}
