// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.transitedEncoding.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.codec.transitedEncoding.TransitedEncodingContainer;
import org.apache.directory.api.asn1.actions.AbstractReadOctetString;

public class StoreContents extends AbstractReadOctetString<TransitedEncodingContainer>
{
    public StoreContents() {
        super("TransitedEncoding contents", true);
    }
    
    protected void setOctetString(final byte[] data, final TransitedEncodingContainer transitedEncodingContainer) {
        transitedEncodingContainer.getTransitedEncoding().setContents(data);
        transitedEncodingContainer.setGrammarEndAllowed(true);
    }
}
