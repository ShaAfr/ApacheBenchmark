// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.hostAddress.actions;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.components.HostAddress;
import org.apache.directory.api.asn1.DecoderException;
import org.apache.directory.server.i18n.I18n;
import org.slf4j.Logger;
import org.apache.directory.shared.kerberos.codec.hostAddress.HostAddressContainer;
import org.apache.directory.api.asn1.ber.grammar.GrammarAction;

public class HostAddressInit extends GrammarAction<HostAddressContainer>
{
    private static final Logger LOG;
    private static final boolean IS_DEBUG;
    
    public HostAddressInit() {
        super("Creates a HostAddress instance");
    }
    
    public void action(final HostAddressContainer hostAddressContainer) throws DecoderException {
        final TLV tlv = hostAddressContainer.getCurrentTLV();
        if (tlv.getLength() == 0) {
            HostAddressInit.LOG.error(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
            throw new DecoderException(I18n.err(I18n.ERR_744_NULL_PDU_LENGTH, new Object[0]));
        }
        final HostAddress hostAddress = new HostAddress();
        hostAddressContainer.setHostAddress(hostAddress);
        if (HostAddressInit.IS_DEBUG) {
            HostAddressInit.LOG.debug("HostAddress created");
        }
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)HostAddressInit.class);
        IS_DEBUG = HostAddressInit.LOG.isDebugEnabled();
    }
}
