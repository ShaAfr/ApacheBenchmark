// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.messages;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.util.Strings;
import java.nio.BufferOverflowException;
import org.apache.directory.api.asn1.ber.tlv.UniversalTag;
import org.apache.directory.api.asn1.EncoderException;
import org.apache.directory.server.i18n.I18n;
import java.nio.ByteBuffer;
import org.apache.directory.api.asn1.ber.tlv.BerValue;
import org.apache.directory.api.asn1.ber.tlv.TLV;
import org.apache.directory.shared.kerberos.KerberosMessageType;
import org.apache.directory.shared.kerberos.components.EncryptedData;
import org.slf4j.Logger;

public class KrbPriv extends KerberosMessage
{
    private static final Logger log;
    private static final boolean IS_DEBUG;
    private EncryptedData encPart;
    private int pvnoLen;
    private int msgTypeLength;
    private int encPartLen;
    private int krbPrivSeqLen;
    private int krbPrivLen;
    
    public KrbPriv() {
        super(5, KerberosMessageType.KRB_PRIV);
    }
    
    public EncryptedData getEncPart() {
        return this.encPart;
    }
    
    public void setEncPart(final EncryptedData encPart) {
        this.encPart = encPart;
    }
    
    public int computeLength() {
        this.pvnoLen = 3;
        this.krbPrivSeqLen = 1 + TLV.getNbBytes(this.pvnoLen) + this.pvnoLen;
        this.msgTypeLength = 2 + BerValue.getNbBytes(this.getMessageType().getValue());
        this.krbPrivSeqLen += 1 + TLV.getNbBytes(this.msgTypeLength) + this.msgTypeLength;
        this.encPartLen = this.encPart.computeLength();
        this.krbPrivSeqLen += 1 + TLV.getNbBytes(this.encPartLen) + this.encPartLen;
        this.krbPrivLen += 1 + TLV.getNbBytes(this.krbPrivSeqLen) + this.krbPrivSeqLen;
        return 1 + TLV.getNbBytes(this.krbPrivLen) + this.krbPrivLen;
    }
    
    public ByteBuffer encode(final ByteBuffer buffer) throws EncoderException {
        if (buffer == null) {
            throw new EncoderException(I18n.err(I18n.ERR_148, new Object[0]));
        }
        try {
            buffer.put((byte)117);
            buffer.put(TLV.getBytes(this.krbPrivLen));
            buffer.put(UniversalTag.SEQUENCE.getValue());
            buffer.put(TLV.getBytes(this.krbPrivSeqLen));
            buffer.put((byte)(-96));
            buffer.put(TLV.getBytes(this.pvnoLen));
            BerValue.encode(buffer, this.getProtocolVersionNumber());
            buffer.put((byte)(-95));
            buffer.put(TLV.getBytes(this.msgTypeLength));
            BerValue.encode(buffer, this.getMessageType().getValue());
            buffer.put((byte)(-93));
            buffer.put(TLV.getBytes(this.encPartLen));
            this.encPart.encode(buffer);
        }
        catch (BufferOverflowException boe) {
            KrbPriv.log.error(I18n.err(I18n.ERR_738_CANNOT_ENCODE_KRB_PRIV, new Object[] { 1 + TLV.getNbBytes(this.krbPrivLen) + this.krbPrivLen, buffer.capacity() }));
            throw new EncoderException(I18n.err(I18n.ERR_138, new Object[0]), (Exception)boe);
        }
        if (KrbPriv.IS_DEBUG) {
            KrbPriv.log.debug("KrbPriv encoding : {}", (Object)Strings.dumpBytes(buffer.array()));
            KrbPriv.log.debug("KrbPriv initial value : {}", (Object)this.toString());
        }
        return buffer;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("KRB-PRIV : {\n");
        sb.append("    pvno: ").append(this.getProtocolVersionNumber()).append('\n');
        sb.append("    msgType: ").append(this.getMessageType()).append('\n');
        sb.append("    msgType: ").append(this.getEncPart()).append('\n');
        sb.append("}\n");
        return sb.toString();
    }
    
    static {
        log = LoggerFactory.getLogger((Class)KrbError.class);
        IS_DEBUG = KrbPriv.log.isDebugEnabled();
    }
}
