// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.kdcReq;

import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.apache.directory.api.asn1.ber.grammar.States;

public enum KdcReqStatesEnum implements States
{
    START_STATE, 
    KDC_REQ_SEQ_STATE, 
    KDC_REQ_PVNO_TAG_STATE, 
    KDC_REQ_PVNO_STATE, 
    KDC_REQ_MSG_TYPE_TAG_STATE, 
    KDC_REQ_MSG_TYPE_STATE, 
    KDC_REQ_PA_DATA_OR_REQ_BODY_STATE, 
    KDC_REQ_PA_DATA_TAG_STATE, 
    KDC_REQ_PA_DATA_SEQ_STATE, 
    KDC_REQ_PA_DATA_STATE, 
    KDC_REQ_KDC_REQ_BODY_STATE, 
    LAST_KDC_REQ_STATE;
    
    public String getGrammarName(final int grammar) {
        return "KDC_REQ_GRAMMAR";
    }
    
    public String getGrammarName(final Grammar<KdcReqContainer> grammar) {
        if (grammar instanceof KdcReqGrammar) {
            return "KDC_REQ_GRAMMAR";
        }
        return "UNKNOWN GRAMMAR";
    }
    
    public String getState(final int state) {
        return (state == KdcReqStatesEnum.LAST_KDC_REQ_STATE.ordinal()) ? "KDC_REQ_END_STATE" : this.name();
    }
    
    public boolean isEndState() {
        return this == KdcReqStatesEnum.LAST_KDC_REQ_STATE;
    }
    
    public KdcReqStatesEnum getStartState() {
        return KdcReqStatesEnum.START_STATE;
    }
}
