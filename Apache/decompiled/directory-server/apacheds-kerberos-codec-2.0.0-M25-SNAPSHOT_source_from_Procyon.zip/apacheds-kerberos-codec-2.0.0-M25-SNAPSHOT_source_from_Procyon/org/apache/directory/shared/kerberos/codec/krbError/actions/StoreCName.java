// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.krbError.actions;

import org.apache.directory.api.asn1.ber.Asn1Container;
import org.apache.directory.shared.kerberos.components.PrincipalName;
import org.apache.directory.shared.kerberos.codec.krbError.KrbErrorContainer;
import org.apache.directory.shared.kerberos.codec.actions.AbstractReadPrincipalName;

public class StoreCName extends AbstractReadPrincipalName<KrbErrorContainer>
{
    public StoreCName() {
        super("KRB-ERROR cname");
    }
    
    @Override
    protected void setPrincipalName(final PrincipalName principalName, final KrbErrorContainer krbErrorContainer) {
        krbErrorContainer.getKrbError().setCName(principalName);
    }
}
