// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.adMandatoryForKdc;

import org.apache.directory.shared.kerberos.components.AuthorizationData;
import org.apache.directory.shared.kerberos.components.AdMandatoryForKdc;
import org.apache.directory.shared.kerberos.codec.authorizationData.AuthorizationDataContainer;

public class AdMandatoryForKdcContainer extends AuthorizationDataContainer
{
    public AdMandatoryForKdcContainer() {
        this.setAuthorizationData(new AdMandatoryForKdc());
    }
    
    public AdMandatoryForKdc getAdMandatoryForKdc() {
        return (AdMandatoryForKdc)this.getAuthorizationData();
    }
}
