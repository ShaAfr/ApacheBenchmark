// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.directory.shared.kerberos.codec.asRep;

import org.slf4j.LoggerFactory;
import org.apache.directory.api.asn1.ber.grammar.Action;
import org.apache.directory.shared.kerberos.codec.asRep.actions.StoreKdcRep;
import org.apache.directory.api.asn1.ber.grammar.GrammarTransition;
import org.apache.directory.api.asn1.ber.grammar.Grammar;
import org.slf4j.Logger;
import org.apache.directory.api.asn1.ber.grammar.AbstractGrammar;

public final class AsRepGrammar extends AbstractGrammar<AsRepContainer>
{
    static final Logger LOG;
    static final boolean IS_DEBUG;
    private static Grammar<AsRepContainer> instance;
    
    private AsRepGrammar() {
        this.setName(AsRepGrammar.class.getName());
        super.transitions = new GrammarTransition[AsRepStatesEnum.LAST_AS_REP_STATE.ordinal()][256];
        super.transitions[AsRepStatesEnum.START_STATE.ordinal()][107] = new GrammarTransition((Enum)AsRepStatesEnum.START_STATE, (Enum)AsRepStatesEnum.AS_REP_STATE, 107, (Action)new StoreKdcRep());
    }
    
    public static Grammar<AsRepContainer> getInstance() {
        return AsRepGrammar.instance;
    }
    
    static {
        LOG = LoggerFactory.getLogger((Class)AsRepGrammar.class);
        IS_DEBUG = AsRepGrammar.LOG.isDebugEnabled();
        AsRepGrammar.instance = (Grammar<AsRepContainer>)new AsRepGrammar();
    }
}
