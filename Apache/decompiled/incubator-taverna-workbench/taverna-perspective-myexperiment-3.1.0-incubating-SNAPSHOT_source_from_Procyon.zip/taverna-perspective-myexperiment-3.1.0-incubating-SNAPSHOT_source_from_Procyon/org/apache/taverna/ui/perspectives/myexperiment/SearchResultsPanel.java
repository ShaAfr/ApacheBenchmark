// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import java.util.Iterator;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import java.util.List;
import java.util.Collections;
import java.util.Collection;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.Icon;
import org.apache.taverna.workbench.icons.WorkbenchIcons;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import javax.swing.JPanel;

public class SearchResultsPanel extends JPanel
{
    public static final String NO_SEARCHES_STATUS = "No searches have been done so far";
    private MainComponent pluginMainComponent;
    private MyExperimentClient myExperimentClient;
    private Logger logger;
    private JLabel lStatusLabel;
    public JButton bRefresh;
    public JButton bClear;
    private JPanel jpResultsBody;
    private ActionListener alClickHandler;
    boolean bNoSearchesMadeYet;
    String strCurrentSearchTerm;
    HashMap<Integer, ArrayList<Resource>> hmSearchResults;
    
    public SearchResultsPanel(final ActionListener buttonClickHandler, final MainComponent component, final MyExperimentClient client, final Logger logger) {
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.alClickHandler = buttonClickHandler;
        this.bNoSearchesMadeYet = true;
        this.hmSearchResults = new HashMap<Integer, ArrayList<Resource>>();
        this.initialiseUI();
    }
    
    private void initialiseUI() {
        (this.lStatusLabel = new JLabel("No searches have been done so far")).setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
        final JPanel jpButtonsPanel = new JPanel();
        jpButtonsPanel.setLayout(new BoxLayout(jpButtonsPanel, 2));
        (this.bClear = new JButton("Clear", WorkbenchIcons.deleteIcon)).addActionListener(this.alClickHandler);
        this.bClear.setToolTipText("Click this button to clear the search results");
        this.bClear.setEnabled(false);
        jpButtonsPanel.add(this.bClear);
        (this.bRefresh = new JButton("Refresh", WorkbenchIcons.refreshIcon)).addActionListener(this.alClickHandler);
        this.bRefresh.setToolTipText("Click this button to refresh the search results");
        this.bRefresh.setEnabled(false);
        jpButtonsPanel.add(this.bRefresh);
        final JPanel jpStatusPanel = new JPanel(new BorderLayout());
        jpStatusPanel.setBorder(BorderFactory.createEtchedBorder());
        jpStatusPanel.add(this.lStatusLabel, "Center");
        jpStatusPanel.add(jpButtonsPanel, "East");
        (this.jpResultsBody = new JPanel()).setLayout(new BorderLayout());
        this.setLayout(new BorderLayout());
        this.add(jpStatusPanel, "North");
        this.add(this.jpResultsBody, "Center");
    }
    
    public void setCurrentSearchTerm(final String strSearchTerm) {
        this.strCurrentSearchTerm = strSearchTerm;
    }
    
    public String getCurrentSearchTerm() {
        return this.strCurrentSearchTerm;
    }
    
    public void setSearchResultsData(final HashMap<Integer, ArrayList<Resource>> hmResults) {
        this.bNoSearchesMadeYet = false;
        this.hmSearchResults = hmResults;
    }
    
    public void setStatus(final String status) {
        this.lStatusLabel.setText(status);
    }
    
    public void refresh() {
        this.jpResultsBody.removeAll();
        if (!this.bNoSearchesMadeYet) {
            final ArrayList<Integer> alResourceTypes = new ArrayList<Integer>(this.hmSearchResults.keySet());
            Collections.sort(alResourceTypes);
            if (alResourceTypes.isEmpty()) {
                this.jpResultsBody.add(new JLabel("No items to display"), "North");
                this.repaint();
            }
            else {
                final JTabbedPane tpResults = new JTabbedPane();
                for (final int iType : alResourceTypes) {
                    final String strTabLabel = Resource.getResourceTypeName(iType) + "s (" + this.hmSearchResults.get(iType).size() + ")";
                    final ResourceListPanel jpTabContents = new ResourceListPanel(this.pluginMainComponent, this.myExperimentClient, this.logger);
                    jpTabContents.setListItems(this.hmSearchResults.get(iType));
                    final JScrollPane spTabContents = new JScrollPane(jpTabContents);
                    spTabContents.getVerticalScrollBar().setUnitIncrement(10);
                    tpResults.add(strTabLabel, spTabContents);
                }
                this.jpResultsBody.add(tpResults, "Center");
                this.bClear.setEnabled(true);
                this.bRefresh.setEnabled(true);
            }
        }
        this.revalidate();
    }
    
    public void clear() {
        this.jpResultsBody.removeAll();
        this.repaint();
        this.revalidate();
    }
}
