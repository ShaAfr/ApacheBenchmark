// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import java.awt.event.ComponentEvent;
import javax.swing.event.CaretEvent;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;
import org.apache.taverna.ui.perspectives.myexperiment.model.ServerResponse;
import org.apache.taverna.ui.perspectives.myexperiment.model.Util;
import javax.swing.JRootPane;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import java.awt.Container;
import javax.swing.JScrollPane;
import java.awt.Component;
import java.awt.Insets;
import java.awt.GridBagConstraints;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import java.awt.Frame;
import javax.swing.JFrame;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import javax.swing.JLabel;
import javax.swing.JButton;
import org.apache.taverna.lang.ui.DialogTextArea;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import java.awt.event.KeyListener;
import java.awt.event.ComponentListener;
import javax.swing.event.CaretListener;
import java.awt.event.ActionListener;
import org.apache.taverna.workbench.helper.HelpEnabledDialog;

public class AddCommentDialog extends HelpEnabledDialog implements ActionListener, CaretListener, ComponentListener, KeyListener
{
    private MainComponent pluginMainComponent;
    private MyExperimentClient myExperimentClient;
    private Logger logger;
    private DialogTextArea taComment;
    private JButton bPost;
    private JButton bCancel;
    private JLabel lStatusMessage;
    private Resource resource;
    private String strComment;
    private boolean bPostingSuccessful;
    
    public AddCommentDialog(final JFrame owner, final Resource resource, final MainComponent component, final MyExperimentClient client, final Logger logger) {
        super((Frame)owner, "Add comment for \"" + resource.getTitle() + "\" " + resource.getItemTypeName(), true);
        this.strComment = null;
        this.bPostingSuccessful = false;
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.resource = resource;
        this.setDefaultCloseOperation(2);
        this.initialiseUI();
    }
    
    private void initialiseUI() {
        final Container contentPane = this.getContentPane();
        contentPane.setLayout(new GridBagLayout());
        final GridBagConstraints c = new GridBagConstraints();
        final JLabel lInfo = new JLabel("Please type in you comment:");
        c.gridx = 0;
        c.gridy = 0;
        c.anchor = 17;
        c.gridwidth = 2;
        c.fill = 0;
        c.insets = new Insets(10, 10, 5, 10);
        contentPane.add(lInfo, c);
        (this.taComment = new DialogTextArea(5, 35)).setLineWrap(true);
        this.taComment.setWrapStyleWord(true);
        this.taComment.addKeyListener((KeyListener)this);
        this.taComment.addCaretListener((CaretListener)this);
        final JScrollPane spComment = new JScrollPane((Component)this.taComment);
        c.gridy = 1;
        c.fill = 2;
        c.insets = new Insets(0, 10, 0, 10);
        contentPane.add(spComment, c);
        (this.bPost = new JButton("Post Comment")).setEnabled(false);
        this.bPost.setDefaultCapable(true);
        this.getRootPane().setDefaultButton(this.bPost);
        this.bPost.addActionListener(this);
        this.bPost.addKeyListener(this);
        c.gridy = 2;
        c.anchor = 13;
        c.gridwidth = 1;
        c.fill = 0;
        c.weightx = 0.5;
        c.insets = new Insets(10, 5, 10, 5);
        contentPane.add(this.bPost, c);
        (this.bCancel = new JButton("Cancel")).setPreferredSize(this.bPost.getPreferredSize());
        this.bCancel.addActionListener(this);
        c.gridx = 1;
        c.anchor = 17;
        c.weightx = 0.5;
        contentPane.add(this.bCancel, c);
        this.pack();
        this.setMinimumSize(this.getPreferredSize());
        this.setMaximumSize(this.getPreferredSize());
        this.addComponentListener((ComponentListener)this);
    }
    
    public String launchAddCommentDialogAndPostCommentIfRequired() {
        this.setVisible(true);
        return this.strComment;
    }
    
    public void actionPerformed(final ActionEvent e) {
        if (e.getSource().equals(this.bPost)) {
            this.strComment = this.taComment.getText();
            final JRootPane rootPane = this.getRootPane();
            final Container contentPane = this.getContentPane();
            contentPane.remove(this.bPost);
            contentPane.remove(this.bCancel);
            if (this.lStatusMessage != null) {
                contentPane.remove(this.lStatusMessage);
            }
            this.taComment.setEditable(false);
            final GridBagConstraints c = new GridBagConstraints();
            c.gridx = 0;
            c.gridy = 2;
            c.gridwidth = 2;
            c.anchor = 10;
            c.fill = 0;
            c.insets = new Insets(10, 5, 10, 5);
            contentPane.add(this.lStatusMessage = new JLabel("Posting your comment...", new ImageIcon(MyExperimentPerspective.getLocalResourceURL("spinner")), 0), c);
            this.setDefaultCloseOperation(0);
            this.pack();
            this.validate();
            this.repaint();
            new Thread("Posting comment") {
                @Override
                public void run() {
                    final ServerResponse response = AddCommentDialog.this.myExperimentClient.postComment(AddCommentDialog.this.resource, Util.stripAllHTML(AddCommentDialog.this.strComment));
                    AddCommentDialog.this.bPostingSuccessful = (response.getResponseCode() == 200);
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            if (AddCommentDialog.this.bPostingSuccessful) {
                                AddCommentDialog.this.setDefaultCloseOperation(2);
                                AddCommentDialog.this.taComment.setEnabled(false);
                                contentPane.remove(AddCommentDialog.this.lStatusMessage);
                                c.insets = new Insets(10, 5, 5, 5);
                                AddCommentDialog.this.lStatusMessage = new JLabel("Your comment was posted successfully", new ImageIcon(MyExperimentPerspective.getLocalResourceURL("success_icon")), 2);
                                contentPane.add(AddCommentDialog.this.lStatusMessage, c);
                                AddCommentDialog.this.bCancel.setText("OK");
                                AddCommentDialog.this.bCancel.setDefaultCapable(true);
                                rootPane.setDefaultButton(AddCommentDialog.this.bCancel);
                                c.insets = new Insets(5, 5, 10, 5);
                                final GridBagConstraints val$c = c;
                                ++val$c.gridy;
                                contentPane.add(AddCommentDialog.this.bCancel, c);
                                AddCommentDialog.this.pack();
                                AddCommentDialog.this.bCancel.requestFocusInWindow();
                            }
                            else {
                                AddCommentDialog.this.setDefaultCloseOperation(2);
                                AddCommentDialog.this.taComment.setEditable(true);
                                contentPane.remove(AddCommentDialog.this.lStatusMessage);
                                c.insets = new Insets(10, 5, 5, 5);
                                AddCommentDialog.this.lStatusMessage = new JLabel("Error occurred while posting comment: " + Util.retrieveReasonFromErrorXMLDocument(response.getResponseBody()), new ImageIcon(MyExperimentPerspective.getLocalResourceURL("failure_icon")), 2);
                                contentPane.add(AddCommentDialog.this.lStatusMessage, c);
                                AddCommentDialog.this.bPost.setText("Try again");
                                AddCommentDialog.this.bPost.setToolTipText("Please review your comment before trying to post it again");
                                c.anchor = 13;
                                c.insets = new Insets(5, 5, 10, 5);
                                c.gridwidth = 1;
                                c.weightx = 0.5;
                                c.gridx = 0;
                                final GridBagConstraints val$c2 = c;
                                ++val$c2.gridy;
                                contentPane.add(AddCommentDialog.this.bPost, c);
                                rootPane.setDefaultButton(AddCommentDialog.this.bPost);
                                c.anchor = 17;
                                c.gridx = 1;
                                AddCommentDialog.this.bCancel.setPreferredSize(AddCommentDialog.this.bPost.getPreferredSize());
                                contentPane.add(AddCommentDialog.this.bCancel, c);
                                AddCommentDialog.this.pack();
                                AddCommentDialog.this.validate();
                                AddCommentDialog.this.repaint();
                            }
                        }
                    });
                }
            }.start();
        }
        else if (e.getSource().equals(this.bCancel)) {
            if (!this.bPostingSuccessful) {
                this.strComment = null;
            }
            this.dispose();
        }
    }
    
    public void keyPressed(final KeyEvent e) {
        if (e.getSource().equals(this.taComment) && e.getKeyCode() == 9) {
            if ((e.getModifiersEx() & 0x40) == 0x40) {
                ((Component)e.getSource()).transferFocusBackward();
            }
            else {
                ((Component)e.getSource()).transferFocus();
            }
            e.consume();
        }
    }
    
    public void keyReleased(final KeyEvent e) {
    }
    
    public void keyTyped(final KeyEvent e) {
    }
    
    public void caretUpdate(final CaretEvent e) {
        this.bPost.setEnabled(this.taComment.getText().length() > 0);
    }
    
    public void componentShown(final ComponentEvent e) {
        Util.centerComponentWithinAnother(this.pluginMainComponent.getPreviewBrowser(), (Component)this);
    }
    
    public void componentHidden(final ComponentEvent e) {
    }
    
    public void componentMoved(final ComponentEvent e) {
    }
    
    public void componentResized(final ComponentEvent e) {
    }
}
