// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import javax.swing.JScrollPane;
import javax.swing.Icon;
import org.apache.taverna.workbench.icons.WorkbenchIcons;
import java.awt.Component;
import javax.swing.BorderFactory;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.util.Collection;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import org.apache.taverna.ui.perspectives.myexperiment.model.Workflow;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

public class ExampleWorkflowsPanel extends JPanel implements ActionListener, ChangeListener
{
    private static final String ACTION_REFRESH = "refresh_example_workflows";
    private MainComponent pluginMainComponent;
    private MyExperimentClient myExperimentClient;
    private Logger logger;
    private JLabel statusLabel;
    private JButton refreshButton;
    private List<Workflow> workflows;
    private ResourceListPanel workflowsListPanel;
    
    public ExampleWorkflowsPanel(final MainComponent component, final MyExperimentClient client, final Logger logger) {
        this.workflows = new ArrayList<Workflow>();
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.initialiseUI();
    }
    
    @Override
    public void actionPerformed(final ActionEvent event) {
        if ("refresh_example_workflows".equals(event.getActionCommand())) {
            this.refresh();
        }
    }
    
    @Override
    public void stateChanged(final ChangeEvent event) {
    }
    
    public void clear() {
        this.statusLabel.setText("");
        this.workflowsListPanel.clear();
    }
    
    public void refresh() {
        this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), "Fetching example workflows from myExperiment");
        this.statusLabel.setText("");
        new Thread("Refresh for ExampleWorkflowsPanel") {
            @Override
            public void run() {
                ExampleWorkflowsPanel.this.logger.debug((Object)"Refreshing Example Workflows tab");
                try {
                    ExampleWorkflowsPanel.this.workflows = ExampleWorkflowsPanel.this.myExperimentClient.getExampleWorkflows();
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            ExampleWorkflowsPanel.this.repopulate();
                        }
                    });
                }
                catch (Exception ex) {
                    ExampleWorkflowsPanel.this.logger.error((Object)"Failed to refresh Example Workflows panel", (Throwable)ex);
                }
            }
        }.start();
    }
    
    public void repopulate() {
        this.logger.debug((Object)"Repopulating Example Workflows tab");
        this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), null);
        this.statusLabel.setText("This will contain example resources to help get you started in Taverna.  Coming Soon.");
        this.statusLabel.setText(this.workflows.size() + " example workflows found");
        this.workflowsListPanel.setListItems(new ArrayList<Resource>(this.workflows));
        this.revalidate();
    }
    
    private void initialiseUI() {
        this.setLayout(new BorderLayout());
        final JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEtchedBorder());
        (this.statusLabel = new JLabel()).setBorder(BorderFactory.createEmptyBorder(0, 7, 0, 0));
        topPanel.add(this.statusLabel, "Center");
        (this.refreshButton = new JButton("Refresh", WorkbenchIcons.refreshIcon)).setActionCommand("refresh_example_workflows");
        this.refreshButton.addActionListener(this);
        this.refreshButton.setToolTipText("Click this button to refresh the Example Workflows list");
        topPanel.add(this.refreshButton, "East");
        this.add(topPanel, "North");
        this.workflowsListPanel = new ResourceListPanel(this.pluginMainComponent, this.myExperimentClient, this.logger);
        final JScrollPane spExampleWorkflowList = new JScrollPane(this.workflowsListPanel);
        spExampleWorkflowList.getVerticalScrollBar().setUnitIncrement(10);
        this.add(spExampleWorkflowList, "Center");
    }
}
