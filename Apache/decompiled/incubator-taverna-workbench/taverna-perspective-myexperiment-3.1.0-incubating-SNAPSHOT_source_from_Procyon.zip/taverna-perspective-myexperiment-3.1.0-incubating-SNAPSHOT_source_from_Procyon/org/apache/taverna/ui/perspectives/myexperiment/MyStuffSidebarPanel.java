// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import javax.swing.SwingUtilities;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;
import org.apache.taverna.ui.perspectives.myexperiment.model.User;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import org.apache.taverna.workbench.icons.WorkbenchIcons;
import java.awt.Dimension;
import java.util.EventListener;
import javax.swing.Icon;
import org.apache.taverna.ui.perspectives.myexperiment.model.Util;
import javax.swing.JLabel;
import java.awt.Container;
import javax.swing.BoxLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import org.apache.taverna.workbench.file.FileManager;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

public class MyStuffSidebarPanel extends JPanel implements ActionListener
{
    private final MainComponent pluginMainComponent;
    private final MyExperimentClient myExperimentClient;
    private final Logger logger;
    private final JPanel jpMyProfileBox;
    private final JPanel jpMyFriendsBox;
    private final JPanel jpMyGroupsBox;
    private final JPanel jpMyFavouritesBox;
    private final JPanel jpMyTagsBox;
    private JButton bLogout;
    protected JButton bRefreshMyStuff;
    private JButton bUpload;
    private final ImageIcon iconUser;
    private final ImageIcon iconLogout;
    private final FileManager fileManager;
    
    public MyStuffSidebarPanel(final MainComponent component, final MyExperimentClient client, final Logger logger, final FileManager fileManager) {
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.fileManager = fileManager;
        this.iconUser = new ImageIcon(MyExperimentPerspective.getLocalIconURL(20));
        this.iconLogout = new ImageIcon(MyExperimentPerspective.getLocalResourceURL("logout_icon"));
        this.setLayout(new GridBagLayout());
        final GridBagConstraints gbConstraints = new GridBagConstraints();
        gbConstraints.anchor = 18;
        gbConstraints.fill = 2;
        gbConstraints.weightx = 1.0;
        gbConstraints.gridx = 0;
        gbConstraints.gridy = 0;
        this.add(this.jpMyProfileBox = this.createMyProfileBox(), gbConstraints);
        gbConstraints.gridy = 1;
        this.add(this.jpMyFriendsBox = this.createMyFriendsBox(), gbConstraints);
        gbConstraints.gridy = 2;
        this.add(this.jpMyGroupsBox = this.createMyGroupsBox(), gbConstraints);
        gbConstraints.gridy = 3;
        this.jpMyFavouritesBox = this.createMyFavouritesBox();
        this.repopulateFavouritesBox();
        this.add(this.jpMyFavouritesBox, gbConstraints);
        gbConstraints.gridy = 4;
        this.add(this.jpMyTagsBox = this.createMyTagsBox(), gbConstraints);
        this.pluginMainComponent.getMyStuffTab().cdlComponentLoadingDone.countDown();
    }
    
    private JPanel createMyProfileBox() {
        final JPanel jpAvatar = new JPanel();
        jpAvatar.setLayout(new BoxLayout(jpAvatar, 0));
        final User currentUser = this.myExperimentClient.getCurrentUser();
        final ImageIcon userAvatar = currentUser.getAvatar();
        JLabel jlUserAvatar = new JLabel("No Profile Picture Found");
        if (userAvatar != null) {
            jlUserAvatar = new JLabel(Util.getResizedImageIcon(userAvatar, 80, 80));
        }
        jlUserAvatar.setAlignmentX(0.0f);
        jpAvatar.add(jlUserAvatar);
        String name = "<html>";
        for (int x = 0; x < currentUser.getName().split(" ").length; ++x) {
            name = name + currentUser.getName().split(" ")[x] + "<br>";
        }
        name += "</html>";
        final JClickableLabel jclUserName = new JClickableLabel(name, "preview:20:" + currentUser.getURI(), this.pluginMainComponent.getPreviewBrowser(), this.iconUser);
        jpAvatar.add(jclUserName);
        final JPanel jpEverythingInProfileBox = new JPanel();
        jpEverythingInProfileBox.setMaximumSize(new Dimension(1024, 0));
        jpEverythingInProfileBox.setLayout(new BoxLayout(jpEverythingInProfileBox, 0));
        jpEverythingInProfileBox.add(jpAvatar);
        (this.bLogout = new JButton("Logout", this.iconLogout)).addActionListener(this);
        (this.bRefreshMyStuff = new JButton("Refresh", WorkbenchIcons.refreshIcon)).addActionListener(this.pluginMainComponent.getMyStuffTab());
        (this.bUpload = new JButton("Upload Workflow", WorkbenchIcons.upArrowIcon)).addActionListener(this);
        final JPanel jpButtons = new JPanel();
        jpButtons.setLayout(new GridBagLayout());
        final GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = 1;
        gbc.gridy = 0;
        gbc.anchor = 11;
        gbc.fill = 1;
        gbc.gridx = 0;
        jpButtons.add(this.bUpload, gbc);
        final GridBagConstraints gridBagConstraints = gbc;
        ++gridBagConstraints.gridy;
        jpButtons.add(this.bRefreshMyStuff, gbc);
        final GridBagConstraints gridBagConstraints2 = gbc;
        ++gridBagConstraints2.gridy;
        jpButtons.add(this.bLogout, gbc);
        jpEverythingInProfileBox.add(jpButtons);
        jpEverythingInProfileBox.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), " My Profile "), BorderFactory.createEmptyBorder(1, 8, 8, 5)));
        return jpEverythingInProfileBox;
    }
    
    private JPanel createMyFriendsBox() {
        final JPanel jpFriends = new JPanel();
        jpFriends.setLayout(new BoxLayout(jpFriends, 1));
        final Iterator<HashMap<String, String>> iFriends = this.myExperimentClient.getCurrentUser().getFriends().iterator();
        if (iFriends.hasNext()) {
            while (iFriends.hasNext()) {
                final HashMap<String, String> hmCurFriend = iFriends.next();
                jpFriends.add(new JClickableLabel(hmCurFriend.get("name"), "preview:20:" + hmCurFriend.get("uri"), this.pluginMainComponent.getPreviewBrowser(), this.iconUser));
            }
        }
        else {
            final JLabel lNone = new JLabel("None");
            lNone.setFont(lNone.getFont().deriveFont(2));
            lNone.setForeground(Color.GRAY);
            jpFriends.add(lNone);
        }
        jpFriends.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), " My Friends "), BorderFactory.createEmptyBorder(1, 8, 8, 5)));
        return jpFriends;
    }
    
    private JPanel createMyGroupsBox() {
        final JPanel jpGroups = new JPanel();
        jpGroups.setLayout(new BoxLayout(jpGroups, 1));
        final ImageIcon iconGroup = new ImageIcon(MyExperimentPerspective.getLocalIconURL(21));
        final Iterator<HashMap<String, String>> iGroups = this.myExperimentClient.getCurrentUser().getGroups().iterator();
        if (iGroups.hasNext()) {
            while (iGroups.hasNext()) {
                final HashMap<String, String> hmCurGroup = iGroups.next();
                jpGroups.add(new JClickableLabel(hmCurGroup.get("name"), "preview:21:" + hmCurGroup.get("uri"), this.pluginMainComponent.getPreviewBrowser(), iconGroup));
            }
        }
        else {
            final JLabel lNone = new JLabel("None");
            lNone.setFont(lNone.getFont().deriveFont(2));
            lNone.setForeground(Color.GRAY);
            jpGroups.add(lNone);
        }
        jpGroups.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), " My Groups "), BorderFactory.createEmptyBorder(1, 8, 8, 5)));
        return jpGroups;
    }
    
    private JPanel createMyFavouritesBox() {
        final JPanel jpFavourites = new JPanel();
        jpFavourites.setLayout(new BoxLayout(jpFavourites, 1));
        jpFavourites.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), " My Favourites "), BorderFactory.createEmptyBorder(1, 8, 8, 5)));
        return jpFavourites;
    }
    
    public void repopulateFavouritesBox() {
        this.jpMyFavouritesBox.removeAll();
        final Iterator<Resource> iFavourites = this.myExperimentClient.getCurrentUser().getFavourites().iterator();
        if (iFavourites.hasNext()) {
            while (iFavourites.hasNext()) {
                final Resource rFavourite = iFavourites.next();
                this.jpMyFavouritesBox.add(new JClickableLabel(rFavourite.getTitle(), "preview:" + rFavourite.getItemType() + ":" + rFavourite.getURI(), this.pluginMainComponent.getPreviewBrowser(), new ImageIcon(MyExperimentPerspective.getLocalIconURL(rFavourite.getItemType()))));
            }
        }
        else {
            final JLabel lNone = new JLabel("None");
            lNone.setFont(lNone.getFont().deriveFont(2));
            lNone.setForeground(Color.GRAY);
            this.jpMyFavouritesBox.add(lNone);
        }
    }
    
    private JPanel createMyTagsBox() {
        final JPanel jpTags = new JPanel();
        jpTags.setLayout(new BoxLayout(jpTags, 1));
        final ImageIcon iconTag = new ImageIcon(MyExperimentPerspective.getLocalIconURL(30));
        final Iterator<HashMap<String, String>> iTags = this.myExperimentClient.getCurrentUser().getTags().iterator();
        if (iTags.hasNext()) {
            while (iTags.hasNext()) {
                final String strCurTag = iTags.next().get("name");
                jpTags.add(new JClickableLabel(strCurTag, "tag:" + strCurTag, this.pluginMainComponent.getPreviewBrowser(), iconTag));
            }
        }
        else {
            final JLabel lNone = new JLabel("None");
            lNone.setFont(lNone.getFont().deriveFont(2));
            lNone.setForeground(Color.GRAY);
            jpTags.add(lNone);
        }
        jpTags.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), " My Tags "), BorderFactory.createEmptyBorder(1, 8, 8, 5)));
        return jpTags;
    }
    
    public JPanel getMyProfileBox() {
        return this.jpMyProfileBox;
    }
    
    @Override
    public void actionPerformed(final ActionEvent e) {
        if (e.getSource().equals(this.bLogout)) {
            try {
                this.myExperimentClient.doLogout();
            }
            catch (Exception ex) {
                this.logger.error((Object)("Error while trying to logout from myExperiment, exception:\n" + ex));
            }
            this.pluginMainComponent.getStatusBar().setStatus(this.pluginMainComponent.getMyStuffTab().getClass().getName(), "Logging out");
            this.pluginMainComponent.getMyStuffTab().createAndInitialiseInnerComponents();
            this.pluginMainComponent.getMyStuffTab().revalidate();
            this.pluginMainComponent.getMyStuffTab().repaint();
            this.pluginMainComponent.getStatusBar().setStatus(this.pluginMainComponent.getMyStuffTab().getClass().getName(), null);
            this.pluginMainComponent.getStatusBar().setCurrentUser(null);
            this.pluginMainComponent.getTagBrowserTab().setMyTagsShown(false);
            this.pluginMainComponent.getTagBrowserTab().getTagSearchResultPanel().clear();
            this.pluginMainComponent.getTagBrowserTab().rerunLastTagSearch();
            this.pluginMainComponent.getSearchTab().getSearchResultPanel().clear();
            this.pluginMainComponent.getSearchTab().rerunLastSearch();
        }
        else if (e.getSource().equals(this.bUpload)) {
            final JFrame containingFrame = (JFrame)SwingUtilities.windowForComponent(this);
            final UploadWorkflowDialog uploadWorkflowDialog = new UploadWorkflowDialog(containingFrame, true, this.fileManager);
            if (uploadWorkflowDialog.launchUploadDialogAndPostIfRequired()) {
                this.actionPerformed(new ActionEvent(this.bRefreshMyStuff, 0, ""));
            }
        }
    }
}
