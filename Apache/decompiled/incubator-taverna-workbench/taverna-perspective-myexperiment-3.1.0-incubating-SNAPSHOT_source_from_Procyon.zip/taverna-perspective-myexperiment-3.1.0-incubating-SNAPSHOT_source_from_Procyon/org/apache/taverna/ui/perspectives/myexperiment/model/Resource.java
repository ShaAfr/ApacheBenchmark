// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import org.jdom.Element;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.border.Border;
import javax.swing.Action;
import javax.swing.JButton;
import java.awt.Container;
import javax.swing.BoxLayout;
import java.awt.Component;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Document;
import javax.swing.text.EditorKit;
import javax.swing.text.html.HTMLDocument;
import org.apache.taverna.ui.perspectives.myexperiment.StyledHTMLEditorKit;
import org.apache.taverna.ui.perspectives.myexperiment.MyExperimentPerspective;
import java.net.URI;
import javax.swing.JTextPane;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import org.apache.log4j.Logger;
import java.util.EventListener;
import org.apache.taverna.ui.perspectives.myexperiment.MainComponent;
import java.util.List;
import java.util.Iterator;
import java.util.Date;
import java.io.Serializable;

public class Resource implements Comparable<Resource>, Serializable
{
    public static final int UNEXPECTED_TYPE = -1;
    public static final int UNKNOWN = 0;
    public static final int WORKFLOW = 10;
    public static final int FILE = 11;
    public static final int PACK = 12;
    public static final int PACK_INTERNAL_ITEM = 14;
    public static final int PACK_EXTERNAL_ITEM = 15;
    public static final int USER = 20;
    public static final int GROUP = 21;
    public static final int TAG = 30;
    public static final int COMMENT = 31;
    public static final String WORKFLOW_VISIBLE_NAME = "Workflow";
    public static final String FILE_VISIBLE_NAME = "File";
    public static final String PACK_VISIBLE_NAME = "Pack";
    public static final String USER_VISIBLE_NAME = "User";
    public static final String GROUP_VISIBLE_NAME = "Group";
    public static final String TAG_VISIBLE_NAME = "Tag";
    public static final String COMMENT_VISIBLE_NAME = "Comment";
    public static final String UNKWNOWN_VISIBLE_NAME = "Unknown";
    public static final String UNEXPECTED_TYPE_VISIBLE_NAME = "ERROR: Unexpected unknown type!";
    public static final int ACCESS_VIEWING = 1000;
    public static final int ACCESS_DOWNLOADING = 1001;
    public static final int ACCESS_EDITING = 1002;
    public static final int REQUEST_ALL_DATA = 5000;
    public static final int REQUEST_FULL_PREVIEW = 5005;
    public static final int REQUEST_FULL_LISTING = 5010;
    public static final int REQUEST_SHORT_LISTING = 5015;
    public static final int REQUEST_USER_FAVOURITES_ONLY = 5050;
    public static final int REQUEST_USER_APPLIED_TAGS_ONLY = 5051;
    public static final int REQUEST_WORKFLOW_CONTENT_ONLY = 5055;
    public static final int REQUEST_DEFAULT_FROM_API = 5100;
    private int iID;
    private String uri;
    private String resource;
    private String title;
    private int itemType;
    private Date createdAt;
    private Date updatedAt;
    private String description;
    
    public int getID() {
        return this.iID;
    }
    
    public void setID(final int id) {
        this.iID = id;
    }
    
    public void setID(final String id) {
        this.iID = Integer.parseInt(id);
    }
    
    public String getURI() {
        return this.uri;
    }
    
    public String getResource() {
        return this.resource;
    }
    
    public int getItemType() {
        return this.itemType;
    }
    
    public String getItemTypeName() {
        return getResourceTypeName(this.itemType);
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public void setURI(final String uri) {
        this.uri = uri;
    }
    
    public void setResource(final String resource) {
        this.resource = resource;
    }
    
    public void setItemType(final int type) {
        this.itemType = type;
    }
    
    public void setItemType(final String type) {
        this.itemType = getResourceTypeFromVisibleName(type);
    }
    
    public void setTitle(final String title) {
        this.title = title;
    }
    
    public Date getCreatedAt() {
        return this.createdAt;
    }
    
    public void setCreatedAt(final Date createdAt) {
        this.createdAt = createdAt;
    }
    
    public Date getUpdatedAt() {
        return this.updatedAt;
    }
    
    public void setUpdatedAt(final Date updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @Override
    public String toString() {
        return "(" + this.getItemTypeName() + ", " + this.getURI() + "," + this.getTitle() + ")";
    }
    
    @Override
    public int compareTo(final Resource other) {
        final int iTypesCompared = this.getItemType() - other.getItemType();
        if (iTypesCompared == 0) {
            return this.getTitle().compareTo(other.getTitle());
        }
        return iTypesCompared;
    }
    
    @Override
    public boolean equals(final Object other) {
        if (!(other instanceof Resource)) {
            return false;
        }
        final Resource otherRes = (Resource)other;
        return this.itemType == otherRes.itemType && this.uri.equals(otherRes.uri) && this.resource.equals(otherRes.resource);
    }
    
    public boolean hasUploader() {
        return this.itemType == 10 || this.itemType == 11;
    }
    
    public User getUploader() {
        switch (this.itemType) {
            case 10: {
                return ((Workflow)this).getUploader();
            }
            case 11: {
                return ((File)this).getUploader();
            }
            default: {
                return null;
            }
        }
    }
    
    public boolean hasCreator() {
        return this.itemType == 12;
    }
    
    public User getCreator() {
        switch (this.itemType) {
            case 12: {
                return ((Pack)this).getCreator();
            }
            default: {
                return null;
            }
        }
    }
    
    public boolean hasAdmin() {
        return this.itemType == 21;
    }
    
    public User getAdmin() {
        switch (this.itemType) {
            case 21: {
                return ((Group)this).getAdmin();
            }
            default: {
                return null;
            }
        }
    }
    
    public boolean isFavouritable() {
        switch (this.itemType) {
            case 10:
            case 11:
            case 12: {
                return true;
            }
            default: {
                return false;
            }
        }
    }
    
    public boolean isFavouritedBy(final User user) {
        for (final Resource r : user.getFavourites()) {
            if (r.getURI().equals(this.getURI())) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isCommentableOn() {
        switch (this.itemType) {
            case 10:
            case 11:
            case 12:
            case 21: {
                return true;
            }
            default: {
                return false;
            }
        }
    }
    
    public List<Comment> getComments() {
        switch (this.itemType) {
            case 10: {
                return ((Workflow)this).getComments();
            }
            case 11: {
                return ((File)this).getComments();
            }
            case 12: {
                return ((Pack)this).getComments();
            }
            case 21: {
                return ((Group)this).getComments();
            }
            default: {
                return null;
            }
        }
    }
    
    public boolean isDownloadable() {
        return this.itemType == 10 || this.itemType == 11 || this.itemType == 12;
    }
    
    public boolean isDownloadAllowed() {
        int iAccessType = 0;
        switch (this.itemType) {
            case 10: {
                iAccessType = ((Workflow)this).getAccessType();
                break;
            }
            case 11: {
                iAccessType = ((File)this).getAccessType();
                break;
            }
            case 12: {
                iAccessType = ((Pack)this).getAccessType();
                break;
            }
            default: {
                iAccessType = 0;
                break;
            }
        }
        return iAccessType >= 1001;
    }
    
    public boolean hasVisibleType() {
        return this.itemType == 10 || this.itemType == 11;
    }
    
    public String getVisibleType() {
        switch (this.itemType) {
            case 10: {
                return ((Workflow)this).getVisibleType();
            }
            case 11: {
                return ((File)this).getVisibleType();
            }
            default: {
                return null;
            }
        }
    }
    
    public JPanel createListViewPanel(final boolean bCreateFullSizeView, final MainComponent pluginMainComponent, final EventListener eventHandler, final Logger logger) {
        try {
            final JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            final JTextPane infoTextPane = new JTextPane();
            infoTextPane.setBorder(BorderFactory.createEmptyBorder());
            infoTextPane.setEditable(false);
            final StringBuffer content = new StringBuffer();
            content.append("<div class='list_item_container'>");
            content.append("<div class='list_item'>");
            content.append("<p class='title'>");
            content.append("<a href='preview:" + this.getItemType() + ":" + this.getURI() + "'>" + this.getTitle() + ((this.getItemType() == 10) ? (" (version " + ((Workflow)this).getVersion() + ")") : "") + "</a>");
            content.append("</p>");
            if (bCreateFullSizeView) {
                if (this.hasUploader()) {
                    content.append("<p class='uploader'>");
                    content.append("Uploader: <a href='preview:20:" + this.getUploader().getURI() + "'>" + this.getUploader().getName() + "</a>");
                    content.append("</p>");
                }
                else if (this.hasCreator()) {
                    content.append("<p class='uploader'>");
                    content.append("Creator: <a href='preview:20:" + this.getCreator().getURI() + "'>" + this.getCreator().getName() + "</a>");
                    content.append("</p>");
                }
                else if (this.hasAdmin()) {
                    content.append("<p class='uploader'>");
                    content.append("Administrator: <a href='preview:20:" + this.getAdmin().getURI() + "'>" + this.getAdmin().getName() + "</a>");
                    content.append("</p>");
                }
                if (this.hasVisibleType()) {
                    content.append("<p class='uploader'>");
                    content.append("Type: " + this.getVisibleType());
                    content.append("</p>");
                }
            }
            content.append("<div class='desc'>");
            content.append("<table style='margin-top: 5px; margin-bottom: 5px;'>");
            content.append("<tr>");
            if (this.itemType == 10 || this.itemType == 20) {
                boolean bManualResizeNeeded = false;
                URI previewURI = null;
                if (this.itemType == 10) {
                    previewURI = ((Workflow)this).getThumbnail();
                }
                else if (this.itemType == 20 && ((User)this).getAvatarResource() != null) {
                    previewURI = new URI(((User)this).getAvatarResource());
                    bManualResizeNeeded = true;
                }
                content.append("<td valign='top'>");
                content.append("<a href='preview:" + this.itemType + ":" + this.getURI() + "'>");
                if (bCreateFullSizeView) {
                    if (!bManualResizeNeeded) {
                        content.append("<img class='preview' src='" + previewURI + "'></img>");
                    }
                    else {
                        final String resizedImageURL = Util.getResizedImageIconTempFileURL(previewURI.toURL(), 90, 90);
                        content.append("<img class='preview' src='" + resizedImageURL + "'></img>");
                    }
                }
                else {
                    final String resizedImageURL = Util.getResizedImageIconTempFileURL(previewURI.toURL(), 60, 45);
                    content.append("<img class='preview' src='" + resizedImageURL + "'></img>");
                }
                content.append("</a>");
                content.append("</td>");
            }
            content.append("<td>");
            content.append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
            content.append("</td>");
            content.append("<td valign='top' style='margin-bottom: 10px;'>");
            if (this.getDescription() != null && this.getDescription().length() > 0) {
                if (bCreateFullSizeView) {
                    content.append(this.getDescription());
                }
                else {
                    String strTruncatedDescription = this.getDescription();
                    if (strTruncatedDescription.length() > 150) {
                        strTruncatedDescription = strTruncatedDescription.substring(0, 150);
                        strTruncatedDescription += " ...";
                    }
                    content.append(strTruncatedDescription);
                }
            }
            else {
                content.append("<span class='none_text'>No description</span>");
            }
            content.append("</td>");
            content.append("</tr>");
            content.append("</table>");
            content.append("</div>");
            if (bCreateFullSizeView) {
                content.append("<p style='text-align: left;'><b><a href='" + this.getResource() + "'>Open in myExperiment</a></b>&nbsp;<img style='border: 0px;' src='" + MyExperimentPerspective.getLocalResourceURL("external_link_small_icon") + "' /></p>");
            }
            content.append("</div>");
            content.append("</div>");
            final HTMLEditorKit kit = new StyledHTMLEditorKit(pluginMainComponent.getStyleSheet());
            final HTMLDocument doc = (HTMLDocument)kit.createDefaultDocument();
            doc.insertAfterStart(doc.getRootElements()[0].getElement(0), content.toString());
            infoTextPane.setEditorKit(kit);
            infoTextPane.setDocument(doc);
            infoTextPane.setContentType("text/html");
            infoTextPane.addHyperlinkListener((HyperlinkListener)eventHandler);
            infoTextPane.setBorder(BorderFactory.createEmptyBorder(0, 0, 7, 0));
            mainPanel.add(infoTextPane, "Center");
            if (bCreateFullSizeView) {
                final JPanel jpButtonsPanel = new JPanel();
                jpButtonsPanel.setLayout(new BoxLayout(jpButtonsPanel, 2));
                final JButton button;
                final JButton previewButton = button = new JButton();
                pluginMainComponent.getClass();
                button.setAction(pluginMainComponent.new PreviewResourceAction(this.getItemType(), this.getURI()));
                jpButtonsPanel.add(previewButton);
                if (this.isDownloadable()) {
                    final JButton button2;
                    final JButton downloadButton = button2 = new JButton();
                    pluginMainComponent.getClass();
                    button2.setAction(pluginMainComponent.new DownloadResourceAction(this));
                    jpButtonsPanel.add(downloadButton);
                }
                if (this.getItemType() == 10) {
                    final JButton button3;
                    final JButton loadButton = button3 = new JButton();
                    pluginMainComponent.getClass();
                    button3.setAction(pluginMainComponent.new LoadResourceInTavernaAction(this));
                    jpButtonsPanel.add(loadButton);
                }
                if (this.getItemType() == 10) {
                    final JButton button4;
                    final JButton importButton = button4 = new JButton();
                    pluginMainComponent.getClass();
                    button4.setAction(pluginMainComponent.new ImportIntoTavernaAction(this));
                    jpButtonsPanel.add(importButton);
                }
                mainPanel.add(jpButtonsPanel, "South");
                jpButtonsPanel.setBackground(new Color(247, 247, 247));
                jpButtonsPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(235, 235, 235)), BorderFactory.createEmptyBorder(3, 3, 3, 3)));
            }
            if (bCreateFullSizeView) {
                mainPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5), BorderFactory.createLineBorder(Color.GRAY)));
            }
            else {
                mainPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
            }
            return mainPanel;
        }
        catch (Exception e) {
            logger.error((Object)("Failed while creating " + this.getItemTypeName() + " list view:\n" + e));
            return null;
        }
    }
    
    public static String getResourceTypeName(final int resourceTypeCode) {
        switch (resourceTypeCode) {
            case 10: {
                return "Workflow";
            }
            case 11: {
                return "File";
            }
            case 12: {
                return "Pack";
            }
            case 20: {
                return "User";
            }
            case 21: {
                return "Group";
            }
            case 30: {
                return "Tag";
            }
            case 31: {
                return "Comment";
            }
            case 0: {
                return "Unknown";
            }
            default: {
                return "ERROR: Unexpected unknown type!";
            }
        }
    }
    
    public static int getResourceTypeFromVisibleName(final String name) {
        if (name.toLowerCase().equals("Workflow".toLowerCase())) {
            return 10;
        }
        if (name.toLowerCase().equals("File".toLowerCase())) {
            return 11;
        }
        if (name.toLowerCase().equals("Pack".toLowerCase())) {
            return 12;
        }
        if (name.toLowerCase().equals("User".toLowerCase())) {
            return 20;
        }
        if (name.toLowerCase().equals("Group".toLowerCase())) {
            return 21;
        }
        if (name.toLowerCase().equals("Tag".toLowerCase())) {
            return 30;
        }
        if (name.toLowerCase().equals("Comment".toLowerCase())) {
            return 31;
        }
        return 0;
    }
    
    public static Resource buildFromXML(final org.jdom.Document resourceXMLDocument, final MyExperimentClient client, final Logger logger) {
        final Element root = resourceXMLDocument.getRootElement();
        return buildFromXML(root, client, logger);
    }
    
    public static Resource buildFromXML(final Element docRootElement, final MyExperimentClient client, final Logger logger) {
        Resource res = null;
        switch (getResourceTypeFromVisibleName(docRootElement.getName())) {
            case 10: {
                res = Workflow.buildFromXML(docRootElement, logger);
                break;
            }
            case 11: {
                res = File.buildFromXML(docRootElement, logger);
                break;
            }
            case 12: {
                res = Pack.buildFromXML(docRootElement, client, logger);
                break;
            }
            case 20: {
                res = User.buildFromXML(docRootElement, logger);
                break;
            }
            case 21: {
                res = Group.buildFromXML(docRootElement, logger);
                break;
            }
        }
        return res;
    }
}
