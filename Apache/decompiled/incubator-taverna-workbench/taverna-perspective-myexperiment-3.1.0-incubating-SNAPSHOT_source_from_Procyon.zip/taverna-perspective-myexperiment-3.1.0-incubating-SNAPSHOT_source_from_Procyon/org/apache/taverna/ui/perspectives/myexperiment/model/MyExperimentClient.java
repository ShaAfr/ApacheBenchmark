// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.Date;
import java.util.Collection;
import java.util.Comparator;
import java.util.Collections;
import java.util.HashMap;
import java.util.ArrayList;
import org.jdom.Element;
import javax.swing.ImageIcon;
import org.xml.sax.InputSource;
import org.jdom.input.SAXBuilder;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import org.jdom.Document;
import java.awt.Component;
import javax.swing.JOptionPane;
import org.apache.taverna.security.credentialmanager.CMException;
import java.net.URI;
import org.apache.taverna.security.credentialmanager.UsernamePassword;
import java.io.Serializable;
import org.apache.taverna.ui.perspectives.myexperiment.MainComponent;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.FileInputStream;
import org.apache.taverna.configuration.app.ApplicationConfiguration;
import org.apache.taverna.security.credentialmanager.CredentialManager;
import org.apache.log4j.Logger;
import java.util.Properties;
import java.io.File;
import java.text.DateFormat;

public class MyExperimentClient
{
    public static final String DEFAULT_BASE_URL = "http://www.myexperiment.org";
    public static final String PLUGIN_USER_AGENT;
    private static final String INI_FILE_NAME = "myexperiment-plugin.ini";
    private static final int EXAMPLE_WORKFLOWS_PACK_ID = 254;
    public static final String INI_BASE_URL = "my_experiment_base_url";
    public static final String INI_AUTO_LOGIN = "auto_login";
    public static final String INI_FAVOURITE_SEARCHES = "favourite_searches";
    public static final String INI_SEARCH_HISTORY = "search_history";
    public static final String INI_TAG_SEARCH_HISTORY = "tag_search_history";
    public static final String INI_PREVIEWED_ITEMS_HISTORY = "previewed_items_history";
    public static final String INI_OPENED_ITEMS_HISTORY = "opened_items_history";
    public static final String INI_UPLOADED_ITEMS_HISTORY = "uploaded_items_history";
    public static final String INI_DOWNLOADED_ITEMS_HISTORY = "downloaded_items_history";
    public static final String INI_COMMENTED_ITEMS_HISTORY = "commented_items_history";
    public static final String INI_DEFAULT_LOGGED_IN_TAB = "default_tab_for_logged_in_users";
    public static final String INI_DEFAULT_ANONYMOUS_TAB = "default_tab_for_anonymous_users";
    public static final String INI_MY_STUFF_WORKFLOWS = "show_workflows_in_my_stuff";
    public static final String INI_MY_STUFF_FILES = "show_files_in_my_stuff";
    public static final String INI_MY_STUFF_PACKS = "show_packs_in_my_stuff";
    private final String DO_PUT = "_DO_UPDATE_SIGNAL_";
    public static boolean baseChangedSinceLastStart;
    private static final DateFormat OLD_DATE_FORMATTER;
    private static final DateFormat OLD_SHORT_DATE_FORMATTER;
    private static final DateFormat NEW_DATE_FORMATTER;
    private String BASE_URL;
    private File fIniFileDir;
    private Properties iniSettings;
    private Logger logger;
    private boolean LOGGED_IN;
    private String AUTH_STRING;
    private User current_user;
    private CredentialManager credentialManager;
    
    public MyExperimentClient(final CredentialManager credentialManager, final ApplicationConfiguration applicationConfig) {
        this.logger = Logger.getLogger((Class)MyExperimentClient.class);
        this.LOGGED_IN = false;
        this.AUTH_STRING = "";
        this.current_user = null;
        this.credentialManager = credentialManager;
        this.fIniFileDir = new File(applicationConfig.getApplicationHomeDir().toFile(), "conf");
        this.iniSettings = new Properties();
        this.loadSettings();
        if (this.BASE_URL == null || this.BASE_URL.length() == 0) {
            this.BASE_URL = "http://www.myexperiment.org";
        }
        this.iniSettings.put("my_experiment_base_url", this.BASE_URL);
    }
    
    public boolean isLoggedIn() {
        return this.LOGGED_IN;
    }
    
    public String getBaseURL() {
        return this.BASE_URL;
    }
    
    public void setBaseURL(final String baseURL) {
        this.BASE_URL = baseURL;
    }
    
    public User getCurrentUser() {
        return this.current_user;
    }
    
    public void setCurrentUser(final User user) {
        this.current_user = user;
    }
    
    public Properties getSettings() {
        return this.iniSettings;
    }
    
    public synchronized void loadSettings() {
        try {
            final FileInputStream fIniInputStream = new FileInputStream(new File(this.fIniFileDir, "myexperiment-plugin.ini"));
            this.iniSettings.load(fIniInputStream);
            fIniInputStream.close();
            this.BASE_URL = this.iniSettings.getProperty("my_experiment_base_url");
        }
        catch (FileNotFoundException e2) {
            this.logger.debug((Object)"myExperiment plugin INI file was not found, defaults will be used.");
        }
        catch (IOException e) {
            this.logger.error((Object)("Error on reading settings from INI file:\n" + e));
        }
    }
    
    private void storeSettings() {
        try {
            this.fIniFileDir.mkdirs();
            final FileOutputStream fIniOutputStream = new FileOutputStream(new File(this.fIniFileDir, "myexperiment-plugin.ini"));
            this.iniSettings.store(fIniOutputStream, "Test comment");
            fIniOutputStream.close();
        }
        catch (IOException e) {
            this.logger.error((Object)("Error while trying to store settings to INI file:\n" + e));
        }
    }
    
    public void storeHistoryAndSettings() {
        this.iniSettings.put("favourite_searches", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getSearchTab().getSearchFavouritesList()));
        this.iniSettings.put("search_history", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getSearchTab().getSearchHistory()));
        this.iniSettings.put("tag_search_history", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getTagBrowserTab().getTagSearchHistory()));
        this.iniSettings.put("previewed_items_history", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getPreviewBrowser().getPreviewHistory()));
        this.iniSettings.put("downloaded_items_history", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getHistoryBrowser().getDownloadedItemsHistoryList()));
        this.iniSettings.put("opened_items_history", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getHistoryBrowser().getOpenedItemsHistoryList()));
        this.iniSettings.put("uploaded_items_history", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getHistoryBrowser().getUploadedItemsHistoryList()));
        this.iniSettings.put("commented_items_history", Base64.encodeObject(MainComponent.MAIN_COMPONENT.getHistoryBrowser().getCommentedOnItemsHistoryList()));
        this.storeSettings();
    }
    
    private UsernamePassword getUserPass(final String urlString) {
        try {
            final URI userpassUrl = URI.create(urlString);
            final UsernamePassword userAndPass = this.credentialManager.getUsernameAndPasswordForService(userpassUrl, true, (String)null);
            return userAndPass;
        }
        catch (CMException e) {
            throw new RuntimeException("Error in Taverna Credential Manager", (Throwable)e);
        }
    }
    
    public boolean doLogin() {
        ServerResponse response = null;
        Document doc = null;
        try {
            response = this.doMyExperimentGET(this.BASE_URL + "/whoami.xml");
        }
        catch (Exception e) {
            this.logger.error((Object)("Error while attempting to verify login credentials from INI file:\n" + e));
        }
        if (response.getResponseCode() == 401) {
            try {
                final List<URI> toDelete = (List<URI>)this.credentialManager.getServiceURIsForAllUsernameAndPasswordPairs();
                for (final URI uri : toDelete) {
                    if (uri.toASCIIString().startsWith(this.BASE_URL)) {
                        this.credentialManager.deleteUsernameAndPasswordForService(uri);
                    }
                }
                doc = null;
            }
            catch (Exception e) {
                this.logger.error((Object)e);
            }
        }
        else {
            doc = response.getResponseBody();
        }
        if (doc == null) {
            this.LOGGED_IN = false;
            this.AUTH_STRING = "";
            this.iniSettings.put("auto_login", new Boolean(false).toString());
            JOptionPane.showMessageDialog(null, "Your myExperiment login details appear to be incorrect.\nPlease check your details.");
            return false;
        }
        final UsernamePassword userPass = this.getUserPass(this.BASE_URL + "/whoami.xml");
        if (userPass == null) {
            return false;
        }
        this.LOGGED_IN = true;
        this.AUTH_STRING = Base64.encodeBytes((userPass.getUsername() + ":" + userPass.getPasswordAsString()).getBytes());
        final String strCurrentUserURI = doc.getRootElement().getAttributeValue("uri");
        try {
            this.current_user = this.fetchCurrentUser(strCurrentUserURI);
            this.logger.debug((Object)"Logged in to myExperiment successfully with credentials that were loaded from INI file.");
            return true;
        }
        catch (Exception e2) {
            this.logger.error((Object)("Couldn't fetch user data from myExperiment (" + strCurrentUserURI + ")"), (Throwable)e2);
            return false;
        }
    }
    
    public void doLogout() throws Exception {
        this.LOGGED_IN = false;
        this.AUTH_STRING = "";
    }
    
    public ServerResponse doMyExperimentGET(final String strURL) throws Exception {
        final URL url = new URL(strURL);
        final HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestProperty("User-Agent", MyExperimentClient.PLUGIN_USER_AGENT);
        if (this.LOGGED_IN) {
            conn.setRequestProperty("Authorization", "Basic " + this.AUTH_STRING);
        }
        return this.doMyExperimentReceiveServerResponse(conn, strURL, true);
    }
    
    public ServerResponse doMyExperimentPOST(String strURL, final String strXMLDataBody) throws Exception {
        if (!this.LOGGED_IN) {
            return null;
        }
        final URL url = new URL(strURL);
        final HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
        urlConn.setRequestMethod(strURL.contains("_DO_UPDATE_SIGNAL_") ? "PUT" : "POST");
        strURL = strURL.replace("_DO_UPDATE_SIGNAL_", "");
        urlConn.setDoOutput(true);
        urlConn.setRequestProperty("Content-Type", "application/xml");
        urlConn.setRequestProperty("User-Agent", MyExperimentClient.PLUGIN_USER_AGENT);
        urlConn.setRequestProperty("Authorization", "Basic " + this.AUTH_STRING);
        final String strPOSTContent = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" + strXMLDataBody;
        final OutputStreamWriter out = new OutputStreamWriter(urlConn.getOutputStream());
        out.write(strPOSTContent);
        out.close();
        return this.doMyExperimentReceiveServerResponse(urlConn, strURL, false);
    }
    
    public ServerResponse doMyExperimentDELETE(final String strURL) throws Exception {
        final URL url = new URL(strURL);
        final HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("DELETE");
        conn.setRequestProperty("User-Agent", MyExperimentClient.PLUGIN_USER_AGENT);
        conn.setRequestProperty("Authorization", "Basic " + this.AUTH_STRING);
        return this.doMyExperimentReceiveServerResponse(conn, strURL, true);
    }
    
    private ServerResponse doMyExperimentReceiveServerResponse(final HttpURLConnection conn, final String strURL, final boolean bIsGETRequest) throws Exception {
        final int iResponseCode = conn.getResponseCode();
        switch (iResponseCode) {
            case 200: {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                final Document doc = new SAXBuilder().build(new InputSource(reader));
                reader.close();
                return new ServerResponse(iResponseCode, doc);
            }
            case 400: {
                final BufferedReader errorReader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                final Document errorDoc = new SAXBuilder().build(new InputSource(errorReader));
                errorReader.close();
                return new ServerResponse(iResponseCode, errorDoc);
            }
            case 401: {
                return new ServerResponse(iResponseCode, null);
            }
            default: {
                throw new IOException("Received unexpected HTTP response code (" + conn.getResponseCode() + ") while " + (bIsGETRequest ? "fetching data at " : "posting data to ") + strURL);
            }
        }
    }
    
    public User fetchCurrentUser(final String uri) {
        User user = null;
        try {
            final Document doc = this.getResource(20, uri, 5005);
            user = User.buildFromXML(doc, this.logger);
        }
        catch (Exception ex) {
            this.logger.error((Object)("Failed to fetch user data from myExperiment (" + uri + "); exception:\n" + ex));
        }
        try {
            if (user.getAvatarURI() == null) {
                final ImageIcon icon = new ImageIcon(user.getAvatarResource());
                user.setAvatar(icon);
            }
            else {
                final Document doc = this.doMyExperimentGET(user.getAvatarURI()).getResponseBody();
                user.setAvatar(doc);
            }
        }
        catch (Exception ex) {
            this.logger.error((Object)("Failed to fetch user's avatar from myExperiment (" + user.getAvatarURI() + "); exception:\n" + ex));
        }
        return user;
    }
    
    public Document getResource(final int iResourceType, String strURI, final int iRequestType) throws Exception {
        if (iRequestType == 5000) {
            strURI += "&all_elements=yes";
        }
        else {
            switch (iResourceType) {
                case 10: {
                    strURI = strURI + "&elements=" + Workflow.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 11: {
                    strURI = strURI + "&elements=" + org.apache.taverna.ui.perspectives.myexperiment.model.File.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 12: {
                    strURI = strURI + "&elements=" + Pack.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 14: {
                    strURI += "&all_elements=yes";
                    break;
                }
                case 15: {
                    strURI += "&all_elements=yes";
                    break;
                }
                case 20: {
                    strURI = strURI + "&elements=" + User.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 21: {
                    strURI = strURI + "&elements=" + Group.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 30: {
                    strURI = strURI + "&elements=" + Tag.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 31: {
                    strURI = strURI + "&elements=" + Comment.getRequiredAPIElements(iRequestType);
                    break;
                }
            }
        }
        return this.doMyExperimentGET(strURI).getResponseBody();
    }
    
    public Workflow fetchWorkflowBinary(final String strWorkflowURI) throws Exception {
        final Document doc = this.getResource(10, strWorkflowURI, 5055);
        final Element root = doc.getRootElement();
        final Workflow w = new Workflow();
        w.setVisibleType(root.getChildText("type"));
        w.setContentType(root.getChildText("content-type"));
        if (!w.isTavernaWorkflow()) {
            throw new Exception("Unsupported workflow type. Details:\nWorkflow type: " + w.getVisibleType() + "\nMime type: " + w.getContentType());
        }
        final String strEncoding = root.getChild("content").getAttributeValue("encoding");
        final String strDataFormat = root.getChild("content").getAttributeValue("type");
        if (!strEncoding.toLowerCase().equals("base64") || !strDataFormat.toLowerCase().equals("binary")) {
            throw new Exception("Unsupported workflow data format. Details:\nContent encoding: " + strEncoding + "\nFormat: " + strDataFormat);
        }
        final byte[] arrWorkflowData = Base64.decode(root.getChildText("content"));
        w.setContent(arrWorkflowData);
        return w;
    }
    
    public List<Workflow> getExampleWorkflows() {
        final List<Workflow> workflows = new ArrayList<Workflow>();
        try {
            final String strExampleWorkflowsPackUrl = this.BASE_URL + "/pack.xml?id=" + 254 + "&elements=internal-pack-items";
            final Document doc = this.doMyExperimentGET(strExampleWorkflowsPackUrl).getResponseBody();
            if (doc != null) {
                final List<Element> allInternalItems = (List<Element>)doc.getRootElement().getChild("internal-pack-items").getChildren("workflow");
                for (final Element e : allInternalItems) {
                    final String itemUri = e.getAttributeValue("uri");
                    final Document itemDoc = this.doMyExperimentGET(itemUri).getResponseBody();
                    final String workflowUri = itemDoc.getRootElement().getChild("item").getChild("workflow").getAttributeValue("uri");
                    final Document docCurWorkflow = this.getResource(10, workflowUri, 5010);
                    workflows.add(Workflow.buildFromXML(docCurWorkflow, this.logger));
                }
            }
        }
        catch (Exception e2) {
            this.logger.error((Object)"Failed to retrieve example workflows", (Throwable)e2);
        }
        this.logger.debug((Object)(workflows.size() + " example workflows retrieved from myExperiment"));
        return workflows;
    }
    
    public TagCloud getGeneralTagCloud(final int size) {
        final TagCloud tcCloud = new TagCloud();
        try {
            final String strTagCloudURL = this.BASE_URL + "/tag-cloud.xml?num=" + ((size > 0) ? ("" + size) : "all");
            final Document doc = this.doMyExperimentGET(strTagCloudURL).getResponseBody();
            if (doc != null) {
                final List<Element> nodes = (List<Element>)doc.getRootElement().getChildren("tag");
                for (final Element e : nodes) {
                    final Tag t = new Tag();
                    t.setTitle(e.getText());
                    t.setTagName(e.getText());
                    t.setResource(e.getAttributeValue("resource"));
                    t.setURI(e.getAttributeValue("uri"));
                    t.setCount(Integer.parseInt(e.getAttributeValue("count")));
                    tcCloud.getTags().add(t);
                }
            }
        }
        catch (Exception e2) {
            this.logger.error((Object)"ERROR: Failed to get tag cloud.\n", (Throwable)e2);
        }
        this.logger.debug((Object)("Tag cloud retrieval successful; fetched " + tcCloud.getTags().size() + " tags from myExperiment"));
        return tcCloud;
    }
    
    public TagCloud getUserTagCloud(final User user, int size) {
        final TagCloud tcCloud = new TagCloud();
        try {
            synchronized (user.getTags()) {
                user.getTags().clear();
                final Document doc = this.getResource(20, user.getURI(), 5051);
                final Iterator<Element> iNewUserTags = doc.getRootElement().getChild("tags-applied").getChildren().iterator();
                Util.getResourceCollectionFromXMLIterator(iNewUserTags, user.getTags());
            }
            final Iterator<HashMap<String, String>> iTagsResourcesHashMaps = user.getTags().iterator();
            while (iTagsResourcesHashMaps.hasNext()) {
                final String strCurTagURI = iTagsResourcesHashMaps.next().get("uri");
                final Document doc2 = this.doMyExperimentGET(strCurTagURI).getResponseBody();
                final Element root = doc2.getRootElement();
                final Tag t = new Tag();
                t.setTagName(root.getChild("name").getText());
                t.setCount(Integer.parseInt(root.getChild("count").getText()));
                tcCloud.getTags().add(t);
            }
            if (size <= 0) {
                size = tcCloud.getTags().size();
            }
            final Comparator<Tag> byPopularity = new Tag.ReversePopularityComparator();
            Collections.sort(tcCloud.getTags(), byPopularity);
            int iSelectedTags = 0;
            final List<Tag> tagListOfRequiredSize = new ArrayList<Tag>();
            for (Iterator<Tag> iTags = tcCloud.getTags().iterator(); iTags.hasNext() && iSelectedTags < size; ++iSelectedTags) {
                tagListOfRequiredSize.add(iTags.next());
            }
            tcCloud.getTags().clear();
            tcCloud.getTags().addAll(tagListOfRequiredSize);
            final Comparator<Tag> byAlphabet = new Tag.AlphanumericComparator();
            Collections.sort(tcCloud.getTags(), byAlphabet);
        }
        catch (Exception e) {
            this.logger.error((Object)("Failed midway through fetching user tags for user ID = " + user.getID() + "\n" + e));
        }
        return tcCloud;
    }
    
    public Document getUserContributions(final User user, final int iResourceType, final int iRequestType, final int page) {
        Document doc = null;
        String strURL = this.BASE_URL;
        String strElements = "&elements=";
        try {
            switch (iResourceType) {
                case 10: {
                    strURL += "/workflows.xml?uploader=";
                    strElements += Workflow.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 11: {
                    strURL += "/files.xml?uploader=";
                    strElements += org.apache.taverna.ui.perspectives.myexperiment.model.File.getRequiredAPIElements(iRequestType);
                    break;
                }
                case 12: {
                    strURL += "/packs.xml?owner=";
                    strElements += Workflow.getRequiredAPIElements(iRequestType);
                    break;
                }
            }
            if (page != 0) {
                strElements = strElements + "&num=100&page=" + page;
            }
            strURL = strURL + urlEncodeQuery(user.getResource()) + strElements;
            doc = this.doMyExperimentGET(strURL).getResponseBody();
        }
        catch (Exception e) {
            this.logger.error((Object)"ERROR: Failed to fetch user's contributions.");
        }
        return doc;
    }
    
    public Document searchByTag(final String strTag) {
        Document doc = null;
        try {
            final String strUrlEncodedTag = urlEncodeQuery(strTag);
            doc = this.doMyExperimentGET(this.BASE_URL + "/tagged.xml?tag=" + strUrlEncodedTag + Util.composeAPIQueryElements(null)).getResponseBody();
        }
        catch (Exception e) {
            this.logger.error((Object)("ERROR: Failed to fetch tagged items from myExperiment. Query tag was '" + strTag + "'\n" + e));
        }
        return doc;
    }
    
    public void convertTagListIntoTagCloudData(final List<Tag> tags) {
        try {
            Document doc = null;
            for (final Tag t : tags) {
                doc = this.getResource(30, t.getURI(), 5000);
                final Element rootElement = doc.getRootElement();
                t.setCount(Integer.parseInt(rootElement.getChild("count").getText()));
            }
        }
        catch (Exception e) {
            this.logger.error((Object)"Failed while getting tag application counts when turning tag list into tag cloud data", (Throwable)e);
        }
    }
    
    public void updateUserFavourites(final User user) {
        try {
            final Document doc = this.getResource(20, user.getURI(), 5050);
            final List<Resource> newUserFavouritesList = Util.retrieveUserFavourites(doc.getRootElement());
            user.getFavourites().clear();
            user.getFavourites().addAll(newUserFavouritesList);
        }
        catch (Exception ex) {
            this.logger.error((Object)("Failed to fetch favourites data from myExperiment for a user (URI: " + user.getURI() + "); exception:\n" + ex));
            JOptionPane.showMessageDialog(null, "Couldn't synchronise data about your favourite items with myExperiment.\nYou might not be able to add / remove other items to your favourites and.\nPlease refresh your profile data manually by clicking 'Refresh' button in 'My Stuff' tab.", "myExperiment Plugin - Error", 0);
        }
    }
    
    public void updateCommentListWithExtraData(final List<Comment> comments) {
        try {
            Document doc = null;
            for (final Comment c : comments) {
                doc = this.getResource(31, c.getURI(), 5000);
                final Element rootElement = doc.getRootElement();
                final Element userElement = rootElement.getChild("author");
                final User u = new User();
                u.setTitle(userElement.getText());
                u.setName(userElement.getText());
                u.setResource(userElement.getAttributeValue("resource"));
                u.setURI(userElement.getAttributeValue("uri"));
                c.setUser(u);
                final String createdAt = rootElement.getChildText("created-at");
                if (createdAt != null && !createdAt.equals("")) {
                    c.setCreatedAt(parseDate(createdAt));
                }
            }
        }
        catch (Exception e) {
            this.logger.error((Object)"Failed while updating comment list for preview", (Throwable)e);
        }
    }
    
    public Document searchByQuery(final SearchEngine.QuerySearchInstance searchQuery) {
        Document doc = null;
        String strSearchURL = null;
        try {
            final String strUrlEncodedQuery = urlEncodeQuery(searchQuery.getSearchQuery());
            String strSearchFor = "";
            if (searchQuery.getSearchWorkflows()) {
                strSearchFor += "workflow";
            }
            if (searchQuery.getSearchFiles()) {
                strSearchFor += ",file";
            }
            if (searchQuery.getSearchPacks()) {
                strSearchFor += ",pack";
            }
            if (searchQuery.getSearchUsers()) {
                strSearchFor += ",user";
            }
            if (searchQuery.getSearchGroups()) {
                strSearchFor += ",group";
            }
            if (strSearchFor.length() != 0) {
                if (strSearchFor.startsWith(",")) {
                    strSearchFor = strSearchFor.replaceFirst(",", "");
                }
                strSearchFor = "type=" + strSearchFor;
            }
            String strParameters = strSearchFor;
            if (strParameters.length() != 0) {
                strParameters += "&";
            }
            strParameters = strParameters + "num=" + searchQuery.getResultCountLimit();
            strParameters += Util.composeAPIQueryElements(searchQuery);
            strSearchURL = this.BASE_URL + "/search.xml?query=" + strUrlEncodedQuery + "&" + strParameters;
            doc = this.doMyExperimentGET(strSearchURL).getResponseBody();
        }
        catch (Exception e) {
            this.logger.error((Object)("ERROR: Failed to run search on myExperiment. Query URL was'" + strSearchURL + "'\n" + e));
        }
        return doc;
    }
    
    public ServerResponse postComment(final Resource resource, final String strComment) {
        try {
            final String strCommentData = "<comment><subject resource=\"" + resource.getResource() + "\"/><comment>" + strComment + "</comment></comment>";
            final ServerResponse response = this.doMyExperimentPOST(this.BASE_URL + "/comment.xml", strCommentData);
            if (response.getResponseCode() == 200) {
                final Comment cNew = Comment.buildFromXML(response.getResponseBody(), this.logger);
                resource.getComments().add(cNew);
            }
            return response;
        }
        catch (Exception e) {
            this.logger.error((Object)("Failed while trying to post a comment for " + resource.getURI() + "\n" + e));
            return new ServerResponse(ServerResponse.LOCAL_FAILURE, null);
        }
    }
    
    private String prepareWorkflowPostContent(final String workflowContent, final String title, final String description, final String license, final String sharing) {
        String strWorkflowData = "<workflow>";
        if (title.length() > 0) {
            strWorkflowData = strWorkflowData + "<title>" + title + "</title>";
        }
        if (description.length() > 0) {
            strWorkflowData = strWorkflowData + "<description>" + description + "</description>";
        }
        if (license.length() > 0) {
            strWorkflowData = strWorkflowData + "<license-type>" + license + "</license-type>";
        }
        if (sharing.length() > 0) {
            if (sharing.contains("private")) {
                strWorkflowData += "<permissions />";
            }
            else {
                strWorkflowData += "<permissions><permission><category>public</category>";
                if (sharing.contains("view") || sharing.contains("download")) {
                    strWorkflowData += "<privilege type=\"view\" />";
                }
                if (sharing.contains("download")) {
                    strWorkflowData += "<privilege type=\"download\" />";
                }
                strWorkflowData += "</permission></permissions>";
            }
        }
        String encodedWorkflow = "";
        final String scuflSchemaDef = "xmlns:s=\"http://org.embl.ebi.escience/xscufl/0.1alpha\"";
        final String t2flowSchemaDef = "xmlns=\"http://taverna.sf.net/2008/xml/t2flow\"";
        if (workflowContent.length() > 0) {
            String contentType;
            if (workflowContent.contains(scuflSchemaDef)) {
                contentType = "application/vnd.taverna.scufl+xml";
            }
            else if (workflowContent.contains(t2flowSchemaDef)) {
                contentType = "application/vnd.taverna.t2flow+xml";
            }
            else {
                contentType = "";
            }
            encodedWorkflow = encodedWorkflow + "<content-type>" + contentType + "</content-type><content encoding=\"base64\" type=\"binary\">" + Base64.encodeBytes(workflowContent.getBytes()) + "</content>";
            strWorkflowData += encodedWorkflow;
        }
        strWorkflowData += "</workflow>";
        return strWorkflowData;
    }
    
    private void afterMyExperimentPost(final ServerResponse response) {
    }
    
    public ServerResponse postWorkflow(final String workflowContent, final String title, final String description, final String license, final String sharing) {
        try {
            final String strWorkflowData = this.prepareWorkflowPostContent(workflowContent, title, description, license, sharing);
            final ServerResponse response = this.doMyExperimentPOST(this.BASE_URL + "/workflow.xml", strWorkflowData);
            this.afterMyExperimentPost(response);
            return response;
        }
        catch (Exception e) {
            this.logger.error((Object)"Failed while trying to upload the workflow");
            return new ServerResponse(ServerResponse.LOCAL_FAILURE, null);
        }
    }
    
    public ServerResponse updateWorkflowVersionOrMetadata(final Resource resource, final String workflowContent, final String title, final String description, final String license, final String sharing) {
        try {
            final String strWorkflowData = this.prepareWorkflowPostContent(workflowContent, title, description, license, sharing);
            final String doUpdateStatus = (workflowContent.length() == 0) ? "_DO_UPDATE_SIGNAL_" : "";
            final ServerResponse response = this.doMyExperimentPOST(this.BASE_URL + "/workflow.xml?id=" + resource.getID() + doUpdateStatus, strWorkflowData);
            this.afterMyExperimentPost(response);
            return response;
        }
        catch (Exception e) {
            this.logger.error((Object)"Failed while trying to upload the workflow");
            return new ServerResponse(ServerResponse.LOCAL_FAILURE, null);
        }
    }
    
    public ServerResponse addFavourite(final Resource resource) {
        try {
            final String strData = "<favourite><object resource=\"" + resource.getResource() + "\"/></favourite>";
            final ServerResponse response = this.doMyExperimentPOST(this.BASE_URL + "/favourite.xml", strData);
            return response;
        }
        catch (Exception e) {
            this.logger.error((Object)("Failed while trying to add an item (" + resource.getURI() + ") to favourites4"), (Throwable)e);
            return new ServerResponse(ServerResponse.LOCAL_FAILURE, null);
        }
    }
    
    public ServerResponse deleteFavourite(final Resource resource) {
        try {
            final String strGetFavouriteObjectURL = this.BASE_URL + "/favourites.xml?user=" + urlEncodeQuery(this.getCurrentUser().getResource()) + "&object=" + urlEncodeQuery(resource.getResource());
            ServerResponse response = this.doMyExperimentGET(strGetFavouriteObjectURL);
            final Element root = response.getResponseBody().getRootElement();
            final String strFavouriteURI = root.getChild("favourite").getAttributeValue("uri");
            response = this.doMyExperimentDELETE(strFavouriteURI);
            return response;
        }
        catch (Exception e) {
            this.logger.error((Object)("Failed while trying to remove an item (" + resource.getURI() + ") from favourites\n" + e));
            return new ServerResponse(ServerResponse.LOCAL_FAILURE, null);
        }
    }
    
    public static Date parseDate(final String date) {
        Date result = null;
        try {
            result = MyExperimentClient.OLD_DATE_FORMATTER.parse(date);
        }
        catch (ParseException e) {
            try {
                result = MyExperimentClient.OLD_SHORT_DATE_FORMATTER.parse(date);
            }
            catch (ParseException e2) {
                try {
                    result = MyExperimentClient.NEW_DATE_FORMATTER.parse(date);
                }
                catch (ParseException e3) {
                    result = null;
                }
            }
        }
        return result;
    }
    
    public static String formatDate(final Date date) {
        return MyExperimentClient.NEW_DATE_FORMATTER.format(date);
    }
    
    private static String urlEncodeQuery(final String query) {
        String strRes = "";
        try {
            strRes = URLEncoder.encode(query, "UTF-8");
        }
        catch (UnsupportedEncodingException ex) {}
        return strRes;
    }
    
    static {
        PLUGIN_USER_AGENT = "Taverna2-myExperiment-plugin/0.2beta Java/" + System.getProperty("java.version");
        MyExperimentClient.baseChangedSinceLastStart = false;
        OLD_DATE_FORMATTER = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.ENGLISH);
        OLD_SHORT_DATE_FORMATTER = new SimpleDateFormat("HH:mm 'on' dd/MM/yyyy", Locale.ENGLISH);
        NEW_DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z");
    }
}
