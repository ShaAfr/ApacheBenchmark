// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import org.jdom.Document;
import javax.swing.SwingUtilities;
import java.util.Iterator;
import java.awt.Dimension;
import java.util.List;
import java.util.Collection;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import org.apache.taverna.ui.perspectives.myexperiment.model.Pack;
import org.apache.taverna.ui.perspectives.myexperiment.model.File;
import org.jdom.Element;
import org.apache.taverna.ui.perspectives.myexperiment.model.Workflow;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Component;
import org.apache.taverna.lang.ui.ShadedLabel;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import java.util.ArrayList;
import javax.swing.JScrollPane;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

public class MyStuffContributionsPanel extends JPanel implements ActionListener
{
    private static final int SHADED_LABEL_HEIGHT = 20;
    private static final int SECTION_VSPACING = 5;
    private static final int SCROLL_PANE_PADDING = 3;
    private static final int TOTAL_SECTION_VSPACING = 33;
    private MainComponent pluginMainComponent;
    private MyExperimentClient myExperimentClient;
    private Logger logger;
    JPanel jpMyWorkflows;
    JPanel jpMyFiles;
    JPanel jpMyPacks;
    ResourceListPanel jpMyWorkflowsContent;
    ResourceListPanel jpMyFilesContent;
    ResourceListPanel jpMyPacksContent;
    JScrollPane spMyWorkflowsContent;
    JScrollPane spMyFilesContent;
    JScrollPane spMyPacksContent;
    private ArrayList<JPanel> alVisiblePanels;
    private ArrayList<JComponent[]> alVisiblePanelsWithHelperElements;
    
    public MyStuffContributionsPanel(final MainComponent component, final MyExperimentClient client, final Logger logger) {
        this.jpMyWorkflowsContent = null;
        this.jpMyFilesContent = null;
        this.jpMyPacksContent = null;
        this.spMyWorkflowsContent = null;
        this.spMyFilesContent = null;
        this.spMyPacksContent = null;
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.alVisiblePanels = new ArrayList<JPanel>();
        this.alVisiblePanelsWithHelperElements = new ArrayList<JComponent[]>();
        if (this.myExperimentClient.getSettings().getProperty("show_workflows_in_my_stuff") == null) {
            this.myExperimentClient.getSettings().put("show_workflows_in_my_stuff", new Boolean(true).toString());
        }
        if (this.myExperimentClient.getSettings().getProperty("show_files_in_my_stuff") == null) {
            this.myExperimentClient.getSettings().put("show_files_in_my_stuff", new Boolean(true).toString());
        }
        if (this.myExperimentClient.getSettings().getProperty("show_packs_in_my_stuff") == null) {
            this.myExperimentClient.getSettings().put("show_packs_in_my_stuff", new Boolean(true).toString());
        }
        this.initialiseUI();
        this.initialiseData();
    }
    
    private void initialiseUI() {
        final JPanel jpMyWorkflowsContainer = new JPanel();
        jpMyWorkflowsContainer.setBorder(BorderFactory.createEmptyBorder());
        if (Boolean.parseBoolean(this.myExperimentClient.getSettings().getProperty("show_workflows_in_my_stuff"))) {
            jpMyWorkflowsContainer.setBorder(BorderFactory.createEtchedBorder());
            jpMyWorkflowsContainer.setLayout(new BorderLayout());
            final ShadedLabel l0 = new ShadedLabel("My Workflows", ShadedLabel.BLUE);
            jpMyWorkflowsContainer.add((Component)l0, "North");
            (this.jpMyWorkflows = new JPanel()).setLayout(new BorderLayout());
            this.jpMyWorkflows.setBackground(Color.WHITE);
            this.jpMyWorkflows.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
            this.jpMyWorkflows.add(new JLabel("Loading...", new ImageIcon(MyExperimentPerspective.getLocalResourceURL("spinner")), 0));
            jpMyWorkflowsContainer.add(this.jpMyWorkflows, "Center");
            this.alVisiblePanels.add(this.jpMyWorkflows);
        }
        final JPanel jpMyFilesContainer = new JPanel();
        if (Boolean.parseBoolean(this.myExperimentClient.getSettings().getProperty("show_files_in_my_stuff"))) {
            jpMyFilesContainer.setBorder(BorderFactory.createEtchedBorder());
            jpMyFilesContainer.setLayout(new BorderLayout());
            final ShadedLabel l2 = new ShadedLabel("My Files", ShadedLabel.BLUE);
            jpMyFilesContainer.add((Component)l2, "North");
            (this.jpMyFiles = new JPanel()).setLayout(new BorderLayout());
            this.jpMyFiles.setBackground(Color.WHITE);
            this.jpMyFiles.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
            this.jpMyFiles.add(new JLabel("Loading...", new ImageIcon(MyExperimentPerspective.getLocalResourceURL("spinner")), 0));
            jpMyFilesContainer.add(this.jpMyFiles, "Center");
            this.alVisiblePanels.add(this.jpMyFiles);
        }
        final JPanel jpMyPacksContainer = new JPanel();
        if (Boolean.parseBoolean(this.myExperimentClient.getSettings().getProperty("show_packs_in_my_stuff"))) {
            jpMyPacksContainer.setBorder(BorderFactory.createEtchedBorder());
            jpMyPacksContainer.setLayout(new BorderLayout());
            final ShadedLabel l3 = new ShadedLabel("My Packs", ShadedLabel.BLUE);
            jpMyPacksContainer.add((Component)l3, "North");
            (this.jpMyPacks = new JPanel()).setLayout(new BorderLayout());
            this.jpMyPacks.setBackground(Color.WHITE);
            this.jpMyPacks.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
            this.jpMyPacks.add(new JLabel("Loading...", new ImageIcon(MyExperimentPerspective.getLocalResourceURL("spinner")), 0));
            jpMyPacksContainer.add(this.jpMyPacks, "Center");
            this.alVisiblePanels.add(this.jpMyPacks);
        }
        final JPanel jpEverything = new JPanel();
        jpEverything.setLayout(new GridBagLayout());
        final GridBagConstraints gbConstraints = new GridBagConstraints();
        gbConstraints.anchor = 18;
        gbConstraints.fill = 1;
        gbConstraints.gridx = 0;
        gbConstraints.weightx = 1.0;
        gbConstraints.weighty = 1.0;
        int index = 0;
        gbConstraints.gridy = index++;
        jpEverything.add(jpMyWorkflowsContainer, gbConstraints);
        gbConstraints.gridy = index++;
        jpEverything.add(jpMyFilesContainer, gbConstraints);
        gbConstraints.gridy = index++;
        jpEverything.add(jpMyPacksContainer, gbConstraints);
        this.setLayout(new BorderLayout());
        this.add(jpEverything, "North");
    }
    
    private void initialiseData() {
        new Thread("Loading data about contributions of current user.") {
            @Override
            public void run() {
                MyStuffContributionsPanel.this.logger.debug((Object)"Loading contributions data for current user");
                try {
                    final ArrayList<Workflow> alWorkflowInstances = new ArrayList<Workflow>();
                    if (MyStuffContributionsPanel.this.alVisiblePanels.contains(MyStuffContributionsPanel.this.jpMyWorkflows)) {
                        boolean anyMore = true;
                        int page = 1;
                        while (anyMore) {
                            final Document doc = MyStuffContributionsPanel.this.myExperimentClient.getUserContributions(MyStuffContributionsPanel.this.myExperimentClient.getCurrentUser(), 10, 5015, page);
                            if (doc != null) {
                                final List<Element> foundElements = (List<Element>)doc.getRootElement().getChildren();
                                anyMore = !foundElements.isEmpty();
                                for (final Element e : foundElements) {
                                    final Workflow wfCurrent = Workflow.buildFromXML(e, MyStuffContributionsPanel.this.logger);
                                    alWorkflowInstances.add(wfCurrent);
                                }
                            }
                            ++page;
                        }
                    }
                    final ArrayList<File> alFileInstances = new ArrayList<File>();
                    if (MyStuffContributionsPanel.this.alVisiblePanels.contains(MyStuffContributionsPanel.this.jpMyFiles)) {
                        boolean anyMore2 = true;
                        int page2 = 1;
                        while (anyMore2) {
                            final Document doc2 = MyStuffContributionsPanel.this.myExperimentClient.getUserContributions(MyStuffContributionsPanel.this.myExperimentClient.getCurrentUser(), 11, 5015, page2);
                            if (doc2 != null) {
                                final List<Element> foundElements2 = (List<Element>)doc2.getRootElement().getChildren();
                                anyMore2 = !foundElements2.isEmpty();
                                for (final Element e2 : foundElements2) {
                                    final File fCurrent = File.buildFromXML(e2, MyStuffContributionsPanel.this.logger);
                                    alFileInstances.add(fCurrent);
                                }
                            }
                            ++page2;
                        }
                    }
                    final ArrayList<Pack> alPackInstances = new ArrayList<Pack>();
                    if (MyStuffContributionsPanel.this.alVisiblePanels.contains(MyStuffContributionsPanel.this.jpMyPacks)) {
                        boolean anyMore3 = true;
                        int page3 = 1;
                        while (anyMore3) {
                            final Document doc3 = MyStuffContributionsPanel.this.myExperimentClient.getUserContributions(MyStuffContributionsPanel.this.myExperimentClient.getCurrentUser(), 12, 5015, page3);
                            if (doc3 != null) {
                                final List<Element> foundElements3 = (List<Element>)doc3.getRootElement().getChildren();
                                anyMore3 = !foundElements3.isEmpty();
                                for (final Element e3 : foundElements3) {
                                    final Pack pCurrent = Pack.buildFromXML(e3, MyStuffContributionsPanel.this.myExperimentClient, MyStuffContributionsPanel.this.logger);
                                    alPackInstances.add(pCurrent);
                                }
                            }
                            ++page3;
                        }
                    }
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            if (MyStuffContributionsPanel.this.alVisiblePanels.contains(MyStuffContributionsPanel.this.jpMyWorkflows)) {
                                (MyStuffContributionsPanel.this.jpMyWorkflowsContent = new ResourceListPanel(MyStuffContributionsPanel.this.pluginMainComponent, MyStuffContributionsPanel.this.myExperimentClient, MyStuffContributionsPanel.this.logger)).setFullSizeItemsList(false);
                                MyStuffContributionsPanel.this.jpMyWorkflowsContent.setListItems(new ArrayList<Resource>(alWorkflowInstances));
                                MyStuffContributionsPanel.this.spMyWorkflowsContent = new JScrollPane(MyStuffContributionsPanel.this.jpMyWorkflowsContent);
                                MyStuffContributionsPanel.this.spMyWorkflowsContent.getVerticalScrollBar().setUnitIncrement(10);
                                MyStuffContributionsPanel.this.jpMyWorkflows.removeAll();
                                MyStuffContributionsPanel.this.jpMyWorkflows.setBackground(null);
                                MyStuffContributionsPanel.this.jpMyWorkflows.setBorder(BorderFactory.createEmptyBorder());
                                MyStuffContributionsPanel.this.jpMyWorkflows.add(MyStuffContributionsPanel.this.spMyWorkflowsContent);
                                MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.add(new JComponent[] { MyStuffContributionsPanel.this.jpMyWorkflows, MyStuffContributionsPanel.this.spMyWorkflowsContent, MyStuffContributionsPanel.this.jpMyWorkflowsContent });
                            }
                            if (MyStuffContributionsPanel.this.alVisiblePanels.contains(MyStuffContributionsPanel.this.jpMyFiles)) {
                                (MyStuffContributionsPanel.this.jpMyFilesContent = new ResourceListPanel(MyStuffContributionsPanel.this.pluginMainComponent, MyStuffContributionsPanel.this.myExperimentClient, MyStuffContributionsPanel.this.logger)).setFullSizeItemsList(false);
                                MyStuffContributionsPanel.this.jpMyFilesContent.setListItems(new ArrayList<Resource>(alFileInstances));
                                MyStuffContributionsPanel.this.spMyFilesContent = new JScrollPane(MyStuffContributionsPanel.this.jpMyFilesContent);
                                MyStuffContributionsPanel.this.spMyFilesContent.getVerticalScrollBar().setUnitIncrement(10);
                                MyStuffContributionsPanel.this.jpMyFiles.removeAll();
                                MyStuffContributionsPanel.this.jpMyFiles.setBackground(null);
                                MyStuffContributionsPanel.this.jpMyFiles.setBorder(BorderFactory.createEmptyBorder());
                                MyStuffContributionsPanel.this.jpMyFiles.add(MyStuffContributionsPanel.this.spMyFilesContent);
                                MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.add(new JComponent[] { MyStuffContributionsPanel.this.jpMyFiles, MyStuffContributionsPanel.this.spMyFilesContent, MyStuffContributionsPanel.this.jpMyFilesContent });
                            }
                            if (MyStuffContributionsPanel.this.alVisiblePanels.contains(MyStuffContributionsPanel.this.jpMyPacks)) {
                                (MyStuffContributionsPanel.this.jpMyPacksContent = new ResourceListPanel(MyStuffContributionsPanel.this.pluginMainComponent, MyStuffContributionsPanel.this.myExperimentClient, MyStuffContributionsPanel.this.logger)).setFullSizeItemsList(false);
                                MyStuffContributionsPanel.this.jpMyPacksContent.setListItems(new ArrayList<Resource>(alPackInstances));
                                MyStuffContributionsPanel.this.spMyPacksContent = new JScrollPane(MyStuffContributionsPanel.this.jpMyPacksContent);
                                MyStuffContributionsPanel.this.spMyPacksContent.getVerticalScrollBar().setUnitIncrement(10);
                                MyStuffContributionsPanel.this.jpMyPacks.removeAll();
                                MyStuffContributionsPanel.this.jpMyPacks.setBackground(null);
                                MyStuffContributionsPanel.this.jpMyPacks.setBorder(BorderFactory.createEmptyBorder());
                                MyStuffContributionsPanel.this.jpMyPacks.add(MyStuffContributionsPanel.this.spMyPacksContent);
                                MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.add(new JComponent[] { MyStuffContributionsPanel.this.jpMyPacks, MyStuffContributionsPanel.this.spMyPacksContent, MyStuffContributionsPanel.this.jpMyPacksContent });
                            }
                            int iFullAvailableHeight = MyStuffContributionsPanel.this.getSize().height;
                            final ArrayList<Integer> alIndexesToScale = new ArrayList<Integer>();
                            for (int i = 0; i < MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.size(); ++i) {
                                final JScrollPane spContent = (JScrollPane)((JComponent[])MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.get(i))[1];
                                final JPanel jpContent = (JPanel)((JComponent[])MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.get(i))[2];
                                if (jpContent.getPreferredSize().height + 33 < iFullAvailableHeight / MyStuffContributionsPanel.this.alVisiblePanels.size()) {
                                    final Dimension preferredSize;
                                    final Dimension d = preferredSize = jpContent.getPreferredSize();
                                    preferredSize.height += 3;
                                    spContent.setPreferredSize(d);
                                    iFullAvailableHeight -= jpContent.getPreferredSize().height + 33;
                                }
                                else {
                                    alIndexesToScale.add(i);
                                }
                            }
                            if (alIndexesToScale.size() > 0) {
                                final Dimension d2 = new Dimension();
                                for (final Integer j : alIndexesToScale) {
                                    d2.height = iFullAvailableHeight / alIndexesToScale.size() - 33;
                                    if (d2.height > ((JPanel)((JComponent[])MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.get(j))[2]).getPreferredSize().height + 3) {
                                        d2.height = ((JPanel)((JComponent[])MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.get(j))[2]).getPreferredSize().height + 3;
                                    }
                                    final JScrollPane spCurrent = (JScrollPane)((JComponent[])MyStuffContributionsPanel.this.alVisiblePanelsWithHelperElements.get(j))[1];
                                    spCurrent.setPreferredSize(d2);
                                }
                            }
                            MyStuffContributionsPanel.this.pluginMainComponent.getMyStuffTab().cdlComponentLoadingDone.countDown();
                            MyStuffContributionsPanel.this.validate();
                            MyStuffContributionsPanel.this.repaint();
                        }
                    });
                }
                catch (Exception ex) {
                    MyStuffContributionsPanel.this.logger.error((Object)"Failed to populate some panel in My Stuff tab (User's files, workflows or packs)", (Throwable)ex);
                }
            }
        }.start();
    }
    
    @Override
    public void actionPerformed(final ActionEvent arg0) {
        JOptionPane.showMessageDialog(null, "button clicked");
    }
}
