// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import javax.swing.text.html.StyleSheet;
import javax.swing.text.html.HTMLEditorKit;

public class StyledHTMLEditorKit extends HTMLEditorKit
{
    private final StyleSheet styleSheet;
    
    public StyledHTMLEditorKit(final StyleSheet styleSheet) {
        this.styleSheet = styleSheet;
    }
    
    @Override
    public StyleSheet getStyleSheet() {
        return this.styleSheet;
    }
}
