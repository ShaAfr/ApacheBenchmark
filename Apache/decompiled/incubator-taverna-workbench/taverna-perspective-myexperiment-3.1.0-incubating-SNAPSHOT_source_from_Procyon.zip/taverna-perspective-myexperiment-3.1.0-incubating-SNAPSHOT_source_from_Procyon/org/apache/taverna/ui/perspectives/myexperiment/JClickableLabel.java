// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import java.util.EventListener;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import javax.swing.JLabel;

public class JClickableLabel extends JLabel implements MouseListener
{
    private String strData;
    private ActionListener clickHandler;
    
    public JClickableLabel(final String strLabel, final String strDataForAction, final EventListener eventHandler) {
        this(strLabel, strDataForAction, eventHandler, null);
    }
    
    public JClickableLabel(final String strLabel, final String strDataForAction, final EventListener eventHandler, final Icon icon) {
        this(strLabel, strDataForAction, eventHandler, icon, 2);
    }
    
    public JClickableLabel(final String strLabel, final String strDataForAction, final EventListener eventHandler, final Icon icon, final int horizontalAlignment) {
        this(strLabel, strDataForAction, eventHandler, icon, horizontalAlignment, null);
    }
    
    public JClickableLabel(final String strLabel, final String strDataForAction, final EventListener eventHandler, final Icon icon, final int horizontalAlignment, final String strTooltip) {
        super(strLabel, icon, horizontalAlignment);
        this.strData = strDataForAction;
        this.clickHandler = (ActionListener)eventHandler;
        if (icon != null) {
            this.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
        }
        this.setToolTipText((strTooltip == null) ? strLabel : strTooltip);
        this.setForeground(Color.BLUE);
        this.addMouseListener(this);
    }
    
    @Override
    public void mouseClicked(final MouseEvent e) {
        this.clickHandler.actionPerformed(new ActionEvent(this, e.getID(), this.strData));
    }
    
    @Override
    public void mouseEntered(final MouseEvent e) {
        this.setCursor(Cursor.getPredefinedCursor(12));
    }
    
    @Override
    public void mouseExited(final MouseEvent e) {
        this.setCursor(Cursor.getPredefinedCursor(0));
    }
    
    @Override
    public void mousePressed(final MouseEvent e) {
    }
    
    @Override
    public void mouseReleased(final MouseEvent e) {
    }
}
