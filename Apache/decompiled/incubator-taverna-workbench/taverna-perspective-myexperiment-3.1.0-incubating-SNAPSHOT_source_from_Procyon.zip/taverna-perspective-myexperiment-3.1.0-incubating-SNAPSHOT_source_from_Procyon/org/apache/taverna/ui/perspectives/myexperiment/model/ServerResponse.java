// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import org.jdom.Document;

public class ServerResponse
{
    public static int LOCAL_FAILURE;
    private int iResponseCode;
    private Document docResponseBody;
    
    public ServerResponse() {
    }
    
    public ServerResponse(final int responseCode, final Document responseBody) {
        this.iResponseCode = responseCode;
        this.docResponseBody = responseBody;
    }
    
    public int getResponseCode() {
        return this.iResponseCode;
    }
    
    public void setResponseCode(final int responseCode) {
        this.iResponseCode = responseCode;
    }
    
    public Document getResponseBody() {
        return this.docResponseBody;
    }
    
    public void setResponseBody(final Document responseBody) {
        this.docResponseBody = responseBody;
    }
    
    static {
        ServerResponse.LOCAL_FAILURE = -1;
    }
}
