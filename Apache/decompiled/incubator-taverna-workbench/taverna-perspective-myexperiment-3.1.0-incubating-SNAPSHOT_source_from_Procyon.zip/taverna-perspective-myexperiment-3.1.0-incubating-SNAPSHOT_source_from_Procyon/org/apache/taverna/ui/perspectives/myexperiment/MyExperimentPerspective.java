// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import javax.swing.JComponent;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import java.net.URL;
import javax.swing.ImageIcon;
import org.apache.taverna.workbench.ui.zaria.PerspectiveSPI;

public class MyExperimentPerspective implements PerspectiveSPI
{
    private static final String BASE_RESOURCE_PATH = "/net/sf/taverna/t2/ui/perspectives/myexperiment/";
    public static final String PERSPECTIVE_NAME = "myExperiment";
    public static final String PLUGIN_VERSION = "0.2beta";
    private MainComponent perspectiveMainComponent;
    private boolean visible;
    
    public MyExperimentPerspective() {
        this.visible = true;
    }
    
    public ImageIcon getButtonIcon() {
        final URL iconURL = getLocalResourceURL("myexp_icon16x16");
        if (iconURL == null) {
            return null;
        }
        return new ImageIcon(iconURL);
    }
    
    public String getText() {
        return "myExperiment";
    }
    
    public boolean isVisible() {
        return this.visible;
    }
    
    public int positionHint() {
        return 30;
    }
    
    public void setVisible(final boolean visible) {
        this.visible = visible;
    }
    
    public void setMainComponent(final MainComponent component) {
        this.perspectiveMainComponent = component;
    }
    
    public MainComponent getMainComponent() {
        return this.perspectiveMainComponent;
    }
    
    public static URL getLocalResourceURL(final String strResourceName) {
        String strResourcePath = "/net/sf/taverna/t2/ui/perspectives/myexperiment/";
        if (strResourceName.equals("not_authorized_icon")) {
            strResourcePath += "denied.png";
        }
        if (strResourceName.equals("failure_icon")) {
            strResourcePath += "denied.png";
        }
        else if (strResourceName.equals("success_icon")) {
            strResourcePath += "tick.png";
        }
        else if (strResourceName.equals("spinner")) {
            strResourcePath += "ajax-loader.gif";
        }
        else if (strResourceName.equals("spinner_stopped")) {
            strResourcePath += "ajax-loader-still.gif";
        }
        else if (strResourceName.equals("external_link_small_icon")) {
            strResourcePath += "external_link_listing_small.png";
        }
        else if (strResourceName.equals("back_icon")) {
            strResourcePath += "arrow_left.png";
        }
        else if (strResourceName.equals("forward_icon")) {
            strResourcePath += "arrow_right.png";
        }
        else if (strResourceName.equals("refresh_icon")) {
            strResourcePath += "arrow_refresh.png";
        }
        else if (strResourceName.equals("favourite_icon")) {
            strResourcePath += "star.png";
        }
        else if (strResourceName.equals("add_favourite_icon")) {
            strResourcePath += "favourite_add.png";
        }
        else if (strResourceName.equals("delete_favourite_icon")) {
            strResourcePath += "favourite_delete.png";
        }
        else if (strResourceName.equals("destroy_icon")) {
            strResourcePath += "cross.png";
        }
        else if (strResourceName.equals("add_comment_icon")) {
            strResourcePath += "comment_add.png";
        }
        else if (strResourceName.equals("myexp_icon")) {
            strResourcePath += "myexp_icon.png";
        }
        else if (strResourceName.equals("myexp_icon16x16")) {
            strResourcePath += "myexp_icon16x16.png";
        }
        else if (strResourceName.equals("open_in_my_experiment_icon")) {
            strResourcePath += "open_in_myExperiment.png";
        }
        else if (strResourceName.equals("login_icon")) {
            strResourcePath += "login.png";
        }
        else if (strResourceName.equals("logout_icon")) {
            strResourcePath += "logout.png";
        }
        else {
            if (!strResourceName.equals("css_stylesheet")) {
                throw new IllegalArgumentException("Unknown myExperiment plugin resource requested; requested resource name was: " + strResourceName);
            }
            strResourcePath += "styles.css";
        }
        return MyExperimentPerspective.class.getResource(strResourcePath);
    }
    
    public static URL getLocalIconURL(final int iResourceType) {
        String strResourcePath = "/net/sf/taverna/t2/ui/perspectives/myexperiment/";
        switch (iResourceType) {
            case 10: {
                strResourcePath += "workflow.png";
                break;
            }
            case 11: {
                strResourcePath += "file.png";
                break;
            }
            case 12: {
                strResourcePath += "pack.png";
                break;
            }
            case 15: {
                strResourcePath += "remote_resource.png";
                break;
            }
            case 20: {
                strResourcePath += "user.png";
                break;
            }
            case 21: {
                strResourcePath += "group.png";
                break;
            }
            case 30: {
                strResourcePath += "tag_blue.png";
                break;
            }
            default: {
                throw new IllegalArgumentException("Unknown myExperiment plugin resource requested; requested resource name was: " + Resource.getResourceTypeName(iResourceType));
            }
        }
        return MyExperimentPerspective.class.getResource(strResourcePath);
    }
    
    public String getID() {
        return "myExperiment";
    }
    
    public JComponent getPanel() {
        return this.getMainComponent();
    }
}
