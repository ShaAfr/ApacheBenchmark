// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.util.Iterator;
import java.util.Collection;
import org.jdom.Element;
import org.apache.log4j.Logger;
import org.jdom.Document;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.net.URI;

public class Workflow extends Resource
{
    public static final String MIME_TYPE_TAVERNA_1 = "application/vnd.taverna.scufl+xml";
    public static final String MIME_TYPE_TAVERNA_2 = "application/vnd.taverna.t2flow+xml";
    private int accessType;
    private int version;
    private User uploader;
    private URI preview;
    private URI thumbnail;
    private URI thumbnailBig;
    private URI svg;
    private License license;
    private String visibleType;
    private String contentType;
    private URI contentUri;
    byte[] content;
    private List<Tag> tags;
    private List<Comment> comments;
    private List<Resource> credits;
    private List<Resource> attributions;
    private HashMap<String, ArrayList<HashMap<String, String>>> components;
    
    public Workflow() {
        this.setItemType(10);
    }
    
    public int getAccessType() {
        return this.accessType;
    }
    
    public void setAccessType(final int accessType) {
        this.accessType = accessType;
    }
    
    public int getVersion() {
        return this.version;
    }
    
    public void setVersion(final int version) {
        this.version = version;
    }
    
    @Override
    public User getUploader() {
        return this.uploader;
    }
    
    public void setUploader(final User uploader) {
        this.uploader = uploader;
    }
    
    public URI getPreview() {
        return this.preview;
    }
    
    public void setPreview(final URI preview) {
        this.preview = preview;
    }
    
    public URI getThumbnail() {
        return this.thumbnail;
    }
    
    public void setThumbnail(final URI thumbnail) {
        this.thumbnail = thumbnail;
    }
    
    public URI getSvg() {
        return this.svg;
    }
    
    public void setSvg(final URI svg) {
        this.svg = svg;
    }
    
    public License getLicense() {
        return this.license;
    }
    
    public void setLicense(final License license) {
        this.license = license;
    }
    
    public URI getContentUri() {
        return this.contentUri;
    }
    
    public void setContentUri(final URI contentUri) {
        this.contentUri = contentUri;
    }
    
    @Override
    public String getVisibleType() {
        return this.visibleType;
    }
    
    public void setVisibleType(final String visibleType) {
        this.visibleType = visibleType;
    }
    
    public String getContentType() {
        return this.contentType;
    }
    
    public void setContentType(final String contentType) {
        this.contentType = contentType;
    }
    
    public byte[] getContent() {
        return this.content;
    }
    
    public void setContent(final byte[] content) {
        this.content = content;
    }
    
    public List<Tag> getTags() {
        return this.tags;
    }
    
    @Override
    public List<Comment> getComments() {
        return this.comments;
    }
    
    public List<Resource> getCredits() {
        return this.credits;
    }
    
    public List<Resource> getAttributions() {
        return this.attributions;
    }
    
    public HashMap<String, ArrayList<HashMap<String, String>>> getComponents() {
        return this.components;
    }
    
    public URI getThumbnailBig() {
        return this.thumbnailBig;
    }
    
    public void setThumbnailBig(final URI thumbnailBig) {
        this.thumbnailBig = thumbnailBig;
    }
    
    public boolean isTavernaWorkflow() {
        return this.contentType.equals("application/vnd.taverna.scufl+xml") || this.contentType.equals("application/vnd.taverna.t2flow+xml");
    }
    
    public boolean isTaverna1Workflow() {
        return this.contentType.equals("application/vnd.taverna.scufl+xml");
    }
    
    public boolean isTaverna2Workflow() {
        return this.contentType.equals("application/vnd.taverna.t2flow+xml");
    }
    
    public static String getRequiredAPIElements(final int iRequestType) {
        String strElements = "";
        switch (iRequestType) {
            case 5005: {
                strElements += "created-at,updated-at,preview,thumbnail-big,svg,license-type,content-uri,tags,comments,ratings,credits,attributions,components,";
            }
            case 5010: {
                strElements += "uploader,type,";
            }
            case 5015: {
                strElements += "id,title,thumbnail,description,privileges,content-type";
                break;
            }
            case 5055: {
                strElements += "type,content-type,content";
                break;
            }
        }
        return strElements;
    }
    
    public static Workflow buildFromXML(final Document doc, final Logger logger) {
        if (doc == null) {
            return null;
        }
        return buildFromXML(doc.getRootElement(), logger);
    }
    
    public static Workflow buildFromXML(final Element docRootElement, final Logger logger) {
        if (docRootElement == null) {
            return null;
        }
        final Workflow w = new Workflow();
        try {
            w.setAccessType(Util.getAccessTypeFromXMLElement(docRootElement.getChild("privileges")));
            w.setURI(docRootElement.getAttributeValue("uri"));
            w.setResource(docRootElement.getAttributeValue("resource"));
            final String version = docRootElement.getAttributeValue("version");
            if (version != null && !version.equals("")) {
                w.setVersion(Integer.parseInt(version));
            }
            String id = docRootElement.getChildText("id");
            if (id == null || id.equals("")) {
                id = "API Error - No workflow ID supplied";
                logger.error((Object)("Error while parsing workflow XML data - no ID provided for workflow with title: \"" + docRootElement.getChildText("title") + "\""));
            }
            w.setID(id);
            w.setTitle(docRootElement.getChildText("title"));
            w.setDescription(docRootElement.getChildText("description"));
            final Element uploaderElement = docRootElement.getChild("uploader");
            w.setUploader(Util.instantiatePrimitiveUserFromElement(uploaderElement));
            final String createdAt = docRootElement.getChildText("created-at");
            if (createdAt != null && !createdAt.equals("")) {
                w.setCreatedAt(MyExperimentClient.parseDate(createdAt));
            }
            final String updatedAt = docRootElement.getChildText("updated-at");
            if (updatedAt != null && !updatedAt.equals("")) {
                w.setUpdatedAt(MyExperimentClient.parseDate(updatedAt));
            }
            final String preview = docRootElement.getChildText("preview");
            if (preview != null && !preview.equals("")) {
                w.setPreview(new URI(preview));
            }
            final String thumbnail = docRootElement.getChildText("thumbnail");
            if (thumbnail != null && !thumbnail.equals("")) {
                w.setThumbnail(new URI(thumbnail));
            }
            final String thumbnailBig = docRootElement.getChildText("thumbnail-big");
            if (thumbnailBig != null && !thumbnailBig.equals("")) {
                w.setThumbnailBig(new URI(thumbnailBig));
            }
            final String svg = docRootElement.getChildText("svg");
            if (svg != null && !svg.equals("")) {
                w.setSvg(new URI(svg));
            }
            w.setLicense(License.getInstance(docRootElement.getChildText("license-type")));
            final String contentUri = docRootElement.getChildText("content-uri");
            if (contentUri != null && !contentUri.equals("")) {
                w.setContentUri(new URI(contentUri));
            }
            w.setVisibleType(docRootElement.getChildText("type"));
            w.setContentType(docRootElement.getChildText("content-type"));
            (w.tags = new ArrayList<Tag>()).addAll(Util.retrieveTags(docRootElement));
            w.comments = new ArrayList<Comment>();
            w.getComments().addAll(Util.retrieveComments(docRootElement, w));
            w.credits = new ArrayList<Resource>();
            w.getCredits().addAll(Util.retrieveCredits(docRootElement));
            w.attributions = new ArrayList<Resource>();
            w.getAttributions().addAll(Util.retrieveAttributions(docRootElement));
            w.components = new HashMap<String, ArrayList<HashMap<String, String>>>();
            final Element componentsElement = docRootElement.getChild("components");
            if (componentsElement != null) {
                final Element sourcesElement = componentsElement.getChild("sources");
                if (sourcesElement != null) {
                    final ArrayList<HashMap<String, String>> inputs = new ArrayList<HashMap<String, String>>();
                    final List<Element> sourcesNodes = (List<Element>)sourcesElement.getChildren();
                    for (final Element e : sourcesNodes) {
                        final HashMap<String, String> curInput = new HashMap<String, String>();
                        curInput.put("name", e.getChildText("name"));
                        curInput.put("description", e.getChildText("description"));
                        inputs.add(curInput);
                    }
                    w.getComponents().put("inputs", inputs);
                }
                final Element outputsElement = componentsElement.getChild("sinks");
                if (outputsElement != null) {
                    final ArrayList<HashMap<String, String>> sinks = new ArrayList<HashMap<String, String>>();
                    final List<Element> outputsNodes = (List<Element>)outputsElement.getChildren();
                    for (final Element e2 : outputsNodes) {
                        final HashMap<String, String> curOutput = new HashMap<String, String>();
                        curOutput.put("name", e2.getChildText("name"));
                        curOutput.put("description", e2.getChildText("description"));
                        sinks.add(curOutput);
                    }
                    w.getComponents().put("outputs", sinks);
                }
                final Element processorsElement = componentsElement.getChild("processors");
                if (processorsElement != null) {
                    final ArrayList<HashMap<String, String>> processors = new ArrayList<HashMap<String, String>>();
                    final List<Element> processorsNodes = (List<Element>)processorsElement.getChildren();
                    for (final Element e3 : processorsNodes) {
                        final HashMap<String, String> curProcessor = new HashMap<String, String>();
                        curProcessor.put("name", e3.getChildText("name"));
                        curProcessor.put("type", e3.getChildText("type"));
                        curProcessor.put("description", e3.getChildText("description"));
                        processors.add(curProcessor);
                    }
                    w.getComponents().put("processors", processors);
                }
                final Element linksElement = componentsElement.getChild("links");
                if (linksElement != null) {
                    final ArrayList<HashMap<String, String>> links = new ArrayList<HashMap<String, String>>();
                    final List<Element> linksNodes = (List<Element>)linksElement.getChildren();
                    for (final Element e4 : linksNodes) {
                        final HashMap<String, String> curLink = new HashMap<String, String>();
                        final String strSource = e4.getChild("source").getChildText("node") + ((e4.getChild("source").getChildText("port") == null) ? "" : (":" + e4.getChild("source").getChildText("port")));
                        curLink.put("source", strSource);
                        final String strSink = e4.getChild("sink").getChildText("node") + ((e4.getChild("sink").getChildText("port") == null) ? "" : (":" + e4.getChild("sink").getChildText("port")));
                        curLink.put("sink", strSink);
                        links.add(curLink);
                    }
                    w.getComponents().put("links", links);
                }
            }
            logger.debug((Object)("Found information for worklow with ID: " + w.getID() + ", Title: " + w.getTitle()));
        }
        catch (Exception e5) {
            logger.error((Object)"Failed midway through creating workflow object from XML", (Throwable)e5);
        }
        return w;
    }
}
