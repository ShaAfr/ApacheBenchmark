// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import org.jdom.Element;
import org.apache.log4j.Logger;
import org.jdom.Document;

public class PackItem extends Resource
{
    private int id;
    private User userWhoAddedThisItem;
    private String strComment;
    private boolean bInternalItem;
    private Resource item;
    private String strLink;
    private String strAlternateLink;
    
    public PackItem() {
        this.setItemType(0);
    }
    
    @Override
    public int getID() {
        return this.id;
    }
    
    @Override
    public void setID(final int id) {
        this.id = id;
    }
    
    @Override
    public void setID(final String id) {
        this.id = Integer.parseInt(id);
    }
    
    public boolean isInternalItem() {
        return this.bInternalItem;
    }
    
    public void setInternalItem(final boolean bIsInternalItem) {
        this.bInternalItem = bIsInternalItem;
    }
    
    public User getUserWhoAddedTheItem() {
        return this.userWhoAddedThisItem;
    }
    
    public void setUserWhoAddedTheItem(final User userWhoAddedTheItem) {
        this.userWhoAddedThisItem = userWhoAddedTheItem;
    }
    
    public String getComment() {
        return this.strComment;
    }
    
    public void setComment(final String strComment) {
        this.strComment = strComment;
    }
    
    public Resource getItem() {
        return this.item;
    }
    
    public void setItem(final Resource item) {
        this.item = item;
    }
    
    public String getLink() {
        return this.strLink;
    }
    
    public void setLink(final String strLink) {
        this.strLink = strLink;
    }
    
    public String getAlternateLink() {
        return this.strAlternateLink;
    }
    
    public void setAlternateLink(final String strAlternateLink) {
        this.strAlternateLink = strAlternateLink;
    }
    
    public static PackItem buildFromXML(final Document doc, final Logger logger) {
        if (doc == null) {
            return null;
        }
        final PackItem p = new PackItem();
        try {
            final Element root = doc.getRootElement();
            p.setURI(root.getAttributeValue("uri"));
            p.setResource(root.getAttributeValue("resource"));
            String strID = root.getChildText("id");
            if (strID == null || strID.equals("")) {
                strID = "API Error - No pack item ID supplied";
                logger.error((Object)("Error while parsing pack item XML data - no ID provided for pack item with uri: \"" + p.getURI() + "\""));
            }
            else {
                p.setID(strID);
            }
            final Element ownerElement = root.getChild("owner");
            p.setUserWhoAddedTheItem(Util.instantiatePrimitiveUserFromElement(ownerElement));
            final String createdAt = root.getChildText("created-at");
            if (createdAt != null && !createdAt.equals("")) {
                p.setCreatedAt(MyExperimentClient.parseDate(createdAt));
            }
            final Element commentElement = root.getChild("comment");
            if (commentElement != null) {
                p.setComment(commentElement.getText());
            }
            if (root.getName().equals("internal-pack-item")) {
                p.setInternalItem(true);
                final Element itemElement = root.getChild("item").getChildren().get(0);
                if (itemElement != null) {
                    p.setItem(Util.instantiatePrimitiveResourceFromElement(itemElement));
                }
                p.setItemType(p.getItem().getItemType());
                p.setTitle(p.getItem().getTitle());
            }
            else {
                p.setInternalItem(false);
                p.setItemType(15);
                p.setTitle(root.getChildText("title"));
                p.setLink(root.getChildText("uri"));
                p.setAlternateLink(root.getChildText("alternate-uri"));
            }
            logger.debug((Object)("Found information for pack item with URI: " + p.getURI()));
        }
        catch (Exception e) {
            logger.error((Object)"Failed midway through creating pack item object from XML", (Throwable)e);
        }
        return p;
    }
}
