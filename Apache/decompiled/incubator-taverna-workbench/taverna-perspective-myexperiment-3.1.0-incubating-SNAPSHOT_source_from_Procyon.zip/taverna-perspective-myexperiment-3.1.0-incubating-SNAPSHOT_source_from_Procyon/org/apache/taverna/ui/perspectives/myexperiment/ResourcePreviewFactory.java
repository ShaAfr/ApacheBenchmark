// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import javax.swing.SwingUtilities;
import java.awt.Rectangle;
import org.apache.taverna.ui.perspectives.myexperiment.model.Comment;
import java.awt.event.ActionListener;
import org.apache.taverna.ui.perspectives.myexperiment.model.Tag;
import java.util.List;
import org.apache.taverna.lang.ui.DialogTextArea;
import org.apache.taverna.ui.perspectives.myexperiment.model.PackItem;
import org.apache.taverna.lang.ui.ShadedLabel;
import javax.swing.JTable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Arrays;
import java.util.Vector;
import java.util.Iterator;
import java.awt.Dimension;
import javax.swing.Icon;
import java.util.HashMap;
import java.awt.Container;
import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import java.awt.Insets;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.text.html.HTMLEditorKit;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.EditorKit;
import javax.swing.JTextPane;
import javax.swing.JTabbedPane;
import javax.swing.text.html.HTMLDocument;
import org.apache.taverna.ui.perspectives.myexperiment.model.Util;
import org.jdom.Document;
import org.apache.taverna.ui.perspectives.myexperiment.model.Group;
import org.apache.taverna.ui.perspectives.myexperiment.model.User;
import org.apache.taverna.ui.perspectives.myexperiment.model.Pack;
import org.apache.taverna.ui.perspectives.myexperiment.model.File;
import org.apache.taverna.ui.perspectives.myexperiment.model.Workflow;
import javax.swing.JComponent;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.util.EventListener;
import javax.swing.ImageIcon;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;

public class ResourcePreviewFactory
{
    private static final int PREFERRED_LOWER_TABBED_PANE_HEIGHT = 250;
    private final MainComponent pluginMainComponent;
    private final MyExperimentClient myExperimentClient;
    private final Logger logger;
    private final ImageIcon iconWorkflow;
    private final ImageIcon iconFile;
    private final ImageIcon iconPack;
    private final ImageIcon iconUser;
    private final ImageIcon iconGroup;
    
    public ResourcePreviewFactory(final MainComponent component, final MyExperimentClient client, final Logger logger) {
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.iconWorkflow = new ImageIcon(MyExperimentPerspective.getLocalIconURL(10));
        this.iconFile = new ImageIcon(MyExperimentPerspective.getLocalIconURL(11));
        this.iconPack = new ImageIcon(MyExperimentPerspective.getLocalIconURL(12));
        this.iconUser = new ImageIcon(MyExperimentPerspective.getLocalIconURL(20));
        this.iconGroup = new ImageIcon(MyExperimentPerspective.getLocalIconURL(21));
    }
    
    public ResourcePreviewContent createPreview(String action, final EventListener eventHandler) {
        final JPanel panelToPopulate = new JPanel();
        if (!action.startsWith("preview:")) {
            this.logger.error((Object)("Bad preview request: \"" + action + "\""));
            panelToPopulate.add(new JLabel("An error has occurred."));
            final Resource r = new Resource();
            r.setItemType(-1);
            r.setTitle("Bad preview request");
            r.setURI(action);
            return new ResourcePreviewContent(r, panelToPopulate);
        }
        action = action.substring(action.indexOf(":") + 1);
        final int iType = Integer.parseInt(action.substring(0, action.indexOf(":")));
        final String strURI;
        action = (strURI = action.substring(action.indexOf(":") + 1));
        Document doc = null;
        try {
            doc = this.myExperimentClient.getResource(iType, strURI, 5005);
        }
        catch (Exception e) {
            this.logger.error((Object)("Error while fetching resource data from myExperiment to generate a preview.\nResource type: " + Resource.getResourceTypeName(iType) + "\nResource URI: " + strURI + "\nException: " + e));
        }
        Resource resource = null;
        switch (iType) {
            case 10: {
                final Workflow w = (Workflow)(resource = Workflow.buildFromXML(doc, this.logger));
                this.generateWorkflowPreviewContent(w, panelToPopulate, eventHandler);
                break;
            }
            case 11: {
                final File f = (File)(resource = File.buildFromXML(doc, this.logger));
                this.generateFilePreviewContent(f, panelToPopulate, eventHandler);
                break;
            }
            case 12: {
                final Pack p = (Pack)(resource = Pack.buildFromXML(doc, this.myExperimentClient, this.logger));
                this.generatePackPreviewContent(p, panelToPopulate, eventHandler);
                break;
            }
            case 20: {
                final User u = (User)(resource = User.buildFromXML(doc, this.logger));
                this.generateUserPreviewContent(u, panelToPopulate, eventHandler);
                break;
            }
            case 21: {
                final Group g = (Group)(resource = Group.buildFromXML(doc, this.logger));
                this.generateGroupPreviewContent(g, panelToPopulate, eventHandler);
                break;
            }
            default: {
                this.logger.error((Object)("Failed generating preview. Reason: unknown resource type - \"" + Resource.getResourceTypeName(iType) + "\""));
                panelToPopulate.add(new JLabel("Cannot generate preview for unknown resource types."));
                final Resource r2 = new Resource();
                r2.setItemType(iType);
                r2.setTitle("Error: unknown resource type");
                r2.setURI(strURI);
                return new ResourcePreviewContent(r2, panelToPopulate);
            }
        }
        return new ResourcePreviewContent(resource, panelToPopulate);
    }
    
    private void generateWorkflowPreviewContent(final Workflow w, final JPanel panelToPopulate, final EventListener eventHandler) {
        if (w != null) {
            try {
                final StringBuffer content = new StringBuffer();
                content.append("<div class='outer'>");
                content.append("<div class='workflow'>");
                content.append("<br>");
                content.append("<p class='title'>");
                content.append("Workflow Entry: <a href='preview:10:" + w.getURI() + "'>" + w.getTitle() + "</a> (version " + w.getVersion() + ")");
                content.append("</p>");
                content.append("<br>");
                content.append("<p class='info'>");
                content.append("<b>Type:</b> " + w.getVisibleType() + "<br><br>");
                content.append("<b>Uploader:</b> <a href='preview:20:" + w.getUploader().getURI() + "'>" + w.getUploader().getName() + "</a><br>");
                content.append("<b>Created at: </b> " + w.getCreatedAt() + "<br>");
                content.append("<b>License: </b> <a href='" + w.getLicense().getLink() + "'>" + w.getLicense().getText() + "</a>&nbsp;<img src='" + MyExperimentPerspective.getLocalResourceURL("external_link_small_icon") + "' />");
                content.append("</p>");
                content.append("<br>");
                content.append("<a href='" + w.getPreview() + "'>");
                content.append("<img class='preview' src='" + w.getThumbnailBig() + "'></img>");
                content.append("</a>");
                content.append("<br>");
                content.append("<br>");
                if (!w.getDescription().equals("")) {
                    content.append("<p class='desc'>");
                    content.append("<br>");
                    content.append(Util.stripHTML(w.getDescription()));
                    content.append("<br>");
                    content.append("</p>");
                }
                else {
                    content.append("<span class='none_text'>No description</span>");
                }
                content.append("<br>");
                content.append("</div>");
                content.append("</div>");
                final HTMLEditorKit kit = new StyledHTMLEditorKit(this.pluginMainComponent.getStyleSheet());
                final HTMLDocument doc = (HTMLDocument)kit.createDefaultDocument();
                doc.insertAfterStart(doc.getRootElements()[0].getElement(0), content.toString());
                final JScrollPane spComponentsTab = this.createWorkflowComponentPreviewTab(w);
                final JScrollPane spTagsTab = this.createTagPreviewTab(w.getTags());
                final JScrollPane spCommentsTab = this.createCommentsPreviewTab(w.getComments());
                final JScrollPane spCreditsTab = this.createCreditsPreviewTab(w.getCredits());
                final JScrollPane spAttributionsTab = this.createAttributionsPreviewTab(w.getAttributions());
                final JTabbedPane tpTabbedView = new JTabbedPane();
                tpTabbedView.add("Components", spComponentsTab);
                tpTabbedView.add("Tags (" + w.getTags().size() + ")", spTagsTab);
                tpTabbedView.add("Comments (" + w.getComments().size() + ")", spCommentsTab);
                tpTabbedView.addTab("Credits (" + w.getCredits().size() + ")", spCreditsTab);
                tpTabbedView.addTab("Attributions (" + w.getAttributions().size() + ")", spAttributionsTab);
                final JTextPane tpWorkflowPreview = new JTextPane();
                tpWorkflowPreview.setEditable(false);
                tpWorkflowPreview.setEditorKit(kit);
                tpWorkflowPreview.setDocument(doc);
                tpWorkflowPreview.addHyperlinkListener((HyperlinkListener)eventHandler);
                final JPanel jpFullWorkflowPreview = this.wrapTextPaneAndTabbedViewIntoFullPreview(tpWorkflowPreview, tpTabbedView);
                panelToPopulate.setLayout(new BorderLayout());
                panelToPopulate.add(jpFullWorkflowPreview, "Center");
            }
            catch (Exception e) {
                this.logger.error((Object)"Failed to populate Workflow Preview pane", (Throwable)e);
            }
        }
    }
    
    private void generateFilePreviewContent(final File f, final JPanel panelToPopulate, final EventListener eventHandler) {
        if (f != null) {
            try {
                final StringBuffer content = new StringBuffer();
                content.append("<div class='outer'>");
                content.append("<div class='file'>");
                content.append("<br>");
                content.append("<p class='title'>");
                content.append("File: <a href='preview:11:" + f.getURI() + "'>" + f.getTitle() + "</a>");
                content.append("</p>");
                content.append("<br>");
                content.append("<p class='info'>");
                content.append("<b>Type:</b> " + f.getVisibleType() + "<br>");
                content.append("<b>Filename:</b> " + f.getFilename() + "<br><br>");
                content.append("<b>Uploader:</b> <a href='preview:20:" + f.getUploader().getURI() + "'>" + f.getUploader().getName() + "</a><br>");
                content.append("<b>Created at: </b> " + f.getCreatedAt() + "<br>");
                content.append("<b>Last updated at: </b> " + f.getUpdatedAt() + "<br>");
                content.append("<b>License: </b> <a href='" + f.getLicense().getLink() + "'>" + f.getLicense().getText() + "</a>&nbsp;<img src='" + MyExperimentPerspective.getLocalResourceURL("external_link_small_icon") + "' />");
                content.append("</p>");
                content.append("<br>");
                if (!f.getDescription().equals("")) {
                    content.append("<p class='desc'>");
                    content.append("<br>");
                    content.append(Util.stripHTML(f.getDescription()));
                    content.append("<br>");
                    content.append("</p>");
                }
                else {
                    content.append("<span class='none_text'>No description</span>");
                }
                content.append("<br>");
                content.append("</div>");
                content.append("</div>");
                final HTMLEditorKit kit = new StyledHTMLEditorKit(this.pluginMainComponent.getStyleSheet());
                final HTMLDocument doc = (HTMLDocument)kit.createDefaultDocument();
                doc.insertAfterStart(doc.getRootElements()[0].getElement(0), content.toString());
                final JScrollPane spTagsTab = this.createTagPreviewTab(f.getTags());
                final JScrollPane spCommentsTab = this.createCommentsPreviewTab(f.getComments());
                final JScrollPane spCreditsTab = this.createCreditsPreviewTab(f.getCredits());
                final JScrollPane spAttributionsTab = this.createAttributionsPreviewTab(f.getAttributions());
                final JTabbedPane tpTabbedView = new JTabbedPane();
                tpTabbedView.add("Tags (" + f.getTags().size() + ")", spTagsTab);
                tpTabbedView.add("Comments (" + f.getComments().size() + ")", spCommentsTab);
                tpTabbedView.add("Credits (" + f.getCredits().size() + ")", spCreditsTab);
                tpTabbedView.add("Attributions (" + f.getAttributions().size() + ")", spAttributionsTab);
                final JTextPane tpFilePreview = new JTextPane();
                tpFilePreview.setEditable(false);
                tpFilePreview.setEditorKit(kit);
                tpFilePreview.setDocument(doc);
                tpFilePreview.addHyperlinkListener((HyperlinkListener)eventHandler);
                final JPanel jpFullFilePreview = new JPanel();
                jpFullFilePreview.setBackground(Color.WHITE);
                jpFullFilePreview.setLayout(new GridBagLayout());
                final GridBagConstraints c = new GridBagConstraints();
                c.gridx = 0;
                c.gridy = 0;
                c.weighty = 0.0;
                jpFullFilePreview.add(tpFilePreview, c);
                c.gridx = 0;
                c.gridy = 1;
                c.weighty = 1.0;
                c.fill = 3;
                c.insets = new Insets(20, 0, 5, 0);
                jpFullFilePreview.add(tpTabbedView, c);
                panelToPopulate.setLayout(new BorderLayout());
                panelToPopulate.add(jpFullFilePreview, "Center");
            }
            catch (Exception e) {
                this.logger.error((Object)"Failed to populate File Preview pane", (Throwable)e);
            }
        }
    }
    
    private void generatePackPreviewContent(final Pack p, final JPanel panelToPopulate, final EventListener eventHandler) {
        if (p != null) {
            try {
                final StringBuffer content = new StringBuffer();
                content.append("<div class='outer'>");
                content.append("<div class='pack'>");
                content.append("<br>");
                content.append("<p class='title'>");
                content.append("Pack: <a href='preview:12:" + p.getURI() + "'>" + p.getTitle() + "</a>");
                content.append("</p>");
                content.append("<br>");
                content.append("<p class='info'>");
                content.append("<b>Creator:</b> <a href='preview:20:" + p.getCreator().getURI() + "'>" + p.getCreator().getName() + "</a><br>");
                content.append("<b>Created at: </b> " + p.getCreatedAt() + "<br>");
                content.append("<b>Last updated at: </b> " + p.getUpdatedAt() + "<br>");
                content.append("</p>");
                content.append("<br>");
                if (!p.getDescription().equals("")) {
                    content.append("<p class='desc'>");
                    content.append("<br>");
                    content.append(Util.stripHTML(p.getDescription()));
                    content.append("<br>");
                    content.append("<br>");
                    content.append("</p>");
                }
                else {
                    content.append("<span class='none_text'>No description</span>");
                }
                content.append("<br>");
                content.append("</div>");
                content.append("</div>");
                final HTMLEditorKit kit = new StyledHTMLEditorKit(this.pluginMainComponent.getStyleSheet());
                final HTMLDocument doc = (HTMLDocument)kit.createDefaultDocument();
                doc.insertAfterStart(doc.getRootElements()[0].getElement(0), content.toString());
                final JScrollPane spPackItemsTab = this.createPackItemPreviewTab(p);
                final JScrollPane spTagsTab = this.createTagPreviewTab(p.getTags());
                final JScrollPane spCommentsTab = this.createCommentsPreviewTab(p.getComments());
                final JTabbedPane tpTabbedView = new JTabbedPane();
                tpTabbedView.addTab("Pack Items (" + p.getItemCount() + ")", spPackItemsTab);
                tpTabbedView.add("Tags (" + p.getTags().size() + ")", spTagsTab);
                tpTabbedView.add("Comments (" + p.getComments().size() + ")", spCommentsTab);
                final JTextPane tpPackPreview = new JTextPane();
                tpPackPreview.setEditable(false);
                tpPackPreview.setEditorKit(kit);
                tpPackPreview.setDocument(doc);
                tpPackPreview.addHyperlinkListener((HyperlinkListener)eventHandler);
                final JPanel jpFullPackPreview = new JPanel();
                jpFullPackPreview.setBackground(Color.WHITE);
                jpFullPackPreview.setLayout(new GridBagLayout());
                final GridBagConstraints c = new GridBagConstraints();
                c.gridx = 0;
                c.gridy = 0;
                c.weighty = 0.0;
                jpFullPackPreview.add(tpPackPreview, c);
                c.gridx = 0;
                c.gridy = 1;
                c.weighty = 1.0;
                c.fill = 3;
                c.insets = new Insets(20, 0, 5, 0);
                jpFullPackPreview.add(tpTabbedView, c);
                panelToPopulate.setLayout(new BorderLayout());
                panelToPopulate.add(jpFullPackPreview, "Center");
            }
            catch (Exception e) {
                this.logger.error((Object)"Failed to populate Pack Preview pane", (Throwable)e);
            }
        }
    }
    
    private void generateUserPreviewContent(final User u, final JPanel panelToPopulate, final EventListener eventHandler) {
        if (u != null) {
            try {
                final StringBuffer content = new StringBuffer();
                content.append("<div class='outer'>");
                content.append("<div class='user'>");
                content.append("<br>");
                content.append("<p class='name'>");
                content.append("User: <a href=preview:20:" + u.getURI() + "'>" + u.getName() + "</a>");
                content.append("</p>");
                content.append("<br>");
                content.append("<p class='info'>");
                String strLocation;
                if (u.getCity().length() == 0 && u.getCountry().length() == 0) {
                    strLocation = "<span class='none_text'>Not specified</span>";
                }
                else {
                    strLocation = u.getCity() + ((u.getCity().length() == 0 || u.getCountry().length() == 0) ? "" : ", ") + u.getCountry();
                }
                content.append("<b>Location:</b> " + strLocation + "<br>");
                content.append("<b>Joined at: </b> " + u.getCreatedAt() + "<br>");
                content.append("<b>Last seen at: </b> " + u.getUpdatedAt() + "<br>");
                content.append("</p>");
                content.append("<br>");
                content.append("<a href='" + u.getAvatarResource() + "'>");
                content.append("<img class='avatar' src='" + u.getAvatarResource() + "'></img>");
                content.append("</a>");
                content.append("<br>");
                content.append("<br>");
                if (!u.getDescription().equals("")) {
                    content.append("<p class='desc'>" + Util.stripHTML(u.getDescription()) + "<br><br></p>");
                }
                else {
                    content.append("<span class='none_text'>No description</span>");
                }
                content.append("<p class='contact_details_header'>Contact Details</p>");
                content.append("<p class='contact_details'>");
                content.append("<b>Email: </b>" + ((u.getEmail().length() == 0) ? "<span class='none_text'>Not specified</span>" : u.getEmail()) + "<br>");
                content.append("<b>Website: </b>" + ((u.getWebsite().length() == 0) ? "<span class='none_text'>Not specified</span>" : u.getWebsite()));
                content.append("</p>");
                content.append("</div>");
                content.append("</div>");
                final HTMLEditorKit kit = new StyledHTMLEditorKit(this.pluginMainComponent.getStyleSheet());
                final HTMLDocument doc = (HTMLDocument)kit.createDefaultDocument();
                doc.insertAfterStart(doc.getRootElements()[0].getElement(0), content.toString());
                final JPanel jpWorkflowsTabContent = new JPanel();
                jpWorkflowsTabContent.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                jpWorkflowsTabContent.setLayout(new BoxLayout(jpWorkflowsTabContent, 1));
                for (final HashMap<String, String> hmCurWF : u.getWorkflows()) {
                    jpWorkflowsTabContent.add(new JClickableLabel(hmCurWF.get("name"), "preview:10:" + hmCurWF.get("uri"), this.pluginMainComponent.getPreviewBrowser(), this.iconWorkflow));
                }
                final JPanel jpFilesTabContent = new JPanel();
                jpFilesTabContent.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                jpFilesTabContent.setLayout(new BoxLayout(jpFilesTabContent, 1));
                for (final HashMap<String, String> hmCurFile : u.getFiles()) {
                    jpFilesTabContent.add(new JClickableLabel(hmCurFile.get("name"), "preview:11:" + hmCurFile.get("uri"), this.pluginMainComponent.getPreviewBrowser(), this.iconFile));
                }
                final JPanel jpPacksTabContent = new JPanel();
                jpPacksTabContent.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                jpPacksTabContent.setLayout(new BoxLayout(jpPacksTabContent, 1));
                for (final HashMap<String, String> hmCurPack : u.getPacks()) {
                    jpPacksTabContent.add(new JClickableLabel(hmCurPack.get("name"), "preview:12:" + hmCurPack.get("uri"), this.pluginMainComponent.getPreviewBrowser(), this.iconPack));
                }
                final JPanel jpFriendsTabContent = new JPanel();
                jpFriendsTabContent.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                jpFriendsTabContent.setLayout(new BoxLayout(jpFriendsTabContent, 1));
                for (final HashMap<String, String> hmCurFriend : u.getFriends()) {
                    jpFriendsTabContent.add(new JClickableLabel(hmCurFriend.get("name"), "preview:20:" + hmCurFriend.get("uri"), this.pluginMainComponent.getPreviewBrowser(), this.iconUser));
                }
                final JPanel jpGroupsTabContent = new JPanel();
                jpGroupsTabContent.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                jpGroupsTabContent.setLayout(new BoxLayout(jpGroupsTabContent, 1));
                for (final HashMap<String, String> hmCurGroup : u.getGroups()) {
                    jpGroupsTabContent.add(new JClickableLabel(hmCurGroup.get("name"), "preview:21:" + hmCurGroup.get("uri"), this.pluginMainComponent.getPreviewBrowser(), this.iconGroup));
                }
                final Dimension dPreferredTabSize = new Dimension(700, 250);
                final JScrollPane spWorkflowsTab = new JScrollPane(jpWorkflowsTabContent);
                spWorkflowsTab.setBorder(BorderFactory.createEmptyBorder());
                spWorkflowsTab.setPreferredSize(dPreferredTabSize);
                spWorkflowsTab.getVerticalScrollBar().setUnitIncrement(10);
                final JScrollPane spFilesTab = new JScrollPane(jpFilesTabContent);
                spFilesTab.setBorder(BorderFactory.createEmptyBorder());
                spFilesTab.setPreferredSize(dPreferredTabSize);
                spFilesTab.getVerticalScrollBar().setUnitIncrement(10);
                final JScrollPane spPacksTab = new JScrollPane(jpPacksTabContent);
                spPacksTab.setBorder(BorderFactory.createEmptyBorder());
                spPacksTab.setPreferredSize(dPreferredTabSize);
                spPacksTab.getVerticalScrollBar().setUnitIncrement(10);
                final JScrollPane spFriendsTab = new JScrollPane(jpFriendsTabContent);
                spFriendsTab.setBorder(BorderFactory.createEmptyBorder());
                spFriendsTab.setPreferredSize(dPreferredTabSize);
                spFriendsTab.getVerticalScrollBar().setUnitIncrement(10);
                final JScrollPane spGroupsTab = new JScrollPane(jpGroupsTabContent);
                spGroupsTab.setBorder(BorderFactory.createEmptyBorder());
                spGroupsTab.setPreferredSize(dPreferredTabSize);
                spGroupsTab.getVerticalScrollBar().setUnitIncrement(10);
                final JTabbedPane tpTabbedItems = new JTabbedPane();
                tpTabbedItems.addTab("Workflows (" + u.getWorkflows().size() + ")", spWorkflowsTab);
                tpTabbedItems.addTab("Files (" + u.getFiles().size() + ")", spFilesTab);
                tpTabbedItems.addTab("Packs (" + u.getPacks().size() + ")", spPacksTab);
                tpTabbedItems.addTab("Friends (" + u.getFriends().size() + ")", spFriendsTab);
                tpTabbedItems.addTab("Groups (" + u.getGroups().size() + ")", spGroupsTab);
                final JTextPane tpUserPreview = new JTextPane();
                tpUserPreview.setEditable(false);
                tpUserPreview.setEditorKit(kit);
                tpUserPreview.setDocument(doc);
                tpUserPreview.addHyperlinkListener((HyperlinkListener)eventHandler);
                final JPanel jpFullUserPreview = new JPanel();
                jpFullUserPreview.setBackground(Color.WHITE);
                jpFullUserPreview.setLayout(new GridBagLayout());
                final GridBagConstraints c = new GridBagConstraints();
                c.gridx = 0;
                c.gridy = 0;
                c.weighty = 0.0;
                jpFullUserPreview.add(tpUserPreview, c);
                c.gridx = 0;
                c.gridy = 1;
                c.weighty = 1.0;
                c.fill = 3;
                c.insets = new Insets(20, 0, 5, 0);
                jpFullUserPreview.add(tpTabbedItems, c);
                panelToPopulate.setLayout(new BorderLayout());
                panelToPopulate.add(jpFullUserPreview, "Center");
            }
            catch (Exception e) {
                this.logger.error((Object)"Failed to populate Workflow Preview pane", (Throwable)e);
            }
        }
    }
    
    private void generateGroupPreviewContent(final Group g, final JPanel panelToPopulate, final EventListener eventHandler) {
        if (g != null) {
            try {
                final StringBuffer content = new StringBuffer();
                content.append("<div class='outer'>");
                content.append("<div class='group'>");
                content.append("<br>");
                content.append("<p class='title'>");
                content.append("Group: <a href='preview:21:" + g.getURI() + "'>" + g.getTitle() + "</a>");
                content.append("</p>");
                content.append("<br>");
                content.append("<p class='info'>");
                content.append("<b>Administrator:</b> <a href='preview:20:" + g.getAdmin().getURI() + "'>" + g.getAdmin().getName() + "</a><br>");
                content.append("<b>Created at: </b> " + g.getCreatedAt() + "<br>");
                content.append("</p>");
                content.append("<br>");
                if (!g.getDescription().equals("")) {
                    content.append("<p class='desc'>");
                    content.append("<br>");
                    content.append(Util.stripHTML(g.getDescription()));
                    content.append("<br>");
                    content.append("</p>");
                }
                else {
                    content.append("<span class='none_text'>No description</span>");
                }
                content.append("<br>");
                content.append("</div>");
                content.append("</div>");
                final HTMLEditorKit kit = new StyledHTMLEditorKit(this.pluginMainComponent.getStyleSheet());
                final HTMLDocument doc = (HTMLDocument)kit.createDefaultDocument();
                doc.insertAfterStart(doc.getRootElements()[0].getElement(0), content.toString());
                final JPanel jpMembersTabContent = this.createStandardTabContentPanel();
                for (final User uCurMember : g.getMembers()) {
                    jpMembersTabContent.add(new JClickableLabel(uCurMember.getName(), "preview:" + uCurMember.getItemType() + ":" + uCurMember.getURI(), this.pluginMainComponent.getPreviewBrowser(), new ImageIcon(MyExperimentPerspective.getLocalIconURL(uCurMember.getItemType()))));
                }
                final JScrollPane spMembersTabContent = this.wrapPreviewTabContentIntoScrollPane(jpMembersTabContent);
                final JPanel jpSharedItemsTabContent = this.createStandardTabContentPanel();
                for (final Resource rCurItem : g.getSharedItems()) {
                    jpSharedItemsTabContent.add(new JClickableLabel(rCurItem.getTitle(), "preview:" + rCurItem.getItemType() + ":" + rCurItem.getURI(), this.pluginMainComponent.getPreviewBrowser(), new ImageIcon(MyExperimentPerspective.getLocalIconURL(rCurItem.getItemType()))));
                }
                final JScrollPane spSharedItemsTabContent = this.wrapPreviewTabContentIntoScrollPane(jpSharedItemsTabContent);
                final JScrollPane spTagsTabContent = this.createTagPreviewTab(g.getTags());
                final JScrollPane spCommentsTab = this.createCommentsPreviewTab(g.getComments());
                final JTabbedPane tpTabbedItems = new JTabbedPane();
                tpTabbedItems.addTab("Members (" + g.getMemberCount() + ")", spMembersTabContent);
                tpTabbedItems.addTab("Shared Items (" + g.getSharedItemCount() + ")", spSharedItemsTabContent);
                tpTabbedItems.addTab("Tags (" + g.getTags().size() + ")", spTagsTabContent);
                tpTabbedItems.addTab("Comments (" + g.getComments().size() + ")", spCommentsTab);
                final JTextPane tpGroupPreview = new JTextPane();
                tpGroupPreview.setEditable(false);
                tpGroupPreview.setEditorKit(kit);
                tpGroupPreview.setDocument(doc);
                tpGroupPreview.addHyperlinkListener((HyperlinkListener)eventHandler);
                final JPanel jpFullGroupPreview = new JPanel();
                jpFullGroupPreview.setBackground(Color.WHITE);
                jpFullGroupPreview.setLayout(new GridBagLayout());
                final GridBagConstraints c = new GridBagConstraints();
                c.gridx = 0;
                c.gridy = 0;
                c.weighty = 0.0;
                jpFullGroupPreview.add(tpGroupPreview, c);
                c.gridx = 0;
                c.gridy = 1;
                c.weighty = 1.0;
                c.fill = 3;
                c.insets = new Insets(20, 0, 5, 0);
                jpFullGroupPreview.add(tpTabbedItems, c);
                panelToPopulate.setLayout(new BorderLayout());
                panelToPopulate.add(jpFullGroupPreview, "Center");
            }
            catch (Exception e) {
                this.logger.error((Object)"Failed to populate Group Preview pane", (Throwable)e);
            }
        }
    }
    
    private JScrollPane createWorkflowComponentPreviewTab(final Workflow w) {
        final JPanel jpWorkflowComponentsTabContent = this.createStandardTabContentPanel();
        if (!w.isTavernaWorkflow()) {
            final JLabel lNotSupported = new JLabel("<html>This is a " + w.getVisibleType() + " workflow;<br>myExperiment can only display Taverna workflow components at the moment.</html>");
            lNotSupported.setFont(lNotSupported.getFont().deriveFont(2));
            lNotSupported.setForeground(Color.GRAY);
            jpWorkflowComponentsTabContent.add(lNotSupported);
        }
        else if (!w.isDownloadAllowed()) {
            final JLabel lNotAuthorized = new JLabel("You are not authorised to download this workflow, and hence component preview is not available.");
            lNotAuthorized.setFont(lNotAuthorized.getFont().deriveFont(2));
            lNotAuthorized.setForeground(Color.GRAY);
            jpWorkflowComponentsTabContent.add(lNotAuthorized);
        }
        else {
            final Vector<String> vColumnNames = new Vector<String>();
            vColumnNames.clear();
            vColumnNames.addAll(Arrays.asList("Name", "Description"));
            final Vector<Vector<String>> vInputsData = new Vector<Vector<String>>();
            final ArrayList<HashMap<String, String>> inputs = w.getComponents().get("inputs");
            if (inputs != null) {
                for (final HashMap<String, String> curInput : inputs) {
                    final Vector<String> vCurData = new Vector<String>();
                    vCurData.add(curInput.get("name"));
                    vCurData.add(curInput.get("description"));
                    vInputsData.add(vCurData);
                }
            }
            final JTable jtInputs = new JTable(vInputsData, vColumnNames);
            jtInputs.getColumnModel().getColumn(0).setPreferredWidth(100);
            jtInputs.getTableHeader().setFont(jtInputs.getTableHeader().getFont().deriveFont(1));
            final JPanel jpInputs = new JPanel();
            jpInputs.setLayout(new BorderLayout());
            jpInputs.add(jtInputs.getTableHeader(), "North");
            jpInputs.add(jtInputs, "Center");
            final JPanel jpInputsWithTitle = new JPanel();
            jpInputsWithTitle.setBorder(BorderFactory.createEtchedBorder());
            jpInputsWithTitle.setLayout(new BorderLayout());
            jpInputsWithTitle.add((Component)new ShadedLabel("Workflow input ports (" + vInputsData.size() + ")", ShadedLabel.BLUE, true), "North");
            if (vInputsData.size() > 0) {
                jpInputsWithTitle.add(jpInputs, "Center");
            }
            vColumnNames.clear();
            vColumnNames.addAll(Arrays.asList("Name", "Type", "Description"));
            final Vector<Vector<String>> vProcessorsData = new Vector<Vector<String>>();
            final ArrayList<HashMap<String, String>> processors = w.getComponents().get("processors");
            if (processors != null) {
                for (final HashMap<String, String> curProcessor : processors) {
                    final Vector<String> vCurData2 = new Vector<String>();
                    vCurData2.add(curProcessor.get("name"));
                    vCurData2.add(curProcessor.get("type"));
                    vCurData2.add(curProcessor.get("description"));
                    vProcessorsData.add(vCurData2);
                }
            }
            final JTable jtProcessors = new JTable(vProcessorsData, vColumnNames);
            jtProcessors.getTableHeader().setFont(jtProcessors.getTableHeader().getFont().deriveFont(1));
            final JPanel jpProcessors = new JPanel();
            jpProcessors.setLayout(new BorderLayout());
            jpProcessors.add(jtProcessors.getTableHeader(), "North");
            jpProcessors.add(jtProcessors, "Center");
            final JPanel jpProcessorsWithTitle = new JPanel();
            jpProcessorsWithTitle.setBorder(BorderFactory.createEtchedBorder());
            jpProcessorsWithTitle.setLayout(new BorderLayout());
            jpProcessorsWithTitle.add((Component)new ShadedLabel("Services (" + vProcessorsData.size() + ")", ShadedLabel.BLUE, true), "North");
            if (vProcessorsData.size() > 0) {
                jpProcessorsWithTitle.add(jpProcessors, "Center");
            }
            vColumnNames.clear();
            vColumnNames.addAll(Arrays.asList("Source", "Sink"));
            final Vector<Vector<String>> vLinksData = new Vector<Vector<String>>();
            final ArrayList<HashMap<String, String>> links = w.getComponents().get("links");
            if (links != null) {
                for (final HashMap<String, String> curLink : links) {
                    final Vector<String> vCurData3 = new Vector<String>();
                    vCurData3.add(curLink.get("source"));
                    vCurData3.add(curLink.get("sink"));
                    vLinksData.add(vCurData3);
                }
            }
            final JTable jtLinks = new JTable(vLinksData, vColumnNames);
            jtLinks.getColumnModel().getColumn(0).setPreferredWidth(100);
            jtLinks.getTableHeader().setFont(jtLinks.getTableHeader().getFont().deriveFont(1));
            final JPanel jpLinks = new JPanel();
            jpLinks.setLayout(new BorderLayout());
            jpLinks.add(jtLinks.getTableHeader(), "North");
            jpLinks.add(jtLinks, "Center");
            final JPanel jpLinksWithTitle = new JPanel();
            jpLinksWithTitle.setBorder(BorderFactory.createEtchedBorder());
            jpLinksWithTitle.setLayout(new BorderLayout());
            jpLinksWithTitle.add((Component)new ShadedLabel("Links (" + vLinksData.size() + ")", ShadedLabel.BLUE, true), "North");
            if (vLinksData.size() > 0) {
                jpLinksWithTitle.add(jpLinks, "Center");
            }
            vColumnNames.clear();
            vColumnNames.addAll(Arrays.asList("Name", "Description"));
            final Vector<Vector<String>> vOutputsData = new Vector<Vector<String>>();
            final ArrayList<HashMap<String, String>> outputs = w.getComponents().get("outputs");
            if (outputs != null) {
                for (final HashMap<String, String> curOutput : outputs) {
                    final Vector<String> vCurData4 = new Vector<String>();
                    vCurData4.add(curOutput.get("name"));
                    vCurData4.add(curOutput.get("description"));
                    vOutputsData.add(vCurData4);
                }
            }
            final JTable jtOutputs = new JTable(vOutputsData, vColumnNames);
            jtOutputs.getColumnModel().getColumn(0).setPreferredWidth(100);
            jtOutputs.getTableHeader().setFont(jtOutputs.getTableHeader().getFont().deriveFont(1));
            final JPanel jpOutputs = new JPanel();
            jpOutputs.setLayout(new BorderLayout());
            jpOutputs.add(jtOutputs.getTableHeader(), "North");
            jpOutputs.add(jtOutputs, "Center");
            final JPanel jpOutputsWithTitle = new JPanel();
            jpOutputsWithTitle.setBorder(BorderFactory.createEtchedBorder());
            jpOutputsWithTitle.setLayout(new BorderLayout());
            jpOutputsWithTitle.add((Component)new ShadedLabel("Workflow output ports (" + vOutputsData.size() + ")", ShadedLabel.BLUE, true), "North");
            if (vOutputsData.size() > 0) {
                jpOutputsWithTitle.add(jpOutputs, "Center");
            }
            jpWorkflowComponentsTabContent.setLayout(new GridBagLayout());
            final GridBagConstraints c = new GridBagConstraints();
            c.gridx = 0;
            c.gridy = -1;
            c.weightx = 1.0;
            c.fill = 2;
            c.anchor = 11;
            jpWorkflowComponentsTabContent.add(jpInputsWithTitle, c);
            c.insets = new Insets(10, 0, 0, 0);
            jpWorkflowComponentsTabContent.add(jpProcessorsWithTitle, c);
            jpWorkflowComponentsTabContent.add(jpLinksWithTitle, c);
            c.weighty = 1.0;
            jpWorkflowComponentsTabContent.add(jpOutputsWithTitle, c);
        }
        return this.wrapPreviewTabContentIntoScrollPane(jpWorkflowComponentsTabContent);
    }
    
    private JScrollPane createPackItemPreviewTab(final Pack p) {
        final JPanel jpPackItemsTabContent = this.createStandardTabContentPanel();
        final GridBagConstraints c = new GridBagConstraints();
        jpPackItemsTabContent.setLayout(new GridBagLayout());
        c.anchor = 18;
        if (p.getItems().size() > 0) {
            int iCnt = 0;
            boolean bNoCommentForPrevItem = false;
            for (final PackItem piCurItem : p.getItems()) {
                c.gridx = 0;
                c.gridy = 3 * iCnt;
                c.weightx = 1.0;
                c.insets = (bNoCommentForPrevItem ? new Insets(7, 0, 0, 0) : new Insets(0, 0, 0, 0));
                c.fill = 0;
                if (piCurItem.isInternalItem()) {
                    jpPackItemsTabContent.add(new JClickableLabel(piCurItem.getItem().getTitle(), "preview:" + piCurItem.getItem().getItemType() + ":" + piCurItem.getItem().getURI(), this.pluginMainComponent.getPreviewBrowser(), new ImageIcon(MyExperimentPerspective.getLocalIconURL(piCurItem.getItem().getItemType()))), c);
                }
                else {
                    jpPackItemsTabContent.add(new JClickableLabel(piCurItem.getTitle(), piCurItem.getLink(), this.pluginMainComponent.getPreviewBrowser(), new ImageIcon(MyExperimentPerspective.getLocalIconURL(piCurItem.getItemType())), 2, piCurItem.getTitle() + " (link: " + piCurItem.getLink() + ")"), c);
                }
                final String strComment = Util.stripAllHTML(piCurItem.getComment());
                bNoCommentForPrevItem = (strComment == null || strComment.length() == 0);
                final JPanel jpWhoAddedTheItem = new JPanel();
                jpWhoAddedTheItem.setLayout(new GridBagLayout());
                final GridBagConstraints c2 = new GridBagConstraints();
                c2.anchor = 18;
                jpWhoAddedTheItem.setBorder(BorderFactory.createEmptyBorder());
                jpWhoAddedTheItem.add(new JLabel("Added by "), c2);
                jpWhoAddedTheItem.add(new JClickableLabel(piCurItem.getUserWhoAddedTheItem().getName(), "preview:20:" + piCurItem.getUserWhoAddedTheItem().getURI(), this.pluginMainComponent.getPreviewBrowser()), c2);
                final String strAddedOnDate = MyExperimentClient.formatDate(piCurItem.getCreatedAt());
                c2.weightx = 1.0;
                jpWhoAddedTheItem.add(new JLabel(" [" + strAddedOnDate + "]"), c2);
                c.gridx = 0;
                c.gridy = 3 * iCnt + 1;
                c.insets = new Insets(0, 25, 0, 0);
                c.weightx = 1.0;
                if (bNoCommentForPrevItem && iCnt + 1 == p.getItems().size()) {
                    c.weighty = 1.0;
                }
                jpPackItemsTabContent.add(jpWhoAddedTheItem, c);
                if (!bNoCommentForPrevItem) {
                    c.gridx = 0;
                    c.gridy = 3 * iCnt + 2;
                    c.fill = 2;
                    c.insets = new Insets(0, 25, 7, 25);
                    c.weightx = 1.0;
                    if (iCnt + 1 == p.getItems().size()) {
                        c.weighty = 1.0;
                    }
                    final DialogTextArea taCommentText = new DialogTextArea("Comment: " + strComment);
                    taCommentText.setOpaque(false);
                    taCommentText.setEditable(false);
                    taCommentText.setLineWrap(true);
                    taCommentText.setWrapStyleWord(true);
                    jpPackItemsTabContent.add((Component)taCommentText, c);
                }
                ++iCnt;
            }
        }
        else {
            c.weighty = 1.0;
            c.weightx = 1.0;
            jpPackItemsTabContent.add(Util.generateNoneTextLabel("None"), c);
        }
        return this.wrapPreviewTabContentIntoScrollPane(jpPackItemsTabContent);
    }
    
    private JScrollPane createTagPreviewTab(final List<Tag> lTags) {
        final TagCloudPanel jpTagTabContent = new TagCloudPanel("Resource tag cloud", 2, this.pluginMainComponent.getPreviewBrowser(), this.pluginMainComponent, this.myExperimentClient, this.logger);
        jpTagTabContent.getTagCloudData().clear();
        jpTagTabContent.getTagCloudData().addAll(lTags);
        jpTagTabContent.refresh();
        final JScrollPane spTagTabContent = this.wrapPreviewTabContentIntoScrollPane(jpTagTabContent);
        spTagTabContent.setHorizontalScrollBarPolicy(31);
        spTagTabContent.setVerticalScrollBarPolicy(21);
        jpTagTabContent.setPreferredSize(spTagTabContent.getPreferredSize());
        return spTagTabContent;
    }
    
    private JScrollPane createCommentsPreviewTab(final List<Comment> comments) {
        final List<Comment> lComments = comments;
        final JPanel jpCommentsTabContent = this.createStandardTabContentPanel();
        if (lComments.size() > 0) {
            final GridBagConstraints c = new GridBagConstraints();
            jpCommentsTabContent.setLayout(new GridBagLayout());
            c.anchor = 18;
            final JLabel lLoading = new JLabel("Loading comments...", new ImageIcon(MyExperimentPerspective.getLocalResourceURL("spinner")), 2);
            lLoading.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 10));
            c.weightx = 1.0;
            c.weighty = 1.0;
            jpCommentsTabContent.add(lLoading, c);
            new Thread("Load comments for preview") {
                @Override
                public void run() {
                    ResourcePreviewFactory.this.myExperimentClient.updateCommentListWithExtraData(lComments);
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            jpCommentsTabContent.removeAll();
                            int iCnt = 0;
                            for (final Comment comment : lComments) {
                                c.gridx = 0;
                                c.gridy = 2 * iCnt;
                                c.weightx = 0.0;
                                c.weighty = 0.0;
                                c.gridwidth = 1;
                                final JClickableLabel lCommentAuthor = new JClickableLabel(comment.getUser().getName(), "preview:" + comment.getUser().getItemType() + ":" + comment.getUser().getURI(), ResourcePreviewFactory.this.pluginMainComponent.getPreviewBrowser(), ResourcePreviewFactory.this.iconUser);
                                jpCommentsTabContent.add(lCommentAuthor, c);
                                c.gridx = 1;
                                c.gridy = 2 * iCnt;
                                c.weightx = 1.0;
                                final String strCommentDate = MyExperimentClient.formatDate(comment.getCreatedAt());
                                final JLabel lCommentDate = new JLabel(" - [" + strCommentDate + "]");
                                lCommentDate.setBorder(lCommentAuthor.getBorder());
                                jpCommentsTabContent.add(lCommentDate, c);
                                c.gridx = 0;
                                c.gridy = 2 * iCnt + 1;
                                c.weightx = 1.0;
                                c.gridwidth = 2;
                                c.fill = 2;
                                if (iCnt + 1 == lComments.size()) {
                                    c.weighty = 1.0;
                                }
                                final DialogTextArea taCommentText = new DialogTextArea(Util.stripAllHTML(comment.getComment()));
                                taCommentText.setBorder(BorderFactory.createEmptyBorder(0, 25, 10, 25));
                                taCommentText.setOpaque(false);
                                taCommentText.setEditable(false);
                                taCommentText.setLineWrap(true);
                                taCommentText.setWrapStyleWord(true);
                                jpCommentsTabContent.add((Component)taCommentText, c);
                                ++iCnt;
                            }
                            jpCommentsTabContent.validate();
                            jpCommentsTabContent.repaint();
                            SwingUtilities.invokeLater(new Runnable() {
                                @Override
                                public void run() {
                                    jpCommentsTabContent.scrollRectToVisible(new Rectangle());
                                }
                            });
                        }
                    });
                }
            }.start();
        }
        else {
            jpCommentsTabContent.add(Util.generateNoneTextLabel("None"));
        }
        final JScrollPane spCommentsTabContent = this.wrapPreviewTabContentIntoScrollPane(jpCommentsTabContent);
        spCommentsTabContent.setHorizontalScrollBarPolicy(31);
        return spCommentsTabContent;
    }
    
    private JScrollPane createCreditsPreviewTab(final List<Resource> lCreditedUsersOrGroups) {
        final JPanel jpCreditsTabContent = this.createStandardTabContentPanel();
        if (lCreditedUsersOrGroups.size() > 0) {
            for (final Resource r : lCreditedUsersOrGroups) {
                jpCreditsTabContent.add(new JClickableLabel(r.getTitle(), "preview:" + r.getItemType() + ":" + r.getURI(), this.pluginMainComponent.getPreviewBrowser(), new ImageIcon(MyExperimentPerspective.getLocalIconURL(r.getItemType()))));
            }
        }
        else {
            jpCreditsTabContent.add(Util.generateNoneTextLabel("None"));
        }
        return this.wrapPreviewTabContentIntoScrollPane(jpCreditsTabContent);
    }
    
    private JScrollPane createAttributionsPreviewTab(final List<Resource> lAttributions) {
        final JPanel jpAttributionsTabContent = this.createStandardTabContentPanel();
        if (lAttributions.size() > 0) {
            for (final Resource r : lAttributions) {
                jpAttributionsTabContent.add(new JClickableLabel(r.getTitle(), "preview:" + r.getItemType() + ":" + r.getURI(), this.pluginMainComponent.getPreviewBrowser(), new ImageIcon(MyExperimentPerspective.getLocalIconURL(r.getItemType()))));
            }
        }
        else {
            jpAttributionsTabContent.add(Util.generateNoneTextLabel("None"));
        }
        return this.wrapPreviewTabContentIntoScrollPane(jpAttributionsTabContent);
    }
    
    private JPanel createStandardTabContentPanel() {
        final JPanel jpTabContentPanel = new JPanel();
        jpTabContentPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        jpTabContentPanel.setLayout(new BoxLayout(jpTabContentPanel, 1));
        return jpTabContentPanel;
    }
    
    private JScrollPane wrapPreviewTabContentIntoScrollPane(final JPanel jpTabContentPanel) {
        final Dimension dPreferredTabSize = new Dimension(700, 250);
        final JScrollPane spTabContent = new JScrollPane(jpTabContentPanel);
        spTabContent.setBorder(BorderFactory.createEmptyBorder());
        spTabContent.setPreferredSize(dPreferredTabSize);
        spTabContent.getVerticalScrollBar().setUnitIncrement(10);
        return spTabContent;
    }
    
    private JPanel wrapTextPaneAndTabbedViewIntoFullPreview(final JTextPane tpHTMLPreview, final JTabbedPane tpTabbedView) {
        final JPanel jpFullPreview = new JPanel();
        jpFullPreview.setBackground(Color.WHITE);
        jpFullPreview.setLayout(new GridBagLayout());
        final GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weighty = 0.0;
        jpFullPreview.add(tpHTMLPreview, c);
        c.gridx = 0;
        c.gridy = 1;
        c.weighty = 1.0;
        c.fill = 3;
        c.insets = new Insets(20, 0, 5, 0);
        jpFullPreview.add(tpTabbedView, c);
        return jpFullPreview;
    }
}
