// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.util.Comparator;
import java.io.Serializable;

public class Tag extends Resource implements Serializable
{
    private String tagName;
    private int count;
    
    public Tag() {
        this.setItemType(30);
    }
    
    public String getTagName() {
        return this.tagName;
    }
    
    public void setTagName(final String tagName) {
        this.tagName = tagName;
    }
    
    public int getCount() {
        return this.count;
    }
    
    public void setCount(final int count) {
        this.count = count;
    }
    
    @Override
    public boolean equals(final Object other) {
        if (!(other instanceof Tag)) {
            return false;
        }
        final Tag otherTag = (Tag)other;
        return this.count == otherTag.count && this.tagName.equals(otherTag.tagName);
    }
    
    @Override
    public String toString() {
        return "Tag (" + this.tagName + ", " + this.count + ")";
    }
    
    public static String getRequiredAPIElements(final int iRequestType) {
        String strElements = "";
        switch (iRequestType) {
            case 5100: {
                strElements += "";
                break;
            }
        }
        return strElements;
    }
    
    public static Tag instantiateTagFromActionCommand(final String strActionCommand) {
        if (!strActionCommand.startsWith("tag:")) {
            return null;
        }
        final Tag t = new Tag();
        t.setTagName(strActionCommand.replaceFirst("tag:", ""));
        return t;
    }
    
    public static class ReversePopularityComparator implements Comparator<Tag>
    {
        @Override
        public int compare(final Tag t1, final Tag t2) {
            if (t1.getCount() == t2.getCount()) {
                return t1.getTagName().compareTo(t2.getTagName());
            }
            return t2.getCount() - t1.getCount();
        }
    }
    
    public static class AlphanumericComparator implements Comparator<Tag>
    {
        @Override
        public int compare(final Tag t1, final Tag t2) {
            return t1.getTagName().compareTo(t2.getTagName());
        }
    }
}
