// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.workbench.myexperiment.config;

import org.apache.taverna.configuration.Configurable;
import javax.swing.JPanel;
import org.apache.taverna.configuration.ConfigurationManager;
import org.apache.taverna.configuration.ConfigurationUIFactory;

public class MyExperimentConfigurationUIFactory implements ConfigurationUIFactory
{
    private ConfigurationManager configurationManager;
    
    public boolean canHandle(final String uuid) {
        return uuid.equals(this.getConfigurable().getUUID());
    }
    
    public JPanel getConfigurationPanel() {
        return new MyExperimentConfigurationPanel();
    }
    
    public Configurable getConfigurable() {
        return (Configurable)new MyExperimentConfiguration(this.configurationManager);
    }
    
    public void setConfigurationManager(final ConfigurationManager configurationManager) {
        this.configurationManager = configurationManager;
    }
}
