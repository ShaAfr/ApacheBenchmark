// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.util.Iterator;
import java.util.Collections;
import java.util.Collection;
import org.jdom.Element;
import org.apache.log4j.Logger;
import org.jdom.Document;
import java.util.ArrayList;
import java.util.List;

public class Pack extends Resource
{
    private int accessType;
    private User creator;
    private List<Tag> tags;
    private List<Comment> comments;
    private ArrayList<PackItem> items;
    
    public Pack() {
        this.setItemType(12);
    }
    
    public int getAccessType() {
        return this.accessType;
    }
    
    public void setAccessType(final int accessType) {
        this.accessType = accessType;
    }
    
    @Override
    public User getCreator() {
        return this.creator;
    }
    
    public void setCreator(final User creator) {
        this.creator = creator;
    }
    
    public List<Tag> getTags() {
        return this.tags;
    }
    
    @Override
    public List<Comment> getComments() {
        return this.comments;
    }
    
    public int getItemCount() {
        return this.items.size();
    }
    
    public ArrayList<PackItem> getItems() {
        return this.items;
    }
    
    public static String getRequiredAPIElements(final int iRequestType) {
        String strElements = "";
        switch (iRequestType) {
            case 5005: {
                strElements += "created-at,updated-at,internal-pack-items,external-pack-items,tags,comments,";
            }
            case 5010: {
                strElements += "owner,";
            }
            case 5015: {
                strElements += "id,title,description,privileges";
                break;
            }
        }
        return strElements;
    }
    
    public static Pack buildFromXML(final Document doc, final MyExperimentClient client, final Logger logger) {
        if (doc == null) {
            return null;
        }
        return buildFromXML(doc.getRootElement(), client, logger);
    }
    
    public static Pack buildFromXML(final Element docRootElement, final MyExperimentClient client, final Logger logger) {
        if (docRootElement == null) {
            return null;
        }
        final Pack p = new Pack();
        try {
            p.setAccessType(Util.getAccessTypeFromXMLElement(docRootElement.getChild("privileges")));
            p.setURI(docRootElement.getAttributeValue("uri"));
            p.setResource(docRootElement.getAttributeValue("resource"));
            String id = docRootElement.getChildText("id");
            if (id == null || id.equals("")) {
                id = "API Error - No pack ID supplied";
                logger.error((Object)("Error while parsing pack XML data - no ID provided for pack with title: \"" + docRootElement.getChildText("title") + "\""));
            }
            p.setID(Integer.parseInt(id));
            p.setTitle(docRootElement.getChildText("title"));
            p.setDescription(docRootElement.getChildText("description"));
            final Element ownerElement = docRootElement.getChild("owner");
            p.setCreator(Util.instantiatePrimitiveUserFromElement(ownerElement));
            final String createdAt = docRootElement.getChildText("created-at");
            if (createdAt != null && !createdAt.equals("")) {
                p.setCreatedAt(MyExperimentClient.parseDate(createdAt));
            }
            final String updatedAt = docRootElement.getChildText("updated-at");
            if (updatedAt != null && !updatedAt.equals("")) {
                p.setUpdatedAt(MyExperimentClient.parseDate(updatedAt));
            }
            p.tags = new ArrayList<Tag>();
            p.getTags().addAll(Util.retrieveTags(docRootElement));
            p.comments = new ArrayList<Comment>();
            p.getComments().addAll(Util.retrieveComments(docRootElement, p));
            p.items = new ArrayList<PackItem>();
            int iCount = 0;
            Element itemsElement = docRootElement.getChild("internal-pack-items");
            if (itemsElement != null) {
                final List<Element> itemsNodes = (List<Element>)itemsElement.getChildren();
                for (final Element e : itemsNodes) {
                    final Document docCurrentItem = client.getResource(14, e.getAttributeValue("uri"), 5100);
                    final PackItem piCurrentItem = PackItem.buildFromXML(docCurrentItem, logger);
                    p.getItems().add(piCurrentItem);
                    ++iCount;
                }
            }
            itemsElement = docRootElement.getChild("external-pack-items");
            if (itemsElement != null) {
                final List<Element> itemsNodes = (List<Element>)itemsElement.getChildren();
                for (final Element e : itemsNodes) {
                    final Document docCurrentItem = client.getResource(15, e.getAttributeValue("uri"), 5100);
                    final PackItem piCurrentItem = PackItem.buildFromXML(docCurrentItem, logger);
                    p.getItems().add(piCurrentItem);
                    ++iCount;
                }
            }
            Collections.sort(p.getItems());
            logger.debug((Object)("Found information for pack with ID: " + p.getID() + ", Title: " + p.getTitle()));
        }
        catch (Exception e2) {
            logger.error((Object)"Failed midway through creating pack object from XML", (Throwable)e2);
        }
        return p;
    }
}
