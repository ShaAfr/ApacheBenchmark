// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.io.Serializable;

public class License implements Serializable
{
    private String type;
    private String text;
    private String link;
    public static String[] SUPPORTED_TYPES;
    public static String DEFAULT_LICENSE;
    
    private License() {
    }
    
    private License(final String type, final String text, final String link) {
        this.type = type;
        this.text = text;
        this.link = link;
    }
    
    public String getType() {
        return this.type;
    }
    
    public String getText() {
        return this.text;
    }
    
    public String getLink() {
        return this.link;
    }
    
    public static License getInstance(final String type) {
        if (type == null) {
            return null;
        }
        if (type.equalsIgnoreCase("by-nd")) {
            return new License(type, "Creative Commons Attribution-NoDerivs 3.0 License", "http://creativecommons.org/licenses/by-nd/3.0/");
        }
        if (type.equalsIgnoreCase("by")) {
            return new License(type, "Creative Commons Attribution 3.0 License", "http://creativecommons.org/licenses/by/3.0/");
        }
        if (type.equalsIgnoreCase("by-sa")) {
            return new License(type, "Creative Commons Attribution-Share Alike 3.0 License", "http://creativecommons.org/licenses/by-sa/3.0/");
        }
        if (type.equalsIgnoreCase("by-nc-nd")) {
            return new License(type, "Creative Commons Attribution-Noncommercial-NoDerivs 3.0 License", "http://creativecommons.org/licenses/by-nc-nd/3.0/");
        }
        if (type.equalsIgnoreCase("by-nc")) {
            return new License(type, "Creative Commons Attribution-Noncommercial 3.0 License", "http://creativecommons.org/licenses/by-nc/3.0/");
        }
        if (type.equalsIgnoreCase("by-nc-sa")) {
            return new License(type, "Creative Commons Attribution-Noncommercial-Share Alike 3.0 License", "http://creativecommons.org/licenses/by-nc-sa/3.0/");
        }
        return null;
    }
    
    static {
        License.SUPPORTED_TYPES = new String[] { "by-nd", "by", "by-sa", "by-nc-nd", "by-nc", "by-nc-sa" };
        License.DEFAULT_LICENSE = "by-sa";
    }
}
