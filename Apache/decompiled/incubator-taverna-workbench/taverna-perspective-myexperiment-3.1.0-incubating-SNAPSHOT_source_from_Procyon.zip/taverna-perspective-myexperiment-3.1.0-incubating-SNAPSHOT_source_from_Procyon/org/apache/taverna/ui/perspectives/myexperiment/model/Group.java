// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.util.Iterator;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import org.jdom.Element;
import org.apache.log4j.Logger;
import org.jdom.Document;
import java.util.List;

public class Group extends Resource
{
    private User admin;
    private List<Tag> tags;
    private List<Comment> comments;
    private List<User> members;
    private List<Resource> sharedItems;
    
    public Group() {
        this.setItemType(21);
    }
    
    @Override
    public User getAdmin() {
        return this.admin;
    }
    
    public void setAdmin(final User admin) {
        this.admin = admin;
    }
    
    public List<Tag> getTags() {
        return this.tags;
    }
    
    @Override
    public List<Comment> getComments() {
        return this.comments;
    }
    
    public int getSharedItemCount() {
        return this.sharedItems.size();
    }
    
    public int getMemberCount() {
        return this.members.size();
    }
    
    public List<Resource> getSharedItems() {
        return this.sharedItems;
    }
    
    public List<User> getMembers() {
        return this.members;
    }
    
    public static String getRequiredAPIElements(final int iRequestType) {
        String strElements = "";
        switch (iRequestType) {
            case 5005: {
                strElements += "created-at,updated-at,members,shared-items,tags,comments,";
            }
            case 5010: {
                strElements += "owner,";
            }
            case 5015: {
                strElements += "id,title,description";
                break;
            }
        }
        return strElements;
    }
    
    public static Group buildFromXML(final Document doc, final Logger logger) {
        if (doc == null) {
            return null;
        }
        return buildFromXML(doc.getRootElement(), logger);
    }
    
    public static Group buildFromXML(final Element docRootElement, final Logger logger) {
        if (docRootElement == null) {
            return null;
        }
        final Group g = new Group();
        try {
            g.setURI(docRootElement.getAttributeValue("uri"));
            g.setResource(docRootElement.getAttributeValue("resource"));
            String id = docRootElement.getChildText("id");
            if (id == null || id.equals("")) {
                id = "API Error - No group ID supplied";
                logger.error((Object)("Error while parsing group XML data - no ID provided for group with title: \"" + docRootElement.getChildText("title") + "\""));
            }
            g.setID(Integer.parseInt(id));
            g.setTitle(docRootElement.getChildText("title"));
            g.setDescription(docRootElement.getChildText("description"));
            final Element ownerElement = docRootElement.getChild("owner");
            g.setAdmin(Util.instantiatePrimitiveUserFromElement(ownerElement));
            final String createdAt = docRootElement.getChildText("created-at");
            if (createdAt != null && !createdAt.equals("")) {
                g.setCreatedAt(MyExperimentClient.parseDate(createdAt));
            }
            final String updatedAt = docRootElement.getChildText("updated-at");
            if (updatedAt != null && !updatedAt.equals("")) {
                g.setUpdatedAt(MyExperimentClient.parseDate(updatedAt));
            }
            g.tags = new ArrayList<Tag>();
            g.getTags().addAll(Util.retrieveTags(docRootElement));
            g.comments = new ArrayList<Comment>();
            g.getComments().addAll(Util.retrieveComments(docRootElement, g));
            g.members = new ArrayList<User>();
            final Element membersElement = docRootElement.getChild("members");
            if (membersElement != null) {
                final List<Element> memberNodes = (List<Element>)membersElement.getChildren();
                for (final Element e : memberNodes) {
                    g.getMembers().add(Util.instantiatePrimitiveUserFromElement(e));
                }
            }
            Collections.sort(g.getMembers());
            g.sharedItems = new ArrayList<Resource>();
            final Element sharedItemsElement = docRootElement.getChild("shared-items");
            if (sharedItemsElement != null) {
                final List<Element> itemsNodes = (List<Element>)sharedItemsElement.getChildren();
                for (final Element e2 : itemsNodes) {
                    g.getSharedItems().add(Util.instantiatePrimitiveResourceFromElement(e2));
                }
            }
            Collections.sort(g.getSharedItems());
            logger.debug((Object)("Found information for group with ID: " + g.getID() + ", Title: " + g.getTitle()));
        }
        catch (Exception e3) {
            logger.error((Object)"Failed midway through creating group object from XML", (Throwable)e3);
        }
        return g;
    }
}
