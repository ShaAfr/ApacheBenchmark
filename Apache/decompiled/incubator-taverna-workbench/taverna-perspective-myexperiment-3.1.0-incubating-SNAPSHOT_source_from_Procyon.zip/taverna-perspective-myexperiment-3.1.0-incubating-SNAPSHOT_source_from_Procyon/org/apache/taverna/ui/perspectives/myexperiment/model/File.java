// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.util.Collection;
import java.util.ArrayList;
import org.jdom.Element;
import org.apache.log4j.Logger;
import org.jdom.Document;
import java.util.List;

public class File extends Resource
{
    private int accessType;
    private User uploader;
    private License license;
    private String filename;
    private String visibleType;
    private String contentType;
    private List<Tag> tags;
    private List<Comment> comments;
    private List<Resource> credits;
    private List<Resource> attributions;
    
    public File() {
        this.setItemType(11);
    }
    
    public int getAccessType() {
        return this.accessType;
    }
    
    public void setAccessType(final int accessType) {
        this.accessType = accessType;
    }
    
    public List<Tag> getTags() {
        return this.tags;
    }
    
    @Override
    public User getUploader() {
        return this.uploader;
    }
    
    public void setUploader(final User uploader) {
        this.uploader = uploader;
    }
    
    public License getLicense() {
        return this.license;
    }
    
    public void setLicense(final License license) {
        this.license = license;
    }
    
    public String getFilename() {
        return this.filename;
    }
    
    public void setFilename(final String filename) {
        this.filename = filename;
    }
    
    public String getContentType() {
        return this.contentType;
    }
    
    public void setContentType(final String contentType) {
        this.contentType = contentType;
    }
    
    @Override
    public String getVisibleType() {
        return this.visibleType;
    }
    
    public void setVisibleType(final String visibleType) {
        this.visibleType = visibleType;
    }
    
    @Override
    public List<Comment> getComments() {
        return this.comments;
    }
    
    public List<Resource> getCredits() {
        return this.credits;
    }
    
    public List<Resource> getAttributions() {
        return this.attributions;
    }
    
    public static String getRequiredAPIElements(final int iRequestType) {
        String strElements = "";
        switch (iRequestType) {
            case 5005: {
                strElements += "filename,content-type,created-at,updated-at,license-type,tags,comments,credits,attributions,";
            }
            case 5010: {
                strElements += "uploader,type,";
            }
            case 5015: {
                strElements += "id,title,description,privileges";
                break;
            }
        }
        return strElements;
    }
    
    public static File buildFromXML(final Document doc, final Logger logger) {
        if (doc == null) {
            return null;
        }
        return buildFromXML(doc.getRootElement(), logger);
    }
    
    public static File buildFromXML(final Element docRootElement, final Logger logger) {
        if (docRootElement == null) {
            return null;
        }
        final File f = new File();
        try {
            f.setAccessType(Util.getAccessTypeFromXMLElement(docRootElement.getChild("privileges")));
            f.setURI(docRootElement.getAttributeValue("uri"));
            f.setResource(docRootElement.getAttributeValue("resource"));
            String id = docRootElement.getChildText("id");
            if (id == null || id.equals("")) {
                id = "API Error - No file ID supplied";
                logger.error((Object)("Error while parsing file XML data - no ID provided for file with title: \"" + docRootElement.getChildText("title") + "\""));
            }
            f.setID(id);
            f.setFilename(docRootElement.getChildText("filename"));
            f.setTitle(docRootElement.getChildText("title"));
            f.setDescription(docRootElement.getChildText("description"));
            final Element uploaderElement = docRootElement.getChild("uploader");
            f.setUploader(Util.instantiatePrimitiveUserFromElement(uploaderElement));
            final String createdAt = docRootElement.getChildText("created-at");
            if (createdAt != null && !createdAt.equals("")) {
                f.setCreatedAt(MyExperimentClient.parseDate(createdAt));
            }
            final String updatedAt = docRootElement.getChildText("updated-at");
            if (updatedAt != null && !updatedAt.equals("")) {
                f.setUpdatedAt(MyExperimentClient.parseDate(updatedAt));
            }
            f.setLicense(License.getInstance(docRootElement.getChildText("license-type")));
            f.setVisibleType(docRootElement.getChildText("type"));
            f.setContentType(docRootElement.getChildText("content-type"));
            f.tags = new ArrayList<Tag>();
            f.getTags().addAll(Util.retrieveTags(docRootElement));
            f.comments = new ArrayList<Comment>();
            f.getComments().addAll(Util.retrieveComments(docRootElement, f));
            f.credits = new ArrayList<Resource>();
            f.getCredits().addAll(Util.retrieveCredits(docRootElement));
            f.attributions = new ArrayList<Resource>();
            f.getAttributions().addAll(Util.retrieveAttributions(docRootElement));
            logger.debug((Object)("Found information for file with ID: " + f.getID() + ", Title: " + f.getTitle()));
        }
        catch (Exception e) {
            logger.error((Object)"Failed midway through creating file object from XML", (Throwable)e);
        }
        return f;
    }
}
