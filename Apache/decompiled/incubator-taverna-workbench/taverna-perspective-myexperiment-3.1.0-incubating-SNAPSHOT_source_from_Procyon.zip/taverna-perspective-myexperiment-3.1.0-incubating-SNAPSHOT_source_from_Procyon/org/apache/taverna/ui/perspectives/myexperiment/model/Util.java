// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.net.UnknownHostException;
import java.net.InetAddress;
import java.util.Collection;
import java.util.TreeSet;
import java.util.Arrays;
import javax.swing.BorderFactory;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.Icon;
import java.util.EventListener;
import org.apache.taverna.ui.perspectives.myexperiment.MyExperimentPerspective;
import org.apache.taverna.ui.perspectives.myexperiment.JClickableLabel;
import java.awt.event.ActionListener;
import java.awt.Component;
import java.util.List;
import org.jdom.Document;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;
import org.jdom.Element;
import java.awt.image.RenderedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.net.URL;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.crypto.SecretKey;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.PBEParameterSpec;
import java.security.MessageDigest;
import java.security.spec.KeySpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.SecretKeyFactory;
import org.apache.log4j.Logger;

public class Util
{
    private static Logger logger;
    private static final String PBE_PASSWORD;
    private static final String PBE_SALT;
    
    public static byte[] encrypt(final String str) {
        return doEncryption(str, 1);
    }
    
    public static byte[] decrypt(final String str) {
        return doEncryption(str, 2);
    }
    
    private static byte[] doEncryption(final String str, final int mode) {
        try {
            final SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
            final PBEKeySpec keySpec = new PBEKeySpec(Util.PBE_PASSWORD.toCharArray());
            final SecretKey key = keyFactory.generateSecret(keySpec);
            final MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(Util.PBE_SALT.getBytes());
            final byte[] digest = md.digest();
            final byte[] salt = new byte[8];
            for (int i = 0; i < 8; ++i) {
                salt[i] = digest[i];
            }
            final PBEParameterSpec paramSpec = new PBEParameterSpec(salt, 20);
            final Cipher cipher = Cipher.getInstance("PBEWithMD5AndDES");
            cipher.init(mode, key, paramSpec);
            final byte[] encrypted = cipher.doFinal(str.getBytes());
            return encrypted;
        }
        catch (Exception e) {
            Util.logger.error((Object)"Could not encrypt and store password");
            Util.logger.error((Object)(e.getCause() + "\n" + e.getMessage()));
            return new byte[1];
        }
    }
    
    public static ImageIcon getResizedImageIcon(final ImageIcon sourceImageIcon, final int iRequiredWidth, final int iRequiredHeight) {
        final int iWidth = sourceImageIcon.getIconWidth();
        final int iHeight = sourceImageIcon.getIconHeight();
        final float fWidthResizeRatio = iWidth / (float)iRequiredWidth;
        final float fHeightResizeRatio = iHeight / (float)iRequiredHeight;
        final float fResizeRatio = Math.max(fWidthResizeRatio, fHeightResizeRatio);
        final int iNewWidth = Math.round(iWidth / fResizeRatio);
        final int iNewHeight = Math.round(iHeight / fResizeRatio);
        final BufferedImage resizedImage = new BufferedImage(iNewWidth, iNewHeight, 1);
        final Graphics2D g2 = resizedImage.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(sourceImageIcon.getImage(), 0, 0, iNewWidth, iNewHeight, null);
        g2.dispose();
        return new ImageIcon(resizedImage, "");
    }
    
    public static String getResizedImageIconTempFileURL(final URL sourceImageURL, final int iRequiredWidth, final int iRequiredHeight) {
        File fDestinationTempFile = null;
        try {
            fDestinationTempFile = File.createTempFile("resized_image", "jpg");
            fDestinationTempFile.deleteOnExit();
            final ImageIcon sourceImageIcon = new ImageIcon(sourceImageURL);
            final ImageIcon resizedImageIcon = getResizedImageIcon(sourceImageIcon, iRequiredWidth, iRequiredHeight);
            final Image img = resizedImageIcon.getImage();
            final BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), 1);
            final Graphics2D g2 = bi.createGraphics();
            g2.drawImage(img, 0, 0, null);
            g2.dispose();
            ImageIO.write(bi, "jpg", fDestinationTempFile);
        }
        catch (Exception ex) {}
        return "file:///" + fDestinationTempFile.getAbsolutePath();
    }
    
    public static Resource instantiatePrimitiveResourceFromElement(final Element e) {
        if (e != null) {
            final Resource r = new Resource();
            r.setItemType(e.getName());
            r.setTitle(e.getText());
            r.setURI(e.getAttributeValue("uri"));
            r.setResource(e.getAttributeValue("resource"));
            return r;
        }
        return null;
    }
    
    public static User instantiatePrimitiveUserFromElement(final Element e) {
        if (e != null) {
            final User u = new User();
            u.setName(e.getText());
            u.setTitle(e.getText());
            u.setURI(e.getAttributeValue("uri"));
            u.setResource(e.getAttributeValue("resource"));
            return u;
        }
        return null;
    }
    
    public static Tag instantiatePrimitiveTagFromElement(final Element e) {
        if (e != null) {
            final Tag t = new Tag();
            t.setTitle(e.getText());
            t.setTagName(e.getText());
            t.setResource(e.getAttributeValue("resource"));
            t.setURI(e.getAttributeValue("uri"));
            return t;
        }
        return null;
    }
    
    public static Comment instantiatePrimitiveCommentFromElement(final Element e, final Resource r) {
        if (e != null) {
            final Comment c = new Comment();
            c.setTitle(e.getText());
            c.setComment(e.getText());
            c.setTypeOfCommentedResource(r.getItemType());
            c.setURIOfCommentedResource(r.getURI());
            c.setResource(e.getAttributeValue("resource"));
            c.setURI(e.getAttributeValue("uri"));
            return c;
        }
        return null;
    }
    
    public static int getResourceCollectionFromXMLIterator(final Iterator<Element> iterator, final ArrayList<HashMap<String, String>> collection) {
        int iCount = 0;
        while (iterator.hasNext()) {
            final Element element = iterator.next();
            final HashMap<String, String> itemDetails = new HashMap<String, String>();
            itemDetails.put("name", element.getText());
            itemDetails.put("uri", element.getAttributeValue("uri"));
            itemDetails.put("resource", element.getAttributeValue("resource"));
            collection.add(itemDetails);
            ++iCount;
        }
        return iCount;
    }
    
    public static int getAccessTypeFromXMLElement(final Element privileges) {
        int iAccessType = 1000;
        for (final Element privilege : privileges.getChildren("privilege")) {
            final String strValue = privilege.getAttributeValue("type");
            int iCurrentPrivilege = 1000;
            if (strValue.equals("download")) {
                iCurrentPrivilege = 1001;
            }
            else if (strValue.equals("edit")) {
                iCurrentPrivilege = 1002;
            }
            if (iCurrentPrivilege > iAccessType) {
                iAccessType = iCurrentPrivilege;
            }
        }
        return iAccessType;
    }
    
    public static String retrieveReasonFromErrorXMLDocument(final Document doc) {
        if (doc != null) {
            final Element root = doc.getRootElement();
            return root.getChildText("reason");
        }
        return "unknown reason";
    }
    
    public static List<Resource> retrieveUserFavourites(final Element docRootElement) {
        final List<Resource> favouritedItemList = new ArrayList<Resource>();
        final Element favouritesElement = docRootElement.getChild("favourited");
        if (favouritesElement != null) {
            final Iterator<Element> iFavourites = favouritesElement.getChildren().iterator();
            while (iFavourites.hasNext()) {
                favouritedItemList.add(instantiatePrimitiveResourceFromElement(iFavourites.next()));
            }
        }
        return favouritedItemList;
    }
    
    public static List<Resource> retrieveCredits(final Element docRootElement) {
        final List<Resource> credits = new ArrayList<Resource>();
        final Element creditsElement = docRootElement.getChild("credits");
        if (creditsElement != null) {
            final List<Element> creditsNodes = (List<Element>)creditsElement.getChildren();
            for (final Element e : creditsNodes) {
                credits.add(instantiatePrimitiveResourceFromElement(e));
            }
        }
        return credits;
    }
    
    public static List<Resource> retrieveAttributions(final Element docRootElement) {
        final List<Resource> attributions = new ArrayList<Resource>();
        final Element attributionsElement = docRootElement.getChild("attributions");
        if (attributionsElement != null) {
            final List<Element> attributionsNodes = (List<Element>)attributionsElement.getChildren();
            for (final Element e : attributionsNodes) {
                attributions.add(instantiatePrimitiveResourceFromElement(e));
            }
        }
        return attributions;
    }
    
    public static List<Tag> retrieveTags(final Element docRootElement) {
        final List<Tag> tags = new ArrayList<Tag>();
        final Element tagsElement = docRootElement.getChild("tags");
        if (tagsElement != null) {
            final List<Element> tagsNodes = (List<Element>)tagsElement.getChildren();
            for (final Element e : tagsNodes) {
                tags.add(instantiatePrimitiveTagFromElement(e));
            }
        }
        return tags;
    }
    
    public static List<Comment> retrieveComments(final Element docRootElement, final Resource r) {
        final List<Comment> comments = new ArrayList<Comment>();
        final Element tagsElement = docRootElement.getChild("comments");
        if (tagsElement != null) {
            final List<Element> tagsNodes = (List<Element>)tagsElement.getChildren();
            for (final Element e : tagsNodes) {
                comments.add(instantiatePrimitiveCommentFromElement(e, r));
            }
        }
        return comments;
    }
    
    public static String stripHTML(String source) {
        if (source == null) {
            return "";
        }
        source = source.replaceAll("</p>[\r\n]*<p>", "<br>");
        source = source.replaceAll("\\<br/?\\>", "[-=BR=-]");
        source = source.replaceAll("\\<.*?\\>", "");
        source = source.replaceAll("\\[-=BR=-\\]", "<br><br>");
        return source;
    }
    
    public static String stripAllHTML(String source) {
        if (source == null) {
            return "";
        }
        source = source.replaceAll("</p>[\r\n]*<p>", "<br>");
        source = source.replaceAll("\\<br/?\\>", "\n\n");
        source = source.replaceAll("\\<.*?\\>", "");
        source = source.replaceAll("&\\w{1,4};", "");
        return source;
    }
    
    public static void centerComponentWithinAnother(final Component mainComponent, final Component dependentComponent) {
        final int iMainComponentCenterX = (int)Math.round(mainComponent.getLocationOnScreen().getX() + mainComponent.getWidth() / 2);
        final int iPosX = iMainComponentCenterX - dependentComponent.getWidth() / 2;
        final int iMainComponentCenterY = (int)Math.round(mainComponent.getLocationOnScreen().getY() + mainComponent.getHeight() / 2);
        final int iPosY = iMainComponentCenterY - dependentComponent.getHeight() / 2;
        dependentComponent.setLocation(iPosX, iPosY);
    }
    
    public static JClickableLabel generateClickableLabelFor(final Resource r, final ActionListener clickHandler) {
        return new JClickableLabel(r.getTitle(), "preview:" + r.getItemType() + ":" + r.getURI(), clickHandler, new ImageIcon(MyExperimentPerspective.getLocalIconURL(r.getItemType())), 2, r.getItemTypeName() + ": " + r.getTitle());
    }
    
    public static JLabel generateNoneTextLabel(final String strLabel) {
        final JLabel lNoneText = new JLabel(strLabel);
        lNoneText.setFont(lNoneText.getFont().deriveFont(2));
        lNoneText.setForeground(Color.GRAY);
        lNoneText.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        return lNoneText;
    }
    
    public static String composeAPIQueryElements(final SearchEngine.QuerySearchInstance queryInstance) {
        String strElements = "";
        if (queryInstance == null || queryInstance.getSearchWorkflows()) {
            strElements = strElements + Workflow.getRequiredAPIElements(5010) + ",";
        }
        if (queryInstance == null || queryInstance.getSearchFiles()) {
            strElements = strElements + org.apache.taverna.ui.perspectives.myexperiment.model.File.getRequiredAPIElements(5010) + ",";
        }
        if (queryInstance == null || queryInstance.getSearchPacks()) {
            strElements = strElements + Pack.getRequiredAPIElements(5010) + ",";
        }
        if (queryInstance == null || queryInstance.getSearchUsers()) {
            strElements = strElements + User.getRequiredAPIElements(5010) + ",";
        }
        if (queryInstance == null || queryInstance.getSearchGroups()) {
            strElements = strElements + Group.getRequiredAPIElements(5010) + ",";
        }
        final TreeSet<String> elementSet = new TreeSet<String>(Arrays.asList(strElements.split(",")));
        final Iterator<String> elementSetIterator = elementSet.iterator();
        strElements = "&elements=";
        while (elementSetIterator.hasNext()) {
            strElements += elementSetIterator.next();
            if (elementSetIterator.hasNext()) {
                strElements += ",";
            }
        }
        return strElements;
    }
    
    public static String getBaseClassName(final String strClassName) {
        String strResult = strClassName;
        final int iDollarIdx = strResult.indexOf("$");
        if (iDollarIdx != -1) {
            strResult = strResult.substring(0, iDollarIdx);
        }
        return strResult;
    }
    
    static {
        Util.logger = Logger.getLogger((Class)Util.class);
        PBE_PASSWORD = System.getProperty("user.home");
        String host_name = "";
        try {
            host_name = InetAddress.getLocalHost().toString();
        }
        catch (UnknownHostException e) {
            host_name = "unknown_localhost";
        }
        PBE_SALT = host_name;
    }
}
