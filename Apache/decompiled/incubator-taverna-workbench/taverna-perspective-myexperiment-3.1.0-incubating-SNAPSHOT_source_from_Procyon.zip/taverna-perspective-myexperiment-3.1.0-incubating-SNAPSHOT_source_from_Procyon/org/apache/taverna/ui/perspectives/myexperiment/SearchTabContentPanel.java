// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import java.text.ParseException;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.Icon;
import java.util.EventListener;
import org.apache.taverna.workbench.icons.WorkbenchIcons;
import org.apache.taverna.ui.perspectives.myexperiment.model.Util;
import java.util.List;
import java.util.Collections;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import java.awt.Dimension;
import javax.swing.SwingUtilities;
import org.apache.taverna.ui.perspectives.myexperiment.model.Base64;
import java.util.Vector;
import java.util.LinkedList;
import org.apache.taverna.ui.perspectives.myexperiment.model.SearchEngine;
import javax.swing.ImageIcon;
import javax.swing.JSplitPane;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

public class SearchTabContentPanel extends JPanel implements ActionListener
{
    private static final int SEARCH_HISTORY_LENGTH = 50;
    private static final int SEARCH_FAVOURITES_LENGTH = 30;
    protected static final String SEARCH_FROM_FAVOURITES = "searchFromFavourites";
    protected static final String SEARCH_FROM_HISTORY = "searchFromHistory";
    protected static final String ADD_FAVOURITE_SEARCH_INSTANCE = "addFavouriteSearchInstance";
    protected static final String REMOVE_FAVOURITE_SEARCH_INSTANCE = "removeFavouriteSearchInstance";
    private final MainComponent pluginMainComponent;
    private final MyExperimentClient myExperimentClient;
    private final Logger logger;
    private JSplitPane spMainSplitPane;
    private SearchOptionsPanel jpSearchOptions;
    private JPanel jpFavouriteSearches;
    private JPanel jpSearchHistory;
    private SearchResultsPanel jpSearchResults;
    private final ImageIcon iconFavourite;
    private final ImageIcon iconRemove;
    private SearchEngine.QuerySearchInstance siPreviousSearch;
    private LinkedList<SearchEngine.QuerySearchInstance> llFavouriteSearches;
    private LinkedList<SearchEngine.QuerySearchInstance> llSearchHistory;
    private final SearchEngine searchEngine;
    private final Vector<Long> vCurrentSearchThreadID;
    
    public SearchTabContentPanel(final MainComponent component, final MyExperimentClient client, final Logger logger) {
        this.iconFavourite = new ImageIcon(MyExperimentPerspective.getLocalResourceURL("favourite_icon"));
        this.iconRemove = new ImageIcon(MyExperimentPerspective.getLocalResourceURL("destroy_icon"));
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        final String strFavouriteSearches = (String)this.myExperimentClient.getSettings().get("favourite_searches");
        if (strFavouriteSearches != null) {
            final Object oFavouriteSearches = Base64.decodeToObject(strFavouriteSearches);
            this.llFavouriteSearches = (LinkedList<SearchEngine.QuerySearchInstance>)oFavouriteSearches;
        }
        else {
            this.llFavouriteSearches = new LinkedList<SearchEngine.QuerySearchInstance>();
        }
        final String strSearchHistory = (String)this.myExperimentClient.getSettings().get("search_history");
        if (strSearchHistory != null) {
            final Object oSearchHistory = Base64.decodeToObject(strSearchHistory);
            this.llSearchHistory = (LinkedList<SearchEngine.QuerySearchInstance>)oSearchHistory;
        }
        else {
            this.llSearchHistory = new LinkedList<SearchEngine.QuerySearchInstance>();
        }
        this.initialiseUI();
        this.updateFavouriteSearches();
        this.updateSearchHistory();
        (this.vCurrentSearchThreadID = new Vector<Long>(1)).add(null);
        this.searchEngine = new SearchEngine(this.vCurrentSearchThreadID, false, this.jpSearchResults, this.pluginMainComponent, this.myExperimentClient, logger);
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                SearchTabContentPanel.this.spMainSplitPane.setDividerLocation(390);
                SearchTabContentPanel.this.spMainSplitPane.setOneTouchExpandable(true);
                SearchTabContentPanel.this.spMainSplitPane.setDoubleBuffered(true);
            }
        });
    }
    
    private void initialiseUI() {
        (this.jpSearchOptions = new SearchOptionsPanel(this, this.pluginMainComponent, this.myExperimentClient, this.logger)).setMaximumSize(new Dimension(1024, 0));
        (this.jpFavouriteSearches = new JPanel()).setMaximumSize(new Dimension(1024, 0));
        this.jpFavouriteSearches.setLayout(new GridBagLayout());
        this.jpFavouriteSearches.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), " Favourite Searches "), BorderFactory.createEmptyBorder(0, 5, 5, 5)));
        (this.jpSearchHistory = new JPanel()).setMaximumSize(new Dimension(1024, 0));
        this.jpSearchHistory.setLayout(new GridBagLayout());
        this.jpSearchHistory.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), " Search History "), BorderFactory.createEmptyBorder(0, 5, 5, 5)));
        final JPanel jpSearchSidebar = new JPanel();
        jpSearchSidebar.setLayout(new GridBagLayout());
        final GridBagConstraints gbConstraints = new GridBagConstraints();
        gbConstraints.anchor = 18;
        gbConstraints.fill = 1;
        gbConstraints.weightx = 1.0;
        gbConstraints.gridx = 0;
        gbConstraints.gridy = 0;
        jpSearchSidebar.add(this.jpSearchOptions, gbConstraints);
        gbConstraints.gridy = 1;
        jpSearchSidebar.add(this.jpFavouriteSearches, gbConstraints);
        gbConstraints.gridy = 2;
        jpSearchSidebar.add(this.jpSearchHistory, gbConstraints);
        final JPanel jpSidebarContainer = new JPanel();
        jpSidebarContainer.setLayout(new BorderLayout());
        jpSidebarContainer.add(jpSearchSidebar, "North");
        final JScrollPane spSearchSidebar = new JScrollPane(jpSidebarContainer);
        spSearchSidebar.getVerticalScrollBar().setUnitIncrement(10);
        spSearchSidebar.setMinimumSize(new Dimension(jpSidebarContainer.getMinimumSize().width + 20, 0));
        this.jpSearchResults = new SearchResultsPanel(this, this.pluginMainComponent, this.myExperimentClient, this.logger);
        (this.spMainSplitPane = new JSplitPane()).setLeftComponent(spSearchSidebar);
        this.spMainSplitPane.setRightComponent(this.jpSearchResults);
        this.setLayout(new BorderLayout());
        this.add(this.spMainSplitPane);
    }
    
    private void addToSearchListQueue(final LinkedList<SearchEngine.QuerySearchInstance> searchInstanceList, final SearchEngine.QuerySearchInstance searchInstanceToAdd, final int queueSize) {
        final int iDuplicateIdx = searchInstanceList.indexOf(searchInstanceToAdd);
        if (searchInstanceList.size() == 0 || iDuplicateIdx != searchInstanceList.size() - 1) {
            if (iDuplicateIdx >= 0) {
                searchInstanceList.remove(iDuplicateIdx);
            }
            if (searchInstanceList.size() >= queueSize) {
                searchInstanceList.remove();
            }
            searchInstanceList.offer(searchInstanceToAdd);
        }
    }
    
    private void addToFavouriteSearches(final SearchEngine.QuerySearchInstance searchInstance) {
        this.addToSearchListQueue(this.llFavouriteSearches, searchInstance, 30);
        Collections.sort(this.llFavouriteSearches);
    }
    
    protected void updateFavouriteSearches() {
        this.jpFavouriteSearches.removeAll();
        if (this.llFavouriteSearches.size() == 0) {
            final GridBagConstraints c = new GridBagConstraints();
            c.weightx = 1.0;
            c.anchor = 17;
            this.jpFavouriteSearches.add(Util.generateNoneTextLabel("No favourite searches"), c);
        }
        else {
            for (int i = this.llFavouriteSearches.size() - 1; i >= 0; --i) {
                this.addEntryToSearchListingPanel(this.llFavouriteSearches, i, "searchFromFavourites", this.jpFavouriteSearches, this.iconRemove, "removeFavouriteSearchInstance", "<html>Click to remove from your local favourite searches.<br>(This will not affect your myExperiment profile settings.)</html>");
            }
        }
        this.jpFavouriteSearches.repaint();
        this.jpFavouriteSearches.revalidate();
    }
    
    private void addToSearchHistory(final SearchEngine.QuerySearchInstance searchInstance) {
        this.addToSearchListQueue(this.llSearchHistory, searchInstance, 50);
    }
    
    protected void updateSearchHistory() {
        this.jpSearchHistory.removeAll();
        if (this.llSearchHistory.size() == 0) {
            final GridBagConstraints c = new GridBagConstraints();
            c.weightx = 1.0;
            c.anchor = 17;
            this.jpSearchHistory.add(Util.generateNoneTextLabel("No searches have been done so far"), c);
        }
        else {
            for (int i = this.llSearchHistory.size() - 1; i >= 0; --i) {
                this.addEntryToSearchListingPanel(this.llSearchHistory, i, "searchFromHistory", this.jpSearchHistory, this.iconFavourite, "addFavouriteSearchInstance", "<html>Click to add to your local favourite searches - these will be available every time you use Taverna.<br>(This will not affect your myExperiment profile settings.)</html>");
            }
        }
        this.jpSearchHistory.repaint();
        this.jpSearchHistory.revalidate();
        if (this.pluginMainComponent.getHistoryBrowser() != null) {
            this.pluginMainComponent.getHistoryBrowser().refreshSearchHistory();
        }
    }
    
    private void addEntryToSearchListingPanel(final List<SearchEngine.QuerySearchInstance> searchInstanceList, final int iIndex, final String searchAction, final JPanel panelToPopulate, final ImageIcon entryIcon, final String iconAction, final String iconActionTooltip) {
        final JClickableLabel jclCurrentEntryLabel = new JClickableLabel(searchInstanceList.get(iIndex).getSearchQuery(), searchAction + ":" + iIndex, this, WorkbenchIcons.findIcon, 2, searchInstanceList.get(iIndex).toString());
        final JLabel jlCurrentEntrySettings = new JLabel(searchInstanceList.get(iIndex).detailsAsString());
        jlCurrentEntrySettings.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
        final JPanel jpCurentEntryDetails = new JPanel();
        jpCurentEntryDetails.setLayout(new GridBagLayout());
        final GridBagConstraints c = new GridBagConstraints();
        c.anchor = 17;
        jpCurentEntryDetails.add(jclCurrentEntryLabel, c);
        c.weightx = 1.0;
        jpCurentEntryDetails.add(jlCurrentEntrySettings, c);
        final JClickableLabel jclFavourite = new JClickableLabel("", iconAction + ":" + iIndex, this, entryIcon, 2, iconActionTooltip);
        jclFavourite.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
        final JPanel jpCurrentEntry = new JPanel();
        jpCurrentEntry.setLayout(new GridBagLayout());
        c.anchor = 17;
        c.weightx = 1.0;
        jpCurrentEntry.add(jpCurentEntryDetails, c);
        c.anchor = 17;
        c.weightx = 0.0;
        jpCurrentEntry.add(jclFavourite, c);
        c.fill = 2;
        c.weightx = 1.0;
        c.gridx = 0;
        c.gridy = -1;
        panelToPopulate.add(jpCurrentEntry, c);
    }
    
    @Override
    public void actionPerformed(final ActionEvent e) {
        if (e.getSource().equals(this.jpSearchOptions.bSearch)) {
            if (this.jpSearchOptions.getSearchQuery().length() == 0) {
                JOptionPane.showMessageDialog(null, "Search query is empty. Please specify your search query and try again.", "Error", 2);
                this.jpSearchOptions.focusSearchQueryField();
            }
            else {
                try {
                    this.jpSearchOptions.jsResultLimit.commitEdit();
                }
                catch (ParseException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid search result limit value. This should be an\ninteger in the range of 1..100", "MyExperiment Plugin - Error", 2);
                    this.jpSearchOptions.tfResultLimitTextField.selectAll();
                    this.jpSearchOptions.tfResultLimitTextField.requestFocusInWindow();
                    return;
                }
                this.siPreviousSearch = new SearchEngine.QuerySearchInstance(this.jpSearchOptions.getSearchQuery(), this.jpSearchOptions.getResultCountLimit(), this.jpSearchOptions.getSearchWorkflows(), this.jpSearchOptions.getSearchFiles(), this.jpSearchOptions.getSearchPacks(), this.jpSearchOptions.getSearchUsers(), this.jpSearchOptions.getSearchGroups());
                this.jpSearchOptions.focusSearchQueryField();
                this.runSearch();
            }
        }
        else if (e.getSource() instanceof JClickableLabel) {
            if (e.getActionCommand().startsWith("searchFromHistory") || e.getActionCommand().startsWith("searchFromFavourites")) {
                final int iEntryID = Integer.parseInt(e.getActionCommand().substring(e.getActionCommand().indexOf(":") + 1));
                final SearchEngine.QuerySearchInstance si = e.getActionCommand().startsWith("searchFromHistory") ? this.llSearchHistory.remove(iEntryID) : this.llFavouriteSearches.get(iEntryID);
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        SearchTabContentPanel.this.jpSearchOptions.setSearchQuery(si.getSearchQuery());
                        SearchTabContentPanel.this.jpSearchOptions.setSearchAllResourceTypes(false);
                        SearchTabContentPanel.this.jpSearchOptions.setSearchWorkflows(si.getSearchWorkflows());
                        SearchTabContentPanel.this.jpSearchOptions.setSearchFiles(si.getSearchFiles());
                        SearchTabContentPanel.this.jpSearchOptions.setSearchPacks(si.getSearchPacks());
                        SearchTabContentPanel.this.jpSearchOptions.setSearchUsers(si.getSearchUsers());
                        SearchTabContentPanel.this.jpSearchOptions.setSearchGroups(si.getSearchGroups());
                        SearchTabContentPanel.this.jpSearchOptions.setResultCountLimit(si.getResultCountLimit());
                        SearchTabContentPanel.this.siPreviousSearch = si;
                        SearchTabContentPanel.this.runSearch();
                    }
                });
            }
            else if (e.getActionCommand().startsWith("addFavouriteSearchInstance")) {
                final int iHistID = Integer.parseInt(e.getActionCommand().substring(e.getActionCommand().indexOf(":") + 1));
                final SearchEngine.QuerySearchInstance si = this.llSearchHistory.get(iHistID);
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        SearchTabContentPanel.this.addToFavouriteSearches(si);
                        SearchTabContentPanel.this.updateFavouriteSearches();
                    }
                });
            }
            else if (e.getActionCommand().startsWith("removeFavouriteSearchInstance")) {
                final int iFavouriteID = Integer.parseInt(e.getActionCommand().substring(e.getActionCommand().indexOf(":") + 1));
                this.llFavouriteSearches.remove(iFavouriteID);
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        SearchTabContentPanel.this.updateFavouriteSearches();
                    }
                });
            }
        }
        else if (e.getSource().equals(this.jpSearchResults.bRefresh)) {
            this.jpSearchResults.bClear.setEnabled(false);
            this.rerunLastSearch();
        }
        else if (e.getSource().equals(this.jpSearchResults.bClear)) {
            this.siPreviousSearch = null;
            this.vCurrentSearchThreadID.set(0, null);
            this.jpSearchResults.clear();
            this.jpSearchResults.setStatus("No searches have been done so far");
            this.jpSearchResults.bClear.setEnabled(false);
            this.jpSearchResults.bRefresh.setEnabled(false);
        }
    }
    
    private void runSearch() {
        this.runSearch(true);
    }
    
    private void runSearch(final boolean bUpdateHistory) {
        if (bUpdateHistory) {
            this.addToSearchHistory(this.siPreviousSearch);
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    SearchTabContentPanel.this.updateSearchHistory();
                }
            });
        }
        this.searchEngine.searchAndPopulateResults(this.siPreviousSearch);
    }
    
    public void rerunLastSearch() {
        if (this.siPreviousSearch != null) {
            this.runSearch();
        }
    }
    
    public SearchResultsPanel getSearchResultPanel() {
        return this.jpSearchResults;
    }
    
    public LinkedList<SearchEngine.QuerySearchInstance> getSearchFavouritesList() {
        return this.llFavouriteSearches;
    }
    
    public LinkedList<SearchEngine.QuerySearchInstance> getSearchHistory() {
        return this.llSearchHistory;
    }
}
