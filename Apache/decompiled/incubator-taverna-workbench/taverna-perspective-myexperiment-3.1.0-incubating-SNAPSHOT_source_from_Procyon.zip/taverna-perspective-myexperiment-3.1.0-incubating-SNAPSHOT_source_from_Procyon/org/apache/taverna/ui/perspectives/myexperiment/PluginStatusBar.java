// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import java.awt.event.ActionEvent;
import org.apache.taverna.ui.perspectives.myexperiment.model.Util;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.BorderFactory;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import javax.swing.JLabel;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

public class PluginStatusBar extends JPanel implements ActionListener
{
    private static final String STATUS_MESSAGE_READY = "Ready";
    private MainComponent pluginMainComponent;
    private MyExperimentClient myExperimentClient;
    private Logger logger;
    private JLabel lSpinnerIcon;
    private JLabel lStatusMsg;
    private JLabel lCurrentUser;
    ArrayList<String> alTabClassNames;
    ArrayList<String> alTabStatuses;
    ImageIcon iconSpinner;
    ImageIcon iconSpinnerStopped;
    
    public PluginStatusBar(final MainComponent component, final MyExperimentClient client, final Logger logger) {
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.alTabClassNames = new ArrayList<String>();
        this.alTabStatuses = new ArrayList<String>();
        this.iconSpinner = new ImageIcon(MyExperimentPerspective.getLocalResourceURL("spinner"));
        this.iconSpinnerStopped = new ImageIcon(MyExperimentPerspective.getLocalResourceURL("spinner_stopped"));
        this.setLayout(new BorderLayout());
        this.setBorder(BorderFactory.createEmptyBorder(1, 4, 1, 1));
        this.lSpinnerIcon = new JLabel("", this.iconSpinnerStopped, 2);
        this.lStatusMsg = new JLabel("Ready");
        this.lCurrentUser = new JLabel("Please log in to access your profile", 0);
        final JPanel pWestStatusBarSection = new JPanel();
        pWestStatusBarSection.add(this.lSpinnerIcon);
        pWestStatusBarSection.add(this.lStatusMsg);
        this.add(pWestStatusBarSection, "West");
        this.add(this.lCurrentUser, "East");
    }
    
    public void setCurrentUser(final String strUsername) {
        if (strUsername == null || strUsername.length() == 0) {
            this.lCurrentUser.setText("Please log in to access your profile");
        }
        else {
            this.lCurrentUser.setText("<html>Logged in as <b>" + strUsername + "</b></html>");
        }
    }
    
    public void displayStatus(final String strTabClassName) {
        int iTabIdx = -1;
        final String strBaseClassName = Util.getBaseClassName(strTabClassName);
        if ((iTabIdx = this.alTabClassNames.indexOf(strBaseClassName)) != -1) {
            final String strCurStatus = this.alTabStatuses.get(iTabIdx);
            this.lStatusMsg.setText(strCurStatus);
            this.startSpinner(!strCurStatus.equals("Ready"));
        }
        else {
            this.setStatus(strBaseClassName, null);
        }
    }
    
    public void setStatus(final String strTabClassName, String strStatus) {
        if (strStatus == null || strStatus.length() == 0) {
            strStatus = "Ready";
        }
        final String strBaseClassName = Util.getBaseClassName(strTabClassName);
        int iTabIdx = -1;
        if ((iTabIdx = this.alTabClassNames.indexOf(strBaseClassName)) != -1) {
            this.alTabStatuses.set(iTabIdx, strStatus);
        }
        else {
            this.alTabClassNames.add(strBaseClassName);
            this.alTabStatuses.add(strStatus);
        }
        if (this.isTabActive(strBaseClassName)) {
            this.displayStatus(strBaseClassName);
        }
    }
    
    public void startSpinner(final boolean bStart) {
        this.lSpinnerIcon.setIcon(bStart ? this.iconSpinner : this.iconSpinnerStopped);
    }
    
    private boolean isTabActive(final String strTabClassName) {
        final String strCurSelectedTabClassName = this.pluginMainComponent.getMainTabs().getSelectedComponent().getClass().getName();
        final String strBaseClassName = Util.getBaseClassName(strTabClassName);
        return strBaseClassName.equals(strCurSelectedTabClassName);
    }
    
    @Override
    public void actionPerformed(final ActionEvent e) {
    }
}
