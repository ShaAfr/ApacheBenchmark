// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import org.apache.taverna.scufl2.api.container.WorkflowBundle;
import org.apache.taverna.workbench.file.exceptions.OpenException;
import java.awt.Frame;
import org.apache.taverna.workbench.file.importworkflow.gui.ImportWorkflowWizard;
import org.apache.taverna.workbench.file.FileType;
import javax.swing.JOptionPane;
import java.io.ByteArrayInputStream;
import org.apache.taverna.ui.perspectives.myexperiment.model.Workflow;
import java.net.URI;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import org.apache.taverna.ui.perspectives.myexperiment.model.Resource;
import javax.swing.AbstractAction;
import javax.swing.event.ChangeEvent;
import javax.swing.JFrame;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.Component;
import org.apache.taverna.lang.ui.ShadedLabel;
import org.apache.taverna.workbench.icons.WorkbenchIcons;
import javax.swing.ImageIcon;
import javax.swing.text.html.HTMLEditorKit;
import org.apache.taverna.workbench.selection.SelectionManager;
import org.apache.taverna.workbench.configuration.workbench.WorkbenchConfiguration;
import org.apache.taverna.workbench.configuration.colour.ColourManager;
import org.apache.taverna.ui.menu.MenuManager;
import org.apache.taverna.workbench.file.FileManager;
import org.apache.taverna.workbench.edits.EditManager;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import javax.swing.JTabbedPane;
import javax.swing.text.html.StyleSheet;
import org.apache.log4j.Logger;
import javax.swing.event.ChangeListener;
import org.apache.taverna.workbench.ui.zaria.UIComponentSPI;
import javax.swing.JPanel;

public final class MainComponent extends JPanel implements UIComponentSPI, ChangeListener
{
    private final Logger logger;
    private final StyleSheet css;
    private final ResourcePreviewFactory previewFactory;
    private final ResourcePreviewBrowser previewBrowser;
    private JTabbedPane tpMainTabs;
    private MyStuffTabContentPanel pMyStuffContainer;
    private ExampleWorkflowsPanel pExampleWorkflows;
    private TagBrowserTabContentPanel pTagBrowser;
    private SearchTabContentPanel pSearchTab;
    private HistoryBrowserTabContentPanel pHistoryBrowserTab;
    private PluginStatusBar pStatusBar;
    private PluginPreferencesDialog jdPreferences;
    public static MainComponent MAIN_COMPONENT;
    public static MyExperimentClient MY_EXPERIMENT_CLIENT;
    public static Logger LOGGER;
    private final EditManager editManager;
    private final FileManager fileManager;
    private final MyExperimentClient myExperimentClient;
    private final MenuManager menuManager;
    private final ColourManager colourManager;
    private final WorkbenchConfiguration workbenchConfiguration;
    private final SelectionManager selectionManager;
    
    public MainComponent(final EditManager editManager, final FileManager fileManager, final MyExperimentClient myExperimentClient, final MenuManager menuManager, final ColourManager colourManager, final WorkbenchConfiguration workbenchConfiguration, final SelectionManager selectionManager) {
        this.logger = Logger.getLogger((Class)MainComponent.class);
        this.editManager = editManager;
        this.fileManager = fileManager;
        this.myExperimentClient = myExperimentClient;
        this.menuManager = menuManager;
        this.colourManager = colourManager;
        this.workbenchConfiguration = workbenchConfiguration;
        this.selectionManager = selectionManager;
        final MainComponent x = MainComponent.MAIN_COMPONENT = this;
        final MyExperimentClient y = MainComponent.MY_EXPERIMENT_CLIENT = this.myExperimentClient;
        final Logger z = MainComponent.LOGGER = this.logger;
        this.previewFactory = new ResourcePreviewFactory(this, myExperimentClient, this.logger);
        this.previewBrowser = new ResourcePreviewBrowser(this, myExperimentClient, this.logger, fileManager);
        (this.css = new StyleSheet()).importStyleSheet(MyExperimentPerspective.getLocalResourceURL("css_stylesheet"));
        this.logger.debug((Object)("Stylesheet loaded: \n" + this.css.toString()));
        if (myExperimentClient.getSettings().getProperty("default_tab_for_anonymous_users") == null) {
            myExperimentClient.getSettings().put("default_tab_for_anonymous_users", "3");
        }
        if (myExperimentClient.getSettings().getProperty("default_tab_for_logged_in_users") == null) {
            myExperimentClient.getSettings().put("default_tab_for_logged_in_users", "0");
        }
        this.initialisePerspectiveUI();
        final HTMLEditorKit kit = new StyledHTMLEditorKit(this.css);
        new Thread("Data initialisation for Taverna 2 - myExperiment plugin") {
            @Override
            public void run() {
                MainComponent.this.initialiseData();
            }
        }.start();
    }
    
    public ImageIcon getIcon() {
        return WorkbenchIcons.databaseIcon;
    }
    
    public String getName() {
        return "myExperiment Perspective Main Component";
    }
    
    public void onDisplay() {
    }
    
    public void onDispose() {
    }
    
    public MyExperimentClient getMyExperimentClient() {
        return this.myExperimentClient;
    }
    
    public Logger getLogger() {
        return this.logger;
    }
    
    public StyleSheet getStyleSheet() {
        return this.css;
    }
    
    public PluginStatusBar getStatusBar() {
        return this.pStatusBar;
    }
    
    public PluginPreferencesDialog getPreferencesDialog() {
        return this.jdPreferences;
    }
    
    public ResourcePreviewFactory getPreviewFactory() {
        return this.previewFactory;
    }
    
    public ResourcePreviewBrowser getPreviewBrowser() {
        return this.previewBrowser;
    }
    
    public HistoryBrowserTabContentPanel getHistoryBrowser() {
        return this.pHistoryBrowserTab;
    }
    
    public JTabbedPane getMainTabs() {
        return this.tpMainTabs;
    }
    
    public MyStuffTabContentPanel getMyStuffTab() {
        return this.pMyStuffContainer;
    }
    
    public ExampleWorkflowsPanel getExampleWorkflowsTab() {
        return this.pExampleWorkflows;
    }
    
    public TagBrowserTabContentPanel getTagBrowserTab() {
        return this.pTagBrowser;
    }
    
    public SearchTabContentPanel getSearchTab() {
        return this.pSearchTab;
    }
    
    private void initialisePerspectiveUI() {
        final ShadedLabel testLabel = new ShadedLabel("test", ShadedLabel.BLUE);
        this.pStatusBar = new PluginStatusBar(this, this.myExperimentClient, this.logger);
        this.pMyStuffContainer = new MyStuffTabContentPanel(this, this.myExperimentClient, this.logger, this.fileManager);
        this.pExampleWorkflows = new ExampleWorkflowsPanel(this, this.myExperimentClient, this.logger);
        this.pTagBrowser = new TagBrowserTabContentPanel(this, this.myExperimentClient, this.logger);
        this.pSearchTab = new SearchTabContentPanel(this, this.myExperimentClient, this.logger);
        this.pHistoryBrowserTab = new HistoryBrowserTabContentPanel(this, this.myExperimentClient, this.logger);
        (this.tpMainTabs = new JTabbedPane()).add("My Stuff", this.pMyStuffContainer);
        this.tpMainTabs.add("Starter Pack", this.pExampleWorkflows);
        this.tpMainTabs.add("Tag Browser", this.pTagBrowser);
        this.tpMainTabs.add("Search", this.pSearchTab);
        this.tpMainTabs.add("Local History", this.pHistoryBrowserTab);
        this.setLayout(new BorderLayout());
        this.add(this.tpMainTabs, "Center");
        this.add(this.pStatusBar, "South");
        this.tpMainTabs.addChangeListener(this);
        this.jdPreferences = new PluginPreferencesDialog(this.getPreviewBrowser(), this, this.myExperimentClient, this.logger);
    }
    
    private void initialiseData() {
        this.logger.debug((Object)"Initialising myExperiment Perspective data");
        final Object oAutoLogin = this.myExperimentClient.getSettings().get("auto_login");
        if (oAutoLogin != null && oAutoLogin.equals("true")) {
            this.getStatusBar().setStatus(this.getMyStuffTab().getClass().getName(), "Performing autologin");
            this.myExperimentClient.doLogin();
            this.getStatusBar().setStatus(this.getMyStuffTab().getClass().getName(), "Autologin finished. Fetching user data");
        }
        this.pMyStuffContainer.createAndInitialiseInnerComponents();
        if (this.myExperimentClient.isLoggedIn()) {
            this.tpMainTabs.setSelectedIndex(Integer.parseInt(this.myExperimentClient.getSettings().getProperty("default_tab_for_logged_in_users")));
            this.pTagBrowser.setMyTagsShown(true);
        }
        else {
            this.tpMainTabs.setSelectedIndex(Integer.parseInt(this.myExperimentClient.getSettings().getProperty("default_tab_for_anonymous_users")));
        }
        this.pExampleWorkflows.refresh();
        this.pTagBrowser.refresh();
    }
    
    public void stateChanged(final ChangeEvent e) {
        if (e.getSource().equals(this.tpMainTabs)) {
            this.getStatusBar().displayStatus(this.getMainTabs().getSelectedComponent().getClass().getName());
        }
    }
    
    public class PreviewResourceAction extends AbstractAction
    {
        private int iResourceType;
        private String strResourceURI;
        
        public PreviewResourceAction(final int iResourceType, final String strResourceURI) {
            this.iResourceType = 0;
            this.strResourceURI = "";
            this.putValue("SmallIcon", WorkbenchIcons.zoomIcon);
            this.putValue("Name", "Preview");
            this.putValue("ShortDescription", "Preview this " + Resource.getResourceTypeName(iResourceType).toLowerCase() + " in the Preview Browser window");
            this.iResourceType = iResourceType;
            this.strResourceURI = strResourceURI;
        }
        
        @Override
        public void actionPerformed(final ActionEvent actionEvent) {
            MainComponent.this.getPreviewBrowser().preview("preview:" + this.iResourceType + ":" + this.strResourceURI);
        }
    }
    
    public class DownloadResourceAction extends AbstractAction
    {
        private Resource resource;
        
        public DownloadResourceAction(final MainComponent this$0, final Resource resource) {
            this(this$0, resource, true);
        }
        
        public DownloadResourceAction(final Resource resource, final boolean bShowButtonLabel) {
            this.resource = null;
            this.resource = resource;
            final String strResourceType = resource.getItemTypeName().toLowerCase();
            this.putValue("SmallIcon", WorkbenchIcons.saveIcon);
            if (bShowButtonLabel) {
                this.putValue("Name", "Download");
            }
            String strTooltip = "Downloading " + strResourceType + "s is currently not possible";
            boolean bDownloadAllowed = false;
            if (resource.isDownloadable()) {
                if (resource.isDownloadAllowed()) {
                    strTooltip = "Download this " + strResourceType + " and store it locally";
                    bDownloadAllowed = true;
                }
                else {
                    strTooltip = "You don't have permissions to download this " + strResourceType;
                }
            }
            this.setEnabled(bDownloadAllowed);
            this.putValue("ShortDescription", strTooltip);
        }
        
        @Override
        public void actionPerformed(final ActionEvent actionEvent) {
            try {
                Desktop.getDesktop().browse(new URI(this.resource.getResource() + "/download"));
                MainComponent.this.getHistoryBrowser().getDownloadedItemsHistoryList().remove(this.resource);
                MainComponent.this.getHistoryBrowser().getDownloadedItemsHistoryList().add(this.resource);
                if (MainComponent.this.getHistoryBrowser().getDownloadedItemsHistoryList().size() > 50) {
                    MainComponent.this.getHistoryBrowser().getDownloadedItemsHistoryList().remove(0);
                }
                if (MainComponent.this.getHistoryBrowser() != null) {
                    MainComponent.this.getHistoryBrowser().refreshHistoryBox(1);
                }
            }
            catch (Exception ex) {
                MainComponent.this.logger.error((Object)("Failed while trying to open download URL in a standard browser; URL was: " + this.resource.getURI() + "\nException was: " + ex));
            }
        }
    }
    
    public class LoadResourceInTavernaAction extends AbstractAction
    {
        private final Resource resource;
        
        public LoadResourceInTavernaAction(final MainComponent this$0, final Resource resource) {
            this(this$0, resource, true);
        }
        
        public LoadResourceInTavernaAction(final Resource resource, final boolean bShowButtonLabel) {
            this.resource = resource;
            final String strResourceType = resource.getItemTypeName().toLowerCase();
            this.putValue("SmallIcon", WorkbenchIcons.openIcon);
            if (bShowButtonLabel) {
                this.putValue("Name", "Open");
            }
            boolean bLoadingAllowed = false;
            String strTooltip = "Loading " + strResourceType + "s into Taverna Workbench is currently not possible";
            if (resource.getItemType() == 10) {
                if (((Workflow)resource).isTavernaWorkflow()) {
                    if (resource.isDownloadAllowed()) {
                        bLoadingAllowed = true;
                        strTooltip = "Download and load this workflow in Design mode of Taverna Workbench";
                    }
                    else {
                        strTooltip = "You don't have permissions to download this workflow, and thus to load into Taverna Workbench";
                    }
                }
                else {
                    strTooltip = "Loading workflow of unsupported type into Taverna Workbench is not possible.";
                }
            }
            this.setEnabled(bLoadingAllowed);
            this.putValue("ShortDescription", strTooltip);
        }
        
        @Override
        public void actionPerformed(final ActionEvent actionEvent) {
            if (MainComponent.this.getPreviewBrowser().isActive()) {
                MainComponent.this.getPreviewBrowser().toBack();
            }
            final String strCallerTabClassName = MainComponent.this.getMainTabs().getSelectedComponent().getClass().getName();
            MainComponent.this.getStatusBar().setStatus(strCallerTabClassName, "Downloading and opening workflow...");
            MainComponent.this.logger.debug((Object)("Downloading and opening workflow from URI: " + this.resource.getURI()));
            new Thread("Download and open workflow") {
                @Override
                public void run() {
                    try {
                        final Workflow w = MainComponent.this.myExperimentClient.fetchWorkflowBinary(LoadResourceInTavernaAction.this.resource.getURI());
                        final ByteArrayInputStream workflowDataInputStream = new ByteArrayInputStream(w.getContent());
                        final FileType fileTypeType = w.isTaverna1Workflow() ? new ScuflFileType() : new T2FlowFileType();
                        MainComponent.this.fileManager.openDataflow(fileTypeType, (Object)workflowDataInputStream);
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "An error has occurred while trying to load a workflow from myExperiment.\n\n" + e, "Error", 0);
                        MainComponent.this.logger.error((Object)"Failed to open connection to URL to download and open workflow, from myExperiment.", (Throwable)e);
                    }
                    MainComponent.this.getStatusBar().setStatus(strCallerTabClassName, null);
                    MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().remove(LoadResourceInTavernaAction.this.resource);
                    MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().add(LoadResourceInTavernaAction.this.resource);
                    if (MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().size() > 50) {
                        MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().remove(0);
                    }
                    if (MainComponent.this.getHistoryBrowser() != null) {
                        MainComponent.this.getHistoryBrowser().refreshHistoryBox(2);
                    }
                }
            }.start();
        }
    }
    
    public class ImportIntoTavernaAction extends AbstractAction
    {
        private final Resource resource;
        private boolean importAsNesting;
        
        public ImportIntoTavernaAction(final Resource r) {
            this.resource = r;
            final String strResourceType = this.resource.getItemTypeName().toLowerCase();
            this.putValue("SmallIcon", WorkbenchIcons.importIcon);
            this.putValue("Name", "Import");
            boolean bLoadingAllowed = false;
            String strTooltip = "Loading " + strResourceType + "s into Taverna Workbench is currently not possible";
            if (this.resource.getItemType() == 10) {
                if (((Workflow)this.resource).isTavernaWorkflow()) {
                    if (this.resource.isDownloadAllowed()) {
                        bLoadingAllowed = true;
                        strTooltip = "Import this workflow into one that is currently open in the Design mode of Taverna Workbench";
                    }
                    else {
                        strTooltip = "You don't have permissions to download this workflow, and thus to load into Taverna Workbench";
                    }
                }
                else {
                    strTooltip = "Loading workflow of unsupported type into Taverna Workbench is not possible.";
                }
            }
            this.setEnabled(bLoadingAllowed);
            this.putValue("ShortDescription", strTooltip);
        }
        
        @Override
        public void actionPerformed(final ActionEvent actionEvent) {
            if (MainComponent.this.getPreviewBrowser().isActive()) {
                MainComponent.this.getPreviewBrowser().toBack();
            }
            final ImportWorkflowWizard importWorkflowDialog = new ImportWorkflowWizard((Frame)MainComponent.this.getPreviewBrowser(), MainComponent.this.editManager, MainComponent.this.fileManager, MainComponent.this.menuManager, MainComponent.this.colourManager, MainComponent.this.workbenchConfiguration, MainComponent.this.selectionManager);
            Workflow w;
            try {
                w = MainComponent.MY_EXPERIMENT_CLIENT.fetchWorkflowBinary(this.resource.getURI());
            }
            catch (Exception e) {
                JOptionPane.showMessageDialog(null, "An error has occurred while trying to load a workflow from myExperiment.\n\n" + e, "Error", 0);
                MainComponent.LOGGER.error((Object)"Failed to open connection to URL to download and open workflow, from myExperiment.", (Throwable)e);
                return;
            }
            final ByteArrayInputStream workflowDataInputStream = new ByteArrayInputStream(w.getContent());
            final FileType fileTypeType = w.isTaverna1Workflow() ? new ScuflFileType() : new T2FlowFileType();
            WorkflowBundle toBeImported;
            try {
                toBeImported = MainComponent.this.fileManager.openDataflowSilently(fileTypeType, (Object)workflowDataInputStream).getDataflow();
            }
            catch (OpenException e2) {
                JOptionPane.showMessageDialog(null, "An error has occurred while trying to load a workflow from myExperiment.\n\n" + e2, "Error", 0);
                MainComponent.LOGGER.error((Object)"Failed to open connection to URL to download and open workflow, from myExperiment.", (Throwable)e2);
                return;
            }
            importWorkflowDialog.setCustomSourceDataflow(toBeImported, "From myExperiment: " + this.resource.getTitle());
            importWorkflowDialog.setSourceEnabled(false);
            importWorkflowDialog.setVisible(true);
            MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().remove(this.resource);
            MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().add(this.resource);
            if (MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().size() > 50) {
                MainComponent.this.getHistoryBrowser().getOpenedItemsHistoryList().remove(0);
            }
            if (MainComponent.this.getHistoryBrowser() != null) {
                MainComponent.this.getHistoryBrowser().refreshHistoryBox(2);
            }
        }
    }
    
    public static class ScuflFileType extends FileType
    {
        public String getDescription() {
            return "Taverna 1 SCUFL workflow";
        }
        
        public String getExtension() {
            return "xml";
        }
        
        public String getMimeType() {
            return "application/vnd.taverna.scufl+xml";
        }
    }
    
    public static class T2FlowFileType extends FileType
    {
        public String getDescription() {
            return "Taverna 2 workflow";
        }
        
        public String getExtension() {
            return "t2flow";
        }
        
        public String getMimeType() {
            return "application/vnd.taverna.t2flow+xml";
        }
    }
    
    public static class WorkflowBundleFileType extends FileType
    {
        public String getDescription() {
            return "Taverna 3 workflow bundle";
        }
        
        public String getExtension() {
            return "wfbundle";
        }
        
        public String getMimeType() {
            return "application/vnd.taverna.scufl2.workflow-bundle";
        }
    }
}
