// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class TagCloud
{
    private List<Tag> tags;
    
    public TagCloud() {
        this.tags = new ArrayList<Tag>();
    }
    
    public List<Tag> getTags() {
        return this.tags;
    }
    
    public void clear() {
        this.tags.clear();
    }
    
    public void addAll(final List<Tag> newTags) {
        this.tags.addAll(newTags);
    }
    
    public int getMaxTagCount() {
        int iMax = 0;
        for (final Tag t : this.tags) {
            if (t.getCount() > iMax) {
                iMax = t.getCount();
            }
        }
        return iMax;
    }
}
