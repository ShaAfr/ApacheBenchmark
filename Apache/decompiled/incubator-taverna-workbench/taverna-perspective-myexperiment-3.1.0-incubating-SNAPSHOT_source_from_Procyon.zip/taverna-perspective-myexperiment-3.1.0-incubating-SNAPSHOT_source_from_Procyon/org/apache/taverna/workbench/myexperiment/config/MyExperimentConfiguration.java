// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.workbench.myexperiment.config;

import java.util.HashMap;
import org.apache.taverna.configuration.ConfigurationManager;
import java.util.Map;
import org.apache.taverna.configuration.AbstractConfigurable;

public class MyExperimentConfiguration extends AbstractConfigurable
{
    private Map<String, String> defaultPropertyMap;
    
    public MyExperimentConfiguration(final ConfigurationManager configurationManager) {
        super(configurationManager);
    }
    
    public String getCategory() {
        return "general";
    }
    
    public Map<String, String> getDefaultPropertyMap() {
        if (this.defaultPropertyMap == null) {
            this.defaultPropertyMap = new HashMap<String, String>();
        }
        return this.defaultPropertyMap;
    }
    
    public String getDisplayName() {
        return "myExperiment";
    }
    
    public String getFilePrefix() {
        return "myExperiment";
    }
    
    public String getUUID() {
        return "d25867g1-6078-22ee-bf27-1911311d0b77";
    }
}
