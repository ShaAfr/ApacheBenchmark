// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import org.apache.log4j.Logger;
import org.apache.taverna.workbench.ShutdownSPI;

public class MyExperimentClientShutdownHook implements ShutdownSPI
{
    private MyExperimentClient myExperimentClient;
    private Logger logger;
    
    public MyExperimentClientShutdownHook() {
        this.logger = Logger.getLogger((Class)MyExperimentClientShutdownHook.class);
    }
    
    public int positionHint() {
        return 100;
    }
    
    public boolean shutdown() {
        if (this.myExperimentClient == null) {
            return true;
        }
        this.logger.debug((Object)"Starting shutdown operations for myExperiment plugin");
        try {
            this.myExperimentClient.storeHistoryAndSettings();
        }
        catch (Exception e) {
            this.logger.error((Object)("Failed while serializing myExperiment plugin settings:\n" + e));
        }
        this.logger.debug((Object)"myExperiment plugin shutdown is completed; terminated...");
        return true;
    }
    
    public void setMyExperimentClient(final MyExperimentClient myExperimentClient) {
        this.myExperimentClient = myExperimentClient;
    }
    
    public MyExperimentClient getMyExperimentClient() {
        return this.myExperimentClient;
    }
}
