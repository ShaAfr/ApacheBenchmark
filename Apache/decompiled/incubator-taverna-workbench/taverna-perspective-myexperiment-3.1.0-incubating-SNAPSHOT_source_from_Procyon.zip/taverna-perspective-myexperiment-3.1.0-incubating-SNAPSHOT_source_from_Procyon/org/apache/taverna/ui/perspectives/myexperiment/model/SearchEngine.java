// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import java.io.Serializable;
import java.util.Iterator;
import javax.swing.SwingUtilities;
import javax.swing.JComponent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.jdom.Element;
import org.jdom.Document;
import java.awt.Component;
import javax.swing.JOptionPane;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.MainComponent;
import org.apache.taverna.ui.perspectives.myexperiment.SearchResultsPanel;
import java.util.Vector;

public class SearchEngine
{
    private Vector<Long> vCurrentSearchThreadID;
    private boolean bSearchByTag;
    private String strSearchQuery;
    private SearchResultsPanel jpResultsPanel;
    private MainComponent pluginMainComponent;
    private MyExperimentClient myExperimentClient;
    private Logger logger;
    
    public SearchEngine(final Vector<Long> currentSearchThreadIDVector, final boolean bSearchByTag, final SearchResultsPanel resultsPanel, final MainComponent pluginMainComponent, final MyExperimentClient client, final Logger logger) {
        this.vCurrentSearchThreadID = currentSearchThreadIDVector;
        this.bSearchByTag = bSearchByTag;
        this.jpResultsPanel = resultsPanel;
        this.pluginMainComponent = pluginMainComponent;
        this.myExperimentClient = client;
        this.logger = logger;
    }
    
    public void searchAndPopulateResults(final String tagQuery) {
        this.strSearchQuery = tagQuery;
        new Thread("Search by tag") {
            @Override
            public void run() {
                final long lThisSearchThreadID = Thread.currentThread().getId();
                SearchEngine.this.vCurrentSearchThreadID.set(0, lThisSearchThreadID);
                SearchEngine.this.pluginMainComponent.getStatusBar().setStatus(SearchEngine.this.pluginMainComponent.getTagBrowserTab().getClass().getName(), "Searching");
                SearchEngine.this.strSearchQuery = Tag.instantiateTagFromActionCommand(SearchEngine.this.strSearchQuery).getTagName();
                SearchEngine.this.jpResultsPanel.setCurrentSearchTerm(SearchEngine.this.strSearchQuery);
                SearchEngine.this.jpResultsPanel.setStatus("Starting to search for a tag '" + SearchEngine.this.strSearchQuery + "'...");
                final Document doc = SearchEngine.this.myExperimentClient.searchByTag(SearchEngine.this.strSearchQuery);
                if (doc == null) {
                    SearchEngine.this.logger.error((Object)"Failed while fetching tagged items. See the error message above. Can't continue.");
                    JOptionPane.showMessageDialog(null, "An error occurred while searching for the results of your query. Please try again.", "Error", 0);
                }
                else {
                    final Element root = doc.getRootElement();
                    SearchEngine.this.processSearchResults(lThisSearchThreadID, root.getChildren());
                }
            }
        }.start();
    }
    
    public void searchAndPopulateResults(final QuerySearchInstance querySearchDetails) {
        final QuerySearchInstance searchQuery = querySearchDetails;
        this.strSearchQuery = searchQuery.getSearchQuery();
        new Thread("Search by query") {
            @Override
            public void run() {
                final long lThisSearchThreadID = Thread.currentThread().getId();
                SearchEngine.this.vCurrentSearchThreadID.set(0, lThisSearchThreadID);
                SearchEngine.this.pluginMainComponent.getStatusBar().setStatus(SearchEngine.this.pluginMainComponent.getSearchTab().getClass().getName(), "Searching");
                SearchEngine.this.strSearchQuery = SearchEngine.this.strSearchQuery.replaceFirst("search:", "");
                SearchEngine.this.jpResultsPanel.setCurrentSearchTerm(SearchEngine.this.strSearchQuery);
                SearchEngine.this.jpResultsPanel.setStatus("Starting to search for '" + SearchEngine.this.strSearchQuery + "'...");
                final Document doc = SearchEngine.this.myExperimentClient.searchByQuery(searchQuery);
                if (doc == null) {
                    SearchEngine.this.logger.error((Object)"Failed while fetching search result XML document. See the error message above. Can't continue.");
                    JOptionPane.showMessageDialog(null, "An error occurred while searching for the results of your query. Please try again.", "Error", 0);
                }
                else {
                    final Element root = doc.getRootElement();
                    SearchEngine.this.processSearchResults(lThisSearchThreadID, root.getChildren());
                }
            }
        }.start();
    }
    
    private void processSearchResults(final Long thisSearchThreadID, final List<Element> foundSearchItemElements) {
        final Long lThisSearchThreadID = thisSearchThreadID;
        final List<Element> lFoundSearchItemElements = foundSearchItemElements;
        final HashMap<Integer, ArrayList<Resource>> hmClassifiedResults = new HashMap<Integer, ArrayList<Resource>>();
        for (final Element foundItem : foundSearchItemElements) {
            if (!lThisSearchThreadID.equals(this.vCurrentSearchThreadID.get(0))) {
                return;
            }
            final Resource res = Resource.buildFromXML(foundItem, this.myExperimentClient, this.logger);
            if (!hmClassifiedResults.containsKey(res.getItemType())) {
                hmClassifiedResults.put(res.getItemType(), new ArrayList<Resource>());
            }
            hmClassifiedResults.get(res.getItemType()).add(res);
        }
        if (lThisSearchThreadID.equals(this.vCurrentSearchThreadID.get(0))) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    SearchEngine.this.jpResultsPanel.setStatus(lFoundSearchItemElements.size() + " items found " + (SearchEngine.this.bSearchByTag ? "with tag '" : "by query '") + SearchEngine.this.jpResultsPanel.getCurrentSearchTerm() + "'");
                    SearchEngine.this.jpResultsPanel.setSearchResultsData(hmClassifiedResults);
                    SearchEngine.this.jpResultsPanel.refresh();
                    final JComponent jcTabForWhichToSetStatus = (JComponent)(SearchEngine.this.bSearchByTag ? SearchEngine.this.pluginMainComponent.getTagBrowserTab() : SearchEngine.this.pluginMainComponent.getSearchTab());
                    SearchEngine.this.pluginMainComponent.getStatusBar().setStatus(jcTabForWhichToSetStatus.getClass().getName(), null);
                }
            });
        }
    }
    
    public static class QuerySearchInstance implements Comparable<QuerySearchInstance>, Serializable
    {
        private String strSearchQuery;
        private int iResultCountLimit;
        private boolean bSearchWorkflows;
        private boolean bSearchFiles;
        private boolean bSearchPacks;
        private boolean bSearchUsers;
        private boolean bSearchGroups;
        
        public QuerySearchInstance(final String searchQuery, final int resultCountLimit, final boolean searchWorkflows, final boolean searchFiles, final boolean searchPacks, final boolean searchUsers, final boolean searchGroups) {
            this.strSearchQuery = searchQuery;
            this.iResultCountLimit = resultCountLimit;
            this.bSearchWorkflows = searchWorkflows;
            this.bSearchFiles = searchFiles;
            this.bSearchPacks = searchPacks;
            this.bSearchUsers = searchUsers;
            this.bSearchGroups = searchGroups;
        }
        
        @Override
        public boolean equals(final Object other) {
            if (other instanceof QuerySearchInstance) {
                final QuerySearchInstance si = (QuerySearchInstance)other;
                return this.strSearchQuery.equals(si.getSearchQuery()) && this.iResultCountLimit == si.getResultCountLimit() && this.bSearchWorkflows == si.getSearchWorkflows() && this.bSearchFiles == si.getSearchFiles() && this.bSearchPacks == si.getSearchPacks() && this.bSearchUsers == si.getSearchUsers() && this.bSearchGroups == si.getSearchGroups();
            }
            return false;
        }
        
        @Override
        public int compareTo(final QuerySearchInstance other) {
            if (this.equals(other)) {
                return 0;
            }
            return -1 * this.toString().compareTo(other.toString());
        }
        
        @Override
        public String toString() {
            return "Search: '" + this.strSearchQuery + "' " + this.detailsAsString();
        }
        
        public String detailsAsString() {
            String str = "";
            int iCnt = 0;
            if (this.bSearchWorkflows) {
                str += "workflows, ";
                ++iCnt;
            }
            if (this.bSearchFiles) {
                str += "files, ";
                ++iCnt;
            }
            if (this.bSearchPacks) {
                str += "packs, ";
                ++iCnt;
            }
            if (this.bSearchUsers) {
                str += "users, ";
                ++iCnt;
            }
            if (this.bSearchGroups) {
                str += "groups, ";
                ++iCnt;
            }
            if (iCnt == 5) {
                str = "all";
            }
            else {
                str = str.substring(0, str.length() - 2);
            }
            str = "[" + str + "; limit: " + this.iResultCountLimit + "]";
            return str;
        }
        
        public String getSearchQuery() {
            return this.strSearchQuery;
        }
        
        public int getResultCountLimit() {
            return this.iResultCountLimit;
        }
        
        public boolean getSearchWorkflows() {
            return this.bSearchWorkflows;
        }
        
        public boolean getSearchFiles() {
            return this.bSearchFiles;
        }
        
        public boolean getSearchPacks() {
            return this.bSearchPacks;
        }
        
        public boolean getSearchUsers() {
            return this.bSearchUsers;
        }
        
        public boolean getSearchGroups() {
            return this.bSearchGroups;
        }
    }
}
