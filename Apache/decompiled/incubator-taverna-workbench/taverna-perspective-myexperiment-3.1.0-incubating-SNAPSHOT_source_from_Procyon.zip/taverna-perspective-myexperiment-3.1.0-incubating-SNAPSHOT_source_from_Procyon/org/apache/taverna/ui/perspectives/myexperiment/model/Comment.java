// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment.model;

import org.jdom.Element;
import org.apache.log4j.Logger;
import org.jdom.Document;

public class Comment extends Resource
{
    private User user;
    private String comment;
    private int typeOfCommentedResource;
    private String uriOfCommetedResource;
    
    public Comment() {
        this.setItemType(31);
    }
    
    public User getUser() {
        return this.user;
    }
    
    public void setUser(final User user) {
        this.user = user;
    }
    
    public String getComment() {
        return this.comment;
    }
    
    public void setComment(final String comment) {
        this.comment = comment;
    }
    
    public int getTypeOfCommentedResource() {
        return this.typeOfCommentedResource;
    }
    
    public void setTypeOfCommentedResource(final int typeOfCommentedResource) {
        this.typeOfCommentedResource = typeOfCommentedResource;
    }
    
    public String getURIOfCommentedResource() {
        return this.uriOfCommetedResource;
    }
    
    public void setURIOfCommentedResource(final String uriOfCommetedResource) {
        this.uriOfCommetedResource = uriOfCommetedResource;
    }
    
    public static String getRequiredAPIElements(final int iRequestType) {
        String strElements = "";
        switch (iRequestType) {
            case 5100: {
                strElements += "";
                break;
            }
        }
        return strElements;
    }
    
    public static Comment buildFromXML(final Document doc, final Logger logger) {
        if (doc == null) {
            return null;
        }
        final Comment c = new Comment();
        try {
            final Element root = doc.getRootElement();
            c.setResource(root.getAttributeValue("resource"));
            c.setURI(root.getAttributeValue("uri"));
            c.setTitle(root.getChildText("comment"));
            c.setComment(root.getChildText("comment"));
            final Element commentedResourceElement = root.getChild("subject");
            if (commentedResourceElement != null) {
                c.setTypeOfCommentedResource(Resource.getResourceTypeFromVisibleName(commentedResourceElement.getName()));
                c.setURIOfCommentedResource(commentedResourceElement.getAttributeValue("uri"));
            }
            final Element userElement = root.getChild("author");
            c.setUser(Util.instantiatePrimitiveUserFromElement(userElement));
            final String createdAt = root.getChildText("created-at");
            if (createdAt != null && !createdAt.equals("")) {
                c.setCreatedAt(MyExperimentClient.parseDate(createdAt));
            }
            logger.debug((Object)("Found information for comment with ID: " + c.getID() + ", URI: " + c.getURI()));
        }
        catch (Exception e) {
            logger.error((Object)"Failed midway through creating comment object from XML", (Throwable)e);
        }
        return c;
    }
}
