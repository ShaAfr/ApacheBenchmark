// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.taverna.ui.perspectives.myexperiment;

import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Insets;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import org.apache.taverna.lang.ui.ShadedLabel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ComponentListener;
import javax.swing.JOptionPane;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentAdapter;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import org.apache.taverna.workbench.file.FileManager;
import javax.swing.JComponent;
import java.util.concurrent.CountDownLatch;
import javax.swing.JSplitPane;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import org.apache.log4j.Logger;
import org.apache.taverna.ui.perspectives.myexperiment.model.MyExperimentClient;
import java.awt.event.KeyListener;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

public class MyStuffTabContentPanel extends JPanel implements ActionListener, KeyListener
{
    private final MainComponent pluginMainComponent;
    private final MyExperimentClient myExperimentClient;
    private final Logger logger;
    private JButton bLogin;
    private JCheckBox cbLoginAutomatically;
    private MyStuffSidebarPanel jpSidebar;
    public JSplitPane spMyStuff;
    protected CountDownLatch cdlComponentLoadingDone;
    int NUMBER_OF_SUBCOMPONENTS;
    protected JComponent cTabContentComponentToSwitchToAfterLogin;
    private final FileManager fileManager;
    
    public MyStuffTabContentPanel(final MainComponent component, final MyExperimentClient client, final Logger logger, final FileManager fileManager) {
        this.NUMBER_OF_SUBCOMPONENTS = 2;
        this.cTabContentComponentToSwitchToAfterLogin = null;
        this.pluginMainComponent = component;
        this.myExperimentClient = client;
        this.logger = logger;
        this.fileManager = fileManager;
    }
    
    public void createAndInitialiseInnerComponents() {
        this.removeAll();
        this.cdlComponentLoadingDone = new CountDownLatch(this.NUMBER_OF_SUBCOMPONENTS);
        if (this.myExperimentClient.isLoggedIn()) {
            this.jpSidebar = new MyStuffSidebarPanel(this.pluginMainComponent, this.myExperimentClient, this.logger, this.fileManager);
            final JPanel jpSidebarContainer = new JPanel();
            jpSidebarContainer.setLayout(new BorderLayout());
            jpSidebarContainer.add(this.jpSidebar, "North");
            final JScrollPane spSidebar = new JScrollPane(jpSidebarContainer);
            spSidebar.getVerticalScrollBar().setUnitIncrement(10);
            spSidebar.setMinimumSize(new Dimension(this.jpSidebar.getMyProfileBox().getPreferredSize().width + 30, 0));
            (this.spMyStuff = new JSplitPane()).setLeftComponent(spSidebar);
            this.spMyStuff.setRightComponent(new MyStuffContributionsPanel(this.pluginMainComponent, this.myExperimentClient, this.logger));
            this.pluginMainComponent.getStatusBar().setCurrentUser(this.myExperimentClient.getCurrentUser().getName());
            this.pluginMainComponent.addComponentListener(new ComponentAdapter() {
                @Override
                public void componentShown(final ComponentEvent e) {
                    JOptionPane.showMessageDialog(null, "component shown");
                    try {
                        Thread.sleep(50L);
                    }
                    catch (Exception ex) {}
                    MyStuffTabContentPanel.this.spMyStuff.setDividerLocation(400);
                }
            });
            this.spMyStuff.setResizeWeight(0.3);
            this.spMyStuff.setOneTouchExpandable(true);
            this.spMyStuff.setDividerLocation(400);
            this.spMyStuff.setDoubleBuffered(true);
            this.setLayout(new BorderLayout());
            this.add(this.spMyStuff);
            new Thread("Waiting for myStuff data to load") {
                @Override
                public void run() {
                    try {
                        MyStuffTabContentPanel.this.cdlComponentLoadingDone.await();
                        MyStuffTabContentPanel.this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), null);
                    }
                    catch (InterruptedException ex) {}
                }
            }.start();
        }
        else {
            this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), null);
            final JPanel jpLoginBoxContainer = new JPanel();
            jpLoginBoxContainer.setLayout(new GridBagLayout());
            final GridBagConstraints c = new GridBagConstraints();
            jpLoginBoxContainer.add(this.createLoginBox(), c);
            this.setLayout(new BorderLayout());
            this.add((Component)new ShadedLabel("Welcome to the myExperiment plugin. Please note that you can still use other tabs even if you don't have a user profile yet!", ShadedLabel.BLUE), "North");
            this.add(jpLoginBoxContainer, "Center");
        }
    }
    
    private JPanel createLoginBox() {
        final JPanel jpLoginBox = new JPanel();
        jpLoginBox.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        jpLoginBox.setLayout(new GridBagLayout());
        final GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = 0;
        c.insets = new Insets(0, 0, 15, 0);
        c.gridx = 0;
        c.gridy = 0;
        final JLabel jlHeader = new JLabel("<html><b>Log in to myExperiment</b></html>");
        jlHeader.setFont(jlHeader.getFont().deriveFont(13.0f));
        jpLoginBox.add(jlHeader, c);
        c.weightx = 1.0;
        c.gridwidth = 1;
        c.anchor = 21;
        c.insets = new Insets(0, 0, 3, 0);
        c.ipadx = 10;
        final GridBagConstraints gridBagConstraints = c;
        ++gridBagConstraints.gridy;
        c.insets = new Insets(0, 0, 0, 3);
        (this.cbLoginAutomatically = new JCheckBox("Log in automatically (next time)")).setBorder(BorderFactory.createEmptyBorder());
        this.cbLoginAutomatically.addActionListener(this);
        this.cbLoginAutomatically.addKeyListener(this);
        jpLoginBox.add(this.cbLoginAutomatically, c);
        final GridBagConstraints gridBagConstraints2 = c;
        ++gridBagConstraints2.gridy;
        c.gridx = 0;
        c.anchor = 10;
        c.gridwidth = 0;
        c.fill = 2;
        c.insets = new Insets(10, 0, 0, 0);
        (this.bLogin = new JButton("Login", new ImageIcon(MyExperimentPerspective.getLocalResourceURL("login_icon")))).setDefaultCapable(true);
        this.bLogin.addKeyListener(this);
        this.bLogin.addActionListener(this);
        jpLoginBox.add(this.bLogin, c);
        return jpLoginBox;
    }
    
    public MyStuffSidebarPanel getSidebar() {
        return this.jpSidebar;
    }
    
    @Override
    public void actionPerformed(final ActionEvent e) {
        if (e.getSource().equals(this.bLogin)) {
            this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), "Logging in");
            new Thread("Login to myExperiment") {
                @Override
                public void run() {
                    MyStuffTabContentPanel.this.logger.debug((Object)"Logging in to myExperiment");
                    try {
                        final boolean bLoginSuccessful = MyStuffTabContentPanel.this.myExperimentClient.doLogin();
                        if (bLoginSuccessful) {
                            MyStuffTabContentPanel.this.myExperimentClient.getSettings().put("auto_login", new Boolean(MyStuffTabContentPanel.this.cbLoginAutomatically.isSelected()).toString());
                            MyStuffTabContentPanel.this.myExperimentClient.storeHistoryAndSettings();
                            MyStuffTabContentPanel.this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), "Fetching user data");
                            SwingUtilities.invokeLater(new Runnable() {
                                @Override
                                public void run() {
                                    if (MyStuffTabContentPanel.this.myExperimentClient.isLoggedIn()) {
                                        MyStuffTabContentPanel.this.createAndInitialiseInnerComponents();
                                        MyStuffTabContentPanel.this.pluginMainComponent.getTagBrowserTab().setMyTagsShown(true);
                                        MyStuffTabContentPanel.this.pluginMainComponent.getTagBrowserTab().getMyTagPanel().refresh();
                                        MyStuffTabContentPanel.this.pluginMainComponent.getTagBrowserTab().rerunLastTagSearch();
                                        MyStuffTabContentPanel.this.pluginMainComponent.getSearchTab().rerunLastSearch();
                                        if (MyStuffTabContentPanel.this.cTabContentComponentToSwitchToAfterLogin != null) {
                                            MyStuffTabContentPanel.this.pluginMainComponent.getMainTabs().setSelectedComponent(MyStuffTabContentPanel.this.cTabContentComponentToSwitchToAfterLogin);
                                            MyStuffTabContentPanel.this.cTabContentComponentToSwitchToAfterLogin = null;
                                        }
                                        MyStuffTabContentPanel.this.logger.debug((Object)"Logged in to myExperiment successfully");
                                    }
                                    else {
                                        MyStuffTabContentPanel.this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), null);
                                        JOptionPane.showMessageDialog(null, "Unable to login to myExperiment - please check your login details", "myExperiment Plugin - Couldn't Login", 0);
                                    }
                                }
                            });
                        }
                    }
                    catch (Exception ex) {
                        MyStuffTabContentPanel.this.logger.error((Object)"Exception on attempt to login to myExperiment:\n", (Throwable)ex);
                    }
                }
            }.start();
        }
        else if (e.getSource().equals(this.jpSidebar.bRefreshMyStuff)) {
            this.pluginMainComponent.getStatusBar().setStatus(this.getClass().getName(), "Refreshing user data");
            new Thread("Refreshing myStuff tab data") {
                @Override
                public void run() {
                    MyStuffTabContentPanel.this.myExperimentClient.setCurrentUser(MyStuffTabContentPanel.this.myExperimentClient.fetchCurrentUser(MyStuffTabContentPanel.this.myExperimentClient.getCurrentUser().getURI()));
                    MyStuffTabContentPanel.this.createAndInitialiseInnerComponents();
                    MyStuffTabContentPanel.this.revalidate();
                }
            }.start();
        }
    }
    
    @Override
    public void keyPressed(final KeyEvent e) {
        if (e.getKeyCode() == 10 && (e.getSource().equals(this.cbLoginAutomatically) || e.getSource().equals(this.bLogin))) {
            this.actionPerformed(new ActionEvent(this.bLogin, 0, ""));
        }
    }
    
    @Override
    public void keyReleased(final KeyEvent e) {
    }
    
    @Override
    public void keyTyped(final KeyEvent e) {
    }
}
